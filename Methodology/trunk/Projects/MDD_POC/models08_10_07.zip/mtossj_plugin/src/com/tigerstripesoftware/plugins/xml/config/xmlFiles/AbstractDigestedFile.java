package com.tigerstripesoftware.plugins.xml.config.xmlFiles;

public interface AbstractDigestedFile
{

}
