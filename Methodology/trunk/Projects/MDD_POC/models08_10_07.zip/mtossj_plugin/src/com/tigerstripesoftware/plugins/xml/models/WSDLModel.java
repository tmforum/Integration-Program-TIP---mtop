package com.tigerstripesoftware.plugins.xml.models;


import com.tigerstripesoftware.api.external.IextPluginReference;
import com.tigerstripesoftware.api.external.TigerstripeException;
import com.tigerstripesoftware.api.external.model.IextMethod;
import com.tigerstripesoftware.api.external.model.artifacts.IArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextSessionArtifact;
import com.tigerstripesoftware.api.external.plugins.IPluginAwareArtifactModel;
import com.tigerstripesoftware.api.external.plugins.PluginLog;
import com.tigerstripesoftware.api.external.profile.stereotype.IextStereotypeInstance;


public class WSDLModel extends BaseModel {

	/**
	 * Override to ignore the special case for Sessions
	 */
	public String getName(){	
		String name = this.artifact.getName();
		PluginLog.logTrace("Getting name for WSDL "+name+"V"+getVersion());
		return name+"V"+getVersion();
	}
		
	/**
	 * Override to set a WSDL (rather than XSD) filename
	 */
	public String getFileName(){
		try {
			String filePath = this.pluginRef.getProperty("wsdlFilePath").toString();
			String fileName = filePath+"/"+getName();
            return fileName+".wsdl";

		} catch (Exception e){
			PluginLog.logError("Failure to build wsdlFileName", e);
			return this.artifact.getName()+"Vunknown"+".xsd";
		}
	}
	
}
