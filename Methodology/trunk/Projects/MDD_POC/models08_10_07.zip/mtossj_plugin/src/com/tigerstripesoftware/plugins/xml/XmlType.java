/*
 * (c) 2005 4DH Software, Inc.  All rights reserved.  
 * 
 * TigerStripe is a registered Trademark of 4DH Software, Inc. 
 * 
 * You may use  this file only under the 4DH License Agreement 
 * located at 
 * 		http://www.tigerstripesoftware.com/licenses/TIGERSTRIPE_LICENSE.txt 
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
 * implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * 	Created on Apr 12, 2005
 *
 */
package com.tigerstripesoftware.plugins.xml;

import java.io.File;
import java.util.Date;

import com.tigerstripesoftware.api.external.IextPluginReference;
import com.tigerstripesoftware.api.external.TigerstripeException;
import com.tigerstripesoftware.api.external.model.artifacts.IArtifact;
import com.tigerstripesoftware.api.external.plugins.PluginLog;
import com.tigerstripesoftware.api.external.project.IextTigerstripeProject;
import com.tigerstripesoftware.plugins.xml.config.xmlFiles.XMLDigesterException;
import com.tigerstripesoftware.plugins.xml.config.xmlFiles.language.LanguageDigester;
import com.tigerstripesoftware.plugins.xml.config.xmlFiles.language.Language_Mapping;



/**
 * This should return a type that can be used in the XML
 * in the manner of 
 * $xmlNamespaces.typeNSOf($field.ContainingArtifact.FullyQualifiedName,"").Prefix
 * 
 * the passed fqn might be anything - eg an int, a String or an Artifact
 */
public class XmlType {
	
	private static Language_Mapping languageMapping;
	private static Long oldLanguageFileDate;
	private static File oldLanguageFile;

	protected static void setMappings(IextPluginReference pluginRef) {
		/* 
		 * Language Mappings
		 */
		if (pluginRef.getProperty("languageMappingsUri") == null){
			PluginLog.logTrace("languageMappingsUri not enabled for this plugin");
			languageMapping = new Language_Mapping();
		} else {
			//      Need to reread config if the file has changed.
			// So also need to save details of current file when we read it
			String languageUrl = String.valueOf(pluginRef.getProperty("languageMappingsUri"));
			File newLanguageFile = new File(pluginRef.getProjectHandle().getBaseDir()+File.separator+languageUrl);
			if ( oldLanguageFile != null && 
					(!newLanguageFile.getAbsolutePath().equals(oldLanguageFile.getAbsolutePath()) ||
							(newLanguageFile.lastModified() != oldLanguageFileDate))){
				// File has been changed 
				PluginLog.logInfo("LanguageMappings File has been changed");
				PluginLog.logInfo("New File : "+new Date(newLanguageFile.lastModified()));
				languageMapping = null;
			} else {
				PluginLog.logInfo("LanguageMappings File no change");
			}
			
			if (languageMapping == null ){
				try {

					PluginLog.logInfo("Setting Language Mapping ");
					LanguageDigester uot = new LanguageDigester();
					oldLanguageFile = newLanguageFile;
					oldLanguageFileDate = oldLanguageFile.lastModified();
					try {
						uot.setUrl(pluginRef.getProjectHandle().getBaseDir()+File.separator+languageUrl);
					} catch (XMLDigesterException e) {
						PluginLog.logError("Could not set URL to "+languageUrl+" in Language Mappings");
						//throw new CartridgeException ("Could not set URL to "+url+" in setMapping",e);
					}
					languageMapping = uot.getRoot();


				} catch (NullPointerException n){
					PluginLog.logDebug("Defaulting Language Mapping ");
					languageMapping = new Language_Mapping();
				}
			}
		}
	}
	
	
	private XmlNamespaces.NamespaceRef nRef;

	
	/** This is the element name in the XML **/
	private String name;
	
	/** This is the key name in the XML where relevant **/
	private String keyName;

	/** This is the keyResult name in the XML where relevant **/
	private String keyResultName;

	/** A string of "[]" or ""  and a boolean that does what it says **/
	private String dimensions;
	private boolean isArray;

	/** The FQN of the object passed in **/
	private String fullyQualifiedName;
	

	/** The project where to look up artifacts **/
	private IextTigerstripeProject project;
	
	/** The pluginRef for this plugin **/
	private IextPluginReference pluginRef;
	
	private String localPrefix;
	
	public XmlType(String fullyQualifiedName,
			String dimensions,
			XmlNamespaces.NamespaceRef nRef,
			IextTigerstripeProject project,
			IextPluginReference pluginRef)
	    throws TigerstripeException{
		
		this.fullyQualifiedName = fullyQualifiedName;
		this.dimensions = dimensions;
		this.nRef = nRef;
		localPrefix = nRef.prefix;
		this.project = project;
		this.pluginRef = pluginRef;
		
		if ("[]".equals(this.dimensions)) {
			this.isArray = true;
		} else {
			this.isArray= false;
		}
		
		build();
	}
	
	private void build() throws TigerstripeException {
		setMappings(this.pluginRef);
		PluginLog.logTrace(languageMapping.toString());
	//	String commonNamespacePrefix = this.pluginRef.getProperty("OSSJSchemaPrefix").toString();
		String commonNamespacePrefix = XmlNamespaces.defaultPrefix;
		IArtifact artifact = this.project.getIextArtifactManagerSession()
           .getIArtifactByFullyQualifiedName(fullyQualifiedName, true);
		

		if (artifact != null){
			
			String nameToUse = "";
			if (this.isArray) {
				nameToUse = "ArrayOf"+capitalize(artifact.getName());
			} else {
				//nameToUse = unCapitalize(artifact.getName());
				// TODO Use of this seems a bit inconsistent
				nameToUse = artifact.getName();
			}

			if (artifact.getIArtifactType().endsWith("ManagedEntityArtifact") ){ 
				this.name          =  nameToUse;// +"Value";
				this.keyName       =  nameToUse +"Key";
				this.keyResultName =  nameToUse +"KeyResult";
			} else if (artifact.getIArtifactType().endsWith("QueryArtifact")
					|| artifact.getIArtifactType().endsWith("UpdateProcedureArtifact")){
				this.name          = nameToUse;// +"Value";
				this.keyName       = this.name;
				this.keyResultName = this.name;
			} else if (artifact.getIArtifactType().endsWith("EventArtifact")){ 
				this.name          = nameToUse +"Type";
				this.keyName       = this.name;
				this.keyResultName = this.name;
			} else {
				this.name          = nameToUse;
				this.keyName       = this.name;
				this.keyResultName = this.name;
			}
		} else {
			// It's not an artifact !
			// This could be a primitive type that we must map

			if (this.isArray){
				if (languageMapping.containsfrom(this.fullyQualifiedName)){
					PluginLog.logDebug("Mapping for "+ this.fullyQualifiedName + " to "+languageMapping.getTo(this.fullyQualifiedName));
					this.name = "ArrayOf" +  capitalize(languageMapping.getTo(this.fullyQualifiedName));
				} else {
					PluginLog.logDebug("No mapping for "+ this.fullyQualifiedName);
					this.name = "ArrayOf" + capitalize(this.fullyQualifiedName);
				}
				localPrefix=commonNamespacePrefix;
			} else {
				if (languageMapping.containsfrom(this.fullyQualifiedName)){
					PluginLog.logDebug("Mapping for "+ this.fullyQualifiedName + " to "+languageMapping.getTo(this.fullyQualifiedName));
					this.name = languageMapping.getTo(this.fullyQualifiedName);
				} else {
					PluginLog.logDebug("No mapping for "+ this.fullyQualifiedName);
					this.name = this.fullyQualifiedName;
				}
				localPrefix="";
			}
			this.keyName = this.name;
			this.keyResultName = this.name;


		} 

	}
	
	private String capitalize(String str) {
		return str.substring(0, 1).toUpperCase()
				+ str.substring(1, str.length());
	}

	private String unCapitalize(String str) {
		return str.substring(0, 1).toLowerCase()
				+ str.substring(1, str.length());
	}
	
	public String getPrefix() {
		return localPrefix;
	}
	
	public String getName() {
		if (localPrefix.equals("")){
			return this.name;
		}else {
			return localPrefix+":"+this.name;
		}
	}

	public String getNameNoNS() {
		return this.name;
	}
	
	public String getKeyName() {
		if (localPrefix.equals("")){
			return this.keyName;
		}else {
			return localPrefix+":"+this.keyName;
		}
	}

	public String getKeyNameNoNS() {
		return this.keyName;
	}
	
	public String getKeyResultName() {
		if (localPrefix.equals("")){
			return this.keyResultName;
		}else {
			return localPrefix+":"+this.keyResultName;
		}
	}

	public String getKeyResultNameNoNS() {
		return this.keyResultName;
	}

}