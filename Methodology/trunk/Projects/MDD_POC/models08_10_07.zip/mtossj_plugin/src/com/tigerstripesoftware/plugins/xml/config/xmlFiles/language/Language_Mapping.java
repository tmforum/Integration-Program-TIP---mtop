package com.tigerstripesoftware.plugins.xml.config.xmlFiles.language;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.tigerstripesoftware.plugins.xml.config.xmlFiles.AbstractDigestedFile;

public class Language_Mapping implements AbstractDigestedFile{

    HashMap<String, Mapping> mappings = new HashMap();
    public void addMapping(Mapping mapping){
        mappings.put(mapping.getFrom(),mapping);
    }
    
    public boolean containsfrom(String from){
        return mappings.containsKey(from);
    }
    
    public String getTo(String from){
        return mappings.get(from).getTo();
    }
    
    public String toString(){
        String out = "language mapping:\n";
        for (Iterator i = mappings.values().iterator();i.hasNext();){
            Object res =  i.next();
            out += res.toString()+"\n";
        }
        
        return out;
    }
}