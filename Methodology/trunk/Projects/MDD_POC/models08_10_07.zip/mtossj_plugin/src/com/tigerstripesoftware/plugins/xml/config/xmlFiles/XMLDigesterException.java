package com.tigerstripesoftware.plugins.xml.config.xmlFiles;

public class XMLDigesterException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8084901577522464650L;

	public XMLDigesterException(Exception e) {
		super (e);
	}
	
	public XMLDigesterException(String s,Exception e) {
		super (s,e);
	}
	

}
