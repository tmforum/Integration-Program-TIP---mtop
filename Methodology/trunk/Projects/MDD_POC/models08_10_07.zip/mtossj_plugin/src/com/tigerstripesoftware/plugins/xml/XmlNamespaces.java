package com.tigerstripesoftware.plugins.xml;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import com.tigerstripesoftware.api.external.IextArtifactManagerSession;
import com.tigerstripesoftware.api.external.IextPluginReference;
import com.tigerstripesoftware.api.external.TigerstripeException;
import com.tigerstripesoftware.api.external.model.IextMethod;
import com.tigerstripesoftware.api.external.model.IextModelComponent;
import com.tigerstripesoftware.api.external.model.IextMethod.IextArgument;
import com.tigerstripesoftware.api.external.model.IextMethod.IextException;
import com.tigerstripesoftware.api.external.model.artifacts.IArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextAssociationArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextAssociationEnd;
import com.tigerstripesoftware.api.external.model.artifacts.IextEnumArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextManagedEntityArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextQueryArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextSessionArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextSessionArtifact.IextManagedEntityDetails;
import com.tigerstripesoftware.api.external.model.artifacts.ossjSpecifics.IextOssjEntitySpecifics;
import com.tigerstripesoftware.api.external.plugins.IArtifactModel;
import com.tigerstripesoftware.api.external.plugins.IExpander;
import com.tigerstripesoftware.api.external.plugins.IextTablePPluginProperty;
import com.tigerstripesoftware.api.external.plugins.PluginLog;
import com.tigerstripesoftware.api.external.project.IextProjectDescriptor;
import com.tigerstripesoftware.api.external.project.IextTigerstripeProject;
import com.tigerstripesoftware.api.external.queries.IArtifactQuery;
import com.tigerstripesoftware.api.external.queries.IQueryAllArtifacts;
import com.tigerstripesoftware.api.external.queries.IQueryModelArtifacts;
import com.tigerstripesoftware.api.external.queries.IQueryRelationshipsByArtifact;
import com.tigerstripesoftware.api.external.queries.IQuerySessionArtifacts;
import com.tigerstripesoftware.plugins.xml.models.BaseModel;

/**
 * This helper class needs to work out the location of all artifacts 
 * be they local or otherwise.
 * 
 * It needs to look at all of the options for the schema structure. 
 * 
 * @author Richard Craddock
 *
 */
public class XmlNamespaces {
	
	private static boolean USE_COMMON_FOR_DEFAULT = false;
	
    public class NamespaceRef {
        public String targetNamespace;

        public String targetLocation;

        public String prefix;

        public String getNamespace() {
            return targetNamespace;
        }

        public String getPrefix() {
            return prefix;
        }

        public String getLocation() {
            return targetLocation;
        }

        @Override
        public boolean equals(Object arg0) {
            if (arg0 instanceof NamespaceRef) {
                NamespaceRef other = (NamespaceRef) arg0;
                return targetLocation.equals(other.targetLocation);
            }
            return false;
        }
    }
	
	private ArrayList<NamespaceRef> nRefList;
	private IextPluginReference pluginRef;
	private IextTigerstripeProject project;
	private IExpander expander;
	private int sessionCount;
	private Collection sessions;
	
	public static final String defaultPrefix = "unknown";
	public static final String defaultLocation = "schema.xsd";
	public static final String defaultNamespace = "unknown";
	
	public NamespaceRef defaultNamespaceRef = new NamespaceRef();
	

	/**
	 * This version is used in the case of a single artifact.
	 * 
	 * @param artifact
	 * @param pluginRef
	 * @param project
	 * @throws TigerstripeException
	 */
	public void buildImportsList(IArtifact artifact,
			IextPluginReference pluginRef,
			IextTigerstripeProject project,
			IExpander expander)
    throws TigerstripeException {
		ArrayList<IArtifact> collection = new ArrayList<IArtifact> ();
		collection.add(artifact);
		buildImportsList(collection,  pluginRef,  project, expander, true);
	}
	
	/**
	 * Populate the list of namespaceRefs based on a list of model components.
	 * These might be Fields or Artifacts
	 * 
	 * @param contents
	 */
	public void buildImportsList(Collection<IArtifact> contents, 
			IextPluginReference pluginRef,
			IextTigerstripeProject project,
			IExpander expander,
			boolean doReferences)
	    throws TigerstripeException {

		nRefList = new ArrayList<NamespaceRef>();
		this.pluginRef = pluginRef;
		this.project = project;
		this.expander = expander;

		defaultNamespaceRef.prefix = defaultPrefix;
		defaultNamespaceRef.targetLocation = defaultLocation;
		defaultNamespaceRef.targetNamespace = defaultNamespace;
 
        
		try {
			IArtifactQuery sessionQuery = this.project.getIextArtifactManagerSession().makeQuery(IQuerySessionArtifacts.class.getName());
			this.sessions = this.project.getIextArtifactManagerSession().queryArtifact(sessionQuery);
			this.sessionCount = sessions.size();	
		} catch (TigerstripeException t){
			this.sessionCount = 0;
		}
        
        // Iterate over the contents in this model and its dependencies
        for (Iterator<IArtifact> iter = contents.iterator(); iter.hasNext();) {
        	IArtifact artifact = iter.next();
        	
        	// ========= Do the artifact itself ================//
        	NamespaceRef nRef = getNSRef(artifact.getFullyQualifiedName());
        	if ( nRef != null && !refListContains(nRef)) {
        		PluginLog.logDebug("Imports : Adding artifact "+artifact.getName());
                nRefList.add(nRef);
            }
        	
        	// *Always* have to do the extending artifact
        	if (artifact.hasExtends()){
				nRef = getNSRef(artifact.getExtendedIArtifact().getFullyQualifiedName());
				if ( nRef != null && !refListContains(nRef)) {
					PluginLog.logDebug("Imports : Adding artifact Extension "+artifact.getExtendedIArtifact().getName());
					nRefList.add(nRef);
				}
			}

        	
            // ========= Do the things the artifact refers to ================//
        	// *Generally* only Required if dealing with a single artifact //
        	if (doReferences == true){
        		Collection references = artifact.getReferencedArtifacts();
        		for (Iterator refIter = references.iterator(); refIter.hasNext();) {
        			String fqn = (String) refIter.next();
        			nRef = getNSRef(fqn);
        			if (nRef != null && !refListContains(nRef)) {
        				PluginLog.logDebug("Imports : Adding (ref) artifact "+fqn);
        				nRefList.add(nRef);
        			}

        			
/*  REMOVED FROM MTOSSJ VERSION               	
 * // If an enum need to do the extended artifact as well (for now)
        			IArtifact art = this.project.getIextArtifactManagerSession().getIArtifactByFullyQualifiedName(fqn,true);
        			
        			if (art != null){
        				PluginLog.logDebug("Art " + art.getName());
        			//	if (art instanceof IextEnumArtifact){
        					if (art.hasExtends()){
        						for (IArtifact ancestor : art.getAncestors()){
        							nRef = getNSRef(ancestor.getFullyQualifiedName());
        							
        							if ( nRef != null && !refListContains(nRef)) {
        								PluginLog.logDebug("Ext Ref  " + nRef.getNamespace());
        								nRefList.add(nRef);
        							}
        						}
        					}
        			//	}
        					
        			}*/

        			
        			// Need the return type, arguments and exceptions from methods 

        			if (artifact instanceof IextSessionArtifact){
        				IextSessionArtifact session = (IextSessionArtifact) artifact;
        				for (IextMethod method : session.getIextMethods()){
                            // Do the Return type
							String returnFQN = method.getReturnIextType().getFullyQualifiedName();
							nRef = getNSRef(returnFQN);
							if (nRef != null && !refListContains(nRef)) {
								PluginLog.logDebug("Imports : Adding (method Return) artifact "+returnFQN);
								nRefList.add(nRef);
							}
							// And the arguments
							for (IextArgument arg : method.getIextArguments()){
								String argumentFQN = arg.getIextType().getFullyQualifiedName();
								nRef = getNSRef(argumentFQN);
								if (nRef != null && !refListContains(nRef)) {
									PluginLog.logDebug("Imports : Adding (method Argument) artifact "+argumentFQN);
									nRefList.add(nRef);
								}
							}
							// And the Exceptions
							for (IextException exception : method.getIextExceptions()){
								String exceptionFQN = exception.getFullyQualifiedName();
								nRef = getNSRef(exceptionFQN);
								if (nRef != null && !refListContains(nRef)) {
									PluginLog.logDebug("Imports : Adding (method Exception) artifact "+exceptionFQN);
									nRefList.add(nRef);
								}
							}
        				}
/*  REMOVED FROM MTOSSJ VERSION 
 *       				for (IextManagedEntityDetails details : session.getIextManagedEntityDetails()){
        					// EntitySpecifics has the supportedFlavors - but we need the Entity (not the entity details)
        					if (details.isResolvedToArtifact()){
        						IextManagedEntityArtifact entity = (IextManagedEntityArtifact) this.project.getIextArtifactManagerSession().getIArtifactByFullyQualifiedName(details.getFullyQualifiedName());
        						    int crud = IextOssjEntitySpecifics.CREATE;
        							IextMethod.OssjEntityMethodFlavor[] flavors = ((IextOssjEntitySpecifics) entity.getIextStandardSpecifics()).getSupportedFlavors(crud);
        							for (IextMethod.OssjEntityMethodFlavor flavor : flavors){
        								if( details.getCreateFlavorDetails(flavor).getFlag().equals("true") || 
        										details.getCreateFlavorDetails(flavor).getFlag().equals("optional")){
        									for (String exception : details.getCreateFlavorDetails(flavor).getExceptions()){
        										nRef = getNSRef(exception);
        										if (nRef != null && !refListContains(nRef)) {
        											nRefList.add(nRef);
        										}
        									}
        								}
        							}
        							crud = IextOssjEntitySpecifics.GET;
        							flavors = ((IextOssjEntitySpecifics) entity.getIextStandardSpecifics()).getSupportedFlavors(crud);
        							for (IextMethod.OssjEntityMethodFlavor flavor : flavors){
        								if( details.getGetFlavorDetails(flavor).getFlag().equals("true") || 
        										details.getGetFlavorDetails(flavor).getFlag().equals("optional")){
        									for (String exception : details.getGetFlavorDetails(flavor).getExceptions()){
        										nRef = getNSRef(exception);
        										if (nRef != null && !refListContains(nRef)) {
        											nRefList.add(nRef);
        										}
        									}
        								}
        							}
        							crud = IextOssjEntitySpecifics.SET;
        							flavors = ((IextOssjEntitySpecifics) entity.getIextStandardSpecifics()).getSupportedFlavors(crud);
        							for (IextMethod.OssjEntityMethodFlavor flavor : flavors){
        								if( details.getSetFlavorDetails(flavor).getFlag().equals("true") || 
        										details.getSetFlavorDetails(flavor).getFlag().equals("optional")){
        									for (String exception : details.getSetFlavorDetails(flavor).getExceptions()){
        										nRef = getNSRef(exception);
        										if (nRef != null && !refListContains(nRef)) {
        											nRefList.add(nRef);
        										}
        									}
        								}
        							}
        							crud = IextOssjEntitySpecifics.DELETE;
        							flavors = ((IextOssjEntitySpecifics) entity.getIextStandardSpecifics()).getSupportedFlavors(crud);
        							for (IextMethod.OssjEntityMethodFlavor flavor : flavors){
        								if( details.getRemoveFlavorDetails(flavor).getFlag().equals("true") || 
        										details.getRemoveFlavorDetails(flavor).getFlag().equals("optional")){
        									for (String exception : details.getRemoveFlavorDetails(flavor).getExceptions()){
        										nRef = getNSRef(exception);
        										if (nRef != null && !refListContains(nRef)) {
        											nRefList.add(nRef);
        										}
        									}
        								}
        							}
        							
        							// Now do the "custom methods"
        							// This is even messier as we need the exceptions,
        							// for which there is no getSupportedFlavorsArray
        							// then go to the arguments and the return type!
        							
        							String[] stringFlavors = {
        									"simple",
        									"simpleByKey",
        									"bulkAtomic",
        									"bulkAtomicByKeys",
        									"byTemplate",
        									"byTemplates",
        									"bulkBestEffort",
        									"bulkBestEffortByKeys",
        									"byTemplateBestEffort",
        									"byTemplatesBestEffort"
        							};
        							for (IextMethod method : entity.getIextMethods())
        								for (int f=0;f<stringFlavors.length;f++){
        									if (details.getCustomMethodFlavorDetailsStr(method.getMethodId(),stringFlavors[f]) != null){
        										if( details.getCustomMethodFlavorDetailsStr(method.getMethodId(),stringFlavors[f]).getFlag().equals("true") || 
        												details.getCustomMethodFlavorDetailsStr(method.getMethodId(),stringFlavors[f]).getFlag().equals("optional")){
        											// Do the exceptions
        											for (String exception : details.getCustomMethodFlavorDetailsStr(method.getMethodId(),stringFlavors[f]).getExceptions()){
        												nRef = getNSRef(exception);
        												if (nRef != null && !refListContains(nRef)) {
        													nRefList.add(nRef);
        												}
        											}
        											// Do the Return type
        											String returnFQN = method.getReturnIextType().getFullyQualifiedName();
        											nRef = getNSRef(returnFQN);
        											if (nRef != null && !refListContains(nRef)) {
        												nRefList.add(nRef);
        											}
        											// And the arguments
        											for (IextArgument arg : method.getIextArguments()){
        												String argumentFQN = arg.getIType().getFullyQualifiedName();
        												nRef = getNSRef(argumentFQN);
        												if (nRef != null && !refListContains(nRef)) {
        													nRefList.add(nRef);
        												}
        											}
        										}
        								}   
        							}
        							
        					} // If it's not an artifact then we are scuppered!
        				}*/
        			}
        		}
                // If its a query need to add the namespace of the returned type
        		// Do we need queries in MTOSSJ ?
				if (artifact instanceof IextQueryArtifact){
					IextQueryArtifact query = (IextQueryArtifact) artifact;
					nRef = getNSRef(query.getReturnedType().getFullyQualifiedName());
					
					if ( nRef != null && !refListContains(nRef)) {
						PluginLog.logDebug("Query Return Ref  " + nRef.getNamespace());
						nRefList.add(nRef);
					}
				}
				
				// Types referenced by Associations....
				for (IextAssociationEnd end : getAssociationOtherEnds(artifact)){
					nRef = getNSRef(end.getIextType().getFullyQualifiedName());
					if ( nRef != null && !refListContains(nRef)) {
						PluginLog.logDebug("Imports : Adding (association End) artifact "+end.getIextType().getFullyQualifiedName());
						nRefList.add(nRef);
					}
				}
				
        	}
        	
        }
	}
	
	
	private NamespaceRef deriveNSRef(IextPluginReference pluginRef, IArtifact artifact){
		NamespaceRef nRef = new NamespaceRef();
		// Any expansion needs to be done in the context of the project where this thing lives.
		this.expander.setCurrentArtifact(artifact);
		this.expander.setPluginRef(pluginRef);
		BaseModel model = new BaseModel();
		model.setIArtifact(artifact);
		this.expander.setCurrentModel(model);

		// ============== ARTIFACT Based Schemas only on the MTOSSJ world =====================//

		nRef.prefix = this.expander.expandVar(pluginRef.getProperty("artifactPrefix").toString());
		nRef.targetNamespace = this.expander.expandVar(pluginRef.getProperty("artifactTargetNamespace").toString());
		nRef.targetLocation = this.expander.expandVar(pluginRef.getProperty("artifactSchemaLocation").toString());
		return nRef;
	}
	
	
	/**
	 * Use this to get a ns reference using an FQN 
	 * @param fullyQualifiedName
	 * @return
	 */
	public NamespaceRef getNSRef(String fullyQualifiedName)
	     throws TigerstripeException {
		//System.out.println("FQN = "+fullyQualifiedName);
		
		NamespaceRef nRef =  new NamespaceRef();
		// Note the use of false here to get only locals
		IArtifact artifact = this.project.getIextArtifactManagerSession()
                .getIArtifactByFullyQualifiedName(fullyQualifiedName, false);
		if (artifact != null) {
			// It's a local artifact
			//System.out.println("local");
			nRef = deriveNSRef(this.pluginRef,artifact);
		} else {
			// It's probably in a ref project or module
			// use true this time to includeDependencies
			artifact = this.project.getIextArtifactManagerSession()
                    .getIArtifactByFullyQualifiedName(fullyQualifiedName, true);
			if (artifact == null) {
				// Don't know about it - or it may not even be an artifact ! 
				//if (!refListContains(defaultNamespaceRef)) {
    			//	nRefList.add(defaultNamespaceRef);
    			//}
				//System.out.println("Don't know what it is "+fullyQualifiedName);
				return null;
			}
		
		//	IextTigerstripeProject refProject = 
        //		artifact.getIextTigerstripeProject();
			
			IextProjectDescriptor refDescriptor = 
        		artifact.getIextProjectDescriptor();
			//System.out.println(refDescriptor);
			if (refDescriptor != null){
				IextPluginReference refRef = getPluginRef(refDescriptor);
				if (refRef != null){
					nRef = deriveNSRef(refRef,artifact);
				} else {
					//System.out.println("No plugin Ref for "+refDescriptor.getIextProjectDetails().getName());
// TODO					throw new TigerstripeException("Could not find mapping for '"+ artifact.getName());
					if (!refListContains(defaultNamespaceRef)) {
	    				nRefList.add(defaultNamespaceRef);
	    			}
					return null;
				}
			} else {
				//System.out.println("Got artifact, but no project descriptor for "+artifact.getName());
// TODO				throw new TigerstripeException("Could not find mapping for '"+ artifact.getName());
				if (!refListContains(defaultNamespaceRef)) {
    				nRefList.add(defaultNamespaceRef);
    			}
				return null;
			}
		}
		return nRef;
	}
	
	/**
	 * Get the ref from the passed project that *matches* the "local" pluginRef
	 * @param project
	 * @return
	 */
	private IextPluginReference getPluginRef(IextProjectDescriptor descriptor) 
	    throws TigerstripeException{
		IextPluginReference[] refs = descriptor.getIextPluginReferences();
		if (refs != null) {
			for (int i=0;i<refs.length;i++){
				IextPluginReference ref = refs[i];
				if (ref.getPluginId().equals(this.pluginRef.getPluginId())){
					return ref;
				}
			}
		}
		//System.out.println("No matching ref");
		// No matching ref!
		return null;
		
	}
	

    /**
     * Checks the ref to make sure it is not empty
     * 
     * @param ref
     * @throws TigerstripeException
     */
    private void checkNamespaceRef(IextModelComponent component, NamespaceRef ref)
            throws TigerstripeException {
        if (ref.targetNamespace == null || "".equals(ref.targetNamespace)) {
            throw new TigerstripeException("Could not find mapping for '"+ component.getName());
        }
    }
	
	
    /**
     * check if the list contains one with the same namespace as this one.
     * @param nRef
     * @return
     */
    public boolean refListContains(NamespaceRef nRef){
    	for (Iterator iter = nRefList.iterator(); iter.hasNext();) {
            NamespaceRef ref = (NamespaceRef) iter.next();
            if (ref.targetNamespace.equals(nRef.targetNamespace)){
            	return true;
            }
    	}
    	// None matched
    	return false;
    }
    
    public boolean refListContainsPrefix(String prefix){
    	for (Iterator iter = nRefList.iterator(); iter.hasNext();) {
            NamespaceRef ref = (NamespaceRef) iter.next();
            if (ref.prefix.equals(prefix)){
            	return true;
            }
    	}
    	// None matched
    	return false;
    }
    
	
    /**
     * Seeding the list of import with the current common to ensure proper
     * namespace and avoid having to hardcode in the template
     * 
     * 
     * NOTE This is an ossj specific behaviour
     */
/*    protected NamespaceRef seedRefListWithCommonAPI(IextPluginReference pluginRef) {
    	NamespaceRef ref = new NamespaceRef();

    		ref.prefix = project.getIextProjectDetails().getProperty(
    				"ossj.common.namespacePrefix", "");
    		ref.targetLocation = project.getIextProjectDetails().getProperty(
    				"ossj.common.schemaLocation", "");
    		ref.targetNamespace = project.getIextProjectDetails().getProperty(
    				"ossj.common.targetNamespace", "");
    		
    		ref.prefix = pluginRef.getProperty("OSSJSchemaPrefix").toString();
    		ref.targetLocation = pluginRef.getProperty("OSSJSchemaLocation").toString();
    		ref.targetNamespace = pluginRef.getProperty("OSSJSchemaNamespace").toString();
    		
    		
            nRefList.add(ref);

        return ref;
    }*/

    
	public ArrayList<NamespaceRef> getNRefs() {
		return nRefList;
	}
	
	public XmlType typeNSOf(String fullyQualifiedName, String dimensions) 
	       throws TigerstripeException {

		NamespaceRef nRef = getNSRef(fullyQualifiedName);
	
		 if (nRef != null){

		   XmlType xType = new XmlType( 
				   fullyQualifiedName,
				   dimensions,
				   nRef,
				   this.project,
				   this.pluginRef);
		   
		   
		   return xType;
		 } else {
				
			 XmlType xType = new XmlType( 
					   fullyQualifiedName,
					   dimensions,
					   this.defaultNamespaceRef,
					   this.project,
					   this.pluginRef);
			   

			   return xType;

		 }
	}
	
	private int getSessionCount(String packageName){
		int packageSessionCount = 0;
		for (Object sessionObject : this.sessions){
			IArtifact session = (IArtifact) sessionObject;
			if (session.getPackage().equals(packageName)){
				packageSessionCount ++;
			}
		}
		return packageSessionCount;
	}
	
	public ArrayList<IextAssociationEnd> getAssociationOtherEnds(IArtifact artifact){
		try {    		
			ArrayList assEnds = new ArrayList();
			// Legacy stuff ha sno project
			if (project != null){
				IextArtifactManagerSession session = project.getIextArtifactManagerSession();    		
				IQueryRelationshipsByArtifact outQuery = (IQueryRelationshipsByArtifact) session.makeQuery(IQueryRelationshipsByArtifact.class.getName());
				outQuery.setIncludeDependencies(true);
				outQuery.setOriginatingFrom(artifact.getFullyQualifiedName());
				// OUTS
				Collection outRefs = session.queryArtifact(outQuery);

				// We're looking at out goings, so the Aend shoud be us!
				for (Object ref : outRefs){
					if (ref instanceof IextAssociationArtifact){
							// The thing we need is on the other end..
						    // provided that it is navigable
						    IextAssociationEnd otherEnd =((IextAssociationArtifact)ref).getZEnd();
						    if (otherEnd.isNavigable()){
							    assEnds.add(otherEnd);
						    }
						
					} 
				}

				IQueryRelationshipsByArtifact inQuery = (IQueryRelationshipsByArtifact) session.makeQuery(IQueryRelationshipsByArtifact.class.getName());
				inQuery.setTerminatingIn(artifact.getFullyQualifiedName());
				inQuery.setIncludeDependencies(true);
				Collection inRefs = session.queryArtifact(inQuery);

                // We're looking at in comings goings, so the Zend shoud be us!
				for (Object ref : inRefs){
					if (ref instanceof IextAssociationArtifact){
                        // The thing we need is on the other end..
					    // provided that it is navigable
					    IextAssociationEnd otherEnd =((IextAssociationArtifact)ref).getAEnd();
					    if (otherEnd.isNavigable()){
						    assEnds.add(otherEnd);
					    }
					} 
				}
			}

   			return assEnds;
    		
		} catch (TigerstripeException t){
			t.printStackTrace();
			return new ArrayList<IextAssociationEnd>();
		}
	}
	
}
