package com.tigerstripesoftware.plugins.xml.config.xmlFiles.language;

public class Mapping
{

    private String from;
    
    private String to;

    public String getFrom()
    {
        return from;
    }

    public void setFrom(String from)
    {
    	if (!from.startsWith("MODEL-TYPES")){
    		this.from = from.trim().replaceAll("::", ".");
    	} 
    }

    public String getTo()
    {
        return to;
    }

    public void setTo(String to)
    {
        this.to = to.trim();
    }
    
    public String toString(){
        return "To:"+to + " From:"+ from ;
    }
}
