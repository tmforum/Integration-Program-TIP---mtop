package com.tigerstripesoftware.plugins.xml;

import com.tigerstripesoftware.api.external.IextPluginReference;
import com.tigerstripesoftware.api.external.TigerstripeException;
import com.tigerstripesoftware.api.external.plugins.PluginLog;

/**
 * Use this to map from a primitive type to an XML Type
 * 
 * @author Richard Craddock
 *
 */
public class XMLTypeMapper {
	
	public XMLTypeMapper(IextPluginReference pluginRef){

	}
	
	public String xsdTypeMapping(String javaType)
	throws TigerstripeException {

		String baseType = null;
		if ("boolean".equals(nameOf(javaType))) {
			baseType = "boolean";
		} else if ("Boolean".equals(nameOf(javaType))) {
				baseType = "boolean";
		} else if ("int".equals(nameOf(javaType))) {
			baseType = "int";
		} else if ("Float".equals(nameOf(javaType))) {
			baseType = "float";
		} else if ("Double".equals(nameOf(javaType))) {
			baseType = "double";
		} else if ("Long".equals(nameOf(javaType))) {
			baseType = "long";
		} else if ("Short".equals(nameOf(javaType))) {
			baseType = "short";
		} else if ("Byte".equals(nameOf(javaType))) {	
			baseType = "byte";
		}else if ("String".equals(nameOf(javaType))) {
			baseType = "string";
		} else if ("Char".equals(nameOf(javaType))) {
			baseType = "string";
			// should also set the length to 1
		} else if ("Date".equals(nameOf(javaType))) {
			baseType = "dateTime";
		} else if ("Name".equals(nameOf(javaType))) {
			baseType = "Name";
		} else if ("Calendar".equals(nameOf(javaType))) {
			baseType = "dateTime";
		} else if ("BigDecimal".equals(nameOf(javaType))) {
			baseType = "decimal";
		} else if ("Object".equals(nameOf(javaType))){
			baseType = "anyType";
		} else if ("TimeZone".equals(nameOf(javaType)) ||
				"URL".equals(nameOf(javaType))      ){
			baseType = "string";
		} else {
			// TODO: this is necessary for now to have the default
			// primary key to be of string type. Not sure what impact
			// this may have in the future.

			// might it be better to default to String if we don't do anythig special with it ?
			// but things like Name are in there..
			// ideally we could check if this is in the declared namespaces.
			baseType = javaType;
			PluginLog.logWarning("No valid Mapping found for "+javaType);
		}

		return baseType;
	}
	
	
	public static String nameOf(String fullyQualifiedName) {
		
		if ( fullyQualifiedName == null )
			return "";
		
		if (fullyQualifiedName.lastIndexOf(".") < 0) {
			return fullyQualifiedName;
		}
		return fullyQualifiedName
				.substring(fullyQualifiedName.lastIndexOf(".") + 1);
	}
	
}
