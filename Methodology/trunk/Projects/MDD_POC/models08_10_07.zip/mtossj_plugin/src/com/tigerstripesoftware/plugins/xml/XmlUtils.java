package com.tigerstripesoftware.plugins.xml;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.tigerstripesoftware.api.external.TigerstripeException;
import com.tigerstripesoftware.api.external.model.IextLabel;
import com.tigerstripesoftware.api.external.model.IextMethod;
import com.tigerstripesoftware.api.external.model.IextType;
import com.tigerstripesoftware.api.external.model.artifacts.IArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextDatatypeArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextEnumArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextEventArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextExceptionArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextManagedEntityArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextQueryArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextSessionArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextUpdateProcedureArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextSessionArtifact.IextEmittedEvent;
import com.tigerstripesoftware.api.external.model.artifacts.IextSessionArtifact.IextNamedQuery;
import com.tigerstripesoftware.api.external.plugins.PluginLog;
import com.tigerstripesoftware.api.external.profile.stereotype.IextStereotypeInstance;
public class XmlUtils {
    
    public int sizeOf(ArrayList coll){
        return coll.size();
    }
    
    public int sizeOf(IextEmittedEvent[] arr){
        return arr.length;
    }
    
    public String pluralisedForm(String name){
        // Very special one off case!
        // If word ends with a consonant then y
        // then change the plural to be "ies"
        
        String ending=".*[^aeiou]y";
        if (name.matches(ending)){
            
            name = name.substring(0,name.length()-1)+"ies";
            return name;
        } else{
            return name+"s";
        }
    }
     
    
    public StringBuffer replaceChar(StringBuffer inBuff, String what,
            String with) {
        while (inBuff.indexOf(what) != -1) {
            int pos = inBuff.indexOf(what);
            inBuff.deleteCharAt(pos);
            inBuff.insert(pos, with);
        }
        return inBuff;
    }
    
    public String valueOfLabel(IextLabel label) {
        if (label.getIextType().getName().equals("int")) {
            return label.getValue();
        } else {
            
            return stripExternalQuotes(label.getValue());
        }
    }
    
    static public String stripExternalQuotes( String str ) {
        if ( str.charAt(0) == '"' && str.charAt(str.length()-1) == '"' ) {
            return str.substring(1, str.length()-1 );
        } else {
            return str;
        }
        
    }
    
    static public String stripExtension( String inString ) {
        if (inString.endsWith(".wsdl")){
            return inString.substring(0,inString.length()-5);
        }
        return inString;
    }
    
    public boolean isSession(IArtifact artifact){
        return artifact.getIArtifactType().equals(IextSessionArtifact.class.getName());
    }
    
    public boolean isEntity(IArtifact artifact){
        return artifact.getIArtifactType().equals(IextManagedEntityArtifact.class.getName());
    }
    
    public boolean isDatatype(IArtifact artifact){
        return artifact.getIArtifactType().equals(IextDatatypeArtifact.class.getName());
    }
    
    public boolean isEnumeration(IArtifact artifact){
        return artifact.getIArtifactType().equals(IextEnumArtifact.class.getName());
    }
    
    public boolean isException(IArtifact artifact){
        return artifact.getIArtifactType().equals(IextExceptionArtifact.class.getName());
    }
    
    public boolean isNamedQuery(IArtifact artifact){
        return artifact.getIArtifactType().equals(IextQueryArtifact.class.getName());
    }
    
    public boolean isUpdateProcedure(IArtifact artifact){
        return artifact.getIArtifactType().equals(IextUpdateProcedureArtifact.class.getName());
    }
    
    public boolean isNotification(IArtifact artifact){
        return artifact.getIArtifactType().equals(IextEventArtifact.class.getName());
    }
    
    public boolean isIgnoreInXML(IextMethod method){
        IextStereotypeInstance[] instances = method.getStereotypeInstances();
        for (int i=0;i<instances.length;i++){
            IextStereotypeInstance instance = instances[i];
            if (instance.getName().equals("ignoreInXML")){
                return true;
            }
        }
        return false;
    }
    
    /**
     * Use the new facility for putting the name in the model,
     * if that is not set, look for the annotation,
     * else use "return"
     * @param method
     * @return
     */
    public String getReturnName(IextMethod method){
    	if ("".equals(method.getMethodReturnName())){
    		return method.getMethodReturnName();
    	}
        IextStereotypeInstance[] instances = method.getStereotypeInstances();
        for (int i=0;i<instances.length;i++){
            IextStereotypeInstance instance = instances[i];
            if (instance.getName().equals("returnName")){
                try {
                    return instance.getAttributeValue("name");
                } catch (TigerstripeException t){
                    return "return";
                }
                
            }
        }
        return "return";
    }
    
    /**
     * Return true if the Type in the first arg is
     * an ancestor of the second arg
     *
     * @return
     */
    public boolean ofAncestorType(IextType type, IArtifact artifact){
        IArtifact[] ancestors =  artifact.getAncestors();
        for (int i=0;i<ancestors.length;i++){
            if (type.getFullyQualifiedName().equals(ancestors[i].getFullyQualifiedName())){
                return true;
            }
        }
        return false;
    }
    
    /**
     * Return the style of an operation
     * Log error if not set, but then apply Default
     * @param method
     * @return
     */
    public String getOperationStyle(IextMethod method) throws TigerstripeException{
    	IextStereotypeInstance[] instances = method.getStereotypeInstances();
    	for (IextStereotypeInstance instance : instances){
    		if (instance.getName().equals("operationStyle")){
    			return instance.getAttributeValue("MEP");
    		}
    	}
    	PluginLog.logError("Annotation 'operationStyle' is not found in the workspace profile");
    	return "requestResponse";
    }
    
}
