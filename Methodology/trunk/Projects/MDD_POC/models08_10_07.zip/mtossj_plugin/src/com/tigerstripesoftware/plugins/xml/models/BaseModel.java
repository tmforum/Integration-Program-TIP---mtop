package com.tigerstripesoftware.plugins.xml.models;


import com.tigerstripesoftware.api.external.IextPluginReference;
import com.tigerstripesoftware.api.external.TigerstripeException;
import com.tigerstripesoftware.api.external.model.IextMethod;
import com.tigerstripesoftware.api.external.model.artifacts.IArtifact;
import com.tigerstripesoftware.api.external.model.artifacts.IextSessionArtifact;
import com.tigerstripesoftware.api.external.plugins.IPluginAwareArtifactModel;
import com.tigerstripesoftware.api.external.plugins.PluginLog;
import com.tigerstripesoftware.api.external.profile.stereotype.IextStereotypeInstance;


public class BaseModel implements IPluginAwareArtifactModel {

	protected IArtifact artifact;
	protected IextPluginReference pluginRef;
	
	public void setIArtifact(IArtifact arg0) {
		this.artifact = arg0;		
	}

	public void setPluginRef(IextPluginReference arg0) {
		this.pluginRef = arg0;
	
	}
	
	public String getName(){	
		String name = this.artifact.getName();
		if (this.artifact instanceof IextSessionArtifact){
			name = name+"Messages";
		}
		return name+"V"+getVersion();
	}
	
	public String getMajorName(){	
		String name = this.artifact.getName();
		if (this.artifact instanceof IextSessionArtifact){
			name = name+"Messages";
		}
		String majorVersion = getVersion();
		if (majorVersion.contains("-")){
			String[] versionTags = majorVersion.split("-");
			majorVersion = versionTags[0];
		}
		return name+"V"+majorVersion;
	}
	
    /**
     * Return the version of an artifact
     * Log error if not set, but then apply Default
     * @param artifact
     * @return
     */
    public String getVersion(){
    	IextStereotypeInstance[] instances = this.artifact.getStereotypeInstances();
    	try {
    		for (IextStereotypeInstance instance : instances){
    			if (instance.getName().equals("version")){
    				return instance.getAttributeValue("value");
    			}
    		}
    		PluginLog.logError("Annotation 'version' is not set for artifact "+this.artifact.getFullyQualifiedName());
    		return "unknown";
    	} catch (TigerstripeException t){
    		PluginLog.logError("Annotation 'version' not found in profile");
    		return "unknown";
    	}
    }
    
	/**
	 * This sets the filename for an XSD and MUST be overridden for WSDL 
	 * @return
	 */
    public String getFileName(){
		try {
			String filePath = this.pluginRef.getProperty("artifactFilePath").toString();
			String fileName = filePath+"/"+getName();
            return fileName+".xsd";

		} catch (Exception e){
			PluginLog.logError("Failure to build xsdFileName", e);
			return this.artifact.getName()+"Vunknown"+".xsd";
		}
	}
    
}
