package com.tigerstripesoftware.plugins.xml.config.xmlFiles;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.digester.Digester;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.tigerstripesoftware.api.external.plugins.PluginLog;

public abstract class AbstractDigester
{
        
    /**
     * The JAXP 1.2 property required to set up the schema location.
     */
    protected static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";

    /**
     * The JAXP 1.2 property to set up the schemaLanguage used.
     */
    protected String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";

    protected Digester digester;
    
    protected static Map<String,AbstractDigestedFile> parsedFiles = new HashMap<String,AbstractDigestedFile>();
    
    synchronized protected AbstractDigestedFile digestFile (final String url) throws XMLDigesterException{
       // if (parsedFiles.containsKey(url))
       //     return parsedFiles.get(url);
       //  else {
         	//System.out.println("Digesting the url");
         	digester = new Digester();
         	digester.clear();
        	digester.setNamespaceAware(true);
        	digester.setErrorHandler(new ErrorHandler(){

    			public void error(SAXParseException exception) throws SAXException {
    				PluginLog.logError("XML parsing error in "+url,exception);
    				throw exception;
    			}

    			public void fatalError(SAXParseException exception) throws SAXException {
    				PluginLog.logError("XML parsing error in "+url,exception);
    				throw exception;
    			}

    			public void warning(SAXParseException exception) throws SAXException {
    				PluginLog.logWarning("XML parsing error in "+url,exception);
    			}
        	
        	});
        	//System.out.println("Digestrer "+digester);
        	//System.out.println("getSchemaUrl "+getSchemaUrl());
        	/*if (getSchemaUrl()!=null)
        		setValidating(digester, getSchemaUrl());*/
        	//System.out.println("Go for it");
             AbstractDigestedFile digestedFile = parseFile(url);
         //    parsedFiles.put(url,digestedFile);
             return digestedFile;
        // }
    }
    
    protected void setValidating(final Digester digester, URL schemaUrl)
    {
        digester.setValidating(true);
        try {
            if (schemaUrl != null) {
                InputStream stream = schemaUrl.openStream();
                stream.close();
                stream = null;
            }
        } catch (final IOException exception) {
            schemaUrl = null;
        }
        if (schemaUrl == null) {
        	PluginLog.logWarning("Was not able to find schemaUri --> '"
                    + schemaUrl.toString()
                    + "' continuing in non validating mode");
            digester.setValidating(false);
        }
        if (schemaUrl != null) {
            try {
                digester.setSchema(schemaUrl.toString());

                // also set the JAXP properties in case we're using a parser
                // that needs those
                digester.setProperty(JAXP_SCHEMA_LANGUAGE, digester
                        .getSchemaLanguage());
                digester.setProperty(JAXP_SCHEMA_SOURCE, digester.getSchema());
            } catch (final Exception exception) {
            	PluginLog.logWarning(
                                "Your parser does NOT support the "
                                        + " schema validation continuing in non validation mode",
                                exception);
                digester.setValidating(false);
            }
        }
    }
    
    
    abstract protected AbstractDigestedFile parseFile(String url) throws XMLDigesterException;
    
    abstract public void setUrl(String url) throws XMLDigesterException;
    
    abstract public AbstractDigestedFile getRoot();
    
    abstract protected URL getSchemaUrl();
    
}
