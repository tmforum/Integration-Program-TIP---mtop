package com.tigerstripesoftware.plugins.xml.config.xmlFiles.language;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.xml.sax.SAXException;

import com.tigerstripesoftware.api.external.plugins.PluginLog;
import com.tigerstripesoftware.plugins.xml.config.xmlFiles.AbstractDigester;
import com.tigerstripesoftware.plugins.xml.config.xmlFiles.XMLDigesterException;


public class LanguageDigester extends AbstractDigester
{
    Language_Mapping elFile;

    @Override
    protected Language_Mapping parseFile(String url)
    {
        if (url == null || url.equals(""))
        	return new Language_Mapping();
        
        Language_Mapping config = null;
       
        digester.addObjectCreate("mappings",
                "com.tigerstripesoftware.plugins.xml.config.xmlFiles.language.Language_Mapping");

        /* There are multiple "from" clauses - default pattern will just use the last one!*/
        /* mappings */
        digester.addObjectCreate("mappings/mapping",
                "com.tigerstripesoftware.plugins.xml.config.xmlFiles.language.Mapping");
        digester.addCallMethod("mappings/mapping/from", "setFrom", 0);
        digester.addCallMethod("mappings/mapping/to", "setTo", 0);
        digester.addSetNext("mappings/mapping",
                "addMapping",
                "com.tigerstripesoftware.plugins.xml.config.xmlFiles.language.Mapping");
        
        try {
        	File f = new File(url);
        	URL realUrl = f.toURL();
        	PluginLog.logInfo(" Language Mappings Url = "+realUrl);
            config = (Language_Mapping) digester.parse(realUrl.openStream());
            String configStr = config.toString();
            PluginLog.logDebug(configStr);
        } catch (IOException e) {
            config = new Language_Mapping();
            PluginLog.logInfo(url + "' not found.", e);
        } catch (SAXException e) {
            config = new Language_Mapping();
            PluginLog.logInfo(url + "' not found.", e);
        } catch (RuntimeException e) {
            config = new Language_Mapping();
            PluginLog.logInfo( url + "' not found.", e);
        }
        return config;
    }

    @Override
    public void setUrl(String url) throws XMLDigesterException
    {
        elFile = (Language_Mapping) digestFile(url);
    }

    @Override
    public Language_Mapping getRoot()
    {
        return elFile;
        
    }

	@Override
	protected URL getSchemaUrl() {
		try {
			return new URL("http://sjc-nm01-w03/xsd/mapper.xsd");
		} catch (MalformedURLException e) {
			PluginLog.logError("Couldm't create URL",e);
		}
		return null;
	}

}
