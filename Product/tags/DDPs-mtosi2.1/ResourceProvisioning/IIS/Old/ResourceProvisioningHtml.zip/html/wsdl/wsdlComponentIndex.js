﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/rp/wsdl/conc/v1-0"] =  new WC (
					new Array(new WCN("52/service/ConnectionControlHttp.html","ConnectionControlHttp",false,null),new WCN("52/service/ConnectionControlJms.html","ConnectionControlJms",false,null)),
					new Array(new WCN("52/message/activateSubnetworkConnectionException.html","activateSubnetworkConnectionException",false,null),new WCN("52/message/activateSubnetworkConnectionRequest.html","activateSubnetworkConnectionRequest",false,null),new WCN("52/message/activateSubnetworkConnectionResponse.html","activateSubnetworkConnectionResponse",false,null),new WCN("52/message/addRouteException.html","addRouteException",false,null),new WCN("52/message/addRouteRequest.html","addRouteRequest",false,null),new WCN("52/message/addRouteResponse.html","addRouteResponse",false,null),new WCN("52/message/checkValidSubnetworkConnectionException.html","checkValidSubnetworkConnectionException",false,null),new WCN("52/message/checkValidSubnetworkConnectionRequest.html","checkValidSubnetworkConnectionRequest",false,null),new WCN("52/message/checkValidSubnetworkConnectionResponse.html","checkValidSubnetworkConnectionResponse",false,null),new WCN("52/message/createAndActivateSubnetworkConnectionException.html","createAndActivateSubnetworkConnectionException",false,null),new WCN("52/message/createAndActivateSubnetworkConnectionRequest.html","createAndActivateSubnetworkConnectionRequest",false,null),new WCN("52/message/createAndActivateSubnetworkConnectionResponse.html","createAndActivateSubnetworkConnectionResponse",false,null),new WCN("52/message/createModifiedSubnetworkConnectionException.html","createModifiedSubnetworkConnectionException",false,null),new WCN("52/message/createModifiedSubnetworkConnectionRequest.html","createModifiedSubnetworkConnectionRequest",false,null),new WCN("52/message/createModifiedSubnetworkConnectionResponse.html","createModifiedSubnetworkConnectionResponse",false,null),new WCN("52/message/createSubnetworkConnectionException.html","createSubnetworkConnectionException",false,null),new WCN("52/message/createSubnetworkConnectionRequest.html","createSubnetworkConnectionRequest",false,null),new WCN("52/message/createSubnetworkConnectionResponse.html","createSubnetworkConnectionResponse",false,null),new WCN("52/message/deactivateAndDeleteSubnetworkConnectionException.html","deactivateAndDeleteSubnetworkConnectionException",false,null),new WCN("52/message/deactivateAndDeleteSubnetworkConnectionRequest.html","deactivateAndDeleteSubnetworkConnectionRequest",false,null),new WCN("52/message/deactivateAndDeleteSubnetworkConnectionResponse.html","deactivateAndDeleteSubnetworkConnectionResponse",false,null),new WCN("52/message/deactivateSubnetworkConnectionException.html","deactivateSubnetworkConnectionException",false,null),new WCN("52/message/deactivateSubnetworkConnectionRequest.html","deactivateSubnetworkConnectionRequest",false,null),new WCN("52/message/deactivateSubnetworkConnectionResponse.html","deactivateSubnetworkConnectionResponse",false,null),new WCN("52/message/deleteSubnetworkConnectionException.html","deleteSubnetworkConnectionException",false,null),new WCN("52/message/deleteSubnetworkConnectionRequest.html","deleteSubnetworkConnectionRequest",false,null),new WCN("52/message/deleteSubnetworkConnectionResponse.html","deleteSubnetworkConnectionResponse",false,null),new WCN("52/message/modifySubnetworkConnectionException.html","modifySubnetworkConnectionException",false,null),new WCN("52/message/modifySubnetworkConnectionRequest.html","modifySubnetworkConnectionRequest",false,null),new WCN("52/message/modifySubnetworkConnectionResponse.html","modifySubnetworkConnectionResponse",false,null),new WCN("52/message/removeRouteException.html","removeRouteException",false,null),new WCN("52/message/removeRouteRequest.html","removeRouteRequest",false,null),new WCN("52/message/removeRouteResponse.html","removeRouteResponse",false,null),new WCN("52/message/setIntendedRouteException.html","setIntendedRouteException",false,null),new WCN("52/message/setIntendedRouteRequest.html","setIntendedRouteRequest",false,null),new WCN("52/message/setIntendedRouteResponse.html","setIntendedRouteResponse",false,null),new WCN("52/message/setRoutesAdminStateException.html","setRoutesAdminStateException",false,null),new WCN("52/message/setRoutesAdminStateRequest.html","setRoutesAdminStateRequest",false,null),new WCN("52/message/setRoutesAdminStateResponse.html","setRoutesAdminStateResponse",false,null),new WCN("52/message/swapSubnetworkConnectionException.html","swapSubnetworkConnectionException",false,null),new WCN("52/message/swapSubnetworkConnectionRequest.html","swapSubnetworkConnectionRequest",false,null),new WCN("52/message/swapSubnetworkConnectionResponse.html","swapSubnetworkConnectionResponse",false,null),new WCN("52/message/switchRouteException.html","switchRouteException",false,null),new WCN("52/message/switchRouteRequest.html","switchRouteRequest",false,null),new WCN("52/message/switchRouteResponse.html","switchRouteResponse",false,null)),
					new Array(new WCN("52/porttype/ConnectionControl.html","ConnectionControl",false,new Array(new WCN("52/operation/activateSubnetworkConnection_4.html","activateSubnetworkConnection",false,null),new WCN("52/operation/addRoute_5.html","addRoute",false,null),new WCN("52/operation/checkValidSubnetworkConnection_6.html","checkValidSubnetworkConnection",false,null),new WCN("52/operation/createAndActivateSubnetworkConnection_7.html","createAndActivateSubnetworkConnection",false,null),new WCN("52/operation/createModifiedSubnetworkConnection_8.html","createModifiedSubnetworkConnection",false,null),new WCN("52/operation/createSubnetworkConnection_9.html","createSubnetworkConnection",false,null),new WCN("52/operation/deactivateAndDeleteSubnetworkConnection_10.html","deactivateAndDeleteSubnetworkConnection",false,null),new WCN("52/operation/deactivateSubnetworkConnection_11.html","deactivateSubnetworkConnection",false,null),new WCN("52/operation/deleteSubnetworkConnection_12.html","deleteSubnetworkConnection",false,null),new WCN("52/operation/modifySubnetworkConnection_13.html","modifySubnetworkConnection",false,null),new WCN("52/operation/removeRoute_14.html","removeRoute",false,null),new WCN("52/operation/setIntendedRoute_15.html","setIntendedRoute",false,null),new WCN("52/operation/setRoutesAdminState_16.html","setRoutesAdminState",false,null),new WCN("52/operation/swapSubnetworkConnection_17.html","swapSubnetworkConnection",false,null),new WCN("52/operation/switchRoute_18.html","switchRoute",false,null)))),
					new Array(new WCN("52/binding/ConnectionControlSoapHttpBinding.html","ConnectionControlSoapHttpBinding",false,new Array(new WCN("52/operation/activateSubnetworkConnection_4.html","activateSubnetworkConnection",false,null),new WCN("52/operation/addRoute_5.html","addRoute",false,null),new WCN("52/operation/checkValidSubnetworkConnection_6.html","checkValidSubnetworkConnection",false,null),new WCN("52/operation/createAndActivateSubnetworkConnection_7.html","createAndActivateSubnetworkConnection",false,null),new WCN("52/operation/createModifiedSubnetworkConnection_8.html","createModifiedSubnetworkConnection",false,null),new WCN("52/operation/createSubnetworkConnection_9.html","createSubnetworkConnection",false,null),new WCN("52/operation/deactivateAndDeleteSubnetworkConnection_10.html","deactivateAndDeleteSubnetworkConnection",false,null),new WCN("52/operation/deactivateSubnetworkConnection_11.html","deactivateSubnetworkConnection",false,null),new WCN("52/operation/deleteSubnetworkConnection_12.html","deleteSubnetworkConnection",false,null),new WCN("52/operation/modifySubnetworkConnection_13.html","modifySubnetworkConnection",false,null),new WCN("52/operation/removeRoute_14.html","removeRoute",false,null),new WCN("52/operation/setIntendedRoute_15.html","setIntendedRoute",false,null),new WCN("52/operation/setRoutesAdminState_16.html","setRoutesAdminState",false,null),new WCN("52/operation/swapSubnetworkConnection_17.html","swapSubnetworkConnection",false,null),new WCN("52/operation/switchRoute_18.html","switchRoute",false,null))),new WCN("52/binding/ConnectionControlSoapJmsBinding.html","ConnectionControlSoapJmsBinding",false,new Array(new WCN("52/operation/activateSubnetworkConnection_4.html","activateSubnetworkConnection",false,null),new WCN("52/operation/addRoute_5.html","addRoute",false,null),new WCN("52/operation/checkValidSubnetworkConnection_6.html","checkValidSubnetworkConnection",false,null),new WCN("52/operation/createAndActivateSubnetworkConnection_7.html","createAndActivateSubnetworkConnection",false,null),new WCN("52/operation/createModifiedSubnetworkConnection_8.html","createModifiedSubnetworkConnection",false,null),new WCN("52/operation/createSubnetworkConnection_9.html","createSubnetworkConnection",false,null),new WCN("52/operation/deactivateAndDeleteSubnetworkConnection_10.html","deactivateAndDeleteSubnetworkConnection",false,null),new WCN("52/operation/deactivateSubnetworkConnection_11.html","deactivateSubnetworkConnection",false,null),new WCN("52/operation/deleteSubnetworkConnection_12.html","deleteSubnetworkConnection",false,null),new WCN("52/operation/modifySubnetworkConnection_13.html","modifySubnetworkConnection",false,null),new WCN("52/operation/removeRoute_14.html","removeRoute",false,null),new WCN("52/operation/setIntendedRoute_15.html","setIntendedRoute",false,null),new WCN("52/operation/setRoutesAdminState_16.html","setRoutesAdminState",false,null),new WCN("52/operation/swapSubnetworkConnection_17.html","swapSubnetworkConnection",false,null),new WCN("52/operation/switchRoute_18.html","switchRoute",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/conc/v1-0"] = "52/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/crp/v1-0"] =  new WC (
					new Array(new WCN("55/service/CommonResourceProvisioningHttp.html","CommonResourceProvisioningHttp",false,null),new WCN("55/service/CommonResourceProvisioningJms.html","CommonResourceProvisioningJms",false,null)),
					new Array(new WCN("55/message/setCommonAttributesException.html","setCommonAttributesException",false,null),new WCN("55/message/setCommonAttributesRequest.html","setCommonAttributesRequest",false,null),new WCN("55/message/setCommonAttributesResponse.html","setCommonAttributesResponse",false,null)),
					new Array(new WCN("55/porttype/CommonResourceProvisioning.html","CommonResourceProvisioning",false,new Array(new WCN("55/operation/setCommonAttributes_31.html","setCommonAttributes",false,null)))),
					new Array(new WCN("55/binding/CommonResourceProvisioningSoapHttpBinding.html","CommonResourceProvisioningSoapHttpBinding",false,new Array(new WCN("55/operation/setCommonAttributes_31.html","setCommonAttributes",false,null))),new WCN("55/binding/CommonResourceProvisioningSoapJmsBinding.html","CommonResourceProvisioningSoapJmsBinding",false,new Array(new WCN("55/operation/setCommonAttributes_31.html","setCommonAttributes",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/crp/v1-0"] = "55/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/ep/v1-0"] =  new WC (
					new Array(new WCN("51/service/EquipmentProvisioningHttp.html","EquipmentProvisioningHttp",false,null),new WCN("51/service/EquipmentProvisioningJms.html","EquipmentProvisioningJms",false,null)),
					new Array(new WCN("51/message/provisionEquipmentException.html","provisionEquipmentException",false,null),new WCN("51/message/provisionEquipmentRequest.html","provisionEquipmentRequest",false,null),new WCN("51/message/provisionEquipmentResponse.html","provisionEquipmentResponse",false,null),new WCN("51/message/unprovisionEquipmentException.html","unprovisionEquipmentException",false,null),new WCN("51/message/unprovisionEquipmentRequest.html","unprovisionEquipmentRequest",false,null),new WCN("51/message/unprovisionEquipmentResponse.html","unprovisionEquipmentResponse",false,null)),
					new Array(new WCN("51/porttype/EquipmentProvisioning.html","EquipmentProvisioning",false,new Array(new WCN("51/operation/provisionEquipment_2.html","provisionEquipment",false,null),new WCN("51/operation/unprovisionEquipment_3.html","unprovisionEquipment",false,null)))),
					new Array(new WCN("51/binding/EquipmentProvisioningSoapHttpBinding.html","EquipmentProvisioningSoapHttpBinding",false,new Array(new WCN("51/operation/provisionEquipment_2.html","provisionEquipment",false,null),new WCN("51/operation/unprovisionEquipment_3.html","unprovisionEquipment",false,null))),new WCN("51/binding/EquipmentProvisioningSoapJmsBinding.html","EquipmentProvisioningSoapJmsBinding",false,new Array(new WCN("51/operation/provisionEquipment_2.html","provisionEquipment",false,null),new WCN("51/operation/unprovisionEquipment_3.html","unprovisionEquipment",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/ep/v1-0"] = "51/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/fdc/v1-0"] =  new WC (
					new Array(new WCN("59/service/FlowDomainControlHttp.html","FlowDomainControlHttp",false,null),new WCN("59/service/FlowDomainControlJms.html","FlowDomainControlJms",false,null)),
					new Array(new WCN("59/message/assignConnectionlessPortTerminationPointsToMfdException.html","assignConnectionlessPortTerminationPointsToMfdException",false,null),new WCN("59/message/assignConnectionlessPortTerminationPointsToMfdRequest.html","assignConnectionlessPortTerminationPointsToMfdRequest",false,null),new WCN("59/message/assignConnectionlessPortTerminationPointsToMfdResponse.html","assignConnectionlessPortTerminationPointsToMfdResponse",false,null),new WCN("59/message/associateConnectionlessPortTerminationPointsWithFdException.html","associateConnectionlessPortTerminationPointsWithFdException",false,null),new WCN("59/message/associateConnectionlessPortTerminationPointsWithFdRequest.html","associateConnectionlessPortTerminationPointsWithFdRequest",false,null),new WCN("59/message/associateConnectionlessPortTerminationPointsWithFdResponse.html","associateConnectionlessPortTerminationPointsWithFdResponse",false,null),new WCN("59/message/associateMatrixFlowDomainsWithFdException.html","associateMatrixFlowDomainsWithFdException",false,null),new WCN("59/message/associateMatrixFlowDomainsWithFdRequest.html","associateMatrixFlowDomainsWithFdRequest",false,null),new WCN("59/message/associateMatrixFlowDomainsWithFdResponse.html","associateMatrixFlowDomainsWithFdResponse",false,null),new WCN("59/message/createAndActivateFlowDomainFragmentException.html","createAndActivateFlowDomainFragmentException",false,null),new WCN("59/message/createAndActivateFlowDomainFragmentRequest.html","createAndActivateFlowDomainFragmentRequest",false,null),new WCN("59/message/createAndActivateFlowDomainFragmentResponse.html","createAndActivateFlowDomainFragmentResponse",false,null),new WCN("59/message/createFlowDomainException.html","createFlowDomainException",false,null),new WCN("59/message/createFlowDomainRequest.html","createFlowDomainRequest",false,null),new WCN("59/message/createFlowDomainResponse.html","createFlowDomainResponse",false,null),new WCN("59/message/createMatrixFlowDomainException.html","createMatrixFlowDomainException",false,null),new WCN("59/message/createMatrixFlowDomainRequest.html","createMatrixFlowDomainRequest",false,null),new WCN("59/message/createMatrixFlowDomainResponse.html","createMatrixFlowDomainResponse",false,null),new WCN("59/message/deactivateAndDeleteFlowDomainFragmentException.html","deactivateAndDeleteFlowDomainFragmentException",false,null),new WCN("59/message/deactivateAndDeleteFlowDomainFragmentRequest.html","deactivateAndDeleteFlowDomainFragmentRequest",false,null),new WCN("59/message/deactivateAndDeleteFlowDomainFragmentResponse.html","deactivateAndDeleteFlowDomainFragmentResponse",false,null),new WCN("59/message/deAssociateConnectionlessPortTerminationPointsFromFdException.html","deAssociateConnectionlessPortTerminationPointsFromFdException",false,null),new WCN("59/message/deAssociateConnectionlessPortTerminationPointsFromFdRequest.html","deAssociateConnectionlessPortTerminationPointsFromFdRequest",false,null),new WCN("59/message/deAssociateConnectionlessPortTerminationPointsFromFdResponse.html","deAssociateConnectionlessPortTerminationPointsFromFdResponse",false,null),new WCN("59/message/deAssociateMatrixFlowDomainsFromFdException.html","deAssociateMatrixFlowDomainsFromFdException",false,null),new WCN("59/message/deAssociateMatrixFlowDomainsFromFdRequest.html","deAssociateMatrixFlowDomainsFromFdRequest",false,null),new WCN("59/message/deAssociateMatrixFlowDomainsFromFdResponse.html","deAssociateMatrixFlowDomainsFromFdResponse",false,null),new WCN("59/message/deleteFlowDomainException.html","deleteFlowDomainException",false,null),new WCN("59/message/deleteFlowDomainRequest.html","deleteFlowDomainRequest",false,null),new WCN("59/message/deleteFlowDomainResponse.html","deleteFlowDomainResponse",false,null),new WCN("59/message/deleteMatrixFlowDomainException.html","deleteMatrixFlowDomainException",false,null),new WCN("59/message/deleteMatrixFlowDomainRequest.html","deleteMatrixFlowDomainRequest",false,null),new WCN("59/message/deleteMatrixFlowDomainResponse.html","deleteMatrixFlowDomainResponse",false,null),new WCN("59/message/modifyFlowDomainException.html","modifyFlowDomainException",false,null),new WCN("59/message/modifyFlowDomainFragmentException.html","modifyFlowDomainFragmentException",false,null),new WCN("59/message/modifyFlowDomainFragmentRequest.html","modifyFlowDomainFragmentRequest",false,null),new WCN("59/message/modifyFlowDomainFragmentResponse.html","modifyFlowDomainFragmentResponse",false,null),new WCN("59/message/modifyFlowDomainRequest.html","modifyFlowDomainRequest",false,null),new WCN("59/message/modifyFlowDomainResponse.html","modifyFlowDomainResponse",false,null),new WCN("59/message/modifyMatrixFlowDomainException.html","modifyMatrixFlowDomainException",false,null),new WCN("59/message/modifyMatrixFlowDomainRequest.html","modifyMatrixFlowDomainRequest",false,null),new WCN("59/message/modifyMatrixFlowDomainResponse.html","modifyMatrixFlowDomainResponse",false,null),new WCN("59/message/unassignConnectionlessPortTerminationPointsFromMfdException.html","unassignConnectionlessPortTerminationPointsFromMfdException",false,null),new WCN("59/message/unassignConnectionlessPortTerminationPointsFromMfdRequest.html","unassignConnectionlessPortTerminationPointsFromMfdRequest",false,null),new WCN("59/message/unassignConnectionlessPortTerminationPointsFromMfdResponse.html","unassignConnectionlessPortTerminationPointsFromMfdResponse",false,null)),
					new Array(new WCN("59/porttype/FlowDomainControl.html","FlowDomainControl",false,new Array(new WCN("59/operation/assignConnectionlessPortTerminationPointsToMfd_46.html","assignConnectionlessPortTerminationPointsToMfd",false,null),new WCN("59/operation/associateConnectionlessPortTerminationPointsWithFd_47.html","associateConnectionlessPortTerminationPointsWithFd",false,null),new WCN("59/operation/associateMatrixFlowDomainsWithFd_48.html","associateMatrixFlowDomainsWithFd",false,null),new WCN("59/operation/createAndActivateFlowDomainFragment_49.html","createAndActivateFlowDomainFragment",false,null),new WCN("59/operation/createFlowDomain_50.html","createFlowDomain",false,null),new WCN("59/operation/createMatrixFlowDomain_51.html","createMatrixFlowDomain",false,null),new WCN("59/operation/deactivateAndDeleteFlowDomainFragment_52.html","deactivateAndDeleteFlowDomainFragment",false,null),new WCN("59/operation/deAssociateConnectionlessPortTerminationPointsFromFd_53.html","deAssociateConnectionlessPortTerminationPointsFromFd",false,null),new WCN("59/operation/deAssociateMatrixFlowDomainsFromFd_54.html","deAssociateMatrixFlowDomainsFromFd",false,null),new WCN("59/operation/deleteFlowDomain_55.html","deleteFlowDomain",false,null),new WCN("59/operation/deleteMatrixFlowDomain_56.html","deleteMatrixFlowDomain",false,null),new WCN("59/operation/modifyFlowDomain_57.html","modifyFlowDomain",false,null),new WCN("59/operation/modifyFlowDomainFragment_58.html","modifyFlowDomainFragment",false,null),new WCN("59/operation/modifyMatrixFlowDomain_59.html","modifyMatrixFlowDomain",false,null),new WCN("59/operation/unassignConnectionlessPortTerminationPointsFromMfd_60.html","unassignConnectionlessPortTerminationPointsFromMfd",false,null)))),
					new Array(new WCN("59/binding/FlowDomainControlSoapHttpBinding.html","FlowDomainControlSoapHttpBinding",false,new Array(new WCN("59/operation/assignConnectionlessPortTerminationPointsToMfd_46.html","assignConnectionlessPortTerminationPointsToMfd",false,null),new WCN("59/operation/associateConnectionlessPortTerminationPointsWithFd_47.html","associateConnectionlessPortTerminationPointsWithFd",false,null),new WCN("59/operation/associateMatrixFlowDomainsWithFd_48.html","associateMatrixFlowDomainsWithFd",false,null),new WCN("59/operation/createAndActivateFlowDomainFragment_49.html","createAndActivateFlowDomainFragment",false,null),new WCN("59/operation/createFlowDomain_50.html","createFlowDomain",false,null),new WCN("59/operation/createMatrixFlowDomain_51.html","createMatrixFlowDomain",false,null),new WCN("59/operation/deactivateAndDeleteFlowDomainFragment_52.html","deactivateAndDeleteFlowDomainFragment",false,null),new WCN("59/operation/deAssociateConnectionlessPortTerminationPointsFromFd_53.html","deAssociateConnectionlessPortTerminationPointsFromFd",false,null),new WCN("59/operation/deAssociateMatrixFlowDomainsFromFd_54.html","deAssociateMatrixFlowDomainsFromFd",false,null),new WCN("59/operation/deleteFlowDomain_55.html","deleteFlowDomain",false,null),new WCN("59/operation/deleteMatrixFlowDomain_56.html","deleteMatrixFlowDomain",false,null),new WCN("59/operation/modifyFlowDomain_57.html","modifyFlowDomain",false,null),new WCN("59/operation/modifyFlowDomainFragment_58.html","modifyFlowDomainFragment",false,null),new WCN("59/operation/modifyMatrixFlowDomain_59.html","modifyMatrixFlowDomain",false,null),new WCN("59/operation/unassignConnectionlessPortTerminationPointsFromMfd_60.html","unassignConnectionlessPortTerminationPointsFromMfd",false,null))),new WCN("59/binding/FlowDomainControlSoapJmsBinding.html","FlowDomainControlSoapJmsBinding",false,new Array(new WCN("59/operation/assignConnectionlessPortTerminationPointsToMfd_46.html","assignConnectionlessPortTerminationPointsToMfd",false,null),new WCN("59/operation/associateConnectionlessPortTerminationPointsWithFd_47.html","associateConnectionlessPortTerminationPointsWithFd",false,null),new WCN("59/operation/associateMatrixFlowDomainsWithFd_48.html","associateMatrixFlowDomainsWithFd",false,null),new WCN("59/operation/createAndActivateFlowDomainFragment_49.html","createAndActivateFlowDomainFragment",false,null),new WCN("59/operation/createFlowDomain_50.html","createFlowDomain",false,null),new WCN("59/operation/createMatrixFlowDomain_51.html","createMatrixFlowDomain",false,null),new WCN("59/operation/deactivateAndDeleteFlowDomainFragment_52.html","deactivateAndDeleteFlowDomainFragment",false,null),new WCN("59/operation/deAssociateConnectionlessPortTerminationPointsFromFd_53.html","deAssociateConnectionlessPortTerminationPointsFromFd",false,null),new WCN("59/operation/deAssociateMatrixFlowDomainsFromFd_54.html","deAssociateMatrixFlowDomainsFromFd",false,null),new WCN("59/operation/deleteFlowDomain_55.html","deleteFlowDomain",false,null),new WCN("59/operation/deleteMatrixFlowDomain_56.html","deleteMatrixFlowDomain",false,null),new WCN("59/operation/modifyFlowDomain_57.html","modifyFlowDomain",false,null),new WCN("59/operation/modifyFlowDomainFragment_58.html","modifyFlowDomainFragment",false,null),new WCN("59/operation/modifyMatrixFlowDomain_59.html","modifyMatrixFlowDomain",false,null),new WCN("59/operation/unassignConnectionlessPortTerminationPointsFromMfd_60.html","unassignConnectionlessPortTerminationPointsFromMfd",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/fdc/v1-0"] = "59/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/gctc/v1-0"] =  new WC (
					new Array(new WCN("53/service/GuiCutThroughControlHttp.html","GuiCutThroughControlHttp",false,null),new WCN("53/service/GuiCutThroughControlJms.html","GuiCutThroughControlJms",false,null)),
					new Array(new WCN("53/message/destroyGuiCutThroughException.html","destroyGuiCutThroughException",false,null),new WCN("53/message/destroyGuiCutThroughRequest.html","destroyGuiCutThroughRequest",false,null),new WCN("53/message/destroyGuiCutThroughResponse.html","destroyGuiCutThroughResponse",false,null),new WCN("53/message/getGuiCutThroughProfileInfoException.html","getGuiCutThroughProfileInfoException",false,null),new WCN("53/message/getGuiCutThroughProfileInfoRequest.html","getGuiCutThroughProfileInfoRequest",false,null),new WCN("53/message/getGuiCutThroughProfileInfoResponse.html","getGuiCutThroughProfileInfoResponse",false,null),new WCN("53/message/launchGuiCutThroughException.html","launchGuiCutThroughException",false,null),new WCN("53/message/launchGuiCutThroughRequest.html","launchGuiCutThroughRequest",false,null),new WCN("53/message/launchGuiCutThroughResponse.html","launchGuiCutThroughResponse",false,null)),
					new Array(new WCN("53/porttype/GuiCutThroughControl.html","GuiCutThroughControl",false,new Array(new WCN("53/operation/destroyGuiCutThrough_19.html","destroyGuiCutThrough",false,null),new WCN("53/operation/getGuiCutThroughProfileInfo_20.html","getGuiCutThroughProfileInfo",false,null),new WCN("53/operation/launchGuiCutThrough_21.html","launchGuiCutThrough",false,null)))),
					new Array(new WCN("53/binding/GuiCutThroughControlSoapHttpBinding.html","GuiCutThroughControlSoapHttpBinding",false,new Array(new WCN("53/operation/destroyGuiCutThrough_19.html","destroyGuiCutThrough",false,null),new WCN("53/operation/getGuiCutThroughProfileInfo_20.html","getGuiCutThroughProfileInfo",false,null),new WCN("53/operation/launchGuiCutThrough_21.html","launchGuiCutThrough",false,null))),new WCN("53/binding/GuiCutThroughControlSoapJmsBinding.html","GuiCutThroughControlSoapJmsBinding",false,new Array(new WCN("53/operation/destroyGuiCutThrough_19.html","destroyGuiCutThrough",false,null),new WCN("53/operation/getGuiCutThroughProfileInfo_20.html","getGuiCutThroughProfileInfo",false,null),new WCN("53/operation/launchGuiCutThrough_21.html","launchGuiCutThrough",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/gctc/v1-0"] = "53/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/sdc/v1-0"] =  new WC (
					new Array(new WCN("56/service/SoftwareAndDataControlHttp.html","SoftwareAndDataControlHttp",false,null),new WCN("56/service/SoftwareAndDataControlJms.html","SoftwareAndDataControlJms",false,null)),
					new Array(new WCN("56/message/abortManagedElementBackupException.html","abortManagedElementBackupException",false,null),new WCN("56/message/abortManagedElementBackupRequest.html","abortManagedElementBackupRequest",false,null),new WCN("56/message/abortManagedElementBackupResponse.html","abortManagedElementBackupResponse",false,null),new WCN("56/message/backupManagedElementException.html","backupManagedElementException",false,null),new WCN("56/message/backupManagedElementRequest.html","backupManagedElementRequest",false,null),new WCN("56/message/backupManagedElementResponse.html","backupManagedElementResponse",false,null),new WCN("56/message/getBackupListException.html","getBackupListException",false,null),new WCN("56/message/getBackupListIteratorException.html","getBackupListIteratorException",false,null),new WCN("56/message/getBackupListIteratorRequest.html","getBackupListIteratorRequest",false,null),new WCN("56/message/getBackupListIteratorResponse.html","getBackupListIteratorResponse",false,null),new WCN("56/message/getBackupListRequest.html","getBackupListRequest",false,null),new WCN("56/message/getBackupListResponse.html","getBackupListResponse",false,null),new WCN("56/message/getManagedElementBackupStatusException.html","getManagedElementBackupStatusException",false,null),new WCN("56/message/getManagedElementBackupStatusRequest.html","getManagedElementBackupStatusRequest",false,null),new WCN("56/message/getManagedElementBackupStatusResponse.html","getManagedElementBackupStatusResponse",false,null)),
					new Array(new WCN("56/porttype/SoftwareAndDataControl.html","SoftwareAndDataControl",false,new Array(new WCN("56/operation/abortManagedElementBackup_32.html","abortManagedElementBackup",false,null),new WCN("56/operation/backupManagedElement_33.html","backupManagedElement",false,null),new WCN("56/operation/getBackupList_34.html","getBackupList",false,null),new WCN("56/operation/getBackupListIterator_36.html","getBackupListIterator",false,null),new WCN("56/operation/getManagedElementBackupStatus_35.html","getManagedElementBackupStatus",false,null)))),
					new Array(new WCN("56/binding/SoftwareAndDataControlSoapHttpBinding.html","SoftwareAndDataControlSoapHttpBinding",false,new Array(new WCN("56/operation/abortManagedElementBackup_32.html","abortManagedElementBackup",false,null),new WCN("56/operation/backupManagedElement_33.html","backupManagedElement",false,null),new WCN("56/operation/getBackupList_34.html","getBackupList",false,null),new WCN("56/operation/getBackupListIterator_36.html","getBackupListIterator",false,null),new WCN("56/operation/getManagedElementBackupStatus_35.html","getManagedElementBackupStatus",false,null))),new WCN("56/binding/SoftwareAndDataControlSoapJmsBinding.html","SoftwareAndDataControlSoapJmsBinding",false,new Array(new WCN("56/operation/abortManagedElementBackup_32.html","abortManagedElementBackup",false,null),new WCN("56/operation/backupManagedElement_33.html","backupManagedElement",false,null),new WCN("56/operation/getBackupList_34.html","getBackupList",false,null),new WCN("56/operation/getBackupListIterator_36.html","getBackupListIterator",false,null),new WCN("56/operation/getManagedElementBackupStatus_35.html","getManagedElementBackupStatus",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/sdc/v1-0"] = "56/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/tcpc/v1-0"] =  new WC (
					new Array(new WCN("58/service/TrafficConditioningProfileControlHttp.html","TrafficConditioningProfileControlHttp",false,null),new WCN("58/service/TrafficConditioningProfileControlJms.html","TrafficConditioningProfileControlJms",false,null)),
					new Array(new WCN("58/message/createTrafficConditioningProfileException.html","createTrafficConditioningProfileException",false,null),new WCN("58/message/createTrafficConditioningProfileRequest.html","createTrafficConditioningProfileRequest",false,null),new WCN("58/message/createTrafficConditioningProfileResponse.html","createTrafficConditioningProfileResponse",false,null),new WCN("58/message/deleteTrafficConditioningProfileException.html","deleteTrafficConditioningProfileException",false,null),new WCN("58/message/deleteTrafficConditioningProfileRequest.html","deleteTrafficConditioningProfileRequest",false,null),new WCN("58/message/deleteTrafficConditioningProfileResponse.html","deleteTrafficConditioningProfileResponse",false,null),new WCN("58/message/modifyTrafficConditioningProfileException.html","modifyTrafficConditioningProfileException",false,null),new WCN("58/message/modifyTrafficConditioningProfileRequest.html","modifyTrafficConditioningProfileRequest",false,null),new WCN("58/message/modifyTrafficConditioningProfileResponse.html","modifyTrafficConditioningProfileResponse",false,null)),
					new Array(new WCN("58/porttype/TrafficConditioningProfileControl.html","TrafficConditioningProfileControl",false,new Array(new WCN("58/operation/createTrafficConditioningProfile_43.html","createTrafficConditioningProfile",false,null),new WCN("58/operation/deleteTrafficConditioningProfile_44.html","deleteTrafficConditioningProfile",false,null),new WCN("58/operation/modifyTrafficConditioningProfile_45.html","modifyTrafficConditioningProfile",false,null)))),
					new Array(new WCN("58/binding/TrafficConditioningProfileControlSoapHttpBinding.html","TrafficConditioningProfileControlSoapHttpBinding",false,new Array(new WCN("58/operation/createTrafficConditioningProfile_43.html","createTrafficConditioningProfile",false,null),new WCN("58/operation/deleteTrafficConditioningProfile_44.html","deleteTrafficConditioningProfile",false,null),new WCN("58/operation/modifyTrafficConditioningProfile_45.html","modifyTrafficConditioningProfile",false,null))),new WCN("58/binding/TrafficConditioningProfileControlSoapJmsBinding.html","TrafficConditioningProfileControlSoapJmsBinding",false,new Array(new WCN("58/operation/createTrafficConditioningProfile_43.html","createTrafficConditioningProfile",false,null),new WCN("58/operation/deleteTrafficConditioningProfile_44.html","deleteTrafficConditioningProfile",false,null),new WCN("58/operation/modifyTrafficConditioningProfile_45.html","modifyTrafficConditioningProfile",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/tcpc/v1-0"] = "58/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/tlc/v1-0"] =  new WC (
					new Array(new WCN("50/service/TopologicalLinkControlHttp.html","TopologicalLinkControlHttp",false,null),new WCN("50/service/TopologicalLinkControlJms.html","TopologicalLinkControlJms",false,null)),
					new Array(new WCN("50/message/createTopologicalLinkException.html","createTopologicalLinkException",false,null),new WCN("50/message/createTopologicalLinkRequest.html","createTopologicalLinkRequest",false,null),new WCN("50/message/createTopologicalLinkResponse.html","createTopologicalLinkResponse",false,null),new WCN("50/message/deleteTopologicalLinkException.html","deleteTopologicalLinkException",false,null),new WCN("50/message/deleteTopologicalLinkRequest.html","deleteTopologicalLinkRequest",false,null),new WCN("50/message/deleteTopologicalLinkResponse.html","deleteTopologicalLinkResponse",false,null)),
					new Array(new WCN("50/porttype/TopologicalLinkControl.html","TopologicalLinkControl",false,new Array(new WCN("50/operation/createTopologicalLink_0.html","createTopologicalLink",false,null),new WCN("50/operation/deleteTopologicalLink_1.html","deleteTopologicalLink",false,null)))),
					new Array(new WCN("50/binding/TopologicalLinkControlSoapHttpBinding.html","TopologicalLinkControlSoapHttpBinding",false,new Array(new WCN("50/operation/createTopologicalLink_0.html","createTopologicalLink",false,null),new WCN("50/operation/deleteTopologicalLink_1.html","deleteTopologicalLink",false,null))),new WCN("50/binding/TopologicalLinkControlSoapJmsBinding.html","TopologicalLinkControlSoapJmsBinding",false,new Array(new WCN("50/operation/createTopologicalLink_0.html","createTopologicalLink",false,null),new WCN("50/operation/deleteTopologicalLink_1.html","deleteTopologicalLink",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/tlc/v1-0"] = "50/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/tmdc/v1-0"] =  new WC (
					new Array(new WCN("57/service/TransmissionDescriptorControlHttp.html","TransmissionDescriptorControlHttp",false,null),new WCN("57/service/TransmissionDescriptorControlJms.html","TransmissionDescriptorControlJms",false,null)),
					new Array(new WCN("57/message/createTransmissionDescriptorException.html","createTransmissionDescriptorException",false,null),new WCN("57/message/createTransmissionDescriptorRequest.html","createTransmissionDescriptorRequest",false,null),new WCN("57/message/createTransmissionDescriptorResponse.html","createTransmissionDescriptorResponse",false,null),new WCN("57/message/deleteTransmissionDescriptorException.html","deleteTransmissionDescriptorException",false,null),new WCN("57/message/deleteTransmissionDescriptorRequest.html","deleteTransmissionDescriptorRequest",false,null),new WCN("57/message/deleteTransmissionDescriptorResponse.html","deleteTransmissionDescriptorResponse",false,null),new WCN("57/message/modifyTransmissionDescriptorException.html","modifyTransmissionDescriptorException",false,null),new WCN("57/message/modifyTransmissionDescriptorRequest.html","modifyTransmissionDescriptorRequest",false,null),new WCN("57/message/modifyTransmissionDescriptorResponse.html","modifyTransmissionDescriptorResponse",false,null),new WCN("57/message/setTransmissionDescriptorAssociationException.html","setTransmissionDescriptorAssociationException",false,null),new WCN("57/message/setTransmissionDescriptorAssociationRequest.html","setTransmissionDescriptorAssociationRequest",false,null),new WCN("57/message/setTransmissionDescriptorAssociationResponse.html","setTransmissionDescriptorAssociationResponse",false,null),new WCN("57/message/validateTransmissionDescriptorAssignmentToObjectException.html","validateTransmissionDescriptorAssignmentToObjectException",false,null),new WCN("57/message/validateTransmissionDescriptorAssignmentToObjectRequest.html","validateTransmissionDescriptorAssignmentToObjectRequest",false,null),new WCN("57/message/validateTransmissionDescriptorAssignmentToObjectResponse.html","validateTransmissionDescriptorAssignmentToObjectResponse",false,null),new WCN("57/message/verifyTransmissionDescriptorAssignmentException.html","verifyTransmissionDescriptorAssignmentException",false,null),new WCN("57/message/verifyTransmissionDescriptorAssignmentRequest.html","verifyTransmissionDescriptorAssignmentRequest",false,null),new WCN("57/message/verifyTransmissionDescriptorAssignmentResponse.html","verifyTransmissionDescriptorAssignmentResponse",false,null)),
					new Array(new WCN("57/porttype/TransmissionDescriptorControl.html","TransmissionDescriptorControl",false,new Array(new WCN("57/operation/createTransmissionDescriptor_37.html","createTransmissionDescriptor",false,null),new WCN("57/operation/deleteTransmissionDescriptor_38.html","deleteTransmissionDescriptor",false,null),new WCN("57/operation/modifyTransmissionDescriptor_39.html","modifyTransmissionDescriptor",false,null),new WCN("57/operation/setTransmissionDescriptorAssociation_40.html","setTransmissionDescriptorAssociation",false,null),new WCN("57/operation/validateTransmissionDescriptorAssignmentToObject_41.html","validateTransmissionDescriptorAssignmentToObject",false,null),new WCN("57/operation/verifyTransmissionDescriptorAssignment_42.html","verifyTransmissionDescriptorAssignment",false,null)))),
					new Array(new WCN("57/binding/TransmissionDescriptorControlSoapHttpBinding.html","TransmissionDescriptorControlSoapHttpBinding",false,new Array(new WCN("57/operation/createTransmissionDescriptor_37.html","createTransmissionDescriptor",false,null),new WCN("57/operation/deleteTransmissionDescriptor_38.html","deleteTransmissionDescriptor",false,null),new WCN("57/operation/modifyTransmissionDescriptor_39.html","modifyTransmissionDescriptor",false,null),new WCN("57/operation/setTransmissionDescriptorAssociation_40.html","setTransmissionDescriptorAssociation",false,null),new WCN("57/operation/validateTransmissionDescriptorAssignmentToObject_41.html","validateTransmissionDescriptorAssignmentToObject",false,null),new WCN("57/operation/verifyTransmissionDescriptorAssignment_42.html","verifyTransmissionDescriptorAssignment",false,null))),new WCN("57/binding/TransmissionDescriptorControlSoapJmsBinding.html","TransmissionDescriptorControlSoapJmsBinding",false,new Array(new WCN("57/operation/createTransmissionDescriptor_37.html","createTransmissionDescriptor",false,null),new WCN("57/operation/deleteTransmissionDescriptor_38.html","deleteTransmissionDescriptor",false,null),new WCN("57/operation/modifyTransmissionDescriptor_39.html","modifyTransmissionDescriptor",false,null),new WCN("57/operation/setTransmissionDescriptorAssociation_40.html","setTransmissionDescriptorAssociation",false,null),new WCN("57/operation/validateTransmissionDescriptorAssignmentToObject_41.html","validateTransmissionDescriptorAssignmentToObject",false,null),new WCN("57/operation/verifyTransmissionDescriptorAssignment_42.html","verifyTransmissionDescriptorAssignment",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/tmdc/v1-0"] = "57/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/tpc/v1-0"] =  new WC (
					new Array(new WCN("54/service/TerminationPointControlHttp.html","TerminationPointControlHttp",false,null),new WCN("54/service/TerminationPointControlJms.html","TerminationPointControlJms",false,null)),
					new Array(new WCN("54/message/createFloatingTerminationPointException.html","createFloatingTerminationPointException",false,null),new WCN("54/message/createFloatingTerminationPointRequest.html","createFloatingTerminationPointRequest",false,null),new WCN("54/message/createFloatingTerminationPointResponse.html","createFloatingTerminationPointResponse",false,null),new WCN("54/message/createGroupTerminationPointException.html","createGroupTerminationPointException",false,null),new WCN("54/message/createGroupTerminationPointRequest.html","createGroupTerminationPointRequest",false,null),new WCN("54/message/createGroupTerminationPointResponse.html","createGroupTerminationPointResponse",false,null),new WCN("54/message/createTerminationPointPoolException.html","createTerminationPointPoolException",false,null),new WCN("54/message/createTerminationPointPoolRequest.html","createTerminationPointPoolRequest",false,null),new WCN("54/message/createTerminationPointPoolResponse.html","createTerminationPointPoolResponse",false,null),new WCN("54/message/deleteFloatingTerminationPointException.html","deleteFloatingTerminationPointException",false,null),new WCN("54/message/deleteFloatingTerminationPointRequest.html","deleteFloatingTerminationPointRequest",false,null),new WCN("54/message/deleteFloatingTerminationPointResponse.html","deleteFloatingTerminationPointResponse",false,null),new WCN("54/message/deleteGroupTerminationPointException.html","deleteGroupTerminationPointException",false,null),new WCN("54/message/deleteGroupTerminationPointRequest.html","deleteGroupTerminationPointRequest",false,null),new WCN("54/message/deleteGroupTerminationPointResponse.html","deleteGroupTerminationPointResponse",false,null),new WCN("54/message/deleteTerminationPointPoolException.html","deleteTerminationPointPoolException",false,null),new WCN("54/message/deleteTerminationPointPoolRequest.html","deleteTerminationPointPoolRequest",false,null),new WCN("54/message/deleteTerminationPointPoolResponse.html","deleteTerminationPointPoolResponse",false,null),new WCN("54/message/modifyGroupTerminationPointException.html","modifyGroupTerminationPointException",false,null),new WCN("54/message/modifyGroupTerminationPointRequest.html","modifyGroupTerminationPointRequest",false,null),new WCN("54/message/modifyGroupTerminationPointResponse.html","modifyGroupTerminationPointResponse",false,null),new WCN("54/message/modifyTerminationPointPoolException.html","modifyTerminationPointPoolException",false,null),new WCN("54/message/modifyTerminationPointPoolRequest.html","modifyTerminationPointPoolRequest",false,null),new WCN("54/message/modifyTerminationPointPoolResponse.html","modifyTerminationPointPoolResponse",false,null),new WCN("54/message/setTerminationPointDataException.html","setTerminationPointDataException",false,null),new WCN("54/message/setTerminationPointDataRequest.html","setTerminationPointDataRequest",false,null),new WCN("54/message/setTerminationPointDataResponse.html","setTerminationPointDataResponse",false,null)),
					new Array(new WCN("54/porttype/TerminationPointControl.html","TerminationPointControl",false,new Array(new WCN("54/operation/createFloatingTerminationPoint_22.html","createFloatingTerminationPoint",false,null),new WCN("54/operation/createGroupTerminationPoint_23.html","createGroupTerminationPoint",false,null),new WCN("54/operation/createTerminationPointPool_24.html","createTerminationPointPool",false,null),new WCN("54/operation/deleteFloatingTerminationPoint_25.html","deleteFloatingTerminationPoint",false,null),new WCN("54/operation/deleteGroupTerminationPoint_26.html","deleteGroupTerminationPoint",false,null),new WCN("54/operation/deleteTerminationPointPool_27.html","deleteTerminationPointPool",false,null),new WCN("54/operation/modifyGroupTerminationPoint_28.html","modifyGroupTerminationPoint",false,null),new WCN("54/operation/modifyTerminationPointPool_29.html","modifyTerminationPointPool",false,null),new WCN("54/operation/setTerminationPointData_30.html","setTerminationPointData",false,null)))),
					new Array(new WCN("54/binding/TerminationPointControlSoapHttpBinding.html","TerminationPointControlSoapHttpBinding",false,new Array(new WCN("54/operation/createFloatingTerminationPoint_22.html","createFloatingTerminationPoint",false,null),new WCN("54/operation/createGroupTerminationPoint_23.html","createGroupTerminationPoint",false,null),new WCN("54/operation/createTerminationPointPool_24.html","createTerminationPointPool",false,null),new WCN("54/operation/deleteFloatingTerminationPoint_25.html","deleteFloatingTerminationPoint",false,null),new WCN("54/operation/deleteGroupTerminationPoint_26.html","deleteGroupTerminationPoint",false,null),new WCN("54/operation/deleteTerminationPointPool_27.html","deleteTerminationPointPool",false,null),new WCN("54/operation/modifyGroupTerminationPoint_28.html","modifyGroupTerminationPoint",false,null),new WCN("54/operation/modifyTerminationPointPool_29.html","modifyTerminationPointPool",false,null),new WCN("54/operation/setTerminationPointData_30.html","setTerminationPointData",false,null))),new WCN("54/binding/TerminationPointControlSoapJmsBinding.html","TerminationPointControlSoapJmsBinding",false,new Array(new WCN("54/operation/createFloatingTerminationPoint_22.html","createFloatingTerminationPoint",false,null),new WCN("54/operation/createGroupTerminationPoint_23.html","createGroupTerminationPoint",false,null),new WCN("54/operation/createTerminationPointPool_24.html","createTerminationPointPool",false,null),new WCN("54/operation/deleteFloatingTerminationPoint_25.html","deleteFloatingTerminationPoint",false,null),new WCN("54/operation/deleteGroupTerminationPoint_26.html","deleteGroupTerminationPoint",false,null),new WCN("54/operation/deleteTerminationPointPool_27.html","deleteTerminationPointPool",false,null),new WCN("54/operation/modifyGroupTerminationPoint_28.html","modifyGroupTerminationPoint",false,null),new WCN("54/operation/modifyTerminationPointPool_29.html","modifyTerminationPointPool",false,null),new WCN("54/operation/setTerminationPointData_30.html","setTerminationPointData",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/tpc/v1-0"] = "54/index.html";
