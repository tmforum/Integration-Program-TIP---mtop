/*
 * XML Type:  AllExceptionsType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * An XML AllExceptionsType(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1).
 *
 * This is a complex type.
 */
public class AllExceptionsTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType
{
    
    public AllExceptionsTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACCESSDENIED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "accessDenied");
    private static final javax.xml.namespace.QName CAPACITYEXCEEDED$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "capacityExceeded");
    private static final javax.xml.namespace.QName COMMUNICATIONFAILURE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "communicationFailure");
    private static final javax.xml.namespace.QName ENTITYNOTFOUND$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "entityNotFound");
    private static final javax.xml.namespace.QName INTERNALERROR$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "internalError");
    private static final javax.xml.namespace.QName INVALIDFILTERDEFINITION$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "invalidFilterDefinition");
    private static final javax.xml.namespace.QName INVALIDINPUT$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "invalidInput");
    private static final javax.xml.namespace.QName INVALIDTOPIC$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "invalidTopic");
    private static final javax.xml.namespace.QName NOTIFICATIONSERVICEPROBLEM$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "notificationServiceProblem");
    private static final javax.xml.namespace.QName NOTIMPLEMENTED$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "notImplemented");
    private static final javax.xml.namespace.QName NOTINVALIDSTATE$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "notInValidState");
    private static final javax.xml.namespace.QName OBJECTINUSE$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "objectInUse");
    private static final javax.xml.namespace.QName PROTECTIONEFFORTNOTMET$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "protectionEffortNotMet");
    private static final javax.xml.namespace.QName TIMESLOTINUSE$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "timeslotInUse");
    private static final javax.xml.namespace.QName TOOMANYOPENITERATORS$28 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "tooManyOpenIterators");
    private static final javax.xml.namespace.QName TPINVALIDENDPOINT$30 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "tpInvalidEndPoint");
    private static final javax.xml.namespace.QName UNABLETOCOMPLY$32 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "unableToComply");
    private static final javax.xml.namespace.QName UNSUPPORTEDCOMPRESSIONFORMAT$34 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "unsupportedCompressionFormat");
    private static final javax.xml.namespace.QName UNSUPPORTEDPACKINGFORMAT$36 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "unsupportedPackingFormat");
    private static final javax.xml.namespace.QName UNSUPPORTEDROUTINGCONSTRAINTS$38 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "unsupportedRoutingConstraints");
    private static final javax.xml.namespace.QName USERLABELINUSE$40 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "userlabelInUse");
    
    
    /**
     * Gets the "accessDenied" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getAccessDenied()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(ACCESSDENIED$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "accessDenied" element
     */
    public boolean isSetAccessDenied()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACCESSDENIED$0) != 0;
        }
    }
    
    /**
     * Sets the "accessDenied" element
     */
    public void setAccessDenied(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType accessDenied)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(ACCESSDENIED$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(ACCESSDENIED$0);
            }
            target.set(accessDenied);
        }
    }
    
    /**
     * Appends and returns a new empty "accessDenied" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewAccessDenied()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(ACCESSDENIED$0);
            return target;
        }
    }
    
    /**
     * Unsets the "accessDenied" element
     */
    public void unsetAccessDenied()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACCESSDENIED$0, 0);
        }
    }
    
    /**
     * Gets the "capacityExceeded" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getCapacityExceeded()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(CAPACITYEXCEEDED$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "capacityExceeded" element
     */
    public boolean isSetCapacityExceeded()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CAPACITYEXCEEDED$2) != 0;
        }
    }
    
    /**
     * Sets the "capacityExceeded" element
     */
    public void setCapacityExceeded(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType capacityExceeded)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(CAPACITYEXCEEDED$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(CAPACITYEXCEEDED$2);
            }
            target.set(capacityExceeded);
        }
    }
    
    /**
     * Appends and returns a new empty "capacityExceeded" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewCapacityExceeded()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(CAPACITYEXCEEDED$2);
            return target;
        }
    }
    
    /**
     * Unsets the "capacityExceeded" element
     */
    public void unsetCapacityExceeded()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CAPACITYEXCEEDED$2, 0);
        }
    }
    
    /**
     * Gets the "communicationFailure" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getCommunicationFailure()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(COMMUNICATIONFAILURE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "communicationFailure" element
     */
    public boolean isSetCommunicationFailure()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COMMUNICATIONFAILURE$4) != 0;
        }
    }
    
    /**
     * Sets the "communicationFailure" element
     */
    public void setCommunicationFailure(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType communicationFailure)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(COMMUNICATIONFAILURE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(COMMUNICATIONFAILURE$4);
            }
            target.set(communicationFailure);
        }
    }
    
    /**
     * Appends and returns a new empty "communicationFailure" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewCommunicationFailure()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(COMMUNICATIONFAILURE$4);
            return target;
        }
    }
    
    /**
     * Unsets the "communicationFailure" element
     */
    public void unsetCommunicationFailure()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COMMUNICATIONFAILURE$4, 0);
        }
    }
    
    /**
     * Gets the "entityNotFound" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getEntityNotFound()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(ENTITYNOTFOUND$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "entityNotFound" element
     */
    public boolean isSetEntityNotFound()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ENTITYNOTFOUND$6) != 0;
        }
    }
    
    /**
     * Sets the "entityNotFound" element
     */
    public void setEntityNotFound(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType entityNotFound)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(ENTITYNOTFOUND$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(ENTITYNOTFOUND$6);
            }
            target.set(entityNotFound);
        }
    }
    
    /**
     * Appends and returns a new empty "entityNotFound" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewEntityNotFound()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(ENTITYNOTFOUND$6);
            return target;
        }
    }
    
    /**
     * Unsets the "entityNotFound" element
     */
    public void unsetEntityNotFound()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ENTITYNOTFOUND$6, 0);
        }
    }
    
    /**
     * Gets the "internalError" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInternalError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INTERNALERROR$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "internalError" element
     */
    public boolean isSetInternalError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTERNALERROR$8) != 0;
        }
    }
    
    /**
     * Sets the "internalError" element
     */
    public void setInternalError(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType internalError)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INTERNALERROR$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INTERNALERROR$8);
            }
            target.set(internalError);
        }
    }
    
    /**
     * Appends and returns a new empty "internalError" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInternalError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INTERNALERROR$8);
            return target;
        }
    }
    
    /**
     * Unsets the "internalError" element
     */
    public void unsetInternalError()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTERNALERROR$8, 0);
        }
    }
    
    /**
     * Gets the "invalidFilterDefinition" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInvalidFilterDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDFILTERDEFINITION$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "invalidFilterDefinition" element
     */
    public boolean isSetInvalidFilterDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INVALIDFILTERDEFINITION$10) != 0;
        }
    }
    
    /**
     * Sets the "invalidFilterDefinition" element
     */
    public void setInvalidFilterDefinition(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType invalidFilterDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDFILTERDEFINITION$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDFILTERDEFINITION$10);
            }
            target.set(invalidFilterDefinition);
        }
    }
    
    /**
     * Appends and returns a new empty "invalidFilterDefinition" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInvalidFilterDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDFILTERDEFINITION$10);
            return target;
        }
    }
    
    /**
     * Unsets the "invalidFilterDefinition" element
     */
    public void unsetInvalidFilterDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INVALIDFILTERDEFINITION$10, 0);
        }
    }
    
    /**
     * Gets the "invalidInput" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInvalidInput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDINPUT$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "invalidInput" element
     */
    public boolean isSetInvalidInput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INVALIDINPUT$12) != 0;
        }
    }
    
    /**
     * Sets the "invalidInput" element
     */
    public void setInvalidInput(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType invalidInput)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDINPUT$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDINPUT$12);
            }
            target.set(invalidInput);
        }
    }
    
    /**
     * Appends and returns a new empty "invalidInput" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInvalidInput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDINPUT$12);
            return target;
        }
    }
    
    /**
     * Unsets the "invalidInput" element
     */
    public void unsetInvalidInput()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INVALIDINPUT$12, 0);
        }
    }
    
    /**
     * Gets the "invalidTopic" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInvalidTopic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDTOPIC$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "invalidTopic" element
     */
    public boolean isSetInvalidTopic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INVALIDTOPIC$14) != 0;
        }
    }
    
    /**
     * Sets the "invalidTopic" element
     */
    public void setInvalidTopic(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType invalidTopic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDTOPIC$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDTOPIC$14);
            }
            target.set(invalidTopic);
        }
    }
    
    /**
     * Appends and returns a new empty "invalidTopic" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInvalidTopic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDTOPIC$14);
            return target;
        }
    }
    
    /**
     * Unsets the "invalidTopic" element
     */
    public void unsetInvalidTopic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INVALIDTOPIC$14, 0);
        }
    }
    
    /**
     * Gets the "notificationServiceProblem" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getNotificationServiceProblem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTIFICATIONSERVICEPROBLEM$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "notificationServiceProblem" element
     */
    public boolean isSetNotificationServiceProblem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOTIFICATIONSERVICEPROBLEM$16) != 0;
        }
    }
    
    /**
     * Sets the "notificationServiceProblem" element
     */
    public void setNotificationServiceProblem(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType notificationServiceProblem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTIFICATIONSERVICEPROBLEM$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTIFICATIONSERVICEPROBLEM$16);
            }
            target.set(notificationServiceProblem);
        }
    }
    
    /**
     * Appends and returns a new empty "notificationServiceProblem" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewNotificationServiceProblem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTIFICATIONSERVICEPROBLEM$16);
            return target;
        }
    }
    
    /**
     * Unsets the "notificationServiceProblem" element
     */
    public void unsetNotificationServiceProblem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOTIFICATIONSERVICEPROBLEM$16, 0);
        }
    }
    
    /**
     * Gets the "notImplemented" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getNotImplemented()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTIMPLEMENTED$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "notImplemented" element
     */
    public boolean isSetNotImplemented()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOTIMPLEMENTED$18) != 0;
        }
    }
    
    /**
     * Sets the "notImplemented" element
     */
    public void setNotImplemented(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType notImplemented)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTIMPLEMENTED$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTIMPLEMENTED$18);
            }
            target.set(notImplemented);
        }
    }
    
    /**
     * Appends and returns a new empty "notImplemented" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewNotImplemented()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTIMPLEMENTED$18);
            return target;
        }
    }
    
    /**
     * Unsets the "notImplemented" element
     */
    public void unsetNotImplemented()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOTIMPLEMENTED$18, 0);
        }
    }
    
    /**
     * Gets the "notInValidState" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getNotInValidState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTINVALIDSTATE$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "notInValidState" element
     */
    public boolean isSetNotInValidState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOTINVALIDSTATE$20) != 0;
        }
    }
    
    /**
     * Sets the "notInValidState" element
     */
    public void setNotInValidState(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType notInValidState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTINVALIDSTATE$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTINVALIDSTATE$20);
            }
            target.set(notInValidState);
        }
    }
    
    /**
     * Appends and returns a new empty "notInValidState" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewNotInValidState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTINVALIDSTATE$20);
            return target;
        }
    }
    
    /**
     * Unsets the "notInValidState" element
     */
    public void unsetNotInValidState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOTINVALIDSTATE$20, 0);
        }
    }
    
    /**
     * Gets the "objectInUse" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getObjectInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(OBJECTINUSE$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "objectInUse" element
     */
    public boolean isSetObjectInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTINUSE$22) != 0;
        }
    }
    
    /**
     * Sets the "objectInUse" element
     */
    public void setObjectInUse(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType objectInUse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(OBJECTINUSE$22, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(OBJECTINUSE$22);
            }
            target.set(objectInUse);
        }
    }
    
    /**
     * Appends and returns a new empty "objectInUse" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewObjectInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(OBJECTINUSE$22);
            return target;
        }
    }
    
    /**
     * Unsets the "objectInUse" element
     */
    public void unsetObjectInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTINUSE$22, 0);
        }
    }
    
    /**
     * Gets the "protectionEffortNotMet" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getProtectionEffortNotMet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(PROTECTIONEFFORTNOTMET$24, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "protectionEffortNotMet" element
     */
    public boolean isSetProtectionEffortNotMet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONEFFORTNOTMET$24) != 0;
        }
    }
    
    /**
     * Sets the "protectionEffortNotMet" element
     */
    public void setProtectionEffortNotMet(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType protectionEffortNotMet)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(PROTECTIONEFFORTNOTMET$24, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(PROTECTIONEFFORTNOTMET$24);
            }
            target.set(protectionEffortNotMet);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionEffortNotMet" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewProtectionEffortNotMet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(PROTECTIONEFFORTNOTMET$24);
            return target;
        }
    }
    
    /**
     * Unsets the "protectionEffortNotMet" element
     */
    public void unsetProtectionEffortNotMet()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONEFFORTNOTMET$24, 0);
        }
    }
    
    /**
     * Gets the "timeslotInUse" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getTimeslotInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(TIMESLOTINUSE$26, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "timeslotInUse" element
     */
    public boolean isSetTimeslotInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TIMESLOTINUSE$26) != 0;
        }
    }
    
    /**
     * Sets the "timeslotInUse" element
     */
    public void setTimeslotInUse(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType timeslotInUse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(TIMESLOTINUSE$26, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(TIMESLOTINUSE$26);
            }
            target.set(timeslotInUse);
        }
    }
    
    /**
     * Appends and returns a new empty "timeslotInUse" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewTimeslotInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(TIMESLOTINUSE$26);
            return target;
        }
    }
    
    /**
     * Unsets the "timeslotInUse" element
     */
    public void unsetTimeslotInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TIMESLOTINUSE$26, 0);
        }
    }
    
    /**
     * Gets the "tooManyOpenIterators" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getTooManyOpenIterators()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(TOOMANYOPENITERATORS$28, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tooManyOpenIterators" element
     */
    public boolean isSetTooManyOpenIterators()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TOOMANYOPENITERATORS$28) != 0;
        }
    }
    
    /**
     * Sets the "tooManyOpenIterators" element
     */
    public void setTooManyOpenIterators(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType tooManyOpenIterators)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(TOOMANYOPENITERATORS$28, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(TOOMANYOPENITERATORS$28);
            }
            target.set(tooManyOpenIterators);
        }
    }
    
    /**
     * Appends and returns a new empty "tooManyOpenIterators" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewTooManyOpenIterators()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(TOOMANYOPENITERATORS$28);
            return target;
        }
    }
    
    /**
     * Unsets the "tooManyOpenIterators" element
     */
    public void unsetTooManyOpenIterators()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TOOMANYOPENITERATORS$28, 0);
        }
    }
    
    /**
     * Gets the "tpInvalidEndPoint" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getTpInvalidEndPoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(TPINVALIDENDPOINT$30, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tpInvalidEndPoint" element
     */
    public boolean isSetTpInvalidEndPoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPINVALIDENDPOINT$30) != 0;
        }
    }
    
    /**
     * Sets the "tpInvalidEndPoint" element
     */
    public void setTpInvalidEndPoint(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType tpInvalidEndPoint)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(TPINVALIDENDPOINT$30, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(TPINVALIDENDPOINT$30);
            }
            target.set(tpInvalidEndPoint);
        }
    }
    
    /**
     * Appends and returns a new empty "tpInvalidEndPoint" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewTpInvalidEndPoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(TPINVALIDENDPOINT$30);
            return target;
        }
    }
    
    /**
     * Unsets the "tpInvalidEndPoint" element
     */
    public void unsetTpInvalidEndPoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPINVALIDENDPOINT$30, 0);
        }
    }
    
    /**
     * Gets the "unableToComply" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnableToComply()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNABLETOCOMPLY$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "unableToComply" element
     */
    public boolean isSetUnableToComply()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UNABLETOCOMPLY$32) != 0;
        }
    }
    
    /**
     * Sets the "unableToComply" element
     */
    public void setUnableToComply(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unableToComply)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNABLETOCOMPLY$32, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNABLETOCOMPLY$32);
            }
            target.set(unableToComply);
        }
    }
    
    /**
     * Appends and returns a new empty "unableToComply" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnableToComply()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNABLETOCOMPLY$32);
            return target;
        }
    }
    
    /**
     * Unsets the "unableToComply" element
     */
    public void unsetUnableToComply()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UNABLETOCOMPLY$32, 0);
        }
    }
    
    /**
     * Gets the "unsupportedCompressionFormat" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnsupportedCompressionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNSUPPORTEDCOMPRESSIONFORMAT$34, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "unsupportedCompressionFormat" element
     */
    public boolean isSetUnsupportedCompressionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UNSUPPORTEDCOMPRESSIONFORMAT$34) != 0;
        }
    }
    
    /**
     * Sets the "unsupportedCompressionFormat" element
     */
    public void setUnsupportedCompressionFormat(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unsupportedCompressionFormat)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNSUPPORTEDCOMPRESSIONFORMAT$34, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNSUPPORTEDCOMPRESSIONFORMAT$34);
            }
            target.set(unsupportedCompressionFormat);
        }
    }
    
    /**
     * Appends and returns a new empty "unsupportedCompressionFormat" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnsupportedCompressionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNSUPPORTEDCOMPRESSIONFORMAT$34);
            return target;
        }
    }
    
    /**
     * Unsets the "unsupportedCompressionFormat" element
     */
    public void unsetUnsupportedCompressionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UNSUPPORTEDCOMPRESSIONFORMAT$34, 0);
        }
    }
    
    /**
     * Gets the "unsupportedPackingFormat" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnsupportedPackingFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNSUPPORTEDPACKINGFORMAT$36, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "unsupportedPackingFormat" element
     */
    public boolean isSetUnsupportedPackingFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UNSUPPORTEDPACKINGFORMAT$36) != 0;
        }
    }
    
    /**
     * Sets the "unsupportedPackingFormat" element
     */
    public void setUnsupportedPackingFormat(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unsupportedPackingFormat)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNSUPPORTEDPACKINGFORMAT$36, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNSUPPORTEDPACKINGFORMAT$36);
            }
            target.set(unsupportedPackingFormat);
        }
    }
    
    /**
     * Appends and returns a new empty "unsupportedPackingFormat" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnsupportedPackingFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNSUPPORTEDPACKINGFORMAT$36);
            return target;
        }
    }
    
    /**
     * Unsets the "unsupportedPackingFormat" element
     */
    public void unsetUnsupportedPackingFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UNSUPPORTEDPACKINGFORMAT$36, 0);
        }
    }
    
    /**
     * Gets the "unsupportedRoutingConstraints" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnsupportedRoutingConstraints()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNSUPPORTEDROUTINGCONSTRAINTS$38, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "unsupportedRoutingConstraints" element
     */
    public boolean isSetUnsupportedRoutingConstraints()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UNSUPPORTEDROUTINGCONSTRAINTS$38) != 0;
        }
    }
    
    /**
     * Sets the "unsupportedRoutingConstraints" element
     */
    public void setUnsupportedRoutingConstraints(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unsupportedRoutingConstraints)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNSUPPORTEDROUTINGCONSTRAINTS$38, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNSUPPORTEDROUTINGCONSTRAINTS$38);
            }
            target.set(unsupportedRoutingConstraints);
        }
    }
    
    /**
     * Appends and returns a new empty "unsupportedRoutingConstraints" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnsupportedRoutingConstraints()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNSUPPORTEDROUTINGCONSTRAINTS$38);
            return target;
        }
    }
    
    /**
     * Unsets the "unsupportedRoutingConstraints" element
     */
    public void unsetUnsupportedRoutingConstraints()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UNSUPPORTEDROUTINGCONSTRAINTS$38, 0);
        }
    }
    
    /**
     * Gets the "userlabelInUse" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUserlabelInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(USERLABELINUSE$40, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "userlabelInUse" element
     */
    public boolean isSetUserlabelInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(USERLABELINUSE$40) != 0;
        }
    }
    
    /**
     * Sets the "userlabelInUse" element
     */
    public void setUserlabelInUse(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType userlabelInUse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(USERLABELINUSE$40, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(USERLABELINUSE$40);
            }
            target.set(userlabelInUse);
        }
    }
    
    /**
     * Appends and returns a new empty "userlabelInUse" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUserlabelInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(USERLABELINUSE$40);
            return target;
        }
    }
    
    /**
     * Unsets the "userlabelInUse" element
     */
    public void unsetUserlabelInUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(USERLABELINUSE$40, 0);
        }
    }
}
