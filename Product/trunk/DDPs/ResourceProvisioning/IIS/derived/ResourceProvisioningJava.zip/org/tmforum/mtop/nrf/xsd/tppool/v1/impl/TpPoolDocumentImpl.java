/*
 * An XML document type.
 * Localname: tpPool
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tppool/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tppool.v1.impl;
/**
 * A document containing one tpPool(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1) element.
 *
 * This is a complex type.
 */
public class TpPoolDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolDocument
{
    
    public TpPoolDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPPOOL$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "tpPool");
    
    
    /**
     * Gets the "tpPool" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType getTpPool()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType)get_store().find_element_user(TPPOOL$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tpPool" element
     */
    public void setTpPool(org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType tpPool)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType)get_store().find_element_user(TPPOOL$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType)get_store().add_element_user(TPPOOL$0);
            }
            target.set(tpPool);
        }
    }
    
    /**
     * Appends and returns a new empty "tpPool" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType addNewTpPool()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType)get_store().add_element_user(TPPOOL$0);
            return target;
        }
    }
}
