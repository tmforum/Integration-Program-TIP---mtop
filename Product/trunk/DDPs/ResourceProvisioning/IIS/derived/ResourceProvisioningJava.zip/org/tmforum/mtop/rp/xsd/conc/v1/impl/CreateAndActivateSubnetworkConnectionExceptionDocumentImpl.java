/*
 * An XML document type.
 * Localname: createAndActivateSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createAndActivateSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAndActivateSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument
{
    
    public CreateAndActivateSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEANDACTIVATESUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createAndActivateSubnetworkConnectionException");
    
    
    /**
     * Gets the "createAndActivateSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException getCreateAndActivateSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException)get_store().find_element_user(CREATEANDACTIVATESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAndActivateSubnetworkConnectionException" element
     */
    public void setCreateAndActivateSubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException createAndActivateSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException)get_store().find_element_user(CREATEANDACTIVATESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException)get_store().add_element_user(CREATEANDACTIVATESUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(createAndActivateSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "createAndActivateSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException addNewCreateAndActivateSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException)get_store().add_element_user(CREATEANDACTIVATESUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML createAndActivateSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAndActivateSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionExceptionDocument.CreateAndActivateSubnetworkConnectionException
    {
        
        public CreateAndActivateSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
