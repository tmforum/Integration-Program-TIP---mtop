/*
 * An XML document type.
 * Localname: checkValidSncRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one checkValidSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CheckValidSncRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument
{
    
    public CheckValidSncRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHECKVALIDSNCREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "checkValidSncRequest");
    
    
    /**
     * Gets the "checkValidSncRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest getCheckValidSncRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest)get_store().find_element_user(CHECKVALIDSNCREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "checkValidSncRequest" element
     */
    public void setCheckValidSncRequest(org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest checkValidSncRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest)get_store().find_element_user(CHECKVALIDSNCREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest)get_store().add_element_user(CHECKVALIDSNCREQUEST$0);
            }
            target.set(checkValidSncRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "checkValidSncRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest addNewCheckValidSncRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest)get_store().add_element_user(CHECKVALIDSNCREQUEST$0);
            return target;
        }
    }
    /**
     * An XML checkValidSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CheckValidSncRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncRequestDocument.CheckValidSncRequest
    {
        
        public CheckValidSncRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CREATEDATA$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createData");
        private static final javax.xml.namespace.QName TPSTOMODIFY$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpsToModify");
        private static final javax.xml.namespace.QName CONSIDERRESOURCES$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "considerResources");
        
        
        /**
         * Gets the "createData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType getCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType)get_store().find_element_user(CREATEDATA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "createData" element
         */
        public boolean isSetCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CREATEDATA$0) != 0;
            }
        }
        
        /**
         * Sets the "createData" element
         */
        public void setCreateData(org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType createData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType)get_store().find_element_user(CREATEDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType)get_store().add_element_user(CREATEDATA$0);
                }
                target.set(createData);
            }
        }
        
        /**
         * Appends and returns a new empty "createData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType addNewCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType)get_store().add_element_user(CREATEDATA$0);
                return target;
            }
        }
        
        /**
         * Unsets the "createData" element
         */
        public void unsetCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CREATEDATA$0, 0);
            }
        }
        
        /**
         * Gets the "tpsToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType getTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(TPSTOMODIFY$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpsToModify" element
         */
        public boolean isSetTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPSTOMODIFY$2) != 0;
            }
        }
        
        /**
         * Sets the "tpsToModify" element
         */
        public void setTpsToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType tpsToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(TPSTOMODIFY$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(TPSTOMODIFY$2);
                }
                target.set(tpsToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpsToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType addNewTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(TPSTOMODIFY$2);
                return target;
            }
        }
        
        /**
         * Unsets the "tpsToModify" element
         */
        public void unsetTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPSTOMODIFY$2, 0);
            }
        }
        
        /**
         * Gets the "considerResources" element
         */
        public boolean getConsiderResources()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONSIDERRESOURCES$4, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "considerResources" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetConsiderResources()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CONSIDERRESOURCES$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "considerResources" element
         */
        public boolean isSetConsiderResources()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONSIDERRESOURCES$4) != 0;
            }
        }
        
        /**
         * Sets the "considerResources" element
         */
        public void setConsiderResources(boolean considerResources)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONSIDERRESOURCES$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONSIDERRESOURCES$4);
                }
                target.setBooleanValue(considerResources);
            }
        }
        
        /**
         * Sets (as xml) the "considerResources" element
         */
        public void xsetConsiderResources(org.apache.xmlbeans.XmlBoolean considerResources)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CONSIDERRESOURCES$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(CONSIDERRESOURCES$4);
                }
                target.set(considerResources);
            }
        }
        
        /**
         * Unsets the "considerResources" element
         */
        public void unsetConsiderResources()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONSIDERRESOURCES$4, 0);
            }
        }
    }
}
