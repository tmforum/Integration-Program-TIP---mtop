/*
 * An XML document type.
 * Localname: deleteSncResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one deleteSncResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class DeleteSncResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument
{
    
    public DeleteSncResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETESNCRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "deleteSncResponse");
    
    
    /**
     * Gets the "deleteSncResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse getDeleteSncResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse)get_store().find_element_user(DELETESNCRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteSncResponse" element
     */
    public void setDeleteSncResponse(org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse deleteSncResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse)get_store().find_element_user(DELETESNCRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse)get_store().add_element_user(DELETESNCRESPONSE$0);
            }
            target.set(deleteSncResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteSncResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse addNewDeleteSncResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse)get_store().add_element_user(DELETESNCRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML deleteSncResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class DeleteSncResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncResponseDocument.DeleteSncResponse
    {
        
        public DeleteSncResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
