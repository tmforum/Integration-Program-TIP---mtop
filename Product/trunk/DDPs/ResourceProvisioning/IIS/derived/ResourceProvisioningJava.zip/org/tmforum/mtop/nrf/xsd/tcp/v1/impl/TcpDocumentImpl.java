/*
 * An XML document type.
 * Localname: tcp
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tcp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tcp.v1.TcpDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tcp.v1.impl;
/**
 * A document containing one tcp(@http://www.tmforum.org/mtop/nrf/xsd/tcp/v1) element.
 *
 * This is a complex type.
 */
public class TcpDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tcp.v1.TcpDocument
{
    
    public TcpDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TCP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tcp/v1", "tcp");
    
    
    /**
     * Gets the "tcp" element
     */
    public org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType getTcp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType)get_store().find_element_user(TCP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tcp" element
     */
    public void setTcp(org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType tcp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType)get_store().find_element_user(TCP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType)get_store().add_element_user(TCP$0);
            }
            target.set(tcp);
        }
    }
    
    /**
     * Appends and returns a new empty "tcp" element
     */
    public org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType addNewTcp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tcp.v1.TcProfileType)get_store().add_element_user(TCP$0);
            return target;
        }
    }
}
