/*
 * An XML document type.
 * Localname: addRouteResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one addRouteResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class AddRouteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument
{
    
    public AddRouteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ADDROUTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "addRouteResponse");
    
    
    /**
     * Gets the "addRouteResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse getAddRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse)get_store().find_element_user(ADDROUTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "addRouteResponse" element
     */
    public void setAddRouteResponse(org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse addRouteResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse)get_store().find_element_user(ADDROUTERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse)get_store().add_element_user(ADDROUTERESPONSE$0);
            }
            target.set(addRouteResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "addRouteResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse addNewAddRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse)get_store().add_element_user(ADDROUTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML addRouteResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class AddRouteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.AddRouteResponseDocument.AddRouteResponse
    {
        
        public AddRouteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName THEROUTE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "theRoute");
        private static final javax.xml.namespace.QName ERRORREASON$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "errorReason");
        
        
        /**
         * Gets the "theRoute" element
         */
        public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType getTheRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
                target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().find_element_user(THEROUTE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "theRoute" element
         */
        public boolean isSetTheRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(THEROUTE$0) != 0;
            }
        }
        
        /**
         * Sets the "theRoute" element
         */
        public void setTheRoute(org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType theRoute)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
                target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().find_element_user(THEROUTE$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().add_element_user(THEROUTE$0);
                }
                target.set(theRoute);
            }
        }
        
        /**
         * Appends and returns a new empty "theRoute" element
         */
        public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType addNewTheRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
                target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().add_element_user(THEROUTE$0);
                return target;
            }
        }
        
        /**
         * Unsets the "theRoute" element
         */
        public void unsetTheRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(THEROUTE$0, 0);
            }
        }
        
        /**
         * Gets the "errorReason" element
         */
        public java.lang.String getErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "errorReason" element
         */
        public org.apache.xmlbeans.XmlString xgetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "errorReason" element
         */
        public boolean isSetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRORREASON$2) != 0;
            }
        }
        
        /**
         * Sets the "errorReason" element
         */
        public void setErrorReason(java.lang.String errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ERRORREASON$2);
                }
                target.setStringValue(errorReason);
            }
        }
        
        /**
         * Sets (as xml) the "errorReason" element
         */
        public void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$2);
                }
                target.set(errorReason);
            }
        }
        
        /**
         * Unsets the "errorReason" element
         */
        public void unsetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRORREASON$2, 0);
            }
        }
    }
}
