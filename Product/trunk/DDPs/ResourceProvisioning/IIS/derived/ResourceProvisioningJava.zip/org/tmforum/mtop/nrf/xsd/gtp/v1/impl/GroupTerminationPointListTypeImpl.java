/*
 * XML Type:  GroupTerminationPointListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/gtp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.gtp.v1.impl;
/**
 * An XML GroupTerminationPointListType(@http://www.tmforum.org/mtop/nrf/xsd/gtp/v1).
 *
 * This is a complex type.
 */
public class GroupTerminationPointListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointListType
{
    
    public GroupTerminationPointListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "gtp");
    
    
    /**
     * Gets a List of "gtp" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType> getGtpList()
    {
        final class GtpList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType>
        {
            public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType get(int i)
                { return GroupTerminationPointListTypeImpl.this.getGtpArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType set(int i, org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType o)
            {
                org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType old = GroupTerminationPointListTypeImpl.this.getGtpArray(i);
                GroupTerminationPointListTypeImpl.this.setGtpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType o)
                { GroupTerminationPointListTypeImpl.this.insertNewGtp(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType old = GroupTerminationPointListTypeImpl.this.getGtpArray(i);
                GroupTerminationPointListTypeImpl.this.removeGtp(i);
                return old;
            }
            
            public int size()
                { return GroupTerminationPointListTypeImpl.this.sizeOfGtpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new GtpList();
        }
    }
    
    /**
     * Gets array of all "gtp" elements
     */
    public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType[] getGtpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(GTP$0, targetList);
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType[] result = new org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "gtp" element
     */
    public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType getGtpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().find_element_user(GTP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "gtp" element
     */
    public int sizeOfGtpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GTP$0);
        }
    }
    
    /**
     * Sets array of all "gtp" element
     */
    public void setGtpArray(org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType[] gtpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(gtpArray, GTP$0);
        }
    }
    
    /**
     * Sets ith "gtp" element
     */
    public void setGtpArray(int i, org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType gtp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().find_element_user(GTP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(gtp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "gtp" element
     */
    public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType insertNewGtp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().insert_element_user(GTP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "gtp" element
     */
    public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType addNewGtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().add_element_user(GTP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "gtp" element
     */
    public void removeGtp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GTP$0, i);
        }
    }
}
