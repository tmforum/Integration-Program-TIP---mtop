/*
 * XML Type:  PhysicalTerminationPointListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ptp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ptp.v1.impl;
/**
 * An XML PhysicalTerminationPointListType(@http://www.tmforum.org/mtop/nrf/xsd/ptp/v1).
 *
 * This is a complex type.
 */
public class PhysicalTerminationPointListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointListType
{
    
    public PhysicalTerminationPointListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "ptp");
    
    
    /**
     * Gets a List of "ptp" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType> getPtpList()
    {
        final class PtpList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType>
        {
            public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType get(int i)
                { return PhysicalTerminationPointListTypeImpl.this.getPtpArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType set(int i, org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType o)
            {
                org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType old = PhysicalTerminationPointListTypeImpl.this.getPtpArray(i);
                PhysicalTerminationPointListTypeImpl.this.setPtpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType o)
                { PhysicalTerminationPointListTypeImpl.this.insertNewPtp(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType old = PhysicalTerminationPointListTypeImpl.this.getPtpArray(i);
                PhysicalTerminationPointListTypeImpl.this.removePtp(i);
                return old;
            }
            
            public int size()
                { return PhysicalTerminationPointListTypeImpl.this.sizeOfPtpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PtpList();
        }
    }
    
    /**
     * Gets array of all "ptp" elements
     */
    public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType[] getPtpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PTP$0, targetList);
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType[] result = new org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ptp" element
     */
    public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType getPtpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().find_element_user(PTP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "ptp" element
     */
    public int sizeOfPtpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PTP$0);
        }
    }
    
    /**
     * Sets array of all "ptp" element
     */
    public void setPtpArray(org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType[] ptpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(ptpArray, PTP$0);
        }
    }
    
    /**
     * Sets ith "ptp" element
     */
    public void setPtpArray(int i, org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType ptp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().find_element_user(PTP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(ptp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ptp" element
     */
    public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType insertNewPtp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().insert_element_user(PTP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ptp" element
     */
    public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType addNewPtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().add_element_user(PTP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ptp" element
     */
    public void removePtp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PTP$0, i);
        }
    }
}
