/*
 * XML Type:  CommonResourceModifyDataType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/crmd/v1
 * Java type: org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.crmd.v1.impl;
/**
 * An XML CommonResourceModifyDataType(@http://www.tmforum.org/mtop/nrb/xsd/crmd/v1).
 *
 * This is a complex type.
 */
public class CommonResourceModifyDataTypeImpl extends org.tmforum.mtop.fmw.xsd.comd.v1.impl.CommonObjectModifyDataTypeImpl implements org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType
{
    
    public CommonResourceModifyDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NETWORKACCESSDOMAIN$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/crmd/v1", "networkAccessDomain");
    
    
    /**
     * Gets the "networkAccessDomain" element
     */
    public java.lang.String getNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKACCESSDOMAIN$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "networkAccessDomain" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType xgetNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "networkAccessDomain" element
     */
    public boolean isNilNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "networkAccessDomain" element
     */
    public boolean isSetNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETWORKACCESSDOMAIN$0) != 0;
        }
    }
    
    /**
     * Sets the "networkAccessDomain" element
     */
    public void setNetworkAccessDomain(java.lang.String networkAccessDomain)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKACCESSDOMAIN$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKACCESSDOMAIN$0);
            }
            target.setStringValue(networkAccessDomain);
        }
    }
    
    /**
     * Sets (as xml) the "networkAccessDomain" element
     */
    public void xsetNetworkAccessDomain(org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType networkAccessDomain)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().add_element_user(NETWORKACCESSDOMAIN$0);
            }
            target.set(networkAccessDomain);
        }
    }
    
    /**
     * Nils the "networkAccessDomain" element
     */
    public void setNilNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().add_element_user(NETWORKACCESSDOMAIN$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "networkAccessDomain" element
     */
    public void unsetNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETWORKACCESSDOMAIN$0, 0);
        }
    }
}
