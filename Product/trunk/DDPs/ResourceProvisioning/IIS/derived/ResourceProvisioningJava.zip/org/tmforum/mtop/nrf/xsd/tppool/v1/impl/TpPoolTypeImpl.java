/*
 * XML Type:  TpPoolType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tppool/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tppool.v1.impl;
/**
 * An XML TpPoolType(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
 *
 * This is a complex type.
 */
public class TpPoolTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType
{
    
    public TpPoolTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NUMBEROFMEMBERS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "numberOfMembers");
    private static final javax.xml.namespace.QName NUMBEROFIDLEMEMBERS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "numberOfIdleMembers");
    private static final javax.xml.namespace.QName DESCRIPTIONOFUSE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "descriptionOfUse");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMS$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "transmissionParams");
    private static final javax.xml.namespace.QName CONTAINEDMEMBERLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "containedMemberList");
    private static final javax.xml.namespace.QName MEMBERCONTAININGMELIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "memberContainingMeList");
    private static final javax.xml.namespace.QName MEMBERCONTAININGTPLIST$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "memberContainingTpList");
    
    
    /**
     * Gets the "numberOfMembers" element
     */
    public long getNumberOfMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBEROFMEMBERS$0, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "numberOfMembers" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType xgetNumberOfMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType)get_store().find_element_user(NUMBEROFMEMBERS$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "numberOfMembers" element
     */
    public boolean isNilNumberOfMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType)get_store().find_element_user(NUMBEROFMEMBERS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "numberOfMembers" element
     */
    public boolean isSetNumberOfMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMBEROFMEMBERS$0) != 0;
        }
    }
    
    /**
     * Sets the "numberOfMembers" element
     */
    public void setNumberOfMembers(long numberOfMembers)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBEROFMEMBERS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMBEROFMEMBERS$0);
            }
            target.setLongValue(numberOfMembers);
        }
    }
    
    /**
     * Sets (as xml) the "numberOfMembers" element
     */
    public void xsetNumberOfMembers(org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType numberOfMembers)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType)get_store().find_element_user(NUMBEROFMEMBERS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType)get_store().add_element_user(NUMBEROFMEMBERS$0);
            }
            target.set(numberOfMembers);
        }
    }
    
    /**
     * Nils the "numberOfMembers" element
     */
    public void setNilNumberOfMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType)get_store().find_element_user(NUMBEROFMEMBERS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfMembersType)get_store().add_element_user(NUMBEROFMEMBERS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "numberOfMembers" element
     */
    public void unsetNumberOfMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMBEROFMEMBERS$0, 0);
        }
    }
    
    /**
     * Gets the "numberOfIdleMembers" element
     */
    public long getNumberOfIdleMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBEROFIDLEMEMBERS$2, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "numberOfIdleMembers" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType xgetNumberOfIdleMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType)get_store().find_element_user(NUMBEROFIDLEMEMBERS$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "numberOfIdleMembers" element
     */
    public boolean isNilNumberOfIdleMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType)get_store().find_element_user(NUMBEROFIDLEMEMBERS$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "numberOfIdleMembers" element
     */
    public boolean isSetNumberOfIdleMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NUMBEROFIDLEMEMBERS$2) != 0;
        }
    }
    
    /**
     * Sets the "numberOfIdleMembers" element
     */
    public void setNumberOfIdleMembers(long numberOfIdleMembers)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NUMBEROFIDLEMEMBERS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NUMBEROFIDLEMEMBERS$2);
            }
            target.setLongValue(numberOfIdleMembers);
        }
    }
    
    /**
     * Sets (as xml) the "numberOfIdleMembers" element
     */
    public void xsetNumberOfIdleMembers(org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType numberOfIdleMembers)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType)get_store().find_element_user(NUMBEROFIDLEMEMBERS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType)get_store().add_element_user(NUMBEROFIDLEMEMBERS$2);
            }
            target.set(numberOfIdleMembers);
        }
    }
    
    /**
     * Nils the "numberOfIdleMembers" element
     */
    public void setNilNumberOfIdleMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType)get_store().find_element_user(NUMBEROFIDLEMEMBERS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.NumberOfIdleMembersType)get_store().add_element_user(NUMBEROFIDLEMEMBERS$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "numberOfIdleMembers" element
     */
    public void unsetNumberOfIdleMembers()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NUMBEROFIDLEMEMBERS$2, 0);
        }
    }
    
    /**
     * Gets the "descriptionOfUse" element
     */
    public java.lang.String getDescriptionOfUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTIONOFUSE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "descriptionOfUse" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType xgetDescriptionOfUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType)get_store().find_element_user(DESCRIPTIONOFUSE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "descriptionOfUse" element
     */
    public boolean isNilDescriptionOfUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType)get_store().find_element_user(DESCRIPTIONOFUSE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "descriptionOfUse" element
     */
    public boolean isSetDescriptionOfUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DESCRIPTIONOFUSE$4) != 0;
        }
    }
    
    /**
     * Sets the "descriptionOfUse" element
     */
    public void setDescriptionOfUse(java.lang.String descriptionOfUse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESCRIPTIONOFUSE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESCRIPTIONOFUSE$4);
            }
            target.setStringValue(descriptionOfUse);
        }
    }
    
    /**
     * Sets (as xml) the "descriptionOfUse" element
     */
    public void xsetDescriptionOfUse(org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType descriptionOfUse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType)get_store().find_element_user(DESCRIPTIONOFUSE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType)get_store().add_element_user(DESCRIPTIONOFUSE$4);
            }
            target.set(descriptionOfUse);
        }
    }
    
    /**
     * Nils the "descriptionOfUse" element
     */
    public void setNilDescriptionOfUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType)get_store().find_element_user(DESCRIPTIONOFUSE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.DescriptionOfUseType)get_store().add_element_user(DESCRIPTIONOFUSE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "descriptionOfUse" element
     */
    public void unsetDescriptionOfUse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DESCRIPTIONOFUSE$4, 0);
        }
    }
    
    /**
     * Gets the "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParams" element
     */
    public boolean isNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParams" element
     */
    public boolean isSetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMS$6) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParams" element
     */
    public void setTransmissionParams(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParams)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$6);
            }
            target.set(transmissionParams);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$6);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParams" element
     */
    public void setNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParams" element
     */
    public void unsetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMS$6, 0);
        }
    }
    
    /**
     * Gets the "containedMemberList" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList getContainedMemberList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList)get_store().find_element_user(CONTAINEDMEMBERLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "containedMemberList" element
     */
    public boolean isNilContainedMemberList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList)get_store().find_element_user(CONTAINEDMEMBERLIST$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "containedMemberList" element
     */
    public boolean isSetContainedMemberList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTAINEDMEMBERLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "containedMemberList" element
     */
    public void setContainedMemberList(org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList containedMemberList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList)get_store().find_element_user(CONTAINEDMEMBERLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList)get_store().add_element_user(CONTAINEDMEMBERLIST$8);
            }
            target.set(containedMemberList);
        }
    }
    
    /**
     * Appends and returns a new empty "containedMemberList" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList addNewContainedMemberList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList)get_store().add_element_user(CONTAINEDMEMBERLIST$8);
            return target;
        }
    }
    
    /**
     * Nils the "containedMemberList" element
     */
    public void setNilContainedMemberList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList)get_store().find_element_user(CONTAINEDMEMBERLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList)get_store().add_element_user(CONTAINEDMEMBERLIST$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "containedMemberList" element
     */
    public void unsetContainedMemberList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTAINEDMEMBERLIST$8, 0);
        }
    }
    
    /**
     * Gets the "memberContainingMeList" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList getMemberContainingMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList)get_store().find_element_user(MEMBERCONTAININGMELIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "memberContainingMeList" element
     */
    public boolean isNilMemberContainingMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList)get_store().find_element_user(MEMBERCONTAININGMELIST$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "memberContainingMeList" element
     */
    public boolean isSetMemberContainingMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MEMBERCONTAININGMELIST$10) != 0;
        }
    }
    
    /**
     * Sets the "memberContainingMeList" element
     */
    public void setMemberContainingMeList(org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList memberContainingMeList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList)get_store().find_element_user(MEMBERCONTAININGMELIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList)get_store().add_element_user(MEMBERCONTAININGMELIST$10);
            }
            target.set(memberContainingMeList);
        }
    }
    
    /**
     * Appends and returns a new empty "memberContainingMeList" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList addNewMemberContainingMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList)get_store().add_element_user(MEMBERCONTAININGMELIST$10);
            return target;
        }
    }
    
    /**
     * Nils the "memberContainingMeList" element
     */
    public void setNilMemberContainingMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList)get_store().find_element_user(MEMBERCONTAININGMELIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList)get_store().add_element_user(MEMBERCONTAININGMELIST$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "memberContainingMeList" element
     */
    public void unsetMemberContainingMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MEMBERCONTAININGMELIST$10, 0);
        }
    }
    
    /**
     * Gets the "memberContainingTpList" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList getMemberContainingTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList)get_store().find_element_user(MEMBERCONTAININGTPLIST$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "memberContainingTpList" element
     */
    public boolean isNilMemberContainingTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList)get_store().find_element_user(MEMBERCONTAININGTPLIST$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "memberContainingTpList" element
     */
    public boolean isSetMemberContainingTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MEMBERCONTAININGTPLIST$12) != 0;
        }
    }
    
    /**
     * Sets the "memberContainingTpList" element
     */
    public void setMemberContainingTpList(org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList memberContainingTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList)get_store().find_element_user(MEMBERCONTAININGTPLIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList)get_store().add_element_user(MEMBERCONTAININGTPLIST$12);
            }
            target.set(memberContainingTpList);
        }
    }
    
    /**
     * Appends and returns a new empty "memberContainingTpList" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList addNewMemberContainingTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList)get_store().add_element_user(MEMBERCONTAININGTPLIST$12);
            return target;
        }
    }
    
    /**
     * Nils the "memberContainingTpList" element
     */
    public void setNilMemberContainingTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList)get_store().find_element_user(MEMBERCONTAININGTPLIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList)get_store().add_element_user(MEMBERCONTAININGTPLIST$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "memberContainingTpList" element
     */
    public void unsetMemberContainingTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MEMBERCONTAININGTPLIST$12, 0);
        }
    }
    /**
     * An XML containedMemberList(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
     *
     * This is a complex type.
     */
    public static class ContainedMemberListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.ContainedMemberList
    {
        
        public ContainedMemberListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONTAINEDMEMBER$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "containedMember");
        
        
        /**
         * Gets a List of "containedMember" elements
         */
        public java.util.List<java.lang.String> getContainedMemberList()
        {
            final class ContainedMemberList extends java.util.AbstractList<java.lang.String>
            {
                public java.lang.String get(int i)
                    { return ContainedMemberListImpl.this.getContainedMemberArray(i); }
                
                public java.lang.String set(int i, java.lang.String o)
                {
                    java.lang.String old = ContainedMemberListImpl.this.getContainedMemberArray(i);
                    ContainedMemberListImpl.this.setContainedMemberArray(i, o);
                    return old;
                }
                
                public void add(int i, java.lang.String o)
                    { ContainedMemberListImpl.this.insertContainedMember(i, o); }
                
                public java.lang.String remove(int i)
                {
                    java.lang.String old = ContainedMemberListImpl.this.getContainedMemberArray(i);
                    ContainedMemberListImpl.this.removeContainedMember(i);
                    return old;
                }
                
                public int size()
                    { return ContainedMemberListImpl.this.sizeOfContainedMemberArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ContainedMemberList();
            }
        }
        
        /**
         * Gets array of all "containedMember" elements
         */
        public java.lang.String[] getContainedMemberArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CONTAINEDMEMBER$0, targetList);
                java.lang.String[] result = new java.lang.String[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
                return result;
            }
        }
        
        /**
         * Gets ith "containedMember" element
         */
        public java.lang.String getContainedMemberArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTAINEDMEMBER$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "containedMember" elements
         */
        public java.util.List<org.apache.xmlbeans.XmlString> xgetContainedMemberList()
        {
            final class ContainedMemberList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
            {
                public org.apache.xmlbeans.XmlString get(int i)
                    { return ContainedMemberListImpl.this.xgetContainedMemberArray(i); }
                
                public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
                {
                    org.apache.xmlbeans.XmlString old = ContainedMemberListImpl.this.xgetContainedMemberArray(i);
                    ContainedMemberListImpl.this.xsetContainedMemberArray(i, o);
                    return old;
                }
                
                public void add(int i, org.apache.xmlbeans.XmlString o)
                    { ContainedMemberListImpl.this.insertNewContainedMember(i).set(o); }
                
                public org.apache.xmlbeans.XmlString remove(int i)
                {
                    org.apache.xmlbeans.XmlString old = ContainedMemberListImpl.this.xgetContainedMemberArray(i);
                    ContainedMemberListImpl.this.removeContainedMember(i);
                    return old;
                }
                
                public int size()
                    { return ContainedMemberListImpl.this.sizeOfContainedMemberArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ContainedMemberList();
            }
        }
        
        /**
         * Gets (as xml) array of all "containedMember" elements
         */
        public org.apache.xmlbeans.XmlString[] xgetContainedMemberArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CONTAINEDMEMBER$0, targetList);
                org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "containedMember" element
         */
        public org.apache.xmlbeans.XmlString xgetContainedMemberArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTAINEDMEMBER$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.apache.xmlbeans.XmlString)target;
            }
        }
        
        /**
         * Returns number of "containedMember" element
         */
        public int sizeOfContainedMemberArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONTAINEDMEMBER$0);
            }
        }
        
        /**
         * Sets array of all "containedMember" element
         */
        public void setContainedMemberArray(java.lang.String[] containedMemberArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(containedMemberArray, CONTAINEDMEMBER$0);
            }
        }
        
        /**
         * Sets ith "containedMember" element
         */
        public void setContainedMemberArray(int i, java.lang.String containedMember)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTAINEDMEMBER$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setStringValue(containedMember);
            }
        }
        
        /**
         * Sets (as xml) array of all "containedMember" element
         */
        public void xsetContainedMemberArray(org.apache.xmlbeans.XmlString[]containedMemberArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(containedMemberArray, CONTAINEDMEMBER$0);
            }
        }
        
        /**
         * Sets (as xml) ith "containedMember" element
         */
        public void xsetContainedMemberArray(int i, org.apache.xmlbeans.XmlString containedMember)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONTAINEDMEMBER$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(containedMember);
            }
        }
        
        /**
         * Inserts the value as the ith "containedMember" element
         */
        public void insertContainedMember(int i, java.lang.String containedMember)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(CONTAINEDMEMBER$0, i);
                target.setStringValue(containedMember);
            }
        }
        
        /**
         * Appends the value as the last "containedMember" element
         */
        public void addContainedMember(java.lang.String containedMember)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONTAINEDMEMBER$0);
                target.setStringValue(containedMember);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "containedMember" element
         */
        public org.apache.xmlbeans.XmlString insertNewContainedMember(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(CONTAINEDMEMBER$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "containedMember" element
         */
        public org.apache.xmlbeans.XmlString addNewContainedMember()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONTAINEDMEMBER$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "containedMember" element
         */
        public void removeContainedMember(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONTAINEDMEMBER$0, i);
            }
        }
    }
    /**
     * An XML memberContainingMeList(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
     *
     * This is a complex type.
     */
    public static class MemberContainingMeListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingMeList
    {
        
        public MemberContainingMeListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MEMBERCONTAININGME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "memberContainingMe");
        
        
        /**
         * Gets a List of "memberContainingMe" elements
         */
        public java.util.List<java.lang.String> getMemberContainingMeList()
        {
            final class MemberContainingMeList extends java.util.AbstractList<java.lang.String>
            {
                public java.lang.String get(int i)
                    { return MemberContainingMeListImpl.this.getMemberContainingMeArray(i); }
                
                public java.lang.String set(int i, java.lang.String o)
                {
                    java.lang.String old = MemberContainingMeListImpl.this.getMemberContainingMeArray(i);
                    MemberContainingMeListImpl.this.setMemberContainingMeArray(i, o);
                    return old;
                }
                
                public void add(int i, java.lang.String o)
                    { MemberContainingMeListImpl.this.insertMemberContainingMe(i, o); }
                
                public java.lang.String remove(int i)
                {
                    java.lang.String old = MemberContainingMeListImpl.this.getMemberContainingMeArray(i);
                    MemberContainingMeListImpl.this.removeMemberContainingMe(i);
                    return old;
                }
                
                public int size()
                    { return MemberContainingMeListImpl.this.sizeOfMemberContainingMeArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MemberContainingMeList();
            }
        }
        
        /**
         * Gets array of all "memberContainingMe" elements
         */
        public java.lang.String[] getMemberContainingMeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MEMBERCONTAININGME$0, targetList);
                java.lang.String[] result = new java.lang.String[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
                return result;
            }
        }
        
        /**
         * Gets ith "memberContainingMe" element
         */
        public java.lang.String getMemberContainingMeArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MEMBERCONTAININGME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "memberContainingMe" elements
         */
        public java.util.List<org.apache.xmlbeans.XmlString> xgetMemberContainingMeList()
        {
            final class MemberContainingMeList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
            {
                public org.apache.xmlbeans.XmlString get(int i)
                    { return MemberContainingMeListImpl.this.xgetMemberContainingMeArray(i); }
                
                public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
                {
                    org.apache.xmlbeans.XmlString old = MemberContainingMeListImpl.this.xgetMemberContainingMeArray(i);
                    MemberContainingMeListImpl.this.xsetMemberContainingMeArray(i, o);
                    return old;
                }
                
                public void add(int i, org.apache.xmlbeans.XmlString o)
                    { MemberContainingMeListImpl.this.insertNewMemberContainingMe(i).set(o); }
                
                public org.apache.xmlbeans.XmlString remove(int i)
                {
                    org.apache.xmlbeans.XmlString old = MemberContainingMeListImpl.this.xgetMemberContainingMeArray(i);
                    MemberContainingMeListImpl.this.removeMemberContainingMe(i);
                    return old;
                }
                
                public int size()
                    { return MemberContainingMeListImpl.this.sizeOfMemberContainingMeArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MemberContainingMeList();
            }
        }
        
        /**
         * Gets (as xml) array of all "memberContainingMe" elements
         */
        public org.apache.xmlbeans.XmlString[] xgetMemberContainingMeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MEMBERCONTAININGME$0, targetList);
                org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "memberContainingMe" element
         */
        public org.apache.xmlbeans.XmlString xgetMemberContainingMeArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEMBERCONTAININGME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.apache.xmlbeans.XmlString)target;
            }
        }
        
        /**
         * Returns number of "memberContainingMe" element
         */
        public int sizeOfMemberContainingMeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MEMBERCONTAININGME$0);
            }
        }
        
        /**
         * Sets array of all "memberContainingMe" element
         */
        public void setMemberContainingMeArray(java.lang.String[] memberContainingMeArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(memberContainingMeArray, MEMBERCONTAININGME$0);
            }
        }
        
        /**
         * Sets ith "memberContainingMe" element
         */
        public void setMemberContainingMeArray(int i, java.lang.String memberContainingMe)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MEMBERCONTAININGME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setStringValue(memberContainingMe);
            }
        }
        
        /**
         * Sets (as xml) array of all "memberContainingMe" element
         */
        public void xsetMemberContainingMeArray(org.apache.xmlbeans.XmlString[]memberContainingMeArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(memberContainingMeArray, MEMBERCONTAININGME$0);
            }
        }
        
        /**
         * Sets (as xml) ith "memberContainingMe" element
         */
        public void xsetMemberContainingMeArray(int i, org.apache.xmlbeans.XmlString memberContainingMe)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEMBERCONTAININGME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(memberContainingMe);
            }
        }
        
        /**
         * Inserts the value as the ith "memberContainingMe" element
         */
        public void insertMemberContainingMe(int i, java.lang.String memberContainingMe)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(MEMBERCONTAININGME$0, i);
                target.setStringValue(memberContainingMe);
            }
        }
        
        /**
         * Appends the value as the last "memberContainingMe" element
         */
        public void addMemberContainingMe(java.lang.String memberContainingMe)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MEMBERCONTAININGME$0);
                target.setStringValue(memberContainingMe);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "memberContainingMe" element
         */
        public org.apache.xmlbeans.XmlString insertNewMemberContainingMe(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(MEMBERCONTAININGME$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "memberContainingMe" element
         */
        public org.apache.xmlbeans.XmlString addNewMemberContainingMe()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MEMBERCONTAININGME$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "memberContainingMe" element
         */
        public void removeMemberContainingMe(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MEMBERCONTAININGME$0, i);
            }
        }
    }
    /**
     * An XML memberContainingTpList(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
     *
     * This is a complex type.
     */
    public static class MemberContainingTpListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType.MemberContainingTpList
    {
        
        public MemberContainingTpListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MEMBERCONTAININGTP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "memberContainingTp");
        
        
        /**
         * Gets a List of "memberContainingTp" elements
         */
        public java.util.List<java.lang.String> getMemberContainingTpList()
        {
            final class MemberContainingTpList extends java.util.AbstractList<java.lang.String>
            {
                public java.lang.String get(int i)
                    { return MemberContainingTpListImpl.this.getMemberContainingTpArray(i); }
                
                public java.lang.String set(int i, java.lang.String o)
                {
                    java.lang.String old = MemberContainingTpListImpl.this.getMemberContainingTpArray(i);
                    MemberContainingTpListImpl.this.setMemberContainingTpArray(i, o);
                    return old;
                }
                
                public void add(int i, java.lang.String o)
                    { MemberContainingTpListImpl.this.insertMemberContainingTp(i, o); }
                
                public java.lang.String remove(int i)
                {
                    java.lang.String old = MemberContainingTpListImpl.this.getMemberContainingTpArray(i);
                    MemberContainingTpListImpl.this.removeMemberContainingTp(i);
                    return old;
                }
                
                public int size()
                    { return MemberContainingTpListImpl.this.sizeOfMemberContainingTpArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MemberContainingTpList();
            }
        }
        
        /**
         * Gets array of all "memberContainingTp" elements
         */
        public java.lang.String[] getMemberContainingTpArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MEMBERCONTAININGTP$0, targetList);
                java.lang.String[] result = new java.lang.String[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
                return result;
            }
        }
        
        /**
         * Gets ith "memberContainingTp" element
         */
        public java.lang.String getMemberContainingTpArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MEMBERCONTAININGTP$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "memberContainingTp" elements
         */
        public java.util.List<org.apache.xmlbeans.XmlString> xgetMemberContainingTpList()
        {
            final class MemberContainingTpList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
            {
                public org.apache.xmlbeans.XmlString get(int i)
                    { return MemberContainingTpListImpl.this.xgetMemberContainingTpArray(i); }
                
                public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
                {
                    org.apache.xmlbeans.XmlString old = MemberContainingTpListImpl.this.xgetMemberContainingTpArray(i);
                    MemberContainingTpListImpl.this.xsetMemberContainingTpArray(i, o);
                    return old;
                }
                
                public void add(int i, org.apache.xmlbeans.XmlString o)
                    { MemberContainingTpListImpl.this.insertNewMemberContainingTp(i).set(o); }
                
                public org.apache.xmlbeans.XmlString remove(int i)
                {
                    org.apache.xmlbeans.XmlString old = MemberContainingTpListImpl.this.xgetMemberContainingTpArray(i);
                    MemberContainingTpListImpl.this.removeMemberContainingTp(i);
                    return old;
                }
                
                public int size()
                    { return MemberContainingTpListImpl.this.sizeOfMemberContainingTpArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MemberContainingTpList();
            }
        }
        
        /**
         * Gets (as xml) array of all "memberContainingTp" elements
         */
        public org.apache.xmlbeans.XmlString[] xgetMemberContainingTpArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MEMBERCONTAININGTP$0, targetList);
                org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "memberContainingTp" element
         */
        public org.apache.xmlbeans.XmlString xgetMemberContainingTpArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEMBERCONTAININGTP$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.apache.xmlbeans.XmlString)target;
            }
        }
        
        /**
         * Returns number of "memberContainingTp" element
         */
        public int sizeOfMemberContainingTpArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MEMBERCONTAININGTP$0);
            }
        }
        
        /**
         * Sets array of all "memberContainingTp" element
         */
        public void setMemberContainingTpArray(java.lang.String[] memberContainingTpArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(memberContainingTpArray, MEMBERCONTAININGTP$0);
            }
        }
        
        /**
         * Sets ith "memberContainingTp" element
         */
        public void setMemberContainingTpArray(int i, java.lang.String memberContainingTp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MEMBERCONTAININGTP$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setStringValue(memberContainingTp);
            }
        }
        
        /**
         * Sets (as xml) array of all "memberContainingTp" element
         */
        public void xsetMemberContainingTpArray(org.apache.xmlbeans.XmlString[]memberContainingTpArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(memberContainingTpArray, MEMBERCONTAININGTP$0);
            }
        }
        
        /**
         * Sets (as xml) ith "memberContainingTp" element
         */
        public void xsetMemberContainingTpArray(int i, org.apache.xmlbeans.XmlString memberContainingTp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEMBERCONTAININGTP$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(memberContainingTp);
            }
        }
        
        /**
         * Inserts the value as the ith "memberContainingTp" element
         */
        public void insertMemberContainingTp(int i, java.lang.String memberContainingTp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(MEMBERCONTAININGTP$0, i);
                target.setStringValue(memberContainingTp);
            }
        }
        
        /**
         * Appends the value as the last "memberContainingTp" element
         */
        public void addMemberContainingTp(java.lang.String memberContainingTp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MEMBERCONTAININGTP$0);
                target.setStringValue(memberContainingTp);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "memberContainingTp" element
         */
        public org.apache.xmlbeans.XmlString insertNewMemberContainingTp(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(MEMBERCONTAININGTP$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "memberContainingTp" element
         */
        public org.apache.xmlbeans.XmlString addNewMemberContainingTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MEMBERCONTAININGTP$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "memberContainingTp" element
         */
        public void removeMemberContainingTp(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MEMBERCONTAININGTP$0, i);
            }
        }
    }
}
