/*
 * An XML document type.
 * Localname: mlsn
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mlsn.v1.MlsnDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mlsn.v1.impl;
/**
 * A document containing one mlsn(@http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1) element.
 *
 * This is a complex type.
 */
public class MlsnDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.mlsn.v1.MlsnDocument
{
    
    public MlsnDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MLSN$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "mlsn");
    
    
    /**
     * Gets the "mlsn" element
     */
    public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType getMlsn()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().find_element_user(MLSN$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "mlsn" element
     */
    public void setMlsn(org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType mlsn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().find_element_user(MLSN$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().add_element_user(MLSN$0);
            }
            target.set(mlsn);
        }
    }
    
    /**
     * Appends and returns a new empty "mlsn" element
     */
    public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType addNewMlsn()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().add_element_user(MLSN$0);
            return target;
        }
    }
}
