/*
 * XML Type:  TerminationPointRoleInSubnetworkConnectionType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/com/v1
 * Java type: org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.com.v1.impl;
/**
 * An XML TerminationPointRoleInSubnetworkConnectionType(@http://www.tmforum.org/mtop/nrf/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.
 */
public class TerminationPointRoleInSubnetworkConnectionTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType
{
    
    public TerminationPointRoleInSubnetworkConnectionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TerminationPointRoleInSubnetworkConnectionTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
