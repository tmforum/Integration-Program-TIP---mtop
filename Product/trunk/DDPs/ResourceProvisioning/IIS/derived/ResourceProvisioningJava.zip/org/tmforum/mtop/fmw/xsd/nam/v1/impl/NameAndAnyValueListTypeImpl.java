/*
 * XML Type:  NameAndAnyValueListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/nam/v1
 * Java type: org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.nam.v1.impl;
/**
 * An XML NameAndAnyValueListType(@http://www.tmforum.org/mtop/fmw/xsd/nam/v1).
 *
 * This is a complex type.
 */
public class NameAndAnyValueListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType
{
    
    public NameAndAnyValueListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NV$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "nv");
    
    
    /**
     * Gets a List of "nv" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType> getNvList()
    {
        final class NvList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType get(int i)
                { return NameAndAnyValueListTypeImpl.this.getNvArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType old = NameAndAnyValueListTypeImpl.this.getNvArray(i);
                NameAndAnyValueListTypeImpl.this.setNvArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType o)
                { NameAndAnyValueListTypeImpl.this.insertNewNv(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType old = NameAndAnyValueListTypeImpl.this.getNvArray(i);
                NameAndAnyValueListTypeImpl.this.removeNv(i);
                return old;
            }
            
            public int size()
                { return NameAndAnyValueListTypeImpl.this.sizeOfNvArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new NvList();
        }
    }
    
    /**
     * Gets array of all "nv" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType[] getNvArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(NV$0, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "nv" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType getNvArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType)get_store().find_element_user(NV$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "nv" element
     */
    public int sizeOfNvArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NV$0);
        }
    }
    
    /**
     * Sets array of all "nv" element
     */
    public void setNvArray(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType[] nvArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(nvArray, NV$0);
        }
    }
    
    /**
     * Sets ith "nv" element
     */
    public void setNvArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType nv)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType)get_store().find_element_user(NV$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(nv);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "nv" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType insertNewNv(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType)get_store().insert_element_user(NV$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "nv" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType addNewNv()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueType)get_store().add_element_user(NV$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "nv" element
     */
    public void removeNv(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NV$0, i);
        }
    }
}
