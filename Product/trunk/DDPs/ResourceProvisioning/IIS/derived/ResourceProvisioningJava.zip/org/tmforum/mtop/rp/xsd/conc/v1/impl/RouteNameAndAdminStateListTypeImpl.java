/*
 * XML Type:  RouteNameAndAdminStateListType
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * An XML RouteNameAndAdminStateListType(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
 *
 * This is a complex type.
 */
public class RouteNameAndAdminStateListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType
{
    
    public RouteNameAndAdminStateListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ITEM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "item");
    
    
    /**
     * Gets a List of "item" elements
     */
    public java.util.List<org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType> getItemList()
    {
        final class ItemList extends java.util.AbstractList<org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType>
        {
            public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType get(int i)
                { return RouteNameAndAdminStateListTypeImpl.this.getItemArray(i); }
            
            public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType set(int i, org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType o)
            {
                org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType old = RouteNameAndAdminStateListTypeImpl.this.getItemArray(i);
                RouteNameAndAdminStateListTypeImpl.this.setItemArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType o)
                { RouteNameAndAdminStateListTypeImpl.this.insertNewItem(i).set(o); }
            
            public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType remove(int i)
            {
                org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType old = RouteNameAndAdminStateListTypeImpl.this.getItemArray(i);
                RouteNameAndAdminStateListTypeImpl.this.removeItem(i);
                return old;
            }
            
            public int size()
                { return RouteNameAndAdminStateListTypeImpl.this.sizeOfItemArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ItemList();
        }
    }
    
    /**
     * Gets array of all "item" elements
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType[] getItemArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ITEM$0, targetList);
            org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType[] result = new org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "item" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType getItemArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType)get_store().find_element_user(ITEM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "item" element
     */
    public int sizeOfItemArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ITEM$0);
        }
    }
    
    /**
     * Sets array of all "item" element
     */
    public void setItemArray(org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType[] itemArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(itemArray, ITEM$0);
        }
    }
    
    /**
     * Sets ith "item" element
     */
    public void setItemArray(int i, org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType item)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType)get_store().find_element_user(ITEM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(item);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "item" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType insertNewItem(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType)get_store().insert_element_user(ITEM$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "item" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType addNewItem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType)get_store().add_element_user(ITEM$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "item" element
     */
    public void removeItem(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ITEM$0, i);
        }
    }
}
