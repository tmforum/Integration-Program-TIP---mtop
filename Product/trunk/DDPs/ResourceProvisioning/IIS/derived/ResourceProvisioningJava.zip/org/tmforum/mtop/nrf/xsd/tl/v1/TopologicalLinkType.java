/*
 * XML Type:  TopologicalLinkType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tl/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tl.v1;


/**
 * An XML TopologicalLinkType(@http://www.tmforum.org/mtop/nrf/xsd/tl/v1).
 *
 * This is a complex type.
 */
public interface TopologicalLinkType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TopologicalLinkType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFA029CF23A6AA97F9ACEA74311DBFDC2").resolveHandle("topologicallinktype5ccctype");
    
    /**
     * Gets the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection();
    
    /**
     * Gets (as xml) the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection();
    
    /**
     * Tests for nil "direction" element
     */
    boolean isNilDirection();
    
    /**
     * True if has "direction" element
     */
    boolean isSetDirection();
    
    /**
     * Sets the "direction" element
     */
    void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction);
    
    /**
     * Sets (as xml) the "direction" element
     */
    void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction);
    
    /**
     * Nils the "direction" element
     */
    void setNilDirection();
    
    /**
     * Unsets the "direction" element
     */
    void unsetDirection();
    
    /**
     * Gets the "rate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getRate();
    
    /**
     * Tests for nil "rate" element
     */
    boolean isNilRate();
    
    /**
     * True if has "rate" element
     */
    boolean isSetRate();
    
    /**
     * Sets the "rate" element
     */
    void setRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType rate);
    
    /**
     * Appends and returns a new empty "rate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewRate();
    
    /**
     * Nils the "rate" element
     */
    void setNilRate();
    
    /**
     * Unsets the "rate" element
     */
    void unsetRate();
    
    /**
     * Gets the "aEndTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getAEndTpRef();
    
    /**
     * True if has "aEndTpRef" element
     */
    boolean isSetAEndTpRef();
    
    /**
     * Sets the "aEndTpRef" element
     */
    void setAEndTpRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType aEndTpRef);
    
    /**
     * Appends and returns a new empty "aEndTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewAEndTpRef();
    
    /**
     * Unsets the "aEndTpRef" element
     */
    void unsetAEndTpRef();
    
    /**
     * Gets the "zEndTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getZEndTpRef();
    
    /**
     * True if has "zEndTpRef" element
     */
    boolean isSetZEndTpRef();
    
    /**
     * Sets the "zEndTpRef" element
     */
    void setZEndTpRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType zEndTpRef);
    
    /**
     * Appends and returns a new empty "zEndTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewZEndTpRef();
    
    /**
     * Unsets the "zEndTpRef" element
     */
    void unsetZEndTpRef();
    
    /**
     * Gets the "isReportingAlarm" element
     */
    boolean getIsReportingAlarm();
    
    /**
     * Gets (as xml) the "isReportingAlarm" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsReportingAlarm();
    
    /**
     * Tests for nil "isReportingAlarm" element
     */
    boolean isNilIsReportingAlarm();
    
    /**
     * True if has "isReportingAlarm" element
     */
    boolean isSetIsReportingAlarm();
    
    /**
     * Sets the "isReportingAlarm" element
     */
    void setIsReportingAlarm(boolean isReportingAlarm);
    
    /**
     * Sets (as xml) the "isReportingAlarm" element
     */
    void xsetIsReportingAlarm(org.apache.xmlbeans.XmlBoolean isReportingAlarm);
    
    /**
     * Nils the "isReportingAlarm" element
     */
    void setNilIsReportingAlarm();
    
    /**
     * Unsets the "isReportingAlarm" element
     */
    void unsetIsReportingAlarm();
    
    /**
     * Gets the "allocatedNumber" element
     */
    java.lang.String getAllocatedNumber();
    
    /**
     * Gets (as xml) the "allocatedNumber" element
     */
    org.apache.xmlbeans.XmlString xgetAllocatedNumber();
    
    /**
     * Tests for nil "allocatedNumber" element
     */
    boolean isNilAllocatedNumber();
    
    /**
     * True if has "allocatedNumber" element
     */
    boolean isSetAllocatedNumber();
    
    /**
     * Sets the "allocatedNumber" element
     */
    void setAllocatedNumber(java.lang.String allocatedNumber);
    
    /**
     * Sets (as xml) the "allocatedNumber" element
     */
    void xsetAllocatedNumber(org.apache.xmlbeans.XmlString allocatedNumber);
    
    /**
     * Nils the "allocatedNumber" element
     */
    void setNilAllocatedNumber();
    
    /**
     * Unsets the "allocatedNumber" element
     */
    void unsetAllocatedNumber();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * Gets the "fragmentServerLayer" element
     */
    java.lang.String getFragmentServerLayer();
    
    /**
     * Gets (as xml) the "fragmentServerLayer" element
     */
    org.apache.xmlbeans.XmlString xgetFragmentServerLayer();
    
    /**
     * Tests for nil "fragmentServerLayer" element
     */
    boolean isNilFragmentServerLayer();
    
    /**
     * True if has "fragmentServerLayer" element
     */
    boolean isSetFragmentServerLayer();
    
    /**
     * Sets the "fragmentServerLayer" element
     */
    void setFragmentServerLayer(java.lang.String fragmentServerLayer);
    
    /**
     * Sets (as xml) the "fragmentServerLayer" element
     */
    void xsetFragmentServerLayer(org.apache.xmlbeans.XmlString fragmentServerLayer);
    
    /**
     * Nils the "fragmentServerLayer" element
     */
    void setNilFragmentServerLayer();
    
    /**
     * Unsets the "fragmentServerLayer" element
     */
    void unsetFragmentServerLayer();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
