/*
 * An XML document type.
 * Localname: deactivateAndDeleteSncRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1;


/**
 * A document containing one deactivateAndDeleteSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public interface DeactivateAndDeleteSncRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DeactivateAndDeleteSncRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("deactivateanddeletesncrequestf263doctype");
    
    /**
     * Gets the "deactivateAndDeleteSncRequest" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument.DeactivateAndDeleteSncRequest getDeactivateAndDeleteSncRequest();
    
    /**
     * Sets the "deactivateAndDeleteSncRequest" element
     */
    void setDeactivateAndDeleteSncRequest(org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument.DeactivateAndDeleteSncRequest deactivateAndDeleteSncRequest);
    
    /**
     * Appends and returns a new empty "deactivateAndDeleteSncRequest" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument.DeactivateAndDeleteSncRequest addNewDeactivateAndDeleteSncRequest();
    
    /**
     * An XML deactivateAndDeleteSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public interface DeactivateAndDeleteSncRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DeactivateAndDeleteSncRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("deactivateanddeletesncrequest6a62elemtype");
        
        /**
         * Gets the "sncName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getSncName();
        
        /**
         * True if has "sncName" element
         */
        boolean isSetSncName();
        
        /**
         * Sets the "sncName" element
         */
        void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType sncName);
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewSncName();
        
        /**
         * Unsets the "sncName" element
         */
        void unsetSncName();
        
        /**
         * Gets the "tolerableImpact" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact();
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact();
        
        /**
         * True if has "tolerableImpact" element
         */
        boolean isSetTolerableImpact();
        
        /**
         * Sets the "tolerableImpact" element
         */
        void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact);
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact);
        
        /**
         * Unsets the "tolerableImpact" element
         */
        void unsetTolerableImpact();
        
        /**
         * Gets the "osFreedomLevel" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum getOsFreedomLevel();
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType xgetOsFreedomLevel();
        
        /**
         * True if has "osFreedomLevel" element
         */
        boolean isSetOsFreedomLevel();
        
        /**
         * Sets the "osFreedomLevel" element
         */
        void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum osFreedomLevel);
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType osFreedomLevel);
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        void unsetOsFreedomLevel();
        
        /**
         * Gets the "tpsToModify" element
         */
        org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType getTpsToModify();
        
        /**
         * True if has "tpsToModify" element
         */
        boolean isSetTpsToModify();
        
        /**
         * Sets the "tpsToModify" element
         */
        void setTpsToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType tpsToModify);
        
        /**
         * Appends and returns a new empty "tpsToModify" element
         */
        org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType addNewTpsToModify();
        
        /**
         * Unsets the "tpsToModify" element
         */
        void unsetTpsToModify();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument.DeactivateAndDeleteSncRequest newInstance() {
              return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument.DeactivateAndDeleteSncRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument.DeactivateAndDeleteSncRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument.DeactivateAndDeleteSncRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument newInstance() {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
