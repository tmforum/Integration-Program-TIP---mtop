/*
 * XML Type:  TrafficConditioningProfileListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tcp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tcp.v1.impl;
/**
 * An XML TrafficConditioningProfileListType(@http://www.tmforum.org/mtop/nrf/xsd/tcp/v1).
 *
 * This is a complex type.
 */
public class TrafficConditioningProfileListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileListType
{
    
    public TrafficConditioningProfileListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TCP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tcp/v1", "tcp");
    
    
    /**
     * Gets a List of "tcp" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType> getTcpList()
    {
        final class TcpList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType>
        {
            public org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType get(int i)
                { return TrafficConditioningProfileListTypeImpl.this.getTcpArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType set(int i, org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType o)
            {
                org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType old = TrafficConditioningProfileListTypeImpl.this.getTcpArray(i);
                TrafficConditioningProfileListTypeImpl.this.setTcpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType o)
                { TrafficConditioningProfileListTypeImpl.this.insertNewTcp(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType old = TrafficConditioningProfileListTypeImpl.this.getTcpArray(i);
                TrafficConditioningProfileListTypeImpl.this.removeTcp(i);
                return old;
            }
            
            public int size()
                { return TrafficConditioningProfileListTypeImpl.this.sizeOfTcpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TcpList();
        }
    }
    
    /**
     * Gets array of all "tcp" elements
     */
    public org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType[] getTcpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TCP$0, targetList);
            org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType[] result = new org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "tcp" element
     */
    public org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType getTcpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType)get_store().find_element_user(TCP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "tcp" element
     */
    public int sizeOfTcpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TCP$0);
        }
    }
    
    /**
     * Sets array of all "tcp" element
     */
    public void setTcpArray(org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType[] tcpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(tcpArray, TCP$0);
        }
    }
    
    /**
     * Sets ith "tcp" element
     */
    public void setTcpArray(int i, org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType tcp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType)get_store().find_element_user(TCP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(tcp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tcp" element
     */
    public org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType insertNewTcp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType)get_store().insert_element_user(TCP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tcp" element
     */
    public org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType addNewTcp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType)get_store().add_element_user(TCP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "tcp" element
     */
    public void removeTcp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TCP$0, i);
        }
    }
}
