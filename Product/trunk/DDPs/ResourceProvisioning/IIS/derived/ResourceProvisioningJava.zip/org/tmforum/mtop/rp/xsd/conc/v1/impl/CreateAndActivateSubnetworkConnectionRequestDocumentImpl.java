/*
 * An XML document type.
 * Localname: createAndActivateSubnetworkConnectionRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createAndActivateSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAndActivateSubnetworkConnectionRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument
{
    
    public CreateAndActivateSubnetworkConnectionRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEANDACTIVATESUBNETWORKCONNECTIONREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createAndActivateSubnetworkConnectionRequest");
    
    
    /**
     * Gets the "createAndActivateSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest getCreateAndActivateSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest)get_store().find_element_user(CREATEANDACTIVATESUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAndActivateSubnetworkConnectionRequest" element
     */
    public void setCreateAndActivateSubnetworkConnectionRequest(org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest createAndActivateSubnetworkConnectionRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest)get_store().find_element_user(CREATEANDACTIVATESUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest)get_store().add_element_user(CREATEANDACTIVATESUBNETWORKCONNECTIONREQUEST$0);
            }
            target.set(createAndActivateSubnetworkConnectionRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "createAndActivateSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest addNewCreateAndActivateSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest)get_store().add_element_user(CREATEANDACTIVATESUBNETWORKCONNECTIONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML createAndActivateSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAndActivateSubnetworkConnectionRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionRequestDocument.CreateAndActivateSubnetworkConnectionRequest
    {
        
        public CreateAndActivateSubnetworkConnectionRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CREATEDATA$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createData");
        private static final javax.xml.namespace.QName TOLERABLEIMPACT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tolerableImpact");
        private static final javax.xml.namespace.QName OSFREEDOMLEVEL$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "osFreedomLevel");
        private static final javax.xml.namespace.QName TPLISTTOMODIFY$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpListToModify");
        
        
        /**
         * Gets the "createData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType getCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType)get_store().find_element_user(CREATEDATA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "createData" element
         */
        public boolean isSetCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CREATEDATA$0) != 0;
            }
        }
        
        /**
         * Sets the "createData" element
         */
        public void setCreateData(org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType createData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType)get_store().find_element_user(CREATEDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType)get_store().add_element_user(CREATEDATA$0);
                }
                target.set(createData);
            }
        }
        
        /**
         * Appends and returns a new empty "createData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType addNewCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType)get_store().add_element_user(CREATEDATA$0);
                return target;
            }
        }
        
        /**
         * Unsets the "createData" element
         */
        public void unsetCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CREATEDATA$0, 0);
            }
        }
        
        /**
         * Gets the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "tolerableImpact" element
         */
        public boolean isSetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOLERABLEIMPACT$2) != 0;
            }
        }
        
        /**
         * Sets the "tolerableImpact" element
         */
        public void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOLERABLEIMPACT$2);
                }
                target.setEnumValue(tolerableImpact);
            }
        }
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        public void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().add_element_user(TOLERABLEIMPACT$2);
                }
                target.set(tolerableImpact);
            }
        }
        
        /**
         * Unsets the "tolerableImpact" element
         */
        public void unsetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOLERABLEIMPACT$2, 0);
            }
        }
        
        /**
         * Gets the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum getOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType xgetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "osFreedomLevel" element
         */
        public boolean isSetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OSFREEDOMLEVEL$4) != 0;
            }
        }
        
        /**
         * Sets the "osFreedomLevel" element
         */
        public void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSFREEDOMLEVEL$4);
                }
                target.setEnumValue(osFreedomLevel);
            }
        }
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        public void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().add_element_user(OSFREEDOMLEVEL$4);
                }
                target.set(osFreedomLevel);
            }
        }
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        public void unsetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OSFREEDOMLEVEL$4, 0);
            }
        }
        
        /**
         * Gets the "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpListToModify" element
         */
        public boolean isSetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPLISTTOMODIFY$6) != 0;
            }
        }
        
        /**
         * Sets the "tpListToModify" element
         */
        public void setTpListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$6);
                }
                target.set(tpListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$6);
                return target;
            }
        }
        
        /**
         * Unsets the "tpListToModify" element
         */
        public void unsetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPLISTTOMODIFY$6, 0);
            }
        }
    }
}
