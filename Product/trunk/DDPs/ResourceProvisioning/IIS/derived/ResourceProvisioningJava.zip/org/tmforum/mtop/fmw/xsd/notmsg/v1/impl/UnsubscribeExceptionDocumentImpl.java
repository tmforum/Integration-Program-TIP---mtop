/*
 * An XML document type.
 * Localname: unsubscribeException
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * A document containing one unsubscribeException(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1) element.
 *
 * This is a complex type.
 */
public class UnsubscribeExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument
{
    
    public UnsubscribeExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UNSUBSCRIBEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "unsubscribeException");
    
    
    /**
     * Gets the "unsubscribeException" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException getUnsubscribeException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException)get_store().find_element_user(UNSUBSCRIBEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "unsubscribeException" element
     */
    public void setUnsubscribeException(org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException unsubscribeException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException)get_store().find_element_user(UNSUBSCRIBEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException)get_store().add_element_user(UNSUBSCRIBEEXCEPTION$0);
            }
            target.set(unsubscribeException);
        }
    }
    
    /**
     * Appends and returns a new empty "unsubscribeException" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException addNewUnsubscribeException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException)get_store().add_element_user(UNSUBSCRIBEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML unsubscribeException(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public static class UnsubscribeExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeExceptionDocument.UnsubscribeException
    {
        
        public UnsubscribeExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
