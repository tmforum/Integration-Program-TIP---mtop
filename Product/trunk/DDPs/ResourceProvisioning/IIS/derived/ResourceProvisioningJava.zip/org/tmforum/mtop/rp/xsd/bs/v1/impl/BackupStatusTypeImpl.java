/*
 * XML Type:  BackupStatusType
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/bs/v1
 * Java type: org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.bs.v1.impl;
/**
 * An XML BackupStatusType(@http://www.tmforum.org/mtop/rp/xsd/bs/v1).
 *
 * This is a complex type.
 */
public class BackupStatusTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationTypeImpl implements org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType
{
    
    public BackupStatusTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName STATUS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/bs/v1", "status");
    private static final javax.xml.namespace.QName MENAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/bs/v1", "meName");
    
    
    /**
     * Gets the "status" element
     */
    public org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType getStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType)get_store().find_element_user(STATUS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "status" element
     */
    public boolean isSetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STATUS$0) != 0;
        }
    }
    
    /**
     * Sets the "status" element
     */
    public void setStatus(org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType)get_store().find_element_user(STATUS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType)get_store().add_element_user(STATUS$0);
            }
            target.set(status);
        }
    }
    
    /**
     * Appends and returns a new empty "status" element
     */
    public org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType addNewStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType)get_store().add_element_user(STATUS$0);
            return target;
        }
    }
    
    /**
     * Unsets the "status" element
     */
    public void unsetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STATUS$0, 0);
        }
    }
    
    /**
     * Gets the "meName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(MENAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "meName" element
     */
    public boolean isSetMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MENAME$2) != 0;
        }
    }
    
    /**
     * Sets the "meName" element
     */
    public void setMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType meName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(MENAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(MENAME$2);
            }
            target.set(meName);
        }
    }
    
    /**
     * Appends and returns a new empty "meName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(MENAME$2);
            return target;
        }
    }
    
    /**
     * Unsets the "meName" element
     */
    public void unsetMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MENAME$2, 0);
        }
    }
}
