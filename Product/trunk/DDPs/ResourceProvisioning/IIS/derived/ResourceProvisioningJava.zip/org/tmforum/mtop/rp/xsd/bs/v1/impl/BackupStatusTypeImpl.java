/*
 * XML Type:  BackupStatusType
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/bs/v1
 * Java type: org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.bs.v1.impl;
/**
 * An XML BackupStatusType(@http://www.tmforum.org/mtop/rp/xsd/bs/v1).
 *
 * This is a complex type.
 */
public class BackupStatusTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoTypeImpl implements org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType
{
    
    public BackupStatusTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NETIME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/bs/v1", "neTime");
    private static final javax.xml.namespace.QName BACKUPSTATUS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/bs/v1", "backupStatus");
    private static final javax.xml.namespace.QName MENAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/bs/v1", "meName");
    
    
    /**
     * Gets the "neTime" element
     */
    public java.util.Calendar getNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETIME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "neTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(NETIME$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "neTime" element
     */
    public boolean isSetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETIME$0) != 0;
        }
    }
    
    /**
     * Sets the "neTime" element
     */
    public void setNeTime(java.util.Calendar neTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETIME$0);
            }
            target.setCalendarValue(neTime);
        }
    }
    
    /**
     * Sets (as xml) the "neTime" element
     */
    public void xsetNeTime(org.apache.xmlbeans.XmlDateTime neTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(NETIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(NETIME$0);
            }
            target.set(neTime);
        }
    }
    
    /**
     * Unsets the "neTime" element
     */
    public void unsetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETIME$0, 0);
        }
    }
    
    /**
     * Gets the "backupStatus" element
     */
    public org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType getBackupStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType)get_store().find_element_user(BACKUPSTATUS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "backupStatus" element
     */
    public boolean isSetBackupStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BACKUPSTATUS$2) != 0;
        }
    }
    
    /**
     * Sets the "backupStatus" element
     */
    public void setBackupStatus(org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType backupStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType)get_store().find_element_user(BACKUPSTATUS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType)get_store().add_element_user(BACKUPSTATUS$2);
            }
            target.set(backupStatus);
        }
    }
    
    /**
     * Appends and returns a new empty "backupStatus" element
     */
    public org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType addNewBackupStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.sdc.v1.BackupStatusType)get_store().add_element_user(BACKUPSTATUS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "backupStatus" element
     */
    public void unsetBackupStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BACKUPSTATUS$2, 0);
        }
    }
    
    /**
     * Gets the "meName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "meName" element
     */
    public boolean isSetMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MENAME$4) != 0;
        }
    }
    
    /**
     * Sets the "meName" element
     */
    public void setMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType meName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$4);
            }
            target.set(meName);
        }
    }
    
    /**
     * Appends and returns a new empty "meName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$4);
            return target;
        }
    }
    
    /**
     * Unsets the "meName" element
     */
    public void unsetMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MENAME$4, 0);
        }
    }
}
