/*
 * An XML document type.
 * Localname: unsubscribeResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * A document containing one unsubscribeResponse(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1) element.
 *
 * This is a complex type.
 */
public class UnsubscribeResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument
{
    
    public UnsubscribeResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UNSUBSCRIBERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "unsubscribeResponse");
    
    
    /**
     * Gets the "unsubscribeResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse getUnsubscribeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse)get_store().find_element_user(UNSUBSCRIBERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "unsubscribeResponse" element
     */
    public void setUnsubscribeResponse(org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse unsubscribeResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse)get_store().find_element_user(UNSUBSCRIBERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse)get_store().add_element_user(UNSUBSCRIBERESPONSE$0);
            }
            target.set(unsubscribeResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "unsubscribeResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse addNewUnsubscribeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse)get_store().add_element_user(UNSUBSCRIBERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML unsubscribeResponse(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public static class UnsubscribeResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeResponseDocument.UnsubscribeResponse
    {
        
        public UnsubscribeResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
