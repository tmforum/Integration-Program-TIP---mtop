/*
 * An XML document type.
 * Localname: createAndActivateSncException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createAndActivateSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAndActivateSncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument
{
    
    public CreateAndActivateSncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEANDACTIVATESNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createAndActivateSncException");
    
    
    /**
     * Gets the "createAndActivateSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException getCreateAndActivateSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException)get_store().find_element_user(CREATEANDACTIVATESNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAndActivateSncException" element
     */
    public void setCreateAndActivateSncException(org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException createAndActivateSncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException)get_store().find_element_user(CREATEANDACTIVATESNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException)get_store().add_element_user(CREATEANDACTIVATESNCEXCEPTION$0);
            }
            target.set(createAndActivateSncException);
        }
    }
    
    /**
     * Appends and returns a new empty "createAndActivateSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException addNewCreateAndActivateSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException)get_store().add_element_user(CREATEANDACTIVATESNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML createAndActivateSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAndActivateSncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncExceptionDocument.CreateAndActivateSncException
    {
        
        public CreateAndActivateSncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
