/*
 * An XML document type.
 * Localname: modifySncRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one modifySncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class ModifySncRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument
{
    
    public ModifySncRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MODIFYSNCREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "modifySncRequest");
    
    
    /**
     * Gets the "modifySncRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest getModifySncRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest)get_store().find_element_user(MODIFYSNCREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "modifySncRequest" element
     */
    public void setModifySncRequest(org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest modifySncRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest)get_store().find_element_user(MODIFYSNCREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest)get_store().add_element_user(MODIFYSNCREQUEST$0);
            }
            target.set(modifySncRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "modifySncRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest addNewModifySncRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest)get_store().add_element_user(MODIFYSNCREQUEST$0);
            return target;
        }
    }
    /**
     * An XML modifySncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ModifySncRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ModifySncRequestDocument.ModifySncRequest
    {
        
        public ModifySncRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNCNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "sncName");
        private static final javax.xml.namespace.QName ROUTEID$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "routeId");
        private static final javax.xml.namespace.QName SNCMODIFYDATA$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "SncModifyData");
        private static final javax.xml.namespace.QName TOLERABLEIMPACT$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tolerableImpact");
        private static final javax.xml.namespace.QName TOLERABLEIMPACTEFFORT$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tolerableImpactEffort");
        private static final javax.xml.namespace.QName OSFREEDOMLEVEL$10 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "osFreedomLevel");
        private static final javax.xml.namespace.QName TPSTOMODIFY$12 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpsToModify");
        
        
        /**
         * Gets the "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "sncName" element
         */
        public boolean isSetSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNCNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "sncName" element
         */
        public void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType sncName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SNCNAME$0);
                }
                target.set(sncName);
            }
        }
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SNCNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "sncName" element
         */
        public void unsetSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNCNAME$0, 0);
            }
        }
        
        /**
         * Gets the "routeId" element
         */
        public java.lang.String getRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "routeId" element
         */
        public org.apache.xmlbeans.XmlString xgetRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "routeId" element
         */
        public boolean isSetRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROUTEID$2) != 0;
            }
        }
        
        /**
         * Sets the "routeId" element
         */
        public void setRouteId(java.lang.String routeId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEID$2);
                }
                target.setStringValue(routeId);
            }
        }
        
        /**
         * Sets (as xml) the "routeId" element
         */
        public void xsetRouteId(org.apache.xmlbeans.XmlString routeId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEID$2);
                }
                target.set(routeId);
            }
        }
        
        /**
         * Unsets the "routeId" element
         */
        public void unsetRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROUTEID$2, 0);
            }
        }
        
        /**
         * Gets the "SncModifyData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType getSncModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType)get_store().find_element_user(SNCMODIFYDATA$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "SncModifyData" element
         */
        public boolean isSetSncModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNCMODIFYDATA$4) != 0;
            }
        }
        
        /**
         * Sets the "SncModifyData" element
         */
        public void setSncModifyData(org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType sncModifyData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType)get_store().find_element_user(SNCMODIFYDATA$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType)get_store().add_element_user(SNCMODIFYDATA$4);
                }
                target.set(sncModifyData);
            }
        }
        
        /**
         * Appends and returns a new empty "SncModifyData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType addNewSncModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType)get_store().add_element_user(SNCMODIFYDATA$4);
                return target;
            }
        }
        
        /**
         * Unsets the "SncModifyData" element
         */
        public void unsetSncModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNCMODIFYDATA$4, 0);
            }
        }
        
        /**
         * Gets the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$6, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$6, 0);
                return target;
            }
        }
        
        /**
         * True if has "tolerableImpact" element
         */
        public boolean isSetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOLERABLEIMPACT$6) != 0;
            }
        }
        
        /**
         * Sets the "tolerableImpact" element
         */
        public void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOLERABLEIMPACT$6);
                }
                target.setEnumValue(tolerableImpact);
            }
        }
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        public void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().add_element_user(TOLERABLEIMPACT$6);
                }
                target.set(tolerableImpact);
            }
        }
        
        /**
         * Unsets the "tolerableImpact" element
         */
        public void unsetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOLERABLEIMPACT$6, 0);
            }
        }
        
        /**
         * Gets the "tolerableImpactEffort" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum getTolerableImpactEffort()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACTEFFORT$8, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "tolerableImpactEffort" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType xgetTolerableImpactEffort()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(TOLERABLEIMPACTEFFORT$8, 0);
                return target;
            }
        }
        
        /**
         * True if has "tolerableImpactEffort" element
         */
        public boolean isSetTolerableImpactEffort()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOLERABLEIMPACTEFFORT$8) != 0;
            }
        }
        
        /**
         * Sets the "tolerableImpactEffort" element
         */
        public void setTolerableImpactEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum tolerableImpactEffort)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACTEFFORT$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOLERABLEIMPACTEFFORT$8);
                }
                target.setEnumValue(tolerableImpactEffort);
            }
        }
        
        /**
         * Sets (as xml) the "tolerableImpactEffort" element
         */
        public void xsetTolerableImpactEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType tolerableImpactEffort)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(TOLERABLEIMPACTEFFORT$8, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().add_element_user(TOLERABLEIMPACTEFFORT$8);
                }
                target.set(tolerableImpactEffort);
            }
        }
        
        /**
         * Unsets the "tolerableImpactEffort" element
         */
        public void unsetTolerableImpactEffort()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOLERABLEIMPACTEFFORT$8, 0);
            }
        }
        
        /**
         * Gets the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum getOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$10, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType xgetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$10, 0);
                return target;
            }
        }
        
        /**
         * True if has "osFreedomLevel" element
         */
        public boolean isSetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OSFREEDOMLEVEL$10) != 0;
            }
        }
        
        /**
         * Sets the "osFreedomLevel" element
         */
        public void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSFREEDOMLEVEL$10);
                }
                target.setEnumValue(osFreedomLevel);
            }
        }
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        public void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$10, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType)get_store().add_element_user(OSFREEDOMLEVEL$10);
                }
                target.set(osFreedomLevel);
            }
        }
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        public void unsetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OSFREEDOMLEVEL$10, 0);
            }
        }
        
        /**
         * Gets the "tpsToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType getTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(TPSTOMODIFY$12, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpsToModify" element
         */
        public boolean isSetTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPSTOMODIFY$12) != 0;
            }
        }
        
        /**
         * Sets the "tpsToModify" element
         */
        public void setTpsToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType tpsToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(TPSTOMODIFY$12, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(TPSTOMODIFY$12);
                }
                target.set(tpsToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpsToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType addNewTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(TPSTOMODIFY$12);
                return target;
            }
        }
        
        /**
         * Unsets the "tpsToModify" element
         */
        public void unsetTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPSTOMODIFY$12, 0);
            }
        }
    }
}
