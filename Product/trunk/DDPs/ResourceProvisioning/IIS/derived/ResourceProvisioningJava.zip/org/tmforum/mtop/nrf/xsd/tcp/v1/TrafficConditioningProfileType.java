/*
 * XML Type:  TrafficConditioningProfileType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tcp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tcp.v1;


/**
 * An XML TrafficConditioningProfileType(@http://www.tmforum.org/mtop/nrf/xsd/tcp/v1).
 *
 * This is a complex type.
 */
public interface TrafficConditioningProfileType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TrafficConditioningProfileType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFA029CF23A6AA97F9ACEA74311DBFDC2").resolveHandle("trafficconditioningprofiletype5ec1type");
    
    /**
     * Gets the "isDefaultProfile" element
     */
    boolean getIsDefaultProfile();
    
    /**
     * Gets (as xml) the "isDefaultProfile" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsDefaultProfile();
    
    /**
     * Tests for nil "isDefaultProfile" element
     */
    boolean isNilIsDefaultProfile();
    
    /**
     * True if has "isDefaultProfile" element
     */
    boolean isSetIsDefaultProfile();
    
    /**
     * Sets the "isDefaultProfile" element
     */
    void setIsDefaultProfile(boolean isDefaultProfile);
    
    /**
     * Sets (as xml) the "isDefaultProfile" element
     */
    void xsetIsDefaultProfile(org.apache.xmlbeans.XmlBoolean isDefaultProfile);
    
    /**
     * Nils the "isDefaultProfile" element
     */
    void setNilIsDefaultProfile();
    
    /**
     * Unsets the "isDefaultProfile" element
     */
    void unsetIsDefaultProfile();
    
    /**
     * Gets the "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList();
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    boolean isNilTransmissionParameterList();
    
    /**
     * True if has "transmissionParameterList" element
     */
    boolean isSetTransmissionParameterList();
    
    /**
     * Sets the "transmissionParameterList" element
     */
    void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList);
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList();
    
    /**
     * Nils the "transmissionParameterList" element
     */
    void setNilTransmissionParameterList();
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    void unsetTransmissionParameterList();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
