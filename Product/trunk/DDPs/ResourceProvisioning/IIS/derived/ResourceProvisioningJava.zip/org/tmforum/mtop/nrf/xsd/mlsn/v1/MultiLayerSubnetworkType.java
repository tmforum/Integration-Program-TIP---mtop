/*
 * XML Type:  MultiLayerSubnetworkType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mlsn.v1;


/**
 * An XML MultiLayerSubnetworkType(@http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1).
 *
 * This is a complex type.
 */
public interface MultiLayerSubnetworkType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MultiLayerSubnetworkType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s191F600D204DEAE7EEDC98360AFBE7C2").resolveHandle("multilayersubnetworktype30f9type");
    
    /**
     * Gets the "subnetworkType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TopologyType getSubnetworkType();
    
    /**
     * Tests for nil "subnetworkType" element
     */
    boolean isNilSubnetworkType();
    
    /**
     * True if has "subnetworkType" element
     */
    boolean isSetSubnetworkType();
    
    /**
     * Sets the "subnetworkType" element
     */
    void setSubnetworkType(org.tmforum.mtop.nrf.xsd.com.v1.TopologyType subnetworkType);
    
    /**
     * Appends and returns a new empty "subnetworkType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TopologyType addNewSubnetworkType();
    
    /**
     * Nils the "subnetworkType" element
     */
    void setNilSubnetworkType();
    
    /**
     * Unsets the "subnetworkType" element
     */
    void unsetSubnetworkType();
    
    /**
     * Gets the "supportedRates" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getSupportedRates();
    
    /**
     * Tests for nil "supportedRates" element
     */
    boolean isNilSupportedRates();
    
    /**
     * True if has "supportedRates" element
     */
    boolean isSetSupportedRates();
    
    /**
     * Sets the "supportedRates" element
     */
    void setSupportedRates(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType supportedRates);
    
    /**
     * Appends and returns a new empty "supportedRates" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewSupportedRates();
    
    /**
     * Nils the "supportedRates" element
     */
    void setNilSupportedRates();
    
    /**
     * Unsets the "supportedRates" element
     */
    void unsetSupportedRates();
    
    /**
     * Gets the "layeredRoutingAreaList" element
     */
    java.lang.String getLayeredRoutingAreaList();
    
    /**
     * Gets (as xml) the "layeredRoutingAreaList" element
     */
    org.apache.xmlbeans.XmlString xgetLayeredRoutingAreaList();
    
    /**
     * Tests for nil "layeredRoutingAreaList" element
     */
    boolean isNilLayeredRoutingAreaList();
    
    /**
     * True if has "layeredRoutingAreaList" element
     */
    boolean isSetLayeredRoutingAreaList();
    
    /**
     * Sets the "layeredRoutingAreaList" element
     */
    void setLayeredRoutingAreaList(java.lang.String layeredRoutingAreaList);
    
    /**
     * Sets (as xml) the "layeredRoutingAreaList" element
     */
    void xsetLayeredRoutingAreaList(org.apache.xmlbeans.XmlString layeredRoutingAreaList);
    
    /**
     * Nils the "layeredRoutingAreaList" element
     */
    void setNilLayeredRoutingAreaList();
    
    /**
     * Unsets the "layeredRoutingAreaList" element
     */
    void unsetLayeredRoutingAreaList();
    
    /**
     * Gets the "routingAreaLevel" element
     */
    java.lang.String getRoutingAreaLevel();
    
    /**
     * Gets (as xml) the "routingAreaLevel" element
     */
    org.apache.xmlbeans.XmlString xgetRoutingAreaLevel();
    
    /**
     * Tests for nil "routingAreaLevel" element
     */
    boolean isNilRoutingAreaLevel();
    
    /**
     * True if has "routingAreaLevel" element
     */
    boolean isSetRoutingAreaLevel();
    
    /**
     * Sets the "routingAreaLevel" element
     */
    void setRoutingAreaLevel(java.lang.String routingAreaLevel);
    
    /**
     * Sets (as xml) the "routingAreaLevel" element
     */
    void xsetRoutingAreaLevel(org.apache.xmlbeans.XmlString routingAreaLevel);
    
    /**
     * Nils the "routingAreaLevel" element
     */
    void setNilRoutingAreaLevel();
    
    /**
     * Unsets the "routingAreaLevel" element
     */
    void unsetRoutingAreaLevel();
    
    /**
     * Gets the "srg" element
     */
    java.lang.String getSrg();
    
    /**
     * Gets (as xml) the "srg" element
     */
    org.apache.xmlbeans.XmlString xgetSrg();
    
    /**
     * Tests for nil "srg" element
     */
    boolean isNilSrg();
    
    /**
     * True if has "srg" element
     */
    boolean isSetSrg();
    
    /**
     * Sets the "srg" element
     */
    void setSrg(java.lang.String srg);
    
    /**
     * Sets (as xml) the "srg" element
     */
    void xsetSrg(org.apache.xmlbeans.XmlString srg);
    
    /**
     * Nils the "srg" element
     */
    void setNilSrg();
    
    /**
     * Unsets the "srg" element
     */
    void unsetSrg();
    
    /**
     * Gets the "superiorMlra" element
     */
    java.lang.String getSuperiorMlra();
    
    /**
     * Gets (as xml) the "superiorMlra" element
     */
    org.apache.xmlbeans.XmlString xgetSuperiorMlra();
    
    /**
     * Tests for nil "superiorMlra" element
     */
    boolean isNilSuperiorMlra();
    
    /**
     * True if has "superiorMlra" element
     */
    boolean isSetSuperiorMlra();
    
    /**
     * Sets the "superiorMlra" element
     */
    void setSuperiorMlra(java.lang.String superiorMlra);
    
    /**
     * Sets (as xml) the "superiorMlra" element
     */
    void xsetSuperiorMlra(org.apache.xmlbeans.XmlString superiorMlra);
    
    /**
     * Nils the "superiorMlra" element
     */
    void setNilSuperiorMlra();
    
    /**
     * Unsets the "superiorMlra" element
     */
    void unsetSuperiorMlra();
    
    /**
     * Gets the "supportingMeName" element
     */
    java.lang.String getSupportingMeName();
    
    /**
     * Gets (as xml) the "supportingMeName" element
     */
    org.apache.xmlbeans.XmlString xgetSupportingMeName();
    
    /**
     * Tests for nil "supportingMeName" element
     */
    boolean isNilSupportingMeName();
    
    /**
     * True if has "supportingMeName" element
     */
    boolean isSetSupportingMeName();
    
    /**
     * Sets the "supportingMeName" element
     */
    void setSupportingMeName(java.lang.String supportingMeName);
    
    /**
     * Sets (as xml) the "supportingMeName" element
     */
    void xsetSupportingMeName(org.apache.xmlbeans.XmlString supportingMeName);
    
    /**
     * Nils the "supportingMeName" element
     */
    void setNilSupportingMeName();
    
    /**
     * Unsets the "supportingMeName" element
     */
    void unsetSupportingMeName();
    
    /**
     * Gets the "supportingMlsnList" element
     */
    java.lang.String getSupportingMlsnList();
    
    /**
     * Gets (as xml) the "supportingMlsnList" element
     */
    org.apache.xmlbeans.XmlString xgetSupportingMlsnList();
    
    /**
     * Tests for nil "supportingMlsnList" element
     */
    boolean isNilSupportingMlsnList();
    
    /**
     * True if has "supportingMlsnList" element
     */
    boolean isSetSupportingMlsnList();
    
    /**
     * Sets the "supportingMlsnList" element
     */
    void setSupportingMlsnList(java.lang.String supportingMlsnList);
    
    /**
     * Sets (as xml) the "supportingMlsnList" element
     */
    void xsetSupportingMlsnList(org.apache.xmlbeans.XmlString supportingMlsnList);
    
    /**
     * Nils the "supportingMlsnList" element
     */
    void setNilSupportingMlsnList();
    
    /**
     * Unsets the "supportingMlsnList" element
     */
    void unsetSupportingMlsnList();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
