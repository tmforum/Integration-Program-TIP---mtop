/*
 * An XML document type.
 * Localname: createModifiedSncRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1;


/**
 * A document containing one createModifiedSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public interface CreateModifiedSncRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateModifiedSncRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("createmodifiedsncrequestc09adoctype");
    
    /**
     * Gets the "createModifiedSncRequest" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument.CreateModifiedSncRequest getCreateModifiedSncRequest();
    
    /**
     * Sets the "createModifiedSncRequest" element
     */
    void setCreateModifiedSncRequest(org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument.CreateModifiedSncRequest createModifiedSncRequest);
    
    /**
     * Appends and returns a new empty "createModifiedSncRequest" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument.CreateModifiedSncRequest addNewCreateModifiedSncRequest();
    
    /**
     * An XML createModifiedSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public interface CreateModifiedSncRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateModifiedSncRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("createmodifiedsncrequest8902elemtype");
        
        /**
         * Gets the "sncName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getSncName();
        
        /**
         * True if has "sncName" element
         */
        boolean isSetSncName();
        
        /**
         * Sets the "sncName" element
         */
        void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType sncName);
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewSncName();
        
        /**
         * Unsets the "sncName" element
         */
        void unsetSncName();
        
        /**
         * Gets the "routeId" element
         */
        java.lang.String getRouteId();
        
        /**
         * Gets (as xml) the "routeId" element
         */
        org.apache.xmlbeans.XmlString xgetRouteId();
        
        /**
         * True if has "routeId" element
         */
        boolean isSetRouteId();
        
        /**
         * Sets the "routeId" element
         */
        void setRouteId(java.lang.String routeId);
        
        /**
         * Sets (as xml) the "routeId" element
         */
        void xsetRouteId(org.apache.xmlbeans.XmlString routeId);
        
        /**
         * Unsets the "routeId" element
         */
        void unsetRouteId();
        
        /**
         * Gets the "SncModifyData" element
         */
        org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType getSncModifyData();
        
        /**
         * True if has "SncModifyData" element
         */
        boolean isSetSncModifyData();
        
        /**
         * Sets the "SncModifyData" element
         */
        void setSncModifyData(org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType sncModifyData);
        
        /**
         * Appends and returns a new empty "SncModifyData" element
         */
        org.tmforum.mtop.rp.xsd.conc.v1.SncModifyDataType addNewSncModifyData();
        
        /**
         * Unsets the "SncModifyData" element
         */
        void unsetSncModifyData();
        
        /**
         * Gets the "tolerableImpact" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact();
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact();
        
        /**
         * True if has "tolerableImpact" element
         */
        boolean isSetTolerableImpact();
        
        /**
         * Sets the "tolerableImpact" element
         */
        void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact);
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact);
        
        /**
         * Unsets the "tolerableImpact" element
         */
        void unsetTolerableImpact();
        
        /**
         * Gets the "tolerableImpactEffort" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum getTolerableImpactEffort();
        
        /**
         * Gets (as xml) the "tolerableImpactEffort" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType xgetTolerableImpactEffort();
        
        /**
         * True if has "tolerableImpactEffort" element
         */
        boolean isSetTolerableImpactEffort();
        
        /**
         * Sets the "tolerableImpactEffort" element
         */
        void setTolerableImpactEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum tolerableImpactEffort);
        
        /**
         * Sets (as xml) the "tolerableImpactEffort" element
         */
        void xsetTolerableImpactEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType tolerableImpactEffort);
        
        /**
         * Unsets the "tolerableImpactEffort" element
         */
        void unsetTolerableImpactEffort();
        
        /**
         * Gets the "osFreedomLevel" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum getOsFreedomLevel();
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType xgetOsFreedomLevel();
        
        /**
         * True if has "osFreedomLevel" element
         */
        boolean isSetOsFreedomLevel();
        
        /**
         * Sets the "osFreedomLevel" element
         */
        void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum osFreedomLevel);
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType osFreedomLevel);
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        void unsetOsFreedomLevel();
        
        /**
         * Gets the "tpsToModify" element
         */
        org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType getTpsToModify();
        
        /**
         * True if has "tpsToModify" element
         */
        boolean isSetTpsToModify();
        
        /**
         * Sets the "tpsToModify" element
         */
        void setTpsToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType tpsToModify);
        
        /**
         * Appends and returns a new empty "tpsToModify" element
         */
        org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType addNewTpsToModify();
        
        /**
         * Unsets the "tpsToModify" element
         */
        void unsetTpsToModify();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument.CreateModifiedSncRequest newInstance() {
              return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument.CreateModifiedSncRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument.CreateModifiedSncRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument.CreateModifiedSncRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument newInstance() {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
