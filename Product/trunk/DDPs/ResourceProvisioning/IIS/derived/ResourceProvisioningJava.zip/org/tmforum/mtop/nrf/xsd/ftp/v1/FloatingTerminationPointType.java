/*
 * XML Type:  FloatingTerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ftp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ftp.v1;


/**
 * An XML FloatingTerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/ftp/v1).
 *
 * This is a complex type.
 */
public interface FloatingTerminationPointType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FloatingTerminationPointType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("floatingterminationpointtypea833type");
    
    /**
     * Gets the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum getDirection();
    
    /**
     * Gets (as xml) the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType xgetDirection();
    
    /**
     * Tests for nil "direction" element
     */
    boolean isNilDirection();
    
    /**
     * True if has "direction" element
     */
    boolean isSetDirection();
    
    /**
     * Sets the "direction" element
     */
    void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum direction);
    
    /**
     * Sets (as xml) the "direction" element
     */
    void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType direction);
    
    /**
     * Nils the "direction" element
     */
    void setNilDirection();
    
    /**
     * Unsets the "direction" element
     */
    void unsetDirection();
    
    /**
     * Gets the "tpProtectionAssociation" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType.Enum getTpProtectionAssociation();
    
    /**
     * Gets (as xml) the "tpProtectionAssociation" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType xgetTpProtectionAssociation();
    
    /**
     * Tests for nil "tpProtectionAssociation" element
     */
    boolean isNilTpProtectionAssociation();
    
    /**
     * True if has "tpProtectionAssociation" element
     */
    boolean isSetTpProtectionAssociation();
    
    /**
     * Sets the "tpProtectionAssociation" element
     */
    void setTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType.Enum tpProtectionAssociation);
    
    /**
     * Sets (as xml) the "tpProtectionAssociation" element
     */
    void xsetTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType tpProtectionAssociation);
    
    /**
     * Nils the "tpProtectionAssociation" element
     */
    void setNilTpProtectionAssociation();
    
    /**
     * Unsets the "tpProtectionAssociation" element
     */
    void unsetTpProtectionAssociation();
    
    /**
     * Gets the "edgePoint" element
     */
    boolean getEdgePoint();
    
    /**
     * Gets (as xml) the "edgePoint" element
     */
    org.apache.xmlbeans.XmlBoolean xgetEdgePoint();
    
    /**
     * Tests for nil "edgePoint" element
     */
    boolean isNilEdgePoint();
    
    /**
     * True if has "edgePoint" element
     */
    boolean isSetEdgePoint();
    
    /**
     * Sets the "edgePoint" element
     */
    void setEdgePoint(boolean edgePoint);
    
    /**
     * Sets (as xml) the "edgePoint" element
     */
    void xsetEdgePoint(org.apache.xmlbeans.XmlBoolean edgePoint);
    
    /**
     * Nils the "edgePoint" element
     */
    void setNilEdgePoint();
    
    /**
     * Unsets the "edgePoint" element
     */
    void unsetEdgePoint();
    
    /**
     * Gets the "equipmentProtected" element
     */
    boolean getEquipmentProtected();
    
    /**
     * Gets (as xml) the "equipmentProtected" element
     */
    org.apache.xmlbeans.XmlBoolean xgetEquipmentProtected();
    
    /**
     * Tests for nil "equipmentProtected" element
     */
    boolean isNilEquipmentProtected();
    
    /**
     * True if has "equipmentProtected" element
     */
    boolean isSetEquipmentProtected();
    
    /**
     * Sets the "equipmentProtected" element
     */
    void setEquipmentProtected(boolean equipmentProtected);
    
    /**
     * Sets (as xml) the "equipmentProtected" element
     */
    void xsetEquipmentProtected(org.apache.xmlbeans.XmlBoolean equipmentProtected);
    
    /**
     * Nils the "equipmentProtected" element
     */
    void setNilEquipmentProtected();
    
    /**
     * Unsets the "equipmentProtected" element
     */
    void unsetEquipmentProtected();
    
    /**
     * Gets the "egressTmdState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum getEgressTmdState();
    
    /**
     * Gets (as xml) the "egressTmdState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType xgetEgressTmdState();
    
    /**
     * Tests for nil "egressTmdState" element
     */
    boolean isNilEgressTmdState();
    
    /**
     * True if has "egressTmdState" element
     */
    boolean isSetEgressTmdState();
    
    /**
     * Sets the "egressTmdState" element
     */
    void setEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum egressTmdState);
    
    /**
     * Sets (as xml) the "egressTmdState" element
     */
    void xsetEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType egressTmdState);
    
    /**
     * Nils the "egressTmdState" element
     */
    void setNilEgressTmdState();
    
    /**
     * Unsets the "egressTmdState" element
     */
    void unsetEgressTmdState();
    
    /**
     * Gets the "ingressTmdState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum getIngressTmdState();
    
    /**
     * Gets (as xml) the "ingressTmdState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType xgetIngressTmdState();
    
    /**
     * Tests for nil "ingressTmdState" element
     */
    boolean isNilIngressTmdState();
    
    /**
     * True if has "ingressTmdState" element
     */
    boolean isSetIngressTmdState();
    
    /**
     * Sets the "ingressTmdState" element
     */
    void setIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum ingressTmdState);
    
    /**
     * Sets (as xml) the "ingressTmdState" element
     */
    void xsetIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType ingressTmdState);
    
    /**
     * Nils the "ingressTmdState" element
     */
    void setNilIngressTmdState();
    
    /**
     * Unsets the "ingressTmdState" element
     */
    void unsetIngressTmdState();
    
    /**
     * Gets the "connectionState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.Enum getConnectionState();
    
    /**
     * Gets (as xml) the "connectionState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType xgetConnectionState();
    
    /**
     * Tests for nil "connectionState" element
     */
    boolean isNilConnectionState();
    
    /**
     * True if has "connectionState" element
     */
    boolean isSetConnectionState();
    
    /**
     * Sets the "connectionState" element
     */
    void setConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.Enum connectionState);
    
    /**
     * Sets (as xml) the "connectionState" element
     */
    void xsetConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType connectionState);
    
    /**
     * Nils the "connectionState" element
     */
    void setNilConnectionState();
    
    /**
     * Unsets the "connectionState" element
     */
    void unsetConnectionState();
    
    /**
     * Gets the "tpMappingMode" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum getTpMappingMode();
    
    /**
     * Gets (as xml) the "tpMappingMode" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType xgetTpMappingMode();
    
    /**
     * Tests for nil "tpMappingMode" element
     */
    boolean isNilTpMappingMode();
    
    /**
     * True if has "tpMappingMode" element
     */
    boolean isSetTpMappingMode();
    
    /**
     * Sets the "tpMappingMode" element
     */
    void setTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum tpMappingMode);
    
    /**
     * Sets (as xml) the "tpMappingMode" element
     */
    void xsetTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType tpMappingMode);
    
    /**
     * Nils the "tpMappingMode" element
     */
    void setNilTpMappingMode();
    
    /**
     * Unsets the "tpMappingMode" element
     */
    void unsetTpMappingMode();
    
    /**
     * Gets the "ingressTransmissionDescriptorName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getIngressTransmissionDescriptorName();
    
    /**
     * Tests for nil "ingressTransmissionDescriptorName" element
     */
    boolean isNilIngressTransmissionDescriptorName();
    
    /**
     * True if has "ingressTransmissionDescriptorName" element
     */
    boolean isSetIngressTransmissionDescriptorName();
    
    /**
     * Sets the "ingressTransmissionDescriptorName" element
     */
    void setIngressTransmissionDescriptorName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType ingressTransmissionDescriptorName);
    
    /**
     * Appends and returns a new empty "ingressTransmissionDescriptorName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewIngressTransmissionDescriptorName();
    
    /**
     * Nils the "ingressTransmissionDescriptorName" element
     */
    void setNilIngressTransmissionDescriptorName();
    
    /**
     * Unsets the "ingressTransmissionDescriptorName" element
     */
    void unsetIngressTransmissionDescriptorName();
    
    /**
     * Gets the "egressTransmissionDescriptorName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getEgressTransmissionDescriptorName();
    
    /**
     * Tests for nil "egressTransmissionDescriptorName" element
     */
    boolean isNilEgressTransmissionDescriptorName();
    
    /**
     * True if has "egressTransmissionDescriptorName" element
     */
    boolean isSetEgressTransmissionDescriptorName();
    
    /**
     * Sets the "egressTransmissionDescriptorName" element
     */
    void setEgressTransmissionDescriptorName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType egressTransmissionDescriptorName);
    
    /**
     * Appends and returns a new empty "egressTransmissionDescriptorName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewEgressTransmissionDescriptorName();
    
    /**
     * Nils the "egressTransmissionDescriptorName" element
     */
    void setNilEgressTransmissionDescriptorName();
    
    /**
     * Unsets the "egressTransmissionDescriptorName" element
     */
    void unsetEgressTransmissionDescriptorName();
    
    /**
     * Gets the "transmissionParams" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParams();
    
    /**
     * Tests for nil "transmissionParams" element
     */
    boolean isNilTransmissionParams();
    
    /**
     * True if has "transmissionParams" element
     */
    boolean isSetTransmissionParams();
    
    /**
     * Sets the "transmissionParams" element
     */
    void setTransmissionParams(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParams);
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParams();
    
    /**
     * Nils the "transmissionParams" element
     */
    void setNilTransmissionParams();
    
    /**
     * Unsets the "transmissionParams" element
     */
    void unsetTransmissionParams();
    
    /**
     * Gets the "clientConnectivity" element
     */
    java.lang.String getClientConnectivity();
    
    /**
     * Gets (as xml) the "clientConnectivity" element
     */
    org.apache.xmlbeans.XmlString xgetClientConnectivity();
    
    /**
     * Tests for nil "clientConnectivity" element
     */
    boolean isNilClientConnectivity();
    
    /**
     * True if has "clientConnectivity" element
     */
    boolean isSetClientConnectivity();
    
    /**
     * Sets the "clientConnectivity" element
     */
    void setClientConnectivity(java.lang.String clientConnectivity);
    
    /**
     * Sets (as xml) the "clientConnectivity" element
     */
    void xsetClientConnectivity(org.apache.xmlbeans.XmlString clientConnectivity);
    
    /**
     * Nils the "clientConnectivity" element
     */
    void setNilClientConnectivity();
    
    /**
     * Unsets the "clientConnectivity" element
     */
    void unsetClientConnectivity();
    
    /**
     * Gets the "serverConnectivity" element
     */
    java.lang.String getServerConnectivity();
    
    /**
     * Gets (as xml) the "serverConnectivity" element
     */
    org.apache.xmlbeans.XmlString xgetServerConnectivity();
    
    /**
     * Tests for nil "serverConnectivity" element
     */
    boolean isNilServerConnectivity();
    
    /**
     * True if has "serverConnectivity" element
     */
    boolean isSetServerConnectivity();
    
    /**
     * Sets the "serverConnectivity" element
     */
    void setServerConnectivity(java.lang.String serverConnectivity);
    
    /**
     * Sets (as xml) the "serverConnectivity" element
     */
    void xsetServerConnectivity(org.apache.xmlbeans.XmlString serverConnectivity);
    
    /**
     * Nils the "serverConnectivity" element
     */
    void setNilServerConnectivity();
    
    /**
     * Unsets the "serverConnectivity" element
     */
    void unsetServerConnectivity();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
