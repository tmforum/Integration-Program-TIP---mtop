/*
 * An XML document type.
 * Localname: setIntendedRouteException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one setIntendedRouteException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SetIntendedRouteExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument
{
    
    public SetIntendedRouteExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETINTENDEDROUTEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "setIntendedRouteException");
    
    
    /**
     * Gets the "setIntendedRouteException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException getSetIntendedRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException)get_store().find_element_user(SETINTENDEDROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setIntendedRouteException" element
     */
    public void setSetIntendedRouteException(org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException setIntendedRouteException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException)get_store().find_element_user(SETINTENDEDROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException)get_store().add_element_user(SETINTENDEDROUTEEXCEPTION$0);
            }
            target.set(setIntendedRouteException);
        }
    }
    
    /**
     * Appends and returns a new empty "setIntendedRouteException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException addNewSetIntendedRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException)get_store().add_element_user(SETINTENDEDROUTEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setIntendedRouteException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SetIntendedRouteExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteExceptionDocument.SetIntendedRouteException
    {
        
        public SetIntendedRouteExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
