/*
 * An XML document type.
 * Localname: createAndActivateSubnetworkConnectionResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1;


/**
 * A document containing one createAndActivateSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public interface CreateAndActivateSubnetworkConnectionResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateAndActivateSubnetworkConnectionResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFA029CF23A6AA97F9ACEA74311DBFDC2").resolveHandle("createandactivatesubnetworkconnectionresponse715ddoctype");
    
    /**
     * Gets the "createAndActivateSubnetworkConnectionResponse" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument.CreateAndActivateSubnetworkConnectionResponse getCreateAndActivateSubnetworkConnectionResponse();
    
    /**
     * Sets the "createAndActivateSubnetworkConnectionResponse" element
     */
    void setCreateAndActivateSubnetworkConnectionResponse(org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument.CreateAndActivateSubnetworkConnectionResponse createAndActivateSubnetworkConnectionResponse);
    
    /**
     * Appends and returns a new empty "createAndActivateSubnetworkConnectionResponse" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument.CreateAndActivateSubnetworkConnectionResponse addNewCreateAndActivateSubnetworkConnectionResponse();
    
    /**
     * An XML createAndActivateSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public interface CreateAndActivateSubnetworkConnectionResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateAndActivateSubnetworkConnectionResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFA029CF23A6AA97F9ACEA74311DBFDC2").resolveHandle("createandactivatesubnetworkconnectionresponsed056elemtype");
        
        /**
         * Gets the "tpDataListToModify" element
         */
        org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpDataListToModify();
        
        /**
         * True if has "tpDataListToModify" element
         */
        boolean isSetTpDataListToModify();
        
        /**
         * Sets the "tpDataListToModify" element
         */
        void setTpDataListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpDataListToModify);
        
        /**
         * Appends and returns a new empty "tpDataListToModify" element
         */
        org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpDataListToModify();
        
        /**
         * Unsets the "tpDataListToModify" element
         */
        void unsetTpDataListToModify();
        
        /**
         * Gets the "theSnc" element
         */
        org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getTheSnc();
        
        /**
         * True if has "theSnc" element
         */
        boolean isSetTheSnc();
        
        /**
         * Sets the "theSnc" element
         */
        void setTheSnc(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType theSnc);
        
        /**
         * Appends and returns a new empty "theSnc" element
         */
        org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewTheSnc();
        
        /**
         * Unsets the "theSnc" element
         */
        void unsetTheSnc();
        
        /**
         * Gets the "errorReason" element
         */
        java.lang.String getErrorReason();
        
        /**
         * Gets (as xml) the "errorReason" element
         */
        org.apache.xmlbeans.XmlString xgetErrorReason();
        
        /**
         * True if has "errorReason" element
         */
        boolean isSetErrorReason();
        
        /**
         * Sets the "errorReason" element
         */
        void setErrorReason(java.lang.String errorReason);
        
        /**
         * Sets (as xml) the "errorReason" element
         */
        void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason);
        
        /**
         * Unsets the "errorReason" element
         */
        void unsetErrorReason();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument.CreateAndActivateSubnetworkConnectionResponse newInstance() {
              return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument.CreateAndActivateSubnetworkConnectionResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument.CreateAndActivateSubnetworkConnectionResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument.CreateAndActivateSubnetworkConnectionResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument newInstance() {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSubnetworkConnectionResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
