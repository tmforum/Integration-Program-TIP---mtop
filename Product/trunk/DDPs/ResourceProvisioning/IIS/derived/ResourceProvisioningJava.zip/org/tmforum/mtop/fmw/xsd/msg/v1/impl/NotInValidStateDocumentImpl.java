/*
 * An XML document type.
 * Localname: notInValidState
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.NotInValidStateDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * A document containing one notInValidState(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1) element.
 *
 * This is a complex type.
 */
public class NotInValidStateDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.NotInValidStateDocument
{
    
    public NotInValidStateDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NOTINVALIDSTATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "notInValidState");
    
    
    /**
     * Gets the "notInValidState" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getNotInValidState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTINVALIDSTATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "notInValidState" element
     */
    public void setNotInValidState(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType notInValidState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTINVALIDSTATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTINVALIDSTATE$0);
            }
            target.set(notInValidState);
        }
    }
    
    /**
     * Appends and returns a new empty "notInValidState" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewNotInValidState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTINVALIDSTATE$0);
            return target;
        }
    }
}
