/*
 * An XML document type.
 * Localname: checkValidSubnetworkConnectionRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one checkValidSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CheckValidSubnetworkConnectionRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument
{
    
    public CheckValidSubnetworkConnectionRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHECKVALIDSUBNETWORKCONNECTIONREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "checkValidSubnetworkConnectionRequest");
    
    
    /**
     * Gets the "checkValidSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest getCheckValidSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest)get_store().find_element_user(CHECKVALIDSUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "checkValidSubnetworkConnectionRequest" element
     */
    public void setCheckValidSubnetworkConnectionRequest(org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest checkValidSubnetworkConnectionRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest)get_store().find_element_user(CHECKVALIDSUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest)get_store().add_element_user(CHECKVALIDSUBNETWORKCONNECTIONREQUEST$0);
            }
            target.set(checkValidSubnetworkConnectionRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "checkValidSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest addNewCheckValidSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest)get_store().add_element_user(CHECKVALIDSUBNETWORKCONNECTIONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML checkValidSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CheckValidSubnetworkConnectionRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionRequestDocument.CheckValidSubnetworkConnectionRequest
    {
        
        public CheckValidSubnetworkConnectionRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CREATEDATA$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createData");
        private static final javax.xml.namespace.QName TPLISTTOMODIFY$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpListToModify");
        private static final javax.xml.namespace.QName CONSIDERRESOURCES$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "considerResources");
        
        
        /**
         * Gets the "createData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType getCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType)get_store().find_element_user(CREATEDATA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "createData" element
         */
        public boolean isSetCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CREATEDATA$0) != 0;
            }
        }
        
        /**
         * Sets the "createData" element
         */
        public void setCreateData(org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType createData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType)get_store().find_element_user(CREATEDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType)get_store().add_element_user(CREATEDATA$0);
                }
                target.set(createData);
            }
        }
        
        /**
         * Appends and returns a new empty "createData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType addNewCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionCreateDataType)get_store().add_element_user(CREATEDATA$0);
                return target;
            }
        }
        
        /**
         * Unsets the "createData" element
         */
        public void unsetCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CREATEDATA$0, 0);
            }
        }
        
        /**
         * Gets the "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpListToModify" element
         */
        public boolean isSetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPLISTTOMODIFY$2) != 0;
            }
        }
        
        /**
         * Sets the "tpListToModify" element
         */
        public void setTpListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$2);
                }
                target.set(tpListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$2);
                return target;
            }
        }
        
        /**
         * Unsets the "tpListToModify" element
         */
        public void unsetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPLISTTOMODIFY$2, 0);
            }
        }
        
        /**
         * Gets the "considerResources" element
         */
        public boolean getConsiderResources()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONSIDERRESOURCES$4, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "considerResources" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetConsiderResources()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CONSIDERRESOURCES$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "considerResources" element
         */
        public boolean isSetConsiderResources()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONSIDERRESOURCES$4) != 0;
            }
        }
        
        /**
         * Sets the "considerResources" element
         */
        public void setConsiderResources(boolean considerResources)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONSIDERRESOURCES$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONSIDERRESOURCES$4);
                }
                target.setBooleanValue(considerResources);
            }
        }
        
        /**
         * Sets (as xml) the "considerResources" element
         */
        public void xsetConsiderResources(org.apache.xmlbeans.XmlBoolean considerResources)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CONSIDERRESOURCES$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(CONSIDERRESOURCES$4);
                }
                target.set(considerResources);
            }
        }
        
        /**
         * Unsets the "considerResources" element
         */
        public void unsetConsiderResources()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONSIDERRESOURCES$4, 0);
            }
        }
    }
}
