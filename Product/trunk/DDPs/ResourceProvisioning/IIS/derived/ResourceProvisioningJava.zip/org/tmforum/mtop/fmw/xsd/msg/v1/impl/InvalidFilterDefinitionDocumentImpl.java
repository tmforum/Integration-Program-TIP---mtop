/*
 * An XML document type.
 * Localname: invalidFilterDefinition
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.InvalidFilterDefinitionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * A document containing one invalidFilterDefinition(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1) element.
 *
 * This is a complex type.
 */
public class InvalidFilterDefinitionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.InvalidFilterDefinitionDocument
{
    
    public InvalidFilterDefinitionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INVALIDFILTERDEFINITION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "invalidFilterDefinition");
    
    
    /**
     * Gets the "invalidFilterDefinition" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInvalidFilterDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDFILTERDEFINITION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "invalidFilterDefinition" element
     */
    public void setInvalidFilterDefinition(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType invalidFilterDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDFILTERDEFINITION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDFILTERDEFINITION$0);
            }
            target.set(invalidFilterDefinition);
        }
    }
    
    /**
     * Appends and returns a new empty "invalidFilterDefinition" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInvalidFilterDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDFILTERDEFINITION$0);
            return target;
        }
    }
}
