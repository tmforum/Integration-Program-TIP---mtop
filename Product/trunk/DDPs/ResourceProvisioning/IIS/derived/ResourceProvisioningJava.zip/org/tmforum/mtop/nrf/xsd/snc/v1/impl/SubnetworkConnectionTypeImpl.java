/*
 * XML Type:  SubnetworkConnectionType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/snc/v1
 * Java type: org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.snc.v1.impl;
/**
 * An XML SubnetworkConnectionType(@http://www.tmforum.org/mtop/nrf/xsd/snc/v1).
 *
 * This is a complex type.
 */
public class SubnetworkConnectionTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType
{
    
    public SubnetworkConnectionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SNCSTATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "sncState");
    private static final javax.xml.namespace.QName DIRECTION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "direction");
    private static final javax.xml.namespace.QName RATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "rate");
    private static final javax.xml.namespace.QName STATICPROTECTIONLEVEL$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "staticProtectionLevel");
    private static final javax.xml.namespace.QName SNCTYPE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "sncType");
    private static final javax.xml.namespace.QName AEND$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "aEnd");
    private static final javax.xml.namespace.QName ZEND$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "zEnd");
    private static final javax.xml.namespace.QName REROUTEALLOWED$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "rerouteAllowed");
    private static final javax.xml.namespace.QName NETWORKROUTED$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "networkRouted");
    private static final javax.xml.namespace.QName ALARMREPORTINGINDICATOR$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "alarmReportingIndicator");
    private static final javax.xml.namespace.QName FIXED$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "fixed");
    private static final javax.xml.namespace.QName ASAPREF$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "asapRef");
    private static final javax.xml.namespace.QName CORRELATIONID$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "correlationId");
    private static final javax.xml.namespace.QName NETWORKREROUTE$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "networkReroute");
    private static final javax.xml.namespace.QName PRIORITY$28 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "priority");
    private static final javax.xml.namespace.QName REVERTIVE$30 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "revertive");
    private static final javax.xml.namespace.QName AROLES$32 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "aRoles");
    private static final javax.xml.namespace.QName AENDTPLIST$34 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "aEndTpList");
    private static final javax.xml.namespace.QName AENDTNANAMEORGROUPTNANAME$36 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "aEndTnaNameOrGroupTnaName");
    private static final javax.xml.namespace.QName BUNDLEDSNCINDICATOR$38 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "bundledSncIndicator");
    private static final javax.xml.namespace.QName CALLID$40 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "callId");
    private static final javax.xml.namespace.QName CALLNAME$42 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "callName");
    private static final javax.xml.namespace.QName CONNECTIONID$44 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "connectionId");
    private static final javax.xml.namespace.QName CONNECTIONSETUPTYPE$46 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "connectionSetUpType");
    private static final javax.xml.namespace.QName CONNECTIONSTATE$48 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "connectionState");
    private static final javax.xml.namespace.QName MAXIMUMCOST$50 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "maximumCost");
    private static final javax.xml.namespace.QName MUSTREMOVEGTPLIST$52 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "mustRemoveGtpList");
    private static final javax.xml.namespace.QName PROTECTIONEFFORT$54 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "protectionEffort");
    private static final javax.xml.namespace.QName ROUTEGROUPLABEL$56 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "routeGroupLabel");
    private static final javax.xml.namespace.QName ROUTINGCONSTRAINTEFFORT$58 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "routingConstraintEffort");
    private static final javax.xml.namespace.QName SRG$60 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "srg");
    private static final javax.xml.namespace.QName SUPPORTEDCONNECTIONNAME$62 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "supportedConnectionName");
    private static final javax.xml.namespace.QName SUPPORTINGSNCLIST$64 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "supportingSncList");
    private static final javax.xml.namespace.QName USINGHOMEROUTE$66 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "usingHomeRoute");
    private static final javax.xml.namespace.QName ZROLES$68 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "zRoles");
    private static final javax.xml.namespace.QName ZENDTPLIST$70 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "zEndTpList");
    private static final javax.xml.namespace.QName ZENDTNANAMEORGROUPTNANAME$72 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "zEndTnaNameOrGroupTnaName");
    
    
    /**
     * Gets the "sncState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SncStateType.Enum getSncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCSTATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.SncStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "sncState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SncStateType xgetSncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncStateType)get_store().find_element_user(SNCSTATE$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "sncState" element
     */
    public boolean isNilSncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncStateType)get_store().find_element_user(SNCSTATE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "sncState" element
     */
    public boolean isSetSncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SNCSTATE$0) != 0;
        }
    }
    
    /**
     * Sets the "sncState" element
     */
    public void setSncState(org.tmforum.mtop.nrf.xsd.com.v1.SncStateType.Enum sncState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCSTATE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SNCSTATE$0);
            }
            target.setEnumValue(sncState);
        }
    }
    
    /**
     * Sets (as xml) the "sncState" element
     */
    public void xsetSncState(org.tmforum.mtop.nrf.xsd.com.v1.SncStateType sncState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncStateType)get_store().find_element_user(SNCSTATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SncStateType)get_store().add_element_user(SNCSTATE$0);
            }
            target.set(sncState);
        }
    }
    
    /**
     * Nils the "sncState" element
     */
    public void setNilSncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncStateType)get_store().find_element_user(SNCSTATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SncStateType)get_store().add_element_user(SNCSTATE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "sncState" element
     */
    public void unsetSncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SNCSTATE$0, 0);
        }
    }
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$2) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$2);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$2);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$2, 0);
        }
    }
    
    /**
     * Gets the "rate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "rate" element
     */
    public boolean isNilRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "rate" element
     */
    public boolean isSetRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RATE$4) != 0;
        }
    }
    
    /**
     * Sets the "rate" element
     */
    public void setRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType rate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$4);
            }
            target.set(rate);
        }
    }
    
    /**
     * Appends and returns a new empty "rate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$4);
            return target;
        }
    }
    
    /**
     * Nils the "rate" element
     */
    public void setNilRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "rate" element
     */
    public void unsetRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RATE$4, 0);
        }
    }
    
    /**
     * Gets the "staticProtectionLevel" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType getStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().find_element_user(STATICPROTECTIONLEVEL$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "staticProtectionLevel" element
     */
    public boolean isNilStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().find_element_user(STATICPROTECTIONLEVEL$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "staticProtectionLevel" element
     */
    public boolean isSetStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STATICPROTECTIONLEVEL$6) != 0;
        }
    }
    
    /**
     * Sets the "staticProtectionLevel" element
     */
    public void setStaticProtectionLevel(org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType staticProtectionLevel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().find_element_user(STATICPROTECTIONLEVEL$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().add_element_user(STATICPROTECTIONLEVEL$6);
            }
            target.set(staticProtectionLevel);
        }
    }
    
    /**
     * Appends and returns a new empty "staticProtectionLevel" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType addNewStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().add_element_user(STATICPROTECTIONLEVEL$6);
            return target;
        }
    }
    
    /**
     * Nils the "staticProtectionLevel" element
     */
    public void setNilStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().find_element_user(STATICPROTECTIONLEVEL$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().add_element_user(STATICPROTECTIONLEVEL$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "staticProtectionLevel" element
     */
    public void unsetStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STATICPROTECTIONLEVEL$6, 0);
        }
    }
    
    /**
     * Gets the "sncType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum getSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCTYPE$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "sncType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType xgetSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(SNCTYPE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "sncType" element
     */
    public boolean isNilSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(SNCTYPE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "sncType" element
     */
    public boolean isSetSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SNCTYPE$8) != 0;
        }
    }
    
    /**
     * Sets the "sncType" element
     */
    public void setSncType(org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum sncType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCTYPE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SNCTYPE$8);
            }
            target.setEnumValue(sncType);
        }
    }
    
    /**
     * Sets (as xml) the "sncType" element
     */
    public void xsetSncType(org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType sncType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(SNCTYPE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().add_element_user(SNCTYPE$8);
            }
            target.set(sncType);
        }
    }
    
    /**
     * Nils the "sncType" element
     */
    public void setNilSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(SNCTYPE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().add_element_user(SNCTYPE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "sncType" element
     */
    public void unsetSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SNCTYPE$8, 0);
        }
    }
    
    /**
     * Gets the "aEnd" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType getAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(AEND$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "aEnd" element
     */
    public boolean isNilAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(AEND$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aEnd" element
     */
    public boolean isSetAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AEND$10) != 0;
        }
    }
    
    /**
     * Sets the "aEnd" element
     */
    public void setAEnd(org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType aEnd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(AEND$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(AEND$10);
            }
            target.set(aEnd);
        }
    }
    
    /**
     * Appends and returns a new empty "aEnd" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType addNewAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(AEND$10);
            return target;
        }
    }
    
    /**
     * Nils the "aEnd" element
     */
    public void setNilAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(AEND$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(AEND$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aEnd" element
     */
    public void unsetAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AEND$10, 0);
        }
    }
    
    /**
     * Gets the "zEnd" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType getZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(ZEND$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "zEnd" element
     */
    public boolean isNilZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(ZEND$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "zEnd" element
     */
    public boolean isSetZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZEND$12) != 0;
        }
    }
    
    /**
     * Sets the "zEnd" element
     */
    public void setZEnd(org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType zEnd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(ZEND$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(ZEND$12);
            }
            target.set(zEnd);
        }
    }
    
    /**
     * Appends and returns a new empty "zEnd" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType addNewZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(ZEND$12);
            return target;
        }
    }
    
    /**
     * Nils the "zEnd" element
     */
    public void setNilZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(ZEND$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(ZEND$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "zEnd" element
     */
    public void unsetZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZEND$12, 0);
        }
    }
    
    /**
     * Gets the "rerouteAllowed" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum getRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REROUTEALLOWED$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "rerouteAllowed" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType xgetRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(REROUTEALLOWED$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "rerouteAllowed" element
     */
    public boolean isNilRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(REROUTEALLOWED$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "rerouteAllowed" element
     */
    public boolean isSetRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REROUTEALLOWED$14) != 0;
        }
    }
    
    /**
     * Sets the "rerouteAllowed" element
     */
    public void setRerouteAllowed(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum rerouteAllowed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REROUTEALLOWED$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REROUTEALLOWED$14);
            }
            target.setEnumValue(rerouteAllowed);
        }
    }
    
    /**
     * Sets (as xml) the "rerouteAllowed" element
     */
    public void xsetRerouteAllowed(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType rerouteAllowed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(REROUTEALLOWED$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().add_element_user(REROUTEALLOWED$14);
            }
            target.set(rerouteAllowed);
        }
    }
    
    /**
     * Nils the "rerouteAllowed" element
     */
    public void setNilRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(REROUTEALLOWED$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().add_element_user(REROUTEALLOWED$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "rerouteAllowed" element
     */
    public void unsetRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REROUTEALLOWED$14, 0);
        }
    }
    
    /**
     * Gets the "networkRouted" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum getNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKROUTED$16, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "networkRouted" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType xgetNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().find_element_user(NETWORKROUTED$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "networkRouted" element
     */
    public boolean isNilNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().find_element_user(NETWORKROUTED$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "networkRouted" element
     */
    public boolean isSetNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETWORKROUTED$16) != 0;
        }
    }
    
    /**
     * Sets the "networkRouted" element
     */
    public void setNetworkRouted(org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum networkRouted)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKROUTED$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKROUTED$16);
            }
            target.setEnumValue(networkRouted);
        }
    }
    
    /**
     * Sets (as xml) the "networkRouted" element
     */
    public void xsetNetworkRouted(org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType networkRouted)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().find_element_user(NETWORKROUTED$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().add_element_user(NETWORKROUTED$16);
            }
            target.set(networkRouted);
        }
    }
    
    /**
     * Nils the "networkRouted" element
     */
    public void setNilNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().find_element_user(NETWORKROUTED$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().add_element_user(NETWORKROUTED$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "networkRouted" element
     */
    public void unsetNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETWORKROUTED$16, 0);
        }
    }
    
    /**
     * Gets the "alarmReportingIndicator" element
     */
    public boolean getAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$18, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "alarmReportingIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType xgetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "alarmReportingIndicator" element
     */
    public boolean isNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "alarmReportingIndicator" element
     */
    public boolean isSetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMREPORTINGINDICATOR$18) != 0;
        }
    }
    
    /**
     * Sets the "alarmReportingIndicator" element
     */
    public void setAlarmReportingIndicator(boolean alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALARMREPORTINGINDICATOR$18);
            }
            target.setBooleanValue(alarmReportingIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "alarmReportingIndicator" element
     */
    public void xsetAlarmReportingIndicator(org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().add_element_user(ALARMREPORTINGINDICATOR$18);
            }
            target.set(alarmReportingIndicator);
        }
    }
    
    /**
     * Nils the "alarmReportingIndicator" element
     */
    public void setNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().add_element_user(ALARMREPORTINGINDICATOR$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "alarmReportingIndicator" element
     */
    public void unsetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMREPORTINGINDICATOR$18, 0);
        }
    }
    
    /**
     * Gets the "fixed" element
     */
    public boolean getFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FIXED$20, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "fixed" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "fixed" element
     */
    public boolean isNilFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "fixed" element
     */
    public boolean isSetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FIXED$20) != 0;
        }
    }
    
    /**
     * Sets the "fixed" element
     */
    public void setFixed(boolean fixed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FIXED$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FIXED$20);
            }
            target.setBooleanValue(fixed);
        }
    }
    
    /**
     * Sets (as xml) the "fixed" element
     */
    public void xsetFixed(org.apache.xmlbeans.XmlBoolean fixed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FIXED$20);
            }
            target.set(fixed);
        }
    }
    
    /**
     * Nils the "fixed" element
     */
    public void setNilFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FIXED$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "fixed" element
     */
    public void unsetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FIXED$20, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$22) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$22);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$22);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$22, 0);
        }
    }
    
    /**
     * Gets the "correlationId" element
     */
    public java.lang.String getCorrelationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "correlationId" element
     */
    public org.apache.xmlbeans.XmlString xgetCorrelationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$24, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "correlationId" element
     */
    public boolean isNilCorrelationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$24, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "correlationId" element
     */
    public boolean isSetCorrelationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CORRELATIONID$24) != 0;
        }
    }
    
    /**
     * Sets the "correlationId" element
     */
    public void setCorrelationId(java.lang.String correlationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRELATIONID$24);
            }
            target.setStringValue(correlationId);
        }
    }
    
    /**
     * Sets (as xml) the "correlationId" element
     */
    public void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$24);
            }
            target.set(correlationId);
        }
    }
    
    /**
     * Nils the "correlationId" element
     */
    public void setNilCorrelationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$24);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "correlationId" element
     */
    public void unsetCorrelationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CORRELATIONID$24, 0);
        }
    }
    
    /**
     * Gets the "networkReroute" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum getNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKREROUTE$26, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "networkReroute" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType xgetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(NETWORKREROUTE$26, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "networkReroute" element
     */
    public boolean isNilNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(NETWORKREROUTE$26, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "networkReroute" element
     */
    public boolean isSetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETWORKREROUTE$26) != 0;
        }
    }
    
    /**
     * Sets the "networkReroute" element
     */
    public void setNetworkReroute(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum networkReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKREROUTE$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKREROUTE$26);
            }
            target.setEnumValue(networkReroute);
        }
    }
    
    /**
     * Sets (as xml) the "networkReroute" element
     */
    public void xsetNetworkReroute(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType networkReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(NETWORKREROUTE$26, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().add_element_user(NETWORKREROUTE$26);
            }
            target.set(networkReroute);
        }
    }
    
    /**
     * Nils the "networkReroute" element
     */
    public void setNilNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(NETWORKREROUTE$26, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().add_element_user(NETWORKREROUTE$26);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "networkReroute" element
     */
    public void unsetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETWORKREROUTE$26, 0);
        }
    }
    
    /**
     * Gets the "priority" element
     */
    public long getPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$28, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "priority" element
     */
    public org.apache.xmlbeans.XmlUnsignedInt xgetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$28, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "priority" element
     */
    public boolean isNilPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$28, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "priority" element
     */
    public boolean isSetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRIORITY$28) != 0;
        }
    }
    
    /**
     * Sets the "priority" element
     */
    public void setPriority(long priority)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRIORITY$28);
            }
            target.setLongValue(priority);
        }
    }
    
    /**
     * Sets (as xml) the "priority" element
     */
    public void xsetPriority(org.apache.xmlbeans.XmlUnsignedInt priority)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(PRIORITY$28);
            }
            target.set(priority);
        }
    }
    
    /**
     * Nils the "priority" element
     */
    public void setNilPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(PRIORITY$28);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "priority" element
     */
    public void unsetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRIORITY$28, 0);
        }
    }
    
    /**
     * Gets the "revertive" element
     */
    public boolean getRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERTIVE$30, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "revertive" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVE$30, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "revertive" element
     */
    public boolean isNilRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVE$30, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "revertive" element
     */
    public boolean isSetRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REVERTIVE$30) != 0;
        }
    }
    
    /**
     * Sets the "revertive" element
     */
    public void setRevertive(boolean revertive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERTIVE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REVERTIVE$30);
            }
            target.setBooleanValue(revertive);
        }
    }
    
    /**
     * Sets (as xml) the "revertive" element
     */
    public void xsetRevertive(org.apache.xmlbeans.XmlBoolean revertive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(REVERTIVE$30);
            }
            target.set(revertive);
        }
    }
    
    /**
     * Nils the "revertive" element
     */
    public void setNilRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(REVERTIVE$30);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "revertive" element
     */
    public void unsetRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REVERTIVE$30, 0);
        }
    }
    
    /**
     * Gets the "aRoles" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles getARoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles)get_store().find_element_user(AROLES$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "aRoles" element
     */
    public boolean isSetARoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AROLES$32) != 0;
        }
    }
    
    /**
     * Sets the "aRoles" element
     */
    public void setARoles(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles aRoles)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles)get_store().find_element_user(AROLES$32, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles)get_store().add_element_user(AROLES$32);
            }
            target.set(aRoles);
        }
    }
    
    /**
     * Appends and returns a new empty "aRoles" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles addNewARoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles)get_store().add_element_user(AROLES$32);
            return target;
        }
    }
    
    /**
     * Unsets the "aRoles" element
     */
    public void unsetARoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AROLES$32, 0);
        }
    }
    
    /**
     * Gets the "aEndTpList" element
     */
    public java.lang.String getAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AENDTPLIST$34, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "aEndTpList" element
     */
    public org.apache.xmlbeans.XmlString xgetAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTPLIST$34, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "aEndTpList" element
     */
    public boolean isNilAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTPLIST$34, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aEndTpList" element
     */
    public boolean isSetAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AENDTPLIST$34) != 0;
        }
    }
    
    /**
     * Sets the "aEndTpList" element
     */
    public void setAEndTpList(java.lang.String aEndTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AENDTPLIST$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AENDTPLIST$34);
            }
            target.setStringValue(aEndTpList);
        }
    }
    
    /**
     * Sets (as xml) the "aEndTpList" element
     */
    public void xsetAEndTpList(org.apache.xmlbeans.XmlString aEndTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTPLIST$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AENDTPLIST$34);
            }
            target.set(aEndTpList);
        }
    }
    
    /**
     * Nils the "aEndTpList" element
     */
    public void setNilAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTPLIST$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AENDTPLIST$34);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aEndTpList" element
     */
    public void unsetAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AENDTPLIST$34, 0);
        }
    }
    
    /**
     * Gets the "aEndTnaNameOrGroupTnaName" element
     */
    public java.lang.String getAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$36, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "aEndTnaNameOrGroupTnaName" element
     */
    public org.apache.xmlbeans.XmlString xgetAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$36, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "aEndTnaNameOrGroupTnaName" element
     */
    public boolean isNilAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$36, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aEndTnaNameOrGroupTnaName" element
     */
    public boolean isSetAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AENDTNANAMEORGROUPTNANAME$36) != 0;
        }
    }
    
    /**
     * Sets the "aEndTnaNameOrGroupTnaName" element
     */
    public void setAEndTnaNameOrGroupTnaName(java.lang.String aEndTnaNameOrGroupTnaName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AENDTNANAMEORGROUPTNANAME$36);
            }
            target.setStringValue(aEndTnaNameOrGroupTnaName);
        }
    }
    
    /**
     * Sets (as xml) the "aEndTnaNameOrGroupTnaName" element
     */
    public void xsetAEndTnaNameOrGroupTnaName(org.apache.xmlbeans.XmlString aEndTnaNameOrGroupTnaName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AENDTNANAMEORGROUPTNANAME$36);
            }
            target.set(aEndTnaNameOrGroupTnaName);
        }
    }
    
    /**
     * Nils the "aEndTnaNameOrGroupTnaName" element
     */
    public void setNilAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AENDTNANAMEORGROUPTNANAME$36);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aEndTnaNameOrGroupTnaName" element
     */
    public void unsetAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AENDTNANAMEORGROUPTNANAME$36, 0);
        }
    }
    
    /**
     * Gets the "bundledSncIndicator" element
     */
    public boolean getBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BUNDLEDSNCINDICATOR$38, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "bundledSncIndicator" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BUNDLEDSNCINDICATOR$38, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "bundledSncIndicator" element
     */
    public boolean isNilBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BUNDLEDSNCINDICATOR$38, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "bundledSncIndicator" element
     */
    public boolean isSetBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BUNDLEDSNCINDICATOR$38) != 0;
        }
    }
    
    /**
     * Sets the "bundledSncIndicator" element
     */
    public void setBundledSncIndicator(boolean bundledSncIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BUNDLEDSNCINDICATOR$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BUNDLEDSNCINDICATOR$38);
            }
            target.setBooleanValue(bundledSncIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "bundledSncIndicator" element
     */
    public void xsetBundledSncIndicator(org.apache.xmlbeans.XmlBoolean bundledSncIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BUNDLEDSNCINDICATOR$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(BUNDLEDSNCINDICATOR$38);
            }
            target.set(bundledSncIndicator);
        }
    }
    
    /**
     * Nils the "bundledSncIndicator" element
     */
    public void setNilBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BUNDLEDSNCINDICATOR$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(BUNDLEDSNCINDICATOR$38);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "bundledSncIndicator" element
     */
    public void unsetBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BUNDLEDSNCINDICATOR$38, 0);
        }
    }
    
    /**
     * Gets the "callId" element
     */
    public java.lang.String getCallId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CALLID$40, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "callId" element
     */
    public org.apache.xmlbeans.XmlString xgetCallId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CALLID$40, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "callId" element
     */
    public boolean isNilCallId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CALLID$40, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "callId" element
     */
    public boolean isSetCallId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CALLID$40) != 0;
        }
    }
    
    /**
     * Sets the "callId" element
     */
    public void setCallId(java.lang.String callId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CALLID$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CALLID$40);
            }
            target.setStringValue(callId);
        }
    }
    
    /**
     * Sets (as xml) the "callId" element
     */
    public void xsetCallId(org.apache.xmlbeans.XmlString callId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CALLID$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CALLID$40);
            }
            target.set(callId);
        }
    }
    
    /**
     * Nils the "callId" element
     */
    public void setNilCallId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CALLID$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CALLID$40);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "callId" element
     */
    public void unsetCallId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CALLID$40, 0);
        }
    }
    
    /**
     * Gets the "callName" element
     */
    public java.lang.String getCallName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CALLNAME$42, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "callName" element
     */
    public org.apache.xmlbeans.XmlString xgetCallName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CALLNAME$42, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "callName" element
     */
    public boolean isNilCallName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CALLNAME$42, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "callName" element
     */
    public boolean isSetCallName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CALLNAME$42) != 0;
        }
    }
    
    /**
     * Sets the "callName" element
     */
    public void setCallName(java.lang.String callName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CALLNAME$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CALLNAME$42);
            }
            target.setStringValue(callName);
        }
    }
    
    /**
     * Sets (as xml) the "callName" element
     */
    public void xsetCallName(org.apache.xmlbeans.XmlString callName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CALLNAME$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CALLNAME$42);
            }
            target.set(callName);
        }
    }
    
    /**
     * Nils the "callName" element
     */
    public void setNilCallName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CALLNAME$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CALLNAME$42);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "callName" element
     */
    public void unsetCallName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CALLNAME$42, 0);
        }
    }
    
    /**
     * Gets the "connectionId" element
     */
    public java.lang.String getConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONID$44, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "connectionId" element
     */
    public org.apache.xmlbeans.XmlString xgetConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONID$44, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "connectionId" element
     */
    public boolean isNilConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONID$44, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "connectionId" element
     */
    public boolean isSetConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIONID$44) != 0;
        }
    }
    
    /**
     * Sets the "connectionId" element
     */
    public void setConnectionId(java.lang.String connectionId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONID$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONNECTIONID$44);
            }
            target.setStringValue(connectionId);
        }
    }
    
    /**
     * Sets (as xml) the "connectionId" element
     */
    public void xsetConnectionId(org.apache.xmlbeans.XmlString connectionId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONID$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONNECTIONID$44);
            }
            target.set(connectionId);
        }
    }
    
    /**
     * Nils the "connectionId" element
     */
    public void setNilConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONID$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONNECTIONID$44);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "connectionId" element
     */
    public void unsetConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIONID$44, 0);
        }
    }
    
    /**
     * Gets the "connectionSetUpType" element
     */
    public java.lang.String getConnectionSetUpType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSETUPTYPE$46, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "connectionSetUpType" element
     */
    public org.apache.xmlbeans.XmlString xgetConnectionSetUpType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONSETUPTYPE$46, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "connectionSetUpType" element
     */
    public boolean isNilConnectionSetUpType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONSETUPTYPE$46, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "connectionSetUpType" element
     */
    public boolean isSetConnectionSetUpType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIONSETUPTYPE$46) != 0;
        }
    }
    
    /**
     * Sets the "connectionSetUpType" element
     */
    public void setConnectionSetUpType(java.lang.String connectionSetUpType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSETUPTYPE$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONNECTIONSETUPTYPE$46);
            }
            target.setStringValue(connectionSetUpType);
        }
    }
    
    /**
     * Sets (as xml) the "connectionSetUpType" element
     */
    public void xsetConnectionSetUpType(org.apache.xmlbeans.XmlString connectionSetUpType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONSETUPTYPE$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONNECTIONSETUPTYPE$46);
            }
            target.set(connectionSetUpType);
        }
    }
    
    /**
     * Nils the "connectionSetUpType" element
     */
    public void setNilConnectionSetUpType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONSETUPTYPE$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONNECTIONSETUPTYPE$46);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "connectionSetUpType" element
     */
    public void unsetConnectionSetUpType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIONSETUPTYPE$46, 0);
        }
    }
    
    /**
     * Gets the "connectionState" element
     */
    public java.lang.String getConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSTATE$48, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "connectionState" element
     */
    public org.apache.xmlbeans.XmlString xgetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONSTATE$48, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "connectionState" element
     */
    public boolean isNilConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONSTATE$48, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "connectionState" element
     */
    public boolean isSetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIONSTATE$48) != 0;
        }
    }
    
    /**
     * Sets the "connectionState" element
     */
    public void setConnectionState(java.lang.String connectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSTATE$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONNECTIONSTATE$48);
            }
            target.setStringValue(connectionState);
        }
    }
    
    /**
     * Sets (as xml) the "connectionState" element
     */
    public void xsetConnectionState(org.apache.xmlbeans.XmlString connectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONSTATE$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONNECTIONSTATE$48);
            }
            target.set(connectionState);
        }
    }
    
    /**
     * Nils the "connectionState" element
     */
    public void setNilConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONSTATE$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONNECTIONSTATE$48);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "connectionState" element
     */
    public void unsetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIONSTATE$48, 0);
        }
    }
    
    /**
     * Gets the "maximumCost" element
     */
    public java.lang.String getMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAXIMUMCOST$50, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "maximumCost" element
     */
    public org.apache.xmlbeans.XmlString xgetMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MAXIMUMCOST$50, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "maximumCost" element
     */
    public boolean isNilMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MAXIMUMCOST$50, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "maximumCost" element
     */
    public boolean isSetMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MAXIMUMCOST$50) != 0;
        }
    }
    
    /**
     * Sets the "maximumCost" element
     */
    public void setMaximumCost(java.lang.String maximumCost)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAXIMUMCOST$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MAXIMUMCOST$50);
            }
            target.setStringValue(maximumCost);
        }
    }
    
    /**
     * Sets (as xml) the "maximumCost" element
     */
    public void xsetMaximumCost(org.apache.xmlbeans.XmlString maximumCost)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MAXIMUMCOST$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MAXIMUMCOST$50);
            }
            target.set(maximumCost);
        }
    }
    
    /**
     * Nils the "maximumCost" element
     */
    public void setNilMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MAXIMUMCOST$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MAXIMUMCOST$50);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "maximumCost" element
     */
    public void unsetMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MAXIMUMCOST$50, 0);
        }
    }
    
    /**
     * Gets the "mustRemoveGtpList" element
     */
    public boolean getMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUSTREMOVEGTPLIST$52, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "mustRemoveGtpList" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$52, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "mustRemoveGtpList" element
     */
    public boolean isNilMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$52, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "mustRemoveGtpList" element
     */
    public boolean isSetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MUSTREMOVEGTPLIST$52) != 0;
        }
    }
    
    /**
     * Sets the "mustRemoveGtpList" element
     */
    public void setMustRemoveGtpList(boolean mustRemoveGtpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUSTREMOVEGTPLIST$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MUSTREMOVEGTPLIST$52);
            }
            target.setBooleanValue(mustRemoveGtpList);
        }
    }
    
    /**
     * Sets (as xml) the "mustRemoveGtpList" element
     */
    public void xsetMustRemoveGtpList(org.apache.xmlbeans.XmlBoolean mustRemoveGtpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(MUSTREMOVEGTPLIST$52);
            }
            target.set(mustRemoveGtpList);
        }
    }
    
    /**
     * Nils the "mustRemoveGtpList" element
     */
    public void setNilMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(MUSTREMOVEGTPLIST$52);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "mustRemoveGtpList" element
     */
    public void unsetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MUSTREMOVEGTPLIST$52, 0);
        }
    }
    
    /**
     * Gets the "protectionEffort" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum getProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTECTIONEFFORT$54, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "protectionEffort" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType xgetProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(PROTECTIONEFFORT$54, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionEffort" element
     */
    public boolean isNilProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(PROTECTIONEFFORT$54, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionEffort" element
     */
    public boolean isSetProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONEFFORT$54) != 0;
        }
    }
    
    /**
     * Sets the "protectionEffort" element
     */
    public void setProtectionEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum protectionEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTECTIONEFFORT$54, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTECTIONEFFORT$54);
            }
            target.setEnumValue(protectionEffort);
        }
    }
    
    /**
     * Sets (as xml) the "protectionEffort" element
     */
    public void xsetProtectionEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType protectionEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(PROTECTIONEFFORT$54, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().add_element_user(PROTECTIONEFFORT$54);
            }
            target.set(protectionEffort);
        }
    }
    
    /**
     * Nils the "protectionEffort" element
     */
    public void setNilProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(PROTECTIONEFFORT$54, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().add_element_user(PROTECTIONEFFORT$54);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionEffort" element
     */
    public void unsetProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONEFFORT$54, 0);
        }
    }
    
    /**
     * Gets the "routeGroupLabel" element
     */
    public java.lang.String getRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEGROUPLABEL$56, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeGroupLabel" element
     */
    public org.apache.xmlbeans.XmlString xgetRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEGROUPLABEL$56, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routeGroupLabel" element
     */
    public boolean isNilRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEGROUPLABEL$56, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routeGroupLabel" element
     */
    public boolean isSetRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEGROUPLABEL$56) != 0;
        }
    }
    
    /**
     * Sets the "routeGroupLabel" element
     */
    public void setRouteGroupLabel(java.lang.String routeGroupLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEGROUPLABEL$56, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEGROUPLABEL$56);
            }
            target.setStringValue(routeGroupLabel);
        }
    }
    
    /**
     * Sets (as xml) the "routeGroupLabel" element
     */
    public void xsetRouteGroupLabel(org.apache.xmlbeans.XmlString routeGroupLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEGROUPLABEL$56, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEGROUPLABEL$56);
            }
            target.set(routeGroupLabel);
        }
    }
    
    /**
     * Nils the "routeGroupLabel" element
     */
    public void setNilRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEGROUPLABEL$56, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEGROUPLABEL$56);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routeGroupLabel" element
     */
    public void unsetRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEGROUPLABEL$56, 0);
        }
    }
    
    /**
     * Gets the "routingConstraintEffort" element
     */
    public java.lang.String getRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$58, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routingConstraintEffort" element
     */
    public org.apache.xmlbeans.XmlString xgetRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$58, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routingConstraintEffort" element
     */
    public boolean isNilRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$58, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routingConstraintEffort" element
     */
    public boolean isSetRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTINGCONSTRAINTEFFORT$58) != 0;
        }
    }
    
    /**
     * Sets the "routingConstraintEffort" element
     */
    public void setRoutingConstraintEffort(java.lang.String routingConstraintEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$58, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTINGCONSTRAINTEFFORT$58);
            }
            target.setStringValue(routingConstraintEffort);
        }
    }
    
    /**
     * Sets (as xml) the "routingConstraintEffort" element
     */
    public void xsetRoutingConstraintEffort(org.apache.xmlbeans.XmlString routingConstraintEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$58, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTINGCONSTRAINTEFFORT$58);
            }
            target.set(routingConstraintEffort);
        }
    }
    
    /**
     * Nils the "routingConstraintEffort" element
     */
    public void setNilRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$58, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTINGCONSTRAINTEFFORT$58);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routingConstraintEffort" element
     */
    public void unsetRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTINGCONSTRAINTEFFORT$58, 0);
        }
    }
    
    /**
     * Gets the "srg" element
     */
    public java.lang.String getSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SRG$60, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "srg" element
     */
    public org.apache.xmlbeans.XmlString xgetSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SRG$60, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "srg" element
     */
    public boolean isNilSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SRG$60, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "srg" element
     */
    public boolean isSetSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SRG$60) != 0;
        }
    }
    
    /**
     * Sets the "srg" element
     */
    public void setSrg(java.lang.String srg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SRG$60, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SRG$60);
            }
            target.setStringValue(srg);
        }
    }
    
    /**
     * Sets (as xml) the "srg" element
     */
    public void xsetSrg(org.apache.xmlbeans.XmlString srg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SRG$60, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SRG$60);
            }
            target.set(srg);
        }
    }
    
    /**
     * Nils the "srg" element
     */
    public void setNilSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SRG$60, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SRG$60);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "srg" element
     */
    public void unsetSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SRG$60, 0);
        }
    }
    
    /**
     * Gets the "supportedConnectionName" element
     */
    public java.lang.String getSupportedConnectionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPPORTEDCONNECTIONNAME$62, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "supportedConnectionName" element
     */
    public org.apache.xmlbeans.XmlString xgetSupportedConnectionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTEDCONNECTIONNAME$62, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "supportedConnectionName" element
     */
    public boolean isNilSupportedConnectionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTEDCONNECTIONNAME$62, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "supportedConnectionName" element
     */
    public boolean isSetSupportedConnectionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTEDCONNECTIONNAME$62) != 0;
        }
    }
    
    /**
     * Sets the "supportedConnectionName" element
     */
    public void setSupportedConnectionName(java.lang.String supportedConnectionName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPPORTEDCONNECTIONNAME$62, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUPPORTEDCONNECTIONNAME$62);
            }
            target.setStringValue(supportedConnectionName);
        }
    }
    
    /**
     * Sets (as xml) the "supportedConnectionName" element
     */
    public void xsetSupportedConnectionName(org.apache.xmlbeans.XmlString supportedConnectionName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTEDCONNECTIONNAME$62, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPPORTEDCONNECTIONNAME$62);
            }
            target.set(supportedConnectionName);
        }
    }
    
    /**
     * Nils the "supportedConnectionName" element
     */
    public void setNilSupportedConnectionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTEDCONNECTIONNAME$62, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPPORTEDCONNECTIONNAME$62);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "supportedConnectionName" element
     */
    public void unsetSupportedConnectionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTEDCONNECTIONNAME$62, 0);
        }
    }
    
    /**
     * Gets the "supportingSncList" element
     */
    public java.lang.String getSupportingSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPPORTINGSNCLIST$64, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "supportingSncList" element
     */
    public org.apache.xmlbeans.XmlString xgetSupportingSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGSNCLIST$64, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "supportingSncList" element
     */
    public boolean isNilSupportingSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGSNCLIST$64, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "supportingSncList" element
     */
    public boolean isSetSupportingSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTINGSNCLIST$64) != 0;
        }
    }
    
    /**
     * Sets the "supportingSncList" element
     */
    public void setSupportingSncList(java.lang.String supportingSncList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPPORTINGSNCLIST$64, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUPPORTINGSNCLIST$64);
            }
            target.setStringValue(supportingSncList);
        }
    }
    
    /**
     * Sets (as xml) the "supportingSncList" element
     */
    public void xsetSupportingSncList(org.apache.xmlbeans.XmlString supportingSncList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGSNCLIST$64, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPPORTINGSNCLIST$64);
            }
            target.set(supportingSncList);
        }
    }
    
    /**
     * Nils the "supportingSncList" element
     */
    public void setNilSupportingSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGSNCLIST$64, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPPORTINGSNCLIST$64);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "supportingSncList" element
     */
    public void unsetSupportingSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTINGSNCLIST$64, 0);
        }
    }
    
    /**
     * Gets the "usingHomeRoute" element
     */
    public boolean getUsingHomeRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USINGHOMEROUTE$66, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "usingHomeRoute" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetUsingHomeRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(USINGHOMEROUTE$66, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "usingHomeRoute" element
     */
    public boolean isNilUsingHomeRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(USINGHOMEROUTE$66, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "usingHomeRoute" element
     */
    public boolean isSetUsingHomeRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(USINGHOMEROUTE$66) != 0;
        }
    }
    
    /**
     * Sets the "usingHomeRoute" element
     */
    public void setUsingHomeRoute(boolean usingHomeRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USINGHOMEROUTE$66, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USINGHOMEROUTE$66);
            }
            target.setBooleanValue(usingHomeRoute);
        }
    }
    
    /**
     * Sets (as xml) the "usingHomeRoute" element
     */
    public void xsetUsingHomeRoute(org.apache.xmlbeans.XmlBoolean usingHomeRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(USINGHOMEROUTE$66, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(USINGHOMEROUTE$66);
            }
            target.set(usingHomeRoute);
        }
    }
    
    /**
     * Nils the "usingHomeRoute" element
     */
    public void setNilUsingHomeRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(USINGHOMEROUTE$66, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(USINGHOMEROUTE$66);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "usingHomeRoute" element
     */
    public void unsetUsingHomeRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(USINGHOMEROUTE$66, 0);
        }
    }
    
    /**
     * Gets the "zRoles" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles getZRoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles)get_store().find_element_user(ZROLES$68, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "zRoles" element
     */
    public boolean isSetZRoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZROLES$68) != 0;
        }
    }
    
    /**
     * Sets the "zRoles" element
     */
    public void setZRoles(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles zRoles)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles)get_store().find_element_user(ZROLES$68, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles)get_store().add_element_user(ZROLES$68);
            }
            target.set(zRoles);
        }
    }
    
    /**
     * Appends and returns a new empty "zRoles" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles addNewZRoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles)get_store().add_element_user(ZROLES$68);
            return target;
        }
    }
    
    /**
     * Unsets the "zRoles" element
     */
    public void unsetZRoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZROLES$68, 0);
        }
    }
    
    /**
     * Gets the "zEndTpList" element
     */
    public java.lang.String getZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ZENDTPLIST$70, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "zEndTpList" element
     */
    public org.apache.xmlbeans.XmlString xgetZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTPLIST$70, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "zEndTpList" element
     */
    public boolean isNilZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTPLIST$70, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "zEndTpList" element
     */
    public boolean isSetZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZENDTPLIST$70) != 0;
        }
    }
    
    /**
     * Sets the "zEndTpList" element
     */
    public void setZEndTpList(java.lang.String zEndTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ZENDTPLIST$70, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ZENDTPLIST$70);
            }
            target.setStringValue(zEndTpList);
        }
    }
    
    /**
     * Sets (as xml) the "zEndTpList" element
     */
    public void xsetZEndTpList(org.apache.xmlbeans.XmlString zEndTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTPLIST$70, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ZENDTPLIST$70);
            }
            target.set(zEndTpList);
        }
    }
    
    /**
     * Nils the "zEndTpList" element
     */
    public void setNilZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTPLIST$70, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ZENDTPLIST$70);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "zEndTpList" element
     */
    public void unsetZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZENDTPLIST$70, 0);
        }
    }
    
    /**
     * Gets the "zEndTnaNameOrGroupTnaName" element
     */
    public java.lang.String getZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$72, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "zEndTnaNameOrGroupTnaName" element
     */
    public org.apache.xmlbeans.XmlString xgetZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$72, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "zEndTnaNameOrGroupTnaName" element
     */
    public boolean isNilZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$72, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "zEndTnaNameOrGroupTnaName" element
     */
    public boolean isSetZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZENDTNANAMEORGROUPTNANAME$72) != 0;
        }
    }
    
    /**
     * Sets the "zEndTnaNameOrGroupTnaName" element
     */
    public void setZEndTnaNameOrGroupTnaName(java.lang.String zEndTnaNameOrGroupTnaName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$72, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ZENDTNANAMEORGROUPTNANAME$72);
            }
            target.setStringValue(zEndTnaNameOrGroupTnaName);
        }
    }
    
    /**
     * Sets (as xml) the "zEndTnaNameOrGroupTnaName" element
     */
    public void xsetZEndTnaNameOrGroupTnaName(org.apache.xmlbeans.XmlString zEndTnaNameOrGroupTnaName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$72, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ZENDTNANAMEORGROUPTNANAME$72);
            }
            target.set(zEndTnaNameOrGroupTnaName);
        }
    }
    
    /**
     * Nils the "zEndTnaNameOrGroupTnaName" element
     */
    public void setNilZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$72, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ZENDTNANAMEORGROUPTNANAME$72);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "zEndTnaNameOrGroupTnaName" element
     */
    public void unsetZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZENDTNANAMEORGROUPTNANAME$72, 0);
        }
    }
    /**
     * An XML aRoles(@http://www.tmforum.org/mtop/nrf/xsd/snc/v1).
     *
     * This is a complex type.
     */
    public static class ARolesImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles
    {
        
        public ARolesImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROLE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "role");
        
        
        /**
         * Gets a List of "role" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum> getRoleList()
        {
            final class RoleList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum get(int i)
                    { return ARolesImpl.this.getRoleArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum set(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum old = ARolesImpl.this.getRoleArray(i);
                    ARolesImpl.this.setRoleArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum o)
                    { ARolesImpl.this.insertRole(i, o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum old = ARolesImpl.this.getRoleArray(i);
                    ARolesImpl.this.removeRole(i);
                    return old;
                }
                
                public int size()
                    { return ARolesImpl.this.sizeOfRoleArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new RoleList();
            }
        }
        
        /**
         * Gets array of all "role" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] getRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ROLE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] result = new org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
                return result;
            }
        }
        
        /**
         * Gets ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum getRoleArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "role" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType> xgetRoleList()
        {
            final class RoleList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType get(int i)
                    { return ARolesImpl.this.xgetRoleArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType set(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType old = ARolesImpl.this.xgetRoleArray(i);
                    ARolesImpl.this.xsetRoleArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType o)
                    { ARolesImpl.this.insertNewRole(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType old = ARolesImpl.this.xgetRoleArray(i);
                    ARolesImpl.this.removeRole(i);
                    return old;
                }
                
                public int size()
                    { return ARolesImpl.this.sizeOfRoleArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new RoleList();
            }
        }
        
        /**
         * Gets (as xml) array of all "role" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[] xgetRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ROLE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[] result = new org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType xgetRoleArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)target;
            }
        }
        
        /**
         * Returns number of "role" element
         */
        public int sizeOfRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROLE$0);
            }
        }
        
        /**
         * Sets array of all "role" element
         */
        public void setRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] roleArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(roleArray, ROLE$0);
            }
        }
        
        /**
         * Sets ith "role" element
         */
        public void setRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setEnumValue(role);
            }
        }
        
        /**
         * Sets (as xml) array of all "role" element
         */
        public void xsetRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[]roleArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(roleArray, ROLE$0);
            }
        }
        
        /**
         * Sets (as xml) ith "role" element
         */
        public void xsetRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(role);
            }
        }
        
        /**
         * Inserts the value as the ith "role" element
         */
        public void insertRole(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(ROLE$0, i);
                target.setEnumValue(role);
            }
        }
        
        /**
         * Appends the value as the last "role" element
         */
        public void addRole(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROLE$0);
                target.setEnumValue(role);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType insertNewRole(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().insert_element_user(ROLE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType addNewRole()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().add_element_user(ROLE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "role" element
         */
        public void removeRole(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROLE$0, i);
            }
        }
    }
    /**
     * An XML zRoles(@http://www.tmforum.org/mtop/nrf/xsd/snc/v1).
     *
     * This is a complex type.
     */
    public static class ZRolesImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles
    {
        
        public ZRolesImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROLE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "role");
        
        
        /**
         * Gets a List of "role" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum> getRoleList()
        {
            final class RoleList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum get(int i)
                    { return ZRolesImpl.this.getRoleArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum set(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum old = ZRolesImpl.this.getRoleArray(i);
                    ZRolesImpl.this.setRoleArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum o)
                    { ZRolesImpl.this.insertRole(i, o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum old = ZRolesImpl.this.getRoleArray(i);
                    ZRolesImpl.this.removeRole(i);
                    return old;
                }
                
                public int size()
                    { return ZRolesImpl.this.sizeOfRoleArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new RoleList();
            }
        }
        
        /**
         * Gets array of all "role" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] getRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ROLE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] result = new org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
                return result;
            }
        }
        
        /**
         * Gets ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum getRoleArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "role" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType> xgetRoleList()
        {
            final class RoleList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType get(int i)
                    { return ZRolesImpl.this.xgetRoleArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType set(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType old = ZRolesImpl.this.xgetRoleArray(i);
                    ZRolesImpl.this.xsetRoleArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType o)
                    { ZRolesImpl.this.insertNewRole(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType old = ZRolesImpl.this.xgetRoleArray(i);
                    ZRolesImpl.this.removeRole(i);
                    return old;
                }
                
                public int size()
                    { return ZRolesImpl.this.sizeOfRoleArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new RoleList();
            }
        }
        
        /**
         * Gets (as xml) array of all "role" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[] xgetRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ROLE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[] result = new org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType xgetRoleArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)target;
            }
        }
        
        /**
         * Returns number of "role" element
         */
        public int sizeOfRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROLE$0);
            }
        }
        
        /**
         * Sets array of all "role" element
         */
        public void setRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] roleArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(roleArray, ROLE$0);
            }
        }
        
        /**
         * Sets ith "role" element
         */
        public void setRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setEnumValue(role);
            }
        }
        
        /**
         * Sets (as xml) array of all "role" element
         */
        public void xsetRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[]roleArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(roleArray, ROLE$0);
            }
        }
        
        /**
         * Sets (as xml) ith "role" element
         */
        public void xsetRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(role);
            }
        }
        
        /**
         * Inserts the value as the ith "role" element
         */
        public void insertRole(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(ROLE$0, i);
                target.setEnumValue(role);
            }
        }
        
        /**
         * Appends the value as the last "role" element
         */
        public void addRole(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROLE$0);
                target.setEnumValue(role);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType insertNewRole(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().insert_element_user(ROLE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType addNewRole()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().add_element_user(ROLE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "role" element
         */
        public void removeRole(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROLE$0, i);
            }
        }
    }
}
