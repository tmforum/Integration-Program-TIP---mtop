/*
 * An XML document type.
 * Localname: setRoutesAdminStateResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one setRoutesAdminStateResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SetRoutesAdminStateResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument
{
    
    public SetRoutesAdminStateResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETROUTESADMINSTATERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "setRoutesAdminStateResponse");
    
    
    /**
     * Gets the "setRoutesAdminStateResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse getSetRoutesAdminStateResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse)get_store().find_element_user(SETROUTESADMINSTATERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setRoutesAdminStateResponse" element
     */
    public void setSetRoutesAdminStateResponse(org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse setRoutesAdminStateResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse)get_store().find_element_user(SETROUTESADMINSTATERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse)get_store().add_element_user(SETROUTESADMINSTATERESPONSE$0);
            }
            target.set(setRoutesAdminStateResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setRoutesAdminStateResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse addNewSetRoutesAdminStateResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse)get_store().add_element_user(SETROUTESADMINSTATERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setRoutesAdminStateResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SetRoutesAdminStateResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateResponseDocument.SetRoutesAdminStateResponse
    {
        
        public SetRoutesAdminStateResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROUTENAMEANDADMINSTATELIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "routeNameAndAdminStateList");
        private static final javax.xml.namespace.QName SNCSTATE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "sncState");
        
        
        /**
         * Gets the "routeNameAndAdminStateList" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType getRouteNameAndAdminStateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType)get_store().find_element_user(ROUTENAMEANDADMINSTATELIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "routeNameAndAdminStateList" element
         */
        public boolean isSetRouteNameAndAdminStateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROUTENAMEANDADMINSTATELIST$0) != 0;
            }
        }
        
        /**
         * Sets the "routeNameAndAdminStateList" element
         */
        public void setRouteNameAndAdminStateList(org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType routeNameAndAdminStateList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType)get_store().find_element_user(ROUTENAMEANDADMINSTATELIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType)get_store().add_element_user(ROUTENAMEANDADMINSTATELIST$0);
                }
                target.set(routeNameAndAdminStateList);
            }
        }
        
        /**
         * Appends and returns a new empty "routeNameAndAdminStateList" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType addNewRouteNameAndAdminStateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType)get_store().add_element_user(ROUTENAMEANDADMINSTATELIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "routeNameAndAdminStateList" element
         */
        public void unsetRouteNameAndAdminStateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROUTENAMEANDADMINSTATELIST$0, 0);
            }
        }
        
        /**
         * Gets the "sncState" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum getSncState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCSTATE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "sncState" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType xgetSncState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().find_element_user(SNCSTATE$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "sncState" element
         */
        public boolean isSetSncState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNCSTATE$2) != 0;
            }
        }
        
        /**
         * Sets the "sncState" element
         */
        public void setSncState(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum sncState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCSTATE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SNCSTATE$2);
                }
                target.setEnumValue(sncState);
            }
        }
        
        /**
         * Sets (as xml) the "sncState" element
         */
        public void xsetSncState(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType sncState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().find_element_user(SNCSTATE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().add_element_user(SNCSTATE$2);
                }
                target.set(sncState);
            }
        }
        
        /**
         * Unsets the "sncState" element
         */
        public void unsetSncState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNCSTATE$2, 0);
            }
        }
    }
}
