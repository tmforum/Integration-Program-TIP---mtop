/*
 * XML Type:  TerminationPointListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tp.v1.impl;
/**
 * An XML TerminationPointListType(@http://www.tmforum.org/mtop/nrf/xsd/tp/v1).
 *
 * This is a complex type.
 */
public class TerminationPointListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointListType
{
    
    public TerminationPointListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tp/v1", "tp");
    
    
    /**
     * Gets a List of "tp" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType> getTpList()
    {
        final class TpList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType>
        {
            public org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType get(int i)
                { return TerminationPointListTypeImpl.this.getTpArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType set(int i, org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType o)
            {
                org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType old = TerminationPointListTypeImpl.this.getTpArray(i);
                TerminationPointListTypeImpl.this.setTpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType o)
                { TerminationPointListTypeImpl.this.insertNewTp(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType old = TerminationPointListTypeImpl.this.getTpArray(i);
                TerminationPointListTypeImpl.this.removeTp(i);
                return old;
            }
            
            public int size()
                { return TerminationPointListTypeImpl.this.sizeOfTpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TpList();
        }
    }
    
    /**
     * Gets array of all "tp" elements
     */
    public org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType[] getTpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TP$0, targetList);
            org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType[] result = new org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "tp" element
     */
    public org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType getTpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType)get_store().find_element_user(TP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "tp" element
     */
    public int sizeOfTpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TP$0);
        }
    }
    
    /**
     * Sets array of all "tp" element
     */
    public void setTpArray(org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType[] tpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(tpArray, TP$0);
        }
    }
    
    /**
     * Sets ith "tp" element
     */
    public void setTpArray(int i, org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType tp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType)get_store().find_element_user(TP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(tp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tp" element
     */
    public org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType insertNewTp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType)get_store().insert_element_user(TP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tp" element
     */
    public org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType addNewTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType)get_store().add_element_user(TP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "tp" element
     */
    public void removeTp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TP$0, i);
        }
    }
}
