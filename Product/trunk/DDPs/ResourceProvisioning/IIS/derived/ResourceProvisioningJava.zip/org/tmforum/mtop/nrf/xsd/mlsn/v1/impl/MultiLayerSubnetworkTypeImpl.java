/*
 * XML Type:  MultiLayerSubnetworkType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mlsn.v1.impl;
/**
 * An XML MultiLayerSubnetworkType(@http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1).
 *
 * This is a complex type.
 */
public class MultiLayerSubnetworkTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType
{
    
    public MultiLayerSubnetworkTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SUBNETWORKTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "subnetworkType");
    private static final javax.xml.namespace.QName SUPPORTEDRATES$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "supportedRates");
    private static final javax.xml.namespace.QName LAYEREDROUTINGAREALIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "layeredRoutingAreaList");
    private static final javax.xml.namespace.QName ROUTINGAREALEVEL$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "routingAreaLevel");
    private static final javax.xml.namespace.QName SRG$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "srg");
    private static final javax.xml.namespace.QName SUPERIORMLRA$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "superiorMlra");
    private static final javax.xml.namespace.QName SUPPORTINGMENAME$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "supportingMeName");
    private static final javax.xml.namespace.QName SUPPORTINGMLSNLIST$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "supportingMlsnList");
    
    
    /**
     * Gets the "subnetworkType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TopologyType getSubnetworkType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TopologyType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TopologyType)get_store().find_element_user(SUBNETWORKTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "subnetworkType" element
     */
    public boolean isNilSubnetworkType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TopologyType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TopologyType)get_store().find_element_user(SUBNETWORKTYPE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "subnetworkType" element
     */
    public boolean isSetSubnetworkType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUBNETWORKTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "subnetworkType" element
     */
    public void setSubnetworkType(org.tmforum.mtop.nrf.xsd.com.v1.TopologyType subnetworkType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TopologyType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TopologyType)get_store().find_element_user(SUBNETWORKTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TopologyType)get_store().add_element_user(SUBNETWORKTYPE$0);
            }
            target.set(subnetworkType);
        }
    }
    
    /**
     * Appends and returns a new empty "subnetworkType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TopologyType addNewSubnetworkType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TopologyType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TopologyType)get_store().add_element_user(SUBNETWORKTYPE$0);
            return target;
        }
    }
    
    /**
     * Nils the "subnetworkType" element
     */
    public void setNilSubnetworkType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TopologyType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TopologyType)get_store().find_element_user(SUBNETWORKTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TopologyType)get_store().add_element_user(SUBNETWORKTYPE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "subnetworkType" element
     */
    public void unsetSubnetworkType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUBNETWORKTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "supportedRates" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getSupportedRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(SUPPORTEDRATES$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "supportedRates" element
     */
    public boolean isNilSupportedRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(SUPPORTEDRATES$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "supportedRates" element
     */
    public boolean isSetSupportedRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTEDRATES$2) != 0;
        }
    }
    
    /**
     * Sets the "supportedRates" element
     */
    public void setSupportedRates(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType supportedRates)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(SUPPORTEDRATES$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(SUPPORTEDRATES$2);
            }
            target.set(supportedRates);
        }
    }
    
    /**
     * Appends and returns a new empty "supportedRates" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewSupportedRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(SUPPORTEDRATES$2);
            return target;
        }
    }
    
    /**
     * Nils the "supportedRates" element
     */
    public void setNilSupportedRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(SUPPORTEDRATES$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(SUPPORTEDRATES$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "supportedRates" element
     */
    public void unsetSupportedRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTEDRATES$2, 0);
        }
    }
    
    /**
     * Gets the "layeredRoutingAreaList" element
     */
    public java.lang.String getLayeredRoutingAreaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAYEREDROUTINGAREALIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "layeredRoutingAreaList" element
     */
    public org.apache.xmlbeans.XmlString xgetLayeredRoutingAreaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LAYEREDROUTINGAREALIST$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "layeredRoutingAreaList" element
     */
    public boolean isNilLayeredRoutingAreaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LAYEREDROUTINGAREALIST$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "layeredRoutingAreaList" element
     */
    public boolean isSetLayeredRoutingAreaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYEREDROUTINGAREALIST$4) != 0;
        }
    }
    
    /**
     * Sets the "layeredRoutingAreaList" element
     */
    public void setLayeredRoutingAreaList(java.lang.String layeredRoutingAreaList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAYEREDROUTINGAREALIST$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LAYEREDROUTINGAREALIST$4);
            }
            target.setStringValue(layeredRoutingAreaList);
        }
    }
    
    /**
     * Sets (as xml) the "layeredRoutingAreaList" element
     */
    public void xsetLayeredRoutingAreaList(org.apache.xmlbeans.XmlString layeredRoutingAreaList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LAYEREDROUTINGAREALIST$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(LAYEREDROUTINGAREALIST$4);
            }
            target.set(layeredRoutingAreaList);
        }
    }
    
    /**
     * Nils the "layeredRoutingAreaList" element
     */
    public void setNilLayeredRoutingAreaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(LAYEREDROUTINGAREALIST$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(LAYEREDROUTINGAREALIST$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "layeredRoutingAreaList" element
     */
    public void unsetLayeredRoutingAreaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYEREDROUTINGAREALIST$4, 0);
        }
    }
    
    /**
     * Gets the "routingAreaLevel" element
     */
    public java.lang.String getRoutingAreaLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTINGAREALEVEL$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routingAreaLevel" element
     */
    public org.apache.xmlbeans.XmlString xgetRoutingAreaLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGAREALEVEL$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routingAreaLevel" element
     */
    public boolean isNilRoutingAreaLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGAREALEVEL$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routingAreaLevel" element
     */
    public boolean isSetRoutingAreaLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTINGAREALEVEL$6) != 0;
        }
    }
    
    /**
     * Sets the "routingAreaLevel" element
     */
    public void setRoutingAreaLevel(java.lang.String routingAreaLevel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTINGAREALEVEL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTINGAREALEVEL$6);
            }
            target.setStringValue(routingAreaLevel);
        }
    }
    
    /**
     * Sets (as xml) the "routingAreaLevel" element
     */
    public void xsetRoutingAreaLevel(org.apache.xmlbeans.XmlString routingAreaLevel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGAREALEVEL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTINGAREALEVEL$6);
            }
            target.set(routingAreaLevel);
        }
    }
    
    /**
     * Nils the "routingAreaLevel" element
     */
    public void setNilRoutingAreaLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGAREALEVEL$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTINGAREALEVEL$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routingAreaLevel" element
     */
    public void unsetRoutingAreaLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTINGAREALEVEL$6, 0);
        }
    }
    
    /**
     * Gets the "srg" element
     */
    public java.lang.String getSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SRG$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "srg" element
     */
    public org.apache.xmlbeans.XmlString xgetSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SRG$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "srg" element
     */
    public boolean isNilSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SRG$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "srg" element
     */
    public boolean isSetSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SRG$8) != 0;
        }
    }
    
    /**
     * Sets the "srg" element
     */
    public void setSrg(java.lang.String srg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SRG$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SRG$8);
            }
            target.setStringValue(srg);
        }
    }
    
    /**
     * Sets (as xml) the "srg" element
     */
    public void xsetSrg(org.apache.xmlbeans.XmlString srg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SRG$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SRG$8);
            }
            target.set(srg);
        }
    }
    
    /**
     * Nils the "srg" element
     */
    public void setNilSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SRG$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SRG$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "srg" element
     */
    public void unsetSrg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SRG$8, 0);
        }
    }
    
    /**
     * Gets the "superiorMlra" element
     */
    public java.lang.String getSuperiorMlra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPERIORMLRA$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "superiorMlra" element
     */
    public org.apache.xmlbeans.XmlString xgetSuperiorMlra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPERIORMLRA$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "superiorMlra" element
     */
    public boolean isNilSuperiorMlra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPERIORMLRA$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "superiorMlra" element
     */
    public boolean isSetSuperiorMlra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPERIORMLRA$10) != 0;
        }
    }
    
    /**
     * Sets the "superiorMlra" element
     */
    public void setSuperiorMlra(java.lang.String superiorMlra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPERIORMLRA$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUPERIORMLRA$10);
            }
            target.setStringValue(superiorMlra);
        }
    }
    
    /**
     * Sets (as xml) the "superiorMlra" element
     */
    public void xsetSuperiorMlra(org.apache.xmlbeans.XmlString superiorMlra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPERIORMLRA$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPERIORMLRA$10);
            }
            target.set(superiorMlra);
        }
    }
    
    /**
     * Nils the "superiorMlra" element
     */
    public void setNilSuperiorMlra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPERIORMLRA$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPERIORMLRA$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "superiorMlra" element
     */
    public void unsetSuperiorMlra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPERIORMLRA$10, 0);
        }
    }
    
    /**
     * Gets the "supportingMeName" element
     */
    public java.lang.String getSupportingMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPPORTINGMENAME$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "supportingMeName" element
     */
    public org.apache.xmlbeans.XmlString xgetSupportingMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGMENAME$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "supportingMeName" element
     */
    public boolean isNilSupportingMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGMENAME$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "supportingMeName" element
     */
    public boolean isSetSupportingMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTINGMENAME$12) != 0;
        }
    }
    
    /**
     * Sets the "supportingMeName" element
     */
    public void setSupportingMeName(java.lang.String supportingMeName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPPORTINGMENAME$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUPPORTINGMENAME$12);
            }
            target.setStringValue(supportingMeName);
        }
    }
    
    /**
     * Sets (as xml) the "supportingMeName" element
     */
    public void xsetSupportingMeName(org.apache.xmlbeans.XmlString supportingMeName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGMENAME$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPPORTINGMENAME$12);
            }
            target.set(supportingMeName);
        }
    }
    
    /**
     * Nils the "supportingMeName" element
     */
    public void setNilSupportingMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGMENAME$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPPORTINGMENAME$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "supportingMeName" element
     */
    public void unsetSupportingMeName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTINGMENAME$12, 0);
        }
    }
    
    /**
     * Gets the "supportingMlsnList" element
     */
    public java.lang.String getSupportingMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPPORTINGMLSNLIST$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "supportingMlsnList" element
     */
    public org.apache.xmlbeans.XmlString xgetSupportingMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGMLSNLIST$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "supportingMlsnList" element
     */
    public boolean isNilSupportingMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGMLSNLIST$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "supportingMlsnList" element
     */
    public boolean isSetSupportingMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTINGMLSNLIST$14) != 0;
        }
    }
    
    /**
     * Sets the "supportingMlsnList" element
     */
    public void setSupportingMlsnList(java.lang.String supportingMlsnList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPPORTINGMLSNLIST$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUPPORTINGMLSNLIST$14);
            }
            target.setStringValue(supportingMlsnList);
        }
    }
    
    /**
     * Sets (as xml) the "supportingMlsnList" element
     */
    public void xsetSupportingMlsnList(org.apache.xmlbeans.XmlString supportingMlsnList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGMLSNLIST$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPPORTINGMLSNLIST$14);
            }
            target.set(supportingMlsnList);
        }
    }
    
    /**
     * Nils the "supportingMlsnList" element
     */
    public void setNilSupportingMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SUPPORTINGMLSNLIST$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SUPPORTINGMLSNLIST$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "supportingMlsnList" element
     */
    public void unsetSupportingMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTINGMLSNLIST$14, 0);
        }
    }
}
