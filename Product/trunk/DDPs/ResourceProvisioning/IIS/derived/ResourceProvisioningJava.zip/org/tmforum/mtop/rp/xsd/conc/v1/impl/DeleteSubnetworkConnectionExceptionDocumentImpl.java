/*
 * An XML document type.
 * Localname: deleteSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one deleteSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class DeleteSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument
{
    
    public DeleteSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETESUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "deleteSubnetworkConnectionException");
    
    
    /**
     * Gets the "deleteSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException getDeleteSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException)get_store().find_element_user(DELETESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteSubnetworkConnectionException" element
     */
    public void setDeleteSubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException deleteSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException)get_store().find_element_user(DELETESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException)get_store().add_element_user(DELETESUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(deleteSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException addNewDeleteSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException)get_store().add_element_user(DELETESUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deleteSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class DeleteSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionExceptionDocument.DeleteSubnetworkConnectionException
    {
        
        public DeleteSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
