/*
 * XML Type:  EquipmentType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/eq/v1
 * Java type: org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.eq.v1;


/**
 * An XML EquipmentType(@http://www.tmforum.org/mtop/nrf/xsd/eq/v1).
 *
 * This is a complex type.
 */
public interface EquipmentType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EquipmentType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("equipmenttype8a7dtype");
    
    /**
     * Gets the "alarmReportingIndicator" element
     */
    boolean getAlarmReportingIndicator();
    
    /**
     * Gets (as xml) the "alarmReportingIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType xgetAlarmReportingIndicator();
    
    /**
     * Tests for nil "alarmReportingIndicator" element
     */
    boolean isNilAlarmReportingIndicator();
    
    /**
     * True if has "alarmReportingIndicator" element
     */
    boolean isSetAlarmReportingIndicator();
    
    /**
     * Sets the "alarmReportingIndicator" element
     */
    void setAlarmReportingIndicator(boolean alarmReportingIndicator);
    
    /**
     * Sets (as xml) the "alarmReportingIndicator" element
     */
    void xsetAlarmReportingIndicator(org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType alarmReportingIndicator);
    
    /**
     * Nils the "alarmReportingIndicator" element
     */
    void setNilAlarmReportingIndicator();
    
    /**
     * Unsets the "alarmReportingIndicator" element
     */
    void unsetAlarmReportingIndicator();
    
    /**
     * Gets the "expectedEquipmentObjectType" element
     */
    java.lang.String getExpectedEquipmentObjectType();
    
    /**
     * Gets (as xml) the "expectedEquipmentObjectType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType xgetExpectedEquipmentObjectType();
    
    /**
     * Tests for nil "expectedEquipmentObjectType" element
     */
    boolean isNilExpectedEquipmentObjectType();
    
    /**
     * True if has "expectedEquipmentObjectType" element
     */
    boolean isSetExpectedEquipmentObjectType();
    
    /**
     * Sets the "expectedEquipmentObjectType" element
     */
    void setExpectedEquipmentObjectType(java.lang.String expectedEquipmentObjectType);
    
    /**
     * Sets (as xml) the "expectedEquipmentObjectType" element
     */
    void xsetExpectedEquipmentObjectType(org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType expectedEquipmentObjectType);
    
    /**
     * Nils the "expectedEquipmentObjectType" element
     */
    void setNilExpectedEquipmentObjectType();
    
    /**
     * Unsets the "expectedEquipmentObjectType" element
     */
    void unsetExpectedEquipmentObjectType();
    
    /**
     * Gets the "installedEquipmentObjectType" element
     */
    java.lang.String getInstalledEquipmentObjectType();
    
    /**
     * Gets (as xml) the "installedEquipmentObjectType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType xgetInstalledEquipmentObjectType();
    
    /**
     * Tests for nil "installedEquipmentObjectType" element
     */
    boolean isNilInstalledEquipmentObjectType();
    
    /**
     * True if has "installedEquipmentObjectType" element
     */
    boolean isSetInstalledEquipmentObjectType();
    
    /**
     * Sets the "installedEquipmentObjectType" element
     */
    void setInstalledEquipmentObjectType(java.lang.String installedEquipmentObjectType);
    
    /**
     * Sets (as xml) the "installedEquipmentObjectType" element
     */
    void xsetInstalledEquipmentObjectType(org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType installedEquipmentObjectType);
    
    /**
     * Nils the "installedEquipmentObjectType" element
     */
    void setNilInstalledEquipmentObjectType();
    
    /**
     * Unsets the "installedEquipmentObjectType" element
     */
    void unsetInstalledEquipmentObjectType();
    
    /**
     * Gets the "installedPartNumber" element
     */
    java.lang.String getInstalledPartNumber();
    
    /**
     * Gets (as xml) the "installedPartNumber" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType xgetInstalledPartNumber();
    
    /**
     * Tests for nil "installedPartNumber" element
     */
    boolean isNilInstalledPartNumber();
    
    /**
     * True if has "installedPartNumber" element
     */
    boolean isSetInstalledPartNumber();
    
    /**
     * Sets the "installedPartNumber" element
     */
    void setInstalledPartNumber(java.lang.String installedPartNumber);
    
    /**
     * Sets (as xml) the "installedPartNumber" element
     */
    void xsetInstalledPartNumber(org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType installedPartNumber);
    
    /**
     * Nils the "installedPartNumber" element
     */
    void setNilInstalledPartNumber();
    
    /**
     * Unsets the "installedPartNumber" element
     */
    void unsetInstalledPartNumber();
    
    /**
     * Gets the "installedSerialNumber" element
     */
    java.lang.String getInstalledSerialNumber();
    
    /**
     * Gets (as xml) the "installedSerialNumber" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType xgetInstalledSerialNumber();
    
    /**
     * Tests for nil "installedSerialNumber" element
     */
    boolean isNilInstalledSerialNumber();
    
    /**
     * True if has "installedSerialNumber" element
     */
    boolean isSetInstalledSerialNumber();
    
    /**
     * Sets the "installedSerialNumber" element
     */
    void setInstalledSerialNumber(java.lang.String installedSerialNumber);
    
    /**
     * Sets (as xml) the "installedSerialNumber" element
     */
    void xsetInstalledSerialNumber(org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType installedSerialNumber);
    
    /**
     * Nils the "installedSerialNumber" element
     */
    void setNilInstalledSerialNumber();
    
    /**
     * Unsets the "installedSerialNumber" element
     */
    void unsetInstalledSerialNumber();
    
    /**
     * Gets the "resourceFulfillmentState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum getResourceFulfillmentState();
    
    /**
     * Gets (as xml) the "resourceFulfillmentState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType xgetResourceFulfillmentState();
    
    /**
     * Tests for nil "resourceFulfillmentState" element
     */
    boolean isNilResourceFulfillmentState();
    
    /**
     * True if has "resourceFulfillmentState" element
     */
    boolean isSetResourceFulfillmentState();
    
    /**
     * Sets the "resourceFulfillmentState" element
     */
    void setResourceFulfillmentState(org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum resourceFulfillmentState);
    
    /**
     * Sets (as xml) the "resourceFulfillmentState" element
     */
    void xsetResourceFulfillmentState(org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType resourceFulfillmentState);
    
    /**
     * Nils the "resourceFulfillmentState" element
     */
    void setNilResourceFulfillmentState();
    
    /**
     * Unsets the "resourceFulfillmentState" element
     */
    void unsetResourceFulfillmentState();
    
    /**
     * Gets the "installedVersion" element
     */
    java.lang.String getInstalledVersion();
    
    /**
     * Gets (as xml) the "installedVersion" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType xgetInstalledVersion();
    
    /**
     * Tests for nil "installedVersion" element
     */
    boolean isNilInstalledVersion();
    
    /**
     * True if has "installedVersion" element
     */
    boolean isSetInstalledVersion();
    
    /**
     * Sets the "installedVersion" element
     */
    void setInstalledVersion(java.lang.String installedVersion);
    
    /**
     * Sets (as xml) the "installedVersion" element
     */
    void xsetInstalledVersion(org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType installedVersion);
    
    /**
     * Nils the "installedVersion" element
     */
    void setNilInstalledVersion();
    
    /**
     * Unsets the "installedVersion" element
     */
    void unsetInstalledVersion();
    
    /**
     * Gets the "manufacturer" element
     */
    java.lang.String getManufacturer();
    
    /**
     * Gets (as xml) the "manufacturer" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType xgetManufacturer();
    
    /**
     * Tests for nil "manufacturer" element
     */
    boolean isNilManufacturer();
    
    /**
     * True if has "manufacturer" element
     */
    boolean isSetManufacturer();
    
    /**
     * Sets the "manufacturer" element
     */
    void setManufacturer(java.lang.String manufacturer);
    
    /**
     * Sets (as xml) the "manufacturer" element
     */
    void xsetManufacturer(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType manufacturer);
    
    /**
     * Nils the "manufacturer" element
     */
    void setNilManufacturer();
    
    /**
     * Unsets the "manufacturer" element
     */
    void unsetManufacturer();
    
    /**
     * Gets the "protectionRole" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType getProtectionRole();
    
    /**
     * Tests for nil "protectionRole" element
     */
    boolean isNilProtectionRole();
    
    /**
     * True if has "protectionRole" element
     */
    boolean isSetProtectionRole();
    
    /**
     * Sets the "protectionRole" element
     */
    void setProtectionRole(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType protectionRole);
    
    /**
     * Appends and returns a new empty "protectionRole" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType addNewProtectionRole();
    
    /**
     * Nils the "protectionRole" element
     */
    void setNilProtectionRole();
    
    /**
     * Unsets the "protectionRole" element
     */
    void unsetProtectionRole();
    
    /**
     * Gets the "protectionSchemeState" element
     */
    org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType getProtectionSchemeState();
    
    /**
     * Tests for nil "protectionSchemeState" element
     */
    boolean isNilProtectionSchemeState();
    
    /**
     * True if has "protectionSchemeState" element
     */
    boolean isSetProtectionSchemeState();
    
    /**
     * Sets the "protectionSchemeState" element
     */
    void setProtectionSchemeState(org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType protectionSchemeState);
    
    /**
     * Appends and returns a new empty "protectionSchemeState" element
     */
    org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType addNewProtectionSchemeState();
    
    /**
     * Nils the "protectionSchemeState" element
     */
    void setNilProtectionSchemeState();
    
    /**
     * Unsets the "protectionSchemeState" element
     */
    void unsetProtectionSchemeState();
    
    /**
     * Gets the "manufacturerDate" element
     */
    java.util.Calendar getManufacturerDate();
    
    /**
     * Gets (as xml) the "manufacturerDate" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType xgetManufacturerDate();
    
    /**
     * Tests for nil "manufacturerDate" element
     */
    boolean isNilManufacturerDate();
    
    /**
     * True if has "manufacturerDate" element
     */
    boolean isSetManufacturerDate();
    
    /**
     * Sets the "manufacturerDate" element
     */
    void setManufacturerDate(java.util.Calendar manufacturerDate);
    
    /**
     * Sets (as xml) the "manufacturerDate" element
     */
    void xsetManufacturerDate(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType manufacturerDate);
    
    /**
     * Nils the "manufacturerDate" element
     */
    void setNilManufacturerDate();
    
    /**
     * Unsets the "manufacturerDate" element
     */
    void unsetManufacturerDate();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
