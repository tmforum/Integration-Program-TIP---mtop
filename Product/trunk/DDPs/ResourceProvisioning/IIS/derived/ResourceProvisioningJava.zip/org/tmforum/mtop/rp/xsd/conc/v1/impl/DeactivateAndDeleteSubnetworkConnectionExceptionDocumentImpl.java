/*
 * An XML document type.
 * Localname: deactivateAndDeleteSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one deactivateAndDeleteSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class DeactivateAndDeleteSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument
{
    
    public DeactivateAndDeleteSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DEACTIVATEANDDELETESUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "deactivateAndDeleteSubnetworkConnectionException");
    
    
    /**
     * Gets the "deactivateAndDeleteSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException getDeactivateAndDeleteSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException)get_store().find_element_user(DEACTIVATEANDDELETESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deactivateAndDeleteSubnetworkConnectionException" element
     */
    public void setDeactivateAndDeleteSubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException deactivateAndDeleteSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException)get_store().find_element_user(DEACTIVATEANDDELETESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException)get_store().add_element_user(DEACTIVATEANDDELETESUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(deactivateAndDeleteSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "deactivateAndDeleteSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException addNewDeactivateAndDeleteSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException)get_store().add_element_user(DEACTIVATEANDDELETESUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deactivateAndDeleteSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class DeactivateAndDeleteSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionExceptionDocument.DeactivateAndDeleteSubnetworkConnectionException
    {
        
        public DeactivateAndDeleteSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
