/*
 * An XML document type.
 * Localname: fd
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fd.v1.FdDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fd.v1.impl;
/**
 * A document containing one fd(@http://www.tmforum.org/mtop/nrf/xsd/fd/v1) element.
 *
 * This is a complex type.
 */
public class FdDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.fd.v1.FdDocument
{
    
    public FdDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fd/v1", "fd");
    
    
    /**
     * Gets the "fd" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType getFd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FD$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "fd" element
     */
    public void setFd(org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType fd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FD$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FD$0);
            }
            target.set(fd);
        }
    }
    
    /**
     * Appends and returns a new empty "fd" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType addNewFd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FD$0);
            return target;
        }
    }
}
