/*
 * An XML document type.
 * Localname: deactivateSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one deactivateSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class DeactivateSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument
{
    
    public DeactivateSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DEACTIVATESUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "deactivateSubnetworkConnectionException");
    
    
    /**
     * Gets the "deactivateSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException getDeactivateSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException)get_store().find_element_user(DEACTIVATESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deactivateSubnetworkConnectionException" element
     */
    public void setDeactivateSubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException deactivateSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException)get_store().find_element_user(DEACTIVATESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException)get_store().add_element_user(DEACTIVATESUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(deactivateSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "deactivateSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException addNewDeactivateSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException)get_store().add_element_user(DEACTIVATESUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deactivateSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class DeactivateSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeactivateSubnetworkConnectionExceptionDocument.DeactivateSubnetworkConnectionException
    {
        
        public DeactivateSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
