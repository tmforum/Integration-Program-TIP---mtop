/*
 * An XML document type.
 * Localname: setRoutesAdminStateRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one setRoutesAdminStateRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SetRoutesAdminStateRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument
{
    
    public SetRoutesAdminStateRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETROUTESADMINSTATEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "setRoutesAdminStateRequest");
    
    
    /**
     * Gets the "setRoutesAdminStateRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest getSetRoutesAdminStateRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest)get_store().find_element_user(SETROUTESADMINSTATEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setRoutesAdminStateRequest" element
     */
    public void setSetRoutesAdminStateRequest(org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest setRoutesAdminStateRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest)get_store().find_element_user(SETROUTESADMINSTATEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest)get_store().add_element_user(SETROUTESADMINSTATEREQUEST$0);
            }
            target.set(setRoutesAdminStateRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setRoutesAdminStateRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest addNewSetRoutesAdminStateRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest)get_store().add_element_user(SETROUTESADMINSTATEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setRoutesAdminStateRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SetRoutesAdminStateRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateRequestDocument.SetRoutesAdminStateRequest
    {
        
        public SetRoutesAdminStateRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNCNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "sncName");
        private static final javax.xml.namespace.QName ROUTENAMEANDADMINSTATELIST$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "routeNameAndAdminStateList");
        
        
        /**
         * Gets the "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "sncName" element
         */
        public boolean isSetSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNCNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "sncName" element
         */
        public void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType sncName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SNCNAME$0);
                }
                target.set(sncName);
            }
        }
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SNCNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "sncName" element
         */
        public void unsetSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNCNAME$0, 0);
            }
        }
        
        /**
         * Gets the "routeNameAndAdminStateList" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType getRouteNameAndAdminStateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType)get_store().find_element_user(ROUTENAMEANDADMINSTATELIST$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "routeNameAndAdminStateList" element
         */
        public boolean isSetRouteNameAndAdminStateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROUTENAMEANDADMINSTATELIST$2) != 0;
            }
        }
        
        /**
         * Sets the "routeNameAndAdminStateList" element
         */
        public void setRouteNameAndAdminStateList(org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType routeNameAndAdminStateList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType)get_store().find_element_user(ROUTENAMEANDADMINSTATELIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType)get_store().add_element_user(ROUTENAMEANDADMINSTATELIST$2);
                }
                target.set(routeNameAndAdminStateList);
            }
        }
        
        /**
         * Appends and returns a new empty "routeNameAndAdminStateList" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType addNewRouteNameAndAdminStateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateListType)get_store().add_element_user(ROUTENAMEANDADMINSTATELIST$2);
                return target;
            }
        }
        
        /**
         * Unsets the "routeNameAndAdminStateList" element
         */
        public void unsetRouteNameAndAdminStateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROUTENAMEANDADMINSTATELIST$2, 0);
            }
        }
    }
}
