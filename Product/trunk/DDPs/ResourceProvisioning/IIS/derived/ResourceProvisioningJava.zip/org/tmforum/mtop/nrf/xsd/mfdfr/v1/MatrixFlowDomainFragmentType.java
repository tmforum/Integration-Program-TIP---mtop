/*
 * XML Type:  MatrixFlowDomainFragmentType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mfdfr.v1;


/**
 * An XML MatrixFlowDomainFragmentType(@http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1).
 *
 * This is a complex type.
 */
public interface MatrixFlowDomainFragmentType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MatrixFlowDomainFragmentType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("matrixflowdomainfragmenttypef64dtype");
    
    /**
     * Gets the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection();
    
    /**
     * Gets (as xml) the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection();
    
    /**
     * Tests for nil "direction" element
     */
    boolean isNilDirection();
    
    /**
     * True if has "direction" element
     */
    boolean isSetDirection();
    
    /**
     * Sets the "direction" element
     */
    void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction);
    
    /**
     * Sets (as xml) the "direction" element
     */
    void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction);
    
    /**
     * Nils the "direction" element
     */
    void setNilDirection();
    
    /**
     * Unsets the "direction" element
     */
    void unsetDirection();
    
    /**
     * Gets the "transmissionParams" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType getTransmissionParams();
    
    /**
     * Tests for nil "transmissionParams" element
     */
    boolean isNilTransmissionParams();
    
    /**
     * True if has "transmissionParams" element
     */
    boolean isSetTransmissionParams();
    
    /**
     * Sets the "transmissionParams" element
     */
    void setTransmissionParams(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType transmissionParams);
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType addNewTransmissionParams();
    
    /**
     * Nils the "transmissionParams" element
     */
    void setNilTransmissionParams();
    
    /**
     * Unsets the "transmissionParams" element
     */
    void unsetTransmissionParams();
    
    /**
     * Gets the "aEnd" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getAEnd();
    
    /**
     * Tests for nil "aEnd" element
     */
    boolean isNilAEnd();
    
    /**
     * True if has "aEnd" element
     */
    boolean isSetAEnd();
    
    /**
     * Sets the "aEnd" element
     */
    void setAEnd(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType aEnd);
    
    /**
     * Appends and returns a new empty "aEnd" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewAEnd();
    
    /**
     * Nils the "aEnd" element
     */
    void setNilAEnd();
    
    /**
     * Unsets the "aEnd" element
     */
    void unsetAEnd();
    
    /**
     * Gets the "zEnd" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getZEnd();
    
    /**
     * Tests for nil "zEnd" element
     */
    boolean isNilZEnd();
    
    /**
     * True if has "zEnd" element
     */
    boolean isSetZEnd();
    
    /**
     * Sets the "zEnd" element
     */
    void setZEnd(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType zEnd);
    
    /**
     * Appends and returns a new empty "zEnd" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewZEnd();
    
    /**
     * Nils the "zEnd" element
     */
    void setNilZEnd();
    
    /**
     * Unsets the "zEnd" element
     */
    void unsetZEnd();
    
    /**
     * Gets the "flexible" element
     */
    boolean getFlexible();
    
    /**
     * Gets (as xml) the "flexible" element
     */
    org.apache.xmlbeans.XmlBoolean xgetFlexible();
    
    /**
     * Tests for nil "flexible" element
     */
    boolean isNilFlexible();
    
    /**
     * True if has "flexible" element
     */
    boolean isSetFlexible();
    
    /**
     * Sets the "flexible" element
     */
    void setFlexible(boolean flexible);
    
    /**
     * Sets (as xml) the "flexible" element
     */
    void xsetFlexible(org.apache.xmlbeans.XmlBoolean flexible);
    
    /**
     * Nils the "flexible" element
     */
    void setNilFlexible();
    
    /**
     * Unsets the "flexible" element
     */
    void unsetFlexible();
    
    /**
     * Gets the "active" element
     */
    boolean getActive();
    
    /**
     * Gets (as xml) the "active" element
     */
    org.apache.xmlbeans.XmlBoolean xgetActive();
    
    /**
     * Tests for nil "active" element
     */
    boolean isNilActive();
    
    /**
     * True if has "active" element
     */
    boolean isSetActive();
    
    /**
     * Sets the "active" element
     */
    void setActive(boolean active);
    
    /**
     * Sets (as xml) the "active" element
     */
    void xsetActive(org.apache.xmlbeans.XmlBoolean active);
    
    /**
     * Nils the "active" element
     */
    void setNilActive();
    
    /**
     * Unsets the "active" element
     */
    void unsetActive();
    
    /**
     * Gets the "mfdfrType" element
     */
    java.lang.String getMfdfrType();
    
    /**
     * Gets (as xml) the "mfdfrType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType xgetMfdfrType();
    
    /**
     * Tests for nil "mfdfrType" element
     */
    boolean isNilMfdfrType();
    
    /**
     * True if has "mfdfrType" element
     */
    boolean isSetMfdfrType();
    
    /**
     * Sets the "mfdfrType" element
     */
    void setMfdfrType(java.lang.String mfdfrType);
    
    /**
     * Sets (as xml) the "mfdfrType" element
     */
    void xsetMfdfrType(org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType mfdfrType);
    
    /**
     * Nils the "mfdfrType" element
     */
    void setNilMfdfrType();
    
    /**
     * Unsets the "mfdfrType" element
     */
    void unsetMfdfrType();
    
    /**
     * Gets the "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
    
    /**
     * True if has "vendorExtensions" element
     */
    boolean isSetVendorExtensions();
    
    /**
     * Sets the "vendorExtensions" element
     */
    void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
    
    /**
     * Unsets the "vendorExtensions" element
     */
    void unsetVendorExtensions();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
