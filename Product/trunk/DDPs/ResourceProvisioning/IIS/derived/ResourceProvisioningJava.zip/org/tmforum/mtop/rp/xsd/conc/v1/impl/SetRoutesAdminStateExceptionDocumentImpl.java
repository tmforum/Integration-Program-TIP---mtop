/*
 * An XML document type.
 * Localname: setRoutesAdminStateException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one setRoutesAdminStateException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SetRoutesAdminStateExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument
{
    
    public SetRoutesAdminStateExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETROUTESADMINSTATEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "setRoutesAdminStateException");
    
    
    /**
     * Gets the "setRoutesAdminStateException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException getSetRoutesAdminStateException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException)get_store().find_element_user(SETROUTESADMINSTATEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setRoutesAdminStateException" element
     */
    public void setSetRoutesAdminStateException(org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException setRoutesAdminStateException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException)get_store().find_element_user(SETROUTESADMINSTATEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException)get_store().add_element_user(SETROUTESADMINSTATEEXCEPTION$0);
            }
            target.set(setRoutesAdminStateException);
        }
    }
    
    /**
     * Appends and returns a new empty "setRoutesAdminStateException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException addNewSetRoutesAdminStateException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException)get_store().add_element_user(SETROUTESADMINSTATEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setRoutesAdminStateException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SetRoutesAdminStateExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetRoutesAdminStateExceptionDocument.SetRoutesAdminStateException
    {
        
        public SetRoutesAdminStateExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
