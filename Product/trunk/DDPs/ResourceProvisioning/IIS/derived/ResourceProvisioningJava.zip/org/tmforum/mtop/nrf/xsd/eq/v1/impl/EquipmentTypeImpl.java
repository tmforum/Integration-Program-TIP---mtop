/*
 * XML Type:  EquipmentType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/eq/v1
 * Java type: org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.eq.v1.impl;
/**
 * An XML EquipmentType(@http://www.tmforum.org/mtop/nrf/xsd/eq/v1).
 *
 * This is a complex type.
 */
public class EquipmentTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType
{
    
    public EquipmentTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARMREPORTINGINDICATOR$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "alarmReportingIndicator");
    private static final javax.xml.namespace.QName EXPECTEDEQUIPMENTOBJECTTYPE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "expectedEquipmentObjectType");
    private static final javax.xml.namespace.QName INSTALLEDEQUIPMENTOBJECTTYPE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "installedEquipmentObjectType");
    private static final javax.xml.namespace.QName INSTALLEDPARTNUMBER$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "installedPartNumber");
    private static final javax.xml.namespace.QName INSTALLEDSERIALNUMBER$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "installedSerialNumber");
    private static final javax.xml.namespace.QName RESOURCEFULFILLMENTSTATE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "resourceFulfillmentState");
    private static final javax.xml.namespace.QName INSTALLEDVERSION$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "installedVersion");
    private static final javax.xml.namespace.QName MANUFACTURER$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "manufacturer");
    private static final javax.xml.namespace.QName PROTECTIONROLE$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "protectionRole");
    private static final javax.xml.namespace.QName PROTECTIONSCHEMESTATE$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "protectionSchemeState");
    private static final javax.xml.namespace.QName MANUFACTURERDATE$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "manufacturerDate");
    private static final javax.xml.namespace.QName ASAPREF$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "asapRef");
    
    
    /**
     * Gets the "alarmReportingIndicator" element
     */
    public boolean getAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "alarmReportingIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType xgetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "alarmReportingIndicator" element
     */
    public boolean isNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "alarmReportingIndicator" element
     */
    public boolean isSetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMREPORTINGINDICATOR$0) != 0;
        }
    }
    
    /**
     * Sets the "alarmReportingIndicator" element
     */
    public void setAlarmReportingIndicator(boolean alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALARMREPORTINGINDICATOR$0);
            }
            target.setBooleanValue(alarmReportingIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "alarmReportingIndicator" element
     */
    public void xsetAlarmReportingIndicator(org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().add_element_user(ALARMREPORTINGINDICATOR$0);
            }
            target.set(alarmReportingIndicator);
        }
    }
    
    /**
     * Nils the "alarmReportingIndicator" element
     */
    public void setNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().add_element_user(ALARMREPORTINGINDICATOR$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "alarmReportingIndicator" element
     */
    public void unsetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMREPORTINGINDICATOR$0, 0);
        }
    }
    
    /**
     * Gets the "expectedEquipmentObjectType" element
     */
    public java.lang.String getExpectedEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "expectedEquipmentObjectType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType xgetExpectedEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "expectedEquipmentObjectType" element
     */
    public boolean isNilExpectedEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "expectedEquipmentObjectType" element
     */
    public boolean isSetExpectedEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXPECTEDEQUIPMENTOBJECTTYPE$2) != 0;
        }
    }
    
    /**
     * Sets the "expectedEquipmentObjectType" element
     */
    public void setExpectedEquipmentObjectType(java.lang.String expectedEquipmentObjectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2);
            }
            target.setStringValue(expectedEquipmentObjectType);
        }
    }
    
    /**
     * Sets (as xml) the "expectedEquipmentObjectType" element
     */
    public void xsetExpectedEquipmentObjectType(org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType expectedEquipmentObjectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().add_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2);
            }
            target.set(expectedEquipmentObjectType);
        }
    }
    
    /**
     * Nils the "expectedEquipmentObjectType" element
     */
    public void setNilExpectedEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().add_element_user(EXPECTEDEQUIPMENTOBJECTTYPE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "expectedEquipmentObjectType" element
     */
    public void unsetExpectedEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXPECTEDEQUIPMENTOBJECTTYPE$2, 0);
        }
    }
    
    /**
     * Gets the "installedEquipmentObjectType" element
     */
    public java.lang.String getInstalledEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "installedEquipmentObjectType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType xgetInstalledEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "installedEquipmentObjectType" element
     */
    public boolean isNilInstalledEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "installedEquipmentObjectType" element
     */
    public boolean isSetInstalledEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSTALLEDEQUIPMENTOBJECTTYPE$4) != 0;
        }
    }
    
    /**
     * Sets the "installedEquipmentObjectType" element
     */
    public void setInstalledEquipmentObjectType(java.lang.String installedEquipmentObjectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4);
            }
            target.setStringValue(installedEquipmentObjectType);
        }
    }
    
    /**
     * Sets (as xml) the "installedEquipmentObjectType" element
     */
    public void xsetInstalledEquipmentObjectType(org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType installedEquipmentObjectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().add_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4);
            }
            target.set(installedEquipmentObjectType);
        }
    }
    
    /**
     * Nils the "installedEquipmentObjectType" element
     */
    public void setNilInstalledEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().add_element_user(INSTALLEDEQUIPMENTOBJECTTYPE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "installedEquipmentObjectType" element
     */
    public void unsetInstalledEquipmentObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSTALLEDEQUIPMENTOBJECTTYPE$4, 0);
        }
    }
    
    /**
     * Gets the "installedPartNumber" element
     */
    public java.lang.String getInstalledPartNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALLEDPARTNUMBER$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "installedPartNumber" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType xgetInstalledPartNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType)get_store().find_element_user(INSTALLEDPARTNUMBER$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "installedPartNumber" element
     */
    public boolean isNilInstalledPartNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType)get_store().find_element_user(INSTALLEDPARTNUMBER$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "installedPartNumber" element
     */
    public boolean isSetInstalledPartNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSTALLEDPARTNUMBER$6) != 0;
        }
    }
    
    /**
     * Sets the "installedPartNumber" element
     */
    public void setInstalledPartNumber(java.lang.String installedPartNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALLEDPARTNUMBER$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSTALLEDPARTNUMBER$6);
            }
            target.setStringValue(installedPartNumber);
        }
    }
    
    /**
     * Sets (as xml) the "installedPartNumber" element
     */
    public void xsetInstalledPartNumber(org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType installedPartNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType)get_store().find_element_user(INSTALLEDPARTNUMBER$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType)get_store().add_element_user(INSTALLEDPARTNUMBER$6);
            }
            target.set(installedPartNumber);
        }
    }
    
    /**
     * Nils the "installedPartNumber" element
     */
    public void setNilInstalledPartNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType)get_store().find_element_user(INSTALLEDPARTNUMBER$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType)get_store().add_element_user(INSTALLEDPARTNUMBER$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "installedPartNumber" element
     */
    public void unsetInstalledPartNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSTALLEDPARTNUMBER$6, 0);
        }
    }
    
    /**
     * Gets the "installedSerialNumber" element
     */
    public java.lang.String getInstalledSerialNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALLEDSERIALNUMBER$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "installedSerialNumber" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType xgetInstalledSerialNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType)get_store().find_element_user(INSTALLEDSERIALNUMBER$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "installedSerialNumber" element
     */
    public boolean isNilInstalledSerialNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType)get_store().find_element_user(INSTALLEDSERIALNUMBER$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "installedSerialNumber" element
     */
    public boolean isSetInstalledSerialNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSTALLEDSERIALNUMBER$8) != 0;
        }
    }
    
    /**
     * Sets the "installedSerialNumber" element
     */
    public void setInstalledSerialNumber(java.lang.String installedSerialNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALLEDSERIALNUMBER$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSTALLEDSERIALNUMBER$8);
            }
            target.setStringValue(installedSerialNumber);
        }
    }
    
    /**
     * Sets (as xml) the "installedSerialNumber" element
     */
    public void xsetInstalledSerialNumber(org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType installedSerialNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType)get_store().find_element_user(INSTALLEDSERIALNUMBER$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType)get_store().add_element_user(INSTALLEDSERIALNUMBER$8);
            }
            target.set(installedSerialNumber);
        }
    }
    
    /**
     * Nils the "installedSerialNumber" element
     */
    public void setNilInstalledSerialNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType)get_store().find_element_user(INSTALLEDSERIALNUMBER$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledSerialNumberType)get_store().add_element_user(INSTALLEDSERIALNUMBER$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "installedSerialNumber" element
     */
    public void unsetInstalledSerialNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSTALLEDSERIALNUMBER$8, 0);
        }
    }
    
    /**
     * Gets the "resourceFulfillmentState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum getResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "resourceFulfillmentState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType xgetResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "resourceFulfillmentState" element
     */
    public boolean isNilResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "resourceFulfillmentState" element
     */
    public boolean isSetResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RESOURCEFULFILLMENTSTATE$10) != 0;
        }
    }
    
    /**
     * Sets the "resourceFulfillmentState" element
     */
    public void setResourceFulfillmentState(org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum resourceFulfillmentState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RESOURCEFULFILLMENTSTATE$10);
            }
            target.setEnumValue(resourceFulfillmentState);
        }
    }
    
    /**
     * Sets (as xml) the "resourceFulfillmentState" element
     */
    public void xsetResourceFulfillmentState(org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType resourceFulfillmentState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().add_element_user(RESOURCEFULFILLMENTSTATE$10);
            }
            target.set(resourceFulfillmentState);
        }
    }
    
    /**
     * Nils the "resourceFulfillmentState" element
     */
    public void setNilResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().add_element_user(RESOURCEFULFILLMENTSTATE$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "resourceFulfillmentState" element
     */
    public void unsetResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RESOURCEFULFILLMENTSTATE$10, 0);
        }
    }
    
    /**
     * Gets the "installedVersion" element
     */
    public java.lang.String getInstalledVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALLEDVERSION$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "installedVersion" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType xgetInstalledVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType)get_store().find_element_user(INSTALLEDVERSION$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "installedVersion" element
     */
    public boolean isNilInstalledVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType)get_store().find_element_user(INSTALLEDVERSION$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "installedVersion" element
     */
    public boolean isSetInstalledVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INSTALLEDVERSION$12) != 0;
        }
    }
    
    /**
     * Sets the "installedVersion" element
     */
    public void setInstalledVersion(java.lang.String installedVersion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INSTALLEDVERSION$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INSTALLEDVERSION$12);
            }
            target.setStringValue(installedVersion);
        }
    }
    
    /**
     * Sets (as xml) the "installedVersion" element
     */
    public void xsetInstalledVersion(org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType installedVersion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType)get_store().find_element_user(INSTALLEDVERSION$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType)get_store().add_element_user(INSTALLEDVERSION$12);
            }
            target.set(installedVersion);
        }
    }
    
    /**
     * Nils the "installedVersion" element
     */
    public void setNilInstalledVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType)get_store().find_element_user(INSTALLEDVERSION$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.InstalledVersionType)get_store().add_element_user(INSTALLEDVERSION$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "installedVersion" element
     */
    public void unsetInstalledVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INSTALLEDVERSION$12, 0);
        }
    }
    
    /**
     * Gets the "manufacturer" element
     */
    public java.lang.String getManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURER$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "manufacturer" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType xgetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "manufacturer" element
     */
    public boolean isNilManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "manufacturer" element
     */
    public boolean isSetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANUFACTURER$14) != 0;
        }
    }
    
    /**
     * Sets the "manufacturer" element
     */
    public void setManufacturer(java.lang.String manufacturer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURER$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MANUFACTURER$14);
            }
            target.setStringValue(manufacturer);
        }
    }
    
    /**
     * Sets (as xml) the "manufacturer" element
     */
    public void xsetManufacturer(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType manufacturer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().add_element_user(MANUFACTURER$14);
            }
            target.set(manufacturer);
        }
    }
    
    /**
     * Nils the "manufacturer" element
     */
    public void setNilManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().add_element_user(MANUFACTURER$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "manufacturer" element
     */
    public void unsetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANUFACTURER$14, 0);
        }
    }
    
    /**
     * Gets the "protectionRole" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType getProtectionRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType)get_store().find_element_user(PROTECTIONROLE$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionRole" element
     */
    public boolean isNilProtectionRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType)get_store().find_element_user(PROTECTIONROLE$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionRole" element
     */
    public boolean isSetProtectionRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONROLE$16) != 0;
        }
    }
    
    /**
     * Sets the "protectionRole" element
     */
    public void setProtectionRole(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType protectionRole)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType)get_store().find_element_user(PROTECTIONROLE$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType)get_store().add_element_user(PROTECTIONROLE$16);
            }
            target.set(protectionRole);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionRole" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType addNewProtectionRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType)get_store().add_element_user(PROTECTIONROLE$16);
            return target;
        }
    }
    
    /**
     * Nils the "protectionRole" element
     */
    public void setNilProtectionRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType)get_store().find_element_user(PROTECTIONROLE$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionRoleType)get_store().add_element_user(PROTECTIONROLE$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionRole" element
     */
    public void unsetProtectionRole()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONROLE$16, 0);
        }
    }
    
    /**
     * Gets the "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType getProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionSchemeState" element
     */
    public boolean isNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionSchemeState" element
     */
    public boolean isSetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONSCHEMESTATE$18) != 0;
        }
    }
    
    /**
     * Sets the "protectionSchemeState" element
     */
    public void setProtectionSchemeState(org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType protectionSchemeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$18);
            }
            target.set(protectionSchemeState);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType addNewProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$18);
            return target;
        }
    }
    
    /**
     * Nils the "protectionSchemeState" element
     */
    public void setNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionSchemeState" element
     */
    public void unsetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONSCHEMESTATE$18, 0);
        }
    }
    
    /**
     * Gets the "manufacturerDate" element
     */
    public java.util.Calendar getManufacturerDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURERDATE$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "manufacturerDate" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType xgetManufacturerDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType)get_store().find_element_user(MANUFACTURERDATE$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "manufacturerDate" element
     */
    public boolean isNilManufacturerDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType)get_store().find_element_user(MANUFACTURERDATE$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "manufacturerDate" element
     */
    public boolean isSetManufacturerDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANUFACTURERDATE$20) != 0;
        }
    }
    
    /**
     * Sets the "manufacturerDate" element
     */
    public void setManufacturerDate(java.util.Calendar manufacturerDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURERDATE$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MANUFACTURERDATE$20);
            }
            target.setCalendarValue(manufacturerDate);
        }
    }
    
    /**
     * Sets (as xml) the "manufacturerDate" element
     */
    public void xsetManufacturerDate(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType manufacturerDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType)get_store().find_element_user(MANUFACTURERDATE$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType)get_store().add_element_user(MANUFACTURERDATE$20);
            }
            target.set(manufacturerDate);
        }
    }
    
    /**
     * Nils the "manufacturerDate" element
     */
    public void setNilManufacturerDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType)get_store().find_element_user(MANUFACTURERDATE$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType)get_store().add_element_user(MANUFACTURERDATE$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "manufacturerDate" element
     */
    public void unsetManufacturerDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANUFACTURERDATE$20, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$22) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$22);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$22);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$22, 0);
        }
    }
}
