/*
 * An XML document type.
 * Localname: checkValidSubnetworkConnectionResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one checkValidSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CheckValidSubnetworkConnectionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument
{
    
    public CheckValidSubnetworkConnectionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHECKVALIDSUBNETWORKCONNECTIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "checkValidSubnetworkConnectionResponse");
    
    
    /**
     * Gets the "checkValidSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse getCheckValidSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse)get_store().find_element_user(CHECKVALIDSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "checkValidSubnetworkConnectionResponse" element
     */
    public void setCheckValidSubnetworkConnectionResponse(org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse checkValidSubnetworkConnectionResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse)get_store().find_element_user(CHECKVALIDSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse)get_store().add_element_user(CHECKVALIDSUBNETWORKCONNECTIONRESPONSE$0);
            }
            target.set(checkValidSubnetworkConnectionResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "checkValidSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse addNewCheckValidSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse)get_store().add_element_user(CHECKVALIDSUBNETWORKCONNECTIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML checkValidSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CheckValidSubnetworkConnectionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionResponseDocument.CheckValidSubnetworkConnectionResponse
    {
        
        public CheckValidSubnetworkConnectionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ISVALID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "isValid");
        
        
        /**
         * Gets the "isValid" element
         */
        public boolean getIsValid()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISVALID$0, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "isValid" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetIsValid()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISVALID$0, 0);
                return target;
            }
        }
        
        /**
         * True if has "isValid" element
         */
        public boolean isSetIsValid()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ISVALID$0) != 0;
            }
        }
        
        /**
         * Sets the "isValid" element
         */
        public void setIsValid(boolean isValid)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISVALID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISVALID$0);
                }
                target.setBooleanValue(isValid);
            }
        }
        
        /**
         * Sets (as xml) the "isValid" element
         */
        public void xsetIsValid(org.apache.xmlbeans.XmlBoolean isValid)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISVALID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISVALID$0);
                }
                target.set(isValid);
            }
        }
        
        /**
         * Unsets the "isValid" element
         */
        public void unsetIsValid()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ISVALID$0, 0);
            }
        }
    }
}
