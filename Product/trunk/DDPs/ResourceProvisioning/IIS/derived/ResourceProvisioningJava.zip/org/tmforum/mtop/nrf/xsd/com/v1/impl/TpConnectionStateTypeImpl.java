/*
 * XML Type:  TpConnectionStateType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/com/v1
 * Java type: org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.com.v1.impl;
/**
 * An XML TpConnectionStateType(@http://www.tmforum.org/mtop/nrf/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.
 */
public class TpConnectionStateTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType
{
    
    public TpConnectionStateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TpConnectionStateTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
