/*
 * XML Type:  NumberOfMembersType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tppool/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfMembersType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tppool.v1.impl;
/**
 * An XML NumberOfMembersType(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfMembersType.
 */
public class NumberOfMembersTypeImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfMembersType
{
    
    public NumberOfMembersTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected NumberOfMembersTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
