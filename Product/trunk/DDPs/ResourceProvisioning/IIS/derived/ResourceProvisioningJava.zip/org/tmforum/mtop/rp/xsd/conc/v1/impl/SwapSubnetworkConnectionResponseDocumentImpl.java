/*
 * An XML document type.
 * Localname: swapSubnetworkConnectionResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one swapSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SwapSubnetworkConnectionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument
{
    
    public SwapSubnetworkConnectionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SWAPSUBNETWORKCONNECTIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "swapSubnetworkConnectionResponse");
    
    
    /**
     * Gets the "swapSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse getSwapSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse)get_store().find_element_user(SWAPSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "swapSubnetworkConnectionResponse" element
     */
    public void setSwapSubnetworkConnectionResponse(org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse swapSubnetworkConnectionResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse)get_store().find_element_user(SWAPSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse)get_store().add_element_user(SWAPSUBNETWORKCONNECTIONRESPONSE$0);
            }
            target.set(swapSubnetworkConnectionResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "swapSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse addNewSwapSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse)get_store().add_element_user(SWAPSUBNETWORKCONNECTIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML swapSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SwapSubnetworkConnectionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionResponseDocument.SwapSubnetworkConnectionResponse
    {
        
        public SwapSubnetworkConnectionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPLISTTOMODIFY$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpListToModify");
        private static final javax.xml.namespace.QName STATEOFACTIVATEDSNC$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "stateOfActivatedSnc");
        private static final javax.xml.namespace.QName ERRORREASON$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "errorReason");
        
        
        /**
         * Gets the "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpListToModify" element
         */
        public boolean isSetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPLISTTOMODIFY$0) != 0;
            }
        }
        
        /**
         * Sets the "tpListToModify" element
         */
        public void setTpListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$0);
                }
                target.set(tpListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tpListToModify" element
         */
        public void unsetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPLISTTOMODIFY$0, 0);
            }
        }
        
        /**
         * Gets the "stateOfActivatedSnc" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum getStateOfActivatedSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATEOFACTIVATEDSNC$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "stateOfActivatedSnc" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType xgetStateOfActivatedSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().find_element_user(STATEOFACTIVATEDSNC$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "stateOfActivatedSnc" element
         */
        public boolean isSetStateOfActivatedSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(STATEOFACTIVATEDSNC$2) != 0;
            }
        }
        
        /**
         * Sets the "stateOfActivatedSnc" element
         */
        public void setStateOfActivatedSnc(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum stateOfActivatedSnc)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATEOFACTIVATEDSNC$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STATEOFACTIVATEDSNC$2);
                }
                target.setEnumValue(stateOfActivatedSnc);
            }
        }
        
        /**
         * Sets (as xml) the "stateOfActivatedSnc" element
         */
        public void xsetStateOfActivatedSnc(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType stateOfActivatedSnc)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().find_element_user(STATEOFACTIVATEDSNC$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().add_element_user(STATEOFACTIVATEDSNC$2);
                }
                target.set(stateOfActivatedSnc);
            }
        }
        
        /**
         * Unsets the "stateOfActivatedSnc" element
         */
        public void unsetStateOfActivatedSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(STATEOFACTIVATEDSNC$2, 0);
            }
        }
        
        /**
         * Gets the "errorReason" element
         */
        public java.lang.String getErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "errorReason" element
         */
        public org.apache.xmlbeans.XmlString xgetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "errorReason" element
         */
        public boolean isSetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRORREASON$4) != 0;
            }
        }
        
        /**
         * Sets the "errorReason" element
         */
        public void setErrorReason(java.lang.String errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ERRORREASON$4);
                }
                target.setStringValue(errorReason);
            }
        }
        
        /**
         * Sets (as xml) the "errorReason" element
         */
        public void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$4);
                }
                target.set(errorReason);
            }
        }
        
        /**
         * Unsets the "errorReason" element
         */
        public void unsetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRORREASON$4, 0);
            }
        }
    }
}
