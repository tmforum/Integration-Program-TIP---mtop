/*
 * XML Type:  TpDataType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tpdata.v1.impl;
/**
 * An XML TpDataType(@http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1).
 *
 * This is a complex type.
 */
public class TpDataTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType
{
    
    public TpDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "tpName");
    private static final javax.xml.namespace.QName TPMAPPINGMODE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "tpMappingMode");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMS$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "transmissionParams");
    private static final javax.xml.namespace.QName INGRESSTRANSMISSIONDESCRIPTORNAME$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "ingressTransmissionDescriptorName");
    private static final javax.xml.namespace.QName EGRESSTRANSMISSIONDESCRIPTORNAME$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "egressTransmissionDescriptorName");
    
    
    /**
     * Gets the "tpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tpName" element
     */
    public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
            }
            target.set(tpName);
        }
    }
    
    /**
     * Appends and returns a new empty "tpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
            return target;
        }
    }
    
    /**
     * Gets the "tpMappingMode" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum getTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpMappingMode" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType xgetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "tpMappingMode" element
     */
    public boolean isNilTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpMappingMode" element
     */
    public boolean isSetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPMAPPINGMODE$2) != 0;
        }
    }
    
    /**
     * Sets the "tpMappingMode" element
     */
    public void setTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum tpMappingMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPMAPPINGMODE$2);
            }
            target.setEnumValue(tpMappingMode);
        }
    }
    
    /**
     * Sets (as xml) the "tpMappingMode" element
     */
    public void xsetTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType tpMappingMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().add_element_user(TPMAPPINGMODE$2);
            }
            target.set(tpMappingMode);
        }
    }
    
    /**
     * Nils the "tpMappingMode" element
     */
    public void setNilTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().add_element_user(TPMAPPINGMODE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpMappingMode" element
     */
    public void unsetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPMAPPINGMODE$2, 0);
        }
    }
    
    /**
     * Gets the "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParams" element
     */
    public boolean isNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParams" element
     */
    public boolean isSetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMS$4) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParams" element
     */
    public void setTransmissionParams(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParams)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$4);
            }
            target.set(transmissionParams);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$4);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParams" element
     */
    public void setNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParams" element
     */
    public void unsetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMS$4, 0);
        }
    }
    
    /**
     * Gets the "ingressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ingressTransmissionDescriptorName" element
     */
    public boolean isNilIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ingressTransmissionDescriptorName" element
     */
    public boolean isSetIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INGRESSTRANSMISSIONDESCRIPTORNAME$6) != 0;
        }
    }
    
    /**
     * Sets the "ingressTransmissionDescriptorName" element
     */
    public void setIngressTransmissionDescriptorName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType ingressTransmissionDescriptorName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$6);
            }
            target.set(ingressTransmissionDescriptorName);
        }
    }
    
    /**
     * Appends and returns a new empty "ingressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$6);
            return target;
        }
    }
    
    /**
     * Nils the "ingressTransmissionDescriptorName" element
     */
    public void setNilIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ingressTransmissionDescriptorName" element
     */
    public void unsetIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INGRESSTRANSMISSIONDESCRIPTORNAME$6, 0);
        }
    }
    
    /**
     * Gets the "egressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "egressTransmissionDescriptorName" element
     */
    public boolean isNilEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "egressTransmissionDescriptorName" element
     */
    public boolean isSetEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EGRESSTRANSMISSIONDESCRIPTORNAME$8) != 0;
        }
    }
    
    /**
     * Sets the "egressTransmissionDescriptorName" element
     */
    public void setEgressTransmissionDescriptorName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType egressTransmissionDescriptorName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$8);
            }
            target.set(egressTransmissionDescriptorName);
        }
    }
    
    /**
     * Appends and returns a new empty "egressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$8);
            return target;
        }
    }
    
    /**
     * Nils the "egressTransmissionDescriptorName" element
     */
    public void setNilEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "egressTransmissionDescriptorName" element
     */
    public void unsetEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EGRESSTRANSMISSIONDESCRIPTORNAME$8, 0);
        }
    }
}
