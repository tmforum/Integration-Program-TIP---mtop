/*
 * XML Type:  AlarmReportingType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/com/v1
 * Java type: org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.com.v1.impl;
/**
 * An XML AlarmReportingType(@http://www.tmforum.org/mtop/nrf/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType.
 */
public class AlarmReportingTypeImpl extends org.apache.xmlbeans.impl.values.JavaBooleanHolderEx implements org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType
{
    
    public AlarmReportingTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected AlarmReportingTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
