/*
 * XML Type:  RouteDescriptorListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/routedes/v1
 * Java type: org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.routedes.v1.impl;
/**
 * An XML RouteDescriptorListType(@http://www.tmforum.org/mtop/nrf/xsd/routedes/v1).
 *
 * This is a complex type.
 */
public class RouteDescriptorListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorListType
{
    
    public RouteDescriptorListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ROUTEDESCRIPTOR$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "routeDescriptor");
    
    
    /**
     * Gets a List of "routeDescriptor" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType> getRouteDescriptorList()
    {
        final class RouteDescriptorList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType>
        {
            public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType get(int i)
                { return RouteDescriptorListTypeImpl.this.getRouteDescriptorArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType set(int i, org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType o)
            {
                org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType old = RouteDescriptorListTypeImpl.this.getRouteDescriptorArray(i);
                RouteDescriptorListTypeImpl.this.setRouteDescriptorArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType o)
                { RouteDescriptorListTypeImpl.this.insertNewRouteDescriptor(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType old = RouteDescriptorListTypeImpl.this.getRouteDescriptorArray(i);
                RouteDescriptorListTypeImpl.this.removeRouteDescriptor(i);
                return old;
            }
            
            public int size()
                { return RouteDescriptorListTypeImpl.this.sizeOfRouteDescriptorArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new RouteDescriptorList();
        }
    }
    
    /**
     * Gets array of all "routeDescriptor" elements
     */
    public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType[] getRouteDescriptorArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ROUTEDESCRIPTOR$0, targetList);
            org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType[] result = new org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "routeDescriptor" element
     */
    public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType getRouteDescriptorArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().find_element_user(ROUTEDESCRIPTOR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "routeDescriptor" element
     */
    public int sizeOfRouteDescriptorArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEDESCRIPTOR$0);
        }
    }
    
    /**
     * Sets array of all "routeDescriptor" element
     */
    public void setRouteDescriptorArray(org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType[] routeDescriptorArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(routeDescriptorArray, ROUTEDESCRIPTOR$0);
        }
    }
    
    /**
     * Sets ith "routeDescriptor" element
     */
    public void setRouteDescriptorArray(int i, org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType routeDescriptor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().find_element_user(ROUTEDESCRIPTOR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(routeDescriptor);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "routeDescriptor" element
     */
    public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType insertNewRouteDescriptor(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().insert_element_user(ROUTEDESCRIPTOR$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "routeDescriptor" element
     */
    public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType addNewRouteDescriptor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().add_element_user(ROUTEDESCRIPTOR$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "routeDescriptor" element
     */
    public void removeRouteDescriptor(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEDESCRIPTOR$0, i);
        }
    }
}
