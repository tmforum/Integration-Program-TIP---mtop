/*
 * An XML document type.
 * Localname: addRouteException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one addRouteException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class AddRouteExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument
{
    
    public AddRouteExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ADDROUTEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "addRouteException");
    
    
    /**
     * Gets the "addRouteException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException getAddRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException)get_store().find_element_user(ADDROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "addRouteException" element
     */
    public void setAddRouteException(org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException addRouteException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException)get_store().find_element_user(ADDROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException)get_store().add_element_user(ADDROUTEEXCEPTION$0);
            }
            target.set(addRouteException);
        }
    }
    
    /**
     * Appends and returns a new empty "addRouteException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException addNewAddRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException)get_store().add_element_user(ADDROUTEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML addRouteException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class AddRouteExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.AddRouteExceptionDocument.AddRouteException
    {
        
        public AddRouteExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
