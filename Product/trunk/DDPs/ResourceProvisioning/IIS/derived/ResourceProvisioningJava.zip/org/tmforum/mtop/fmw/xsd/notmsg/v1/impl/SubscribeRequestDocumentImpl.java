/*
 * An XML document type.
 * Localname: subscribeRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * A document containing one subscribeRequest(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1) element.
 *
 * This is a complex type.
 */
public class SubscribeRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument
{
    
    public SubscribeRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SUBSCRIBEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "subscribeRequest");
    
    
    /**
     * Gets the "subscribeRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest getSubscribeRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest)get_store().find_element_user(SUBSCRIBEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "subscribeRequest" element
     */
    public void setSubscribeRequest(org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest subscribeRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest)get_store().find_element_user(SUBSCRIBEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest)get_store().add_element_user(SUBSCRIBEREQUEST$0);
            }
            target.set(subscribeRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "subscribeRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest addNewSubscribeRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest)get_store().add_element_user(SUBSCRIBEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML subscribeRequest(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public static class SubscribeRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest
    {
        
        public SubscribeRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONSUMEREPR$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "consumerEpr");
        private static final javax.xml.namespace.QName TOPIC$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "topic");
        private static final javax.xml.namespace.QName SELECTOR$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "selector");
        
        
        /**
         * Gets the "consumerEpr" element
         */
        public java.lang.String getConsumerEpr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONSUMEREPR$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "consumerEpr" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType xgetConsumerEpr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType)get_store().find_element_user(CONSUMEREPR$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "consumerEpr" element
         */
        public void setConsumerEpr(java.lang.String consumerEpr)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONSUMEREPR$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONSUMEREPR$0);
                }
                target.setStringValue(consumerEpr);
            }
        }
        
        /**
         * Sets (as xml) the "consumerEpr" element
         */
        public void xsetConsumerEpr(org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType consumerEpr)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType)get_store().find_element_user(CONSUMEREPR$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType)get_store().add_element_user(CONSUMEREPR$0);
                }
                target.set(consumerEpr);
            }
        }
        
        /**
         * Gets the "topic" element
         */
        public java.lang.String getTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOPIC$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "topic" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType xgetTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().find_element_user(TOPIC$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "topic" element
         */
        public boolean isSetTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOPIC$2) != 0;
            }
        }
        
        /**
         * Sets the "topic" element
         */
        public void setTopic(java.lang.String topic)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOPIC$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOPIC$2);
                }
                target.setStringValue(topic);
            }
        }
        
        /**
         * Sets (as xml) the "topic" element
         */
        public void xsetTopic(org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType topic)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().find_element_user(TOPIC$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().add_element_user(TOPIC$2);
                }
                target.set(topic);
            }
        }
        
        /**
         * Unsets the "topic" element
         */
        public void unsetTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOPIC$2, 0);
            }
        }
        
        /**
         * Gets the "selector" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType getSelector()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType)get_store().find_element_user(SELECTOR$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "selector" element
         */
        public boolean isSetSelector()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SELECTOR$4) != 0;
            }
        }
        
        /**
         * Sets the "selector" element
         */
        public void setSelector(org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType selector)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType)get_store().find_element_user(SELECTOR$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType)get_store().add_element_user(SELECTOR$4);
                }
                target.set(selector);
            }
        }
        
        /**
         * Appends and returns a new empty "selector" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType addNewSelector()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType)get_store().add_element_user(SELECTOR$4);
                return target;
            }
        }
        
        /**
         * Unsets the "selector" element
         */
        public void unsetSelector()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SELECTOR$4, 0);
            }
        }
    }
}
