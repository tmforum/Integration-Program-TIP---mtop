/*
 * An XML document type.
 * Localname: ftp
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ftp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ftp.v1.FtpDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ftp.v1.impl;
/**
 * A document containing one ftp(@http://www.tmforum.org/mtop/nrf/xsd/ftp/v1) element.
 *
 * This is a complex type.
 */
public class FtpDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.ftp.v1.FtpDocument
{
    
    public FtpDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ftp/v1", "ftp");
    
    
    /**
     * Gets the "ftp" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType getFtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().find_element_user(FTP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ftp" element
     */
    public void setFtp(org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType ftp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().find_element_user(FTP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().add_element_user(FTP$0);
            }
            target.set(ftp);
        }
    }
    
    /**
     * Appends and returns a new empty "ftp" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType addNewFtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().add_element_user(FTP$0);
            return target;
        }
    }
}
