/*
 * XML Type:  ConnectivityStateType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fd.v1.impl;
/**
 * An XML ConnectivityStateType(@http://www.tmforum.org/mtop/nrf/xsd/fd/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType.
 */
public class ConnectivityStateTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType
{
    
    public ConnectivityStateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ConnectivityStateTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
