/*
 * XML Type:  NotificationIdListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1.impl;
/**
 * An XML NotificationIdListType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is a complex type.
 */
public class NotificationIdListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdListType
{
    
    public NotificationIdListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NOTIFICATIONID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/gen/v1", "notificationId");
    
    
    /**
     * Gets a List of "notificationId" elements
     */
    public java.util.List<java.lang.String> getNotificationIdList()
    {
        final class NotificationIdList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return NotificationIdListTypeImpl.this.getNotificationIdArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = NotificationIdListTypeImpl.this.getNotificationIdArray(i);
                NotificationIdListTypeImpl.this.setNotificationIdArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { NotificationIdListTypeImpl.this.insertNotificationId(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = NotificationIdListTypeImpl.this.getNotificationIdArray(i);
                NotificationIdListTypeImpl.this.removeNotificationId(i);
                return old;
            }
            
            public int size()
                { return NotificationIdListTypeImpl.this.sizeOfNotificationIdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new NotificationIdList();
        }
    }
    
    /**
     * Gets array of all "notificationId" elements
     */
    public java.lang.String[] getNotificationIdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(NOTIFICATIONID$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "notificationId" element
     */
    public java.lang.String getNotificationIdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOTIFICATIONID$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "notificationId" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType> xgetNotificationIdList()
    {
        final class NotificationIdList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType>
        {
            public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType get(int i)
                { return NotificationIdListTypeImpl.this.xgetNotificationIdArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType set(int i, org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType o)
            {
                org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType old = NotificationIdListTypeImpl.this.xgetNotificationIdArray(i);
                NotificationIdListTypeImpl.this.xsetNotificationIdArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType o)
                { NotificationIdListTypeImpl.this.insertNewNotificationId(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType old = NotificationIdListTypeImpl.this.xgetNotificationIdArray(i);
                NotificationIdListTypeImpl.this.removeNotificationId(i);
                return old;
            }
            
            public int size()
                { return NotificationIdListTypeImpl.this.sizeOfNotificationIdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new NotificationIdList();
        }
    }
    
    /**
     * Gets (as xml) array of all "notificationId" elements
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType[] xgetNotificationIdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(NOTIFICATIONID$0, targetList);
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType[] result = new org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "notificationId" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType xgetNotificationIdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType)get_store().find_element_user(NOTIFICATIONID$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType)target;
        }
    }
    
    /**
     * Returns number of "notificationId" element
     */
    public int sizeOfNotificationIdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOTIFICATIONID$0);
        }
    }
    
    /**
     * Sets array of all "notificationId" element
     */
    public void setNotificationIdArray(java.lang.String[] notificationIdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(notificationIdArray, NOTIFICATIONID$0);
        }
    }
    
    /**
     * Sets ith "notificationId" element
     */
    public void setNotificationIdArray(int i, java.lang.String notificationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOTIFICATIONID$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(notificationId);
        }
    }
    
    /**
     * Sets (as xml) array of all "notificationId" element
     */
    public void xsetNotificationIdArray(org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType[]notificationIdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(notificationIdArray, NOTIFICATIONID$0);
        }
    }
    
    /**
     * Sets (as xml) ith "notificationId" element
     */
    public void xsetNotificationIdArray(int i, org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType notificationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType)get_store().find_element_user(NOTIFICATIONID$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(notificationId);
        }
    }
    
    /**
     * Inserts the value as the ith "notificationId" element
     */
    public void insertNotificationId(int i, java.lang.String notificationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(NOTIFICATIONID$0, i);
            target.setStringValue(notificationId);
        }
    }
    
    /**
     * Appends the value as the last "notificationId" element
     */
    public void addNotificationId(java.lang.String notificationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOTIFICATIONID$0);
            target.setStringValue(notificationId);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "notificationId" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType insertNewNotificationId(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType)get_store().insert_element_user(NOTIFICATIONID$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "notificationId" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType addNewNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType)get_store().add_element_user(NOTIFICATIONID$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "notificationId" element
     */
    public void removeNotificationId(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOTIFICATIONID$0, i);
        }
    }
}
