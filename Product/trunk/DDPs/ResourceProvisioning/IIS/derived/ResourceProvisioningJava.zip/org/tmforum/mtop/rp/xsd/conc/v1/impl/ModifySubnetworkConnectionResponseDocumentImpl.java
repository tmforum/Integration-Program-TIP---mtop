/*
 * An XML document type.
 * Localname: modifySubnetworkConnectionResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one modifySubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class ModifySubnetworkConnectionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument
{
    
    public ModifySubnetworkConnectionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MODIFYSUBNETWORKCONNECTIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "modifySubnetworkConnectionResponse");
    
    
    /**
     * Gets the "modifySubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse getModifySubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse)get_store().find_element_user(MODIFYSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "modifySubnetworkConnectionResponse" element
     */
    public void setModifySubnetworkConnectionResponse(org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse modifySubnetworkConnectionResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse)get_store().find_element_user(MODIFYSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse)get_store().add_element_user(MODIFYSUBNETWORKCONNECTIONRESPONSE$0);
            }
            target.set(modifySubnetworkConnectionResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "modifySubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse addNewModifySubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse)get_store().add_element_user(MODIFYSUBNETWORKCONNECTIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML modifySubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ModifySubnetworkConnectionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionResponseDocument.ModifySubnetworkConnectionResponse
    {
        
        public ModifySubnetworkConnectionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPDATALISTTOMODIFY$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "TpDataListToModify");
        private static final javax.xml.namespace.QName THESNC$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "theSnc");
        private static final javax.xml.namespace.QName ERRORREASON$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "errorReason");
        
        
        /**
         * Gets the "TpDataListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPDATALISTTOMODIFY$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "TpDataListToModify" element
         */
        public boolean isSetTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPDATALISTTOMODIFY$0) != 0;
            }
        }
        
        /**
         * Sets the "TpDataListToModify" element
         */
        public void setTpDataListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpDataListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPDATALISTTOMODIFY$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPDATALISTTOMODIFY$0);
                }
                target.set(tpDataListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "TpDataListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPDATALISTTOMODIFY$0);
                return target;
            }
        }
        
        /**
         * Unsets the "TpDataListToModify" element
         */
        public void unsetTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPDATALISTTOMODIFY$0, 0);
            }
        }
        
        /**
         * Gets the "theSnc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getTheSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(THESNC$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "theSnc" element
         */
        public boolean isSetTheSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(THESNC$2) != 0;
            }
        }
        
        /**
         * Sets the "theSnc" element
         */
        public void setTheSnc(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType theSnc)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(THESNC$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(THESNC$2);
                }
                target.set(theSnc);
            }
        }
        
        /**
         * Appends and returns a new empty "theSnc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewTheSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(THESNC$2);
                return target;
            }
        }
        
        /**
         * Unsets the "theSnc" element
         */
        public void unsetTheSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(THESNC$2, 0);
            }
        }
        
        /**
         * Gets the "errorReason" element
         */
        public java.lang.String getErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "errorReason" element
         */
        public org.apache.xmlbeans.XmlString xgetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "errorReason" element
         */
        public boolean isSetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRORREASON$4) != 0;
            }
        }
        
        /**
         * Sets the "errorReason" element
         */
        public void setErrorReason(java.lang.String errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ERRORREASON$4);
                }
                target.setStringValue(errorReason);
            }
        }
        
        /**
         * Sets (as xml) the "errorReason" element
         */
        public void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$4);
                }
                target.set(errorReason);
            }
        }
        
        /**
         * Unsets the "errorReason" element
         */
        public void unsetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRORREASON$4, 0);
            }
        }
    }
}
