/*
 * XML Type:  SubnetworkConnectionModifyDataType
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * An XML SubnetworkConnectionModifyDataType(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
 *
 * This is a complex type.
 */
public class SubnetworkConnectionModifyDataTypeImpl extends org.tmforum.mtop.nrb.xsd.crmd.v1.impl.CommonResourceModifyDataTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType
{
    
    public SubnetworkConnectionModifyDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "direction");
    private static final javax.xml.namespace.QName MODIFYTYPE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "modifyType");
    private static final javax.xml.namespace.QName RETAINOLDSNC$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "retainOldSNC");
    private static final javax.xml.namespace.QName MODIFYSERVERSALLOWED$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "modifyServersAllowed");
    private static final javax.xml.namespace.QName STATICPROTECTIONLEVEL$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "staticProtectionLevel");
    private static final javax.xml.namespace.QName PROTECTIONEFFORT$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "protectionEffort");
    private static final javax.xml.namespace.QName REROUTEALLOWED$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "rerouteAllowed");
    private static final javax.xml.namespace.QName NETWORKROUTED$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "networkRouted");
    private static final javax.xml.namespace.QName SNCTYPE$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "sncType");
    private static final javax.xml.namespace.QName LAYERRATE$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "layerRate");
    private static final javax.xml.namespace.QName ADDEDORNEWROUTE$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "addedOrNewRoute");
    private static final javax.xml.namespace.QName REMOVEDROUTE$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "removedRoute");
    private static final javax.xml.namespace.QName INCLUSIONREFLIST$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "inclusionRefList");
    private static final javax.xml.namespace.QName ISFULLROUTE$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "isFullRoute");
    private static final javax.xml.namespace.QName EXCLUSIONREFLIST$28 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "exclusionRefList");
    private static final javax.xml.namespace.QName AENDREFLIST$30 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "aEndRefList");
    private static final javax.xml.namespace.QName ZENDREFLIST$32 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "zEndRefList");
    private static final javax.xml.namespace.QName ISREPORTINGALARM$34 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "isReportingAlarm");
    private static final javax.xml.namespace.QName NETWORKREROUTE$36 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "networkReroute");
    private static final javax.xml.namespace.QName ISREVERTIVE$38 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "isRevertive");
    private static final javax.xml.namespace.QName ISREVERTIVEREROUTE$40 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "isRevertiveReroute");
    private static final javax.xml.namespace.QName ASAPREF$42 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "asapRef");
    private static final javax.xml.namespace.QName MUSTREMOVEGTPLIST$44 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "mustRemoveGtpList");
    private static final javax.xml.namespace.QName PRIORITY$46 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "priority");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$0) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$0, 0);
        }
    }
    
    /**
     * Gets the "modifyType" element
     */
    public java.lang.String getModifyType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MODIFYTYPE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "modifyType" element
     */
    public org.apache.xmlbeans.XmlString xgetModifyType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MODIFYTYPE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "modifyType" element
     */
    public boolean isSetModifyType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MODIFYTYPE$2) != 0;
        }
    }
    
    /**
     * Sets the "modifyType" element
     */
    public void setModifyType(java.lang.String modifyType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MODIFYTYPE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MODIFYTYPE$2);
            }
            target.setStringValue(modifyType);
        }
    }
    
    /**
     * Sets (as xml) the "modifyType" element
     */
    public void xsetModifyType(org.apache.xmlbeans.XmlString modifyType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MODIFYTYPE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MODIFYTYPE$2);
            }
            target.set(modifyType);
        }
    }
    
    /**
     * Unsets the "modifyType" element
     */
    public void unsetModifyType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MODIFYTYPE$2, 0);
        }
    }
    
    /**
     * Gets the "retainOldSNC" element
     */
    public boolean getRetainOldSNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RETAINOLDSNC$4, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "retainOldSNC" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRetainOldSNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(RETAINOLDSNC$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "retainOldSNC" element
     */
    public boolean isSetRetainOldSNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RETAINOLDSNC$4) != 0;
        }
    }
    
    /**
     * Sets the "retainOldSNC" element
     */
    public void setRetainOldSNC(boolean retainOldSNC)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RETAINOLDSNC$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RETAINOLDSNC$4);
            }
            target.setBooleanValue(retainOldSNC);
        }
    }
    
    /**
     * Sets (as xml) the "retainOldSNC" element
     */
    public void xsetRetainOldSNC(org.apache.xmlbeans.XmlBoolean retainOldSNC)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(RETAINOLDSNC$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(RETAINOLDSNC$4);
            }
            target.set(retainOldSNC);
        }
    }
    
    /**
     * Unsets the "retainOldSNC" element
     */
    public void unsetRetainOldSNC()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RETAINOLDSNC$4, 0);
        }
    }
    
    /**
     * Gets the "modifyServersAllowed" element
     */
    public boolean getModifyServersAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MODIFYSERVERSALLOWED$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "modifyServersAllowed" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetModifyServersAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MODIFYSERVERSALLOWED$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "modifyServersAllowed" element
     */
    public boolean isSetModifyServersAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MODIFYSERVERSALLOWED$6) != 0;
        }
    }
    
    /**
     * Sets the "modifyServersAllowed" element
     */
    public void setModifyServersAllowed(boolean modifyServersAllowed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MODIFYSERVERSALLOWED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MODIFYSERVERSALLOWED$6);
            }
            target.setBooleanValue(modifyServersAllowed);
        }
    }
    
    /**
     * Sets (as xml) the "modifyServersAllowed" element
     */
    public void xsetModifyServersAllowed(org.apache.xmlbeans.XmlBoolean modifyServersAllowed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MODIFYSERVERSALLOWED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(MODIFYSERVERSALLOWED$6);
            }
            target.set(modifyServersAllowed);
        }
    }
    
    /**
     * Unsets the "modifyServersAllowed" element
     */
    public void unsetModifyServersAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MODIFYSERVERSALLOWED$6, 0);
        }
    }
    
    /**
     * Gets the "staticProtectionLevel" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType getStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().find_element_user(STATICPROTECTIONLEVEL$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "staticProtectionLevel" element
     */
    public boolean isSetStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STATICPROTECTIONLEVEL$8) != 0;
        }
    }
    
    /**
     * Sets the "staticProtectionLevel" element
     */
    public void setStaticProtectionLevel(org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType staticProtectionLevel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().find_element_user(STATICPROTECTIONLEVEL$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().add_element_user(STATICPROTECTIONLEVEL$8);
            }
            target.set(staticProtectionLevel);
        }
    }
    
    /**
     * Appends and returns a new empty "staticProtectionLevel" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType addNewStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().add_element_user(STATICPROTECTIONLEVEL$8);
            return target;
        }
    }
    
    /**
     * Unsets the "staticProtectionLevel" element
     */
    public void unsetStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STATICPROTECTIONLEVEL$8, 0);
        }
    }
    
    /**
     * Gets the "protectionEffort" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum getProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTECTIONEFFORT$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "protectionEffort" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType xgetProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(PROTECTIONEFFORT$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "protectionEffort" element
     */
    public boolean isSetProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONEFFORT$10) != 0;
        }
    }
    
    /**
     * Sets the "protectionEffort" element
     */
    public void setProtectionEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum protectionEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTECTIONEFFORT$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTECTIONEFFORT$10);
            }
            target.setEnumValue(protectionEffort);
        }
    }
    
    /**
     * Sets (as xml) the "protectionEffort" element
     */
    public void xsetProtectionEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType protectionEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(PROTECTIONEFFORT$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().add_element_user(PROTECTIONEFFORT$10);
            }
            target.set(protectionEffort);
        }
    }
    
    /**
     * Unsets the "protectionEffort" element
     */
    public void unsetProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONEFFORT$10, 0);
        }
    }
    
    /**
     * Gets the "rerouteAllowed" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum getRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REROUTEALLOWED$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "rerouteAllowed" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType xgetRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(REROUTEALLOWED$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "rerouteAllowed" element
     */
    public boolean isSetRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REROUTEALLOWED$12) != 0;
        }
    }
    
    /**
     * Sets the "rerouteAllowed" element
     */
    public void setRerouteAllowed(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum rerouteAllowed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REROUTEALLOWED$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REROUTEALLOWED$12);
            }
            target.setEnumValue(rerouteAllowed);
        }
    }
    
    /**
     * Sets (as xml) the "rerouteAllowed" element
     */
    public void xsetRerouteAllowed(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType rerouteAllowed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(REROUTEALLOWED$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().add_element_user(REROUTEALLOWED$12);
            }
            target.set(rerouteAllowed);
        }
    }
    
    /**
     * Unsets the "rerouteAllowed" element
     */
    public void unsetRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REROUTEALLOWED$12, 0);
        }
    }
    
    /**
     * Gets the "networkRouted" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum getNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKROUTED$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "networkRouted" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType xgetNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().find_element_user(NETWORKROUTED$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "networkRouted" element
     */
    public boolean isSetNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETWORKROUTED$14) != 0;
        }
    }
    
    /**
     * Sets the "networkRouted" element
     */
    public void setNetworkRouted(org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum networkRouted)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKROUTED$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKROUTED$14);
            }
            target.setEnumValue(networkRouted);
        }
    }
    
    /**
     * Sets (as xml) the "networkRouted" element
     */
    public void xsetNetworkRouted(org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType networkRouted)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().find_element_user(NETWORKROUTED$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().add_element_user(NETWORKROUTED$14);
            }
            target.set(networkRouted);
        }
    }
    
    /**
     * Unsets the "networkRouted" element
     */
    public void unsetNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETWORKROUTED$14, 0);
        }
    }
    
    /**
     * Gets the "sncType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType.Enum getSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCTYPE$16, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "sncType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType xgetSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType)get_store().find_element_user(SNCTYPE$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "sncType" element
     */
    public boolean isSetSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SNCTYPE$16) != 0;
        }
    }
    
    /**
     * Sets the "sncType" element
     */
    public void setSncType(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType.Enum sncType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCTYPE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SNCTYPE$16);
            }
            target.setEnumValue(sncType);
        }
    }
    
    /**
     * Sets (as xml) the "sncType" element
     */
    public void xsetSncType(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType sncType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType)get_store().find_element_user(SNCTYPE$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType)get_store().add_element_user(SNCTYPE$16);
            }
            target.set(sncType);
        }
    }
    
    /**
     * Unsets the "sncType" element
     */
    public void unsetSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SNCTYPE$16, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$18) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$18);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$18);
            return target;
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$18, 0);
        }
    }
    
    /**
     * Gets the "addedOrNewRoute" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteListType getAddedOrNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().find_element_user(ADDEDORNEWROUTE$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "addedOrNewRoute" element
     */
    public boolean isSetAddedOrNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ADDEDORNEWROUTE$20) != 0;
        }
    }
    
    /**
     * Sets the "addedOrNewRoute" element
     */
    public void setAddedOrNewRoute(org.tmforum.mtop.nrf.xsd.route.v1.RouteListType addedOrNewRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().find_element_user(ADDEDORNEWROUTE$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().add_element_user(ADDEDORNEWROUTE$20);
            }
            target.set(addedOrNewRoute);
        }
    }
    
    /**
     * Appends and returns a new empty "addedOrNewRoute" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteListType addNewAddedOrNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().add_element_user(ADDEDORNEWROUTE$20);
            return target;
        }
    }
    
    /**
     * Unsets the "addedOrNewRoute" element
     */
    public void unsetAddedOrNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ADDEDORNEWROUTE$20, 0);
        }
    }
    
    /**
     * Gets the "removedRoute" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteListType getRemovedRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().find_element_user(REMOVEDROUTE$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "removedRoute" element
     */
    public boolean isSetRemovedRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REMOVEDROUTE$22) != 0;
        }
    }
    
    /**
     * Sets the "removedRoute" element
     */
    public void setRemovedRoute(org.tmforum.mtop.nrf.xsd.route.v1.RouteListType removedRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().find_element_user(REMOVEDROUTE$22, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().add_element_user(REMOVEDROUTE$22);
            }
            target.set(removedRoute);
        }
    }
    
    /**
     * Appends and returns a new empty "removedRoute" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteListType addNewRemovedRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().add_element_user(REMOVEDROUTE$22);
            return target;
        }
    }
    
    /**
     * Unsets the "removedRoute" element
     */
    public void unsetRemovedRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REMOVEDROUTE$22, 0);
        }
    }
    
    /**
     * Gets the "inclusionRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getInclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INCLUSIONREFLIST$24, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "inclusionRefList" element
     */
    public boolean isSetInclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INCLUSIONREFLIST$24) != 0;
        }
    }
    
    /**
     * Sets the "inclusionRefList" element
     */
    public void setInclusionRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType inclusionRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INCLUSIONREFLIST$24, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INCLUSIONREFLIST$24);
            }
            target.set(inclusionRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "inclusionRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewInclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INCLUSIONREFLIST$24);
            return target;
        }
    }
    
    /**
     * Unsets the "inclusionRefList" element
     */
    public void unsetInclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INCLUSIONREFLIST$24, 0);
        }
    }
    
    /**
     * Gets the "isFullRoute" element
     */
    public boolean getIsFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFULLROUTE$26, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isFullRoute" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFULLROUTE$26, 0);
            return target;
        }
    }
    
    /**
     * True if has "isFullRoute" element
     */
    public boolean isSetIsFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISFULLROUTE$26) != 0;
        }
    }
    
    /**
     * Sets the "isFullRoute" element
     */
    public void setIsFullRoute(boolean isFullRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFULLROUTE$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISFULLROUTE$26);
            }
            target.setBooleanValue(isFullRoute);
        }
    }
    
    /**
     * Sets (as xml) the "isFullRoute" element
     */
    public void xsetIsFullRoute(org.apache.xmlbeans.XmlBoolean isFullRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFULLROUTE$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISFULLROUTE$26);
            }
            target.set(isFullRoute);
        }
    }
    
    /**
     * Unsets the "isFullRoute" element
     */
    public void unsetIsFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISFULLROUTE$26, 0);
        }
    }
    
    /**
     * Gets the "exclusionRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getExclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(EXCLUSIONREFLIST$28, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "exclusionRefList" element
     */
    public boolean isSetExclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXCLUSIONREFLIST$28) != 0;
        }
    }
    
    /**
     * Sets the "exclusionRefList" element
     */
    public void setExclusionRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType exclusionRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(EXCLUSIONREFLIST$28, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(EXCLUSIONREFLIST$28);
            }
            target.set(exclusionRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "exclusionRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewExclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(EXCLUSIONREFLIST$28);
            return target;
        }
    }
    
    /**
     * Unsets the "exclusionRefList" element
     */
    public void unsetExclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXCLUSIONREFLIST$28, 0);
        }
    }
    
    /**
     * Gets the "aEndRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAEndRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(AENDREFLIST$30, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "aEndRefList" element
     */
    public boolean isSetAEndRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AENDREFLIST$30) != 0;
        }
    }
    
    /**
     * Sets the "aEndRefList" element
     */
    public void setAEndRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType aEndRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(AENDREFLIST$30, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(AENDREFLIST$30);
            }
            target.set(aEndRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "aEndRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAEndRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(AENDREFLIST$30);
            return target;
        }
    }
    
    /**
     * Unsets the "aEndRefList" element
     */
    public void unsetAEndRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AENDREFLIST$30, 0);
        }
    }
    
    /**
     * Gets the "zEndRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getZEndRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ZENDREFLIST$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "zEndRefList" element
     */
    public boolean isSetZEndRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZENDREFLIST$32) != 0;
        }
    }
    
    /**
     * Sets the "zEndRefList" element
     */
    public void setZEndRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType zEndRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ZENDREFLIST$32, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ZENDREFLIST$32);
            }
            target.set(zEndRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "zEndRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewZEndRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ZENDREFLIST$32);
            return target;
        }
    }
    
    /**
     * Unsets the "zEndRefList" element
     */
    public void unsetZEndRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZENDREFLIST$32, 0);
        }
    }
    
    /**
     * Gets the "isReportingAlarm" element
     */
    public boolean getIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREPORTINGALARM$34, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isReportingAlarm" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$34, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isReportingAlarm" element
     */
    public boolean isNilIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$34, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isReportingAlarm" element
     */
    public boolean isSetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISREPORTINGALARM$34) != 0;
        }
    }
    
    /**
     * Sets the "isReportingAlarm" element
     */
    public void setIsReportingAlarm(boolean isReportingAlarm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREPORTINGALARM$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISREPORTINGALARM$34);
            }
            target.setBooleanValue(isReportingAlarm);
        }
    }
    
    /**
     * Sets (as xml) the "isReportingAlarm" element
     */
    public void xsetIsReportingAlarm(org.apache.xmlbeans.XmlBoolean isReportingAlarm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREPORTINGALARM$34);
            }
            target.set(isReportingAlarm);
        }
    }
    
    /**
     * Nils the "isReportingAlarm" element
     */
    public void setNilIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREPORTINGALARM$34);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isReportingAlarm" element
     */
    public void unsetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISREPORTINGALARM$34, 0);
        }
    }
    
    /**
     * Gets the "networkReroute" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum getNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKREROUTE$36, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "networkReroute" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType xgetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(NETWORKREROUTE$36, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "networkReroute" element
     */
    public boolean isNilNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(NETWORKREROUTE$36, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "networkReroute" element
     */
    public boolean isSetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETWORKREROUTE$36) != 0;
        }
    }
    
    /**
     * Sets the "networkReroute" element
     */
    public void setNetworkReroute(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum networkReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKREROUTE$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKREROUTE$36);
            }
            target.setEnumValue(networkReroute);
        }
    }
    
    /**
     * Sets (as xml) the "networkReroute" element
     */
    public void xsetNetworkReroute(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType networkReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(NETWORKREROUTE$36, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().add_element_user(NETWORKREROUTE$36);
            }
            target.set(networkReroute);
        }
    }
    
    /**
     * Nils the "networkReroute" element
     */
    public void setNilNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(NETWORKREROUTE$36, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().add_element_user(NETWORKREROUTE$36);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "networkReroute" element
     */
    public void unsetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETWORKREROUTE$36, 0);
        }
    }
    
    /**
     * Gets the "isRevertive" element
     */
    public boolean getIsRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREVERTIVE$38, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isRevertive" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREVERTIVE$38, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isRevertive" element
     */
    public boolean isNilIsRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREVERTIVE$38, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isRevertive" element
     */
    public boolean isSetIsRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISREVERTIVE$38) != 0;
        }
    }
    
    /**
     * Sets the "isRevertive" element
     */
    public void setIsRevertive(boolean isRevertive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREVERTIVE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISREVERTIVE$38);
            }
            target.setBooleanValue(isRevertive);
        }
    }
    
    /**
     * Sets (as xml) the "isRevertive" element
     */
    public void xsetIsRevertive(org.apache.xmlbeans.XmlBoolean isRevertive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREVERTIVE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREVERTIVE$38);
            }
            target.set(isRevertive);
        }
    }
    
    /**
     * Nils the "isRevertive" element
     */
    public void setNilIsRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREVERTIVE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREVERTIVE$38);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isRevertive" element
     */
    public void unsetIsRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISREVERTIVE$38, 0);
        }
    }
    
    /**
     * Gets the "isRevertiveReroute" element
     */
    public boolean getIsRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREVERTIVEREROUTE$40, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isRevertiveReroute" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREVERTIVEREROUTE$40, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isRevertiveReroute" element
     */
    public boolean isNilIsRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREVERTIVEREROUTE$40, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isRevertiveReroute" element
     */
    public boolean isSetIsRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISREVERTIVEREROUTE$40) != 0;
        }
    }
    
    /**
     * Sets the "isRevertiveReroute" element
     */
    public void setIsRevertiveReroute(boolean isRevertiveReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREVERTIVEREROUTE$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISREVERTIVEREROUTE$40);
            }
            target.setBooleanValue(isRevertiveReroute);
        }
    }
    
    /**
     * Sets (as xml) the "isRevertiveReroute" element
     */
    public void xsetIsRevertiveReroute(org.apache.xmlbeans.XmlBoolean isRevertiveReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREVERTIVEREROUTE$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREVERTIVEREROUTE$40);
            }
            target.set(isRevertiveReroute);
        }
    }
    
    /**
     * Nils the "isRevertiveReroute" element
     */
    public void setNilIsRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREVERTIVEREROUTE$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREVERTIVEREROUTE$40);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isRevertiveReroute" element
     */
    public void unsetIsRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISREVERTIVEREROUTE$40, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$42, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$42, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$42, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$42) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$42);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$42);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$42);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$42, 0);
        }
    }
    
    /**
     * Gets the "mustRemoveGtpList" element
     */
    public boolean getMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUSTREMOVEGTPLIST$44, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "mustRemoveGtpList" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$44, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "mustRemoveGtpList" element
     */
    public boolean isNilMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$44, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "mustRemoveGtpList" element
     */
    public boolean isSetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MUSTREMOVEGTPLIST$44) != 0;
        }
    }
    
    /**
     * Sets the "mustRemoveGtpList" element
     */
    public void setMustRemoveGtpList(boolean mustRemoveGtpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUSTREMOVEGTPLIST$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MUSTREMOVEGTPLIST$44);
            }
            target.setBooleanValue(mustRemoveGtpList);
        }
    }
    
    /**
     * Sets (as xml) the "mustRemoveGtpList" element
     */
    public void xsetMustRemoveGtpList(org.apache.xmlbeans.XmlBoolean mustRemoveGtpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(MUSTREMOVEGTPLIST$44);
            }
            target.set(mustRemoveGtpList);
        }
    }
    
    /**
     * Nils the "mustRemoveGtpList" element
     */
    public void setNilMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$44, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(MUSTREMOVEGTPLIST$44);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "mustRemoveGtpList" element
     */
    public void unsetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MUSTREMOVEGTPLIST$44, 0);
        }
    }
    
    /**
     * Gets the "priority" element
     */
    public long getPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$46, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "priority" element
     */
    public org.apache.xmlbeans.XmlUnsignedInt xgetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$46, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "priority" element
     */
    public boolean isNilPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$46, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "priority" element
     */
    public boolean isSetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRIORITY$46) != 0;
        }
    }
    
    /**
     * Sets the "priority" element
     */
    public void setPriority(long priority)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRIORITY$46);
            }
            target.setLongValue(priority);
        }
    }
    
    /**
     * Sets (as xml) the "priority" element
     */
    public void xsetPriority(org.apache.xmlbeans.XmlUnsignedInt priority)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(PRIORITY$46);
            }
            target.set(priority);
        }
    }
    
    /**
     * Nils the "priority" element
     */
    public void setNilPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(PRIORITY$46);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "priority" element
     */
    public void unsetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRIORITY$46, 0);
        }
    }
}
