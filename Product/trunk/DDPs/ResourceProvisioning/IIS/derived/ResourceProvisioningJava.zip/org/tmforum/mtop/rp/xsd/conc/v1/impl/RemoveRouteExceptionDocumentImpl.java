/*
 * An XML document type.
 * Localname: removeRouteException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one removeRouteException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class RemoveRouteExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument
{
    
    public RemoveRouteExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName REMOVEROUTEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "removeRouteException");
    
    
    /**
     * Gets the "removeRouteException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException getRemoveRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException)get_store().find_element_user(REMOVEROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "removeRouteException" element
     */
    public void setRemoveRouteException(org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException removeRouteException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException)get_store().find_element_user(REMOVEROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException)get_store().add_element_user(REMOVEROUTEEXCEPTION$0);
            }
            target.set(removeRouteException);
        }
    }
    
    /**
     * Appends and returns a new empty "removeRouteException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException addNewRemoveRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException)get_store().add_element_user(REMOVEROUTEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML removeRouteException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class RemoveRouteExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteExceptionDocument.RemoveRouteException
    {
        
        public RemoveRouteExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
