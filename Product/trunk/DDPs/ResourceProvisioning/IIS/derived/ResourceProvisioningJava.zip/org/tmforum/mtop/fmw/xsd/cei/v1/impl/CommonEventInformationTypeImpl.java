/*
 * XML Type:  CommonEventInformationType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cei/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cei.v1.impl;
/**
 * An XML CommonEventInformationType(@http://www.tmforum.org/mtop/fmw/xsd/cei/v1).
 *
 * This is a complex type.
 */
public class CommonEventInformationTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType
{
    
    public CommonEventInformationTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NOTIFICATIONID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "notificationId");
    private static final javax.xml.namespace.QName SOURCETIME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "sourceTime");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "vendorExtensions");
    
    
    /**
     * Gets the "notificationId" element
     */
    public java.lang.String getNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOTIFICATIONID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "notificationId" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType xgetNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType)get_store().find_element_user(NOTIFICATIONID$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "notificationId" element
     */
    public boolean isSetNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NOTIFICATIONID$0) != 0;
        }
    }
    
    /**
     * Sets the "notificationId" element
     */
    public void setNotificationId(java.lang.String notificationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOTIFICATIONID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOTIFICATIONID$0);
            }
            target.setStringValue(notificationId);
        }
    }
    
    /**
     * Sets (as xml) the "notificationId" element
     */
    public void xsetNotificationId(org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType notificationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType)get_store().find_element_user(NOTIFICATIONID$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType)get_store().add_element_user(NOTIFICATIONID$0);
            }
            target.set(notificationId);
        }
    }
    
    /**
     * Unsets the "notificationId" element
     */
    public void unsetNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NOTIFICATIONID$0, 0);
        }
    }
    
    /**
     * Gets the "sourceTime" element
     */
    public java.util.Calendar getSourceTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOURCETIME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "sourceTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetSourceTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(SOURCETIME$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "sourceTime" element
     */
    public boolean isSetSourceTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SOURCETIME$2) != 0;
        }
    }
    
    /**
     * Sets the "sourceTime" element
     */
    public void setSourceTime(java.util.Calendar sourceTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOURCETIME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SOURCETIME$2);
            }
            target.setCalendarValue(sourceTime);
        }
    }
    
    /**
     * Sets (as xml) the "sourceTime" element
     */
    public void xsetSourceTime(org.apache.xmlbeans.XmlDateTime sourceTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(SOURCETIME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(SOURCETIME$2);
            }
            target.set(sourceTime);
        }
    }
    
    /**
     * Unsets the "sourceTime" element
     */
    public void unsetSourceTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SOURCETIME$2, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$4) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$4);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$4);
            return target;
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$4, 0);
        }
    }
}
