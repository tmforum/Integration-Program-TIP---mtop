/*
 * XML Type:  FlowDomainType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fd.v1.impl;
/**
 * An XML FlowDomainType(@http://www.tmforum.org/mtop/nrf/xsd/fd/v1).
 *
 * This is a complex type.
 */
public class FlowDomainTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType
{
    
    public FlowDomainTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMETERLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fd/v1", "transmissionParameterList");
    private static final javax.xml.namespace.QName CONNECTIVITYSTATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fd/v1", "connectivityState");
    private static final javax.xml.namespace.QName TYPE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fd/v1", "type");
    
    
    /**
     * Gets the "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    public boolean isNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParameterList" element
     */
    public boolean isSetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMETERLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParameterList" element
     */
    public void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            }
            target.set(transmissionParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParameterList" element
     */
    public void setNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    public void unsetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMETERLIST$0, 0);
        }
    }
    
    /**
     * Gets the "connectivityState" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType.Enum getConnectivityState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIVITYSTATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "connectivityState" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType xgetConnectivityState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType)get_store().find_element_user(CONNECTIVITYSTATE$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "connectivityState" element
     */
    public boolean isNilConnectivityState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType)get_store().find_element_user(CONNECTIVITYSTATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "connectivityState" element
     */
    public boolean isSetConnectivityState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIVITYSTATE$2) != 0;
        }
    }
    
    /**
     * Sets the "connectivityState" element
     */
    public void setConnectivityState(org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType.Enum connectivityState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIVITYSTATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONNECTIVITYSTATE$2);
            }
            target.setEnumValue(connectivityState);
        }
    }
    
    /**
     * Sets (as xml) the "connectivityState" element
     */
    public void xsetConnectivityState(org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType connectivityState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType)get_store().find_element_user(CONNECTIVITYSTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType)get_store().add_element_user(CONNECTIVITYSTATE$2);
            }
            target.set(connectivityState);
        }
    }
    
    /**
     * Nils the "connectivityState" element
     */
    public void setNilConnectivityState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType)get_store().find_element_user(CONNECTIVITYSTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.ConnectivityStateType)get_store().add_element_user(CONNECTIVITYSTATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "connectivityState" element
     */
    public void unsetConnectivityState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIVITYSTATE$2, 0);
        }
    }
    
    /**
     * Gets the "type" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType.Enum getType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "type" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType xgetType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType)get_store().find_element_user(TYPE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "type" element
     */
    public boolean isNilType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType)get_store().find_element_user(TYPE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "type" element
     */
    public boolean isSetType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TYPE$4) != 0;
        }
    }
    
    /**
     * Sets the "type" element
     */
    public void setType(org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType.Enum type)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TYPE$4);
            }
            target.setEnumValue(type);
        }
    }
    
    /**
     * Sets (as xml) the "type" element
     */
    public void xsetType(org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType type)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType)get_store().find_element_user(TYPE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType)get_store().add_element_user(TYPE$4);
            }
            target.set(type);
        }
    }
    
    /**
     * Nils the "type" element
     */
    public void setNilType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType)get_store().find_element_user(TYPE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType)get_store().add_element_user(TYPE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "type" element
     */
    public void unsetType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TYPE$4, 0);
        }
    }
}
