/*
 * XML Type:  TpDataListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tpdata.v1.impl;
/**
 * An XML TpDataListType(@http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1).
 *
 * This is a complex type.
 */
public class TpDataListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType
{
    
    public TpDataListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "tpData");
    
    
    /**
     * Gets a List of "tpData" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType> getTpDataList()
    {
        final class TpDataList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType>
        {
            public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType get(int i)
                { return TpDataListTypeImpl.this.getTpDataArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType set(int i, org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType o)
            {
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType old = TpDataListTypeImpl.this.getTpDataArray(i);
                TpDataListTypeImpl.this.setTpDataArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType o)
                { TpDataListTypeImpl.this.insertNewTpData(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType old = TpDataListTypeImpl.this.getTpDataArray(i);
                TpDataListTypeImpl.this.removeTpData(i);
                return old;
            }
            
            public int size()
                { return TpDataListTypeImpl.this.sizeOfTpDataArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TpDataList();
        }
    }
    
    /**
     * Gets array of all "tpData" elements
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType[] getTpDataArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TPDATA$0, targetList);
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType[] result = new org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "tpData" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType getTpDataArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType)get_store().find_element_user(TPDATA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "tpData" element
     */
    public int sizeOfTpDataArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPDATA$0);
        }
    }
    
    /**
     * Sets array of all "tpData" element
     */
    public void setTpDataArray(org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType[] tpDataArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(tpDataArray, TPDATA$0);
        }
    }
    
    /**
     * Sets ith "tpData" element
     */
    public void setTpDataArray(int i, org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType tpData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType)get_store().find_element_user(TPDATA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(tpData);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tpData" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType insertNewTpData(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType)get_store().insert_element_user(TPDATA$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tpData" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType addNewTpData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataType)get_store().add_element_user(TPDATA$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "tpData" element
     */
    public void removeTpData(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPDATA$0, i);
        }
    }
}
