/*
 * XML Type:  TopologicalLinkListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tl/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tl.v1.impl;
/**
 * An XML TopologicalLinkListType(@http://www.tmforum.org/mtop/nrf/xsd/tl/v1).
 *
 * This is a complex type.
 */
public class TopologicalLinkListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkListType
{
    
    public TopologicalLinkListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TL$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "tl");
    
    
    /**
     * Gets a List of "tl" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType> getTlList()
    {
        final class TlList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType>
        {
            public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType get(int i)
                { return TopologicalLinkListTypeImpl.this.getTlArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType set(int i, org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType o)
            {
                org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType old = TopologicalLinkListTypeImpl.this.getTlArray(i);
                TopologicalLinkListTypeImpl.this.setTlArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType o)
                { TopologicalLinkListTypeImpl.this.insertNewTl(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType old = TopologicalLinkListTypeImpl.this.getTlArray(i);
                TopologicalLinkListTypeImpl.this.removeTl(i);
                return old;
            }
            
            public int size()
                { return TopologicalLinkListTypeImpl.this.sizeOfTlArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TlList();
        }
    }
    
    /**
     * Gets array of all "tl" elements
     */
    public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType[] getTlArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TL$0, targetList);
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType[] result = new org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "tl" element
     */
    public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType getTlArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().find_element_user(TL$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "tl" element
     */
    public int sizeOfTlArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TL$0);
        }
    }
    
    /**
     * Sets array of all "tl" element
     */
    public void setTlArray(org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType[] tlArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(tlArray, TL$0);
        }
    }
    
    /**
     * Sets ith "tl" element
     */
    public void setTlArray(int i, org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType tl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().find_element_user(TL$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(tl);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tl" element
     */
    public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType insertNewTl(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().insert_element_user(TL$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tl" element
     */
    public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType addNewTl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().add_element_user(TL$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "tl" element
     */
    public void removeTl(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TL$0, i);
        }
    }
}
