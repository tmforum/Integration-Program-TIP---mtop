/*
 * XML Type:  TransmissionDescriptorListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tmd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tmd.v1.impl;
/**
 * An XML TransmissionDescriptorListType(@http://www.tmforum.org/mtop/nrf/xsd/tmd/v1).
 *
 * This is a complex type.
 */
public class TransmissionDescriptorListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorListType
{
    
    public TransmissionDescriptorListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TMD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "tmd");
    
    
    /**
     * Gets a List of "tmd" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType> getTmdList()
    {
        final class TmdList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType>
        {
            public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType get(int i)
                { return TransmissionDescriptorListTypeImpl.this.getTmdArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType set(int i, org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType o)
            {
                org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType old = TransmissionDescriptorListTypeImpl.this.getTmdArray(i);
                TransmissionDescriptorListTypeImpl.this.setTmdArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType o)
                { TransmissionDescriptorListTypeImpl.this.insertNewTmd(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType old = TransmissionDescriptorListTypeImpl.this.getTmdArray(i);
                TransmissionDescriptorListTypeImpl.this.removeTmd(i);
                return old;
            }
            
            public int size()
                { return TransmissionDescriptorListTypeImpl.this.sizeOfTmdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TmdList();
        }
    }
    
    /**
     * Gets array of all "tmd" elements
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType[] getTmdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TMD$0, targetList);
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType[] result = new org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "tmd" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType getTmdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().find_element_user(TMD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "tmd" element
     */
    public int sizeOfTmdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TMD$0);
        }
    }
    
    /**
     * Sets array of all "tmd" element
     */
    public void setTmdArray(org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType[] tmdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(tmdArray, TMD$0);
        }
    }
    
    /**
     * Sets ith "tmd" element
     */
    public void setTmdArray(int i, org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType tmd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().find_element_user(TMD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(tmd);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tmd" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType insertNewTmd(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().insert_element_user(TMD$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tmd" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType addNewTmd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().add_element_user(TMD$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "tmd" element
     */
    public void removeTmd(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TMD$0, i);
        }
    }
}
