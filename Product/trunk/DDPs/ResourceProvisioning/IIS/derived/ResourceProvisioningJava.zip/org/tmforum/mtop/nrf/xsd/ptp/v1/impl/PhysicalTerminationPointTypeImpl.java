/*
 * XML Type:  PhysicalTerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ptp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ptp.v1.impl;
/**
 * An XML PhysicalTerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/ptp/v1).
 *
 * This is a complex type.
 */
public class PhysicalTerminationPointTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType
{
    
    public PhysicalTerminationPointTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "direction");
    private static final javax.xml.namespace.QName TPPROTECTIONASSOCIATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "tpProtectionAssociation");
    private static final javax.xml.namespace.QName EDGEPOINT$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "edgePoint");
    private static final javax.xml.namespace.QName EQUIPMENTPROTECTED$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "equipmentProtected");
    private static final javax.xml.namespace.QName EGRESSTMDSTATE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "egressTmdState");
    private static final javax.xml.namespace.QName INGRESSTMDSTATE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "ingressTmdState");
    private static final javax.xml.namespace.QName INGRESSTRANSMISSIONDESCRIPTORNAME$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "ingressTransmissionDescriptorName");
    private static final javax.xml.namespace.QName EGRESSTRANSMISSIONDESCRIPTORNAME$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "egressTransmissionDescriptorName");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMS$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "transmissionParams");
    private static final javax.xml.namespace.QName CLIENTCONNECTIVITY$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "clientConnectivity");
    private static final javax.xml.namespace.QName SERVERCONNECTIVITY$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "serverConnectivity");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$0) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().add_element_user(DIRECTION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$0, 0);
        }
    }
    
    /**
     * Gets the "tpProtectionAssociation" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType.Enum getTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpProtectionAssociation" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType xgetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "tpProtectionAssociation" element
     */
    public boolean isNilTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpProtectionAssociation" element
     */
    public boolean isSetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPPROTECTIONASSOCIATION$2) != 0;
        }
    }
    
    /**
     * Sets the "tpProtectionAssociation" element
     */
    public void setTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType.Enum tpProtectionAssociation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.setEnumValue(tpProtectionAssociation);
        }
    }
    
    /**
     * Sets (as xml) the "tpProtectionAssociation" element
     */
    public void xsetTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType tpProtectionAssociation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.set(tpProtectionAssociation);
        }
    }
    
    /**
     * Nils the "tpProtectionAssociation" element
     */
    public void setNilTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpProtectionAssociation" element
     */
    public void unsetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPPROTECTIONASSOCIATION$2, 0);
        }
    }
    
    /**
     * Gets the "edgePoint" element
     */
    public boolean getEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "edgePoint" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINT$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "edgePoint" element
     */
    public boolean isNilEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "edgePoint" element
     */
    public boolean isSetEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EDGEPOINT$4) != 0;
        }
    }
    
    /**
     * Sets the "edgePoint" element
     */
    public void setEdgePoint(boolean edgePoint)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EDGEPOINT$4);
            }
            target.setBooleanValue(edgePoint);
        }
    }
    
    /**
     * Sets (as xml) the "edgePoint" element
     */
    public void xsetEdgePoint(org.apache.xmlbeans.XmlBoolean edgePoint)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EDGEPOINT$4);
            }
            target.set(edgePoint);
        }
    }
    
    /**
     * Nils the "edgePoint" element
     */
    public void setNilEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EDGEPOINT$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "edgePoint" element
     */
    public void unsetEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EDGEPOINT$4, 0);
        }
    }
    
    /**
     * Gets the "equipmentProtected" element
     */
    public boolean getEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "equipmentProtected" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "equipmentProtected" element
     */
    public boolean isNilEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "equipmentProtected" element
     */
    public boolean isSetEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQUIPMENTPROTECTED$6) != 0;
        }
    }
    
    /**
     * Sets the "equipmentProtected" element
     */
    public void setEquipmentProtected(boolean equipmentProtected)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EQUIPMENTPROTECTED$6);
            }
            target.setBooleanValue(equipmentProtected);
        }
    }
    
    /**
     * Sets (as xml) the "equipmentProtected" element
     */
    public void xsetEquipmentProtected(org.apache.xmlbeans.XmlBoolean equipmentProtected)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EQUIPMENTPROTECTED$6);
            }
            target.set(equipmentProtected);
        }
    }
    
    /**
     * Nils the "equipmentProtected" element
     */
    public void setNilEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EQUIPMENTPROTECTED$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "equipmentProtected" element
     */
    public void unsetEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQUIPMENTPROTECTED$6, 0);
        }
    }
    
    /**
     * Gets the "egressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum getEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "egressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType xgetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "egressTmdState" element
     */
    public boolean isNilEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "egressTmdState" element
     */
    public boolean isSetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EGRESSTMDSTATE$8) != 0;
        }
    }
    
    /**
     * Sets the "egressTmdState" element
     */
    public void setEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum egressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.setEnumValue(egressTmdState);
        }
    }
    
    /**
     * Sets (as xml) the "egressTmdState" element
     */
    public void xsetEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType egressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.set(egressTmdState);
        }
    }
    
    /**
     * Nils the "egressTmdState" element
     */
    public void setNilEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "egressTmdState" element
     */
    public void unsetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EGRESSTMDSTATE$8, 0);
        }
    }
    
    /**
     * Gets the "ingressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum getIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "ingressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType xgetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ingressTmdState" element
     */
    public boolean isNilIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ingressTmdState" element
     */
    public boolean isSetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INGRESSTMDSTATE$10) != 0;
        }
    }
    
    /**
     * Sets the "ingressTmdState" element
     */
    public void setIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum ingressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.setEnumValue(ingressTmdState);
        }
    }
    
    /**
     * Sets (as xml) the "ingressTmdState" element
     */
    public void xsetIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType ingressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.set(ingressTmdState);
        }
    }
    
    /**
     * Nils the "ingressTmdState" element
     */
    public void setNilIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ingressTmdState" element
     */
    public void unsetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INGRESSTMDSTATE$10, 0);
        }
    }
    
    /**
     * Gets the "ingressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ingressTransmissionDescriptorName" element
     */
    public boolean isNilIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ingressTransmissionDescriptorName" element
     */
    public boolean isSetIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INGRESSTRANSMISSIONDESCRIPTORNAME$12) != 0;
        }
    }
    
    /**
     * Sets the "ingressTransmissionDescriptorName" element
     */
    public void setIngressTransmissionDescriptorName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType ingressTransmissionDescriptorName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$12);
            }
            target.set(ingressTransmissionDescriptorName);
        }
    }
    
    /**
     * Appends and returns a new empty "ingressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$12);
            return target;
        }
    }
    
    /**
     * Nils the "ingressTransmissionDescriptorName" element
     */
    public void setNilIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ingressTransmissionDescriptorName" element
     */
    public void unsetIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INGRESSTRANSMISSIONDESCRIPTORNAME$12, 0);
        }
    }
    
    /**
     * Gets the "egressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "egressTransmissionDescriptorName" element
     */
    public boolean isNilEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "egressTransmissionDescriptorName" element
     */
    public boolean isSetEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EGRESSTRANSMISSIONDESCRIPTORNAME$14) != 0;
        }
    }
    
    /**
     * Sets the "egressTransmissionDescriptorName" element
     */
    public void setEgressTransmissionDescriptorName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType egressTransmissionDescriptorName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$14);
            }
            target.set(egressTransmissionDescriptorName);
        }
    }
    
    /**
     * Appends and returns a new empty "egressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$14);
            return target;
        }
    }
    
    /**
     * Nils the "egressTransmissionDescriptorName" element
     */
    public void setNilEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "egressTransmissionDescriptorName" element
     */
    public void unsetEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EGRESSTRANSMISSIONDESCRIPTORNAME$14, 0);
        }
    }
    
    /**
     * Gets the "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParams" element
     */
    public boolean isNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParams" element
     */
    public boolean isSetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMS$16) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParams" element
     */
    public void setTransmissionParams(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParams)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$16);
            }
            target.set(transmissionParams);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$16);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParams" element
     */
    public void setNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParams" element
     */
    public void unsetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMS$16, 0);
        }
    }
    
    /**
     * Gets the "clientConnectivity" element
     */
    public java.lang.String getClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLIENTCONNECTIVITY$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "clientConnectivity" element
     */
    public org.apache.xmlbeans.XmlString xgetClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLIENTCONNECTIVITY$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "clientConnectivity" element
     */
    public boolean isNilClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLIENTCONNECTIVITY$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "clientConnectivity" element
     */
    public boolean isSetClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLIENTCONNECTIVITY$18) != 0;
        }
    }
    
    /**
     * Sets the "clientConnectivity" element
     */
    public void setClientConnectivity(java.lang.String clientConnectivity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLIENTCONNECTIVITY$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CLIENTCONNECTIVITY$18);
            }
            target.setStringValue(clientConnectivity);
        }
    }
    
    /**
     * Sets (as xml) the "clientConnectivity" element
     */
    public void xsetClientConnectivity(org.apache.xmlbeans.XmlString clientConnectivity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLIENTCONNECTIVITY$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CLIENTCONNECTIVITY$18);
            }
            target.set(clientConnectivity);
        }
    }
    
    /**
     * Nils the "clientConnectivity" element
     */
    public void setNilClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLIENTCONNECTIVITY$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CLIENTCONNECTIVITY$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "clientConnectivity" element
     */
    public void unsetClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLIENTCONNECTIVITY$18, 0);
        }
    }
    
    /**
     * Gets the "serverConnectivity" element
     */
    public java.lang.String getServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVERCONNECTIVITY$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serverConnectivity" element
     */
    public org.apache.xmlbeans.XmlString xgetServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVERCONNECTIVITY$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "serverConnectivity" element
     */
    public boolean isNilServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVERCONNECTIVITY$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "serverConnectivity" element
     */
    public boolean isSetServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVERCONNECTIVITY$20) != 0;
        }
    }
    
    /**
     * Sets the "serverConnectivity" element
     */
    public void setServerConnectivity(java.lang.String serverConnectivity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVERCONNECTIVITY$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVERCONNECTIVITY$20);
            }
            target.setStringValue(serverConnectivity);
        }
    }
    
    /**
     * Sets (as xml) the "serverConnectivity" element
     */
    public void xsetServerConnectivity(org.apache.xmlbeans.XmlString serverConnectivity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVERCONNECTIVITY$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVERCONNECTIVITY$20);
            }
            target.set(serverConnectivity);
        }
    }
    
    /**
     * Nils the "serverConnectivity" element
     */
    public void setNilServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVERCONNECTIVITY$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVERCONNECTIVITY$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "serverConnectivity" element
     */
    public void unsetServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVERCONNECTIVITY$20, 0);
        }
    }
}
