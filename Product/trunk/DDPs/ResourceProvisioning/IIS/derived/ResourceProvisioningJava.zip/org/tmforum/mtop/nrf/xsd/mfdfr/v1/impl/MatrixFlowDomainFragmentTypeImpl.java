/*
 * XML Type:  MatrixFlowDomainFragmentType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mfdfr.v1.impl;
/**
 * An XML MatrixFlowDomainFragmentType(@http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1).
 *
 * This is a complex type.
 */
public class MatrixFlowDomainFragmentTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType
{
    
    public MatrixFlowDomainFragmentTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "direction");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMETERLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "transmissionParameterList");
    private static final javax.xml.namespace.QName AENDTPREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "aEndTpRefList");
    private static final javax.xml.namespace.QName ZENDTPREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "zEndTpRefList");
    private static final javax.xml.namespace.QName ISFLEXIBLE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "isFlexible");
    private static final javax.xml.namespace.QName ISACTIVE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "isActive");
    private static final javax.xml.namespace.QName MFDFRTYPE$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "mfdfrType");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "vendorExtensions");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$0) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$0, 0);
        }
    }
    
    /**
     * Gets the "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType getTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    public boolean isNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParameterList" element
     */
    public boolean isSetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMETERLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParameterList" element
     */
    public void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType transmissionParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            }
            target.set(transmissionParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType addNewTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParameterList" element
     */
    public void setNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    public void unsetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMETERLIST$2, 0);
        }
    }
    
    /**
     * Gets the "aEndTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(AENDTPREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "aEndTpRefList" element
     */
    public boolean isNilAEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(AENDTPREFLIST$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aEndTpRefList" element
     */
    public boolean isSetAEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AENDTPREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "aEndTpRefList" element
     */
    public void setAEndTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType aEndTpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(AENDTPREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(AENDTPREFLIST$4);
            }
            target.set(aEndTpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "aEndTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(AENDTPREFLIST$4);
            return target;
        }
    }
    
    /**
     * Nils the "aEndTpRefList" element
     */
    public void setNilAEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(AENDTPREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(AENDTPREFLIST$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aEndTpRefList" element
     */
    public void unsetAEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AENDTPREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "zEndTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getZEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ZENDTPREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "zEndTpRefList" element
     */
    public boolean isNilZEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ZENDTPREFLIST$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "zEndTpRefList" element
     */
    public boolean isSetZEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZENDTPREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "zEndTpRefList" element
     */
    public void setZEndTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType zEndTpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ZENDTPREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ZENDTPREFLIST$6);
            }
            target.set(zEndTpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "zEndTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewZEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ZENDTPREFLIST$6);
            return target;
        }
    }
    
    /**
     * Nils the "zEndTpRefList" element
     */
    public void setNilZEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ZENDTPREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ZENDTPREFLIST$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "zEndTpRefList" element
     */
    public void unsetZEndTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZENDTPREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "isFlexible" element
     */
    public boolean getIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isFlexible" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isFlexible" element
     */
    public boolean isNilIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isFlexible" element
     */
    public boolean isSetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISFLEXIBLE$8) != 0;
        }
    }
    
    /**
     * Sets the "isFlexible" element
     */
    public void setIsFlexible(boolean isFlexible)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISFLEXIBLE$8);
            }
            target.setBooleanValue(isFlexible);
        }
    }
    
    /**
     * Sets (as xml) the "isFlexible" element
     */
    public void xsetIsFlexible(org.apache.xmlbeans.XmlBoolean isFlexible)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISFLEXIBLE$8);
            }
            target.set(isFlexible);
        }
    }
    
    /**
     * Nils the "isFlexible" element
     */
    public void setNilIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISFLEXIBLE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isFlexible" element
     */
    public void unsetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISFLEXIBLE$8, 0);
        }
    }
    
    /**
     * Gets the "isActive" element
     */
    public boolean getIsActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISACTIVE$10, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isActive" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISACTIVE$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isActive" element
     */
    public boolean isNilIsActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISACTIVE$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isActive" element
     */
    public boolean isSetIsActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISACTIVE$10) != 0;
        }
    }
    
    /**
     * Sets the "isActive" element
     */
    public void setIsActive(boolean isActive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISACTIVE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISACTIVE$10);
            }
            target.setBooleanValue(isActive);
        }
    }
    
    /**
     * Sets (as xml) the "isActive" element
     */
    public void xsetIsActive(org.apache.xmlbeans.XmlBoolean isActive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISACTIVE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISACTIVE$10);
            }
            target.set(isActive);
        }
    }
    
    /**
     * Nils the "isActive" element
     */
    public void setNilIsActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISACTIVE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISACTIVE$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isActive" element
     */
    public void unsetIsActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISACTIVE$10, 0);
        }
    }
    
    /**
     * Gets the "mfdfrType" element
     */
    public java.lang.String getMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "mfdfrType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType xgetMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().find_element_user(MFDFRTYPE$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "mfdfrType" element
     */
    public boolean isNilMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "mfdfrType" element
     */
    public boolean isSetMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFDFRTYPE$12) != 0;
        }
    }
    
    /**
     * Sets the "mfdfrType" element
     */
    public void setMfdfrType(java.lang.String mfdfrType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MFDFRTYPE$12);
            }
            target.setStringValue(mfdfrType);
        }
    }
    
    /**
     * Sets (as xml) the "mfdfrType" element
     */
    public void xsetMfdfrType(org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType mfdfrType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().add_element_user(MFDFRTYPE$12);
            }
            target.set(mfdfrType);
        }
    }
    
    /**
     * Nils the "mfdfrType" element
     */
    public void setNilMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().add_element_user(MFDFRTYPE$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "mfdfrType" element
     */
    public void unsetMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFDFRTYPE$12, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$14) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$14);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$14);
            return target;
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$14, 0);
        }
    }
}
