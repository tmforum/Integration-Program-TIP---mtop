/*
 * XML Type:  MatrixFlowDomainFragmentType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mfdfr.v1.impl;
/**
 * An XML MatrixFlowDomainFragmentType(@http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1).
 *
 * This is a complex type.
 */
public class MatrixFlowDomainFragmentTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType
{
    
    public MatrixFlowDomainFragmentTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "direction");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "transmissionParams");
    private static final javax.xml.namespace.QName AEND$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "aEnd");
    private static final javax.xml.namespace.QName ZEND$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "zEnd");
    private static final javax.xml.namespace.QName FLEXIBLE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "flexible");
    private static final javax.xml.namespace.QName ACTIVE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "active");
    private static final javax.xml.namespace.QName MFDFRTYPE$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "mfdfrType");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "vendorExtensions");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$0) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$0, 0);
        }
    }
    
    /**
     * Gets the "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType getTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParams" element
     */
    public boolean isNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMS$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParams" element
     */
    public boolean isSetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMS$2) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParams" element
     */
    public void setTransmissionParams(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType transmissionParams)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMS$2);
            }
            target.set(transmissionParams);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType addNewTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMS$2);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParams" element
     */
    public void setNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMS$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParams" element
     */
    public void unsetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMS$2, 0);
        }
    }
    
    /**
     * Gets the "aEnd" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(AEND$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "aEnd" element
     */
    public boolean isNilAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(AEND$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aEnd" element
     */
    public boolean isSetAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AEND$4) != 0;
        }
    }
    
    /**
     * Sets the "aEnd" element
     */
    public void setAEnd(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType aEnd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(AEND$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(AEND$4);
            }
            target.set(aEnd);
        }
    }
    
    /**
     * Appends and returns a new empty "aEnd" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(AEND$4);
            return target;
        }
    }
    
    /**
     * Nils the "aEnd" element
     */
    public void setNilAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(AEND$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(AEND$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aEnd" element
     */
    public void unsetAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AEND$4, 0);
        }
    }
    
    /**
     * Gets the "zEnd" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ZEND$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "zEnd" element
     */
    public boolean isNilZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ZEND$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "zEnd" element
     */
    public boolean isSetZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZEND$6) != 0;
        }
    }
    
    /**
     * Sets the "zEnd" element
     */
    public void setZEnd(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType zEnd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ZEND$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(ZEND$6);
            }
            target.set(zEnd);
        }
    }
    
    /**
     * Appends and returns a new empty "zEnd" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(ZEND$6);
            return target;
        }
    }
    
    /**
     * Nils the "zEnd" element
     */
    public void setNilZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ZEND$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(ZEND$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "zEnd" element
     */
    public void unsetZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZEND$6, 0);
        }
    }
    
    /**
     * Gets the "flexible" element
     */
    public boolean getFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FLEXIBLE$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "flexible" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FLEXIBLE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "flexible" element
     */
    public boolean isNilFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FLEXIBLE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "flexible" element
     */
    public boolean isSetFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FLEXIBLE$8) != 0;
        }
    }
    
    /**
     * Sets the "flexible" element
     */
    public void setFlexible(boolean flexible)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FLEXIBLE$8);
            }
            target.setBooleanValue(flexible);
        }
    }
    
    /**
     * Sets (as xml) the "flexible" element
     */
    public void xsetFlexible(org.apache.xmlbeans.XmlBoolean flexible)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FLEXIBLE$8);
            }
            target.set(flexible);
        }
    }
    
    /**
     * Nils the "flexible" element
     */
    public void setNilFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FLEXIBLE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "flexible" element
     */
    public void unsetFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FLEXIBLE$8, 0);
        }
    }
    
    /**
     * Gets the "active" element
     */
    public boolean getActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVE$10, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "active" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACTIVE$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "active" element
     */
    public boolean isNilActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACTIVE$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "active" element
     */
    public boolean isSetActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACTIVE$10) != 0;
        }
    }
    
    /**
     * Sets the "active" element
     */
    public void setActive(boolean active)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACTIVE$10);
            }
            target.setBooleanValue(active);
        }
    }
    
    /**
     * Sets (as xml) the "active" element
     */
    public void xsetActive(org.apache.xmlbeans.XmlBoolean active)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACTIVE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ACTIVE$10);
            }
            target.set(active);
        }
    }
    
    /**
     * Nils the "active" element
     */
    public void setNilActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACTIVE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ACTIVE$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "active" element
     */
    public void unsetActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACTIVE$10, 0);
        }
    }
    
    /**
     * Gets the "mfdfrType" element
     */
    public java.lang.String getMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "mfdfrType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType xgetMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType)get_store().find_element_user(MFDFRTYPE$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "mfdfrType" element
     */
    public boolean isNilMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "mfdfrType" element
     */
    public boolean isSetMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFDFRTYPE$12) != 0;
        }
    }
    
    /**
     * Sets the "mfdfrType" element
     */
    public void setMfdfrType(java.lang.String mfdfrType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MFDFRTYPE$12);
            }
            target.setStringValue(mfdfrType);
        }
    }
    
    /**
     * Sets (as xml) the "mfdfrType" element
     */
    public void xsetMfdfrType(org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType mfdfrType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType)get_store().add_element_user(MFDFRTYPE$12);
            }
            target.set(mfdfrType);
        }
    }
    
    /**
     * Nils the "mfdfrType" element
     */
    public void setNilMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType)get_store().find_element_user(MFDFRTYPE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.FdfrTypeType)get_store().add_element_user(MFDFRTYPE$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "mfdfrType" element
     */
    public void unsetMfdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFDFRTYPE$12, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$14) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$14);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$14);
            return target;
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$14, 0);
        }
    }
}
