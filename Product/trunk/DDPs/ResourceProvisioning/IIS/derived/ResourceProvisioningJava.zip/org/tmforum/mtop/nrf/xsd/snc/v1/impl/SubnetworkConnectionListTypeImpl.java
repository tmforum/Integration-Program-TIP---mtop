/*
 * XML Type:  SubnetworkConnectionListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/snc/v1
 * Java type: org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.snc.v1.impl;
/**
 * An XML SubnetworkConnectionListType(@http://www.tmforum.org/mtop/nrf/xsd/snc/v1).
 *
 * This is a complex type.
 */
public class SubnetworkConnectionListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType
{
    
    public SubnetworkConnectionListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SNC$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "snc");
    
    
    /**
     * Gets a List of "snc" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType> getSncList()
    {
        final class SncList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType>
        {
            public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType get(int i)
                { return SubnetworkConnectionListTypeImpl.this.getSncArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType set(int i, org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType o)
            {
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType old = SubnetworkConnectionListTypeImpl.this.getSncArray(i);
                SubnetworkConnectionListTypeImpl.this.setSncArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType o)
                { SubnetworkConnectionListTypeImpl.this.insertNewSnc(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType old = SubnetworkConnectionListTypeImpl.this.getSncArray(i);
                SubnetworkConnectionListTypeImpl.this.removeSnc(i);
                return old;
            }
            
            public int size()
                { return SubnetworkConnectionListTypeImpl.this.sizeOfSncArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new SncList();
        }
    }
    
    /**
     * Gets array of all "snc" elements
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType[] getSncArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SNC$0, targetList);
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType[] result = new org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "snc" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getSncArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNC$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "snc" element
     */
    public int sizeOfSncArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SNC$0);
        }
    }
    
    /**
     * Sets array of all "snc" element
     */
    public void setSncArray(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType[] sncArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(sncArray, SNC$0);
        }
    }
    
    /**
     * Sets ith "snc" element
     */
    public void setSncArray(int i, org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType snc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNC$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(snc);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "snc" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType insertNewSnc(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().insert_element_user(SNC$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "snc" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewSnc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNC$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "snc" element
     */
    public void removeSnc(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SNC$0, i);
        }
    }
}
