/*
 * An XML document type.
 * Localname: createModifiedSubnetworkConnectionResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createModifiedSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateModifiedSubnetworkConnectionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument
{
    
    public CreateModifiedSubnetworkConnectionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEMODIFIEDSUBNETWORKCONNECTIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createModifiedSubnetworkConnectionResponse");
    
    
    /**
     * Gets the "createModifiedSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse getCreateModifiedSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse)get_store().find_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createModifiedSubnetworkConnectionResponse" element
     */
    public void setCreateModifiedSubnetworkConnectionResponse(org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse createModifiedSubnetworkConnectionResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse)get_store().find_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse)get_store().add_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONRESPONSE$0);
            }
            target.set(createModifiedSubnetworkConnectionResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "createModifiedSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse addNewCreateModifiedSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse)get_store().add_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML createModifiedSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateModifiedSubnetworkConnectionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionResponseDocument.CreateModifiedSubnetworkConnectionResponse
    {
        
        public CreateModifiedSubnetworkConnectionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPDATALISTTOMODIFY$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpDataListToModify");
        private static final javax.xml.namespace.QName NEWSNC$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "newSnc");
        private static final javax.xml.namespace.QName ERRORREASON$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "errorReason");
        
        
        /**
         * Gets the "tpDataListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPDATALISTTOMODIFY$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpDataListToModify" element
         */
        public boolean isSetTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPDATALISTTOMODIFY$0) != 0;
            }
        }
        
        /**
         * Sets the "tpDataListToModify" element
         */
        public void setTpDataListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpDataListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPDATALISTTOMODIFY$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPDATALISTTOMODIFY$0);
                }
                target.set(tpDataListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpDataListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPDATALISTTOMODIFY$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tpDataListToModify" element
         */
        public void unsetTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPDATALISTTOMODIFY$0, 0);
            }
        }
        
        /**
         * Gets the "newSnc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getNewSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(NEWSNC$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "newSnc" element
         */
        public boolean isSetNewSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NEWSNC$2) != 0;
            }
        }
        
        /**
         * Sets the "newSnc" element
         */
        public void setNewSnc(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType newSnc)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(NEWSNC$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(NEWSNC$2);
                }
                target.set(newSnc);
            }
        }
        
        /**
         * Appends and returns a new empty "newSnc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewNewSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(NEWSNC$2);
                return target;
            }
        }
        
        /**
         * Unsets the "newSnc" element
         */
        public void unsetNewSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NEWSNC$2, 0);
            }
        }
        
        /**
         * Gets the "errorReason" element
         */
        public java.lang.String getErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "errorReason" element
         */
        public org.apache.xmlbeans.XmlString xgetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "errorReason" element
         */
        public boolean isSetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRORREASON$4) != 0;
            }
        }
        
        /**
         * Sets the "errorReason" element
         */
        public void setErrorReason(java.lang.String errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ERRORREASON$4);
                }
                target.setStringValue(errorReason);
            }
        }
        
        /**
         * Sets (as xml) the "errorReason" element
         */
        public void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$4);
                }
                target.set(errorReason);
            }
        }
        
        /**
         * Unsets the "errorReason" element
         */
        public void unsetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRORREASON$4, 0);
            }
        }
    }
}
