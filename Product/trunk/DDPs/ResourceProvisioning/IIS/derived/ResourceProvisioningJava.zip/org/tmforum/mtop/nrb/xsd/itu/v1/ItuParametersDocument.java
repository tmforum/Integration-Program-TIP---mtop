/*
 * An XML document type.
 * Localname: ituParameters
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1;


/**
 * A document containing one ituParameters(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1) element.
 *
 * This is a complex type.
 */
public interface ItuParametersDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ItuParametersDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFA029CF23A6AA97F9ACEA74311DBFDC2").resolveHandle("ituparameters62c9doctype");
    
    /**
     * Gets the "ituParameters" element
     */
    org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument.ItuParameters getItuParameters();
    
    /**
     * Sets the "ituParameters" element
     */
    void setItuParameters(org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument.ItuParameters ituParameters);
    
    /**
     * Appends and returns a new empty "ituParameters" element
     */
    org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument.ItuParameters addNewItuParameters();
    
    /**
     * An XML ituParameters(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
     *
     * This is a complex type.
     */
    public interface ItuParameters extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ItuParameters.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFA029CF23A6AA97F9ACEA74311DBFDC2").resolveHandle("ituparameterse629elemtype");
        
        /**
         * Gets the "x721.OperationalState" element
         */
        boolean getX721OperationalState();
        
        /**
         * Gets (as xml) the "x721.OperationalState" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType xgetX721OperationalState();
        
        /**
         * True if has "x721.OperationalState" element
         */
        boolean isSetX721OperationalState();
        
        /**
         * Sets the "x721.OperationalState" element
         */
        void setX721OperationalState(boolean x721OperationalState);
        
        /**
         * Sets (as xml) the "x721.OperationalState" element
         */
        void xsetX721OperationalState(org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType x721OperationalState);
        
        /**
         * Unsets the "x721.OperationalState" element
         */
        void unsetX721OperationalState();
        
        /**
         * Gets the "x721.AdministrativeState" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum getX721AdministrativeState();
        
        /**
         * Gets (as xml) the "x721.AdministrativeState" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType xgetX721AdministrativeState();
        
        /**
         * True if has "x721.AdministrativeState" element
         */
        boolean isSetX721AdministrativeState();
        
        /**
         * Sets the "x721.AdministrativeState" element
         */
        void setX721AdministrativeState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum x721AdministrativeState);
        
        /**
         * Sets (as xml) the "x721.AdministrativeState" element
         */
        void xsetX721AdministrativeState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType x721AdministrativeState);
        
        /**
         * Unsets the "x721.AdministrativeState" element
         */
        void unsetX721AdministrativeState();
        
        /**
         * Gets the "x721.UsageState" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType.Enum getX721UsageState();
        
        /**
         * Gets (as xml) the "x721.UsageState" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType xgetX721UsageState();
        
        /**
         * True if has "x721.UsageState" element
         */
        boolean isSetX721UsageState();
        
        /**
         * Sets the "x721.UsageState" element
         */
        void setX721UsageState(org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType.Enum x721UsageState);
        
        /**
         * Sets (as xml) the "x721.UsageState" element
         */
        void xsetX721UsageState(org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType x721UsageState);
        
        /**
         * Unsets the "x721.UsageState" element
         */
        void unsetX721UsageState();
        
        /**
         * Gets the "x721.AvailabilityStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType.Enum getX721AvailabilityStatus();
        
        /**
         * Gets (as xml) the "x721.AvailabilityStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType xgetX721AvailabilityStatus();
        
        /**
         * True if has "x721.AvailabilityStatus" element
         */
        boolean isSetX721AvailabilityStatus();
        
        /**
         * Sets the "x721.AvailabilityStatus" element
         */
        void setX721AvailabilityStatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType.Enum x721AvailabilityStatus);
        
        /**
         * Sets (as xml) the "x721.AvailabilityStatus" element
         */
        void xsetX721AvailabilityStatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType x721AvailabilityStatus);
        
        /**
         * Unsets the "x721.AvailabilityStatus" element
         */
        void unsetX721AvailabilityStatus();
        
        /**
         * Gets the "x721.ControlStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType.Enum getX721ControlStatus();
        
        /**
         * Gets (as xml) the "x721.ControlStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType xgetX721ControlStatus();
        
        /**
         * True if has "x721.ControlStatus" element
         */
        boolean isSetX721ControlStatus();
        
        /**
         * Sets the "x721.ControlStatus" element
         */
        void setX721ControlStatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType.Enum x721ControlStatus);
        
        /**
         * Sets (as xml) the "x721.ControlStatus" element
         */
        void xsetX721ControlStatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType x721ControlStatus);
        
        /**
         * Unsets the "x721.ControlStatus" element
         */
        void unsetX721ControlStatus();
        
        /**
         * Gets the "m3100.HolderStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType.Enum getM3100HolderStatus();
        
        /**
         * Gets (as xml) the "m3100.HolderStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType xgetM3100HolderStatus();
        
        /**
         * True if has "m3100.HolderStatus" element
         */
        boolean isSetM3100HolderStatus();
        
        /**
         * Sets the "m3100.HolderStatus" element
         */
        void setM3100HolderStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType.Enum m3100HolderStatus);
        
        /**
         * Sets (as xml) the "m3100.HolderStatus" element
         */
        void xsetM3100HolderStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType m3100HolderStatus);
        
        /**
         * Unsets the "m3100.HolderStatus" element
         */
        void unsetM3100HolderStatus();
        
        /**
         * Gets the "m3100.CircuitPackType" element
         */
        java.lang.String getM3100CircuitPackType();
        
        /**
         * Gets (as xml) the "m3100.CircuitPackType" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100CircuitPackTypeType xgetM3100CircuitPackType();
        
        /**
         * True if has "m3100.CircuitPackType" element
         */
        boolean isSetM3100CircuitPackType();
        
        /**
         * Sets the "m3100.CircuitPackType" element
         */
        void setM3100CircuitPackType(java.lang.String m3100CircuitPackType);
        
        /**
         * Sets (as xml) the "m3100.CircuitPackType" element
         */
        void xsetM3100CircuitPackType(org.tmforum.mtop.nrb.xsd.itu.v1.M3100CircuitPackTypeType m3100CircuitPackType);
        
        /**
         * Unsets the "m3100.CircuitPackType" element
         */
        void unsetM3100CircuitPackType();
        
        /**
         * Gets the "m3100.AlarmStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType.Enum getM3100AlarmStatus();
        
        /**
         * Gets (as xml) the "m3100.AlarmStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType xgetM3100AlarmStatus();
        
        /**
         * True if has "m3100.AlarmStatus" element
         */
        boolean isSetM3100AlarmStatus();
        
        /**
         * Sets the "m3100.AlarmStatus" element
         */
        void setM3100AlarmStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType.Enum m3100AlarmStatus);
        
        /**
         * Sets (as xml) the "m3100.AlarmStatus" element
         */
        void xsetM3100AlarmStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType m3100AlarmStatus);
        
        /**
         * Unsets the "m3100.AlarmStatus" element
         */
        void unsetM3100AlarmStatus();
        
        /**
         * Gets the "m3100.ArcState" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType.Enum getM3100ArcState();
        
        /**
         * Gets (as xml) the "m3100.ArcState" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType xgetM3100ArcState();
        
        /**
         * True if has "m3100.ArcState" element
         */
        boolean isSetM3100ArcState();
        
        /**
         * Sets the "m3100.ArcState" element
         */
        void setM3100ArcState(org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType.Enum m3100ArcState);
        
        /**
         * Sets (as xml) the "m3100.ArcState" element
         */
        void xsetM3100ArcState(org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType m3100ArcState);
        
        /**
         * Unsets the "m3100.ArcState" element
         */
        void unsetM3100ArcState();
        
        /**
         * Gets the "m3100.NALMTIInterval" element
         */
        java.lang.Object getM3100NALMTIInterval();
        
        /**
         * Gets (as xml) the "m3100.NALMTIInterval" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType xgetM3100NALMTIInterval();
        
        /**
         * True if has "m3100.NALMTIInterval" element
         */
        boolean isSetM3100NALMTIInterval();
        
        /**
         * Sets the "m3100.NALMTIInterval" element
         */
        void setM3100NALMTIInterval(java.lang.Object m3100NALMTIInterval);
        
        /**
         * Sets (as xml) the "m3100.NALMTIInterval" element
         */
        void xsetM3100NALMTIInterval(org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType m3100NALMTIInterval);
        
        /**
         * Unsets the "m3100.NALMTIInterval" element
         */
        void unsetM3100NALMTIInterval();
        
        /**
         * Gets the "m3100.NALMQIInterval" element
         */
        java.lang.Object getM3100NALMQIInterval();
        
        /**
         * Gets (as xml) the "m3100.NALMQIInterval" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMQIIntervalType xgetM3100NALMQIInterval();
        
        /**
         * True if has "m3100.NALMQIInterval" element
         */
        boolean isSetM3100NALMQIInterval();
        
        /**
         * Sets the "m3100.NALMQIInterval" element
         */
        void setM3100NALMQIInterval(java.lang.Object m3100NALMQIInterval);
        
        /**
         * Sets (as xml) the "m3100.NALMQIInterval" element
         */
        void xsetM3100NALMQIInterval(org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMQIIntervalType m3100NALMQIInterval);
        
        /**
         * Unsets the "m3100.NALMQIInterval" element
         */
        void unsetM3100NALMQIInterval();
        
        /**
         * Gets the "m3100.ArcQIStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType.Enum getM3100ArcQIStatus();
        
        /**
         * Gets (as xml) the "m3100.ArcQIStatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType xgetM3100ArcQIStatus();
        
        /**
         * True if has "m3100.ArcQIStatus" element
         */
        boolean isSetM3100ArcQIStatus();
        
        /**
         * Sets the "m3100.ArcQIStatus" element
         */
        void setM3100ArcQIStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType.Enum m3100ArcQIStatus);
        
        /**
         * Sets (as xml) the "m3100.ArcQIStatus" element
         */
        void xsetM3100ArcQIStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType m3100ArcQIStatus);
        
        /**
         * Unsets the "m3100.ArcQIStatus" element
         */
        void unsetM3100ArcQIStatus();
        
        /**
         * Gets the "x721.Unkownstatus" element
         */
        boolean getX721Unkownstatus();
        
        /**
         * Gets (as xml) the "x721.Unkownstatus" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType xgetX721Unkownstatus();
        
        /**
         * True if has "x721.Unkownstatus" element
         */
        boolean isSetX721Unkownstatus();
        
        /**
         * Sets the "x721.Unkownstatus" element
         */
        void setX721Unkownstatus(boolean x721Unkownstatus);
        
        /**
         * Sets (as xml) the "x721.Unkownstatus" element
         */
        void xsetX721Unkownstatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType x721Unkownstatus);
        
        /**
         * Unsets the "x721.Unkownstatus" element
         */
        void unsetX721Unkownstatus();
        
        /**
         * Gets the "x721.State" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721StateType getX721State();
        
        /**
         * True if has "x721.State" element
         */
        boolean isSetX721State();
        
        /**
         * Sets the "x721.State" element
         */
        void setX721State(org.tmforum.mtop.nrb.xsd.itu.v1.X721StateType x721State);
        
        /**
         * Appends and returns a new empty "x721.State" element
         */
        org.tmforum.mtop.nrb.xsd.itu.v1.X721StateType addNewX721State();
        
        /**
         * Unsets the "x721.State" element
         */
        void unsetX721State();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument.ItuParameters newInstance() {
              return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument.ItuParameters) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument.ItuParameters newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument.ItuParameters) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument newInstance() {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.ItuParametersDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
