/*
 * An XML document type.
 * Localname: deactivateAndDeleteSncException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one deactivateAndDeleteSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class DeactivateAndDeleteSncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument
{
    
    public DeactivateAndDeleteSncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DEACTIVATEANDDELETESNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "deactivateAndDeleteSncException");
    
    
    /**
     * Gets the "deactivateAndDeleteSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException getDeactivateAndDeleteSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException)get_store().find_element_user(DEACTIVATEANDDELETESNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deactivateAndDeleteSncException" element
     */
    public void setDeactivateAndDeleteSncException(org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException deactivateAndDeleteSncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException)get_store().find_element_user(DEACTIVATEANDDELETESNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException)get_store().add_element_user(DEACTIVATEANDDELETESNCEXCEPTION$0);
            }
            target.set(deactivateAndDeleteSncException);
        }
    }
    
    /**
     * Appends and returns a new empty "deactivateAndDeleteSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException addNewDeactivateAndDeleteSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException)get_store().add_element_user(DEACTIVATEANDDELETESNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deactivateAndDeleteSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class DeactivateAndDeleteSncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSncExceptionDocument.DeactivateAndDeleteSncException
    {
        
        public DeactivateAndDeleteSncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
