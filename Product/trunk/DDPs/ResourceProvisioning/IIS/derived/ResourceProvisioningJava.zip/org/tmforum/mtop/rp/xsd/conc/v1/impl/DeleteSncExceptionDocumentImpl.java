/*
 * An XML document type.
 * Localname: deleteSncException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one deleteSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class DeleteSncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument
{
    
    public DeleteSncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETESNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "deleteSncException");
    
    
    /**
     * Gets the "deleteSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException getDeleteSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException)get_store().find_element_user(DELETESNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteSncException" element
     */
    public void setDeleteSncException(org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException deleteSncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException)get_store().find_element_user(DELETESNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException)get_store().add_element_user(DELETESNCEXCEPTION$0);
            }
            target.set(deleteSncException);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException addNewDeleteSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException)get_store().add_element_user(DELETESNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deleteSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class DeleteSncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeleteSncExceptionDocument.DeleteSncException
    {
        
        public DeleteSncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
