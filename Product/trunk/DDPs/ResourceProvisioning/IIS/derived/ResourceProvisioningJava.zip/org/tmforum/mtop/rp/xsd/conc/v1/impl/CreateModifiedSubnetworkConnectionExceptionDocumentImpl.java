/*
 * An XML document type.
 * Localname: createModifiedSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createModifiedSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateModifiedSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument
{
    
    public CreateModifiedSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEMODIFIEDSUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createModifiedSubnetworkConnectionException");
    
    
    /**
     * Gets the "createModifiedSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException getCreateModifiedSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException)get_store().find_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createModifiedSubnetworkConnectionException" element
     */
    public void setCreateModifiedSubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException createModifiedSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException)get_store().find_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException)get_store().add_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(createModifiedSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "createModifiedSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException addNewCreateModifiedSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException)get_store().add_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML createModifiedSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateModifiedSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionExceptionDocument.CreateModifiedSubnetworkConnectionException
    {
        
        public CreateModifiedSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
