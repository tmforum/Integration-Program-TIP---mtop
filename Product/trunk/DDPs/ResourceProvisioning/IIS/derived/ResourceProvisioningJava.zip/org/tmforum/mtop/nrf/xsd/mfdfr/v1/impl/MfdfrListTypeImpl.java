/*
 * XML Type:  MfdfrListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mfdfr.v1.MfdfrListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mfdfr.v1.impl;
/**
 * An XML MfdfrListType(@http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1).
 *
 * This is a complex type.
 */
public class MfdfrListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.mfdfr.v1.MfdfrListType
{
    
    public MfdfrListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MFDFR$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "mfdfr");
    
    
    /**
     * Gets a List of "mfdfr" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType> getMfdfrList()
    {
        final class MfdfrList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType>
        {
            public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType get(int i)
                { return MfdfrListTypeImpl.this.getMfdfrArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType set(int i, org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType o)
            {
                org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType old = MfdfrListTypeImpl.this.getMfdfrArray(i);
                MfdfrListTypeImpl.this.setMfdfrArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType o)
                { MfdfrListTypeImpl.this.insertNewMfdfr(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType old = MfdfrListTypeImpl.this.getMfdfrArray(i);
                MfdfrListTypeImpl.this.removeMfdfr(i);
                return old;
            }
            
            public int size()
                { return MfdfrListTypeImpl.this.sizeOfMfdfrArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new MfdfrList();
        }
    }
    
    /**
     * Gets array of all "mfdfr" elements
     */
    public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType[] getMfdfrArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(MFDFR$0, targetList);
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType[] result = new org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "mfdfr" element
     */
    public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType getMfdfrArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().find_element_user(MFDFR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "mfdfr" element
     */
    public int sizeOfMfdfrArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFDFR$0);
        }
    }
    
    /**
     * Sets array of all "mfdfr" element
     */
    public void setMfdfrArray(org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType[] mfdfrArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(mfdfrArray, MFDFR$0);
        }
    }
    
    /**
     * Sets ith "mfdfr" element
     */
    public void setMfdfrArray(int i, org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType mfdfr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().find_element_user(MFDFR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(mfdfr);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "mfdfr" element
     */
    public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType insertNewMfdfr(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().insert_element_user(MFDFR$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "mfdfr" element
     */
    public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType addNewMfdfr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().add_element_user(MFDFR$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "mfdfr" element
     */
    public void removeMfdfr(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFDFR$0, i);
        }
    }
}
