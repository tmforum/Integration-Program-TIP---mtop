/*
 * XML Type:  TerminationPointDataType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tpdata.v1.impl;
/**
 * An XML TerminationPointDataType(@http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1).
 *
 * This is a complex type.
 */
public class TerminationPointDataTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType
{
    
    public TerminationPointDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "tpName");
    private static final javax.xml.namespace.QName TPMAPPINGMODE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "tpMappingMode");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMETERLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "transmissionParameterList");
    private static final javax.xml.namespace.QName INGRESSTMDREF$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "ingressTmdRef");
    private static final javax.xml.namespace.QName EGRESSTMDREF$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1", "egressTmdRef");
    
    
    /**
     * Gets the "tpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tpName" element
     */
    public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType tpName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(TPNAME$0);
            }
            target.set(tpName);
        }
    }
    
    /**
     * Appends and returns a new empty "tpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(TPNAME$0);
            return target;
        }
    }
    
    /**
     * Gets the "tpMappingMode" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum getTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpMappingMode" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType xgetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "tpMappingMode" element
     */
    public boolean isNilTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpMappingMode" element
     */
    public boolean isSetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPMAPPINGMODE$2) != 0;
        }
    }
    
    /**
     * Sets the "tpMappingMode" element
     */
    public void setTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum tpMappingMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPMAPPINGMODE$2);
            }
            target.setEnumValue(tpMappingMode);
        }
    }
    
    /**
     * Sets (as xml) the "tpMappingMode" element
     */
    public void xsetTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType tpMappingMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().add_element_user(TPMAPPINGMODE$2);
            }
            target.set(tpMappingMode);
        }
    }
    
    /**
     * Nils the "tpMappingMode" element
     */
    public void setNilTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().add_element_user(TPMAPPINGMODE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpMappingMode" element
     */
    public void unsetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPMAPPINGMODE$2, 0);
        }
    }
    
    /**
     * Gets the "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    public boolean isNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParameterList" element
     */
    public boolean isSetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMETERLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParameterList" element
     */
    public void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$4);
            }
            target.set(transmissionParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$4);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParameterList" element
     */
    public void setNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    public void unsetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMETERLIST$4, 0);
        }
    }
    
    /**
     * Gets the "ingressTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INGRESSTMDREF$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ingressTmdRef" element
     */
    public boolean isNilIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INGRESSTMDREF$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ingressTmdRef" element
     */
    public boolean isSetIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INGRESSTMDREF$6) != 0;
        }
    }
    
    /**
     * Sets the "ingressTmdRef" element
     */
    public void setIngressTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType ingressTmdRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INGRESSTMDREF$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(INGRESSTMDREF$6);
            }
            target.set(ingressTmdRef);
        }
    }
    
    /**
     * Appends and returns a new empty "ingressTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(INGRESSTMDREF$6);
            return target;
        }
    }
    
    /**
     * Nils the "ingressTmdRef" element
     */
    public void setNilIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INGRESSTMDREF$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(INGRESSTMDREF$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ingressTmdRef" element
     */
    public void unsetIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INGRESSTMDREF$6, 0);
        }
    }
    
    /**
     * Gets the "egressTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EGRESSTMDREF$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "egressTmdRef" element
     */
    public boolean isNilEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EGRESSTMDREF$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "egressTmdRef" element
     */
    public boolean isSetEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EGRESSTMDREF$8) != 0;
        }
    }
    
    /**
     * Sets the "egressTmdRef" element
     */
    public void setEgressTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType egressTmdRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EGRESSTMDREF$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EGRESSTMDREF$8);
            }
            target.set(egressTmdRef);
        }
    }
    
    /**
     * Appends and returns a new empty "egressTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EGRESSTMDREF$8);
            return target;
        }
    }
    
    /**
     * Nils the "egressTmdRef" element
     */
    public void setNilEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EGRESSTMDREF$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EGRESSTMDREF$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "egressTmdRef" element
     */
    public void unsetEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EGRESSTMDREF$8, 0);
        }
    }
}
