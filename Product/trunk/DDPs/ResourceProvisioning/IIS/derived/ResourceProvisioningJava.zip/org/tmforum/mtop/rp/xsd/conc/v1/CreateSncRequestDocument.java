/*
 * An XML document type.
 * Localname: createSncRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1;


/**
 * A document containing one createSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public interface CreateSncRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateSncRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("createsncrequestc2e3doctype");
    
    /**
     * Gets the "createSncRequest" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument.CreateSncRequest getCreateSncRequest();
    
    /**
     * Sets the "createSncRequest" element
     */
    void setCreateSncRequest(org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument.CreateSncRequest createSncRequest);
    
    /**
     * Appends and returns a new empty "createSncRequest" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument.CreateSncRequest addNewCreateSncRequest();
    
    /**
     * An XML createSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public interface CreateSncRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateSncRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sC1EF555E97527FCC47E2430115F41EE6").resolveHandle("createsncrequesta162elemtype");
        
        /**
         * Gets the "createData" element
         */
        org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType getCreateData();
        
        /**
         * True if has "createData" element
         */
        boolean isSetCreateData();
        
        /**
         * Sets the "createData" element
         */
        void setCreateData(org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType createData);
        
        /**
         * Appends and returns a new empty "createData" element
         */
        org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType addNewCreateData();
        
        /**
         * Unsets the "createData" element
         */
        void unsetCreateData();
        
        /**
         * Gets the "tolerableImpact" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact();
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact();
        
        /**
         * True if has "tolerableImpact" element
         */
        boolean isSetTolerableImpact();
        
        /**
         * Sets the "tolerableImpact" element
         */
        void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact);
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact);
        
        /**
         * Unsets the "tolerableImpact" element
         */
        void unsetTolerableImpact();
        
        /**
         * Gets the "osFreedomLevel" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum getOsFreedomLevel();
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType xgetOsFreedomLevel();
        
        /**
         * True if has "osFreedomLevel" element
         */
        boolean isSetOsFreedomLevel();
        
        /**
         * Sets the "osFreedomLevel" element
         */
        void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum osFreedomLevel);
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType osFreedomLevel);
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        void unsetOsFreedomLevel();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument.CreateSncRequest newInstance() {
              return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument.CreateSncRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument.CreateSncRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument.CreateSncRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument newInstance() {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
