/*
 * An XML document type.
 * Localname: modifySubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one modifySubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class ModifySubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument
{
    
    public ModifySubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MODIFYSUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "modifySubnetworkConnectionException");
    
    
    /**
     * Gets the "modifySubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException getModifySubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException)get_store().find_element_user(MODIFYSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "modifySubnetworkConnectionException" element
     */
    public void setModifySubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException modifySubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException)get_store().find_element_user(MODIFYSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException)get_store().add_element_user(MODIFYSUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(modifySubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "modifySubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException addNewModifySubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException)get_store().add_element_user(MODIFYSUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML modifySubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ModifySubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ModifySubnetworkConnectionExceptionDocument.ModifySubnetworkConnectionException
    {
        
        public ModifySubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
