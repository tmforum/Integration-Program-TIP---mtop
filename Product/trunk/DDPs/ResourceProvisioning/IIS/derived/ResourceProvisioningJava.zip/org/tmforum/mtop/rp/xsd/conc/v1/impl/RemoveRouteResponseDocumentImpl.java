/*
 * An XML document type.
 * Localname: removeRouteResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one removeRouteResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class RemoveRouteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument
{
    
    public RemoveRouteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName REMOVEROUTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "removeRouteResponse");
    
    
    /**
     * Gets the "removeRouteResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse getRemoveRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse)get_store().find_element_user(REMOVEROUTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "removeRouteResponse" element
     */
    public void setRemoveRouteResponse(org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse removeRouteResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse)get_store().find_element_user(REMOVEROUTERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse)get_store().add_element_user(REMOVEROUTERESPONSE$0);
            }
            target.set(removeRouteResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "removeRouteResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse addNewRemoveRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse)get_store().add_element_user(REMOVEROUTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML removeRouteResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class RemoveRouteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse
    {
        
        public RemoveRouteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "vendorExtensions");
        
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions)get_store().add_element_user(VENDOREXTENSIONS$0);
                return target;
            }
        }
        /**
         * An XML vendorExtensions(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
         *
         * This is a complex type.
         */
        public static class VendorExtensionsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RemoveRouteResponseDocument.RemoveRouteResponse.VendorExtensions
        {
            
            public VendorExtensionsImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            
        }
    }
}
