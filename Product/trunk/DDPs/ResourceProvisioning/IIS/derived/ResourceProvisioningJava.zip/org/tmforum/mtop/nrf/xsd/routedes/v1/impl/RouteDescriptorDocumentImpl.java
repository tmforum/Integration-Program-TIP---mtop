/*
 * An XML document type.
 * Localname: routeDescriptor
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/routedes/v1
 * Java type: org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.routedes.v1.impl;
/**
 * A document containing one routeDescriptor(@http://www.tmforum.org/mtop/nrf/xsd/routedes/v1) element.
 *
 * This is a complex type.
 */
public class RouteDescriptorDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorDocument
{
    
    public RouteDescriptorDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ROUTEDESCRIPTOR$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "routeDescriptor");
    
    
    /**
     * Gets the "routeDescriptor" element
     */
    public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType getRouteDescriptor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().find_element_user(ROUTEDESCRIPTOR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "routeDescriptor" element
     */
    public void setRouteDescriptor(org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType routeDescriptor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().find_element_user(ROUTEDESCRIPTOR$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().add_element_user(ROUTEDESCRIPTOR$0);
            }
            target.set(routeDescriptor);
        }
    }
    
    /**
     * Appends and returns a new empty "routeDescriptor" element
     */
    public org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType addNewRouteDescriptor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType)get_store().add_element_user(ROUTEDESCRIPTOR$0);
            return target;
        }
    }
}
