/*
 * XML Type:  X721.UsageStateType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1.impl;
/**
 * An XML X721.UsageStateType(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType.
 */
public class X721UsageStateTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType
{
    
    public X721UsageStateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected X721UsageStateTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
