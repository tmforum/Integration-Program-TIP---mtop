/*
 * XML Type:  FdTypeType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fd.v1.impl;
/**
 * An XML FdTypeType(@http://www.tmforum.org/mtop/nrf/xsd/fd/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType.
 */
public class FdTypeTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrf.xsd.fd.v1.FdTypeType
{
    
    public FdTypeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected FdTypeTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
