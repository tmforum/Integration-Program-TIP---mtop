/*
 * XML Type:  EndPointReferenceType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * An XML EndPointReferenceType(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType.
 */
public class EndPointReferenceTypeImpl extends org.apache.xmlbeans.impl.values.JavaUriHolderEx implements org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType
{
    
    public EndPointReferenceTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected EndPointReferenceTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
