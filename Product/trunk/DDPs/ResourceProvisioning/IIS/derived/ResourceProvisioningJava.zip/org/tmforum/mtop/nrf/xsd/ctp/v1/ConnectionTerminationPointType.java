/*
 * XML Type:  ConnectionTerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ctp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ctp.v1;


/**
 * An XML ConnectionTerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/ctp/v1).
 *
 * This is a complex type.
 */
public interface ConnectionTerminationPointType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ConnectionTerminationPointType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s191F600D204DEAE7EEDC98360AFBE7C2").resolveHandle("connectionterminationpointtype32betype");
    
    /**
     * Gets the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum getDirection();
    
    /**
     * Gets (as xml) the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType xgetDirection();
    
    /**
     * Tests for nil "direction" element
     */
    boolean isNilDirection();
    
    /**
     * True if has "direction" element
     */
    boolean isSetDirection();
    
    /**
     * Sets the "direction" element
     */
    void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum direction);
    
    /**
     * Sets (as xml) the "direction" element
     */
    void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType direction);
    
    /**
     * Nils the "direction" element
     */
    void setNilDirection();
    
    /**
     * Unsets the "direction" element
     */
    void unsetDirection();
    
    /**
     * Gets the "tpProtectionAssociation" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType.Enum getTpProtectionAssociation();
    
    /**
     * Gets (as xml) the "tpProtectionAssociation" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType xgetTpProtectionAssociation();
    
    /**
     * Tests for nil "tpProtectionAssociation" element
     */
    boolean isNilTpProtectionAssociation();
    
    /**
     * True if has "tpProtectionAssociation" element
     */
    boolean isSetTpProtectionAssociation();
    
    /**
     * Sets the "tpProtectionAssociation" element
     */
    void setTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType.Enum tpProtectionAssociation);
    
    /**
     * Sets (as xml) the "tpProtectionAssociation" element
     */
    void xsetTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType tpProtectionAssociation);
    
    /**
     * Nils the "tpProtectionAssociation" element
     */
    void setNilTpProtectionAssociation();
    
    /**
     * Unsets the "tpProtectionAssociation" element
     */
    void unsetTpProtectionAssociation();
    
    /**
     * Gets the "isEdgePoint" element
     */
    boolean getIsEdgePoint();
    
    /**
     * Gets (as xml) the "isEdgePoint" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsEdgePoint();
    
    /**
     * Tests for nil "isEdgePoint" element
     */
    boolean isNilIsEdgePoint();
    
    /**
     * True if has "isEdgePoint" element
     */
    boolean isSetIsEdgePoint();
    
    /**
     * Sets the "isEdgePoint" element
     */
    void setIsEdgePoint(boolean isEdgePoint);
    
    /**
     * Sets (as xml) the "isEdgePoint" element
     */
    void xsetIsEdgePoint(org.apache.xmlbeans.XmlBoolean isEdgePoint);
    
    /**
     * Nils the "isEdgePoint" element
     */
    void setNilIsEdgePoint();
    
    /**
     * Unsets the "isEdgePoint" element
     */
    void unsetIsEdgePoint();
    
    /**
     * Gets the "isEquipmentProtected" element
     */
    boolean getIsEquipmentProtected();
    
    /**
     * Gets (as xml) the "isEquipmentProtected" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsEquipmentProtected();
    
    /**
     * Tests for nil "isEquipmentProtected" element
     */
    boolean isNilIsEquipmentProtected();
    
    /**
     * True if has "isEquipmentProtected" element
     */
    boolean isSetIsEquipmentProtected();
    
    /**
     * Sets the "isEquipmentProtected" element
     */
    void setIsEquipmentProtected(boolean isEquipmentProtected);
    
    /**
     * Sets (as xml) the "isEquipmentProtected" element
     */
    void xsetIsEquipmentProtected(org.apache.xmlbeans.XmlBoolean isEquipmentProtected);
    
    /**
     * Nils the "isEquipmentProtected" element
     */
    void setNilIsEquipmentProtected();
    
    /**
     * Unsets the "isEquipmentProtected" element
     */
    void unsetIsEquipmentProtected();
    
    /**
     * Gets the "egressTmdState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum getEgressTmdState();
    
    /**
     * Gets (as xml) the "egressTmdState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType xgetEgressTmdState();
    
    /**
     * Tests for nil "egressTmdState" element
     */
    boolean isNilEgressTmdState();
    
    /**
     * True if has "egressTmdState" element
     */
    boolean isSetEgressTmdState();
    
    /**
     * Sets the "egressTmdState" element
     */
    void setEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum egressTmdState);
    
    /**
     * Sets (as xml) the "egressTmdState" element
     */
    void xsetEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType egressTmdState);
    
    /**
     * Nils the "egressTmdState" element
     */
    void setNilEgressTmdState();
    
    /**
     * Unsets the "egressTmdState" element
     */
    void unsetEgressTmdState();
    
    /**
     * Gets the "ingressTmdState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum getIngressTmdState();
    
    /**
     * Gets (as xml) the "ingressTmdState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType xgetIngressTmdState();
    
    /**
     * Tests for nil "ingressTmdState" element
     */
    boolean isNilIngressTmdState();
    
    /**
     * True if has "ingressTmdState" element
     */
    boolean isSetIngressTmdState();
    
    /**
     * Sets the "ingressTmdState" element
     */
    void setIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum ingressTmdState);
    
    /**
     * Sets (as xml) the "ingressTmdState" element
     */
    void xsetIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType ingressTmdState);
    
    /**
     * Nils the "ingressTmdState" element
     */
    void setNilIngressTmdState();
    
    /**
     * Unsets the "ingressTmdState" element
     */
    void unsetIngressTmdState();
    
    /**
     * Gets the "connectionState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum getConnectionState();
    
    /**
     * Gets (as xml) the "connectionState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType xgetConnectionState();
    
    /**
     * Tests for nil "connectionState" element
     */
    boolean isNilConnectionState();
    
    /**
     * True if has "connectionState" element
     */
    boolean isSetConnectionState();
    
    /**
     * Sets the "connectionState" element
     */
    void setConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum connectionState);
    
    /**
     * Sets (as xml) the "connectionState" element
     */
    void xsetConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType connectionState);
    
    /**
     * Nils the "connectionState" element
     */
    void setNilConnectionState();
    
    /**
     * Unsets the "connectionState" element
     */
    void unsetConnectionState();
    
    /**
     * Gets the "tpMappingMode" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum getTpMappingMode();
    
    /**
     * Gets (as xml) the "tpMappingMode" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType xgetTpMappingMode();
    
    /**
     * Tests for nil "tpMappingMode" element
     */
    boolean isNilTpMappingMode();
    
    /**
     * True if has "tpMappingMode" element
     */
    boolean isSetTpMappingMode();
    
    /**
     * Sets the "tpMappingMode" element
     */
    void setTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum tpMappingMode);
    
    /**
     * Sets (as xml) the "tpMappingMode" element
     */
    void xsetTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType tpMappingMode);
    
    /**
     * Nils the "tpMappingMode" element
     */
    void setNilTpMappingMode();
    
    /**
     * Unsets the "tpMappingMode" element
     */
    void unsetTpMappingMode();
    
    /**
     * Gets the "ingressTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getIngressTmdRef();
    
    /**
     * Tests for nil "ingressTmdRef" element
     */
    boolean isNilIngressTmdRef();
    
    /**
     * True if has "ingressTmdRef" element
     */
    boolean isSetIngressTmdRef();
    
    /**
     * Sets the "ingressTmdRef" element
     */
    void setIngressTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType ingressTmdRef);
    
    /**
     * Appends and returns a new empty "ingressTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewIngressTmdRef();
    
    /**
     * Nils the "ingressTmdRef" element
     */
    void setNilIngressTmdRef();
    
    /**
     * Unsets the "ingressTmdRef" element
     */
    void unsetIngressTmdRef();
    
    /**
     * Gets the "egressTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEgressTmdRef();
    
    /**
     * Tests for nil "egressTmdRef" element
     */
    boolean isNilEgressTmdRef();
    
    /**
     * True if has "egressTmdRef" element
     */
    boolean isSetEgressTmdRef();
    
    /**
     * Sets the "egressTmdRef" element
     */
    void setEgressTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType egressTmdRef);
    
    /**
     * Appends and returns a new empty "egressTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEgressTmdRef();
    
    /**
     * Nils the "egressTmdRef" element
     */
    void setNilEgressTmdRef();
    
    /**
     * Unsets the "egressTmdRef" element
     */
    void unsetEgressTmdRef();
    
    /**
     * Gets the "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList();
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    boolean isNilTransmissionParameterList();
    
    /**
     * True if has "transmissionParameterList" element
     */
    boolean isSetTransmissionParameterList();
    
    /**
     * Sets the "transmissionParameterList" element
     */
    void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList);
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList();
    
    /**
     * Nils the "transmissionParameterList" element
     */
    void setNilTransmissionParameterList();
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    void unsetTransmissionParameterList();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
