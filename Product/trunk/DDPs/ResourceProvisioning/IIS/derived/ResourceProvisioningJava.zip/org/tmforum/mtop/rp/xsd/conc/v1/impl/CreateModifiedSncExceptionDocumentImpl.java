/*
 * An XML document type.
 * Localname: createModifiedSncException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createModifiedSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateModifiedSncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument
{
    
    public CreateModifiedSncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEMODIFIEDSNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createModifiedSncException");
    
    
    /**
     * Gets the "createModifiedSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException getCreateModifiedSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException)get_store().find_element_user(CREATEMODIFIEDSNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createModifiedSncException" element
     */
    public void setCreateModifiedSncException(org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException createModifiedSncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException)get_store().find_element_user(CREATEMODIFIEDSNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException)get_store().add_element_user(CREATEMODIFIEDSNCEXCEPTION$0);
            }
            target.set(createModifiedSncException);
        }
    }
    
    /**
     * Appends and returns a new empty "createModifiedSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException addNewCreateModifiedSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException)get_store().add_element_user(CREATEMODIFIEDSNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML createModifiedSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateModifiedSncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSncExceptionDocument.CreateModifiedSncException
    {
        
        public CreateModifiedSncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
