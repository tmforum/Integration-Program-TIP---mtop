/*
 * An XML document type.
 * Localname: activateSncException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one activateSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class ActivateSncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument
{
    
    public ActivateSncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACTIVATESNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "activateSncException");
    
    
    /**
     * Gets the "activateSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException getActivateSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException)get_store().find_element_user(ACTIVATESNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "activateSncException" element
     */
    public void setActivateSncException(org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException activateSncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException)get_store().find_element_user(ACTIVATESNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException)get_store().add_element_user(ACTIVATESNCEXCEPTION$0);
            }
            target.set(activateSncException);
        }
    }
    
    /**
     * Appends and returns a new empty "activateSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException addNewActivateSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException)get_store().add_element_user(ACTIVATESNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML activateSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ActivateSncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ActivateSncExceptionDocument.ActivateSncException
    {
        
        public ActivateSncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
