/*
 * XML Type:  CrossConnectType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/cc/v1
 * Java type: org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.cc.v1;


/**
 * An XML CrossConnectType(@http://www.tmforum.org/mtop/nrf/xsd/cc/v1).
 *
 * This is a complex type.
 */
public interface CrossConnectType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CrossConnectType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s732E47122B99A5ED8D93FEE82721A56B").resolveHandle("crossconnecttype8637type");
    
    /**
     * Gets the "isActive" element
     */
    boolean getIsActive();
    
    /**
     * Gets (as xml) the "isActive" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsActive();
    
    /**
     * Tests for nil "isActive" element
     */
    boolean isNilIsActive();
    
    /**
     * True if has "isActive" element
     */
    boolean isSetIsActive();
    
    /**
     * Sets the "isActive" element
     */
    void setIsActive(boolean isActive);
    
    /**
     * Sets (as xml) the "isActive" element
     */
    void xsetIsActive(org.apache.xmlbeans.XmlBoolean isActive);
    
    /**
     * Nils the "isActive" element
     */
    void setNilIsActive();
    
    /**
     * Unsets the "isActive" element
     */
    void unsetIsActive();
    
    /**
     * Gets the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection();
    
    /**
     * Gets (as xml) the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection();
    
    /**
     * Tests for nil "direction" element
     */
    boolean isNilDirection();
    
    /**
     * True if has "direction" element
     */
    boolean isSetDirection();
    
    /**
     * Sets the "direction" element
     */
    void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction);
    
    /**
     * Sets (as xml) the "direction" element
     */
    void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction);
    
    /**
     * Nils the "direction" element
     */
    void setNilDirection();
    
    /**
     * Unsets the "direction" element
     */
    void unsetDirection();
    
    /**
     * Gets the "ccType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType.Enum getCcType();
    
    /**
     * Gets (as xml) the "ccType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType xgetCcType();
    
    /**
     * Tests for nil "ccType" element
     */
    boolean isNilCcType();
    
    /**
     * True if has "ccType" element
     */
    boolean isSetCcType();
    
    /**
     * Sets the "ccType" element
     */
    void setCcType(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType.Enum ccType);
    
    /**
     * Sets (as xml) the "ccType" element
     */
    void xsetCcType(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType ccType);
    
    /**
     * Nils the "ccType" element
     */
    void setNilCcType();
    
    /**
     * Unsets the "ccType" element
     */
    void unsetCcType();
    
    /**
     * Gets the "isFixed" element
     */
    boolean getIsFixed();
    
    /**
     * Gets (as xml) the "isFixed" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsFixed();
    
    /**
     * Tests for nil "isFixed" element
     */
    boolean isNilIsFixed();
    
    /**
     * True if has "isFixed" element
     */
    boolean isSetIsFixed();
    
    /**
     * Sets the "isFixed" element
     */
    void setIsFixed(boolean isFixed);
    
    /**
     * Sets (as xml) the "isFixed" element
     */
    void xsetIsFixed(org.apache.xmlbeans.XmlBoolean isFixed);
    
    /**
     * Nils the "isFixed" element
     */
    void setNilIsFixed();
    
    /**
     * Unsets the "isFixed" element
     */
    void unsetIsFixed();
    
    /**
     * Gets the "aEndNameList" element
     */
    org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList getAEndNameList();
    
    /**
     * Tests for nil "aEndNameList" element
     */
    boolean isNilAEndNameList();
    
    /**
     * True if has "aEndNameList" element
     */
    boolean isSetAEndNameList();
    
    /**
     * Sets the "aEndNameList" element
     */
    void setAEndNameList(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList aEndNameList);
    
    /**
     * Appends and returns a new empty "aEndNameList" element
     */
    org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList addNewAEndNameList();
    
    /**
     * Nils the "aEndNameList" element
     */
    void setNilAEndNameList();
    
    /**
     * Unsets the "aEndNameList" element
     */
    void unsetAEndNameList();
    
    /**
     * Gets the "zEndNameList" element
     */
    org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList getZEndNameList();
    
    /**
     * Tests for nil "zEndNameList" element
     */
    boolean isNilZEndNameList();
    
    /**
     * True if has "zEndNameList" element
     */
    boolean isSetZEndNameList();
    
    /**
     * Sets the "zEndNameList" element
     */
    void setZEndNameList(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList zEndNameList);
    
    /**
     * Appends and returns a new empty "zEndNameList" element
     */
    org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList addNewZEndNameList();
    
    /**
     * Nils the "zEndNameList" element
     */
    void setNilZEndNameList();
    
    /**
     * Unsets the "zEndNameList" element
     */
    void unsetZEndNameList();
    
    /**
     * Gets the "connectionId" element
     */
    java.lang.String getConnectionId();
    
    /**
     * Gets (as xml) the "connectionId" element
     */
    org.apache.xmlbeans.XmlString xgetConnectionId();
    
    /**
     * Tests for nil "connectionId" element
     */
    boolean isNilConnectionId();
    
    /**
     * True if has "connectionId" element
     */
    boolean isSetConnectionId();
    
    /**
     * Sets the "connectionId" element
     */
    void setConnectionId(java.lang.String connectionId);
    
    /**
     * Sets (as xml) the "connectionId" element
     */
    void xsetConnectionId(org.apache.xmlbeans.XmlString connectionId);
    
    /**
     * Nils the "connectionId" element
     */
    void setNilConnectionId();
    
    /**
     * Unsets the "connectionId" element
     */
    void unsetConnectionId();
    
    /**
     * Gets the "routeActualState" element
     */
    java.lang.String getRouteActualState();
    
    /**
     * Gets (as xml) the "routeActualState" element
     */
    org.apache.xmlbeans.XmlString xgetRouteActualState();
    
    /**
     * Tests for nil "routeActualState" element
     */
    boolean isNilRouteActualState();
    
    /**
     * True if has "routeActualState" element
     */
    boolean isSetRouteActualState();
    
    /**
     * Sets the "routeActualState" element
     */
    void setRouteActualState(java.lang.String routeActualState);
    
    /**
     * Sets (as xml) the "routeActualState" element
     */
    void xsetRouteActualState(org.apache.xmlbeans.XmlString routeActualState);
    
    /**
     * Nils the "routeActualState" element
     */
    void setNilRouteActualState();
    
    /**
     * Unsets the "routeActualState" element
     */
    void unsetRouteActualState();
    
    /**
     * Gets the "routeAdminState" element
     */
    java.lang.String getRouteAdminState();
    
    /**
     * Gets (as xml) the "routeAdminState" element
     */
    org.apache.xmlbeans.XmlString xgetRouteAdminState();
    
    /**
     * Tests for nil "routeAdminState" element
     */
    boolean isNilRouteAdminState();
    
    /**
     * True if has "routeAdminState" element
     */
    boolean isSetRouteAdminState();
    
    /**
     * Sets the "routeAdminState" element
     */
    void setRouteAdminState(java.lang.String routeAdminState);
    
    /**
     * Sets (as xml) the "routeAdminState" element
     */
    void xsetRouteAdminState(org.apache.xmlbeans.XmlString routeAdminState);
    
    /**
     * Nils the "routeAdminState" element
     */
    void setNilRouteAdminState();
    
    /**
     * Unsets the "routeAdminState" element
     */
    void unsetRouteAdminState();
    
    /**
     * Gets the "isRouteExclusive" element
     */
    boolean getIsRouteExclusive();
    
    /**
     * Gets (as xml) the "isRouteExclusive" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsRouteExclusive();
    
    /**
     * Tests for nil "isRouteExclusive" element
     */
    boolean isNilIsRouteExclusive();
    
    /**
     * True if has "isRouteExclusive" element
     */
    boolean isSetIsRouteExclusive();
    
    /**
     * Sets the "isRouteExclusive" element
     */
    void setIsRouteExclusive(boolean isRouteExclusive);
    
    /**
     * Sets (as xml) the "isRouteExclusive" element
     */
    void xsetIsRouteExclusive(org.apache.xmlbeans.XmlBoolean isRouteExclusive);
    
    /**
     * Nils the "isRouteExclusive" element
     */
    void setNilIsRouteExclusive();
    
    /**
     * Unsets the "isRouteExclusive" element
     */
    void unsetIsRouteExclusive();
    
    /**
     * Gets the "routeId" element
     */
    java.lang.String getRouteId();
    
    /**
     * Gets (as xml) the "routeId" element
     */
    org.apache.xmlbeans.XmlString xgetRouteId();
    
    /**
     * Tests for nil "routeId" element
     */
    boolean isNilRouteId();
    
    /**
     * True if has "routeId" element
     */
    boolean isSetRouteId();
    
    /**
     * Sets the "routeId" element
     */
    void setRouteId(java.lang.String routeId);
    
    /**
     * Sets (as xml) the "routeId" element
     */
    void xsetRouteId(org.apache.xmlbeans.XmlString routeId);
    
    /**
     * Nils the "routeId" element
     */
    void setNilRouteId();
    
    /**
     * Unsets the "routeId" element
     */
    void unsetRouteId();
    
    /**
     * Gets the "isRouteIntended" element
     */
    boolean getIsRouteIntended();
    
    /**
     * Gets (as xml) the "isRouteIntended" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsRouteIntended();
    
    /**
     * Tests for nil "isRouteIntended" element
     */
    boolean isNilIsRouteIntended();
    
    /**
     * True if has "isRouteIntended" element
     */
    boolean isSetIsRouteIntended();
    
    /**
     * Sets the "isRouteIntended" element
     */
    void setIsRouteIntended(boolean isRouteIntended);
    
    /**
     * Sets (as xml) the "isRouteIntended" element
     */
    void xsetIsRouteIntended(org.apache.xmlbeans.XmlBoolean isRouteIntended);
    
    /**
     * Nils the "isRouteIntended" element
     */
    void setNilIsRouteIntended();
    
    /**
     * Unsets the "isRouteIntended" element
     */
    void unsetIsRouteIntended();
    
    /**
     * Gets the "isRouteInUseBy" element
     */
    boolean getIsRouteInUseBy();
    
    /**
     * Gets (as xml) the "isRouteInUseBy" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsRouteInUseBy();
    
    /**
     * Tests for nil "isRouteInUseBy" element
     */
    boolean isNilIsRouteInUseBy();
    
    /**
     * True if has "isRouteInUseBy" element
     */
    boolean isSetIsRouteInUseBy();
    
    /**
     * Sets the "isRouteInUseBy" element
     */
    void setIsRouteInUseBy(boolean isRouteInUseBy);
    
    /**
     * Sets (as xml) the "isRouteInUseBy" element
     */
    void xsetIsRouteInUseBy(org.apache.xmlbeans.XmlBoolean isRouteInUseBy);
    
    /**
     * Nils the "isRouteInUseBy" element
     */
    void setNilIsRouteInUseBy();
    
    /**
     * Unsets the "isRouteInUseBy" element
     */
    void unsetIsRouteInUseBy();
    
    /**
     * Gets the "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
    
    /**
     * True if has "vendorExtensions" element
     */
    boolean isSetVendorExtensions();
    
    /**
     * Sets the "vendorExtensions" element
     */
    void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
    
    /**
     * Unsets the "vendorExtensions" element
     */
    void unsetVendorExtensions();
    
    /**
     * An XML aEndNameList(@http://www.tmforum.org/mtop/nrf/xsd/cc/v1).
     *
     * This is a complex type.
     */
    public interface AEndNameList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AEndNameList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s732E47122B99A5ED8D93FEE82721A56B").resolveHandle("aendnamelist2558elemtype");
        
        /**
         * Gets a List of "aEndName" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getAEndNameList();
        
        /**
         * Gets array of all "aEndName" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getAEndNameArray();
        
        /**
         * Gets ith "aEndName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getAEndNameArray(int i);
        
        /**
         * Returns number of "aEndName" element
         */
        int sizeOfAEndNameArray();
        
        /**
         * Sets array of all "aEndName" element
         */
        void setAEndNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] aEndNameArray);
        
        /**
         * Sets ith "aEndName" element
         */
        void setAEndNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType aEndName);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "aEndName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewAEndName(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "aEndName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewAEndName();
        
        /**
         * Removes the ith "aEndName" element
         */
        void removeAEndName(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML zEndNameList(@http://www.tmforum.org/mtop/nrf/xsd/cc/v1).
     *
     * This is a complex type.
     */
    public interface ZEndNameList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ZEndNameList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s732E47122B99A5ED8D93FEE82721A56B").resolveHandle("zendnamelistb471elemtype");
        
        /**
         * Gets a List of "zEndName" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getZEndNameList();
        
        /**
         * Gets array of all "zEndName" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getZEndNameArray();
        
        /**
         * Gets ith "zEndName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getZEndNameArray(int i);
        
        /**
         * Returns number of "zEndName" element
         */
        int sizeOfZEndNameArray();
        
        /**
         * Sets array of all "zEndName" element
         */
        void setZEndNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] zEndNameArray);
        
        /**
         * Sets ith "zEndName" element
         */
        void setZEndNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType zEndName);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "zEndName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewZEndName(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "zEndName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewZEndName();
        
        /**
         * Removes the ith "zEndName" element
         */
        void removeZEndName(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
