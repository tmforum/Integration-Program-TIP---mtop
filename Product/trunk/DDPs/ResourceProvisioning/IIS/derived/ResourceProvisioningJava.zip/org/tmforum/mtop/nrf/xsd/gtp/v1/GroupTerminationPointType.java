/*
 * XML Type:  GroupTerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/gtp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.gtp.v1;


/**
 * An XML GroupTerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/gtp/v1).
 *
 * This is a complex type.
 */
public interface GroupTerminationPointType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GroupTerminationPointType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sFA029CF23A6AA97F9ACEA74311DBFDC2").resolveHandle("groupterminationpointtype83ebtype");
    
    /**
     * Gets the "isReportingAlarm" element
     */
    boolean getIsReportingAlarm();
    
    /**
     * Gets (as xml) the "isReportingAlarm" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsReportingAlarm();
    
    /**
     * Tests for nil "isReportingAlarm" element
     */
    boolean isNilIsReportingAlarm();
    
    /**
     * True if has "isReportingAlarm" element
     */
    boolean isSetIsReportingAlarm();
    
    /**
     * Sets the "isReportingAlarm" element
     */
    void setIsReportingAlarm(boolean isReportingAlarm);
    
    /**
     * Sets (as xml) the "isReportingAlarm" element
     */
    void xsetIsReportingAlarm(org.apache.xmlbeans.XmlBoolean isReportingAlarm);
    
    /**
     * Nils the "isReportingAlarm" element
     */
    void setNilIsReportingAlarm();
    
    /**
     * Unsets the "isReportingAlarm" element
     */
    void unsetIsReportingAlarm();
    
    /**
     * Gets the "containedTpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getContainedTpRefList();
    
    /**
     * Tests for nil "containedTpRefList" element
     */
    boolean isNilContainedTpRefList();
    
    /**
     * True if has "containedTpRefList" element
     */
    boolean isSetContainedTpRefList();
    
    /**
     * Sets the "containedTpRefList" element
     */
    void setContainedTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType containedTpRefList);
    
    /**
     * Appends and returns a new empty "containedTpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewContainedTpRefList();
    
    /**
     * Nils the "containedTpRefList" element
     */
    void setNilContainedTpRefList();
    
    /**
     * Unsets the "containedTpRefList" element
     */
    void unsetContainedTpRefList();
    
    /**
     * Gets the "connectionState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum getConnectionState();
    
    /**
     * Gets (as xml) the "connectionState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType xgetConnectionState();
    
    /**
     * Tests for nil "connectionState" element
     */
    boolean isNilConnectionState();
    
    /**
     * True if has "connectionState" element
     */
    boolean isSetConnectionState();
    
    /**
     * Sets the "connectionState" element
     */
    void setConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum connectionState);
    
    /**
     * Sets (as xml) the "connectionState" element
     */
    void xsetConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType connectionState);
    
    /**
     * Nils the "connectionState" element
     */
    void setNilConnectionState();
    
    /**
     * Unsets the "connectionState" element
     */
    void unsetConnectionState();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
