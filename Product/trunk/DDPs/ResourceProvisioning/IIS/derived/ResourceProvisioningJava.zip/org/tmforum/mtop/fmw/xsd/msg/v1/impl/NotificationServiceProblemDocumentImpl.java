/*
 * An XML document type.
 * Localname: notificationServiceProblem
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.NotificationServiceProblemDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * A document containing one notificationServiceProblem(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1) element.
 *
 * This is a complex type.
 */
public class NotificationServiceProblemDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.NotificationServiceProblemDocument
{
    
    public NotificationServiceProblemDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NOTIFICATIONSERVICEPROBLEM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "notificationServiceProblem");
    
    
    /**
     * Gets the "notificationServiceProblem" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getNotificationServiceProblem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTIFICATIONSERVICEPROBLEM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "notificationServiceProblem" element
     */
    public void setNotificationServiceProblem(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType notificationServiceProblem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(NOTIFICATIONSERVICEPROBLEM$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTIFICATIONSERVICEPROBLEM$0);
            }
            target.set(notificationServiceProblem);
        }
    }
    
    /**
     * Appends and returns a new empty "notificationServiceProblem" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewNotificationServiceProblem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(NOTIFICATIONSERVICEPROBLEM$0);
            return target;
        }
    }
}
