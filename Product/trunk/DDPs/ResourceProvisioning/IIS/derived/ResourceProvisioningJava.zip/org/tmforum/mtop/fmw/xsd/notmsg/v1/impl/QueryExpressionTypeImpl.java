/*
 * XML Type:  QueryExpressionType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * An XML QueryExpressionType(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
 *
 * This is a complex type.
 */
public class QueryExpressionTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType
{
    
    public QueryExpressionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIALECT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "dialect");
    private static final javax.xml.namespace.QName QUERY$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "query");
    
    
    /**
     * Gets the "dialect" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType.Enum getDialect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIALECT$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "dialect" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType xgetDialect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType)get_store().find_element_user(DIALECT$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "dialect" element
     */
    public void setDialect(org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType.Enum dialect)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIALECT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIALECT$0);
            }
            target.setEnumValue(dialect);
        }
    }
    
    /**
     * Sets (as xml) the "dialect" element
     */
    public void xsetDialect(org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType dialect)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType)get_store().find_element_user(DIALECT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType)get_store().add_element_user(DIALECT$0);
            }
            target.set(dialect);
        }
    }
    
    /**
     * Gets the "query" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query getQuery()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query)get_store().find_element_user(QUERY$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "query" element
     */
    public boolean isSetQuery()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUERY$2) != 0;
        }
    }
    
    /**
     * Sets the "query" element
     */
    public void setQuery(org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query query)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query)get_store().find_element_user(QUERY$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query)get_store().add_element_user(QUERY$2);
            }
            target.set(query);
        }
    }
    
    /**
     * Appends and returns a new empty "query" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query addNewQuery()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query)get_store().add_element_user(QUERY$2);
            return target;
        }
    }
    
    /**
     * Unsets the "query" element
     */
    public void unsetQuery()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUERY$2, 0);
        }
    }
    /**
     * An XML query(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public static class QueryImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType.Query
    {
        
        public QueryImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
