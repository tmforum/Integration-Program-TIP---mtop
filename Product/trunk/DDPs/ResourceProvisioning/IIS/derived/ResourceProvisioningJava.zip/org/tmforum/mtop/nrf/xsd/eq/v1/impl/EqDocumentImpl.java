/*
 * An XML document type.
 * Localname: eq
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/eq/v1
 * Java type: org.tmforum.mtop.nrf.xsd.eq.v1.EqDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.eq.v1.impl;
/**
 * A document containing one eq(@http://www.tmforum.org/mtop/nrf/xsd/eq/v1) element.
 *
 * This is a complex type.
 */
public class EqDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.eq.v1.EqDocument
{
    
    public EqDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EQ$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "eq");
    
    
    /**
     * Gets the "eq" element
     */
    public org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType getEq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().find_element_user(EQ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "eq" element
     */
    public void setEq(org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType eq)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().find_element_user(EQ$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().add_element_user(EQ$0);
            }
            target.set(eq);
        }
    }
    
    /**
     * Appends and returns a new empty "eq" element
     */
    public org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType addNewEq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().add_element_user(EQ$0);
            return target;
        }
    }
}
