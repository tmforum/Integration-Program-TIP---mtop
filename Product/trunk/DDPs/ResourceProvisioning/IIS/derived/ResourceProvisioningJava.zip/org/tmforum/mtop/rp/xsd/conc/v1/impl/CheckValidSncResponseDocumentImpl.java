/*
 * An XML document type.
 * Localname: checkValidSncResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one checkValidSncResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CheckValidSncResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument
{
    
    public CheckValidSncResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHECKVALIDSNCRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "checkValidSncResponse");
    
    
    /**
     * Gets the "checkValidSncResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse getCheckValidSncResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse)get_store().find_element_user(CHECKVALIDSNCRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "checkValidSncResponse" element
     */
    public void setCheckValidSncResponse(org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse checkValidSncResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse)get_store().find_element_user(CHECKVALIDSNCRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse)get_store().add_element_user(CHECKVALIDSNCRESPONSE$0);
            }
            target.set(checkValidSncResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "checkValidSncResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse addNewCheckValidSncResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse)get_store().add_element_user(CHECKVALIDSNCRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML checkValidSncResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CheckValidSncResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncResponseDocument.CheckValidSncResponse
    {
        
        public CheckValidSncResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VALID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "valid");
        
        
        /**
         * Gets the "valid" element
         */
        public boolean getValid()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALID$0, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "valid" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetValid()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(VALID$0, 0);
                return target;
            }
        }
        
        /**
         * True if has "valid" element
         */
        public boolean isSetValid()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VALID$0) != 0;
            }
        }
        
        /**
         * Sets the "valid" element
         */
        public void setValid(boolean valid)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALID$0);
                }
                target.setBooleanValue(valid);
            }
        }
        
        /**
         * Sets (as xml) the "valid" element
         */
        public void xsetValid(org.apache.xmlbeans.XmlBoolean valid)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(VALID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(VALID$0);
                }
                target.set(valid);
            }
        }
        
        /**
         * Unsets the "valid" element
         */
        public void unsetValid()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VALID$0, 0);
            }
        }
    }
}
