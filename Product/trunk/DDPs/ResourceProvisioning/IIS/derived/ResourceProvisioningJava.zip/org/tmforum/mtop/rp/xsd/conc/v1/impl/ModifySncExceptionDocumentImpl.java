/*
 * An XML document type.
 * Localname: modifySncException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one modifySncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class ModifySncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument
{
    
    public ModifySncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MODIFYSNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "modifySncException");
    
    
    /**
     * Gets the "modifySncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException getModifySncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException)get_store().find_element_user(MODIFYSNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "modifySncException" element
     */
    public void setModifySncException(org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException modifySncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException)get_store().find_element_user(MODIFYSNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException)get_store().add_element_user(MODIFYSNCEXCEPTION$0);
            }
            target.set(modifySncException);
        }
    }
    
    /**
     * Appends and returns a new empty "modifySncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException addNewModifySncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException)get_store().add_element_user(MODIFYSNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML modifySncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ModifySncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ModifySncExceptionDocument.ModifySncException
    {
        
        public ModifySncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
