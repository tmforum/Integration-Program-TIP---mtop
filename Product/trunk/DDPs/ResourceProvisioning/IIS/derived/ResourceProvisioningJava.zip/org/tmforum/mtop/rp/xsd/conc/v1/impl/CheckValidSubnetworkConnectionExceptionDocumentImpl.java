/*
 * An XML document type.
 * Localname: checkValidSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one checkValidSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CheckValidSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument
{
    
    public CheckValidSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHECKVALIDSUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "checkValidSubnetworkConnectionException");
    
    
    /**
     * Gets the "checkValidSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException getCheckValidSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException)get_store().find_element_user(CHECKVALIDSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "checkValidSubnetworkConnectionException" element
     */
    public void setCheckValidSubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException checkValidSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException)get_store().find_element_user(CHECKVALIDSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException)get_store().add_element_user(CHECKVALIDSUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(checkValidSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "checkValidSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException addNewCheckValidSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException)get_store().add_element_user(CHECKVALIDSUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML checkValidSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CheckValidSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSubnetworkConnectionExceptionDocument.CheckValidSubnetworkConnectionException
    {
        
        public CheckValidSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
