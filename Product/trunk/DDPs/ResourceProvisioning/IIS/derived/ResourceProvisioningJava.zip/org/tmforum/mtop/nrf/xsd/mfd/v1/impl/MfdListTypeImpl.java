/*
 * XML Type:  MfdListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mfd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mfd.v1.impl;
/**
 * An XML MfdListType(@http://www.tmforum.org/mtop/nrf/xsd/mfd/v1).
 *
 * This is a complex type.
 */
public class MfdListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType
{
    
    public MfdListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MFD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfd/v1", "mfd");
    
    
    /**
     * Gets a List of "mfd" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType> getMfdList()
    {
        final class MfdList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType>
        {
            public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType get(int i)
                { return MfdListTypeImpl.this.getMfdArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType set(int i, org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType o)
            {
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType old = MfdListTypeImpl.this.getMfdArray(i);
                MfdListTypeImpl.this.setMfdArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType o)
                { MfdListTypeImpl.this.insertNewMfd(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType old = MfdListTypeImpl.this.getMfdArray(i);
                MfdListTypeImpl.this.removeMfd(i);
                return old;
            }
            
            public int size()
                { return MfdListTypeImpl.this.sizeOfMfdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new MfdList();
        }
    }
    
    /**
     * Gets array of all "mfd" elements
     */
    public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType[] getMfdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(MFD$0, targetList);
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType[] result = new org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "mfd" element
     */
    public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType getMfdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "mfd" element
     */
    public int sizeOfMfdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFD$0);
        }
    }
    
    /**
     * Sets array of all "mfd" element
     */
    public void setMfdArray(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType[] mfdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(mfdArray, MFD$0);
        }
    }
    
    /**
     * Sets ith "mfd" element
     */
    public void setMfdArray(int i, org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType mfd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(mfd);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "mfd" element
     */
    public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType insertNewMfd(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().insert_element_user(MFD$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "mfd" element
     */
    public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType addNewMfd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "mfd" element
     */
    public void removeMfd(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFD$0, i);
        }
    }
}
