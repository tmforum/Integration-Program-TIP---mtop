/*
 * XML Type:  ProtectionSchemeStateEnumType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/com/v1
 * Java type: org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.com.v1.impl;
/**
 * An XML ProtectionSchemeStateEnumType(@http://www.tmforum.org/mtop/nrb/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateEnumType.
 */
public class ProtectionSchemeStateEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateEnumType
{
    
    public ProtectionSchemeStateEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ProtectionSchemeStateEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
