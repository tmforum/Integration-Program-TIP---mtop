/*
 * An XML document type.
 * Localname: activateSubnetworkConnectionResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one activateSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class ActivateSubnetworkConnectionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument
{
    
    public ActivateSubnetworkConnectionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACTIVATESUBNETWORKCONNECTIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "activateSubnetworkConnectionResponse");
    
    
    /**
     * Gets the "activateSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse getActivateSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse)get_store().find_element_user(ACTIVATESUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "activateSubnetworkConnectionResponse" element
     */
    public void setActivateSubnetworkConnectionResponse(org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse activateSubnetworkConnectionResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse)get_store().find_element_user(ACTIVATESUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse)get_store().add_element_user(ACTIVATESUBNETWORKCONNECTIONRESPONSE$0);
            }
            target.set(activateSubnetworkConnectionResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "activateSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse addNewActivateSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse)get_store().add_element_user(ACTIVATESUBNETWORKCONNECTIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML activateSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ActivateSubnetworkConnectionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionResponseDocument.ActivateSubnetworkConnectionResponse
    {
        
        public ActivateSubnetworkConnectionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPLISTTOMODIFY$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpListToModify");
        private static final javax.xml.namespace.QName THESNC$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "theSnc");
        private static final javax.xml.namespace.QName ERRORREASON$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "errorReason");
        
        
        /**
         * Gets the "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpListToModify" element
         */
        public boolean isSetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPLISTTOMODIFY$0) != 0;
            }
        }
        
        /**
         * Sets the "tpListToModify" element
         */
        public void setTpListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$0);
                }
                target.set(tpListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tpListToModify" element
         */
        public void unsetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPLISTTOMODIFY$0, 0);
            }
        }
        
        /**
         * Gets the "theSnc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getTheSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(THESNC$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "theSnc" element
         */
        public boolean isSetTheSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(THESNC$2) != 0;
            }
        }
        
        /**
         * Sets the "theSnc" element
         */
        public void setTheSnc(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType theSnc)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(THESNC$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(THESNC$2);
                }
                target.set(theSnc);
            }
        }
        
        /**
         * Appends and returns a new empty "theSnc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewTheSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(THESNC$2);
                return target;
            }
        }
        
        /**
         * Unsets the "theSnc" element
         */
        public void unsetTheSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(THESNC$2, 0);
            }
        }
        
        /**
         * Gets the "errorReason" element
         */
        public java.lang.String getErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "errorReason" element
         */
        public org.apache.xmlbeans.XmlString xgetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "errorReason" element
         */
        public boolean isSetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRORREASON$4) != 0;
            }
        }
        
        /**
         * Sets the "errorReason" element
         */
        public void setErrorReason(java.lang.String errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ERRORREASON$4);
                }
                target.setStringValue(errorReason);
            }
        }
        
        /**
         * Sets (as xml) the "errorReason" element
         */
        public void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$4);
                }
                target.set(errorReason);
            }
        }
        
        /**
         * Unsets the "errorReason" element
         */
        public void unsetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRORREASON$4, 0);
            }
        }
    }
}
