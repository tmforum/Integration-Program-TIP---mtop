/*
 * An XML document type.
 * Localname: createModifiedSubnetworkConnectionRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createModifiedSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateModifiedSubnetworkConnectionRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument
{
    
    public CreateModifiedSubnetworkConnectionRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEMODIFIEDSUBNETWORKCONNECTIONREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createModifiedSubnetworkConnectionRequest");
    
    
    /**
     * Gets the "createModifiedSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest getCreateModifiedSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest)get_store().find_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createModifiedSubnetworkConnectionRequest" element
     */
    public void setCreateModifiedSubnetworkConnectionRequest(org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest createModifiedSubnetworkConnectionRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest)get_store().find_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest)get_store().add_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONREQUEST$0);
            }
            target.set(createModifiedSubnetworkConnectionRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "createModifiedSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest addNewCreateModifiedSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest)get_store().add_element_user(CREATEMODIFIEDSUBNETWORKCONNECTIONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML createModifiedSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateModifiedSubnetworkConnectionRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateModifiedSubnetworkConnectionRequestDocument.CreateModifiedSubnetworkConnectionRequest
    {
        
        public CreateModifiedSubnetworkConnectionRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNCNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "sncName");
        private static final javax.xml.namespace.QName ROUTEID$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "routeId");
        private static final javax.xml.namespace.QName MODIFYDATA$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "modifyData");
        private static final javax.xml.namespace.QName TOLERABLEIMPACT$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tolerableImpact");
        private static final javax.xml.namespace.QName TOLERABLEIMPACTEFFORT$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tolerableImpactEffort");
        private static final javax.xml.namespace.QName OSFREEDOMLEVEL$10 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "osFreedomLevel");
        private static final javax.xml.namespace.QName TPDATALISTTOMODIFY$12 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "TpDataListToModify");
        
        
        /**
         * Gets the "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "sncName" element
         */
        public boolean isSetSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNCNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "sncName" element
         */
        public void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType sncName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SNCNAME$0);
                }
                target.set(sncName);
            }
        }
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SNCNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "sncName" element
         */
        public void unsetSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNCNAME$0, 0);
            }
        }
        
        /**
         * Gets the "routeId" element
         */
        public java.lang.String getRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "routeId" element
         */
        public org.apache.xmlbeans.XmlString xgetRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "routeId" element
         */
        public boolean isSetRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROUTEID$2) != 0;
            }
        }
        
        /**
         * Sets the "routeId" element
         */
        public void setRouteId(java.lang.String routeId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEID$2);
                }
                target.setStringValue(routeId);
            }
        }
        
        /**
         * Sets (as xml) the "routeId" element
         */
        public void xsetRouteId(org.apache.xmlbeans.XmlString routeId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEID$2);
                }
                target.set(routeId);
            }
        }
        
        /**
         * Unsets the "routeId" element
         */
        public void unsetRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROUTEID$2, 0);
            }
        }
        
        /**
         * Gets the "modifyData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType getModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType)get_store().find_element_user(MODIFYDATA$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "modifyData" element
         */
        public boolean isSetModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MODIFYDATA$4) != 0;
            }
        }
        
        /**
         * Sets the "modifyData" element
         */
        public void setModifyData(org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType modifyData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType)get_store().find_element_user(MODIFYDATA$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType)get_store().add_element_user(MODIFYDATA$4);
                }
                target.set(modifyData);
            }
        }
        
        /**
         * Appends and returns a new empty "modifyData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType addNewModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SubnetworkConnectionModifyDataType)get_store().add_element_user(MODIFYDATA$4);
                return target;
            }
        }
        
        /**
         * Unsets the "modifyData" element
         */
        public void unsetModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MODIFYDATA$4, 0);
            }
        }
        
        /**
         * Gets the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$6, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$6, 0);
                return target;
            }
        }
        
        /**
         * True if has "tolerableImpact" element
         */
        public boolean isSetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOLERABLEIMPACT$6) != 0;
            }
        }
        
        /**
         * Sets the "tolerableImpact" element
         */
        public void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOLERABLEIMPACT$6);
                }
                target.setEnumValue(tolerableImpact);
            }
        }
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        public void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().add_element_user(TOLERABLEIMPACT$6);
                }
                target.set(tolerableImpact);
            }
        }
        
        /**
         * Unsets the "tolerableImpact" element
         */
        public void unsetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOLERABLEIMPACT$6, 0);
            }
        }
        
        /**
         * Gets the "tolerableImpactEffort" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum getTolerableImpactEffort()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACTEFFORT$8, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "tolerableImpactEffort" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType xgetTolerableImpactEffort()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(TOLERABLEIMPACTEFFORT$8, 0);
                return target;
            }
        }
        
        /**
         * True if has "tolerableImpactEffort" element
         */
        public boolean isSetTolerableImpactEffort()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOLERABLEIMPACTEFFORT$8) != 0;
            }
        }
        
        /**
         * Sets the "tolerableImpactEffort" element
         */
        public void setTolerableImpactEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum tolerableImpactEffort)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACTEFFORT$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOLERABLEIMPACTEFFORT$8);
                }
                target.setEnumValue(tolerableImpactEffort);
            }
        }
        
        /**
         * Sets (as xml) the "tolerableImpactEffort" element
         */
        public void xsetTolerableImpactEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType tolerableImpactEffort)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(TOLERABLEIMPACTEFFORT$8, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().add_element_user(TOLERABLEIMPACTEFFORT$8);
                }
                target.set(tolerableImpactEffort);
            }
        }
        
        /**
         * Unsets the "tolerableImpactEffort" element
         */
        public void unsetTolerableImpactEffort()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOLERABLEIMPACTEFFORT$8, 0);
            }
        }
        
        /**
         * Gets the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum getOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$10, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType xgetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$10, 0);
                return target;
            }
        }
        
        /**
         * True if has "osFreedomLevel" element
         */
        public boolean isSetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OSFREEDOMLEVEL$10) != 0;
            }
        }
        
        /**
         * Sets the "osFreedomLevel" element
         */
        public void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSFREEDOMLEVEL$10);
                }
                target.setEnumValue(osFreedomLevel);
            }
        }
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        public void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$10, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().add_element_user(OSFREEDOMLEVEL$10);
                }
                target.set(osFreedomLevel);
            }
        }
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        public void unsetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OSFREEDOMLEVEL$10, 0);
            }
        }
        
        /**
         * Gets the "TpDataListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPDATALISTTOMODIFY$12, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "TpDataListToModify" element
         */
        public boolean isSetTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPDATALISTTOMODIFY$12) != 0;
            }
        }
        
        /**
         * Sets the "TpDataListToModify" element
         */
        public void setTpDataListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpDataListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPDATALISTTOMODIFY$12, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPDATALISTTOMODIFY$12);
                }
                target.set(tpDataListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "TpDataListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPDATALISTTOMODIFY$12);
                return target;
            }
        }
        
        /**
         * Unsets the "TpDataListToModify" element
         */
        public void unsetTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPDATALISTTOMODIFY$12, 0);
            }
        }
    }
}
