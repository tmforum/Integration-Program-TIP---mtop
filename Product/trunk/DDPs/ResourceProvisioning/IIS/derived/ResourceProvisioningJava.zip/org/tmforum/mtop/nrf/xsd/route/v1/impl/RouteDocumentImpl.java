/*
 * An XML document type.
 * Localname: route
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/route/v1
 * Java type: org.tmforum.mtop.nrf.xsd.route.v1.RouteDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.route.v1.impl;
/**
 * A document containing one route(@http://www.tmforum.org/mtop/nrf/xsd/route/v1) element.
 *
 * This is a complex type.
 */
public class RouteDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.route.v1.RouteDocument
{
    
    public RouteDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ROUTE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/route/v1", "route");
    
    
    /**
     * Gets the "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType getRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "route" element
     */
    public void setRoute(org.tmforum.mtop.nrf.xsd.route.v1.RouteType route)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$0);
            }
            target.set(route);
        }
    }
    
    /**
     * Appends and returns a new empty "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType addNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$0);
            return target;
        }
    }
}
