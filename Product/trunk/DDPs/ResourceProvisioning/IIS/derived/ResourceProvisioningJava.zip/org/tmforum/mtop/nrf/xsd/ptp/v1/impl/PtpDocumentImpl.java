/*
 * An XML document type.
 * Localname: ptp
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ptp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ptp.v1.PtpDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ptp.v1.impl;
/**
 * A document containing one ptp(@http://www.tmforum.org/mtop/nrf/xsd/ptp/v1) element.
 *
 * This is a complex type.
 */
public class PtpDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.ptp.v1.PtpDocument
{
    
    public PtpDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "ptp");
    
    
    /**
     * Gets the "ptp" element
     */
    public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType getPtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().find_element_user(PTP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ptp" element
     */
    public void setPtp(org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType ptp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().find_element_user(PTP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().add_element_user(PTP$0);
            }
            target.set(ptp);
        }
    }
    
    /**
     * Appends and returns a new empty "ptp" element
     */
    public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType addNewPtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().add_element_user(PTP$0);
            return target;
        }
    }
}
