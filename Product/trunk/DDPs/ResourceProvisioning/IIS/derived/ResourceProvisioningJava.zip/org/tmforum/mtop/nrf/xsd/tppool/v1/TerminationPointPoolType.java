/*
 * XML Type:  TerminationPointPoolType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tppool/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tppool.v1;


/**
 * An XML TerminationPointPoolType(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
 *
 * This is a complex type.
 */
public interface TerminationPointPoolType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TerminationPointPoolType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s191F600D204DEAE7EEDC98360AFBE7C2").resolveHandle("terminationpointpooltype4a9dtype");
    
    /**
     * Gets the "numberOfMembers" element
     */
    long getNumberOfMembers();
    
    /**
     * Gets (as xml) the "numberOfMembers" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfMembersType xgetNumberOfMembers();
    
    /**
     * Tests for nil "numberOfMembers" element
     */
    boolean isNilNumberOfMembers();
    
    /**
     * True if has "numberOfMembers" element
     */
    boolean isSetNumberOfMembers();
    
    /**
     * Sets the "numberOfMembers" element
     */
    void setNumberOfMembers(long numberOfMembers);
    
    /**
     * Sets (as xml) the "numberOfMembers" element
     */
    void xsetNumberOfMembers(org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfMembersType numberOfMembers);
    
    /**
     * Nils the "numberOfMembers" element
     */
    void setNilNumberOfMembers();
    
    /**
     * Unsets the "numberOfMembers" element
     */
    void unsetNumberOfMembers();
    
    /**
     * Gets the "numberOfIdleMembers" element
     */
    long getNumberOfIdleMembers();
    
    /**
     * Gets (as xml) the "numberOfIdleMembers" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfIdleMembersType xgetNumberOfIdleMembers();
    
    /**
     * Tests for nil "numberOfIdleMembers" element
     */
    boolean isNilNumberOfIdleMembers();
    
    /**
     * True if has "numberOfIdleMembers" element
     */
    boolean isSetNumberOfIdleMembers();
    
    /**
     * Sets the "numberOfIdleMembers" element
     */
    void setNumberOfIdleMembers(long numberOfIdleMembers);
    
    /**
     * Sets (as xml) the "numberOfIdleMembers" element
     */
    void xsetNumberOfIdleMembers(org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfIdleMembersType numberOfIdleMembers);
    
    /**
     * Nils the "numberOfIdleMembers" element
     */
    void setNilNumberOfIdleMembers();
    
    /**
     * Unsets the "numberOfIdleMembers" element
     */
    void unsetNumberOfIdleMembers();
    
    /**
     * Gets the "descriptionOfUse" element
     */
    java.lang.String getDescriptionOfUse();
    
    /**
     * Gets (as xml) the "descriptionOfUse" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.DescriptionOfUseType xgetDescriptionOfUse();
    
    /**
     * Tests for nil "descriptionOfUse" element
     */
    boolean isNilDescriptionOfUse();
    
    /**
     * True if has "descriptionOfUse" element
     */
    boolean isSetDescriptionOfUse();
    
    /**
     * Sets the "descriptionOfUse" element
     */
    void setDescriptionOfUse(java.lang.String descriptionOfUse);
    
    /**
     * Sets (as xml) the "descriptionOfUse" element
     */
    void xsetDescriptionOfUse(org.tmforum.mtop.nrf.xsd.tppool.v1.DescriptionOfUseType descriptionOfUse);
    
    /**
     * Nils the "descriptionOfUse" element
     */
    void setNilDescriptionOfUse();
    
    /**
     * Unsets the "descriptionOfUse" element
     */
    void unsetDescriptionOfUse();
    
    /**
     * Gets the "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList();
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    boolean isNilTransmissionParameterList();
    
    /**
     * True if has "transmissionParameterList" element
     */
    boolean isSetTransmissionParameterList();
    
    /**
     * Sets the "transmissionParameterList" element
     */
    void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList);
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList();
    
    /**
     * Nils the "transmissionParameterList" element
     */
    void setNilTransmissionParameterList();
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    void unsetTransmissionParameterList();
    
    /**
     * Gets the "containedMemberList" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.ContainedMemberList getContainedMemberList();
    
    /**
     * Tests for nil "containedMemberList" element
     */
    boolean isNilContainedMemberList();
    
    /**
     * True if has "containedMemberList" element
     */
    boolean isSetContainedMemberList();
    
    /**
     * Sets the "containedMemberList" element
     */
    void setContainedMemberList(org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.ContainedMemberList containedMemberList);
    
    /**
     * Appends and returns a new empty "containedMemberList" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.ContainedMemberList addNewContainedMemberList();
    
    /**
     * Nils the "containedMemberList" element
     */
    void setNilContainedMemberList();
    
    /**
     * Unsets the "containedMemberList" element
     */
    void unsetContainedMemberList();
    
    /**
     * Gets the "memberContainingMeList" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingMeList getMemberContainingMeList();
    
    /**
     * Tests for nil "memberContainingMeList" element
     */
    boolean isNilMemberContainingMeList();
    
    /**
     * True if has "memberContainingMeList" element
     */
    boolean isSetMemberContainingMeList();
    
    /**
     * Sets the "memberContainingMeList" element
     */
    void setMemberContainingMeList(org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingMeList memberContainingMeList);
    
    /**
     * Appends and returns a new empty "memberContainingMeList" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingMeList addNewMemberContainingMeList();
    
    /**
     * Nils the "memberContainingMeList" element
     */
    void setNilMemberContainingMeList();
    
    /**
     * Unsets the "memberContainingMeList" element
     */
    void unsetMemberContainingMeList();
    
    /**
     * Gets the "memberContainingTpList" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingTpList getMemberContainingTpList();
    
    /**
     * Tests for nil "memberContainingTpList" element
     */
    boolean isNilMemberContainingTpList();
    
    /**
     * True if has "memberContainingTpList" element
     */
    boolean isSetMemberContainingTpList();
    
    /**
     * Sets the "memberContainingTpList" element
     */
    void setMemberContainingTpList(org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingTpList memberContainingTpList);
    
    /**
     * Appends and returns a new empty "memberContainingTpList" element
     */
    org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingTpList addNewMemberContainingTpList();
    
    /**
     * Nils the "memberContainingTpList" element
     */
    void setNilMemberContainingTpList();
    
    /**
     * Unsets the "memberContainingTpList" element
     */
    void unsetMemberContainingTpList();
    
    /**
     * An XML containedMemberList(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
     *
     * This is a complex type.
     */
    public interface ContainedMemberList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ContainedMemberList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s191F600D204DEAE7EEDC98360AFBE7C2").resolveHandle("containedmemberlist94e6elemtype");
        
        /**
         * Gets a List of "containedMember" elements
         */
        java.util.List<java.lang.String> getContainedMemberList();
        
        /**
         * Gets array of all "containedMember" elements
         * @deprecated
         */
        java.lang.String[] getContainedMemberArray();
        
        /**
         * Gets ith "containedMember" element
         */
        java.lang.String getContainedMemberArray(int i);
        
        /**
         * Gets (as xml) a List of "containedMember" elements
         */
        java.util.List<org.apache.xmlbeans.XmlString> xgetContainedMemberList();
        
        /**
         * Gets (as xml) array of all "containedMember" elements
         * @deprecated
         */
        org.apache.xmlbeans.XmlString[] xgetContainedMemberArray();
        
        /**
         * Gets (as xml) ith "containedMember" element
         */
        org.apache.xmlbeans.XmlString xgetContainedMemberArray(int i);
        
        /**
         * Returns number of "containedMember" element
         */
        int sizeOfContainedMemberArray();
        
        /**
         * Sets array of all "containedMember" element
         */
        void setContainedMemberArray(java.lang.String[] containedMemberArray);
        
        /**
         * Sets ith "containedMember" element
         */
        void setContainedMemberArray(int i, java.lang.String containedMember);
        
        /**
         * Sets (as xml) array of all "containedMember" element
         */
        void xsetContainedMemberArray(org.apache.xmlbeans.XmlString[] containedMemberArray);
        
        /**
         * Sets (as xml) ith "containedMember" element
         */
        void xsetContainedMemberArray(int i, org.apache.xmlbeans.XmlString containedMember);
        
        /**
         * Inserts the value as the ith "containedMember" element
         */
        void insertContainedMember(int i, java.lang.String containedMember);
        
        /**
         * Appends the value as the last "containedMember" element
         */
        void addContainedMember(java.lang.String containedMember);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "containedMember" element
         */
        org.apache.xmlbeans.XmlString insertNewContainedMember(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "containedMember" element
         */
        org.apache.xmlbeans.XmlString addNewContainedMember();
        
        /**
         * Removes the ith "containedMember" element
         */
        void removeContainedMember(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.ContainedMemberList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.ContainedMemberList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.ContainedMemberList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.ContainedMemberList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML memberContainingMeList(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
     *
     * This is a complex type.
     */
    public interface MemberContainingMeList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MemberContainingMeList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s191F600D204DEAE7EEDC98360AFBE7C2").resolveHandle("membercontainingmelist2c03elemtype");
        
        /**
         * Gets a List of "memberContainingMe" elements
         */
        java.util.List<java.lang.String> getMemberContainingMeList();
        
        /**
         * Gets array of all "memberContainingMe" elements
         * @deprecated
         */
        java.lang.String[] getMemberContainingMeArray();
        
        /**
         * Gets ith "memberContainingMe" element
         */
        java.lang.String getMemberContainingMeArray(int i);
        
        /**
         * Gets (as xml) a List of "memberContainingMe" elements
         */
        java.util.List<org.apache.xmlbeans.XmlString> xgetMemberContainingMeList();
        
        /**
         * Gets (as xml) array of all "memberContainingMe" elements
         * @deprecated
         */
        org.apache.xmlbeans.XmlString[] xgetMemberContainingMeArray();
        
        /**
         * Gets (as xml) ith "memberContainingMe" element
         */
        org.apache.xmlbeans.XmlString xgetMemberContainingMeArray(int i);
        
        /**
         * Returns number of "memberContainingMe" element
         */
        int sizeOfMemberContainingMeArray();
        
        /**
         * Sets array of all "memberContainingMe" element
         */
        void setMemberContainingMeArray(java.lang.String[] memberContainingMeArray);
        
        /**
         * Sets ith "memberContainingMe" element
         */
        void setMemberContainingMeArray(int i, java.lang.String memberContainingMe);
        
        /**
         * Sets (as xml) array of all "memberContainingMe" element
         */
        void xsetMemberContainingMeArray(org.apache.xmlbeans.XmlString[] memberContainingMeArray);
        
        /**
         * Sets (as xml) ith "memberContainingMe" element
         */
        void xsetMemberContainingMeArray(int i, org.apache.xmlbeans.XmlString memberContainingMe);
        
        /**
         * Inserts the value as the ith "memberContainingMe" element
         */
        void insertMemberContainingMe(int i, java.lang.String memberContainingMe);
        
        /**
         * Appends the value as the last "memberContainingMe" element
         */
        void addMemberContainingMe(java.lang.String memberContainingMe);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "memberContainingMe" element
         */
        org.apache.xmlbeans.XmlString insertNewMemberContainingMe(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "memberContainingMe" element
         */
        org.apache.xmlbeans.XmlString addNewMemberContainingMe();
        
        /**
         * Removes the ith "memberContainingMe" element
         */
        void removeMemberContainingMe(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingMeList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingMeList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingMeList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingMeList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML memberContainingTpList(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
     *
     * This is a complex type.
     */
    public interface MemberContainingTpList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MemberContainingTpList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s191F600D204DEAE7EEDC98360AFBE7C2").resolveHandle("membercontainingtplistdd9felemtype");
        
        /**
         * Gets a List of "memberContainingTp" elements
         */
        java.util.List<java.lang.String> getMemberContainingTpList();
        
        /**
         * Gets array of all "memberContainingTp" elements
         * @deprecated
         */
        java.lang.String[] getMemberContainingTpArray();
        
        /**
         * Gets ith "memberContainingTp" element
         */
        java.lang.String getMemberContainingTpArray(int i);
        
        /**
         * Gets (as xml) a List of "memberContainingTp" elements
         */
        java.util.List<org.apache.xmlbeans.XmlString> xgetMemberContainingTpList();
        
        /**
         * Gets (as xml) array of all "memberContainingTp" elements
         * @deprecated
         */
        org.apache.xmlbeans.XmlString[] xgetMemberContainingTpArray();
        
        /**
         * Gets (as xml) ith "memberContainingTp" element
         */
        org.apache.xmlbeans.XmlString xgetMemberContainingTpArray(int i);
        
        /**
         * Returns number of "memberContainingTp" element
         */
        int sizeOfMemberContainingTpArray();
        
        /**
         * Sets array of all "memberContainingTp" element
         */
        void setMemberContainingTpArray(java.lang.String[] memberContainingTpArray);
        
        /**
         * Sets ith "memberContainingTp" element
         */
        void setMemberContainingTpArray(int i, java.lang.String memberContainingTp);
        
        /**
         * Sets (as xml) array of all "memberContainingTp" element
         */
        void xsetMemberContainingTpArray(org.apache.xmlbeans.XmlString[] memberContainingTpArray);
        
        /**
         * Sets (as xml) ith "memberContainingTp" element
         */
        void xsetMemberContainingTpArray(int i, org.apache.xmlbeans.XmlString memberContainingTp);
        
        /**
         * Inserts the value as the ith "memberContainingTp" element
         */
        void insertMemberContainingTp(int i, java.lang.String memberContainingTp);
        
        /**
         * Appends the value as the last "memberContainingTp" element
         */
        void addMemberContainingTp(java.lang.String memberContainingTp);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "memberContainingTp" element
         */
        org.apache.xmlbeans.XmlString insertNewMemberContainingTp(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "memberContainingTp" element
         */
        org.apache.xmlbeans.XmlString addNewMemberContainingTp();
        
        /**
         * Removes the ith "memberContainingTp" element
         */
        void removeMemberContainingTp(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingTpList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingTpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingTpList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType.MemberContainingTpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
