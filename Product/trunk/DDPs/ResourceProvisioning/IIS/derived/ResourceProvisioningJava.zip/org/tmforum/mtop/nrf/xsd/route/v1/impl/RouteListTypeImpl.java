/*
 * XML Type:  RouteListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/route/v1
 * Java type: org.tmforum.mtop.nrf.xsd.route.v1.RouteListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.route.v1.impl;
/**
 * An XML RouteListType(@http://www.tmforum.org/mtop/nrf/xsd/route/v1).
 *
 * This is a complex type.
 */
public class RouteListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.route.v1.RouteListType
{
    
    public RouteListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ROUTE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/route/v1", "route");
    
    
    /**
     * Gets a List of "route" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.route.v1.RouteType> getRouteList()
    {
        final class RouteList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.route.v1.RouteType>
        {
            public org.tmforum.mtop.nrf.xsd.route.v1.RouteType get(int i)
                { return RouteListTypeImpl.this.getRouteArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.route.v1.RouteType set(int i, org.tmforum.mtop.nrf.xsd.route.v1.RouteType o)
            {
                org.tmforum.mtop.nrf.xsd.route.v1.RouteType old = RouteListTypeImpl.this.getRouteArray(i);
                RouteListTypeImpl.this.setRouteArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.route.v1.RouteType o)
                { RouteListTypeImpl.this.insertNewRoute(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.route.v1.RouteType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.route.v1.RouteType old = RouteListTypeImpl.this.getRouteArray(i);
                RouteListTypeImpl.this.removeRoute(i);
                return old;
            }
            
            public int size()
                { return RouteListTypeImpl.this.sizeOfRouteArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new RouteList();
        }
    }
    
    /**
     * Gets array of all "route" elements
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType[] getRouteArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ROUTE$0, targetList);
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType[] result = new org.tmforum.mtop.nrf.xsd.route.v1.RouteType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType getRouteArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "route" element
     */
    public int sizeOfRouteArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTE$0);
        }
    }
    
    /**
     * Sets array of all "route" element
     */
    public void setRouteArray(org.tmforum.mtop.nrf.xsd.route.v1.RouteType[] routeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(routeArray, ROUTE$0);
        }
    }
    
    /**
     * Sets ith "route" element
     */
    public void setRouteArray(int i, org.tmforum.mtop.nrf.xsd.route.v1.RouteType route)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(route);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType insertNewRoute(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().insert_element_user(ROUTE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType addNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "route" element
     */
    public void removeRoute(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTE$0, i);
        }
    }
}
