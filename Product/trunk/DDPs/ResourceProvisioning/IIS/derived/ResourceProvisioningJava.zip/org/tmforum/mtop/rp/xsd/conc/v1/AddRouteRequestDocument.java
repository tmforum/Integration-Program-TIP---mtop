/*
 * An XML document type.
 * Localname: addRouteRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1;


/**
 * A document containing one addRouteRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public interface AddRouteRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AddRouteRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s732E47122B99A5ED8D93FEE82721A56B").resolveHandle("addrouterequestbe91doctype");
    
    /**
     * Gets the "addRouteRequest" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument.AddRouteRequest getAddRouteRequest();
    
    /**
     * Sets the "addRouteRequest" element
     */
    void setAddRouteRequest(org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument.AddRouteRequest addRouteRequest);
    
    /**
     * Appends and returns a new empty "addRouteRequest" element
     */
    org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument.AddRouteRequest addNewAddRouteRequest();
    
    /**
     * An XML addRouteRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public interface AddRouteRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AddRouteRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s732E47122B99A5ED8D93FEE82721A56B").resolveHandle("addrouterequestafbeelemtype");
        
        /**
         * Gets the "sncName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSncName();
        
        /**
         * True if has "sncName" element
         */
        boolean isSetSncName();
        
        /**
         * Sets the "sncName" element
         */
        void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType sncName);
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSncName();
        
        /**
         * Unsets the "sncName" element
         */
        void unsetSncName();
        
        /**
         * Gets the "createRoute" element
         */
        org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType getCreateRoute();
        
        /**
         * True if has "createRoute" element
         */
        boolean isSetCreateRoute();
        
        /**
         * Sets the "createRoute" element
         */
        void setCreateRoute(org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType createRoute);
        
        /**
         * Appends and returns a new empty "createRoute" element
         */
        org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType addNewCreateRoute();
        
        /**
         * Unsets the "createRoute" element
         */
        void unsetCreateRoute();
        
        /**
         * Gets the "tolerableImpact" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact();
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact();
        
        /**
         * True if has "tolerableImpact" element
         */
        boolean isSetTolerableImpact();
        
        /**
         * Sets the "tolerableImpact" element
         */
        void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact);
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact);
        
        /**
         * Unsets the "tolerableImpact" element
         */
        void unsetTolerableImpact();
        
        /**
         * Gets the "osFreedomLevel" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum getOsFreedomLevel();
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType xgetOsFreedomLevel();
        
        /**
         * True if has "osFreedomLevel" element
         */
        boolean isSetOsFreedomLevel();
        
        /**
         * Sets the "osFreedomLevel" element
         */
        void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum osFreedomLevel);
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType osFreedomLevel);
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        void unsetOsFreedomLevel();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument.AddRouteRequest newInstance() {
              return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument.AddRouteRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument.AddRouteRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument.AddRouteRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument newInstance() {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rp.xsd.conc.v1.AddRouteRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
