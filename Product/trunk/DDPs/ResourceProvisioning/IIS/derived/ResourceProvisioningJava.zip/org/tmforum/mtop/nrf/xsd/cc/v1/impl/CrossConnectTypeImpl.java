/*
 * XML Type:  CrossConnectType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/cc/v1
 * Java type: org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.cc.v1.impl;
/**
 * An XML CrossConnectType(@http://www.tmforum.org/mtop/nrf/xsd/cc/v1).
 *
 * This is a complex type.
 */
public class CrossConnectTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType
{
    
    public CrossConnectTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACTIVE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "active");
    private static final javax.xml.namespace.QName DIRECTION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "direction");
    private static final javax.xml.namespace.QName CCTYPE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "ccType");
    private static final javax.xml.namespace.QName FIXED$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "fixed");
    private static final javax.xml.namespace.QName AENDNAMELIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "aEndNameList");
    private static final javax.xml.namespace.QName ZENDNAMELIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "zEndNameList");
    private static final javax.xml.namespace.QName CONNECTIONID$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "connectionId");
    private static final javax.xml.namespace.QName ROUTEACTUALSTATE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "routeActualState");
    private static final javax.xml.namespace.QName ROUTEADMINSTATE$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "routeAdminState");
    private static final javax.xml.namespace.QName ROUTEEXCLUSIVE$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "routeExclusive");
    private static final javax.xml.namespace.QName ROUTEID$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "routeId");
    private static final javax.xml.namespace.QName ROUTEINTENDED$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "routeIntended");
    private static final javax.xml.namespace.QName ROUTEINUSEBY$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "routeInUseBy");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "vendorExtensions");
    
    
    /**
     * Gets the "active" element
     */
    public boolean getActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVE$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "active" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACTIVE$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "active" element
     */
    public boolean isNilActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACTIVE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "active" element
     */
    public boolean isSetActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACTIVE$0) != 0;
        }
    }
    
    /**
     * Sets the "active" element
     */
    public void setActive(boolean active)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACTIVE$0);
            }
            target.setBooleanValue(active);
        }
    }
    
    /**
     * Sets (as xml) the "active" element
     */
    public void xsetActive(org.apache.xmlbeans.XmlBoolean active)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACTIVE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ACTIVE$0);
            }
            target.set(active);
        }
    }
    
    /**
     * Nils the "active" element
     */
    public void setNilActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACTIVE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ACTIVE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "active" element
     */
    public void unsetActive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACTIVE$0, 0);
        }
    }
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$2) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$2);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$2);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$2, 0);
        }
    }
    
    /**
     * Gets the "ccType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum getCcType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCTYPE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "ccType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType xgetCcType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(CCTYPE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ccType" element
     */
    public boolean isNilCcType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(CCTYPE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ccType" element
     */
    public boolean isSetCcType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CCTYPE$4) != 0;
        }
    }
    
    /**
     * Sets the "ccType" element
     */
    public void setCcType(org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum ccType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CCTYPE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CCTYPE$4);
            }
            target.setEnumValue(ccType);
        }
    }
    
    /**
     * Sets (as xml) the "ccType" element
     */
    public void xsetCcType(org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType ccType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(CCTYPE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().add_element_user(CCTYPE$4);
            }
            target.set(ccType);
        }
    }
    
    /**
     * Nils the "ccType" element
     */
    public void setNilCcType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(CCTYPE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().add_element_user(CCTYPE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ccType" element
     */
    public void unsetCcType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CCTYPE$4, 0);
        }
    }
    
    /**
     * Gets the "fixed" element
     */
    public boolean getFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FIXED$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "fixed" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "fixed" element
     */
    public boolean isNilFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "fixed" element
     */
    public boolean isSetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FIXED$6) != 0;
        }
    }
    
    /**
     * Sets the "fixed" element
     */
    public void setFixed(boolean fixed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FIXED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FIXED$6);
            }
            target.setBooleanValue(fixed);
        }
    }
    
    /**
     * Sets (as xml) the "fixed" element
     */
    public void xsetFixed(org.apache.xmlbeans.XmlBoolean fixed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FIXED$6);
            }
            target.set(fixed);
        }
    }
    
    /**
     * Nils the "fixed" element
     */
    public void setNilFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FIXED$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "fixed" element
     */
    public void unsetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FIXED$6, 0);
        }
    }
    
    /**
     * Gets the "aEndNameList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList getAEndNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList)get_store().find_element_user(AENDNAMELIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "aEndNameList" element
     */
    public void setAEndNameList(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList aEndNameList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList)get_store().find_element_user(AENDNAMELIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList)get_store().add_element_user(AENDNAMELIST$8);
            }
            target.set(aEndNameList);
        }
    }
    
    /**
     * Appends and returns a new empty "aEndNameList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList addNewAEndNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList)get_store().add_element_user(AENDNAMELIST$8);
            return target;
        }
    }
    
    /**
     * Gets the "zEndNameList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList getZEndNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList)get_store().find_element_user(ZENDNAMELIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "zEndNameList" element
     */
    public void setZEndNameList(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList zEndNameList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList)get_store().find_element_user(ZENDNAMELIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList)get_store().add_element_user(ZENDNAMELIST$10);
            }
            target.set(zEndNameList);
        }
    }
    
    /**
     * Appends and returns a new empty "zEndNameList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList addNewZEndNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList)get_store().add_element_user(ZENDNAMELIST$10);
            return target;
        }
    }
    
    /**
     * Gets the "connectionId" element
     */
    public java.lang.String getConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONID$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "connectionId" element
     */
    public org.apache.xmlbeans.XmlString xgetConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONID$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "connectionId" element
     */
    public boolean isNilConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONID$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "connectionId" element
     */
    public boolean isSetConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIONID$12) != 0;
        }
    }
    
    /**
     * Sets the "connectionId" element
     */
    public void setConnectionId(java.lang.String connectionId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONID$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONNECTIONID$12);
            }
            target.setStringValue(connectionId);
        }
    }
    
    /**
     * Sets (as xml) the "connectionId" element
     */
    public void xsetConnectionId(org.apache.xmlbeans.XmlString connectionId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONID$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONNECTIONID$12);
            }
            target.set(connectionId);
        }
    }
    
    /**
     * Nils the "connectionId" element
     */
    public void setNilConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONNECTIONID$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONNECTIONID$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "connectionId" element
     */
    public void unsetConnectionId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIONID$12, 0);
        }
    }
    
    /**
     * Gets the "routeActualState" element
     */
    public java.lang.String getRouteActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEACTUALSTATE$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeActualState" element
     */
    public org.apache.xmlbeans.XmlString xgetRouteActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEACTUALSTATE$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routeActualState" element
     */
    public boolean isNilRouteActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEACTUALSTATE$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routeActualState" element
     */
    public boolean isSetRouteActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEACTUALSTATE$14) != 0;
        }
    }
    
    /**
     * Sets the "routeActualState" element
     */
    public void setRouteActualState(java.lang.String routeActualState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEACTUALSTATE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEACTUALSTATE$14);
            }
            target.setStringValue(routeActualState);
        }
    }
    
    /**
     * Sets (as xml) the "routeActualState" element
     */
    public void xsetRouteActualState(org.apache.xmlbeans.XmlString routeActualState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEACTUALSTATE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEACTUALSTATE$14);
            }
            target.set(routeActualState);
        }
    }
    
    /**
     * Nils the "routeActualState" element
     */
    public void setNilRouteActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEACTUALSTATE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEACTUALSTATE$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routeActualState" element
     */
    public void unsetRouteActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEACTUALSTATE$14, 0);
        }
    }
    
    /**
     * Gets the "routeAdminState" element
     */
    public java.lang.String getRouteAdminState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEADMINSTATE$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeAdminState" element
     */
    public org.apache.xmlbeans.XmlString xgetRouteAdminState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEADMINSTATE$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routeAdminState" element
     */
    public boolean isNilRouteAdminState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEADMINSTATE$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routeAdminState" element
     */
    public boolean isSetRouteAdminState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEADMINSTATE$16) != 0;
        }
    }
    
    /**
     * Sets the "routeAdminState" element
     */
    public void setRouteAdminState(java.lang.String routeAdminState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEADMINSTATE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEADMINSTATE$16);
            }
            target.setStringValue(routeAdminState);
        }
    }
    
    /**
     * Sets (as xml) the "routeAdminState" element
     */
    public void xsetRouteAdminState(org.apache.xmlbeans.XmlString routeAdminState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEADMINSTATE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEADMINSTATE$16);
            }
            target.set(routeAdminState);
        }
    }
    
    /**
     * Nils the "routeAdminState" element
     */
    public void setNilRouteAdminState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEADMINSTATE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEADMINSTATE$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routeAdminState" element
     */
    public void unsetRouteAdminState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEADMINSTATE$16, 0);
        }
    }
    
    /**
     * Gets the "routeExclusive" element
     */
    public boolean getRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEEXCLUSIVE$18, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeExclusive" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEEXCLUSIVE$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routeExclusive" element
     */
    public boolean isNilRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEEXCLUSIVE$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routeExclusive" element
     */
    public boolean isSetRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEEXCLUSIVE$18) != 0;
        }
    }
    
    /**
     * Sets the "routeExclusive" element
     */
    public void setRouteExclusive(boolean routeExclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEEXCLUSIVE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEEXCLUSIVE$18);
            }
            target.setBooleanValue(routeExclusive);
        }
    }
    
    /**
     * Sets (as xml) the "routeExclusive" element
     */
    public void xsetRouteExclusive(org.apache.xmlbeans.XmlBoolean routeExclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEEXCLUSIVE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ROUTEEXCLUSIVE$18);
            }
            target.set(routeExclusive);
        }
    }
    
    /**
     * Nils the "routeExclusive" element
     */
    public void setNilRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEEXCLUSIVE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ROUTEEXCLUSIVE$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routeExclusive" element
     */
    public void unsetRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEEXCLUSIVE$18, 0);
        }
    }
    
    /**
     * Gets the "routeId" element
     */
    public java.lang.String getRouteId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEID$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeId" element
     */
    public org.apache.xmlbeans.XmlString xgetRouteId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$20, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routeId" element
     */
    public boolean isNilRouteId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routeId" element
     */
    public boolean isSetRouteId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEID$20) != 0;
        }
    }
    
    /**
     * Sets the "routeId" element
     */
    public void setRouteId(java.lang.String routeId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEID$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEID$20);
            }
            target.setStringValue(routeId);
        }
    }
    
    /**
     * Sets (as xml) the "routeId" element
     */
    public void xsetRouteId(org.apache.xmlbeans.XmlString routeId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEID$20);
            }
            target.set(routeId);
        }
    }
    
    /**
     * Nils the "routeId" element
     */
    public void setNilRouteId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEID$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routeId" element
     */
    public void unsetRouteId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEID$20, 0);
        }
    }
    
    /**
     * Gets the "routeIntended" element
     */
    public boolean getRouteIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEINTENDED$22, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeIntended" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRouteIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEINTENDED$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routeIntended" element
     */
    public boolean isNilRouteIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEINTENDED$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routeIntended" element
     */
    public boolean isSetRouteIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEINTENDED$22) != 0;
        }
    }
    
    /**
     * Sets the "routeIntended" element
     */
    public void setRouteIntended(boolean routeIntended)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEINTENDED$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEINTENDED$22);
            }
            target.setBooleanValue(routeIntended);
        }
    }
    
    /**
     * Sets (as xml) the "routeIntended" element
     */
    public void xsetRouteIntended(org.apache.xmlbeans.XmlBoolean routeIntended)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEINTENDED$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ROUTEINTENDED$22);
            }
            target.set(routeIntended);
        }
    }
    
    /**
     * Nils the "routeIntended" element
     */
    public void setNilRouteIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEINTENDED$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ROUTEINTENDED$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routeIntended" element
     */
    public void unsetRouteIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEINTENDED$22, 0);
        }
    }
    
    /**
     * Gets the "routeInUseBy" element
     */
    public boolean getRouteInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEINUSEBY$24, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeInUseBy" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRouteInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEINUSEBY$24, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routeInUseBy" element
     */
    public boolean isNilRouteInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEINUSEBY$24, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routeInUseBy" element
     */
    public boolean isSetRouteInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEINUSEBY$24) != 0;
        }
    }
    
    /**
     * Sets the "routeInUseBy" element
     */
    public void setRouteInUseBy(boolean routeInUseBy)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEINUSEBY$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEINUSEBY$24);
            }
            target.setBooleanValue(routeInUseBy);
        }
    }
    
    /**
     * Sets (as xml) the "routeInUseBy" element
     */
    public void xsetRouteInUseBy(org.apache.xmlbeans.XmlBoolean routeInUseBy)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEINUSEBY$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ROUTEINUSEBY$24);
            }
            target.set(routeInUseBy);
        }
    }
    
    /**
     * Nils the "routeInUseBy" element
     */
    public void setNilRouteInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROUTEINUSEBY$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ROUTEINUSEBY$24);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routeInUseBy" element
     */
    public void unsetRouteInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEINUSEBY$24, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$26, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$26) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$26, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$26);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$26);
            return target;
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$26, 0);
        }
    }
    /**
     * An XML aEndNameList(@http://www.tmforum.org/mtop/nrf/xsd/cc/v1).
     *
     * This is a complex type.
     */
    public static class AEndNameListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.AEndNameList
    {
        
        public AEndNameListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName AENDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "aEndName");
        
        
        /**
         * Gets a List of "aEndName" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getAEndNameList()
        {
            final class AEndNameList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType>
            {
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType get(int i)
                    { return AEndNameListImpl.this.getAEndNameArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = AEndNameListImpl.this.getAEndNameArray(i);
                    AEndNameListImpl.this.setAEndNameArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                    { AEndNameListImpl.this.insertNewAEndName(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = AEndNameListImpl.this.getAEndNameArray(i);
                    AEndNameListImpl.this.removeAEndName(i);
                    return old;
                }
                
                public int size()
                    { return AEndNameListImpl.this.sizeOfAEndNameArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new AEndNameList();
            }
        }
        
        /**
         * Gets array of all "aEndName" elements
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getAEndNameArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(AENDNAME$0, targetList);
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "aEndName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getAEndNameArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(AENDNAME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "aEndName" element
         */
        public int sizeOfAEndNameArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(AENDNAME$0);
            }
        }
        
        /**
         * Sets array of all "aEndName" element
         */
        public void setAEndNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] aEndNameArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(aEndNameArray, AENDNAME$0);
            }
        }
        
        /**
         * Sets ith "aEndName" element
         */
        public void setAEndNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType aEndName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(AENDNAME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(aEndName);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "aEndName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewAEndName(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().insert_element_user(AENDNAME$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "aEndName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewAEndName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(AENDNAME$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "aEndName" element
         */
        public void removeAEndName(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(AENDNAME$0, i);
            }
        }
    }
    /**
     * An XML zEndNameList(@http://www.tmforum.org/mtop/nrf/xsd/cc/v1).
     *
     * This is a complex type.
     */
    public static class ZEndNameListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType.ZEndNameList
    {
        
        public ZEndNameListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ZENDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "zEndName");
        
        
        /**
         * Gets a List of "zEndName" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getZEndNameList()
        {
            final class ZEndNameList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType>
            {
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType get(int i)
                    { return ZEndNameListImpl.this.getZEndNameArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = ZEndNameListImpl.this.getZEndNameArray(i);
                    ZEndNameListImpl.this.setZEndNameArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                    { ZEndNameListImpl.this.insertNewZEndName(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = ZEndNameListImpl.this.getZEndNameArray(i);
                    ZEndNameListImpl.this.removeZEndName(i);
                    return old;
                }
                
                public int size()
                    { return ZEndNameListImpl.this.sizeOfZEndNameArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ZEndNameList();
            }
        }
        
        /**
         * Gets array of all "zEndName" elements
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getZEndNameArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ZENDNAME$0, targetList);
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "zEndName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getZEndNameArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ZENDNAME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "zEndName" element
         */
        public int sizeOfZEndNameArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ZENDNAME$0);
            }
        }
        
        /**
         * Sets array of all "zEndName" element
         */
        public void setZEndNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] zEndNameArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(zEndNameArray, ZENDNAME$0);
            }
        }
        
        /**
         * Sets ith "zEndName" element
         */
        public void setZEndNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType zEndName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ZENDNAME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(zEndName);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "zEndName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewZEndName(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().insert_element_user(ZENDNAME$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "zEndName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewZEndName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ZENDNAME$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "zEndName" element
         */
        public void removeZEndName(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ZENDNAME$0, i);
            }
        }
    }
}
