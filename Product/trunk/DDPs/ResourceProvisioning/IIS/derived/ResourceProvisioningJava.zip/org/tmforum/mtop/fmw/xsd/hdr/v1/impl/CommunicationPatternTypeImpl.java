/*
 * XML Type:  CommunicationPatternType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/hdr/v1
 * Java type: org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.hdr.v1.impl;
/**
 * An XML CommunicationPatternType(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType.
 */
public class CommunicationPatternTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType
{
    
    public CommunicationPatternTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected CommunicationPatternTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
