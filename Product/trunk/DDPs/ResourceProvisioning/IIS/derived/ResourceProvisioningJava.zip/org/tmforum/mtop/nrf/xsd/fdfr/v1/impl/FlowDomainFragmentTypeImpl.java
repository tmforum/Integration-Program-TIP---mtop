/*
 * XML Type:  FlowDomainFragmentType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fdfr.v1.impl;
/**
 * An XML FlowDomainFragmentType(@http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1).
 *
 * This is a complex type.
 */
public class FlowDomainFragmentTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType
{
    
    public FlowDomainFragmentTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "direction");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMETERLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "transmissionParameterList");
    private static final javax.xml.namespace.QName AENDTPDATALIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "aEndTpDataList");
    private static final javax.xml.namespace.QName ZENDTPDATALIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "zEndTpDataList");
    private static final javax.xml.namespace.QName ISFLEXIBLE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "isFlexible");
    private static final javax.xml.namespace.QName ADMINISTRATIVESTATE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "administrativeState");
    private static final javax.xml.namespace.QName FDFRSTATE$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "fdfrState");
    private static final javax.xml.namespace.QName FDFRTYPE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "fdfrType");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$0) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$0, 0);
        }
    }
    
    /**
     * Gets the "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType getTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    public boolean isNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParameterList" element
     */
    public boolean isSetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMETERLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParameterList" element
     */
    public void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType transmissionParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            }
            target.set(transmissionParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType addNewTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParameterList" element
     */
    public void setNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    public void unsetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMETERLIST$2, 0);
        }
    }
    
    /**
     * Gets the "aEndTpDataList" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getAEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(AENDTPDATALIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "aEndTpDataList" element
     */
    public boolean isNilAEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(AENDTPDATALIST$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aEndTpDataList" element
     */
    public boolean isSetAEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AENDTPDATALIST$4) != 0;
        }
    }
    
    /**
     * Sets the "aEndTpDataList" element
     */
    public void setAEndTpDataList(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType aEndTpDataList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(AENDTPDATALIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(AENDTPDATALIST$4);
            }
            target.set(aEndTpDataList);
        }
    }
    
    /**
     * Appends and returns a new empty "aEndTpDataList" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewAEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(AENDTPDATALIST$4);
            return target;
        }
    }
    
    /**
     * Nils the "aEndTpDataList" element
     */
    public void setNilAEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(AENDTPDATALIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(AENDTPDATALIST$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aEndTpDataList" element
     */
    public void unsetAEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AENDTPDATALIST$4, 0);
        }
    }
    
    /**
     * Gets the "zEndTpDataList" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getZEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(ZENDTPDATALIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "zEndTpDataList" element
     */
    public boolean isNilZEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(ZENDTPDATALIST$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "zEndTpDataList" element
     */
    public boolean isSetZEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZENDTPDATALIST$6) != 0;
        }
    }
    
    /**
     * Sets the "zEndTpDataList" element
     */
    public void setZEndTpDataList(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType zEndTpDataList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(ZENDTPDATALIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(ZENDTPDATALIST$6);
            }
            target.set(zEndTpDataList);
        }
    }
    
    /**
     * Appends and returns a new empty "zEndTpDataList" element
     */
    public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewZEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(ZENDTPDATALIST$6);
            return target;
        }
    }
    
    /**
     * Nils the "zEndTpDataList" element
     */
    public void setNilZEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(ZENDTPDATALIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(ZENDTPDATALIST$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "zEndTpDataList" element
     */
    public void unsetZEndTpDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZENDTPDATALIST$6, 0);
        }
    }
    
    /**
     * Gets the "isFlexible" element
     */
    public boolean getIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isFlexible" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isFlexible" element
     */
    public boolean isNilIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isFlexible" element
     */
    public boolean isSetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISFLEXIBLE$8) != 0;
        }
    }
    
    /**
     * Sets the "isFlexible" element
     */
    public void setIsFlexible(boolean isFlexible)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISFLEXIBLE$8);
            }
            target.setBooleanValue(isFlexible);
        }
    }
    
    /**
     * Sets (as xml) the "isFlexible" element
     */
    public void xsetIsFlexible(org.apache.xmlbeans.XmlBoolean isFlexible)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISFLEXIBLE$8);
            }
            target.set(isFlexible);
        }
    }
    
    /**
     * Nils the "isFlexible" element
     */
    public void setNilIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISFLEXIBLE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isFlexible" element
     */
    public void unsetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISFLEXIBLE$8, 0);
        }
    }
    
    /**
     * Gets the "administrativeState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum getAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADMINISTRATIVESTATE$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "administrativeState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType xgetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(ADMINISTRATIVESTATE$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "administrativeState" element
     */
    public boolean isNilAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(ADMINISTRATIVESTATE$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "administrativeState" element
     */
    public boolean isSetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ADMINISTRATIVESTATE$10) != 0;
        }
    }
    
    /**
     * Sets the "administrativeState" element
     */
    public void setAdministrativeState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum administrativeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADMINISTRATIVESTATE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ADMINISTRATIVESTATE$10);
            }
            target.setEnumValue(administrativeState);
        }
    }
    
    /**
     * Sets (as xml) the "administrativeState" element
     */
    public void xsetAdministrativeState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType administrativeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(ADMINISTRATIVESTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().add_element_user(ADMINISTRATIVESTATE$10);
            }
            target.set(administrativeState);
        }
    }
    
    /**
     * Nils the "administrativeState" element
     */
    public void setNilAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(ADMINISTRATIVESTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().add_element_user(ADMINISTRATIVESTATE$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "administrativeState" element
     */
    public void unsetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ADMINISTRATIVESTATE$10, 0);
        }
    }
    
    /**
     * Gets the "fdfrState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum getFdfrState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FDFRSTATE$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "fdfrState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType xgetFdfrState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().find_element_user(FDFRSTATE$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "fdfrState" element
     */
    public boolean isNilFdfrState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().find_element_user(FDFRSTATE$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "fdfrState" element
     */
    public boolean isSetFdfrState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDFRSTATE$12) != 0;
        }
    }
    
    /**
     * Sets the "fdfrState" element
     */
    public void setFdfrState(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum fdfrState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FDFRSTATE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FDFRSTATE$12);
            }
            target.setEnumValue(fdfrState);
        }
    }
    
    /**
     * Sets (as xml) the "fdfrState" element
     */
    public void xsetFdfrState(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType fdfrState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().find_element_user(FDFRSTATE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().add_element_user(FDFRSTATE$12);
            }
            target.set(fdfrState);
        }
    }
    
    /**
     * Nils the "fdfrState" element
     */
    public void setNilFdfrState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().find_element_user(FDFRSTATE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType)get_store().add_element_user(FDFRSTATE$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "fdfrState" element
     */
    public void unsetFdfrState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDFRSTATE$12, 0);
        }
    }
    
    /**
     * Gets the "fdfrType" element
     */
    public java.lang.String getFdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FDFRTYPE$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "fdfrType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType xgetFdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().find_element_user(FDFRTYPE$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "fdfrType" element
     */
    public boolean isNilFdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().find_element_user(FDFRTYPE$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "fdfrType" element
     */
    public boolean isSetFdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDFRTYPE$14) != 0;
        }
    }
    
    /**
     * Sets the "fdfrType" element
     */
    public void setFdfrType(java.lang.String fdfrType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FDFRTYPE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FDFRTYPE$14);
            }
            target.setStringValue(fdfrType);
        }
    }
    
    /**
     * Sets (as xml) the "fdfrType" element
     */
    public void xsetFdfrType(org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType fdfrType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().find_element_user(FDFRTYPE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().add_element_user(FDFRTYPE$14);
            }
            target.set(fdfrType);
        }
    }
    
    /**
     * Nils the "fdfrType" element
     */
    public void setNilFdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().find_element_user(FDFRTYPE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType)get_store().add_element_user(FDFRTYPE$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "fdfrType" element
     */
    public void unsetFdfrType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDFRTYPE$14, 0);
        }
    }
}
