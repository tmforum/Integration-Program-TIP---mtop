/*
 * XML Type:  ConnectionTerminationPointListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ctp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ctp.v1.impl;
/**
 * An XML ConnectionTerminationPointListType(@http://www.tmforum.org/mtop/nrf/xsd/ctp/v1).
 *
 * This is a complex type.
 */
public class ConnectionTerminationPointListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointListType
{
    
    public ConnectionTerminationPointListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "ctp");
    
    
    /**
     * Gets a List of "ctp" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType> getCtpList()
    {
        final class CtpList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType>
        {
            public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType get(int i)
                { return ConnectionTerminationPointListTypeImpl.this.getCtpArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType set(int i, org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType o)
            {
                org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType old = ConnectionTerminationPointListTypeImpl.this.getCtpArray(i);
                ConnectionTerminationPointListTypeImpl.this.setCtpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType o)
                { ConnectionTerminationPointListTypeImpl.this.insertNewCtp(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType old = ConnectionTerminationPointListTypeImpl.this.getCtpArray(i);
                ConnectionTerminationPointListTypeImpl.this.removeCtp(i);
                return old;
            }
            
            public int size()
                { return ConnectionTerminationPointListTypeImpl.this.sizeOfCtpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CtpList();
        }
    }
    
    /**
     * Gets array of all "ctp" elements
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType[] getCtpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CTP$0, targetList);
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType[] result = new org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ctp" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType getCtpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().find_element_user(CTP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "ctp" element
     */
    public int sizeOfCtpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CTP$0);
        }
    }
    
    /**
     * Sets array of all "ctp" element
     */
    public void setCtpArray(org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType[] ctpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(ctpArray, CTP$0);
        }
    }
    
    /**
     * Sets ith "ctp" element
     */
    public void setCtpArray(int i, org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType ctp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().find_element_user(CTP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(ctp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ctp" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType insertNewCtp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().insert_element_user(CTP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ctp" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType addNewCtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().add_element_user(CTP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ctp" element
     */
    public void removeCtp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CTP$0, i);
        }
    }
}
