/*
 * XML Type:  ConnectionTerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ctp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ctp.v1.impl;
/**
 * An XML ConnectionTerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/ctp/v1).
 *
 * This is a complex type.
 */
public class ConnectionTerminationPointTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType
{
    
    public ConnectionTerminationPointTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "direction");
    private static final javax.xml.namespace.QName TPPROTECTIONASSOCIATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "tpProtectionAssociation");
    private static final javax.xml.namespace.QName EDGEPOINT$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "edgePoint");
    private static final javax.xml.namespace.QName EQUIPMENTPROTECTED$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "equipmentProtected");
    private static final javax.xml.namespace.QName EGRESSTMDSTATE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "egressTmdState");
    private static final javax.xml.namespace.QName INGRESSTMDSTATE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "ingressTmdState");
    private static final javax.xml.namespace.QName CONNECTIONSTATE$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "connectionState");
    private static final javax.xml.namespace.QName TPMAPPINGMODE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "tpMappingMode");
    private static final javax.xml.namespace.QName INGRESSTRANSMISSIONDESCRIPTORNAME$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "ingressTransmissionDescriptorName");
    private static final javax.xml.namespace.QName EGRESSTRANSMISSIONDESCRIPTORNAME$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "egressTransmissionDescriptorName");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMS$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "transmissionParams");
    private static final javax.xml.namespace.QName CLIENTCONNECTIVITY$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "clientConnectivity");
    private static final javax.xml.namespace.QName SERVERCONNECTIVITY$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "serverConnectivity");
    private static final javax.xml.namespace.QName CONFORMANCEDEFINITION$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "conformanceDefinition");
    private static final javax.xml.namespace.QName SERVICECATEGORY$28 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "serviceCategory");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$0) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().add_element_user(DIRECTION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$0, 0);
        }
    }
    
    /**
     * Gets the "tpProtectionAssociation" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType.Enum getTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpProtectionAssociation" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType xgetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "tpProtectionAssociation" element
     */
    public boolean isNilTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpProtectionAssociation" element
     */
    public boolean isSetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPPROTECTIONASSOCIATION$2) != 0;
        }
    }
    
    /**
     * Sets the "tpProtectionAssociation" element
     */
    public void setTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType.Enum tpProtectionAssociation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.setEnumValue(tpProtectionAssociation);
        }
    }
    
    /**
     * Sets (as xml) the "tpProtectionAssociation" element
     */
    public void xsetTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType tpProtectionAssociation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.set(tpProtectionAssociation);
        }
    }
    
    /**
     * Nils the "tpProtectionAssociation" element
     */
    public void setNilTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpProtectionAssociationType)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpProtectionAssociation" element
     */
    public void unsetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPPROTECTIONASSOCIATION$2, 0);
        }
    }
    
    /**
     * Gets the "edgePoint" element
     */
    public boolean getEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "edgePoint" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINT$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "edgePoint" element
     */
    public boolean isNilEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "edgePoint" element
     */
    public boolean isSetEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EDGEPOINT$4) != 0;
        }
    }
    
    /**
     * Sets the "edgePoint" element
     */
    public void setEdgePoint(boolean edgePoint)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EDGEPOINT$4);
            }
            target.setBooleanValue(edgePoint);
        }
    }
    
    /**
     * Sets (as xml) the "edgePoint" element
     */
    public void xsetEdgePoint(org.apache.xmlbeans.XmlBoolean edgePoint)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EDGEPOINT$4);
            }
            target.set(edgePoint);
        }
    }
    
    /**
     * Nils the "edgePoint" element
     */
    public void setNilEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EDGEPOINT$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "edgePoint" element
     */
    public void unsetEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EDGEPOINT$4, 0);
        }
    }
    
    /**
     * Gets the "equipmentProtected" element
     */
    public boolean getEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "equipmentProtected" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "equipmentProtected" element
     */
    public boolean isNilEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "equipmentProtected" element
     */
    public boolean isSetEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQUIPMENTPROTECTED$6) != 0;
        }
    }
    
    /**
     * Sets the "equipmentProtected" element
     */
    public void setEquipmentProtected(boolean equipmentProtected)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EQUIPMENTPROTECTED$6);
            }
            target.setBooleanValue(equipmentProtected);
        }
    }
    
    /**
     * Sets (as xml) the "equipmentProtected" element
     */
    public void xsetEquipmentProtected(org.apache.xmlbeans.XmlBoolean equipmentProtected)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EQUIPMENTPROTECTED$6);
            }
            target.set(equipmentProtected);
        }
    }
    
    /**
     * Nils the "equipmentProtected" element
     */
    public void setNilEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EQUIPMENTPROTECTED$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "equipmentProtected" element
     */
    public void unsetEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQUIPMENTPROTECTED$6, 0);
        }
    }
    
    /**
     * Gets the "egressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum getEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "egressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType xgetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "egressTmdState" element
     */
    public boolean isNilEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "egressTmdState" element
     */
    public boolean isSetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EGRESSTMDSTATE$8) != 0;
        }
    }
    
    /**
     * Sets the "egressTmdState" element
     */
    public void setEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum egressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.setEnumValue(egressTmdState);
        }
    }
    
    /**
     * Sets (as xml) the "egressTmdState" element
     */
    public void xsetEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType egressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.set(egressTmdState);
        }
    }
    
    /**
     * Nils the "egressTmdState" element
     */
    public void setNilEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "egressTmdState" element
     */
    public void unsetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EGRESSTMDSTATE$8, 0);
        }
    }
    
    /**
     * Gets the "ingressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum getIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "ingressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType xgetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ingressTmdState" element
     */
    public boolean isNilIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ingressTmdState" element
     */
    public boolean isSetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INGRESSTMDSTATE$10) != 0;
        }
    }
    
    /**
     * Sets the "ingressTmdState" element
     */
    public void setIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType.Enum ingressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.setEnumValue(ingressTmdState);
        }
    }
    
    /**
     * Sets (as xml) the "ingressTmdState" element
     */
    public void xsetIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType ingressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.set(ingressTmdState);
        }
    }
    
    /**
     * Nils the "ingressTmdState" element
     */
    public void setNilIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TmdStateType)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ingressTmdState" element
     */
    public void unsetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INGRESSTMDSTATE$10, 0);
        }
    }
    
    /**
     * Gets the "connectionState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.Enum getConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "connectionState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType xgetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "connectionState" element
     */
    public boolean isNilConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "connectionState" element
     */
    public boolean isSetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIONSTATE$12) != 0;
        }
    }
    
    /**
     * Sets the "connectionState" element
     */
    public void setConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.Enum connectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONNECTIONSTATE$12);
            }
            target.setEnumValue(connectionState);
        }
    }
    
    /**
     * Sets (as xml) the "connectionState" element
     */
    public void xsetConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType connectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().add_element_user(CONNECTIONSTATE$12);
            }
            target.set(connectionState);
        }
    }
    
    /**
     * Nils the "connectionState" element
     */
    public void setNilConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().add_element_user(CONNECTIONSTATE$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "connectionState" element
     */
    public void unsetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIONSTATE$12, 0);
        }
    }
    
    /**
     * Gets the "tpMappingMode" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum getTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpMappingMode" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType xgetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "tpMappingMode" element
     */
    public boolean isNilTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpMappingMode" element
     */
    public boolean isSetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPMAPPINGMODE$14) != 0;
        }
    }
    
    /**
     * Sets the "tpMappingMode" element
     */
    public void setTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum tpMappingMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPMAPPINGMODE$14);
            }
            target.setEnumValue(tpMappingMode);
        }
    }
    
    /**
     * Sets (as xml) the "tpMappingMode" element
     */
    public void xsetTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType tpMappingMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().add_element_user(TPMAPPINGMODE$14);
            }
            target.set(tpMappingMode);
        }
    }
    
    /**
     * Nils the "tpMappingMode" element
     */
    public void setNilTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().add_element_user(TPMAPPINGMODE$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpMappingMode" element
     */
    public void unsetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPMAPPINGMODE$14, 0);
        }
    }
    
    /**
     * Gets the "ingressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ingressTransmissionDescriptorName" element
     */
    public boolean isNilIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ingressTransmissionDescriptorName" element
     */
    public boolean isSetIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INGRESSTRANSMISSIONDESCRIPTORNAME$16) != 0;
        }
    }
    
    /**
     * Sets the "ingressTransmissionDescriptorName" element
     */
    public void setIngressTransmissionDescriptorName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType ingressTransmissionDescriptorName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$16);
            }
            target.set(ingressTransmissionDescriptorName);
        }
    }
    
    /**
     * Appends and returns a new empty "ingressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$16);
            return target;
        }
    }
    
    /**
     * Nils the "ingressTransmissionDescriptorName" element
     */
    public void setNilIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INGRESSTRANSMISSIONDESCRIPTORNAME$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ingressTransmissionDescriptorName" element
     */
    public void unsetIngressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INGRESSTRANSMISSIONDESCRIPTORNAME$16, 0);
        }
    }
    
    /**
     * Gets the "egressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "egressTransmissionDescriptorName" element
     */
    public boolean isNilEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "egressTransmissionDescriptorName" element
     */
    public boolean isSetEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EGRESSTRANSMISSIONDESCRIPTORNAME$18) != 0;
        }
    }
    
    /**
     * Sets the "egressTransmissionDescriptorName" element
     */
    public void setEgressTransmissionDescriptorName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType egressTransmissionDescriptorName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$18);
            }
            target.set(egressTransmissionDescriptorName);
        }
    }
    
    /**
     * Appends and returns a new empty "egressTransmissionDescriptorName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$18);
            return target;
        }
    }
    
    /**
     * Nils the "egressTransmissionDescriptorName" element
     */
    public void setNilEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EGRESSTRANSMISSIONDESCRIPTORNAME$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "egressTransmissionDescriptorName" element
     */
    public void unsetEgressTransmissionDescriptorName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EGRESSTRANSMISSIONDESCRIPTORNAME$18, 0);
        }
    }
    
    /**
     * Gets the "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParams" element
     */
    public boolean isNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParams" element
     */
    public boolean isSetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMS$20) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParams" element
     */
    public void setTransmissionParams(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParams)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$20);
            }
            target.set(transmissionParams);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$20);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParams" element
     */
    public void setNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParams" element
     */
    public void unsetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMS$20, 0);
        }
    }
    
    /**
     * Gets the "clientConnectivity" element
     */
    public java.lang.String getClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLIENTCONNECTIVITY$22, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "clientConnectivity" element
     */
    public org.apache.xmlbeans.XmlString xgetClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLIENTCONNECTIVITY$22, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "clientConnectivity" element
     */
    public boolean isNilClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLIENTCONNECTIVITY$22, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "clientConnectivity" element
     */
    public boolean isSetClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CLIENTCONNECTIVITY$22) != 0;
        }
    }
    
    /**
     * Sets the "clientConnectivity" element
     */
    public void setClientConnectivity(java.lang.String clientConnectivity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CLIENTCONNECTIVITY$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CLIENTCONNECTIVITY$22);
            }
            target.setStringValue(clientConnectivity);
        }
    }
    
    /**
     * Sets (as xml) the "clientConnectivity" element
     */
    public void xsetClientConnectivity(org.apache.xmlbeans.XmlString clientConnectivity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLIENTCONNECTIVITY$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CLIENTCONNECTIVITY$22);
            }
            target.set(clientConnectivity);
        }
    }
    
    /**
     * Nils the "clientConnectivity" element
     */
    public void setNilClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CLIENTCONNECTIVITY$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CLIENTCONNECTIVITY$22);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "clientConnectivity" element
     */
    public void unsetClientConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CLIENTCONNECTIVITY$22, 0);
        }
    }
    
    /**
     * Gets the "serverConnectivity" element
     */
    public java.lang.String getServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVERCONNECTIVITY$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serverConnectivity" element
     */
    public org.apache.xmlbeans.XmlString xgetServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVERCONNECTIVITY$24, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "serverConnectivity" element
     */
    public boolean isNilServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVERCONNECTIVITY$24, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "serverConnectivity" element
     */
    public boolean isSetServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVERCONNECTIVITY$24) != 0;
        }
    }
    
    /**
     * Sets the "serverConnectivity" element
     */
    public void setServerConnectivity(java.lang.String serverConnectivity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVERCONNECTIVITY$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVERCONNECTIVITY$24);
            }
            target.setStringValue(serverConnectivity);
        }
    }
    
    /**
     * Sets (as xml) the "serverConnectivity" element
     */
    public void xsetServerConnectivity(org.apache.xmlbeans.XmlString serverConnectivity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVERCONNECTIVITY$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVERCONNECTIVITY$24);
            }
            target.set(serverConnectivity);
        }
    }
    
    /**
     * Nils the "serverConnectivity" element
     */
    public void setNilServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVERCONNECTIVITY$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVERCONNECTIVITY$24);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "serverConnectivity" element
     */
    public void unsetServerConnectivity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVERCONNECTIVITY$24, 0);
        }
    }
    
    /**
     * Gets the "conformanceDefinition" element
     */
    public java.lang.String getConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONFORMANCEDEFINITION$26, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "conformanceDefinition" element
     */
    public org.apache.xmlbeans.XmlString xgetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$26, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "conformanceDefinition" element
     */
    public boolean isNilConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$26, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "conformanceDefinition" element
     */
    public boolean isSetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONFORMANCEDEFINITION$26) != 0;
        }
    }
    
    /**
     * Sets the "conformanceDefinition" element
     */
    public void setConformanceDefinition(java.lang.String conformanceDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONFORMANCEDEFINITION$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONFORMANCEDEFINITION$26);
            }
            target.setStringValue(conformanceDefinition);
        }
    }
    
    /**
     * Sets (as xml) the "conformanceDefinition" element
     */
    public void xsetConformanceDefinition(org.apache.xmlbeans.XmlString conformanceDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONFORMANCEDEFINITION$26);
            }
            target.set(conformanceDefinition);
        }
    }
    
    /**
     * Nils the "conformanceDefinition" element
     */
    public void setNilConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONFORMANCEDEFINITION$26);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "conformanceDefinition" element
     */
    public void unsetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONFORMANCEDEFINITION$26, 0);
        }
    }
    
    /**
     * Gets the "serviceCategory" element
     */
    public java.lang.String getServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICECATEGORY$28, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceCategory" element
     */
    public org.apache.xmlbeans.XmlString xgetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$28, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "serviceCategory" element
     */
    public boolean isNilServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$28, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "serviceCategory" element
     */
    public boolean isSetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICECATEGORY$28) != 0;
        }
    }
    
    /**
     * Sets the "serviceCategory" element
     */
    public void setServiceCategory(java.lang.String serviceCategory)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICECATEGORY$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICECATEGORY$28);
            }
            target.setStringValue(serviceCategory);
        }
    }
    
    /**
     * Sets (as xml) the "serviceCategory" element
     */
    public void xsetServiceCategory(org.apache.xmlbeans.XmlString serviceCategory)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICECATEGORY$28);
            }
            target.set(serviceCategory);
        }
    }
    
    /**
     * Nils the "serviceCategory" element
     */
    public void setNilServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICECATEGORY$28);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "serviceCategory" element
     */
    public void unsetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICECATEGORY$28, 0);
        }
    }
}
