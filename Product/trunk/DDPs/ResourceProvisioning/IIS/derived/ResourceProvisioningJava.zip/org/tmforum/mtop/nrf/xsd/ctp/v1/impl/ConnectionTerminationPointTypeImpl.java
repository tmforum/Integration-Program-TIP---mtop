/*
 * XML Type:  ConnectionTerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ctp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ctp.v1.impl;
/**
 * An XML ConnectionTerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/ctp/v1).
 *
 * This is a complex type.
 */
public class ConnectionTerminationPointTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType
{
    
    public ConnectionTerminationPointTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "direction");
    private static final javax.xml.namespace.QName TPPROTECTIONASSOCIATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "tpProtectionAssociation");
    private static final javax.xml.namespace.QName ISEDGEPOINT$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "isEdgePoint");
    private static final javax.xml.namespace.QName ISEQUIPMENTPROTECTED$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "isEquipmentProtected");
    private static final javax.xml.namespace.QName EGRESSTMDSTATE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "egressTmdState");
    private static final javax.xml.namespace.QName INGRESSTMDSTATE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "ingressTmdState");
    private static final javax.xml.namespace.QName CONNECTIONSTATE$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "connectionState");
    private static final javax.xml.namespace.QName TPMAPPINGMODE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "tpMappingMode");
    private static final javax.xml.namespace.QName INGRESSTMDREF$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "ingressTmdRef");
    private static final javax.xml.namespace.QName EGRESSTMDREF$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "egressTmdRef");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMETERLIST$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "transmissionParameterList");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$0) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.DirectionalityType)get_store().add_element_user(DIRECTION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$0, 0);
        }
    }
    
    /**
     * Gets the "tpProtectionAssociation" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType.Enum getTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpProtectionAssociation" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType xgetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "tpProtectionAssociation" element
     */
    public boolean isNilTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpProtectionAssociation" element
     */
    public boolean isSetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPPROTECTIONASSOCIATION$2) != 0;
        }
    }
    
    /**
     * Sets the "tpProtectionAssociation" element
     */
    public void setTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType.Enum tpProtectionAssociation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.setEnumValue(tpProtectionAssociation);
        }
    }
    
    /**
     * Sets (as xml) the "tpProtectionAssociation" element
     */
    public void xsetTpProtectionAssociation(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType tpProtectionAssociation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.set(tpProtectionAssociation);
        }
    }
    
    /**
     * Nils the "tpProtectionAssociation" element
     */
    public void setNilTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType)get_store().find_element_user(TPPROTECTIONASSOCIATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointProtectionAssociationType)get_store().add_element_user(TPPROTECTIONASSOCIATION$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpProtectionAssociation" element
     */
    public void unsetTpProtectionAssociation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPPROTECTIONASSOCIATION$2, 0);
        }
    }
    
    /**
     * Gets the "isEdgePoint" element
     */
    public boolean getIsEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEDGEPOINT$4, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isEdgePoint" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINT$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isEdgePoint" element
     */
    public boolean isNilIsEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINT$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isEdgePoint" element
     */
    public boolean isSetIsEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISEDGEPOINT$4) != 0;
        }
    }
    
    /**
     * Sets the "isEdgePoint" element
     */
    public void setIsEdgePoint(boolean isEdgePoint)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISEDGEPOINT$4);
            }
            target.setBooleanValue(isEdgePoint);
        }
    }
    
    /**
     * Sets (as xml) the "isEdgePoint" element
     */
    public void xsetIsEdgePoint(org.apache.xmlbeans.XmlBoolean isEdgePoint)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISEDGEPOINT$4);
            }
            target.set(isEdgePoint);
        }
    }
    
    /**
     * Nils the "isEdgePoint" element
     */
    public void setNilIsEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISEDGEPOINT$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isEdgePoint" element
     */
    public void unsetIsEdgePoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISEDGEPOINT$4, 0);
        }
    }
    
    /**
     * Gets the "isEquipmentProtected" element
     */
    public boolean getIsEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isEquipmentProtected" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEQUIPMENTPROTECTED$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isEquipmentProtected" element
     */
    public boolean isNilIsEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEQUIPMENTPROTECTED$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isEquipmentProtected" element
     */
    public boolean isSetIsEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISEQUIPMENTPROTECTED$6) != 0;
        }
    }
    
    /**
     * Sets the "isEquipmentProtected" element
     */
    public void setIsEquipmentProtected(boolean isEquipmentProtected)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISEQUIPMENTPROTECTED$6);
            }
            target.setBooleanValue(isEquipmentProtected);
        }
    }
    
    /**
     * Sets (as xml) the "isEquipmentProtected" element
     */
    public void xsetIsEquipmentProtected(org.apache.xmlbeans.XmlBoolean isEquipmentProtected)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISEQUIPMENTPROTECTED$6);
            }
            target.set(isEquipmentProtected);
        }
    }
    
    /**
     * Nils the "isEquipmentProtected" element
     */
    public void setNilIsEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEQUIPMENTPROTECTED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISEQUIPMENTPROTECTED$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isEquipmentProtected" element
     */
    public void unsetIsEquipmentProtected()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISEQUIPMENTPROTECTED$6, 0);
        }
    }
    
    /**
     * Gets the "egressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum getEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "egressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType xgetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "egressTmdState" element
     */
    public boolean isNilEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "egressTmdState" element
     */
    public boolean isSetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EGRESSTMDSTATE$8) != 0;
        }
    }
    
    /**
     * Sets the "egressTmdState" element
     */
    public void setEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum egressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.setEnumValue(egressTmdState);
        }
    }
    
    /**
     * Sets (as xml) the "egressTmdState" element
     */
    public void xsetEgressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType egressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.set(egressTmdState);
        }
    }
    
    /**
     * Nils the "egressTmdState" element
     */
    public void setNilEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().find_element_user(EGRESSTMDSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().add_element_user(EGRESSTMDSTATE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "egressTmdState" element
     */
    public void unsetEgressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EGRESSTMDSTATE$8, 0);
        }
    }
    
    /**
     * Gets the "ingressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum getIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "ingressTmdState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType xgetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "ingressTmdState" element
     */
    public boolean isNilIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ingressTmdState" element
     */
    public boolean isSetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INGRESSTMDSTATE$10) != 0;
        }
    }
    
    /**
     * Sets the "ingressTmdState" element
     */
    public void setIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.Enum ingressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.setEnumValue(ingressTmdState);
        }
    }
    
    /**
     * Sets (as xml) the "ingressTmdState" element
     */
    public void xsetIngressTmdState(org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType ingressTmdState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.set(ingressTmdState);
        }
    }
    
    /**
     * Nils the "ingressTmdState" element
     */
    public void setNilIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().find_element_user(INGRESSTMDSTATE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType)get_store().add_element_user(INGRESSTMDSTATE$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ingressTmdState" element
     */
    public void unsetIngressTmdState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INGRESSTMDSTATE$10, 0);
        }
    }
    
    /**
     * Gets the "connectionState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum getConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "connectionState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType xgetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "connectionState" element
     */
    public boolean isNilConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "connectionState" element
     */
    public boolean isSetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIONSTATE$12) != 0;
        }
    }
    
    /**
     * Sets the "connectionState" element
     */
    public void setConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum connectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONNECTIONSTATE$12);
            }
            target.setEnumValue(connectionState);
        }
    }
    
    /**
     * Sets (as xml) the "connectionState" element
     */
    public void xsetConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType connectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().add_element_user(CONNECTIONSTATE$12);
            }
            target.set(connectionState);
        }
    }
    
    /**
     * Nils the "connectionState" element
     */
    public void setNilConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().add_element_user(CONNECTIONSTATE$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "connectionState" element
     */
    public void unsetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIONSTATE$12, 0);
        }
    }
    
    /**
     * Gets the "tpMappingMode" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum getTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "tpMappingMode" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType xgetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "tpMappingMode" element
     */
    public boolean isNilTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpMappingMode" element
     */
    public boolean isSetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPMAPPINGMODE$14) != 0;
        }
    }
    
    /**
     * Sets the "tpMappingMode" element
     */
    public void setTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum tpMappingMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPMAPPINGMODE$14);
            }
            target.setEnumValue(tpMappingMode);
        }
    }
    
    /**
     * Sets (as xml) the "tpMappingMode" element
     */
    public void xsetTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType tpMappingMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().add_element_user(TPMAPPINGMODE$14);
            }
            target.set(tpMappingMode);
        }
    }
    
    /**
     * Nils the "tpMappingMode" element
     */
    public void setNilTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().find_element_user(TPMAPPINGMODE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType)get_store().add_element_user(TPMAPPINGMODE$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpMappingMode" element
     */
    public void unsetTpMappingMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPMAPPINGMODE$14, 0);
        }
    }
    
    /**
     * Gets the "ingressTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INGRESSTMDREF$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "ingressTmdRef" element
     */
    public boolean isNilIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INGRESSTMDREF$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "ingressTmdRef" element
     */
    public boolean isSetIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INGRESSTMDREF$16) != 0;
        }
    }
    
    /**
     * Sets the "ingressTmdRef" element
     */
    public void setIngressTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType ingressTmdRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INGRESSTMDREF$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(INGRESSTMDREF$16);
            }
            target.set(ingressTmdRef);
        }
    }
    
    /**
     * Appends and returns a new empty "ingressTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(INGRESSTMDREF$16);
            return target;
        }
    }
    
    /**
     * Nils the "ingressTmdRef" element
     */
    public void setNilIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INGRESSTMDREF$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(INGRESSTMDREF$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "ingressTmdRef" element
     */
    public void unsetIngressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INGRESSTMDREF$16, 0);
        }
    }
    
    /**
     * Gets the "egressTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EGRESSTMDREF$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "egressTmdRef" element
     */
    public boolean isNilEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EGRESSTMDREF$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "egressTmdRef" element
     */
    public boolean isSetEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EGRESSTMDREF$18) != 0;
        }
    }
    
    /**
     * Sets the "egressTmdRef" element
     */
    public void setEgressTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType egressTmdRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EGRESSTMDREF$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EGRESSTMDREF$18);
            }
            target.set(egressTmdRef);
        }
    }
    
    /**
     * Appends and returns a new empty "egressTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EGRESSTMDREF$18);
            return target;
        }
    }
    
    /**
     * Nils the "egressTmdRef" element
     */
    public void setNilEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EGRESSTMDREF$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EGRESSTMDREF$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "egressTmdRef" element
     */
    public void unsetEgressTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EGRESSTMDREF$18, 0);
        }
    }
    
    /**
     * Gets the "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    public boolean isNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$20, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParameterList" element
     */
    public boolean isSetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMETERLIST$20) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParameterList" element
     */
    public void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$20);
            }
            target.set(transmissionParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$20);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParameterList" element
     */
    public void setNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$20);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    public void unsetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMETERLIST$20, 0);
        }
    }
}
