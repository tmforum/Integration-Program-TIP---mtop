/*
 * An XML document type.
 * Localname: mfd
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mfd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mfd.v1.MfdDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mfd.v1.impl;
/**
 * A document containing one mfd(@http://www.tmforum.org/mtop/nrf/xsd/mfd/v1) element.
 *
 * This is a complex type.
 */
public class MfdDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.mfd.v1.MfdDocument
{
    
    public MfdDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MFD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfd/v1", "mfd");
    
    
    /**
     * Gets the "mfd" element
     */
    public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType getMfd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "mfd" element
     */
    public void setMfd(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType mfd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
            }
            target.set(mfd);
        }
    }
    
    /**
     * Appends and returns a new empty "mfd" element
     */
    public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType addNewMfd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
            return target;
        }
    }
}
