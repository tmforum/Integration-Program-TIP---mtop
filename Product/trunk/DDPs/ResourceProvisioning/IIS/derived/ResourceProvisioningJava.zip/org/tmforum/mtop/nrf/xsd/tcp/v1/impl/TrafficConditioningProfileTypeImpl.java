/*
 * XML Type:  TrafficConditioningProfileType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tcp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tcp.v1.impl;
/**
 * An XML TrafficConditioningProfileType(@http://www.tmforum.org/mtop/nrf/xsd/tcp/v1).
 *
 * This is a complex type.
 */
public class TrafficConditioningProfileTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.tcp.v1.TrafficConditioningProfileType
{
    
    public TrafficConditioningProfileTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ISDEFAULTPROFILE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tcp/v1", "isDefaultProfile");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMETERLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tcp/v1", "transmissionParameterList");
    
    
    /**
     * Gets the "isDefaultProfile" element
     */
    public boolean getIsDefaultProfile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISDEFAULTPROFILE$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isDefaultProfile" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsDefaultProfile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISDEFAULTPROFILE$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isDefaultProfile" element
     */
    public boolean isNilIsDefaultProfile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISDEFAULTPROFILE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isDefaultProfile" element
     */
    public boolean isSetIsDefaultProfile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISDEFAULTPROFILE$0) != 0;
        }
    }
    
    /**
     * Sets the "isDefaultProfile" element
     */
    public void setIsDefaultProfile(boolean isDefaultProfile)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISDEFAULTPROFILE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISDEFAULTPROFILE$0);
            }
            target.setBooleanValue(isDefaultProfile);
        }
    }
    
    /**
     * Sets (as xml) the "isDefaultProfile" element
     */
    public void xsetIsDefaultProfile(org.apache.xmlbeans.XmlBoolean isDefaultProfile)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISDEFAULTPROFILE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISDEFAULTPROFILE$0);
            }
            target.set(isDefaultProfile);
        }
    }
    
    /**
     * Nils the "isDefaultProfile" element
     */
    public void setNilIsDefaultProfile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISDEFAULTPROFILE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISDEFAULTPROFILE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isDefaultProfile" element
     */
    public void unsetIsDefaultProfile()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISDEFAULTPROFILE$0, 0);
        }
    }
    
    /**
     * Gets the "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    public boolean isNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParameterList" element
     */
    public boolean isSetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMETERLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParameterList" element
     */
    public void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            }
            target.set(transmissionParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParameterList" element
     */
    public void setNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    public void unsetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMETERLIST$2, 0);
        }
    }
}
