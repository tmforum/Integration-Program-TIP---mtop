/*
 * XML Type:  RouteDescriptorType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/routedes/v1
 * Java type: org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.routedes.v1.impl;
/**
 * An XML RouteDescriptorType(@http://www.tmforum.org/mtop/nrf/xsd/routedes/v1).
 *
 * This is a complex type.
 */
public class RouteDescriptorTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.routedes.v1.RouteDescriptorType
{
    
    public RouteDescriptorTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "id");
    private static final javax.xml.namespace.QName INTENDED$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "intended");
    private static final javax.xml.namespace.QName ACTUALSTATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "actualState");
    private static final javax.xml.namespace.QName ADMINISTRATIVESTATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "administrativeState");
    private static final javax.xml.namespace.QName INUSEBY$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "inUseBy");
    private static final javax.xml.namespace.QName EXCLUSIVE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "exclusive");
    private static final javax.xml.namespace.QName ROUTEXCS$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "routeXCs");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routedes/v1", "vendorExtensions");
    
    
    /**
     * Gets the "id" element
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "id" element
     */
    public org.apache.xmlbeans.XmlString xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "id" element
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ID$0) != 0;
        }
    }
    
    /**
     * Sets the "id" element
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ID$0);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "id" element
     */
    public void xsetId(org.apache.xmlbeans.XmlString id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ID$0);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "id" element
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ID$0, 0);
        }
    }
    
    /**
     * Gets the "intended" element
     */
    public java.lang.String getIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDED$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "intended" element
     */
    public org.apache.xmlbeans.XmlString xgetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDED$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "intended" element
     */
    public boolean isSetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTENDED$2) != 0;
        }
    }
    
    /**
     * Sets the "intended" element
     */
    public void setIntended(java.lang.String intended)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDED$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTENDED$2);
            }
            target.setStringValue(intended);
        }
    }
    
    /**
     * Sets (as xml) the "intended" element
     */
    public void xsetIntended(org.apache.xmlbeans.XmlString intended)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDED$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INTENDED$2);
            }
            target.set(intended);
        }
    }
    
    /**
     * Unsets the "intended" element
     */
    public void unsetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTENDED$2, 0);
        }
    }
    
    /**
     * Gets the "actualState" element
     */
    public java.lang.String getActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTUALSTATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "actualState" element
     */
    public org.apache.xmlbeans.XmlString xgetActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ACTUALSTATE$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "actualState" element
     */
    public boolean isSetActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACTUALSTATE$4) != 0;
        }
    }
    
    /**
     * Sets the "actualState" element
     */
    public void setActualState(java.lang.String actualState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTUALSTATE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACTUALSTATE$4);
            }
            target.setStringValue(actualState);
        }
    }
    
    /**
     * Sets (as xml) the "actualState" element
     */
    public void xsetActualState(org.apache.xmlbeans.XmlString actualState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ACTUALSTATE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ACTUALSTATE$4);
            }
            target.set(actualState);
        }
    }
    
    /**
     * Unsets the "actualState" element
     */
    public void unsetActualState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACTUALSTATE$4, 0);
        }
    }
    
    /**
     * Gets the "administrativeState" element
     */
    public java.lang.String getAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADMINISTRATIVESTATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "administrativeState" element
     */
    public org.apache.xmlbeans.XmlString xgetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ADMINISTRATIVESTATE$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "administrativeState" element
     */
    public boolean isSetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ADMINISTRATIVESTATE$6) != 0;
        }
    }
    
    /**
     * Sets the "administrativeState" element
     */
    public void setAdministrativeState(java.lang.String administrativeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADMINISTRATIVESTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ADMINISTRATIVESTATE$6);
            }
            target.setStringValue(administrativeState);
        }
    }
    
    /**
     * Sets (as xml) the "administrativeState" element
     */
    public void xsetAdministrativeState(org.apache.xmlbeans.XmlString administrativeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ADMINISTRATIVESTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ADMINISTRATIVESTATE$6);
            }
            target.set(administrativeState);
        }
    }
    
    /**
     * Unsets the "administrativeState" element
     */
    public void unsetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ADMINISTRATIVESTATE$6, 0);
        }
    }
    
    /**
     * Gets the "inUseBy" element
     */
    public java.lang.String getInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INUSEBY$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "inUseBy" element
     */
    public org.apache.xmlbeans.XmlString xgetInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INUSEBY$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "inUseBy" element
     */
    public boolean isSetInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INUSEBY$8) != 0;
        }
    }
    
    /**
     * Sets the "inUseBy" element
     */
    public void setInUseBy(java.lang.String inUseBy)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INUSEBY$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INUSEBY$8);
            }
            target.setStringValue(inUseBy);
        }
    }
    
    /**
     * Sets (as xml) the "inUseBy" element
     */
    public void xsetInUseBy(org.apache.xmlbeans.XmlString inUseBy)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INUSEBY$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INUSEBY$8);
            }
            target.set(inUseBy);
        }
    }
    
    /**
     * Unsets the "inUseBy" element
     */
    public void unsetInUseBy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INUSEBY$8, 0);
        }
    }
    
    /**
     * Gets the "exclusive" element
     */
    public java.lang.String getExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXCLUSIVE$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "exclusive" element
     */
    public org.apache.xmlbeans.XmlString xgetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXCLUSIVE$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "exclusive" element
     */
    public boolean isSetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXCLUSIVE$10) != 0;
        }
    }
    
    /**
     * Sets the "exclusive" element
     */
    public void setExclusive(java.lang.String exclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXCLUSIVE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXCLUSIVE$10);
            }
            target.setStringValue(exclusive);
        }
    }
    
    /**
     * Sets (as xml) the "exclusive" element
     */
    public void xsetExclusive(org.apache.xmlbeans.XmlString exclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXCLUSIVE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EXCLUSIVE$10);
            }
            target.set(exclusive);
        }
    }
    
    /**
     * Unsets the "exclusive" element
     */
    public void unsetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXCLUSIVE$10, 0);
        }
    }
    
    /**
     * Gets the "routeXCs" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType getRouteXCs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTEXCS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "routeXCs" element
     */
    public boolean isSetRouteXCs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEXCS$12) != 0;
        }
    }
    
    /**
     * Sets the "routeXCs" element
     */
    public void setRouteXCs(org.tmforum.mtop.nrf.xsd.route.v1.RouteType routeXCs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTEXCS$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTEXCS$12);
            }
            target.set(routeXCs);
        }
    }
    
    /**
     * Appends and returns a new empty "routeXCs" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType addNewRouteXCs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTEXCS$12);
            return target;
        }
    }
    
    /**
     * Unsets the "routeXCs" element
     */
    public void unsetRouteXCs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEXCS$12, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$14) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$14);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$14);
            return target;
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$14, 0);
        }
    }
}
