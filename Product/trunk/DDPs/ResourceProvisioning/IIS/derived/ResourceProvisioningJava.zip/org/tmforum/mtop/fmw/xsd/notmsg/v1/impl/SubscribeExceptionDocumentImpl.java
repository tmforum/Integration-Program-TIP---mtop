/*
 * An XML document type.
 * Localname: subscribeException
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * A document containing one subscribeException(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1) element.
 *
 * This is a complex type.
 */
public class SubscribeExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument
{
    
    public SubscribeExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SUBSCRIBEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "subscribeException");
    
    
    /**
     * Gets the "subscribeException" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException getSubscribeException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException)get_store().find_element_user(SUBSCRIBEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "subscribeException" element
     */
    public void setSubscribeException(org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException subscribeException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException)get_store().find_element_user(SUBSCRIBEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException)get_store().add_element_user(SUBSCRIBEEXCEPTION$0);
            }
            target.set(subscribeException);
        }
    }
    
    /**
     * Appends and returns a new empty "subscribeException" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException addNewSubscribeException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException)get_store().add_element_user(SUBSCRIBEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML subscribeException(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public static class SubscribeExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeExceptionDocument.SubscribeException
    {
        
        public SubscribeExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
