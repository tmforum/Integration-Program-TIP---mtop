/*
 * An XML document type.
 * Localname: backupStatus
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/bs/v1
 * Java type: org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.bs.v1.impl;
/**
 * A document containing one backupStatus(@http://www.tmforum.org/mtop/rp/xsd/bs/v1) element.
 *
 * This is a complex type.
 */
public class BackupStatusDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusDocument
{
    
    public BackupStatusDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName BACKUPSTATUS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/bs/v1", "backupStatus");
    
    
    /**
     * Gets the "backupStatus" element
     */
    public org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType getBackupStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType)get_store().find_element_user(BACKUPSTATUS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "backupStatus" element
     */
    public void setBackupStatus(org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType backupStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType)get_store().find_element_user(BACKUPSTATUS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType)get_store().add_element_user(BACKUPSTATUS$0);
            }
            target.set(backupStatus);
        }
    }
    
    /**
     * Appends and returns a new empty "backupStatus" element
     */
    public org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType addNewBackupStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType target = null;
            target = (org.tmforum.mtop.rp.xsd.bs.v1.BackupStatusType)get_store().add_element_user(BACKUPSTATUS$0);
            return target;
        }
    }
}
