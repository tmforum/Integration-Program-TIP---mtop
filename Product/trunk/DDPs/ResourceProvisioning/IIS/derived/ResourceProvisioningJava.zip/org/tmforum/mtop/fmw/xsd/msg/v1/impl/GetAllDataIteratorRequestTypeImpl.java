/*
 * XML Type:  GetAllDataIteratorRequestType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * An XML GetAllDataIteratorRequestType(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1).
 *
 * This is a complex type.
 */
public class GetAllDataIteratorRequestTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType
{
    
    public GetAllDataIteratorRequestTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
