/*
 * An XML document type.
 * Localname: tl
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tl/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tl.v1.TlDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tl.v1.impl;
/**
 * A document containing one tl(@http://www.tmforum.org/mtop/nrf/xsd/tl/v1) element.
 *
 * This is a complex type.
 */
public class TlDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tl.v1.TlDocument
{
    
    public TlDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TL$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "tl");
    
    
    /**
     * Gets the "tl" element
     */
    public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType getTl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().find_element_user(TL$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tl" element
     */
    public void setTl(org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType tl)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().find_element_user(TL$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().add_element_user(TL$0);
            }
            target.set(tl);
        }
    }
    
    /**
     * Appends and returns a new empty "tl" element
     */
    public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType addNewTl()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().add_element_user(TL$0);
            return target;
        }
    }
}
