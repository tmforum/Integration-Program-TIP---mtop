/*
 * XML Type:  X721.AvailabilityStatusType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1;


/**
 * An XML X721.AvailabilityStatusType(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType.
 */
public interface X721AvailabilityStatusType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(X721AvailabilityStatusType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s191F600D204DEAE7EEDC98360AFBE7C2").resolveHandle("x721availabilitystatustypec296type");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum X = Enum.forString("");
    static final Enum IN_TYPE_EST = Enum.forString("INTypeEST");
    static final Enum FAILED = Enum.forString("FAILED");
    static final Enum POWER_OFF = Enum.forString("POWER_OFF");
    static final Enum OFF_LINE = Enum.forString("OFF_LINE");
    static final Enum OFF_DUTY = Enum.forString("OFF_DUTY");
    static final Enum DEPENDENCY = Enum.forString("DEPENDENCY");
    static final Enum DEGRADED = Enum.forString("DEGRADED");
    static final Enum NOT_INSTALLED = Enum.forString("NOT_INSTALLED");
    static final Enum LOG_FULL = Enum.forString("LOG_FULL");
    
    static final int INT_X = Enum.INT_X;
    static final int INT_IN_TYPE_EST = Enum.INT_IN_TYPE_EST;
    static final int INT_FAILED = Enum.INT_FAILED;
    static final int INT_POWER_OFF = Enum.INT_POWER_OFF;
    static final int INT_OFF_LINE = Enum.INT_OFF_LINE;
    static final int INT_OFF_DUTY = Enum.INT_OFF_DUTY;
    static final int INT_DEPENDENCY = Enum.INT_DEPENDENCY;
    static final int INT_DEGRADED = Enum.INT_DEGRADED;
    static final int INT_NOT_INSTALLED = Enum.INT_NOT_INSTALLED;
    static final int INT_LOG_FULL = Enum.INT_LOG_FULL;
    
    /**
     * Enumeration value class for org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_X
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_X = 1;
        static final int INT_IN_TYPE_EST = 2;
        static final int INT_FAILED = 3;
        static final int INT_POWER_OFF = 4;
        static final int INT_OFF_LINE = 5;
        static final int INT_OFF_DUTY = 6;
        static final int INT_DEPENDENCY = 7;
        static final int INT_DEGRADED = 8;
        static final int INT_NOT_INSTALLED = 9;
        static final int INT_LOG_FULL = 10;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("", INT_X),
                new Enum("INTypeEST", INT_IN_TYPE_EST),
                new Enum("FAILED", INT_FAILED),
                new Enum("POWER_OFF", INT_POWER_OFF),
                new Enum("OFF_LINE", INT_OFF_LINE),
                new Enum("OFF_DUTY", INT_OFF_DUTY),
                new Enum("DEPENDENCY", INT_DEPENDENCY),
                new Enum("DEGRADED", INT_DEGRADED),
                new Enum("NOT_INSTALLED", INT_NOT_INSTALLED),
                new Enum("LOG_FULL", INT_LOG_FULL),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType newValue(java.lang.Object obj) {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) type.newValue( obj ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType newInstance() {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
