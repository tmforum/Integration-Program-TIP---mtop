/*
 * XML Type:  TransmissionDescriptorStateType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/com/v1
 * Java type: org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.com.v1.impl;
/**
 * An XML TransmissionDescriptorStateType(@http://www.tmforum.org/mtop/nrf/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType.
 */
public class TransmissionDescriptorStateTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrf.xsd.com.v1.TransmissionDescriptorStateType
{
    
    public TransmissionDescriptorStateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected TransmissionDescriptorStateTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
