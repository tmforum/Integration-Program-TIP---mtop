/*
 * An XML document type.
 * Localname: tmd
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tmd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tmd.v1.TmdDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tmd.v1.impl;
/**
 * A document containing one tmd(@http://www.tmforum.org/mtop/nrf/xsd/tmd/v1) element.
 *
 * This is a complex type.
 */
public class TmdDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tmd.v1.TmdDocument
{
    
    public TmdDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TMD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "tmd");
    
    
    /**
     * Gets the "tmd" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType getTmd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().find_element_user(TMD$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tmd" element
     */
    public void setTmd(org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType tmd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().find_element_user(TMD$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().add_element_user(TMD$0);
            }
            target.set(tmd);
        }
    }
    
    /**
     * Appends and returns a new empty "tmd" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType addNewTmd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().add_element_user(TMD$0);
            return target;
        }
    }
}
