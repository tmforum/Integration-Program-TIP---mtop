/*
 * XML Type:  RouteNameAndAdminStateType
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * An XML RouteNameAndAdminStateType(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
 *
 * This is a complex type.
 */
public class RouteNameAndAdminStateTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType
{
    
    public RouteNameAndAdminStateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "id");
    private static final javax.xml.namespace.QName ADMINISTRATIVESTATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "administrativeState");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "vendorExtensions");
    
    
    /**
     * Gets the "id" element
     */
    public java.lang.String getId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "id" element
     */
    public org.apache.xmlbeans.XmlString xgetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "id" element
     */
    public boolean isSetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ID$0) != 0;
        }
    }
    
    /**
     * Sets the "id" element
     */
    public void setId(java.lang.String id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ID$0);
            }
            target.setStringValue(id);
        }
    }
    
    /**
     * Sets (as xml) the "id" element
     */
    public void xsetId(org.apache.xmlbeans.XmlString id)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ID$0);
            }
            target.set(id);
        }
    }
    
    /**
     * Unsets the "id" element
     */
    public void unsetId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ID$0, 0);
        }
    }
    
    /**
     * Gets the "administrativeState" element
     */
    public java.lang.String getAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADMINISTRATIVESTATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "administrativeState" element
     */
    public org.apache.xmlbeans.XmlString xgetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ADMINISTRATIVESTATE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "administrativeState" element
     */
    public boolean isSetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ADMINISTRATIVESTATE$2) != 0;
        }
    }
    
    /**
     * Sets the "administrativeState" element
     */
    public void setAdministrativeState(java.lang.String administrativeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADMINISTRATIVESTATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ADMINISTRATIVESTATE$2);
            }
            target.setStringValue(administrativeState);
        }
    }
    
    /**
     * Sets (as xml) the "administrativeState" element
     */
    public void xsetAdministrativeState(org.apache.xmlbeans.XmlString administrativeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ADMINISTRATIVESTATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ADMINISTRATIVESTATE$2);
            }
            target.set(administrativeState);
        }
    }
    
    /**
     * Unsets the "administrativeState" element
     */
    public void unsetAdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ADMINISTRATIVESTATE$2, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions)get_store().find_element_user(VENDOREXTENSIONS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions)get_store().find_element_user(VENDOREXTENSIONS$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions)get_store().add_element_user(VENDOREXTENSIONS$4);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions)get_store().add_element_user(VENDOREXTENSIONS$4);
            return target;
        }
    }
    /**
     * An XML vendorExtensions(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class VendorExtensionsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RouteNameAndAdminStateType.VendorExtensions
    {
        
        public VendorExtensionsImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
