/*
 * XML Type:  InstalledPartNumberType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/com/v1
 * Java type: org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.com.v1.impl;
/**
 * An XML InstalledPartNumberType(@http://www.tmforum.org/mtop/nrf/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType.
 */
public class InstalledPartNumberTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.nrf.xsd.com.v1.InstalledPartNumberType
{
    
    public InstalledPartNumberTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected InstalledPartNumberTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
