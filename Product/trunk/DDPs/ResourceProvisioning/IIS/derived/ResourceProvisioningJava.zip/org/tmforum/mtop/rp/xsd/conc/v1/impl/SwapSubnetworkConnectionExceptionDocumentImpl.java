/*
 * An XML document type.
 * Localname: swapSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one swapSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SwapSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument
{
    
    public SwapSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SWAPSUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "swapSubnetworkConnectionException");
    
    
    /**
     * Gets the "swapSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException getSwapSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException)get_store().find_element_user(SWAPSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "swapSubnetworkConnectionException" element
     */
    public void setSwapSubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException swapSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException)get_store().find_element_user(SWAPSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException)get_store().add_element_user(SWAPSUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(swapSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "swapSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException addNewSwapSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException)get_store().add_element_user(SWAPSUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML swapSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SwapSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionExceptionDocument.SwapSubnetworkConnectionException
    {
        
        public SwapSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
