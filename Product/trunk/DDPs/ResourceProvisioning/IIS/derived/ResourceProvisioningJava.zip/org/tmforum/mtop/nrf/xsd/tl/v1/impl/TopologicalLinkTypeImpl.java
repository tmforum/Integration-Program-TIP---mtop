/*
 * XML Type:  TopologicalLinkType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tl/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tl.v1.impl;
/**
 * An XML TopologicalLinkType(@http://www.tmforum.org/mtop/nrf/xsd/tl/v1).
 *
 * This is a complex type.
 */
public class TopologicalLinkTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType
{
    
    public TopologicalLinkTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "direction");
    private static final javax.xml.namespace.QName RATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "rate");
    private static final javax.xml.namespace.QName AENDTP$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "aEndTp");
    private static final javax.xml.namespace.QName ZENDTP$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "zEndTp");
    private static final javax.xml.namespace.QName ALARMREPORTINGINDICATOR$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "alarmReportingIndicator");
    private static final javax.xml.namespace.QName ALLOCATEDNUMBER$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "allocatedNumber");
    private static final javax.xml.namespace.QName ASAPREF$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "asapRef");
    private static final javax.xml.namespace.QName FRAGMENTSERVERLAYER$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tl/v1", "fragmentServerLayer");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "direction" element
     */
    public boolean isNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "direction" element
     */
    public boolean isSetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DIRECTION$0) != 0;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Nils the "direction" element
     */
    public void setNilDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "direction" element
     */
    public void unsetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DIRECTION$0, 0);
        }
    }
    
    /**
     * Gets the "rate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "rate" element
     */
    public boolean isNilRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "rate" element
     */
    public boolean isSetRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RATE$2) != 0;
        }
    }
    
    /**
     * Sets the "rate" element
     */
    public void setRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType rate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$2);
            }
            target.set(rate);
        }
    }
    
    /**
     * Appends and returns a new empty "rate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$2);
            return target;
        }
    }
    
    /**
     * Nils the "rate" element
     */
    public void setNilRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "rate" element
     */
    public void unsetRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RATE$2, 0);
        }
    }
    
    /**
     * Gets the "aEndTp" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getAEndTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(AENDTP$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "aEndTp" element
     */
    public boolean isSetAEndTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AENDTP$4) != 0;
        }
    }
    
    /**
     * Sets the "aEndTp" element
     */
    public void setAEndTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType aEndTp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(AENDTP$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(AENDTP$4);
            }
            target.set(aEndTp);
        }
    }
    
    /**
     * Appends and returns a new empty "aEndTp" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewAEndTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(AENDTP$4);
            return target;
        }
    }
    
    /**
     * Unsets the "aEndTp" element
     */
    public void unsetAEndTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AENDTP$4, 0);
        }
    }
    
    /**
     * Gets the "zEndTp" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getZEndTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ZENDTP$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "zEndTp" element
     */
    public boolean isSetZEndTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZENDTP$6) != 0;
        }
    }
    
    /**
     * Sets the "zEndTp" element
     */
    public void setZEndTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType zEndTp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ZENDTP$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ZENDTP$6);
            }
            target.set(zEndTp);
        }
    }
    
    /**
     * Appends and returns a new empty "zEndTp" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewZEndTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ZENDTP$6);
            return target;
        }
    }
    
    /**
     * Unsets the "zEndTp" element
     */
    public void unsetZEndTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZENDTP$6, 0);
        }
    }
    
    /**
     * Gets the "alarmReportingIndicator" element
     */
    public boolean getAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "alarmReportingIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType xgetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "alarmReportingIndicator" element
     */
    public boolean isNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "alarmReportingIndicator" element
     */
    public boolean isSetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMREPORTINGINDICATOR$8) != 0;
        }
    }
    
    /**
     * Sets the "alarmReportingIndicator" element
     */
    public void setAlarmReportingIndicator(boolean alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALARMREPORTINGINDICATOR$8);
            }
            target.setBooleanValue(alarmReportingIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "alarmReportingIndicator" element
     */
    public void xsetAlarmReportingIndicator(org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().add_element_user(ALARMREPORTINGINDICATOR$8);
            }
            target.set(alarmReportingIndicator);
        }
    }
    
    /**
     * Nils the "alarmReportingIndicator" element
     */
    public void setNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().add_element_user(ALARMREPORTINGINDICATOR$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "alarmReportingIndicator" element
     */
    public void unsetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMREPORTINGINDICATOR$8, 0);
        }
    }
    
    /**
     * Gets the "allocatedNumber" element
     */
    public java.lang.String getAllocatedNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALLOCATEDNUMBER$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "allocatedNumber" element
     */
    public org.apache.xmlbeans.XmlString xgetAllocatedNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALLOCATEDNUMBER$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "allocatedNumber" element
     */
    public boolean isNilAllocatedNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALLOCATEDNUMBER$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "allocatedNumber" element
     */
    public boolean isSetAllocatedNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALLOCATEDNUMBER$10) != 0;
        }
    }
    
    /**
     * Sets the "allocatedNumber" element
     */
    public void setAllocatedNumber(java.lang.String allocatedNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALLOCATEDNUMBER$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALLOCATEDNUMBER$10);
            }
            target.setStringValue(allocatedNumber);
        }
    }
    
    /**
     * Sets (as xml) the "allocatedNumber" element
     */
    public void xsetAllocatedNumber(org.apache.xmlbeans.XmlString allocatedNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALLOCATEDNUMBER$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ALLOCATEDNUMBER$10);
            }
            target.set(allocatedNumber);
        }
    }
    
    /**
     * Nils the "allocatedNumber" element
     */
    public void setNilAllocatedNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALLOCATEDNUMBER$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ALLOCATEDNUMBER$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "allocatedNumber" element
     */
    public void unsetAllocatedNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALLOCATEDNUMBER$10, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$12) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$12);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$12);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$12, 0);
        }
    }
    
    /**
     * Gets the "fragmentServerLayer" element
     */
    public java.lang.String getFragmentServerLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FRAGMENTSERVERLAYER$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "fragmentServerLayer" element
     */
    public org.apache.xmlbeans.XmlString xgetFragmentServerLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FRAGMENTSERVERLAYER$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "fragmentServerLayer" element
     */
    public boolean isNilFragmentServerLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FRAGMENTSERVERLAYER$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "fragmentServerLayer" element
     */
    public boolean isSetFragmentServerLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FRAGMENTSERVERLAYER$14) != 0;
        }
    }
    
    /**
     * Sets the "fragmentServerLayer" element
     */
    public void setFragmentServerLayer(java.lang.String fragmentServerLayer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FRAGMENTSERVERLAYER$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FRAGMENTSERVERLAYER$14);
            }
            target.setStringValue(fragmentServerLayer);
        }
    }
    
    /**
     * Sets (as xml) the "fragmentServerLayer" element
     */
    public void xsetFragmentServerLayer(org.apache.xmlbeans.XmlString fragmentServerLayer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FRAGMENTSERVERLAYER$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FRAGMENTSERVERLAYER$14);
            }
            target.set(fragmentServerLayer);
        }
    }
    
    /**
     * Nils the "fragmentServerLayer" element
     */
    public void setNilFragmentServerLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FRAGMENTSERVERLAYER$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FRAGMENTSERVERLAYER$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "fragmentServerLayer" element
     */
    public void unsetFragmentServerLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FRAGMENTSERVERLAYER$14, 0);
        }
    }
}
