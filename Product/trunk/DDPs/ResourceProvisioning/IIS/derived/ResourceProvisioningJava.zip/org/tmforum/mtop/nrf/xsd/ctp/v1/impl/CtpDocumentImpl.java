/*
 * An XML document type.
 * Localname: ctp
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ctp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ctp.v1.CtpDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ctp.v1.impl;
/**
 * A document containing one ctp(@http://www.tmforum.org/mtop/nrf/xsd/ctp/v1) element.
 *
 * This is a complex type.
 */
public class CtpDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.ctp.v1.CtpDocument
{
    
    public CtpDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "ctp");
    
    
    /**
     * Gets the "ctp" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType getCtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().find_element_user(CTP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ctp" element
     */
    public void setCtp(org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType ctp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().find_element_user(CTP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().add_element_user(CTP$0);
            }
            target.set(ctp);
        }
    }
    
    /**
     * Appends and returns a new empty "ctp" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType addNewCtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().add_element_user(CTP$0);
            return target;
        }
    }
}
