/*
 * An XML document type.
 * Localname: cc
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/cc/v1
 * Java type: org.tmforum.mtop.nrf.xsd.cc.v1.CcDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.cc.v1.impl;
/**
 * A document containing one cc(@http://www.tmforum.org/mtop/nrf/xsd/cc/v1) element.
 *
 * This is a complex type.
 */
public class CcDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.cc.v1.CcDocument
{
    
    public CcDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CC$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "cc");
    
    
    /**
     * Gets the "cc" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType getCc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType)get_store().find_element_user(CC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "cc" element
     */
    public void setCc(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType cc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType)get_store().find_element_user(CC$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType)get_store().add_element_user(CC$0);
            }
            target.set(cc);
        }
    }
    
    /**
     * Appends and returns a new empty "cc" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType addNewCc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType)get_store().add_element_user(CC$0);
            return target;
        }
    }
}
