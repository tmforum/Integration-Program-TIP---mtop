/*
 * XML Type:  MultiLayerSubnetworkListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mlsn.v1.impl;
/**
 * An XML MultiLayerSubnetworkListType(@http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1).
 *
 * This is a complex type.
 */
public class MultiLayerSubnetworkListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkListType
{
    
    public MultiLayerSubnetworkListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MLSN$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mlsn/v1", "mlsn");
    
    
    /**
     * Gets a List of "mlsn" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType> getMlsnList()
    {
        final class MlsnList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType>
        {
            public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType get(int i)
                { return MultiLayerSubnetworkListTypeImpl.this.getMlsnArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType set(int i, org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType o)
            {
                org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType old = MultiLayerSubnetworkListTypeImpl.this.getMlsnArray(i);
                MultiLayerSubnetworkListTypeImpl.this.setMlsnArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType o)
                { MultiLayerSubnetworkListTypeImpl.this.insertNewMlsn(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType old = MultiLayerSubnetworkListTypeImpl.this.getMlsnArray(i);
                MultiLayerSubnetworkListTypeImpl.this.removeMlsn(i);
                return old;
            }
            
            public int size()
                { return MultiLayerSubnetworkListTypeImpl.this.sizeOfMlsnArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new MlsnList();
        }
    }
    
    /**
     * Gets array of all "mlsn" elements
     */
    public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType[] getMlsnArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(MLSN$0, targetList);
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType[] result = new org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "mlsn" element
     */
    public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType getMlsnArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().find_element_user(MLSN$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "mlsn" element
     */
    public int sizeOfMlsnArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MLSN$0);
        }
    }
    
    /**
     * Sets array of all "mlsn" element
     */
    public void setMlsnArray(org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType[] mlsnArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(mlsnArray, MLSN$0);
        }
    }
    
    /**
     * Sets ith "mlsn" element
     */
    public void setMlsnArray(int i, org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType mlsn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().find_element_user(MLSN$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(mlsn);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "mlsn" element
     */
    public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType insertNewMlsn(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().insert_element_user(MLSN$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "mlsn" element
     */
    public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType addNewMlsn()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().add_element_user(MLSN$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "mlsn" element
     */
    public void removeMlsn(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MLSN$0, i);
        }
    }
}
