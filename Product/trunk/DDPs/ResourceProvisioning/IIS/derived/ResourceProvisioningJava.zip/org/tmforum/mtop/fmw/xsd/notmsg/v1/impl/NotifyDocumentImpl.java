/*
 * An XML document type.
 * Localname: notify
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * A document containing one notify(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1) element.
 *
 * This is a complex type.
 */
public class NotifyDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument
{
    
    public NotifyDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NOTIFY$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "notify");
    
    
    /**
     * Gets the "notify" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify getNotify()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify)get_store().find_element_user(NOTIFY$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "notify" element
     */
    public void setNotify(org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify notify)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify)get_store().find_element_user(NOTIFY$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify)get_store().add_element_user(NOTIFY$0);
            }
            target.set(notify);
        }
    }
    
    /**
     * Appends and returns a new empty "notify" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify addNewNotify()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify)get_store().add_element_user(NOTIFY$0);
            return target;
        }
    }
    /**
     * An XML notify(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public static class NotifyImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify
    {
        
        public NotifyImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TOPIC$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "topic");
        private static final javax.xml.namespace.QName MESSAGE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "message");
        
        
        /**
         * Gets the "topic" element
         */
        public java.lang.String getTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOPIC$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "topic" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType xgetTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().find_element_user(TOPIC$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "topic" element
         */
        public void setTopic(java.lang.String topic)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOPIC$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOPIC$0);
                }
                target.setStringValue(topic);
            }
        }
        
        /**
         * Sets (as xml) the "topic" element
         */
        public void xsetTopic(org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType topic)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().find_element_user(TOPIC$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().add_element_user(TOPIC$0);
                }
                target.set(topic);
            }
        }
        
        /**
         * Gets the "message" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message getMessage()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message)get_store().find_element_user(MESSAGE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "message" element
         */
        public void setMessage(org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message message)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message)get_store().find_element_user(MESSAGE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message)get_store().add_element_user(MESSAGE$2);
                }
                target.set(message);
            }
        }
        
        /**
         * Appends and returns a new empty "message" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message addNewMessage()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message)get_store().add_element_user(MESSAGE$2);
                return target;
            }
        }
        /**
         * An XML message(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
         *
         * This is a complex type.
         */
        public static class MessageImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.NotifyDocument.Notify.Message
        {
            
            public MessageImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName COMMONEVENTINFORMATION$0 = 
                new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "commonEventInformation");
            private static final org.apache.xmlbeans.QNameSet COMMONEVENTINFORMATION$1 = org.apache.xmlbeans.QNameSet.forArray( new javax.xml.namespace.QName[] { 
                new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "commonEventInformation"),
                new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/bs/v1", "backupStatus"),
            });
            
            
            /**
             * Gets a List of "commonEventInformation" elements
             */
            public java.util.List<org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType> getCommonEventInformationList()
            {
                final class CommonEventInformationList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType>
                {
                    public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType get(int i)
                        { return MessageImpl.this.getCommonEventInformationArray(i); }
                    
                    public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType set(int i, org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType o)
                    {
                      org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType old = MessageImpl.this.getCommonEventInformationArray(i);
                      MessageImpl.this.setCommonEventInformationArray(i, o);
                      return old;
                    }
                    
                    public void add(int i, org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType o)
                        { MessageImpl.this.insertNewCommonEventInformation(i).set(o); }
                    
                    public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType remove(int i)
                    {
                      org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType old = MessageImpl.this.getCommonEventInformationArray(i);
                      MessageImpl.this.removeCommonEventInformation(i);
                      return old;
                    }
                    
                    public int size()
                        { return MessageImpl.this.sizeOfCommonEventInformationArray(); }
                    
                }
                
                synchronized (monitor())
                {
                    check_orphaned();
                    return new CommonEventInformationList();
                }
            }
            
            /**
             * Gets array of all "commonEventInformation" elements
             */
            public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType[] getCommonEventInformationArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(COMMONEVENTINFORMATION$1, targetList);
                    org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType[] result = new org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets ith "commonEventInformation" element
             */
            public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType getCommonEventInformationArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
                    target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().find_element_user(COMMONEVENTINFORMATION$1, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "commonEventInformation" element
             */
            public int sizeOfCommonEventInformationArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(COMMONEVENTINFORMATION$1);
                }
            }
            
            /**
             * Sets array of all "commonEventInformation" element
             */
            public void setCommonEventInformationArray(org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType[] commonEventInformationArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(commonEventInformationArray, COMMONEVENTINFORMATION$0, COMMONEVENTINFORMATION$1);
                }
            }
            
            /**
             * Sets ith "commonEventInformation" element
             */
            public void setCommonEventInformationArray(int i, org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType commonEventInformation)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
                    target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().find_element_user(COMMONEVENTINFORMATION$1, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.set(commonEventInformation);
                }
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "commonEventInformation" element
             */
            public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType insertNewCommonEventInformation(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
                    target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().insert_element_user(COMMONEVENTINFORMATION$1, COMMONEVENTINFORMATION$0, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "commonEventInformation" element
             */
            public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType addNewCommonEventInformation()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
                    target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().add_element_user(COMMONEVENTINFORMATION$0);
                    return target;
                }
            }
            
            /**
             * Removes the ith "commonEventInformation" element
             */
            public void removeCommonEventInformation(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(COMMONEVENTINFORMATION$1, i);
                }
            }
        }
    }
}
