/*
 * XML Type:  FlowDomainFragmentType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fdfr.v1;


/**
 * An XML FlowDomainFragmentType(@http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1).
 *
 * This is a complex type.
 */
public interface FlowDomainFragmentType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FlowDomainFragmentType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s732E47122B99A5ED8D93FEE82721A56B").resolveHandle("flowdomainfragmenttype31c5type");
    
    /**
     * Gets the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection();
    
    /**
     * Gets (as xml) the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection();
    
    /**
     * Tests for nil "direction" element
     */
    boolean isNilDirection();
    
    /**
     * True if has "direction" element
     */
    boolean isSetDirection();
    
    /**
     * Sets the "direction" element
     */
    void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction);
    
    /**
     * Sets (as xml) the "direction" element
     */
    void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction);
    
    /**
     * Nils the "direction" element
     */
    void setNilDirection();
    
    /**
     * Unsets the "direction" element
     */
    void unsetDirection();
    
    /**
     * Gets the "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType getTransmissionParameterList();
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    boolean isNilTransmissionParameterList();
    
    /**
     * True if has "transmissionParameterList" element
     */
    boolean isSetTransmissionParameterList();
    
    /**
     * Sets the "transmissionParameterList" element
     */
    void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType transmissionParameterList);
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType addNewTransmissionParameterList();
    
    /**
     * Nils the "transmissionParameterList" element
     */
    void setNilTransmissionParameterList();
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    void unsetTransmissionParameterList();
    
    /**
     * Gets the "aEndTpDataList" element
     */
    org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getAEndTpDataList();
    
    /**
     * Tests for nil "aEndTpDataList" element
     */
    boolean isNilAEndTpDataList();
    
    /**
     * True if has "aEndTpDataList" element
     */
    boolean isSetAEndTpDataList();
    
    /**
     * Sets the "aEndTpDataList" element
     */
    void setAEndTpDataList(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType aEndTpDataList);
    
    /**
     * Appends and returns a new empty "aEndTpDataList" element
     */
    org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewAEndTpDataList();
    
    /**
     * Nils the "aEndTpDataList" element
     */
    void setNilAEndTpDataList();
    
    /**
     * Unsets the "aEndTpDataList" element
     */
    void unsetAEndTpDataList();
    
    /**
     * Gets the "zEndTpDataList" element
     */
    org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getZEndTpDataList();
    
    /**
     * Tests for nil "zEndTpDataList" element
     */
    boolean isNilZEndTpDataList();
    
    /**
     * True if has "zEndTpDataList" element
     */
    boolean isSetZEndTpDataList();
    
    /**
     * Sets the "zEndTpDataList" element
     */
    void setZEndTpDataList(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType zEndTpDataList);
    
    /**
     * Appends and returns a new empty "zEndTpDataList" element
     */
    org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewZEndTpDataList();
    
    /**
     * Nils the "zEndTpDataList" element
     */
    void setNilZEndTpDataList();
    
    /**
     * Unsets the "zEndTpDataList" element
     */
    void unsetZEndTpDataList();
    
    /**
     * Gets the "isFlexible" element
     */
    boolean getIsFlexible();
    
    /**
     * Gets (as xml) the "isFlexible" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsFlexible();
    
    /**
     * Tests for nil "isFlexible" element
     */
    boolean isNilIsFlexible();
    
    /**
     * True if has "isFlexible" element
     */
    boolean isSetIsFlexible();
    
    /**
     * Sets the "isFlexible" element
     */
    void setIsFlexible(boolean isFlexible);
    
    /**
     * Sets (as xml) the "isFlexible" element
     */
    void xsetIsFlexible(org.apache.xmlbeans.XmlBoolean isFlexible);
    
    /**
     * Nils the "isFlexible" element
     */
    void setNilIsFlexible();
    
    /**
     * Unsets the "isFlexible" element
     */
    void unsetIsFlexible();
    
    /**
     * Gets the "administrativeState" element
     */
    org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum getAdministrativeState();
    
    /**
     * Gets (as xml) the "administrativeState" element
     */
    org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType xgetAdministrativeState();
    
    /**
     * Tests for nil "administrativeState" element
     */
    boolean isNilAdministrativeState();
    
    /**
     * True if has "administrativeState" element
     */
    boolean isSetAdministrativeState();
    
    /**
     * Sets the "administrativeState" element
     */
    void setAdministrativeState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum administrativeState);
    
    /**
     * Sets (as xml) the "administrativeState" element
     */
    void xsetAdministrativeState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType administrativeState);
    
    /**
     * Nils the "administrativeState" element
     */
    void setNilAdministrativeState();
    
    /**
     * Unsets the "administrativeState" element
     */
    void unsetAdministrativeState();
    
    /**
     * Gets the "fdfrState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum getFdfrState();
    
    /**
     * Gets (as xml) the "fdfrState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType xgetFdfrState();
    
    /**
     * Tests for nil "fdfrState" element
     */
    boolean isNilFdfrState();
    
    /**
     * True if has "fdfrState" element
     */
    boolean isSetFdfrState();
    
    /**
     * Sets the "fdfrState" element
     */
    void setFdfrState(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum fdfrState);
    
    /**
     * Sets (as xml) the "fdfrState" element
     */
    void xsetFdfrState(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType fdfrState);
    
    /**
     * Nils the "fdfrState" element
     */
    void setNilFdfrState();
    
    /**
     * Unsets the "fdfrState" element
     */
    void unsetFdfrState();
    
    /**
     * Gets the "fdfrType" element
     */
    java.lang.String getFdfrType();
    
    /**
     * Gets (as xml) the "fdfrType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType xgetFdfrType();
    
    /**
     * Tests for nil "fdfrType" element
     */
    boolean isNilFdfrType();
    
    /**
     * True if has "fdfrType" element
     */
    boolean isSetFdfrType();
    
    /**
     * Sets the "fdfrType" element
     */
    void setFdfrType(java.lang.String fdfrType);
    
    /**
     * Sets (as xml) the "fdfrType" element
     */
    void xsetFdfrType(org.tmforum.mtop.nrf.xsd.com.v1.FlowDomainFragmentTypeType fdfrType);
    
    /**
     * Nils the "fdfrType" element
     */
    void setNilFdfrType();
    
    /**
     * Unsets the "fdfrType" element
     */
    void unsetFdfrType();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
