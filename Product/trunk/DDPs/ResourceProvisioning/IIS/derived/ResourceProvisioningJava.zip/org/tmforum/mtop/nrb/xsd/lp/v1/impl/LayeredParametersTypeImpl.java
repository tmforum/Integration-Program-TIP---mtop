/*
 * XML Type:  LayeredParametersType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/lp/v1
 * Java type: org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.lp.v1.impl;
/**
 * An XML LayeredParametersType(@http://www.tmforum.org/mtop/nrb/xsd/lp/v1).
 *
 * This is a complex type.
 */
public class LayeredParametersTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType
{
    
    public LayeredParametersTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LAYER$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/lp/v1", "layer");
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/lp/v1", "transmissionParams");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/lp/v1", "vendorExtensions");
    
    
    /**
     * Gets the "layer" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "layer" element
     */
    public boolean isSetLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYER$0) != 0;
        }
    }
    
    /**
     * Sets the "layer" element
     */
    public void setLayer(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYER$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYER$0);
            }
            target.set(layer);
        }
    }
    
    /**
     * Appends and returns a new empty "layer" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYER$0);
            return target;
        }
    }
    
    /**
     * Unsets the "layer" element
     */
    public void unsetLayer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYER$0, 0);
        }
    }
    
    /**
     * Gets the "transmissionParams" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType getTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(TRANSMISSIONPARAMS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "transmissionParams" element
     */
    public boolean isSetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMS$2) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParams" element
     */
    public void setTransmissionParams(org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType transmissionParams)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(TRANSMISSIONPARAMS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(TRANSMISSIONPARAMS$2);
            }
            target.set(transmissionParams);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType addNewTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(TRANSMISSIONPARAMS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "transmissionParams" element
     */
    public void unsetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMS$2, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$4) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$4);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$4);
            return target;
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$4, 0);
        }
    }
}
