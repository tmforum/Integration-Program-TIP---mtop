/*
 * An XML document type.
 * Localname: createSncException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateSncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument
{
    
    public CreateSncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATESNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createSncException");
    
    
    /**
     * Gets the "createSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException getCreateSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException)get_store().find_element_user(CREATESNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createSncException" element
     */
    public void setCreateSncException(org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException createSncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException)get_store().find_element_user(CREATESNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException)get_store().add_element_user(CREATESNCEXCEPTION$0);
            }
            target.set(createSncException);
        }
    }
    
    /**
     * Appends and returns a new empty "createSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException addNewCreateSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException)get_store().add_element_user(CREATESNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML createSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateSncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateSncExceptionDocument.CreateSncException
    {
        
        public CreateSncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
