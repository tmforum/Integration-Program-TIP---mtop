/*
 * An XML document type.
 * Localname: commonResourceInfo
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/cri/v1
 * Java type: org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.cri.v1.impl;
/**
 * A document containing one commonResourceInfo(@http://www.tmforum.org/mtop/nrb/xsd/cri/v1) element.
 *
 * This is a complex type.
 */
public class CommonResourceInfoDocumentImpl extends org.tmforum.mtop.fmw.xsd.coi.v1.impl.CommonObjectInfoDocumentImpl implements org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoDocument
{
    
    public CommonResourceInfoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONRESOURCEINFO$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/cri/v1", "commonResourceInfo");
    
    
    /**
     * Gets the "commonResourceInfo" element
     */
    public org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType getCommonResourceInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType)get_store().find_element_user(COMMONRESOURCEINFO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonResourceInfo" element
     */
    public void setCommonResourceInfo(org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType commonResourceInfo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType)get_store().find_element_user(COMMONRESOURCEINFO$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType)get_store().add_element_user(COMMONRESOURCEINFO$0);
            }
            target.set(commonResourceInfo);
        }
    }
    
    /**
     * Appends and returns a new empty "commonResourceInfo" element
     */
    public org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType addNewCommonResourceInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType)get_store().add_element_user(COMMONRESOURCEINFO$0);
            return target;
        }
    }
}
