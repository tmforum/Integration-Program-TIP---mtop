/*
 * An XML document type.
 * Localname: activateSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one activateSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class ActivateSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument
{
    
    public ActivateSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACTIVATESUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "activateSubnetworkConnectionException");
    
    
    /**
     * Gets the "activateSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException getActivateSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException)get_store().find_element_user(ACTIVATESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "activateSubnetworkConnectionException" element
     */
    public void setActivateSubnetworkConnectionException(org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException activateSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException)get_store().find_element_user(ACTIVATESUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException)get_store().add_element_user(ACTIVATESUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(activateSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "activateSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException addNewActivateSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException)get_store().add_element_user(ACTIVATESUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML activateSubnetworkConnectionException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ActivateSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.ActivateSubnetworkConnectionExceptionDocument.ActivateSubnetworkConnectionException
    {
        
        public ActivateSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
