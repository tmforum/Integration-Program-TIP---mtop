/*
 * XML Type:  GroupTerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/gtp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.gtp.v1.impl;
/**
 * An XML GroupTerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/gtp/v1).
 *
 * This is a complex type.
 */
public class GroupTerminationPointTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType
{
    
    public GroupTerminationPointTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARMREPORTINGINDICATOR$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "alarmReportingIndicator");
    private static final javax.xml.namespace.QName TPLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "tpList");
    private static final javax.xml.namespace.QName GTPCONNECTIONSTATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "gtpConnectionState");
    private static final javax.xml.namespace.QName ASAPREF$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "asapRef");
    
    
    /**
     * Gets the "alarmReportingIndicator" element
     */
    public boolean getAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "alarmReportingIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType xgetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "alarmReportingIndicator" element
     */
    public boolean isNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "alarmReportingIndicator" element
     */
    public boolean isSetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMREPORTINGINDICATOR$0) != 0;
        }
    }
    
    /**
     * Sets the "alarmReportingIndicator" element
     */
    public void setAlarmReportingIndicator(boolean alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALARMREPORTINGINDICATOR$0);
            }
            target.setBooleanValue(alarmReportingIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "alarmReportingIndicator" element
     */
    public void xsetAlarmReportingIndicator(org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().add_element_user(ALARMREPORTINGINDICATOR$0);
            }
            target.set(alarmReportingIndicator);
        }
    }
    
    /**
     * Nils the "alarmReportingIndicator" element
     */
    public void setNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().find_element_user(ALARMREPORTINGINDICATOR$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.AlarmReportingType)get_store().add_element_user(ALARMREPORTINGINDICATOR$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "alarmReportingIndicator" element
     */
    public void unsetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMREPORTINGINDICATOR$0, 0);
        }
    }
    
    /**
     * Gets the "tpList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(TPLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "tpList" element
     */
    public boolean isNilTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(TPLIST$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpList" element
     */
    public boolean isSetTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "tpList" element
     */
    public void setTpList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType tpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(TPLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(TPLIST$2);
            }
            target.set(tpList);
        }
    }
    
    /**
     * Appends and returns a new empty "tpList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(TPLIST$2);
            return target;
        }
    }
    
    /**
     * Nils the "tpList" element
     */
    public void setNilTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(TPLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(TPLIST$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpList" element
     */
    public void unsetTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPLIST$2, 0);
        }
    }
    
    /**
     * Gets the "gtpConnectionState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.Enum getGtpConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GTPCONNECTIONSTATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "gtpConnectionState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType xgetGtpConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().find_element_user(GTPCONNECTIONSTATE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "gtpConnectionState" element
     */
    public boolean isNilGtpConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().find_element_user(GTPCONNECTIONSTATE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "gtpConnectionState" element
     */
    public boolean isSetGtpConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GTPCONNECTIONSTATE$4) != 0;
        }
    }
    
    /**
     * Sets the "gtpConnectionState" element
     */
    public void setGtpConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType.Enum gtpConnectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GTPCONNECTIONSTATE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(GTPCONNECTIONSTATE$4);
            }
            target.setEnumValue(gtpConnectionState);
        }
    }
    
    /**
     * Sets (as xml) the "gtpConnectionState" element
     */
    public void xsetGtpConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType gtpConnectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().find_element_user(GTPCONNECTIONSTATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().add_element_user(GTPCONNECTIONSTATE$4);
            }
            target.set(gtpConnectionState);
        }
    }
    
    /**
     * Nils the "gtpConnectionState" element
     */
    public void setNilGtpConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().find_element_user(GTPCONNECTIONSTATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpConnectionStateType)get_store().add_element_user(GTPCONNECTIONSTATE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "gtpConnectionState" element
     */
    public void unsetGtpConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GTPCONNECTIONSTATE$4, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$6) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$6);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$6);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$6, 0);
        }
    }
}
