/*
 * XML Type:  GroupTerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/gtp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.gtp.v1.impl;
/**
 * An XML GroupTerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/gtp/v1).
 *
 * This is a complex type.
 */
public class GroupTerminationPointTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType
{
    
    public GroupTerminationPointTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ISREPORTINGALARM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "isReportingAlarm");
    private static final javax.xml.namespace.QName CONTAINEDTPREFLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "containedTpRefList");
    private static final javax.xml.namespace.QName CONNECTIONSTATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "connectionState");
    private static final javax.xml.namespace.QName ASAPREF$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "asapRef");
    
    
    /**
     * Gets the "isReportingAlarm" element
     */
    public boolean getIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isReportingAlarm" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isReportingAlarm" element
     */
    public boolean isNilIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isReportingAlarm" element
     */
    public boolean isSetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISREPORTINGALARM$0) != 0;
        }
    }
    
    /**
     * Sets the "isReportingAlarm" element
     */
    public void setIsReportingAlarm(boolean isReportingAlarm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISREPORTINGALARM$0);
            }
            target.setBooleanValue(isReportingAlarm);
        }
    }
    
    /**
     * Sets (as xml) the "isReportingAlarm" element
     */
    public void xsetIsReportingAlarm(org.apache.xmlbeans.XmlBoolean isReportingAlarm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREPORTINGALARM$0);
            }
            target.set(isReportingAlarm);
        }
    }
    
    /**
     * Nils the "isReportingAlarm" element
     */
    public void setNilIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREPORTINGALARM$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isReportingAlarm" element
     */
    public void unsetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISREPORTINGALARM$0, 0);
        }
    }
    
    /**
     * Gets the "containedTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getContainedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CONTAINEDTPREFLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "containedTpRefList" element
     */
    public boolean isNilContainedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CONTAINEDTPREFLIST$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "containedTpRefList" element
     */
    public boolean isSetContainedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTAINEDTPREFLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "containedTpRefList" element
     */
    public void setContainedTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType containedTpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CONTAINEDTPREFLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CONTAINEDTPREFLIST$2);
            }
            target.set(containedTpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "containedTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewContainedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CONTAINEDTPREFLIST$2);
            return target;
        }
    }
    
    /**
     * Nils the "containedTpRefList" element
     */
    public void setNilContainedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CONTAINEDTPREFLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CONTAINEDTPREFLIST$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "containedTpRefList" element
     */
    public void unsetContainedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTAINEDTPREFLIST$2, 0);
        }
    }
    
    /**
     * Gets the "connectionState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum getConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSTATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "connectionState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType xgetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "connectionState" element
     */
    public boolean isNilConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "connectionState" element
     */
    public boolean isSetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIONSTATE$4) != 0;
        }
    }
    
    /**
     * Sets the "connectionState" element
     */
    public void setConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType.Enum connectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONNECTIONSTATE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONNECTIONSTATE$4);
            }
            target.setEnumValue(connectionState);
        }
    }
    
    /**
     * Sets (as xml) the "connectionState" element
     */
    public void xsetConnectionState(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType connectionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().add_element_user(CONNECTIONSTATE$4);
            }
            target.set(connectionState);
        }
    }
    
    /**
     * Nils the "connectionState" element
     */
    public void setNilConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().find_element_user(CONNECTIONSTATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointConnectionStateType)get_store().add_element_user(CONNECTIONSTATE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "connectionState" element
     */
    public void unsetConnectionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIONSTATE$4, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$6) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$6);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$6);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$6, 0);
        }
    }
}
