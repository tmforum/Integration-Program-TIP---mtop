/*
 * XML Type:  TransmissionDescriptorType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tmd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tmd.v1.impl;
/**
 * An XML TransmissionDescriptorType(@http://www.tmforum.org/mtop/nrf/xsd/tmd/v1).
 *
 * This is a complex type.
 */
public class TransmissionDescriptorTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType
{
    
    public TransmissionDescriptorTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMETERLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "transmissionParameterList");
    private static final javax.xml.namespace.QName ADDITIONALOBJECTINFO$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "additionalObjectInfo");
    private static final javax.xml.namespace.QName CONTAININGTMDREF$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "containingTmdRef");
    private static final javax.xml.namespace.QName EXTERNALREPRESENTATIONREFERENCE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "externalRepresentationReference");
    private static final javax.xml.namespace.QName CONFORMANCEDEFINITION$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "conformanceDefinition");
    private static final javax.xml.namespace.QName SERVICECATEGORY$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "serviceCategory");
    
    
    /**
     * Gets the "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    public boolean isNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParameterList" element
     */
    public boolean isSetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMETERLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParameterList" element
     */
    public void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            }
            target.set(transmissionParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParameterList" element
     */
    public void setNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    public void unsetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMETERLIST$0, 0);
        }
    }
    
    /**
     * Gets the "additionalObjectInfo" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType getAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().find_element_user(ADDITIONALOBJECTINFO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "additionalObjectInfo" element
     */
    public boolean isNilAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().find_element_user(ADDITIONALOBJECTINFO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "additionalObjectInfo" element
     */
    public boolean isSetAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ADDITIONALOBJECTINFO$2) != 0;
        }
    }
    
    /**
     * Sets the "additionalObjectInfo" element
     */
    public void setAdditionalObjectInfo(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType additionalObjectInfo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().find_element_user(ADDITIONALOBJECTINFO$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().add_element_user(ADDITIONALOBJECTINFO$2);
            }
            target.set(additionalObjectInfo);
        }
    }
    
    /**
     * Appends and returns a new empty "additionalObjectInfo" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType addNewAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().add_element_user(ADDITIONALOBJECTINFO$2);
            return target;
        }
    }
    
    /**
     * Nils the "additionalObjectInfo" element
     */
    public void setNilAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().find_element_user(ADDITIONALOBJECTINFO$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().add_element_user(ADDITIONALOBJECTINFO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "additionalObjectInfo" element
     */
    public void unsetAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ADDITIONALOBJECTINFO$2, 0);
        }
    }
    
    /**
     * Gets the "containingTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getContainingTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CONTAININGTMDREF$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "containingTmdRef" element
     */
    public boolean isNilContainingTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CONTAININGTMDREF$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "containingTmdRef" element
     */
    public boolean isSetContainingTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTAININGTMDREF$4) != 0;
        }
    }
    
    /**
     * Sets the "containingTmdRef" element
     */
    public void setContainingTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType containingTmdRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CONTAININGTMDREF$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CONTAININGTMDREF$4);
            }
            target.set(containingTmdRef);
        }
    }
    
    /**
     * Appends and returns a new empty "containingTmdRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewContainingTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CONTAININGTMDREF$4);
            return target;
        }
    }
    
    /**
     * Nils the "containingTmdRef" element
     */
    public void setNilContainingTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CONTAININGTMDREF$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CONTAININGTMDREF$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "containingTmdRef" element
     */
    public void unsetContainingTmdRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTAININGTMDREF$4, 0);
        }
    }
    
    /**
     * Gets the "externalRepresentationReference" element
     */
    public java.lang.String getExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "externalRepresentationReference" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType xgetExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "externalRepresentationReference" element
     */
    public boolean isNilExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "externalRepresentationReference" element
     */
    public boolean isSetExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXTERNALREPRESENTATIONREFERENCE$6) != 0;
        }
    }
    
    /**
     * Sets the "externalRepresentationReference" element
     */
    public void setExternalRepresentationReference(java.lang.String externalRepresentationReference)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXTERNALREPRESENTATIONREFERENCE$6);
            }
            target.setStringValue(externalRepresentationReference);
        }
    }
    
    /**
     * Sets (as xml) the "externalRepresentationReference" element
     */
    public void xsetExternalRepresentationReference(org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType externalRepresentationReference)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().add_element_user(EXTERNALREPRESENTATIONREFERENCE$6);
            }
            target.set(externalRepresentationReference);
        }
    }
    
    /**
     * Nils the "externalRepresentationReference" element
     */
    public void setNilExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().add_element_user(EXTERNALREPRESENTATIONREFERENCE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "externalRepresentationReference" element
     */
    public void unsetExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXTERNALREPRESENTATIONREFERENCE$6, 0);
        }
    }
    
    /**
     * Gets the "conformanceDefinition" element
     */
    public java.lang.String getConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "conformanceDefinition" element
     */
    public org.apache.xmlbeans.XmlString xgetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "conformanceDefinition" element
     */
    public boolean isNilConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "conformanceDefinition" element
     */
    public boolean isSetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONFORMANCEDEFINITION$8) != 0;
        }
    }
    
    /**
     * Sets the "conformanceDefinition" element
     */
    public void setConformanceDefinition(java.lang.String conformanceDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONFORMANCEDEFINITION$8);
            }
            target.setStringValue(conformanceDefinition);
        }
    }
    
    /**
     * Sets (as xml) the "conformanceDefinition" element
     */
    public void xsetConformanceDefinition(org.apache.xmlbeans.XmlString conformanceDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONFORMANCEDEFINITION$8);
            }
            target.set(conformanceDefinition);
        }
    }
    
    /**
     * Nils the "conformanceDefinition" element
     */
    public void setNilConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONFORMANCEDEFINITION$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "conformanceDefinition" element
     */
    public void unsetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONFORMANCEDEFINITION$8, 0);
        }
    }
    
    /**
     * Gets the "serviceCategory" element
     */
    public java.lang.String getServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceCategory" element
     */
    public org.apache.xmlbeans.XmlString xgetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "serviceCategory" element
     */
    public boolean isNilServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "serviceCategory" element
     */
    public boolean isSetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICECATEGORY$10) != 0;
        }
    }
    
    /**
     * Sets the "serviceCategory" element
     */
    public void setServiceCategory(java.lang.String serviceCategory)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICECATEGORY$10);
            }
            target.setStringValue(serviceCategory);
        }
    }
    
    /**
     * Sets (as xml) the "serviceCategory" element
     */
    public void xsetServiceCategory(org.apache.xmlbeans.XmlString serviceCategory)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICECATEGORY$10);
            }
            target.set(serviceCategory);
        }
    }
    
    /**
     * Nils the "serviceCategory" element
     */
    public void setNilServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICECATEGORY$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "serviceCategory" element
     */
    public void unsetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICECATEGORY$10, 0);
        }
    }
}
