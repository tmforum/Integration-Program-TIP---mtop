/*
 * XML Type:  TransmissionDescriptorType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tmd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tmd.v1.impl;
/**
 * An XML TransmissionDescriptorType(@http://www.tmforum.org/mtop/nrf/xsd/tmd/v1).
 *
 * This is a complex type.
 */
public class TransmissionDescriptorTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType
{
    
    public TransmissionDescriptorTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "transmissionParams");
    private static final javax.xml.namespace.QName ADDITIONALOBJECTINFO$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "additionalObjectInfo");
    private static final javax.xml.namespace.QName CONTAININGTMDNAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "containingTmdName");
    private static final javax.xml.namespace.QName EXTERNALREPRESENTATIONREFERENCE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "externalRepresentationReference");
    private static final javax.xml.namespace.QName CONFORMANCEDEFINITION$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "conformanceDefinition");
    private static final javax.xml.namespace.QName SERVICECATEGORY$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tmd/v1", "serviceCategory");
    
    
    /**
     * Gets the "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParams" element
     */
    public boolean isNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParams" element
     */
    public boolean isSetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMS$0) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParams" element
     */
    public void setTransmissionParams(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParams)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$0);
            }
            target.set(transmissionParams);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParams" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$0);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParams" element
     */
    public void setNilTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParams" element
     */
    public void unsetTransmissionParams()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMS$0, 0);
        }
    }
    
    /**
     * Gets the "additionalObjectInfo" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType getAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(ADDITIONALOBJECTINFO$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "additionalObjectInfo" element
     */
    public boolean isNilAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(ADDITIONALOBJECTINFO$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "additionalObjectInfo" element
     */
    public boolean isSetAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ADDITIONALOBJECTINFO$2) != 0;
        }
    }
    
    /**
     * Sets the "additionalObjectInfo" element
     */
    public void setAdditionalObjectInfo(org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType additionalObjectInfo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(ADDITIONALOBJECTINFO$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(ADDITIONALOBJECTINFO$2);
            }
            target.set(additionalObjectInfo);
        }
    }
    
    /**
     * Appends and returns a new empty "additionalObjectInfo" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType addNewAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(ADDITIONALOBJECTINFO$2);
            return target;
        }
    }
    
    /**
     * Nils the "additionalObjectInfo" element
     */
    public void setNilAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(ADDITIONALOBJECTINFO$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(ADDITIONALOBJECTINFO$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "additionalObjectInfo" element
     */
    public void unsetAdditionalObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ADDITIONALOBJECTINFO$2, 0);
        }
    }
    
    /**
     * Gets the "containingTmdName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getContainingTmdName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(CONTAININGTMDNAME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "containingTmdName" element
     */
    public boolean isNilContainingTmdName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(CONTAININGTMDNAME$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "containingTmdName" element
     */
    public boolean isSetContainingTmdName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTAININGTMDNAME$4) != 0;
        }
    }
    
    /**
     * Sets the "containingTmdName" element
     */
    public void setContainingTmdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType containingTmdName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(CONTAININGTMDNAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(CONTAININGTMDNAME$4);
            }
            target.set(containingTmdName);
        }
    }
    
    /**
     * Appends and returns a new empty "containingTmdName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewContainingTmdName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(CONTAININGTMDNAME$4);
            return target;
        }
    }
    
    /**
     * Nils the "containingTmdName" element
     */
    public void setNilContainingTmdName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(CONTAININGTMDNAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(CONTAININGTMDNAME$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "containingTmdName" element
     */
    public void unsetContainingTmdName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTAININGTMDNAME$4, 0);
        }
    }
    
    /**
     * Gets the "externalRepresentationReference" element
     */
    public java.lang.String getExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "externalRepresentationReference" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType xgetExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "externalRepresentationReference" element
     */
    public boolean isNilExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "externalRepresentationReference" element
     */
    public boolean isSetExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXTERNALREPRESENTATIONREFERENCE$6) != 0;
        }
    }
    
    /**
     * Sets the "externalRepresentationReference" element
     */
    public void setExternalRepresentationReference(java.lang.String externalRepresentationReference)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXTERNALREPRESENTATIONREFERENCE$6);
            }
            target.setStringValue(externalRepresentationReference);
        }
    }
    
    /**
     * Sets (as xml) the "externalRepresentationReference" element
     */
    public void xsetExternalRepresentationReference(org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType externalRepresentationReference)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().add_element_user(EXTERNALREPRESENTATIONREFERENCE$6);
            }
            target.set(externalRepresentationReference);
        }
    }
    
    /**
     * Nils the "externalRepresentationReference" element
     */
    public void setNilExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().find_element_user(EXTERNALREPRESENTATIONREFERENCE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType)get_store().add_element_user(EXTERNALREPRESENTATIONREFERENCE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "externalRepresentationReference" element
     */
    public void unsetExternalRepresentationReference()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXTERNALREPRESENTATIONREFERENCE$6, 0);
        }
    }
    
    /**
     * Gets the "conformanceDefinition" element
     */
    public java.lang.String getConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "conformanceDefinition" element
     */
    public org.apache.xmlbeans.XmlString xgetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "conformanceDefinition" element
     */
    public boolean isNilConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "conformanceDefinition" element
     */
    public boolean isSetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONFORMANCEDEFINITION$8) != 0;
        }
    }
    
    /**
     * Sets the "conformanceDefinition" element
     */
    public void setConformanceDefinition(java.lang.String conformanceDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONFORMANCEDEFINITION$8);
            }
            target.setStringValue(conformanceDefinition);
        }
    }
    
    /**
     * Sets (as xml) the "conformanceDefinition" element
     */
    public void xsetConformanceDefinition(org.apache.xmlbeans.XmlString conformanceDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONFORMANCEDEFINITION$8);
            }
            target.set(conformanceDefinition);
        }
    }
    
    /**
     * Nils the "conformanceDefinition" element
     */
    public void setNilConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CONFORMANCEDEFINITION$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CONFORMANCEDEFINITION$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "conformanceDefinition" element
     */
    public void unsetConformanceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONFORMANCEDEFINITION$8, 0);
        }
    }
    
    /**
     * Gets the "serviceCategory" element
     */
    public java.lang.String getServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceCategory" element
     */
    public org.apache.xmlbeans.XmlString xgetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "serviceCategory" element
     */
    public boolean isNilServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "serviceCategory" element
     */
    public boolean isSetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICECATEGORY$10) != 0;
        }
    }
    
    /**
     * Sets the "serviceCategory" element
     */
    public void setServiceCategory(java.lang.String serviceCategory)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICECATEGORY$10);
            }
            target.setStringValue(serviceCategory);
        }
    }
    
    /**
     * Sets (as xml) the "serviceCategory" element
     */
    public void xsetServiceCategory(org.apache.xmlbeans.XmlString serviceCategory)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICECATEGORY$10);
            }
            target.set(serviceCategory);
        }
    }
    
    /**
     * Nils the "serviceCategory" element
     */
    public void setNilServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICECATEGORY$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICECATEGORY$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "serviceCategory" element
     */
    public void unsetServiceCategory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICECATEGORY$10, 0);
        }
    }
}
