/*
 * XML Type:  FdfrListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fdfr.v1.impl;
/**
 * An XML FdfrListType(@http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1).
 *
 * This is a complex type.
 */
public class FdfrListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType
{
    
    public FdfrListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FDFR$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfr/v1", "fdfr");
    
    
    /**
     * Gets a List of "fdfr" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType> getFdfrList()
    {
        final class FdfrList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType>
        {
            public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType get(int i)
                { return FdfrListTypeImpl.this.getFdfrArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType set(int i, org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType o)
            {
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType old = FdfrListTypeImpl.this.getFdfrArray(i);
                FdfrListTypeImpl.this.setFdfrArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType o)
                { FdfrListTypeImpl.this.insertNewFdfr(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType old = FdfrListTypeImpl.this.getFdfrArray(i);
                FdfrListTypeImpl.this.removeFdfr(i);
                return old;
            }
            
            public int size()
                { return FdfrListTypeImpl.this.sizeOfFdfrArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new FdfrList();
        }
    }
    
    /**
     * Gets array of all "fdfr" elements
     */
    public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType[] getFdfrArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(FDFR$0, targetList);
            org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType[] result = new org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "fdfr" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType getFdfrArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().find_element_user(FDFR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "fdfr" element
     */
    public int sizeOfFdfrArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDFR$0);
        }
    }
    
    /**
     * Sets array of all "fdfr" element
     */
    public void setFdfrArray(org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType[] fdfrArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(fdfrArray, FDFR$0);
        }
    }
    
    /**
     * Sets ith "fdfr" element
     */
    public void setFdfrArray(int i, org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType fdfr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().find_element_user(FDFR$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(fdfr);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "fdfr" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType insertNewFdfr(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().insert_element_user(FDFR$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "fdfr" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType addNewFdfr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().add_element_user(FDFR$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "fdfr" element
     */
    public void removeFdfr(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDFR$0, i);
        }
    }
}
