/*
 * XML Type:  FloatingTerminationPointListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/ftp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.ftp.v1.impl;
/**
 * An XML FloatingTerminationPointListType(@http://www.tmforum.org/mtop/nrf/xsd/ftp/v1).
 *
 * This is a complex type.
 */
public class FloatingTerminationPointListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointListType
{
    
    public FloatingTerminationPointListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ftp/v1", "ftp");
    
    
    /**
     * Gets a List of "ftp" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType> getFtpList()
    {
        final class FtpList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType>
        {
            public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType get(int i)
                { return FloatingTerminationPointListTypeImpl.this.getFtpArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType set(int i, org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType o)
            {
                org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType old = FloatingTerminationPointListTypeImpl.this.getFtpArray(i);
                FloatingTerminationPointListTypeImpl.this.setFtpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType o)
                { FloatingTerminationPointListTypeImpl.this.insertNewFtp(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType old = FloatingTerminationPointListTypeImpl.this.getFtpArray(i);
                FloatingTerminationPointListTypeImpl.this.removeFtp(i);
                return old;
            }
            
            public int size()
                { return FloatingTerminationPointListTypeImpl.this.sizeOfFtpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new FtpList();
        }
    }
    
    /**
     * Gets array of all "ftp" elements
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType[] getFtpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(FTP$0, targetList);
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType[] result = new org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "ftp" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType getFtpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().find_element_user(FTP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "ftp" element
     */
    public int sizeOfFtpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FTP$0);
        }
    }
    
    /**
     * Sets array of all "ftp" element
     */
    public void setFtpArray(org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType[] ftpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(ftpArray, FTP$0);
        }
    }
    
    /**
     * Sets ith "ftp" element
     */
    public void setFtpArray(int i, org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType ftp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().find_element_user(FTP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(ftp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "ftp" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType insertNewFtp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().insert_element_user(FTP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "ftp" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType addNewFtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().add_element_user(FTP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "ftp" element
     */
    public void removeFtp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FTP$0, i);
        }
    }
}
