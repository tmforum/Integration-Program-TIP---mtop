/*
 * XML Type:  RouteCreateDataType
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * An XML RouteCreateDataType(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
 *
 * This is a complex type.
 */
public class RouteCreateDataTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType
{
    
    public RouteCreateDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INTENDED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "intended");
    private static final javax.xml.namespace.QName EXCLUSIVE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "exclusive");
    private static final javax.xml.namespace.QName CCINCLUSIONLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "ccInclusionList");
    private static final javax.xml.namespace.QName INCLUSIONREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "inclusionRefList");
    private static final javax.xml.namespace.QName ISFULLROUTE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "isFullRoute");
    private static final javax.xml.namespace.QName EXCLUSIONREFLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "exclusionRefList");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "vendorExtensions");
    
    
    /**
     * Gets the "intended" element
     */
    public java.lang.String getIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDED$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "intended" element
     */
    public org.apache.xmlbeans.XmlString xgetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDED$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "intended" element
     */
    public boolean isSetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTENDED$0) != 0;
        }
    }
    
    /**
     * Sets the "intended" element
     */
    public void setIntended(java.lang.String intended)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTENDED$0);
            }
            target.setStringValue(intended);
        }
    }
    
    /**
     * Sets (as xml) the "intended" element
     */
    public void xsetIntended(org.apache.xmlbeans.XmlString intended)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INTENDED$0);
            }
            target.set(intended);
        }
    }
    
    /**
     * Unsets the "intended" element
     */
    public void unsetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTENDED$0, 0);
        }
    }
    
    /**
     * Gets the "exclusive" element
     */
    public java.lang.String getExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXCLUSIVE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "exclusive" element
     */
    public org.apache.xmlbeans.XmlString xgetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXCLUSIVE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "exclusive" element
     */
    public boolean isSetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXCLUSIVE$2) != 0;
        }
    }
    
    /**
     * Sets the "exclusive" element
     */
    public void setExclusive(java.lang.String exclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXCLUSIVE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXCLUSIVE$2);
            }
            target.setStringValue(exclusive);
        }
    }
    
    /**
     * Sets (as xml) the "exclusive" element
     */
    public void xsetExclusive(org.apache.xmlbeans.XmlString exclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXCLUSIVE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EXCLUSIVE$2);
            }
            target.set(exclusive);
        }
    }
    
    /**
     * Unsets the "exclusive" element
     */
    public void unsetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXCLUSIVE$2, 0);
        }
    }
    
    /**
     * Gets the "ccInclusionList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType getCcInclusionList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCINCLUSIONLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ccInclusionList" element
     */
    public boolean isSetCcInclusionList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CCINCLUSIONLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "ccInclusionList" element
     */
    public void setCcInclusionList(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType ccInclusionList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCINCLUSIONLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCINCLUSIONLIST$4);
            }
            target.set(ccInclusionList);
        }
    }
    
    /**
     * Appends and returns a new empty "ccInclusionList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType addNewCcInclusionList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCINCLUSIONLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ccInclusionList" element
     */
    public void unsetCcInclusionList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CCINCLUSIONLIST$4, 0);
        }
    }
    
    /**
     * Gets the "inclusionRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getInclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INCLUSIONREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "inclusionRefList" element
     */
    public boolean isSetInclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INCLUSIONREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "inclusionRefList" element
     */
    public void setInclusionRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType inclusionRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INCLUSIONREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INCLUSIONREFLIST$6);
            }
            target.set(inclusionRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "inclusionRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewInclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INCLUSIONREFLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "inclusionRefList" element
     */
    public void unsetInclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INCLUSIONREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "isFullRoute" element
     */
    public boolean getIsFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFULLROUTE$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isFullRoute" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFULLROUTE$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "isFullRoute" element
     */
    public boolean isSetIsFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISFULLROUTE$8) != 0;
        }
    }
    
    /**
     * Sets the "isFullRoute" element
     */
    public void setIsFullRoute(boolean isFullRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFULLROUTE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISFULLROUTE$8);
            }
            target.setBooleanValue(isFullRoute);
        }
    }
    
    /**
     * Sets (as xml) the "isFullRoute" element
     */
    public void xsetIsFullRoute(org.apache.xmlbeans.XmlBoolean isFullRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFULLROUTE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISFULLROUTE$8);
            }
            target.set(isFullRoute);
        }
    }
    
    /**
     * Unsets the "isFullRoute" element
     */
    public void unsetIsFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISFULLROUTE$8, 0);
        }
    }
    
    /**
     * Gets the "exclusionRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getExclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(EXCLUSIONREFLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "exclusionRefList" element
     */
    public boolean isSetExclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXCLUSIONREFLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "exclusionRefList" element
     */
    public void setExclusionRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType exclusionRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(EXCLUSIONREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(EXCLUSIONREFLIST$10);
            }
            target.set(exclusionRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "exclusionRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewExclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(EXCLUSIONREFLIST$10);
            return target;
        }
    }
    
    /**
     * Unsets the "exclusionRefList" element
     */
    public void unsetExclusionRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXCLUSIONREFLIST$10, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$12) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$12);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$12);
            return target;
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$12, 0);
        }
    }
}
