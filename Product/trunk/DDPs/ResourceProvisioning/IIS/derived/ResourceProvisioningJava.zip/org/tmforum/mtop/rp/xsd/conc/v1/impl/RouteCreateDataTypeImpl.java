/*
 * XML Type:  RouteCreateDataType
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * An XML RouteCreateDataType(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
 *
 * This is a complex type.
 */
public class RouteCreateDataTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType
{
    
    public RouteCreateDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INTENDED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "intended");
    private static final javax.xml.namespace.QName EXCLUSIVE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "exclusive");
    private static final javax.xml.namespace.QName CCINCLUSIONS$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "ccInclusions");
    private static final javax.xml.namespace.QName NETPINCLUSIONS$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "neTpInclusions");
    private static final javax.xml.namespace.QName FULLROUTE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "fullRoute");
    private static final javax.xml.namespace.QName NETPSNCEXCLUSIONS$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "neTpSncExclusions");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "vendorExtensions");
    
    
    /**
     * Gets the "intended" element
     */
    public java.lang.String getIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDED$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "intended" element
     */
    public org.apache.xmlbeans.XmlString xgetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDED$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "intended" element
     */
    public boolean isSetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTENDED$0) != 0;
        }
    }
    
    /**
     * Sets the "intended" element
     */
    public void setIntended(java.lang.String intended)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTENDED$0);
            }
            target.setStringValue(intended);
        }
    }
    
    /**
     * Sets (as xml) the "intended" element
     */
    public void xsetIntended(org.apache.xmlbeans.XmlString intended)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INTENDED$0);
            }
            target.set(intended);
        }
    }
    
    /**
     * Unsets the "intended" element
     */
    public void unsetIntended()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTENDED$0, 0);
        }
    }
    
    /**
     * Gets the "exclusive" element
     */
    public java.lang.String getExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXCLUSIVE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "exclusive" element
     */
    public org.apache.xmlbeans.XmlString xgetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXCLUSIVE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "exclusive" element
     */
    public boolean isSetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXCLUSIVE$2) != 0;
        }
    }
    
    /**
     * Sets the "exclusive" element
     */
    public void setExclusive(java.lang.String exclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXCLUSIVE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXCLUSIVE$2);
            }
            target.setStringValue(exclusive);
        }
    }
    
    /**
     * Sets (as xml) the "exclusive" element
     */
    public void xsetExclusive(org.apache.xmlbeans.XmlString exclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EXCLUSIVE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EXCLUSIVE$2);
            }
            target.set(exclusive);
        }
    }
    
    /**
     * Unsets the "exclusive" element
     */
    public void unsetExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXCLUSIVE$2, 0);
        }
    }
    
    /**
     * Gets the "ccInclusions" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType getCcInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCINCLUSIONS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ccInclusions" element
     */
    public boolean isSetCcInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CCINCLUSIONS$4) != 0;
        }
    }
    
    /**
     * Sets the "ccInclusions" element
     */
    public void setCcInclusions(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType ccInclusions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCINCLUSIONS$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCINCLUSIONS$4);
            }
            target.set(ccInclusions);
        }
    }
    
    /**
     * Appends and returns a new empty "ccInclusions" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType addNewCcInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCINCLUSIONS$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ccInclusions" element
     */
    public void unsetCcInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CCINCLUSIONS$4, 0);
        }
    }
    
    /**
     * Gets the "neTpInclusions" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getNeTpInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NETPINCLUSIONS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "neTpInclusions" element
     */
    public boolean isSetNeTpInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETPINCLUSIONS$6) != 0;
        }
    }
    
    /**
     * Sets the "neTpInclusions" element
     */
    public void setNeTpInclusions(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType neTpInclusions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NETPINCLUSIONS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NETPINCLUSIONS$6);
            }
            target.set(neTpInclusions);
        }
    }
    
    /**
     * Appends and returns a new empty "neTpInclusions" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewNeTpInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NETPINCLUSIONS$6);
            return target;
        }
    }
    
    /**
     * Unsets the "neTpInclusions" element
     */
    public void unsetNeTpInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETPINCLUSIONS$6, 0);
        }
    }
    
    /**
     * Gets the "fullRoute" element
     */
    public boolean getFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FULLROUTE$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "fullRoute" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FULLROUTE$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "fullRoute" element
     */
    public void setFullRoute(boolean fullRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FULLROUTE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FULLROUTE$8);
            }
            target.setBooleanValue(fullRoute);
        }
    }
    
    /**
     * Sets (as xml) the "fullRoute" element
     */
    public void xsetFullRoute(org.apache.xmlbeans.XmlBoolean fullRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FULLROUTE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FULLROUTE$8);
            }
            target.set(fullRoute);
        }
    }
    
    /**
     * Gets the "neTpSncExclusions" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getNeTpSncExclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NETPSNCEXCLUSIONS$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "neTpSncExclusions" element
     */
    public boolean isSetNeTpSncExclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETPSNCEXCLUSIONS$10) != 0;
        }
    }
    
    /**
     * Sets the "neTpSncExclusions" element
     */
    public void setNeTpSncExclusions(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType neTpSncExclusions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NETPSNCEXCLUSIONS$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NETPSNCEXCLUSIONS$10);
            }
            target.set(neTpSncExclusions);
        }
    }
    
    /**
     * Appends and returns a new empty "neTpSncExclusions" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewNeTpSncExclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NETPSNCEXCLUSIONS$10);
            return target;
        }
    }
    
    /**
     * Unsets the "neTpSncExclusions" element
     */
    public void unsetNeTpSncExclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETPSNCEXCLUSIONS$10, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions)get_store().add_element_user(VENDOREXTENSIONS$12);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions)get_store().add_element_user(VENDOREXTENSIONS$12);
            return target;
        }
    }
    /**
     * An XML vendorExtensions(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class VendorExtensionsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.RouteCreateDataType.VendorExtensions
    {
        
        public VendorExtensionsImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
