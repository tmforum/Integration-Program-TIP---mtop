/*
 * An XML document type.
 * Localname: checkValidSncException
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one checkValidSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CheckValidSncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument
{
    
    public CheckValidSncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CHECKVALIDSNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "checkValidSncException");
    
    
    /**
     * Gets the "checkValidSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException getCheckValidSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException)get_store().find_element_user(CHECKVALIDSNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "checkValidSncException" element
     */
    public void setCheckValidSncException(org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException checkValidSncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException)get_store().find_element_user(CHECKVALIDSNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException)get_store().add_element_user(CHECKVALIDSNCEXCEPTION$0);
            }
            target.set(checkValidSncException);
        }
    }
    
    /**
     * Appends and returns a new empty "checkValidSncException" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException addNewCheckValidSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException)get_store().add_element_user(CHECKVALIDSNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML checkValidSncException(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CheckValidSncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CheckValidSncExceptionDocument.CheckValidSncException
    {
        
        public CheckValidSncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
