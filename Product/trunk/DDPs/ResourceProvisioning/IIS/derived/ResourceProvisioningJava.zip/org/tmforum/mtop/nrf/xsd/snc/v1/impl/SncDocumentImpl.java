/*
 * An XML document type.
 * Localname: snc
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/snc/v1
 * Java type: org.tmforum.mtop.nrf.xsd.snc.v1.SncDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.snc.v1.impl;
/**
 * A document containing one snc(@http://www.tmforum.org/mtop/nrf/xsd/snc/v1) element.
 *
 * This is a complex type.
 */
public class SncDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.snc.v1.SncDocument
{
    
    public SncDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SNC$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/snc/v1", "snc");
    
    
    /**
     * Gets the "snc" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getSnc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "snc" element
     */
    public void setSnc(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType snc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNC$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNC$0);
            }
            target.set(snc);
        }
    }
    
    /**
     * Appends and returns a new empty "snc" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewSnc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNC$0);
            return target;
        }
    }
}
