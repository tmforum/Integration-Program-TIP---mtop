/*
 * XML Type:  TerminationPointDataType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tpdata.v1;


/**
 * An XML TerminationPointDataType(@http://www.tmforum.org/mtop/nrf/xsd/tpdata/v1).
 *
 * This is a complex type.
 */
public interface TerminationPointDataType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TerminationPointDataType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s732E47122B99A5ED8D93FEE82721A56B").resolveHandle("terminationpointdatatype385dtype");
    
    /**
     * Gets the "tpName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getTpName();
    
    /**
     * Sets the "tpName" element
     */
    void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType tpName);
    
    /**
     * Appends and returns a new empty "tpName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewTpName();
    
    /**
     * Gets the "tpMappingMode" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum getTpMappingMode();
    
    /**
     * Gets (as xml) the "tpMappingMode" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType xgetTpMappingMode();
    
    /**
     * Tests for nil "tpMappingMode" element
     */
    boolean isNilTpMappingMode();
    
    /**
     * True if has "tpMappingMode" element
     */
    boolean isSetTpMappingMode();
    
    /**
     * Sets the "tpMappingMode" element
     */
    void setTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType.Enum tpMappingMode);
    
    /**
     * Sets (as xml) the "tpMappingMode" element
     */
    void xsetTpMappingMode(org.tmforum.mtop.nrf.xsd.com.v1.TerminationModeType tpMappingMode);
    
    /**
     * Nils the "tpMappingMode" element
     */
    void setNilTpMappingMode();
    
    /**
     * Unsets the "tpMappingMode" element
     */
    void unsetTpMappingMode();
    
    /**
     * Gets the "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList();
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    boolean isNilTransmissionParameterList();
    
    /**
     * True if has "transmissionParameterList" element
     */
    boolean isSetTransmissionParameterList();
    
    /**
     * Sets the "transmissionParameterList" element
     */
    void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList);
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList();
    
    /**
     * Nils the "transmissionParameterList" element
     */
    void setNilTransmissionParameterList();
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    void unsetTransmissionParameterList();
    
    /**
     * Gets the "ingressTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getIngressTmdRef();
    
    /**
     * Tests for nil "ingressTmdRef" element
     */
    boolean isNilIngressTmdRef();
    
    /**
     * True if has "ingressTmdRef" element
     */
    boolean isSetIngressTmdRef();
    
    /**
     * Sets the "ingressTmdRef" element
     */
    void setIngressTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType ingressTmdRef);
    
    /**
     * Appends and returns a new empty "ingressTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewIngressTmdRef();
    
    /**
     * Nils the "ingressTmdRef" element
     */
    void setNilIngressTmdRef();
    
    /**
     * Unsets the "ingressTmdRef" element
     */
    void unsetIngressTmdRef();
    
    /**
     * Gets the "egressTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEgressTmdRef();
    
    /**
     * Tests for nil "egressTmdRef" element
     */
    boolean isNilEgressTmdRef();
    
    /**
     * True if has "egressTmdRef" element
     */
    boolean isSetEgressTmdRef();
    
    /**
     * Sets the "egressTmdRef" element
     */
    void setEgressTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType egressTmdRef);
    
    /**
     * Appends and returns a new empty "egressTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEgressTmdRef();
    
    /**
     * Nils the "egressTmdRef" element
     */
    void setNilEgressTmdRef();
    
    /**
     * Unsets the "egressTmdRef" element
     */
    void unsetEgressTmdRef();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
