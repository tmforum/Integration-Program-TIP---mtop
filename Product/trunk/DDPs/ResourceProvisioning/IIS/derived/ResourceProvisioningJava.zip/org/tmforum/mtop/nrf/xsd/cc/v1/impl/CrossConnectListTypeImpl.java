/*
 * XML Type:  CrossConnectListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/cc/v1
 * Java type: org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.cc.v1.impl;
/**
 * An XML CrossConnectListType(@http://www.tmforum.org/mtop/nrf/xsd/cc/v1).
 *
 * This is a complex type.
 */
public class CrossConnectListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType
{
    
    public CrossConnectListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CC$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/cc/v1", "cc");
    
    
    /**
     * Gets a List of "cc" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType> getCcList()
    {
        final class CcList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType>
        {
            public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType get(int i)
                { return CrossConnectListTypeImpl.this.getCcArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType set(int i, org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType o)
            {
                org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType old = CrossConnectListTypeImpl.this.getCcArray(i);
                CrossConnectListTypeImpl.this.setCcArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType o)
                { CrossConnectListTypeImpl.this.insertNewCc(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType old = CrossConnectListTypeImpl.this.getCcArray(i);
                CrossConnectListTypeImpl.this.removeCc(i);
                return old;
            }
            
            public int size()
                { return CrossConnectListTypeImpl.this.sizeOfCcArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CcList();
        }
    }
    
    /**
     * Gets array of all "cc" elements
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType[] getCcArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CC$0, targetList);
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType[] result = new org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "cc" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType getCcArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType)get_store().find_element_user(CC$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "cc" element
     */
    public int sizeOfCcArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CC$0);
        }
    }
    
    /**
     * Sets array of all "cc" element
     */
    public void setCcArray(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType[] ccArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(ccArray, CC$0);
        }
    }
    
    /**
     * Sets ith "cc" element
     */
    public void setCcArray(int i, org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType cc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType)get_store().find_element_user(CC$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(cc);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "cc" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType insertNewCc(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType)get_store().insert_element_user(CC$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "cc" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType addNewCc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectType)get_store().add_element_user(CC$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "cc" element
     */
    public void removeCc(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CC$0, i);
        }
    }
}
