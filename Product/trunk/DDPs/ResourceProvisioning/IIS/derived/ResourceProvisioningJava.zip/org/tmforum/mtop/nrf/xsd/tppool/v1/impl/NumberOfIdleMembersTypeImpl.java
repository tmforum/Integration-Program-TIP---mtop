/*
 * XML Type:  NumberOfIdleMembersType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tppool/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfIdleMembersType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tppool.v1.impl;
/**
 * An XML NumberOfIdleMembersType(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfIdleMembersType.
 */
public class NumberOfIdleMembersTypeImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.tmforum.mtop.nrf.xsd.tppool.v1.NumberOfIdleMembersType
{
    
    public NumberOfIdleMembersTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected NumberOfIdleMembersTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
