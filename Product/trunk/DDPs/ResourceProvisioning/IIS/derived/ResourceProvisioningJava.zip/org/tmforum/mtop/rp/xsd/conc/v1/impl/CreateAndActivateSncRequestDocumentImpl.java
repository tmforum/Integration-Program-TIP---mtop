/*
 * An XML document type.
 * Localname: createAndActivateSncRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one createAndActivateSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAndActivateSncRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument
{
    
    public CreateAndActivateSncRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEANDACTIVATESNCREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createAndActivateSncRequest");
    
    
    /**
     * Gets the "createAndActivateSncRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest getCreateAndActivateSncRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest)get_store().find_element_user(CREATEANDACTIVATESNCREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAndActivateSncRequest" element
     */
    public void setCreateAndActivateSncRequest(org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest createAndActivateSncRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest)get_store().find_element_user(CREATEANDACTIVATESNCREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest)get_store().add_element_user(CREATEANDACTIVATESNCREQUEST$0);
            }
            target.set(createAndActivateSncRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "createAndActivateSncRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest addNewCreateAndActivateSncRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest)get_store().add_element_user(CREATEANDACTIVATESNCREQUEST$0);
            return target;
        }
    }
    /**
     * An XML createAndActivateSncRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAndActivateSncRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.CreateAndActivateSncRequestDocument.CreateAndActivateSncRequest
    {
        
        public CreateAndActivateSncRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CREATEDATA$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "createData");
        private static final javax.xml.namespace.QName TOLERABLEIMPACT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tolerableImpact");
        private static final javax.xml.namespace.QName OSFREEDOMLEVEL$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "osFreedomLevel");
        private static final javax.xml.namespace.QName TPSTOMODIFY$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpsToModify");
        
        
        /**
         * Gets the "createData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType getCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType)get_store().find_element_user(CREATEDATA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "createData" element
         */
        public boolean isSetCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CREATEDATA$0) != 0;
            }
        }
        
        /**
         * Sets the "createData" element
         */
        public void setCreateData(org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType createData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType)get_store().find_element_user(CREATEDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType)get_store().add_element_user(CREATEDATA$0);
                }
                target.set(createData);
            }
        }
        
        /**
         * Appends and returns a new empty "createData" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType addNewCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType)get_store().add_element_user(CREATEDATA$0);
                return target;
            }
        }
        
        /**
         * Unsets the "createData" element
         */
        public void unsetCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CREATEDATA$0, 0);
            }
        }
        
        /**
         * Gets the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "tolerableImpact" element
         */
        public boolean isSetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOLERABLEIMPACT$2) != 0;
            }
        }
        
        /**
         * Sets the "tolerableImpact" element
         */
        public void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOLERABLEIMPACT$2);
                }
                target.setEnumValue(tolerableImpact);
            }
        }
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        public void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().add_element_user(TOLERABLEIMPACT$2);
                }
                target.set(tolerableImpact);
            }
        }
        
        /**
         * Unsets the "tolerableImpact" element
         */
        public void unsetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOLERABLEIMPACT$2, 0);
            }
        }
        
        /**
         * Gets the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum getOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType xgetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "osFreedomLevel" element
         */
        public boolean isSetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OSFREEDOMLEVEL$4) != 0;
            }
        }
        
        /**
         * Sets the "osFreedomLevel" element
         */
        public void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType.Enum osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSFREEDOMLEVEL$4);
                }
                target.setEnumValue(osFreedomLevel);
            }
        }
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        public void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.OsFreedomLevelType)get_store().add_element_user(OSFREEDOMLEVEL$4);
                }
                target.set(osFreedomLevel);
            }
        }
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        public void unsetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OSFREEDOMLEVEL$4, 0);
            }
        }
        
        /**
         * Gets the "tpsToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType getTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(TPSTOMODIFY$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpsToModify" element
         */
        public boolean isSetTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPSTOMODIFY$6) != 0;
            }
        }
        
        /**
         * Sets the "tpsToModify" element
         */
        public void setTpsToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType tpsToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().find_element_user(TPSTOMODIFY$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(TPSTOMODIFY$6);
                }
                target.set(tpsToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpsToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType addNewTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TpDataListType)get_store().add_element_user(TPSTOMODIFY$6);
                return target;
            }
        }
        
        /**
         * Unsets the "tpsToModify" element
         */
        public void unsetTpsToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPSTOMODIFY$6, 0);
            }
        }
    }
}
