/*
 * An XML document type.
 * Localname: deleteSubnetworkConnectionResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one deleteSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class DeleteSubnetworkConnectionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument
{
    
    public DeleteSubnetworkConnectionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETESUBNETWORKCONNECTIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "deleteSubnetworkConnectionResponse");
    
    
    /**
     * Gets the "deleteSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse getDeleteSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse)get_store().find_element_user(DELETESUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteSubnetworkConnectionResponse" element
     */
    public void setDeleteSubnetworkConnectionResponse(org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse deleteSubnetworkConnectionResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse)get_store().find_element_user(DELETESUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse)get_store().add_element_user(DELETESUBNETWORKCONNECTIONRESPONSE$0);
            }
            target.set(deleteSubnetworkConnectionResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse addNewDeleteSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse)get_store().add_element_user(DELETESUBNETWORKCONNECTIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML deleteSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class DeleteSubnetworkConnectionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeleteSubnetworkConnectionResponseDocument.DeleteSubnetworkConnectionResponse
    {
        
        public DeleteSubnetworkConnectionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
