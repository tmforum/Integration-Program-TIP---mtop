/*
 * XML Type:  CompressionEnumType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/hdr/v1
 * Java type: org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.hdr.v1.impl;
/**
 * An XML CompressionEnumType(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionEnumType.
 */
public class CompressionEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionEnumType
{
    
    public CompressionEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected CompressionEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
