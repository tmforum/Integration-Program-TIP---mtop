/*
 * An XML document type.
 * Localname: setIntendedRouteResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one setIntendedRouteResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SetIntendedRouteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument
{
    
    public SetIntendedRouteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETINTENDEDROUTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "setIntendedRouteResponse");
    
    
    /**
     * Gets the "setIntendedRouteResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse getSetIntendedRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse)get_store().find_element_user(SETINTENDEDROUTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setIntendedRouteResponse" element
     */
    public void setSetIntendedRouteResponse(org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse setIntendedRouteResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse)get_store().find_element_user(SETINTENDEDROUTERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse)get_store().add_element_user(SETINTENDEDROUTERESPONSE$0);
            }
            target.set(setIntendedRouteResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setIntendedRouteResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse addNewSetIntendedRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse)get_store().add_element_user(SETINTENDEDROUTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setIntendedRouteResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SetIntendedRouteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse
    {
        
        public SetIntendedRouteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "vendorExtensions");
        
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions target = null;
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions)get_store().add_element_user(VENDOREXTENSIONS$0);
                return target;
            }
        }
        /**
         * An XML vendorExtensions(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
         *
         * This is a complex type.
         */
        public static class VendorExtensionsImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse.VendorExtensions
        {
            
            public VendorExtensionsImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            
        }
    }
}
