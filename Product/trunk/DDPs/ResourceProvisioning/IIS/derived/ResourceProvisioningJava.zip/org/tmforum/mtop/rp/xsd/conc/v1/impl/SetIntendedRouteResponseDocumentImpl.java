/*
 * An XML document type.
 * Localname: setIntendedRouteResponse
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one setIntendedRouteResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SetIntendedRouteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument
{
    
    public SetIntendedRouteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETINTENDEDROUTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "setIntendedRouteResponse");
    
    
    /**
     * Gets the "setIntendedRouteResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse getSetIntendedRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse)get_store().find_element_user(SETINTENDEDROUTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setIntendedRouteResponse" element
     */
    public void setSetIntendedRouteResponse(org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse setIntendedRouteResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse)get_store().find_element_user(SETINTENDEDROUTERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse)get_store().add_element_user(SETINTENDEDROUTERESPONSE$0);
            }
            target.set(setIntendedRouteResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setIntendedRouteResponse" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse addNewSetIntendedRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse)get_store().add_element_user(SETINTENDEDROUTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setIntendedRouteResponse(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SetIntendedRouteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SetIntendedRouteResponseDocument.SetIntendedRouteResponse
    {
        
        public SetIntendedRouteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "vendorExtensions");
        
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$0) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                return target;
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$0, 0);
            }
        }
    }
}
