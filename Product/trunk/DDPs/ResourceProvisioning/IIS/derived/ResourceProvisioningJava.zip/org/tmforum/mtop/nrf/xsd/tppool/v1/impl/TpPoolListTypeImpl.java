/*
 * XML Type:  TpPoolListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tppool/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tppool.v1.impl;
/**
 * An XML TpPoolListType(@http://www.tmforum.org/mtop/nrf/xsd/tppool/v1).
 *
 * This is a complex type.
 */
public class TpPoolListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolListType
{
    
    public TpPoolListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPPOOL$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/tppool/v1", "tpPool");
    
    
    /**
     * Gets a List of "tpPool" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType> getTpPoolList()
    {
        final class TpPoolList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType>
        {
            public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType get(int i)
                { return TpPoolListTypeImpl.this.getTpPoolArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType set(int i, org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType o)
            {
                org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType old = TpPoolListTypeImpl.this.getTpPoolArray(i);
                TpPoolListTypeImpl.this.setTpPoolArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType o)
                { TpPoolListTypeImpl.this.insertNewTpPool(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType old = TpPoolListTypeImpl.this.getTpPoolArray(i);
                TpPoolListTypeImpl.this.removeTpPool(i);
                return old;
            }
            
            public int size()
                { return TpPoolListTypeImpl.this.sizeOfTpPoolArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TpPoolList();
        }
    }
    
    /**
     * Gets array of all "tpPool" elements
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType[] getTpPoolArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TPPOOL$0, targetList);
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType[] result = new org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "tpPool" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType getTpPoolArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType)get_store().find_element_user(TPPOOL$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "tpPool" element
     */
    public int sizeOfTpPoolArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPPOOL$0);
        }
    }
    
    /**
     * Sets array of all "tpPool" element
     */
    public void setTpPoolArray(org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType[] tpPoolArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(tpPoolArray, TPPOOL$0);
        }
    }
    
    /**
     * Sets ith "tpPool" element
     */
    public void setTpPoolArray(int i, org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType tpPool)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType)get_store().find_element_user(TPPOOL$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(tpPool);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tpPool" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType insertNewTpPool(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType)get_store().insert_element_user(TPPOOL$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tpPool" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType addNewTpPool()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TpPoolType)get_store().add_element_user(TPPOOL$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "tpPool" element
     */
    public void removeTpPool(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPPOOL$0, i);
        }
    }
}
