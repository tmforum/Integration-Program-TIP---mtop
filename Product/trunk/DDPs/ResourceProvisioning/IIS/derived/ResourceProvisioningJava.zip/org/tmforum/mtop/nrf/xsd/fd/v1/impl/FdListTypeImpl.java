/*
 * XML Type:  FdListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fd.v1.FdListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fd.v1.impl;
/**
 * An XML FdListType(@http://www.tmforum.org/mtop/nrf/xsd/fd/v1).
 *
 * This is a complex type.
 */
public class FdListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.fd.v1.FdListType
{
    
    public FdListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fd/v1", "fd");
    
    
    /**
     * Gets a List of "fd" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType> getFdList()
    {
        final class FdList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType>
        {
            public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType get(int i)
                { return FdListTypeImpl.this.getFdArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType set(int i, org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType o)
            {
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType old = FdListTypeImpl.this.getFdArray(i);
                FdListTypeImpl.this.setFdArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType o)
                { FdListTypeImpl.this.insertNewFd(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType old = FdListTypeImpl.this.getFdArray(i);
                FdListTypeImpl.this.removeFd(i);
                return old;
            }
            
            public int size()
                { return FdListTypeImpl.this.sizeOfFdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new FdList();
        }
    }
    
    /**
     * Gets array of all "fd" elements
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType[] getFdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(FD$0, targetList);
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType[] result = new org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "fd" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType getFdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "fd" element
     */
    public int sizeOfFdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FD$0);
        }
    }
    
    /**
     * Sets array of all "fd" element
     */
    public void setFdArray(org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType[] fdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(fdArray, FD$0);
        }
    }
    
    /**
     * Sets ith "fd" element
     */
    public void setFdArray(int i, org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType fd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(fd);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "fd" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType insertNewFd(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().insert_element_user(FD$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "fd" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType addNewFd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FD$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "fd" element
     */
    public void removeFd(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FD$0, i);
        }
    }
}
