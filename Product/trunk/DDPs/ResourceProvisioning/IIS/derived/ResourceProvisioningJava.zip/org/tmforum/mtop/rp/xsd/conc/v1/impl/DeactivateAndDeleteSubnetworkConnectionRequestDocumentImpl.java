/*
 * An XML document type.
 * Localname: deactivateAndDeleteSubnetworkConnectionRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one deactivateAndDeleteSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class DeactivateAndDeleteSubnetworkConnectionRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument
{
    
    public DeactivateAndDeleteSubnetworkConnectionRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DEACTIVATEANDDELETESUBNETWORKCONNECTIONREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "deactivateAndDeleteSubnetworkConnectionRequest");
    
    
    /**
     * Gets the "deactivateAndDeleteSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest getDeactivateAndDeleteSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest)get_store().find_element_user(DEACTIVATEANDDELETESUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deactivateAndDeleteSubnetworkConnectionRequest" element
     */
    public void setDeactivateAndDeleteSubnetworkConnectionRequest(org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest deactivateAndDeleteSubnetworkConnectionRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest)get_store().find_element_user(DEACTIVATEANDDELETESUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest)get_store().add_element_user(DEACTIVATEANDDELETESUBNETWORKCONNECTIONREQUEST$0);
            }
            target.set(deactivateAndDeleteSubnetworkConnectionRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "deactivateAndDeleteSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest addNewDeactivateAndDeleteSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest)get_store().add_element_user(DEACTIVATEANDDELETESUBNETWORKCONNECTIONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML deactivateAndDeleteSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class DeactivateAndDeleteSubnetworkConnectionRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.DeactivateAndDeleteSubnetworkConnectionRequestDocument.DeactivateAndDeleteSubnetworkConnectionRequest
    {
        
        public DeactivateAndDeleteSubnetworkConnectionRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNCNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "sncName");
        private static final javax.xml.namespace.QName TOLERABLEIMPACT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tolerableImpact");
        private static final javax.xml.namespace.QName OSFREEDOMLEVEL$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "osFreedomLevel");
        private static final javax.xml.namespace.QName TPDATALISTTOMODIFY$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "TpDataListToModify");
        
        
        /**
         * Gets the "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "sncName" element
         */
        public boolean isSetSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNCNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "sncName" element
         */
        public void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType sncName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SNCNAME$0);
                }
                target.set(sncName);
            }
        }
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SNCNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "sncName" element
         */
        public void unsetSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNCNAME$0, 0);
            }
        }
        
        /**
         * Gets the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "tolerableImpact" element
         */
        public boolean isSetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOLERABLEIMPACT$2) != 0;
            }
        }
        
        /**
         * Sets the "tolerableImpact" element
         */
        public void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOLERABLEIMPACT$2);
                }
                target.setEnumValue(tolerableImpact);
            }
        }
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        public void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().add_element_user(TOLERABLEIMPACT$2);
                }
                target.set(tolerableImpact);
            }
        }
        
        /**
         * Unsets the "tolerableImpact" element
         */
        public void unsetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOLERABLEIMPACT$2, 0);
            }
        }
        
        /**
         * Gets the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum getOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType xgetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "osFreedomLevel" element
         */
        public boolean isSetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OSFREEDOMLEVEL$4) != 0;
            }
        }
        
        /**
         * Sets the "osFreedomLevel" element
         */
        public void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSFREEDOMLEVEL$4);
                }
                target.setEnumValue(osFreedomLevel);
            }
        }
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        public void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().add_element_user(OSFREEDOMLEVEL$4);
                }
                target.set(osFreedomLevel);
            }
        }
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        public void unsetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OSFREEDOMLEVEL$4, 0);
            }
        }
        
        /**
         * Gets the "TpDataListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPDATALISTTOMODIFY$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "TpDataListToModify" element
         */
        public boolean isSetTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPDATALISTTOMODIFY$6) != 0;
            }
        }
        
        /**
         * Sets the "TpDataListToModify" element
         */
        public void setTpDataListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpDataListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPDATALISTTOMODIFY$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPDATALISTTOMODIFY$6);
                }
                target.set(tpDataListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "TpDataListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPDATALISTTOMODIFY$6);
                return target;
            }
        }
        
        /**
         * Unsets the "TpDataListToModify" element
         */
        public void unsetTpDataListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPDATALISTTOMODIFY$6, 0);
            }
        }
    }
}
