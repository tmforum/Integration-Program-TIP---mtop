/*
 * XML Type:  SncCreateDataType
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * An XML SncCreateDataType(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
 *
 * This is a complex type.
 */
public class SncCreateDataTypeImpl extends org.tmforum.mtop.nrb.xsd.crcd.v1.impl.CommonResourceCreateDataTypeImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType
{
    
    public SncCreateDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DIRECTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "direction");
    private static final javax.xml.namespace.QName STATICPROTECTIONLEVEL$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "staticProtectionLevel");
    private static final javax.xml.namespace.QName PROTECTIONEFFORT$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "protectionEffort");
    private static final javax.xml.namespace.QName REROUTEALLOWED$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "rerouteAllowed");
    private static final javax.xml.namespace.QName NETWORKROUTED$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "networkRouted");
    private static final javax.xml.namespace.QName SNCTYPE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "sncType");
    private static final javax.xml.namespace.QName LAYERRATE$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "layerRate");
    private static final javax.xml.namespace.QName CCINCLUSIONS$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "ccInclusions");
    private static final javax.xml.namespace.QName NETPINCLUSIONS$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "neTpInclusions");
    private static final javax.xml.namespace.QName FULLROUTE$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "fullRoute");
    private static final javax.xml.namespace.QName NETPSNCEXCLUSIONS$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "neTpSncExclusions");
    private static final javax.xml.namespace.QName AEND$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "aEnd");
    private static final javax.xml.namespace.QName ZEND$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "zEnd");
    private static final javax.xml.namespace.QName AROLES$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "aRoles");
    private static final javax.xml.namespace.QName ALARMREPORTINGINDICATOR$28 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "alarmReportingIndicator");
    private static final javax.xml.namespace.QName NETWORKREROUTE$30 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "networkReroute");
    private static final javax.xml.namespace.QName REVERTIVE$32 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "revertive");
    private static final javax.xml.namespace.QName REVERTIVEREROUTE$34 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "revertiveReroute");
    private static final javax.xml.namespace.QName INTENDEDROUTEAENDS$36 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "intendedRouteAEnds");
    private static final javax.xml.namespace.QName INTENDEDROUTEEXCLUSIVE$38 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "intendedRouteExclusive");
    private static final javax.xml.namespace.QName INTENDEDROUTEZENDS$40 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "intendedRouteZEnds");
    private static final javax.xml.namespace.QName PRIORITY$42 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "priority");
    private static final javax.xml.namespace.QName ZROLES$44 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "zRoles");
    private static final javax.xml.namespace.QName ASAPREF$46 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "asapRef");
    private static final javax.xml.namespace.QName AENDTPLIST$48 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "aEndTpList");
    private static final javax.xml.namespace.QName AENDTNANAMEORGROUPTNANAME$50 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "aEndTnaNameOrGroupTnaName");
    private static final javax.xml.namespace.QName BLSRDIRECTION$52 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "blsrDirection");
    private static final javax.xml.namespace.QName BUNDLEDSNCINDICATOR$54 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "bundledSncIndicator");
    private static final javax.xml.namespace.QName MAXIMUMCOST$56 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "maximumCost");
    private static final javax.xml.namespace.QName MUSTREMOVEGTPLIST$58 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "mustRemoveGtpList");
    private static final javax.xml.namespace.QName POTENTIALFUTURESETUPINDICATOR$60 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "potentialFutureSetupIndicator");
    private static final javax.xml.namespace.QName ROUTEGROUPLABEL$62 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "routeGroupLabel");
    private static final javax.xml.namespace.QName ROUTINGCONSTRAINTEFFORT$64 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "routingConstraintEffort");
    private static final javax.xml.namespace.QName TIMESLOT$66 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "timeslot");
    private static final javax.xml.namespace.QName ZENDTPLIST$68 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "zEndTpList");
    private static final javax.xml.namespace.QName ZENDTNANAMEORGROUPTNANAME$70 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "zEndTnaNameOrGroupTnaName");
    
    
    /**
     * Gets the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "direction" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "direction" element
     */
    public void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DIRECTION$0);
            }
            target.setEnumValue(direction);
        }
    }
    
    /**
     * Sets (as xml) the "direction" element
     */
    public void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().find_element_user(DIRECTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType)get_store().add_element_user(DIRECTION$0);
            }
            target.set(direction);
        }
    }
    
    /**
     * Gets the "staticProtectionLevel" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType getStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().find_element_user(STATICPROTECTIONLEVEL$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "staticProtectionLevel" element
     */
    public void setStaticProtectionLevel(org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType staticProtectionLevel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().find_element_user(STATICPROTECTIONLEVEL$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().add_element_user(STATICPROTECTIONLEVEL$2);
            }
            target.set(staticProtectionLevel);
        }
    }
    
    /**
     * Appends and returns a new empty "staticProtectionLevel" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType addNewStaticProtectionLevel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType)get_store().add_element_user(STATICPROTECTIONLEVEL$2);
            return target;
        }
    }
    
    /**
     * Gets the "protectionEffort" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum getProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTECTIONEFFORT$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "protectionEffort" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType xgetProtectionEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(PROTECTIONEFFORT$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "protectionEffort" element
     */
    public void setProtectionEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum protectionEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTECTIONEFFORT$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTECTIONEFFORT$4);
            }
            target.setEnumValue(protectionEffort);
        }
    }
    
    /**
     * Sets (as xml) the "protectionEffort" element
     */
    public void xsetProtectionEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType protectionEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().find_element_user(PROTECTIONEFFORT$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType)get_store().add_element_user(PROTECTIONEFFORT$4);
            }
            target.set(protectionEffort);
        }
    }
    
    /**
     * Gets the "rerouteAllowed" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum getRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REROUTEALLOWED$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "rerouteAllowed" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.RerouteType xgetRerouteAllowed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(REROUTEALLOWED$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "rerouteAllowed" element
     */
    public void setRerouteAllowed(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum rerouteAllowed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REROUTEALLOWED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REROUTEALLOWED$6);
            }
            target.setEnumValue(rerouteAllowed);
        }
    }
    
    /**
     * Sets (as xml) the "rerouteAllowed" element
     */
    public void xsetRerouteAllowed(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType rerouteAllowed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.RerouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().find_element_user(REROUTEALLOWED$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.RerouteType)get_store().add_element_user(REROUTEALLOWED$6);
            }
            target.set(rerouteAllowed);
        }
    }
    
    /**
     * Gets the "networkRouted" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum getNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKROUTED$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "networkRouted" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType xgetNetworkRouted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().find_element_user(NETWORKROUTED$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "networkRouted" element
     */
    public void setNetworkRouted(org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum networkRouted)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKROUTED$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKROUTED$8);
            }
            target.setEnumValue(networkRouted);
        }
    }
    
    /**
     * Sets (as xml) the "networkRouted" element
     */
    public void xsetNetworkRouted(org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType networkRouted)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().find_element_user(NETWORKROUTED$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType)get_store().add_element_user(NETWORKROUTED$8);
            }
            target.set(networkRouted);
        }
    }
    
    /**
     * Gets the "sncType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum getSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCTYPE$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "sncType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType xgetSncType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(SNCTYPE$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "sncType" element
     */
    public void setSncType(org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType.Enum sncType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCTYPE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SNCTYPE$10);
            }
            target.setEnumValue(sncType);
        }
    }
    
    /**
     * Sets (as xml) the "sncType" element
     */
    public void xsetSncType(org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType sncType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().find_element_user(SNCTYPE$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SncTypeType)get_store().add_element_user(SNCTYPE$10);
            }
            target.set(sncType);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$12);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$12);
            return target;
        }
    }
    
    /**
     * Gets the "ccInclusions" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType getCcInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCINCLUSIONS$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ccInclusions" element
     */
    public boolean isSetCcInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CCINCLUSIONS$14) != 0;
        }
    }
    
    /**
     * Sets the "ccInclusions" element
     */
    public void setCcInclusions(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType ccInclusions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCINCLUSIONS$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCINCLUSIONS$14);
            }
            target.set(ccInclusions);
        }
    }
    
    /**
     * Appends and returns a new empty "ccInclusions" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType addNewCcInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCINCLUSIONS$14);
            return target;
        }
    }
    
    /**
     * Unsets the "ccInclusions" element
     */
    public void unsetCcInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CCINCLUSIONS$14, 0);
        }
    }
    
    /**
     * Gets the "neTpInclusions" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getNeTpInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NETPINCLUSIONS$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "neTpInclusions" element
     */
    public boolean isSetNeTpInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETPINCLUSIONS$16) != 0;
        }
    }
    
    /**
     * Sets the "neTpInclusions" element
     */
    public void setNeTpInclusions(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType neTpInclusions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NETPINCLUSIONS$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NETPINCLUSIONS$16);
            }
            target.set(neTpInclusions);
        }
    }
    
    /**
     * Appends and returns a new empty "neTpInclusions" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewNeTpInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NETPINCLUSIONS$16);
            return target;
        }
    }
    
    /**
     * Unsets the "neTpInclusions" element
     */
    public void unsetNeTpInclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETPINCLUSIONS$16, 0);
        }
    }
    
    /**
     * Gets the "fullRoute" element
     */
    public boolean getFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FULLROUTE$18, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "fullRoute" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetFullRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FULLROUTE$18, 0);
            return target;
        }
    }
    
    /**
     * Sets the "fullRoute" element
     */
    public void setFullRoute(boolean fullRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FULLROUTE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FULLROUTE$18);
            }
            target.setBooleanValue(fullRoute);
        }
    }
    
    /**
     * Sets (as xml) the "fullRoute" element
     */
    public void xsetFullRoute(org.apache.xmlbeans.XmlBoolean fullRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FULLROUTE$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FULLROUTE$18);
            }
            target.set(fullRoute);
        }
    }
    
    /**
     * Gets the "neTpSncExclusions" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getNeTpSncExclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NETPSNCEXCLUSIONS$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "neTpSncExclusions" element
     */
    public boolean isSetNeTpSncExclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETPSNCEXCLUSIONS$20) != 0;
        }
    }
    
    /**
     * Sets the "neTpSncExclusions" element
     */
    public void setNeTpSncExclusions(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType neTpSncExclusions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NETPSNCEXCLUSIONS$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NETPSNCEXCLUSIONS$20);
            }
            target.set(neTpSncExclusions);
        }
    }
    
    /**
     * Appends and returns a new empty "neTpSncExclusions" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewNeTpSncExclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NETPSNCEXCLUSIONS$20);
            return target;
        }
    }
    
    /**
     * Unsets the "neTpSncExclusions" element
     */
    public void unsetNeTpSncExclusions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETPSNCEXCLUSIONS$20, 0);
        }
    }
    
    /**
     * Gets the "aEnd" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(AEND$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "aEnd" element
     */
    public void setAEnd(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType aEnd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(AEND$22, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(AEND$22);
            }
            target.set(aEnd);
        }
    }
    
    /**
     * Appends and returns a new empty "aEnd" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewAEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(AEND$22);
            return target;
        }
    }
    
    /**
     * Gets the "zEnd" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ZEND$24, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "zEnd" element
     */
    public void setZEnd(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType zEnd)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ZEND$24, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(ZEND$24);
            }
            target.set(zEnd);
        }
    }
    
    /**
     * Appends and returns a new empty "zEnd" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewZEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(ZEND$24);
            return target;
        }
    }
    
    /**
     * Gets the "aRoles" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles getARoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles)get_store().find_element_user(AROLES$26, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "aRoles" element
     */
    public boolean isSetARoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AROLES$26) != 0;
        }
    }
    
    /**
     * Sets the "aRoles" element
     */
    public void setARoles(org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles aRoles)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles)get_store().find_element_user(AROLES$26, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles)get_store().add_element_user(AROLES$26);
            }
            target.set(aRoles);
        }
    }
    
    /**
     * Appends and returns a new empty "aRoles" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles addNewARoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles)get_store().add_element_user(AROLES$26);
            return target;
        }
    }
    
    /**
     * Unsets the "aRoles" element
     */
    public void unsetARoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AROLES$26, 0);
        }
    }
    
    /**
     * Gets the "alarmReportingIndicator" element
     */
    public boolean getAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$28, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "alarmReportingIndicator" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ALARMREPORTINGINDICATOR$28, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "alarmReportingIndicator" element
     */
    public boolean isNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ALARMREPORTINGINDICATOR$28, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "alarmReportingIndicator" element
     */
    public boolean isSetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMREPORTINGINDICATOR$28) != 0;
        }
    }
    
    /**
     * Sets the "alarmReportingIndicator" element
     */
    public void setAlarmReportingIndicator(boolean alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALARMREPORTINGINDICATOR$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALARMREPORTINGINDICATOR$28);
            }
            target.setBooleanValue(alarmReportingIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "alarmReportingIndicator" element
     */
    public void xsetAlarmReportingIndicator(org.apache.xmlbeans.XmlBoolean alarmReportingIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ALARMREPORTINGINDICATOR$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ALARMREPORTINGINDICATOR$28);
            }
            target.set(alarmReportingIndicator);
        }
    }
    
    /**
     * Nils the "alarmReportingIndicator" element
     */
    public void setNilAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ALARMREPORTINGINDICATOR$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ALARMREPORTINGINDICATOR$28);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "alarmReportingIndicator" element
     */
    public void unsetAlarmReportingIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMREPORTINGINDICATOR$28, 0);
        }
    }
    
    /**
     * Gets the "networkReroute" element
     */
    public java.lang.String getNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKREROUTE$30, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "networkReroute" element
     */
    public org.apache.xmlbeans.XmlString xgetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NETWORKREROUTE$30, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "networkReroute" element
     */
    public boolean isNilNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NETWORKREROUTE$30, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "networkReroute" element
     */
    public boolean isSetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETWORKREROUTE$30) != 0;
        }
    }
    
    /**
     * Sets the "networkReroute" element
     */
    public void setNetworkReroute(java.lang.String networkReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKREROUTE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKREROUTE$30);
            }
            target.setStringValue(networkReroute);
        }
    }
    
    /**
     * Sets (as xml) the "networkReroute" element
     */
    public void xsetNetworkReroute(org.apache.xmlbeans.XmlString networkReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NETWORKREROUTE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NETWORKREROUTE$30);
            }
            target.set(networkReroute);
        }
    }
    
    /**
     * Nils the "networkReroute" element
     */
    public void setNilNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NETWORKREROUTE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NETWORKREROUTE$30);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "networkReroute" element
     */
    public void unsetNetworkReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETWORKREROUTE$30, 0);
        }
    }
    
    /**
     * Gets the "revertive" element
     */
    public boolean getRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERTIVE$32, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "revertive" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVE$32, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "revertive" element
     */
    public boolean isNilRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVE$32, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "revertive" element
     */
    public boolean isSetRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REVERTIVE$32) != 0;
        }
    }
    
    /**
     * Sets the "revertive" element
     */
    public void setRevertive(boolean revertive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERTIVE$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REVERTIVE$32);
            }
            target.setBooleanValue(revertive);
        }
    }
    
    /**
     * Sets (as xml) the "revertive" element
     */
    public void xsetRevertive(org.apache.xmlbeans.XmlBoolean revertive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVE$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(REVERTIVE$32);
            }
            target.set(revertive);
        }
    }
    
    /**
     * Nils the "revertive" element
     */
    public void setNilRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVE$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(REVERTIVE$32);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "revertive" element
     */
    public void unsetRevertive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REVERTIVE$32, 0);
        }
    }
    
    /**
     * Gets the "revertiveReroute" element
     */
    public boolean getRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERTIVEREROUTE$34, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "revertiveReroute" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVEREROUTE$34, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "revertiveReroute" element
     */
    public boolean isNilRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVEREROUTE$34, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "revertiveReroute" element
     */
    public boolean isSetRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REVERTIVEREROUTE$34) != 0;
        }
    }
    
    /**
     * Sets the "revertiveReroute" element
     */
    public void setRevertiveReroute(boolean revertiveReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERTIVEREROUTE$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REVERTIVEREROUTE$34);
            }
            target.setBooleanValue(revertiveReroute);
        }
    }
    
    /**
     * Sets (as xml) the "revertiveReroute" element
     */
    public void xsetRevertiveReroute(org.apache.xmlbeans.XmlBoolean revertiveReroute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVEREROUTE$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(REVERTIVEREROUTE$34);
            }
            target.set(revertiveReroute);
        }
    }
    
    /**
     * Nils the "revertiveReroute" element
     */
    public void setNilRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(REVERTIVEREROUTE$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(REVERTIVEREROUTE$34);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "revertiveReroute" element
     */
    public void unsetRevertiveReroute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REVERTIVEREROUTE$34, 0);
        }
    }
    
    /**
     * Gets the "intendedRouteAEnds" element
     */
    public java.lang.String getIntendedRouteAEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDEDROUTEAENDS$36, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "intendedRouteAEnds" element
     */
    public org.apache.xmlbeans.XmlString xgetIntendedRouteAEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDEDROUTEAENDS$36, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "intendedRouteAEnds" element
     */
    public boolean isNilIntendedRouteAEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDEDROUTEAENDS$36, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "intendedRouteAEnds" element
     */
    public boolean isSetIntendedRouteAEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTENDEDROUTEAENDS$36) != 0;
        }
    }
    
    /**
     * Sets the "intendedRouteAEnds" element
     */
    public void setIntendedRouteAEnds(java.lang.String intendedRouteAEnds)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDEDROUTEAENDS$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTENDEDROUTEAENDS$36);
            }
            target.setStringValue(intendedRouteAEnds);
        }
    }
    
    /**
     * Sets (as xml) the "intendedRouteAEnds" element
     */
    public void xsetIntendedRouteAEnds(org.apache.xmlbeans.XmlString intendedRouteAEnds)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDEDROUTEAENDS$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INTENDEDROUTEAENDS$36);
            }
            target.set(intendedRouteAEnds);
        }
    }
    
    /**
     * Nils the "intendedRouteAEnds" element
     */
    public void setNilIntendedRouteAEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDEDROUTEAENDS$36, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INTENDEDROUTEAENDS$36);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "intendedRouteAEnds" element
     */
    public void unsetIntendedRouteAEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTENDEDROUTEAENDS$36, 0);
        }
    }
    
    /**
     * Gets the "intendedRouteExclusive" element
     */
    public boolean getIntendedRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDEDROUTEEXCLUSIVE$38, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "intendedRouteExclusive" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIntendedRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(INTENDEDROUTEEXCLUSIVE$38, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "intendedRouteExclusive" element
     */
    public boolean isNilIntendedRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(INTENDEDROUTEEXCLUSIVE$38, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "intendedRouteExclusive" element
     */
    public boolean isSetIntendedRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTENDEDROUTEEXCLUSIVE$38) != 0;
        }
    }
    
    /**
     * Sets the "intendedRouteExclusive" element
     */
    public void setIntendedRouteExclusive(boolean intendedRouteExclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDEDROUTEEXCLUSIVE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTENDEDROUTEEXCLUSIVE$38);
            }
            target.setBooleanValue(intendedRouteExclusive);
        }
    }
    
    /**
     * Sets (as xml) the "intendedRouteExclusive" element
     */
    public void xsetIntendedRouteExclusive(org.apache.xmlbeans.XmlBoolean intendedRouteExclusive)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(INTENDEDROUTEEXCLUSIVE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(INTENDEDROUTEEXCLUSIVE$38);
            }
            target.set(intendedRouteExclusive);
        }
    }
    
    /**
     * Nils the "intendedRouteExclusive" element
     */
    public void setNilIntendedRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(INTENDEDROUTEEXCLUSIVE$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(INTENDEDROUTEEXCLUSIVE$38);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "intendedRouteExclusive" element
     */
    public void unsetIntendedRouteExclusive()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTENDEDROUTEEXCLUSIVE$38, 0);
        }
    }
    
    /**
     * Gets the "intendedRouteZEnds" element
     */
    public java.lang.String getIntendedRouteZEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDEDROUTEZENDS$40, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "intendedRouteZEnds" element
     */
    public org.apache.xmlbeans.XmlString xgetIntendedRouteZEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDEDROUTEZENDS$40, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "intendedRouteZEnds" element
     */
    public boolean isNilIntendedRouteZEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDEDROUTEZENDS$40, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "intendedRouteZEnds" element
     */
    public boolean isSetIntendedRouteZEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTENDEDROUTEZENDS$40) != 0;
        }
    }
    
    /**
     * Sets the "intendedRouteZEnds" element
     */
    public void setIntendedRouteZEnds(java.lang.String intendedRouteZEnds)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTENDEDROUTEZENDS$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTENDEDROUTEZENDS$40);
            }
            target.setStringValue(intendedRouteZEnds);
        }
    }
    
    /**
     * Sets (as xml) the "intendedRouteZEnds" element
     */
    public void xsetIntendedRouteZEnds(org.apache.xmlbeans.XmlString intendedRouteZEnds)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDEDROUTEZENDS$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INTENDEDROUTEZENDS$40);
            }
            target.set(intendedRouteZEnds);
        }
    }
    
    /**
     * Nils the "intendedRouteZEnds" element
     */
    public void setNilIntendedRouteZEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(INTENDEDROUTEZENDS$40, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(INTENDEDROUTEZENDS$40);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "intendedRouteZEnds" element
     */
    public void unsetIntendedRouteZEnds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTENDEDROUTEZENDS$40, 0);
        }
    }
    
    /**
     * Gets the "priority" element
     */
    public long getPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$42, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "priority" element
     */
    public org.apache.xmlbeans.XmlUnsignedInt xgetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$42, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "priority" element
     */
    public boolean isNilPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$42, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "priority" element
     */
    public boolean isSetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRIORITY$42) != 0;
        }
    }
    
    /**
     * Sets the "priority" element
     */
    public void setPriority(long priority)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRIORITY$42);
            }
            target.setLongValue(priority);
        }
    }
    
    /**
     * Sets (as xml) the "priority" element
     */
    public void xsetPriority(org.apache.xmlbeans.XmlUnsignedInt priority)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(PRIORITY$42);
            }
            target.set(priority);
        }
    }
    
    /**
     * Nils the "priority" element
     */
    public void setNilPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PRIORITY$42, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(PRIORITY$42);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "priority" element
     */
    public void unsetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRIORITY$42, 0);
        }
    }
    
    /**
     * Gets the "zRoles" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles getZRoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles)get_store().find_element_user(ZROLES$44, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "zRoles" element
     */
    public boolean isSetZRoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZROLES$44) != 0;
        }
    }
    
    /**
     * Sets the "zRoles" element
     */
    public void setZRoles(org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles zRoles)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles)get_store().find_element_user(ZROLES$44, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles)get_store().add_element_user(ZROLES$44);
            }
            target.set(zRoles);
        }
    }
    
    /**
     * Appends and returns a new empty "zRoles" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles addNewZRoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles)get_store().add_element_user(ZROLES$44);
            return target;
        }
    }
    
    /**
     * Unsets the "zRoles" element
     */
    public void unsetZRoles()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZROLES$44, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$46, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$46, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$46, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$46) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$46);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$46);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$46, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$46);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$46, 0);
        }
    }
    
    /**
     * Gets the "aEndTpList" element
     */
    public java.lang.String getAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AENDTPLIST$48, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "aEndTpList" element
     */
    public org.apache.xmlbeans.XmlString xgetAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTPLIST$48, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "aEndTpList" element
     */
    public boolean isNilAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTPLIST$48, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aEndTpList" element
     */
    public boolean isSetAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AENDTPLIST$48) != 0;
        }
    }
    
    /**
     * Sets the "aEndTpList" element
     */
    public void setAEndTpList(java.lang.String aEndTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AENDTPLIST$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AENDTPLIST$48);
            }
            target.setStringValue(aEndTpList);
        }
    }
    
    /**
     * Sets (as xml) the "aEndTpList" element
     */
    public void xsetAEndTpList(org.apache.xmlbeans.XmlString aEndTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTPLIST$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AENDTPLIST$48);
            }
            target.set(aEndTpList);
        }
    }
    
    /**
     * Nils the "aEndTpList" element
     */
    public void setNilAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTPLIST$48, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AENDTPLIST$48);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aEndTpList" element
     */
    public void unsetAEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AENDTPLIST$48, 0);
        }
    }
    
    /**
     * Gets the "aEndTnaNameOrGroupTnaName" element
     */
    public java.lang.String getAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$50, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "aEndTnaNameOrGroupTnaName" element
     */
    public org.apache.xmlbeans.XmlString xgetAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$50, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "aEndTnaNameOrGroupTnaName" element
     */
    public boolean isNilAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$50, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aEndTnaNameOrGroupTnaName" element
     */
    public boolean isSetAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AENDTNANAMEORGROUPTNANAME$50) != 0;
        }
    }
    
    /**
     * Sets the "aEndTnaNameOrGroupTnaName" element
     */
    public void setAEndTnaNameOrGroupTnaName(java.lang.String aEndTnaNameOrGroupTnaName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AENDTNANAMEORGROUPTNANAME$50);
            }
            target.setStringValue(aEndTnaNameOrGroupTnaName);
        }
    }
    
    /**
     * Sets (as xml) the "aEndTnaNameOrGroupTnaName" element
     */
    public void xsetAEndTnaNameOrGroupTnaName(org.apache.xmlbeans.XmlString aEndTnaNameOrGroupTnaName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AENDTNANAMEORGROUPTNANAME$50);
            }
            target.set(aEndTnaNameOrGroupTnaName);
        }
    }
    
    /**
     * Nils the "aEndTnaNameOrGroupTnaName" element
     */
    public void setNilAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(AENDTNANAMEORGROUPTNANAME$50, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(AENDTNANAMEORGROUPTNANAME$50);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aEndTnaNameOrGroupTnaName" element
     */
    public void unsetAEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AENDTNANAMEORGROUPTNANAME$50, 0);
        }
    }
    
    /**
     * Gets the "blsrDirection" element
     */
    public java.lang.String getBlsrDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BLSRDIRECTION$52, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "blsrDirection" element
     */
    public org.apache.xmlbeans.XmlString xgetBlsrDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BLSRDIRECTION$52, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "blsrDirection" element
     */
    public boolean isNilBlsrDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BLSRDIRECTION$52, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "blsrDirection" element
     */
    public boolean isSetBlsrDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BLSRDIRECTION$52) != 0;
        }
    }
    
    /**
     * Sets the "blsrDirection" element
     */
    public void setBlsrDirection(java.lang.String blsrDirection)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BLSRDIRECTION$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BLSRDIRECTION$52);
            }
            target.setStringValue(blsrDirection);
        }
    }
    
    /**
     * Sets (as xml) the "blsrDirection" element
     */
    public void xsetBlsrDirection(org.apache.xmlbeans.XmlString blsrDirection)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BLSRDIRECTION$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(BLSRDIRECTION$52);
            }
            target.set(blsrDirection);
        }
    }
    
    /**
     * Nils the "blsrDirection" element
     */
    public void setNilBlsrDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(BLSRDIRECTION$52, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(BLSRDIRECTION$52);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "blsrDirection" element
     */
    public void unsetBlsrDirection()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BLSRDIRECTION$52, 0);
        }
    }
    
    /**
     * Gets the "bundledSncIndicator" element
     */
    public boolean getBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BUNDLEDSNCINDICATOR$54, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "bundledSncIndicator" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BUNDLEDSNCINDICATOR$54, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "bundledSncIndicator" element
     */
    public boolean isNilBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BUNDLEDSNCINDICATOR$54, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "bundledSncIndicator" element
     */
    public boolean isSetBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BUNDLEDSNCINDICATOR$54) != 0;
        }
    }
    
    /**
     * Sets the "bundledSncIndicator" element
     */
    public void setBundledSncIndicator(boolean bundledSncIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BUNDLEDSNCINDICATOR$54, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BUNDLEDSNCINDICATOR$54);
            }
            target.setBooleanValue(bundledSncIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "bundledSncIndicator" element
     */
    public void xsetBundledSncIndicator(org.apache.xmlbeans.XmlBoolean bundledSncIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BUNDLEDSNCINDICATOR$54, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(BUNDLEDSNCINDICATOR$54);
            }
            target.set(bundledSncIndicator);
        }
    }
    
    /**
     * Nils the "bundledSncIndicator" element
     */
    public void setNilBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BUNDLEDSNCINDICATOR$54, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(BUNDLEDSNCINDICATOR$54);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "bundledSncIndicator" element
     */
    public void unsetBundledSncIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BUNDLEDSNCINDICATOR$54, 0);
        }
    }
    
    /**
     * Gets the "maximumCost" element
     */
    public java.lang.String getMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAXIMUMCOST$56, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "maximumCost" element
     */
    public org.apache.xmlbeans.XmlString xgetMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MAXIMUMCOST$56, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "maximumCost" element
     */
    public boolean isNilMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MAXIMUMCOST$56, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "maximumCost" element
     */
    public boolean isSetMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MAXIMUMCOST$56) != 0;
        }
    }
    
    /**
     * Sets the "maximumCost" element
     */
    public void setMaximumCost(java.lang.String maximumCost)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAXIMUMCOST$56, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MAXIMUMCOST$56);
            }
            target.setStringValue(maximumCost);
        }
    }
    
    /**
     * Sets (as xml) the "maximumCost" element
     */
    public void xsetMaximumCost(org.apache.xmlbeans.XmlString maximumCost)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MAXIMUMCOST$56, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MAXIMUMCOST$56);
            }
            target.set(maximumCost);
        }
    }
    
    /**
     * Nils the "maximumCost" element
     */
    public void setNilMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MAXIMUMCOST$56, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MAXIMUMCOST$56);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "maximumCost" element
     */
    public void unsetMaximumCost()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MAXIMUMCOST$56, 0);
        }
    }
    
    /**
     * Gets the "mustRemoveGtpList" element
     */
    public boolean getMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUSTREMOVEGTPLIST$58, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "mustRemoveGtpList" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$58, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "mustRemoveGtpList" element
     */
    public boolean isNilMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$58, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "mustRemoveGtpList" element
     */
    public boolean isSetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MUSTREMOVEGTPLIST$58) != 0;
        }
    }
    
    /**
     * Sets the "mustRemoveGtpList" element
     */
    public void setMustRemoveGtpList(boolean mustRemoveGtpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MUSTREMOVEGTPLIST$58, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MUSTREMOVEGTPLIST$58);
            }
            target.setBooleanValue(mustRemoveGtpList);
        }
    }
    
    /**
     * Sets (as xml) the "mustRemoveGtpList" element
     */
    public void xsetMustRemoveGtpList(org.apache.xmlbeans.XmlBoolean mustRemoveGtpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$58, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(MUSTREMOVEGTPLIST$58);
            }
            target.set(mustRemoveGtpList);
        }
    }
    
    /**
     * Nils the "mustRemoveGtpList" element
     */
    public void setNilMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(MUSTREMOVEGTPLIST$58, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(MUSTREMOVEGTPLIST$58);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "mustRemoveGtpList" element
     */
    public void unsetMustRemoveGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MUSTREMOVEGTPLIST$58, 0);
        }
    }
    
    /**
     * Gets the "potentialFutureSetupIndicator" element
     */
    public java.lang.String getPotentialFutureSetupIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(POTENTIALFUTURESETUPINDICATOR$60, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "potentialFutureSetupIndicator" element
     */
    public org.apache.xmlbeans.XmlString xgetPotentialFutureSetupIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(POTENTIALFUTURESETUPINDICATOR$60, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "potentialFutureSetupIndicator" element
     */
    public boolean isNilPotentialFutureSetupIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(POTENTIALFUTURESETUPINDICATOR$60, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "potentialFutureSetupIndicator" element
     */
    public boolean isSetPotentialFutureSetupIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(POTENTIALFUTURESETUPINDICATOR$60) != 0;
        }
    }
    
    /**
     * Sets the "potentialFutureSetupIndicator" element
     */
    public void setPotentialFutureSetupIndicator(java.lang.String potentialFutureSetupIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(POTENTIALFUTURESETUPINDICATOR$60, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(POTENTIALFUTURESETUPINDICATOR$60);
            }
            target.setStringValue(potentialFutureSetupIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "potentialFutureSetupIndicator" element
     */
    public void xsetPotentialFutureSetupIndicator(org.apache.xmlbeans.XmlString potentialFutureSetupIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(POTENTIALFUTURESETUPINDICATOR$60, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(POTENTIALFUTURESETUPINDICATOR$60);
            }
            target.set(potentialFutureSetupIndicator);
        }
    }
    
    /**
     * Nils the "potentialFutureSetupIndicator" element
     */
    public void setNilPotentialFutureSetupIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(POTENTIALFUTURESETUPINDICATOR$60, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(POTENTIALFUTURESETUPINDICATOR$60);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "potentialFutureSetupIndicator" element
     */
    public void unsetPotentialFutureSetupIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(POTENTIALFUTURESETUPINDICATOR$60, 0);
        }
    }
    
    /**
     * Gets the "routeGroupLabel" element
     */
    public java.lang.String getRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEGROUPLABEL$62, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeGroupLabel" element
     */
    public org.apache.xmlbeans.XmlString xgetRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEGROUPLABEL$62, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routeGroupLabel" element
     */
    public boolean isNilRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEGROUPLABEL$62, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routeGroupLabel" element
     */
    public boolean isSetRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTEGROUPLABEL$62) != 0;
        }
    }
    
    /**
     * Sets the "routeGroupLabel" element
     */
    public void setRouteGroupLabel(java.lang.String routeGroupLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEGROUPLABEL$62, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEGROUPLABEL$62);
            }
            target.setStringValue(routeGroupLabel);
        }
    }
    
    /**
     * Sets (as xml) the "routeGroupLabel" element
     */
    public void xsetRouteGroupLabel(org.apache.xmlbeans.XmlString routeGroupLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEGROUPLABEL$62, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEGROUPLABEL$62);
            }
            target.set(routeGroupLabel);
        }
    }
    
    /**
     * Nils the "routeGroupLabel" element
     */
    public void setNilRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEGROUPLABEL$62, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEGROUPLABEL$62);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routeGroupLabel" element
     */
    public void unsetRouteGroupLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTEGROUPLABEL$62, 0);
        }
    }
    
    /**
     * Gets the "routingConstraintEffort" element
     */
    public java.lang.String getRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$64, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routingConstraintEffort" element
     */
    public org.apache.xmlbeans.XmlString xgetRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$64, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "routingConstraintEffort" element
     */
    public boolean isNilRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$64, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "routingConstraintEffort" element
     */
    public boolean isSetRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTINGCONSTRAINTEFFORT$64) != 0;
        }
    }
    
    /**
     * Sets the "routingConstraintEffort" element
     */
    public void setRoutingConstraintEffort(java.lang.String routingConstraintEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$64, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTINGCONSTRAINTEFFORT$64);
            }
            target.setStringValue(routingConstraintEffort);
        }
    }
    
    /**
     * Sets (as xml) the "routingConstraintEffort" element
     */
    public void xsetRoutingConstraintEffort(org.apache.xmlbeans.XmlString routingConstraintEffort)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$64, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTINGCONSTRAINTEFFORT$64);
            }
            target.set(routingConstraintEffort);
        }
    }
    
    /**
     * Nils the "routingConstraintEffort" element
     */
    public void setNilRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTINGCONSTRAINTEFFORT$64, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTINGCONSTRAINTEFFORT$64);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "routingConstraintEffort" element
     */
    public void unsetRoutingConstraintEffort()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTINGCONSTRAINTEFFORT$64, 0);
        }
    }
    
    /**
     * Gets the "timeslot" element
     */
    public java.math.BigInteger getTimeslot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIMESLOT$66, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigIntegerValue();
        }
    }
    
    /**
     * Gets (as xml) the "timeslot" element
     */
    public org.apache.xmlbeans.XmlInteger xgetTimeslot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInteger target = null;
            target = (org.apache.xmlbeans.XmlInteger)get_store().find_element_user(TIMESLOT$66, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "timeslot" element
     */
    public boolean isNilTimeslot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInteger target = null;
            target = (org.apache.xmlbeans.XmlInteger)get_store().find_element_user(TIMESLOT$66, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "timeslot" element
     */
    public boolean isSetTimeslot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TIMESLOT$66) != 0;
        }
    }
    
    /**
     * Sets the "timeslot" element
     */
    public void setTimeslot(java.math.BigInteger timeslot)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIMESLOT$66, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIMESLOT$66);
            }
            target.setBigIntegerValue(timeslot);
        }
    }
    
    /**
     * Sets (as xml) the "timeslot" element
     */
    public void xsetTimeslot(org.apache.xmlbeans.XmlInteger timeslot)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInteger target = null;
            target = (org.apache.xmlbeans.XmlInteger)get_store().find_element_user(TIMESLOT$66, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInteger)get_store().add_element_user(TIMESLOT$66);
            }
            target.set(timeslot);
        }
    }
    
    /**
     * Nils the "timeslot" element
     */
    public void setNilTimeslot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInteger target = null;
            target = (org.apache.xmlbeans.XmlInteger)get_store().find_element_user(TIMESLOT$66, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInteger)get_store().add_element_user(TIMESLOT$66);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "timeslot" element
     */
    public void unsetTimeslot()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TIMESLOT$66, 0);
        }
    }
    
    /**
     * Gets the "zEndTpList" element
     */
    public java.lang.String getZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ZENDTPLIST$68, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "zEndTpList" element
     */
    public org.apache.xmlbeans.XmlString xgetZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTPLIST$68, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "zEndTpList" element
     */
    public boolean isNilZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTPLIST$68, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "zEndTpList" element
     */
    public boolean isSetZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZENDTPLIST$68) != 0;
        }
    }
    
    /**
     * Sets the "zEndTpList" element
     */
    public void setZEndTpList(java.lang.String zEndTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ZENDTPLIST$68, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ZENDTPLIST$68);
            }
            target.setStringValue(zEndTpList);
        }
    }
    
    /**
     * Sets (as xml) the "zEndTpList" element
     */
    public void xsetZEndTpList(org.apache.xmlbeans.XmlString zEndTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTPLIST$68, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ZENDTPLIST$68);
            }
            target.set(zEndTpList);
        }
    }
    
    /**
     * Nils the "zEndTpList" element
     */
    public void setNilZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTPLIST$68, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ZENDTPLIST$68);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "zEndTpList" element
     */
    public void unsetZEndTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZENDTPLIST$68, 0);
        }
    }
    
    /**
     * Gets the "zEndTnaNameOrGroupTnaName" element
     */
    public java.lang.String getZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$70, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "zEndTnaNameOrGroupTnaName" element
     */
    public org.apache.xmlbeans.XmlString xgetZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$70, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "zEndTnaNameOrGroupTnaName" element
     */
    public boolean isNilZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$70, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "zEndTnaNameOrGroupTnaName" element
     */
    public boolean isSetZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ZENDTNANAMEORGROUPTNANAME$70) != 0;
        }
    }
    
    /**
     * Sets the "zEndTnaNameOrGroupTnaName" element
     */
    public void setZEndTnaNameOrGroupTnaName(java.lang.String zEndTnaNameOrGroupTnaName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$70, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ZENDTNANAMEORGROUPTNANAME$70);
            }
            target.setStringValue(zEndTnaNameOrGroupTnaName);
        }
    }
    
    /**
     * Sets (as xml) the "zEndTnaNameOrGroupTnaName" element
     */
    public void xsetZEndTnaNameOrGroupTnaName(org.apache.xmlbeans.XmlString zEndTnaNameOrGroupTnaName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$70, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ZENDTNANAMEORGROUPTNANAME$70);
            }
            target.set(zEndTnaNameOrGroupTnaName);
        }
    }
    
    /**
     * Nils the "zEndTnaNameOrGroupTnaName" element
     */
    public void setNilZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ZENDTNANAMEORGROUPTNANAME$70, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ZENDTNANAMEORGROUPTNANAME$70);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "zEndTnaNameOrGroupTnaName" element
     */
    public void unsetZEndTnaNameOrGroupTnaName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ZENDTNANAMEORGROUPTNANAME$70, 0);
        }
    }
    /**
     * An XML aRoles(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ARolesImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ARoles
    {
        
        public ARolesImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROLE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "role");
        
        
        /**
         * Gets a List of "role" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum> getRoleList()
        {
            final class RoleList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum get(int i)
                    { return ARolesImpl.this.getRoleArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum set(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum old = ARolesImpl.this.getRoleArray(i);
                    ARolesImpl.this.setRoleArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum o)
                    { ARolesImpl.this.insertRole(i, o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum old = ARolesImpl.this.getRoleArray(i);
                    ARolesImpl.this.removeRole(i);
                    return old;
                }
                
                public int size()
                    { return ARolesImpl.this.sizeOfRoleArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new RoleList();
            }
        }
        
        /**
         * Gets array of all "role" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] getRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ROLE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] result = new org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
                return result;
            }
        }
        
        /**
         * Gets ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum getRoleArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "role" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType> xgetRoleList()
        {
            final class RoleList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType get(int i)
                    { return ARolesImpl.this.xgetRoleArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType set(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType old = ARolesImpl.this.xgetRoleArray(i);
                    ARolesImpl.this.xsetRoleArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType o)
                    { ARolesImpl.this.insertNewRole(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType old = ARolesImpl.this.xgetRoleArray(i);
                    ARolesImpl.this.removeRole(i);
                    return old;
                }
                
                public int size()
                    { return ARolesImpl.this.sizeOfRoleArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new RoleList();
            }
        }
        
        /**
         * Gets (as xml) array of all "role" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[] xgetRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ROLE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[] result = new org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType xgetRoleArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)target;
            }
        }
        
        /**
         * Returns number of "role" element
         */
        public int sizeOfRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROLE$0);
            }
        }
        
        /**
         * Sets array of all "role" element
         */
        public void setRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] roleArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(roleArray, ROLE$0);
            }
        }
        
        /**
         * Sets ith "role" element
         */
        public void setRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setEnumValue(role);
            }
        }
        
        /**
         * Sets (as xml) array of all "role" element
         */
        public void xsetRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[]roleArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(roleArray, ROLE$0);
            }
        }
        
        /**
         * Sets (as xml) ith "role" element
         */
        public void xsetRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(role);
            }
        }
        
        /**
         * Inserts the value as the ith "role" element
         */
        public void insertRole(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(ROLE$0, i);
                target.setEnumValue(role);
            }
        }
        
        /**
         * Appends the value as the last "role" element
         */
        public void addRole(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROLE$0);
                target.setEnumValue(role);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType insertNewRole(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().insert_element_user(ROLE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType addNewRole()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().add_element_user(ROLE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "role" element
         */
        public void removeRole(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROLE$0, i);
            }
        }
    }
    /**
     * An XML zRoles(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class ZRolesImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SncCreateDataType.ZRoles
    {
        
        public ZRolesImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROLE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "role");
        
        
        /**
         * Gets a List of "role" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum> getRoleList()
        {
            final class RoleList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum get(int i)
                    { return ZRolesImpl.this.getRoleArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum set(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum old = ZRolesImpl.this.getRoleArray(i);
                    ZRolesImpl.this.setRoleArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum o)
                    { ZRolesImpl.this.insertRole(i, o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum old = ZRolesImpl.this.getRoleArray(i);
                    ZRolesImpl.this.removeRole(i);
                    return old;
                }
                
                public int size()
                    { return ZRolesImpl.this.sizeOfRoleArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new RoleList();
            }
        }
        
        /**
         * Gets array of all "role" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] getRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ROLE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] result = new org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
                return result;
            }
        }
        
        /**
         * Gets ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum getRoleArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "role" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType> xgetRoleList()
        {
            final class RoleList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType get(int i)
                    { return ZRolesImpl.this.xgetRoleArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType set(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType old = ZRolesImpl.this.xgetRoleArray(i);
                    ZRolesImpl.this.xsetRoleArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType o)
                    { ZRolesImpl.this.insertNewRole(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType old = ZRolesImpl.this.xgetRoleArray(i);
                    ZRolesImpl.this.removeRole(i);
                    return old;
                }
                
                public int size()
                    { return ZRolesImpl.this.sizeOfRoleArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new RoleList();
            }
        }
        
        /**
         * Gets (as xml) array of all "role" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[] xgetRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ROLE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[] result = new org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType xgetRoleArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)target;
            }
        }
        
        /**
         * Returns number of "role" element
         */
        public int sizeOfRoleArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROLE$0);
            }
        }
        
        /**
         * Sets array of all "role" element
         */
        public void setRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum[] roleArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(roleArray, ROLE$0);
            }
        }
        
        /**
         * Sets ith "role" element
         */
        public void setRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setEnumValue(role);
            }
        }
        
        /**
         * Sets (as xml) array of all "role" element
         */
        public void xsetRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType[]roleArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(roleArray, ROLE$0);
            }
        }
        
        /**
         * Sets (as xml) ith "role" element
         */
        public void xsetRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().find_element_user(ROLE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(role);
            }
        }
        
        /**
         * Inserts the value as the ith "role" element
         */
        public void insertRole(int i, org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(ROLE$0, i);
                target.setEnumValue(role);
            }
        }
        
        /**
         * Appends the value as the last "role" element
         */
        public void addRole(org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType.Enum role)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROLE$0);
                target.setEnumValue(role);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType insertNewRole(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().insert_element_user(ROLE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "role" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType addNewRole()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.TpRoleInSncType)get_store().add_element_user(ROLE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "role" element
         */
        public void removeRole(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROLE$0, i);
            }
        }
    }
}
