/*
 * An XML document type.
 * Localname: swapSubnetworkConnectionRequest
 * Namespace: http://www.tmforum.org/mtop/rp/xsd/conc/v1
 * Java type: org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rp.xsd.conc.v1.impl;
/**
 * A document containing one swapSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1) element.
 *
 * This is a complex type.
 */
public class SwapSubnetworkConnectionRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument
{
    
    public SwapSubnetworkConnectionRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SWAPSUBNETWORKCONNECTIONREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "swapSubnetworkConnectionRequest");
    
    
    /**
     * Gets the "swapSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest getSwapSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest)get_store().find_element_user(SWAPSUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "swapSubnetworkConnectionRequest" element
     */
    public void setSwapSubnetworkConnectionRequest(org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest swapSubnetworkConnectionRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest)get_store().find_element_user(SWAPSUBNETWORKCONNECTIONREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest)get_store().add_element_user(SWAPSUBNETWORKCONNECTIONREQUEST$0);
            }
            target.set(swapSubnetworkConnectionRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "swapSubnetworkConnectionRequest" element
     */
    public org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest addNewSwapSubnetworkConnectionRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest target = null;
            target = (org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest)get_store().add_element_user(SWAPSUBNETWORKCONNECTIONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML swapSubnetworkConnectionRequest(@http://www.tmforum.org/mtop/rp/xsd/conc/v1).
     *
     * This is a complex type.
     */
    public static class SwapSubnetworkConnectionRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rp.xsd.conc.v1.SwapSubnetworkConnectionRequestDocument.SwapSubnetworkConnectionRequest
    {
        
        public SwapSubnetworkConnectionRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NAMEOFSNCTOBEDEACTIVATED$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "nameOfSncToBeDeactivated");
        private static final javax.xml.namespace.QName NAMEOFSNCTOBEACTIVATED$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "nameOfSncToBeActivated");
        private static final javax.xml.namespace.QName TOLERABLEIMPACT$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tolerableImpact");
        private static final javax.xml.namespace.QName OSFREEDOMLEVEL$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "osFreedomLevel");
        private static final javax.xml.namespace.QName TPLISTTOMODIFY$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rp/xsd/conc/v1", "tpListToModify");
        
        
        /**
         * Gets the "nameOfSncToBeDeactivated" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getNameOfSncToBeDeactivated()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAMEOFSNCTOBEDEACTIVATED$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "nameOfSncToBeDeactivated" element
         */
        public boolean isSetNameOfSncToBeDeactivated()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NAMEOFSNCTOBEDEACTIVATED$0) != 0;
            }
        }
        
        /**
         * Sets the "nameOfSncToBeDeactivated" element
         */
        public void setNameOfSncToBeDeactivated(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType nameOfSncToBeDeactivated)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAMEOFSNCTOBEDEACTIVATED$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAMEOFSNCTOBEDEACTIVATED$0);
                }
                target.set(nameOfSncToBeDeactivated);
            }
        }
        
        /**
         * Appends and returns a new empty "nameOfSncToBeDeactivated" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewNameOfSncToBeDeactivated()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAMEOFSNCTOBEDEACTIVATED$0);
                return target;
            }
        }
        
        /**
         * Unsets the "nameOfSncToBeDeactivated" element
         */
        public void unsetNameOfSncToBeDeactivated()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NAMEOFSNCTOBEDEACTIVATED$0, 0);
            }
        }
        
        /**
         * Gets the "nameOfSncToBeActivated" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getNameOfSncToBeActivated()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAMEOFSNCTOBEACTIVATED$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "nameOfSncToBeActivated" element
         */
        public boolean isSetNameOfSncToBeActivated()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NAMEOFSNCTOBEACTIVATED$2) != 0;
            }
        }
        
        /**
         * Sets the "nameOfSncToBeActivated" element
         */
        public void setNameOfSncToBeActivated(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType nameOfSncToBeActivated)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAMEOFSNCTOBEACTIVATED$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAMEOFSNCTOBEACTIVATED$2);
                }
                target.set(nameOfSncToBeActivated);
            }
        }
        
        /**
         * Appends and returns a new empty "nameOfSncToBeActivated" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewNameOfSncToBeActivated()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAMEOFSNCTOBEACTIVATED$2);
                return target;
            }
        }
        
        /**
         * Unsets the "nameOfSncToBeActivated" element
         */
        public void unsetNameOfSncToBeActivated()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NAMEOFSNCTOBEACTIVATED$2, 0);
            }
        }
        
        /**
         * Gets the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum getTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$4, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "tolerableImpact" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType xgetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "tolerableImpact" element
         */
        public boolean isSetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOLERABLEIMPACT$4) != 0;
            }
        }
        
        /**
         * Sets the "tolerableImpact" element
         */
        public void setTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType.Enum tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOLERABLEIMPACT$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOLERABLEIMPACT$4);
                }
                target.setEnumValue(tolerableImpact);
            }
        }
        
        /**
         * Sets (as xml) the "tolerableImpact" element
         */
        public void xsetTolerableImpact(org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType tolerableImpact)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().find_element_user(TOLERABLEIMPACT$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.GradesOfImpactType)get_store().add_element_user(TOLERABLEIMPACT$4);
                }
                target.set(tolerableImpact);
            }
        }
        
        /**
         * Unsets the "tolerableImpact" element
         */
        public void unsetTolerableImpact()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOLERABLEIMPACT$4, 0);
            }
        }
        
        /**
         * Gets the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum getOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$6, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "osFreedomLevel" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType xgetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$6, 0);
                return target;
            }
        }
        
        /**
         * True if has "osFreedomLevel" element
         */
        public boolean isSetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OSFREEDOMLEVEL$6) != 0;
            }
        }
        
        /**
         * Sets the "osFreedomLevel" element
         */
        public void setOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType.Enum osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSFREEDOMLEVEL$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSFREEDOMLEVEL$6);
                }
                target.setEnumValue(osFreedomLevel);
            }
        }
        
        /**
         * Sets (as xml) the "osFreedomLevel" element
         */
        public void xsetOsFreedomLevel(org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType osFreedomLevel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().find_element_user(OSFREEDOMLEVEL$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.com.v1.OperationsSystemFreedomLevelType)get_store().add_element_user(OSFREEDOMLEVEL$6);
                }
                target.set(osFreedomLevel);
            }
        }
        
        /**
         * Unsets the "osFreedomLevel" element
         */
        public void unsetOsFreedomLevel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OSFREEDOMLEVEL$6, 0);
            }
        }
        
        /**
         * Gets the "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$8, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpListToModify" element
         */
        public boolean isSetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPLISTTOMODIFY$8) != 0;
            }
        }
        
        /**
         * Sets the "tpListToModify" element
         */
        public void setTpListToModify(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType tpListToModify)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().find_element_user(TPLISTTOMODIFY$8, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$8);
                }
                target.set(tpListToModify);
            }
        }
        
        /**
         * Appends and returns a new empty "tpListToModify" element
         */
        public org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType)get_store().add_element_user(TPLISTTOMODIFY$8);
                return target;
            }
        }
        
        /**
         * Unsets the "tpListToModify" element
         */
        public void unsetTpListToModify()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPLISTTOMODIFY$8, 0);
            }
        }
    }
}
