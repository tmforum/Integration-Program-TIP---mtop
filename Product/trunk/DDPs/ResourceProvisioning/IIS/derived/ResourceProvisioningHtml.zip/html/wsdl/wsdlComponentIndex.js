﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/rp/wsdl/conc/v1-0"] =  new WC (
					new Array(new WCN("51/service/ConnectionControlHttp.html","ConnectionControlHttp",false,null),new WCN("51/service/ConnectionControlJms.html","ConnectionControlJms",false,null)),
					new Array(new WCN("51/message/activateSncException.html","activateSncException",false,null),new WCN("51/message/activateSncRequest.html","activateSncRequest",false,null),new WCN("51/message/activateSncResponse.html","activateSncResponse",false,null),new WCN("51/message/addRouteException.html","addRouteException",false,null),new WCN("51/message/addRouteRequest.html","addRouteRequest",false,null),new WCN("51/message/addRouteResponse.html","addRouteResponse",false,null),new WCN("51/message/checkValidSncException.html","checkValidSncException",false,null),new WCN("51/message/checkValidSncRequest.html","checkValidSncRequest",false,null),new WCN("51/message/checkValidSncResponse.html","checkValidSncResponse",false,null),new WCN("51/message/createAndActivateSncException.html","createAndActivateSncException",false,null),new WCN("51/message/createAndActivateSncRequest.html","createAndActivateSncRequest",false,null),new WCN("51/message/createAndActivateSncResponse.html","createAndActivateSncResponse",false,null),new WCN("51/message/createModifiedSncException.html","createModifiedSncException",false,null),new WCN("51/message/createModifiedSncRequest.html","createModifiedSncRequest",false,null),new WCN("51/message/createModifiedSncResponse.html","createModifiedSncResponse",false,null),new WCN("51/message/createSncException.html","createSncException",false,null),new WCN("51/message/createSncRequest.html","createSncRequest",false,null),new WCN("51/message/createSncResponse.html","createSncResponse",false,null),new WCN("51/message/deactivateAndDeleteSncException.html","deactivateAndDeleteSncException",false,null),new WCN("51/message/deactivateAndDeleteSncRequest.html","deactivateAndDeleteSncRequest",false,null),new WCN("51/message/deactivateAndDeleteSncResponse.html","deactivateAndDeleteSncResponse",false,null),new WCN("51/message/deactivateSncException.html","deactivateSncException",false,null),new WCN("51/message/deactivateSncRequest.html","deactivateSncRequest",false,null),new WCN("51/message/deactivateSncResponse.html","deactivateSncResponse",false,null),new WCN("51/message/deleteSncException.html","deleteSncException",false,null),new WCN("51/message/deleteSncRequest.html","deleteSncRequest",false,null),new WCN("51/message/deleteSncResponse.html","deleteSncResponse",false,null),new WCN("51/message/modifySncException.html","modifySncException",false,null),new WCN("51/message/modifySncRequest.html","modifySncRequest",false,null),new WCN("51/message/modifySncResponse.html","modifySncResponse",false,null),new WCN("51/message/removeRouteException.html","removeRouteException",false,null),new WCN("51/message/removeRouteRequest.html","removeRouteRequest",false,null),new WCN("51/message/removeRouteResponse.html","removeRouteResponse",false,null),new WCN("51/message/setIntendedRouteException.html","setIntendedRouteException",false,null),new WCN("51/message/setIntendedRouteRequest.html","setIntendedRouteRequest",false,null),new WCN("51/message/setIntendedRouteResponse.html","setIntendedRouteResponse",false,null),new WCN("51/message/setRoutesAdminStateException.html","setRoutesAdminStateException",false,null),new WCN("51/message/setRoutesAdminStateRequest.html","setRoutesAdminStateRequest",false,null),new WCN("51/message/setRoutesAdminStateResponse.html","setRoutesAdminStateResponse",false,null),new WCN("51/message/swapSncException.html","swapSncException",false,null),new WCN("51/message/swapSncRequest.html","swapSncRequest",false,null),new WCN("51/message/swapSncResponse.html","swapSncResponse",false,null),new WCN("51/message/switchRouteException.html","switchRouteException",false,null),new WCN("51/message/switchRouteRequest.html","switchRouteRequest",false,null),new WCN("51/message/switchRouteResponse.html","switchRouteResponse",false,null)),
					new Array(new WCN("51/porttype/ConnectionControl.html","ConnectionControl",false,new Array(new WCN("51/operation/activateSnc_4.html","activateSnc",false,null),new WCN("51/operation/addRoute_5.html","addRoute",false,null),new WCN("51/operation/checkValidSnc_6.html","checkValidSnc",false,null),new WCN("51/operation/createAndActivateSnc_7.html","createAndActivateSnc",false,null),new WCN("51/operation/createModifiedSnc_8.html","createModifiedSnc",false,null),new WCN("51/operation/createSnc_9.html","createSnc",false,null),new WCN("51/operation/deactivateAndDeleteSnc_10.html","deactivateAndDeleteSnc",false,null),new WCN("51/operation/deactivateSnc_11.html","deactivateSnc",false,null),new WCN("51/operation/deleteSnc_12.html","deleteSnc",false,null),new WCN("51/operation/modifySnc_13.html","modifySnc",false,null),new WCN("51/operation/removeRoute_14.html","removeRoute",false,null),new WCN("51/operation/setIntendedRoute_15.html","setIntendedRoute",false,null),new WCN("51/operation/setRoutesAdminState_16.html","setRoutesAdminState",false,null),new WCN("51/operation/swapSnc_17.html","swapSnc",false,null),new WCN("51/operation/switchRoute_18.html","switchRoute",false,null)))),
					new Array(new WCN("51/binding/ConnectionControlSoapHttpBinding.html","ConnectionControlSoapHttpBinding",false,new Array(new WCN("51/operation/activateSnc_4.html","activateSnc",false,null),new WCN("51/operation/addRoute_5.html","addRoute",false,null),new WCN("51/operation/checkValidSnc_6.html","checkValidSnc",false,null),new WCN("51/operation/createAndActivateSnc_7.html","createAndActivateSnc",false,null),new WCN("51/operation/createModifiedSnc_8.html","createModifiedSnc",false,null),new WCN("51/operation/createSnc_9.html","createSnc",false,null),new WCN("51/operation/deactivateAndDeleteSnc_10.html","deactivateAndDeleteSnc",false,null),new WCN("51/operation/deactivateSnc_11.html","deactivateSnc",false,null),new WCN("51/operation/deleteSnc_12.html","deleteSnc",false,null),new WCN("51/operation/modifySnc_13.html","modifySnc",false,null),new WCN("51/operation/removeRoute_14.html","removeRoute",false,null),new WCN("51/operation/setIntendedRoute_15.html","setIntendedRoute",false,null),new WCN("51/operation/setRoutesAdminState_16.html","setRoutesAdminState",false,null),new WCN("51/operation/swapSnc_17.html","swapSnc",false,null),new WCN("51/operation/switchRoute_18.html","switchRoute",false,null))),new WCN("51/binding/ConnectionControlSoapJmsBinding.html","ConnectionControlSoapJmsBinding",false,new Array(new WCN("51/operation/activateSnc_4.html","activateSnc",false,null),new WCN("51/operation/addRoute_5.html","addRoute",false,null),new WCN("51/operation/checkValidSnc_6.html","checkValidSnc",false,null),new WCN("51/operation/createAndActivateSnc_7.html","createAndActivateSnc",false,null),new WCN("51/operation/createModifiedSnc_8.html","createModifiedSnc",false,null),new WCN("51/operation/createSnc_9.html","createSnc",false,null),new WCN("51/operation/deactivateAndDeleteSnc_10.html","deactivateAndDeleteSnc",false,null),new WCN("51/operation/deactivateSnc_11.html","deactivateSnc",false,null),new WCN("51/operation/deleteSnc_12.html","deleteSnc",false,null),new WCN("51/operation/modifySnc_13.html","modifySnc",false,null),new WCN("51/operation/removeRoute_14.html","removeRoute",false,null),new WCN("51/operation/setIntendedRoute_15.html","setIntendedRoute",false,null),new WCN("51/operation/setRoutesAdminState_16.html","setRoutesAdminState",false,null),new WCN("51/operation/swapSnc_17.html","swapSnc",false,null),new WCN("51/operation/switchRoute_18.html","switchRoute",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/conc/v1-0"] = "51/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/crp/v1-0"] =  new WC (
					new Array(new WCN("54/service/CommonResourceProvisioningHttp.html","CommonResourceProvisioningHttp",false,null),new WCN("54/service/CommonResourceProvisioningJms.html","CommonResourceProvisioningJms",false,null)),
					new Array(new WCN("54/message/setCommonAttributesException.html","setCommonAttributesException",false,null),new WCN("54/message/setCommonAttributesRequest.html","setCommonAttributesRequest",false,null),new WCN("54/message/setCommonAttributesResponse.html","setCommonAttributesResponse",false,null)),
					new Array(new WCN("54/porttype/CommonResourceProvisioning.html","CommonResourceProvisioning",false,new Array(new WCN("54/operation/setCommonAttributes_31.html","setCommonAttributes",false,null)))),
					new Array(new WCN("54/binding/CommonResourceProvisioningSoapHttpBinding.html","CommonResourceProvisioningSoapHttpBinding",false,new Array(new WCN("54/operation/setCommonAttributes_31.html","setCommonAttributes",false,null))),new WCN("54/binding/CommonResourceProvisioningSoapJmsBinding.html","CommonResourceProvisioningSoapJmsBinding",false,new Array(new WCN("54/operation/setCommonAttributes_31.html","setCommonAttributes",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/crp/v1-0"] = "54/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/ep/v1-0"] =  new WC (
					new Array(new WCN("50/service/EquipmentProvisioningHttp.html","EquipmentProvisioningHttp",false,null),new WCN("50/service/EquipmentProvisioningJms.html","EquipmentProvisioningJms",false,null)),
					new Array(new WCN("50/message/provisionEquipmentException.html","provisionEquipmentException",false,null),new WCN("50/message/provisionEquipmentRequest.html","provisionEquipmentRequest",false,null),new WCN("50/message/provisionEquipmentResponse.html","provisionEquipmentResponse",false,null),new WCN("50/message/unprovisionEquipmentException.html","unprovisionEquipmentException",false,null),new WCN("50/message/unprovisionEquipmentRequest.html","unprovisionEquipmentRequest",false,null),new WCN("50/message/unprovisionEquipmentResponse.html","unprovisionEquipmentResponse",false,null)),
					new Array(new WCN("50/porttype/EquipmentProvisioning.html","EquipmentProvisioning",false,new Array(new WCN("50/operation/provisionEquipment_2.html","provisionEquipment",false,null),new WCN("50/operation/unprovisionEquipment_3.html","unprovisionEquipment",false,null)))),
					new Array(new WCN("50/binding/EquipmentProvisioningSoapHttpBinding.html","EquipmentProvisioningSoapHttpBinding",false,new Array(new WCN("50/operation/provisionEquipment_2.html","provisionEquipment",false,null),new WCN("50/operation/unprovisionEquipment_3.html","unprovisionEquipment",false,null))),new WCN("50/binding/EquipmentProvisioningSoapJmsBinding.html","EquipmentProvisioningSoapJmsBinding",false,new Array(new WCN("50/operation/provisionEquipment_2.html","provisionEquipment",false,null),new WCN("50/operation/unprovisionEquipment_3.html","unprovisionEquipment",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/ep/v1-0"] = "50/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/fdc/v1-0"] =  new WC (
					new Array(new WCN("58/service/FlowDomainControlHttp.html","FlowDomainControlHttp",false,null),new WCN("58/service/FlowDomainControlJms.html","FlowDomainControlJms",false,null)),
					new Array(new WCN("58/message/assignCptpsToMfdException.html","assignCptpsToMfdException",false,null),new WCN("58/message/assignCptpsToMfdRequest.html","assignCptpsToMfdRequest",false,null),new WCN("58/message/assignCptpsToMfdResponse.html","assignCptpsToMfdResponse",false,null),new WCN("58/message/associateCptpsWithFlowDomainException.html","associateCptpsWithFlowDomainException",false,null),new WCN("58/message/associateCptpsWithFlowDomainRequest.html","associateCptpsWithFlowDomainRequest",false,null),new WCN("58/message/associateCptpsWithFlowDomainResponse.html","associateCptpsWithFlowDomainResponse",false,null),new WCN("58/message/associateMfdsWithFlowDomainException.html","associateMfdsWithFlowDomainException",false,null),new WCN("58/message/associateMfdsWithFlowDomainRequest.html","associateMfdsWithFlowDomainRequest",false,null),new WCN("58/message/associateMfdsWithFlowDomainResponse.html","associateMfdsWithFlowDomainResponse",false,null),new WCN("58/message/createAndActivateFdfrException.html","createAndActivateFdfrException",false,null),new WCN("58/message/createAndActivateFdfrRequest.html","createAndActivateFdfrRequest",false,null),new WCN("58/message/createAndActivateFdfrResponse.html","createAndActivateFdfrResponse",false,null),new WCN("58/message/createFlowDomainException.html","createFlowDomainException",false,null),new WCN("58/message/createFlowDomainRequest.html","createFlowDomainRequest",false,null),new WCN("58/message/createFlowDomainResponse.html","createFlowDomainResponse",false,null),new WCN("58/message/createMfdException.html","createMfdException",false,null),new WCN("58/message/createMfdRequest.html","createMfdRequest",false,null),new WCN("58/message/createMfdResponse.html","createMfdResponse",false,null),new WCN("58/message/deactivateAndDeleteFdfrException.html","deactivateAndDeleteFdfrException",false,null),new WCN("58/message/deactivateAndDeleteFdfrRequest.html","deactivateAndDeleteFdfrRequest",false,null),new WCN("58/message/deactivateAndDeleteFdfrResponse.html","deactivateAndDeleteFdfrResponse",false,null),new WCN("58/message/deAssociateCptpsFromFlowDomainException.html","deAssociateCptpsFromFlowDomainException",false,null),new WCN("58/message/deAssociateCptpsFromFlowDomainRequest.html","deAssociateCptpsFromFlowDomainRequest",false,null),new WCN("58/message/deAssociateCptpsFromFlowDomainResponse.html","deAssociateCptpsFromFlowDomainResponse",false,null),new WCN("58/message/deAssociateMfdsFromFlowDomainException.html","deAssociateMfdsFromFlowDomainException",false,null),new WCN("58/message/deAssociateMfdsFromFlowDomainRequest.html","deAssociateMfdsFromFlowDomainRequest",false,null),new WCN("58/message/deAssociateMfdsFromFlowDomainResponse.html","deAssociateMfdsFromFlowDomainResponse",false,null),new WCN("58/message/deleteFlowDomainException.html","deleteFlowDomainException",false,null),new WCN("58/message/deleteFlowDomainRequest.html","deleteFlowDomainRequest",false,null),new WCN("58/message/deleteFlowDomainResponse.html","deleteFlowDomainResponse",false,null),new WCN("58/message/deleteMfdException.html","deleteMfdException",false,null),new WCN("58/message/deleteMfdRequest.html","deleteMfdRequest",false,null),new WCN("58/message/deleteMfdResponse.html","deleteMfdResponse",false,null),new WCN("58/message/modifyFdfrException.html","modifyFdfrException",false,null),new WCN("58/message/modifyFdfrRequest.html","modifyFdfrRequest",false,null),new WCN("58/message/modifyFdfrResponse.html","modifyFdfrResponse",false,null),new WCN("58/message/modifyFlowDomainException.html","modifyFlowDomainException",false,null),new WCN("58/message/modifyFlowDomainRequest.html","modifyFlowDomainRequest",false,null),new WCN("58/message/modifyFlowDomainResponse.html","modifyFlowDomainResponse",false,null),new WCN("58/message/modifyMfdException.html","modifyMfdException",false,null),new WCN("58/message/modifyMfdRequest.html","modifyMfdRequest",false,null),new WCN("58/message/modifyMfdResponse.html","modifyMfdResponse",false,null),new WCN("58/message/unassignCptpsFromMfdException.html","unassignCptpsFromMfdException",false,null),new WCN("58/message/unassignCptpsFromMfdRequest.html","unassignCptpsFromMfdRequest",false,null),new WCN("58/message/unassignCptpsFromMfdResponse.html","unassignCptpsFromMfdResponse",false,null)),
					new Array(new WCN("58/porttype/FlowDomainControl.html","FlowDomainControl",false,new Array(new WCN("58/operation/assignCptpsToMfd_45.html","assignCptpsToMfd",false,null),new WCN("58/operation/associateCptpsWithFlowDomain_46.html","associateCptpsWithFlowDomain",false,null),new WCN("58/operation/associateMfdsWithFlowDomain_47.html","associateMfdsWithFlowDomain",false,null),new WCN("58/operation/createAndActivateFdfr_48.html","createAndActivateFdfr",false,null),new WCN("58/operation/createFlowDomain_49.html","createFlowDomain",false,null),new WCN("58/operation/createMfd_50.html","createMfd",false,null),new WCN("58/operation/deactivateAndDeleteFdfr_51.html","deactivateAndDeleteFdfr",false,null),new WCN("58/operation/deAssociateCptpsFromFlowDomain_52.html","deAssociateCptpsFromFlowDomain",false,null),new WCN("58/operation/deAssociateMfdsFromFlowDomain_53.html","deAssociateMfdsFromFlowDomain",false,null),new WCN("58/operation/deleteFlowDomain_54.html","deleteFlowDomain",false,null),new WCN("58/operation/deleteMfd_55.html","deleteMfd",false,null),new WCN("58/operation/modifyFdfr_56.html","modifyFdfr",false,null),new WCN("58/operation/modifyFlowDomain_57.html","modifyFlowDomain",false,null),new WCN("58/operation/modifyMfd_58.html","modifyMfd",false,null),new WCN("58/operation/unassignCptpsFromMfd_59.html","unassignCptpsFromMfd",false,null)))),
					new Array(new WCN("58/binding/FlowDomainControlSoapHttpBinding.html","FlowDomainControlSoapHttpBinding",false,new Array(new WCN("58/operation/assignCptpsToMfd_45.html","assignCptpsToMfd",false,null),new WCN("58/operation/associateCptpsWithFlowDomain_46.html","associateCptpsWithFlowDomain",false,null),new WCN("58/operation/associateMfdsWithFlowDomain_47.html","associateMfdsWithFlowDomain",false,null),new WCN("58/operation/createAndActivateFdfr_48.html","createAndActivateFdfr",false,null),new WCN("58/operation/createFlowDomain_49.html","createFlowDomain",false,null),new WCN("58/operation/createMfd_50.html","createMfd",false,null),new WCN("58/operation/deactivateAndDeleteFdfr_51.html","deactivateAndDeleteFdfr",false,null),new WCN("58/operation/deAssociateCptpsFromFlowDomain_52.html","deAssociateCptpsFromFlowDomain",false,null),new WCN("58/operation/deAssociateMfdsFromFlowDomain_53.html","deAssociateMfdsFromFlowDomain",false,null),new WCN("58/operation/deleteFlowDomain_54.html","deleteFlowDomain",false,null),new WCN("58/operation/deleteMfd_55.html","deleteMfd",false,null),new WCN("58/operation/modifyFdfr_56.html","modifyFdfr",false,null),new WCN("58/operation/modifyFlowDomain_57.html","modifyFlowDomain",false,null),new WCN("58/operation/modifyMfd_58.html","modifyMfd",false,null),new WCN("58/operation/unassignCptpsFromMfd_59.html","unassignCptpsFromMfd",false,null))),new WCN("58/binding/FlowDomainControlSoapJmsBinding.html","FlowDomainControlSoapJmsBinding",false,new Array(new WCN("58/operation/assignCptpsToMfd_45.html","assignCptpsToMfd",false,null),new WCN("58/operation/associateCptpsWithFlowDomain_46.html","associateCptpsWithFlowDomain",false,null),new WCN("58/operation/associateMfdsWithFlowDomain_47.html","associateMfdsWithFlowDomain",false,null),new WCN("58/operation/createAndActivateFdfr_48.html","createAndActivateFdfr",false,null),new WCN("58/operation/createFlowDomain_49.html","createFlowDomain",false,null),new WCN("58/operation/createMfd_50.html","createMfd",false,null),new WCN("58/operation/deactivateAndDeleteFdfr_51.html","deactivateAndDeleteFdfr",false,null),new WCN("58/operation/deAssociateCptpsFromFlowDomain_52.html","deAssociateCptpsFromFlowDomain",false,null),new WCN("58/operation/deAssociateMfdsFromFlowDomain_53.html","deAssociateMfdsFromFlowDomain",false,null),new WCN("58/operation/deleteFlowDomain_54.html","deleteFlowDomain",false,null),new WCN("58/operation/deleteMfd_55.html","deleteMfd",false,null),new WCN("58/operation/modifyFdfr_56.html","modifyFdfr",false,null),new WCN("58/operation/modifyFlowDomain_57.html","modifyFlowDomain",false,null),new WCN("58/operation/modifyMfd_58.html","modifyMfd",false,null),new WCN("58/operation/unassignCptpsFromMfd_59.html","unassignCptpsFromMfd",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/fdc/v1-0"] = "58/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/gctc/v1-0"] =  new WC (
					new Array(new WCN("52/service/GuiCutThroughControlHttp.html","GuiCutThroughControlHttp",false,null),new WCN("52/service/GuiCutThroughControlJms.html","GuiCutThroughControlJms",false,null)),
					new Array(new WCN("52/message/destroyGuiCutThroughException.html","destroyGuiCutThroughException",false,null),new WCN("52/message/destroyGuiCutThroughRequest.html","destroyGuiCutThroughRequest",false,null),new WCN("52/message/destroyGuiCutThroughResponse.html","destroyGuiCutThroughResponse",false,null),new WCN("52/message/getGuiCutThroughProfileInfoException.html","getGuiCutThroughProfileInfoException",false,null),new WCN("52/message/getGuiCutThroughProfileInfoRequest.html","getGuiCutThroughProfileInfoRequest",false,null),new WCN("52/message/getGuiCutThroughProfileInfoResponse.html","getGuiCutThroughProfileInfoResponse",false,null),new WCN("52/message/launchGuiCutThroughException.html","launchGuiCutThroughException",false,null),new WCN("52/message/launchGuiCutThroughRequest.html","launchGuiCutThroughRequest",false,null),new WCN("52/message/launchGuiCutThroughResponse.html","launchGuiCutThroughResponse",false,null)),
					new Array(new WCN("52/porttype/GuiCutThroughControl.html","GuiCutThroughControl",false,new Array(new WCN("52/operation/destroyGuiCutThrough_19.html","destroyGuiCutThrough",false,null),new WCN("52/operation/getGuiCutThroughProfileInfo_20.html","getGuiCutThroughProfileInfo",false,null),new WCN("52/operation/launchGuiCutThrough_21.html","launchGuiCutThrough",false,null)))),
					new Array(new WCN("52/binding/GuiCutThroughControlSoapHttpBinding.html","GuiCutThroughControlSoapHttpBinding",false,new Array(new WCN("52/operation/destroyGuiCutThrough_19.html","destroyGuiCutThrough",false,null),new WCN("52/operation/getGuiCutThroughProfileInfo_20.html","getGuiCutThroughProfileInfo",false,null),new WCN("52/operation/launchGuiCutThrough_21.html","launchGuiCutThrough",false,null))),new WCN("52/binding/GuiCutThroughControlSoapJmsBinding.html","GuiCutThroughControlSoapJmsBinding",false,new Array(new WCN("52/operation/destroyGuiCutThrough_19.html","destroyGuiCutThrough",false,null),new WCN("52/operation/getGuiCutThroughProfileInfo_20.html","getGuiCutThroughProfileInfo",false,null),new WCN("52/operation/launchGuiCutThrough_21.html","launchGuiCutThrough",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/gctc/v1-0"] = "52/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/sdc/v1-0"] =  new WC (
					new Array(new WCN("55/service/SoftwareAndDataControlHttp.html","SoftwareAndDataControlHttp",false,null),new WCN("55/service/SoftwareAndDataControlJms.html","SoftwareAndDataControlJms",false,null)),
					new Array(new WCN("55/message/abortMeBackupException.html","abortMeBackupException",false,null),new WCN("55/message/abortMeBackupRequest.html","abortMeBackupRequest",false,null),new WCN("55/message/abortMeBackupResponse.html","abortMeBackupResponse",false,null),new WCN("55/message/backupMeException.html","backupMeException",false,null),new WCN("55/message/backupMeRequest.html","backupMeRequest",false,null),new WCN("55/message/backupMeResponse.html","backupMeResponse",false,null),new WCN("55/message/getBackupListException.html","getBackupListException",false,null),new WCN("55/message/getBackupListRequest.html","getBackupListRequest",false,null),new WCN("55/message/getBackupListResponse.html","getBackupListResponse",false,null),new WCN("55/message/getMeBackupStatusException.html","getMeBackupStatusException",false,null),new WCN("55/message/getMeBackupStatusRequest.html","getMeBackupStatusRequest",false,null),new WCN("55/message/getMeBackupStatusResponse.html","getMeBackupStatusResponse",false,null)),
					new Array(new WCN("55/porttype/SoftwareAndDataControl.html","SoftwareAndDataControl",false,new Array(new WCN("55/operation/abortMeBackup_32.html","abortMeBackup",false,null),new WCN("55/operation/backupMe_33.html","backupMe",false,null),new WCN("55/operation/getBackupList_34.html","getBackupList",false,null),new WCN("55/operation/getMeBackupStatus_35.html","getMeBackupStatus",false,null)))),
					new Array(new WCN("55/binding/SoftwareAndDataControlSoapHttpBinding.html","SoftwareAndDataControlSoapHttpBinding",false,new Array(new WCN("55/operation/abortMeBackup_32.html","abortMeBackup",false,null),new WCN("55/operation/backupMe_33.html","backupMe",false,null),new WCN("55/operation/getBackupList_34.html","getBackupList",false,null),new WCN("55/operation/getMeBackupStatus_35.html","getMeBackupStatus",false,null))),new WCN("55/binding/SoftwareAndDataControlSoapJmsBinding.html","SoftwareAndDataControlSoapJmsBinding",false,new Array(new WCN("55/operation/abortMeBackup_32.html","abortMeBackup",false,null),new WCN("55/operation/backupMe_33.html","backupMe",false,null),new WCN("55/operation/getBackupList_34.html","getBackupList",false,null),new WCN("55/operation/getMeBackupStatus_35.html","getMeBackupStatus",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/sdc/v1-0"] = "55/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/tcpc/v1-0"] =  new WC (
					new Array(new WCN("57/service/TrafficConditioningProfileControlHttp.html","TrafficConditioningProfileControlHttp",false,null),new WCN("57/service/TrafficConditioningProfileControlJms.html","TrafficConditioningProfileControlJms",false,null)),
					new Array(new WCN("57/message/createTcProfileException.html","createTcProfileException",false,null),new WCN("57/message/createTcProfileRequest.html","createTcProfileRequest",false,null),new WCN("57/message/createTcProfileResponse.html","createTcProfileResponse",false,null),new WCN("57/message/deleteTcProfileException.html","deleteTcProfileException",false,null),new WCN("57/message/deleteTcProfileRequest.html","deleteTcProfileRequest",false,null),new WCN("57/message/deleteTcProfileResponse.html","deleteTcProfileResponse",false,null),new WCN("57/message/modifyTcProfileException.html","modifyTcProfileException",false,null),new WCN("57/message/modifyTcProfileRequest.html","modifyTcProfileRequest",false,null),new WCN("57/message/modifyTcProfileResponse.html","modifyTcProfileResponse",false,null)),
					new Array(new WCN("57/porttype/TrafficConditioningProfileControl.html","TrafficConditioningProfileControl",false,new Array(new WCN("57/operation/createTcProfile_42.html","createTcProfile",false,null),new WCN("57/operation/deleteTcProfile_43.html","deleteTcProfile",false,null),new WCN("57/operation/modifyTcProfile_44.html","modifyTcProfile",false,null)))),
					new Array(new WCN("57/binding/TrafficConditioningProfileControlSoapHttpBinding.html","TrafficConditioningProfileControlSoapHttpBinding",false,new Array(new WCN("57/operation/createTcProfile_42.html","createTcProfile",false,null),new WCN("57/operation/deleteTcProfile_43.html","deleteTcProfile",false,null),new WCN("57/operation/modifyTcProfile_44.html","modifyTcProfile",false,null))),new WCN("57/binding/TrafficConditioningProfileControlSoapJmsBinding.html","TrafficConditioningProfileControlSoapJmsBinding",false,new Array(new WCN("57/operation/createTcProfile_42.html","createTcProfile",false,null),new WCN("57/operation/deleteTcProfile_43.html","deleteTcProfile",false,null),new WCN("57/operation/modifyTcProfile_44.html","modifyTcProfile",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/tcpc/v1-0"] = "57/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/tlc/v1-0"] =  new WC (
					new Array(new WCN("49/service/TopologicalLinkControlHttp.html","TopologicalLinkControlHttp",false,null),new WCN("49/service/TopologicalLinkControlJms.html","TopologicalLinkControlJms",false,null)),
					new Array(new WCN("49/message/createTopologicalLinkException.html","createTopologicalLinkException",false,null),new WCN("49/message/createTopologicalLinkRequest.html","createTopologicalLinkRequest",false,null),new WCN("49/message/createTopologicalLinkResponse.html","createTopologicalLinkResponse",false,null),new WCN("49/message/deleteTopologicalLinkException.html","deleteTopologicalLinkException",false,null),new WCN("49/message/deleteTopologicalLinkRequest.html","deleteTopologicalLinkRequest",false,null),new WCN("49/message/deleteTopologicalLinkResponse.html","deleteTopologicalLinkResponse",false,null)),
					new Array(new WCN("49/porttype/TopologicalLinkControl.html","TopologicalLinkControl",false,new Array(new WCN("49/operation/createTopologicalLink_0.html","createTopologicalLink",false,null),new WCN("49/operation/deleteTopologicalLink_1.html","deleteTopologicalLink",false,null)))),
					new Array(new WCN("49/binding/TopologicalLinkControlSoapHttpBinding.html","TopologicalLinkControlSoapHttpBinding",false,new Array(new WCN("49/operation/createTopologicalLink_0.html","createTopologicalLink",false,null),new WCN("49/operation/deleteTopologicalLink_1.html","deleteTopologicalLink",false,null))),new WCN("49/binding/TopologicalLinkControlSoapJmsBinding.html","TopologicalLinkControlSoapJmsBinding",false,new Array(new WCN("49/operation/createTopologicalLink_0.html","createTopologicalLink",false,null),new WCN("49/operation/deleteTopologicalLink_1.html","deleteTopologicalLink",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/tlc/v1-0"] = "49/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/tmdc/v1-0"] =  new WC (
					new Array(new WCN("56/service/TransmissionDescriptorControlHttp.html","TransmissionDescriptorControlHttp",false,null),new WCN("56/service/TransmissionDescriptorControlJms.html","TransmissionDescriptorControlJms",false,null)),
					new Array(new WCN("56/message/createTransmissionDescriptorException.html","createTransmissionDescriptorException",false,null),new WCN("56/message/createTransmissionDescriptorRequest.html","createTransmissionDescriptorRequest",false,null),new WCN("56/message/createTransmissionDescriptorResponse.html","createTransmissionDescriptorResponse",false,null),new WCN("56/message/deleteTransmissionDescriptorException.html","deleteTransmissionDescriptorException",false,null),new WCN("56/message/deleteTransmissionDescriptorRequest.html","deleteTransmissionDescriptorRequest",false,null),new WCN("56/message/deleteTransmissionDescriptorResponse.html","deleteTransmissionDescriptorResponse",false,null),new WCN("56/message/modifyTransmissionDescriptorException.html","modifyTransmissionDescriptorException",false,null),new WCN("56/message/modifyTransmissionDescriptorRequest.html","modifyTransmissionDescriptorRequest",false,null),new WCN("56/message/modifyTransmissionDescriptorResponse.html","modifyTransmissionDescriptorResponse",false,null),new WCN("56/message/setTmdAssociationException.html","setTmdAssociationException",false,null),new WCN("56/message/setTmdAssociationRequest.html","setTmdAssociationRequest",false,null),new WCN("56/message/setTmdAssociationResponse.html","setTmdAssociationResponse",false,null),new WCN("56/message/validateTmdAssignmentToObjectException.html","validateTmdAssignmentToObjectException",false,null),new WCN("56/message/validateTmdAssignmentToObjectRequest.html","validateTmdAssignmentToObjectRequest",false,null),new WCN("56/message/validateTmdAssignmentToObjectResponse.html","validateTmdAssignmentToObjectResponse",false,null),new WCN("56/message/verifyTmdAssignmentException.html","verifyTmdAssignmentException",false,null),new WCN("56/message/verifyTmdAssignmentRequest.html","verifyTmdAssignmentRequest",false,null),new WCN("56/message/verifyTmdAssignmentResponse.html","verifyTmdAssignmentResponse",false,null)),
					new Array(new WCN("56/porttype/TransmissionDescriptorControl.html","TransmissionDescriptorControl",false,new Array(new WCN("56/operation/createTransmissionDescriptor_36.html","createTransmissionDescriptor",false,null),new WCN("56/operation/deleteTransmissionDescriptor_37.html","deleteTransmissionDescriptor",false,null),new WCN("56/operation/modifyTransmissionDescriptor_38.html","modifyTransmissionDescriptor",false,null),new WCN("56/operation/setTmdAssociation_40.html","setTmdAssociation",false,null),new WCN("56/operation/validateTmdAssignmentToObject_39.html","validateTmdAssignmentToObject",false,null),new WCN("56/operation/verifyTmdAssignment_41.html","verifyTmdAssignment",false,null)))),
					new Array(new WCN("56/binding/TransmissionDescriptorControlSoapHttpBinding.html","TransmissionDescriptorControlSoapHttpBinding",false,new Array(new WCN("56/operation/createTransmissionDescriptor_36.html","createTransmissionDescriptor",false,null),new WCN("56/operation/deleteTransmissionDescriptor_37.html","deleteTransmissionDescriptor",false,null),new WCN("56/operation/modifyTransmissionDescriptor_38.html","modifyTransmissionDescriptor",false,null),new WCN("56/operation/setTmdAssociation_40.html","setTmdAssociation",false,null),new WCN("56/operation/validateTmdAssignmentToObject_39.html","validateTmdAssignmentToObject",false,null),new WCN("56/operation/verifyTmdAssignment_41.html","verifyTmdAssignment",false,null))),new WCN("56/binding/TransmissionDescriptorControlSoapJmsBinding.html","TransmissionDescriptorControlSoapJmsBinding",false,new Array(new WCN("56/operation/createTransmissionDescriptor_36.html","createTransmissionDescriptor",false,null),new WCN("56/operation/deleteTransmissionDescriptor_37.html","deleteTransmissionDescriptor",false,null),new WCN("56/operation/modifyTransmissionDescriptor_38.html","modifyTransmissionDescriptor",false,null),new WCN("56/operation/setTmdAssociation_40.html","setTmdAssociation",false,null),new WCN("56/operation/validateTmdAssignmentToObject_39.html","validateTmdAssignmentToObject",false,null),new WCN("56/operation/verifyTmdAssignment_41.html","verifyTmdAssignment",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/tmdc/v1-0"] = "56/index.html";
wcDB ["http://www.tmforum.org/mtop/rp/wsdl/tpc/v1-0"] =  new WC (
					new Array(new WCN("53/service/TerminationPointControlHttp.html","TerminationPointControlHttp",false,null),new WCN("53/service/TerminationPointControlJms.html","TerminationPointControlJms",false,null)),
					new Array(new WCN("53/message/createFtpException.html","createFtpException",false,null),new WCN("53/message/createFtpRequest.html","createFtpRequest",false,null),new WCN("53/message/createFtpResponse.html","createFtpResponse",false,null),new WCN("53/message/createGtpException.html","createGtpException",false,null),new WCN("53/message/createGtpRequest.html","createGtpRequest",false,null),new WCN("53/message/createGtpResponse.html","createGtpResponse",false,null),new WCN("53/message/createTpPoolException.html","createTpPoolException",false,null),new WCN("53/message/createTpPoolRequest.html","createTpPoolRequest",false,null),new WCN("53/message/createTpPoolResponse.html","createTpPoolResponse",false,null),new WCN("53/message/deleteFtpException.html","deleteFtpException",false,null),new WCN("53/message/deleteFtpRequest.html","deleteFtpRequest",false,null),new WCN("53/message/deleteFtpResponse.html","deleteFtpResponse",false,null),new WCN("53/message/deleteGtpException.html","deleteGtpException",false,null),new WCN("53/message/deleteGtpRequest.html","deleteGtpRequest",false,null),new WCN("53/message/deleteGtpResponse.html","deleteGtpResponse",false,null),new WCN("53/message/deleteTpPoolException.html","deleteTpPoolException",false,null),new WCN("53/message/deleteTpPoolRequest.html","deleteTpPoolRequest",false,null),new WCN("53/message/deleteTpPoolResponse.html","deleteTpPoolResponse",false,null),new WCN("53/message/modifyGtpException.html","modifyGtpException",false,null),new WCN("53/message/modifyGtpRequest.html","modifyGtpRequest",false,null),new WCN("53/message/modifyGtpResponse.html","modifyGtpResponse",false,null),new WCN("53/message/modifyTpPoolException.html","modifyTpPoolException",false,null),new WCN("53/message/modifyTpPoolRequest.html","modifyTpPoolRequest",false,null),new WCN("53/message/modifyTpPoolResponse.html","modifyTpPoolResponse",false,null),new WCN("53/message/setTpDataException.html","setTpDataException",false,null),new WCN("53/message/setTpDataRequest.html","setTpDataRequest",false,null),new WCN("53/message/setTpDataResponse.html","setTpDataResponse",false,null)),
					new Array(new WCN("53/porttype/TerminationPointControl.html","TerminationPointControl",false,new Array(new WCN("53/operation/createFtp_22.html","createFtp",false,null),new WCN("53/operation/createGtp_23.html","createGtp",false,null),new WCN("53/operation/createTpPool_24.html","createTpPool",false,null),new WCN("53/operation/deleteFtp_25.html","deleteFtp",false,null),new WCN("53/operation/deleteGtp_26.html","deleteGtp",false,null),new WCN("53/operation/deleteTpPool_27.html","deleteTpPool",false,null),new WCN("53/operation/modifyGtp_28.html","modifyGtp",false,null),new WCN("53/operation/modifyTpPool_29.html","modifyTpPool",false,null),new WCN("53/operation/setTpData_30.html","setTpData",false,null)))),
					new Array(new WCN("53/binding/TerminationPointControlSoapHttpBinding.html","TerminationPointControlSoapHttpBinding",false,new Array(new WCN("53/operation/createFtp_22.html","createFtp",false,null),new WCN("53/operation/createGtp_23.html","createGtp",false,null),new WCN("53/operation/createTpPool_24.html","createTpPool",false,null),new WCN("53/operation/deleteFtp_25.html","deleteFtp",false,null),new WCN("53/operation/deleteGtp_26.html","deleteGtp",false,null),new WCN("53/operation/deleteTpPool_27.html","deleteTpPool",false,null),new WCN("53/operation/modifyGtp_28.html","modifyGtp",false,null),new WCN("53/operation/modifyTpPool_29.html","modifyTpPool",false,null),new WCN("53/operation/setTpData_30.html","setTpData",false,null))),new WCN("53/binding/TerminationPointControlSoapJmsBinding.html","TerminationPointControlSoapJmsBinding",false,new Array(new WCN("53/operation/createFtp_22.html","createFtp",false,null),new WCN("53/operation/createGtp_23.html","createGtp",false,null),new WCN("53/operation/createTpPool_24.html","createTpPool",false,null),new WCN("53/operation/deleteFtp_25.html","deleteFtp",false,null),new WCN("53/operation/deleteGtp_26.html","deleteGtp",false,null),new WCN("53/operation/deleteTpPool_27.html","deleteTpPool",false,null),new WCN("53/operation/modifyGtp_28.html","modifyGtp",false,null),new WCN("53/operation/modifyTpPool_29.html","modifyTpPool",false,null),new WCN("53/operation/setTpData_30.html","setTpData",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rp/wsdl/tpc/v1-0"] = "53/index.html";
