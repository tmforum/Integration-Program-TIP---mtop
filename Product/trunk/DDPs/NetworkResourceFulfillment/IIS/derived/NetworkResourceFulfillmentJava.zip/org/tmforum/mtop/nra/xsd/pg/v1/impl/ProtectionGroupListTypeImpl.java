/*
 * XML Type:  ProtectionGroupListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pg/v1
 * Java type: org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pg.v1.impl;
/**
 * An XML ProtectionGroupListType(@http://www.tmforum.org/mtop/nra/xsd/pg/v1).
 *
 * This is a complex type.
 */
public class ProtectionGroupListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupListType
{
    
    public ProtectionGroupListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PG$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "pg");
    
    
    /**
     * Gets a List of "pg" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType> getPgList()
    {
        final class PgList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType>
        {
            public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType get(int i)
                { return ProtectionGroupListTypeImpl.this.getPgArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType set(int i, org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType o)
            {
                org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType old = ProtectionGroupListTypeImpl.this.getPgArray(i);
                ProtectionGroupListTypeImpl.this.setPgArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType o)
                { ProtectionGroupListTypeImpl.this.insertNewPg(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType old = ProtectionGroupListTypeImpl.this.getPgArray(i);
                ProtectionGroupListTypeImpl.this.removePg(i);
                return old;
            }
            
            public int size()
                { return ProtectionGroupListTypeImpl.this.sizeOfPgArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PgList();
        }
    }
    
    /**
     * Gets array of all "pg" elements
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType[] getPgArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PG$0, targetList);
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType[] result = new org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pg" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType getPgArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PG$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pg" element
     */
    public int sizeOfPgArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PG$0);
        }
    }
    
    /**
     * Sets array of all "pg" element
     */
    public void setPgArray(org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType[] pgArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pgArray, PG$0);
        }
    }
    
    /**
     * Sets ith "pg" element
     */
    public void setPgArray(int i, org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType pg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PG$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pg);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pg" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType insertNewPg(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().insert_element_user(PG$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pg" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType addNewPg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().add_element_user(PG$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pg" element
     */
    public void removePg(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PG$0, i);
        }
    }
}
