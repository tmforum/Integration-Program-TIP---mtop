/*
 * XML Type:  EquipmentHolderInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML EquipmentHolderInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class EquipmentHolderInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType
{
    
    public EquipmentHolderInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EHNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ehNm");
    private static final javax.xml.namespace.QName EHATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ehAttrs");
    private static final javax.xml.namespace.QName EHLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ehList");
    private static final javax.xml.namespace.QName EQINV$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "eqInv");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "ehNm" element
     */
    public java.lang.String getEhNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EHNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ehNm" element
     */
    public org.apache.xmlbeans.XmlString xgetEhNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EHNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "ehNm" element
     */
    public boolean isSetEhNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EHNM$0) != 0;
        }
    }
    
    /**
     * Sets the "ehNm" element
     */
    public void setEhNm(java.lang.String ehNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EHNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EHNM$0);
            }
            target.setStringValue(ehNm);
        }
    }
    
    /**
     * Sets (as xml) the "ehNm" element
     */
    public void xsetEhNm(org.apache.xmlbeans.XmlString ehNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EHNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EHNM$0);
            }
            target.set(ehNm);
        }
    }
    
    /**
     * Unsets the "ehNm" element
     */
    public void unsetEhNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EHNM$0, 0);
        }
    }
    
    /**
     * Gets the "ehAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType getEhAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().find_element_user(EHATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ehAttrs" element
     */
    public boolean isSetEhAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EHATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "ehAttrs" element
     */
    public void setEhAttrs(org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType ehAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().find_element_user(EHATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().add_element_user(EHATTRS$2);
            }
            target.set(ehAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "ehAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType addNewEhAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().add_element_user(EHATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "ehAttrs" element
     */
    public void unsetEhAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EHATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "ehList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList getEhList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList)get_store().find_element_user(EHLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ehList" element
     */
    public boolean isSetEhList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EHLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "ehList" element
     */
    public void setEhList(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList ehList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList)get_store().find_element_user(EHLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList)get_store().add_element_user(EHLIST$4);
            }
            target.set(ehList);
        }
    }
    
    /**
     * Appends and returns a new empty "ehList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList addNewEhList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList)get_store().add_element_user(EHLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ehList" element
     */
    public void unsetEhList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EHLIST$4, 0);
        }
    }
    
    /**
     * Gets the "eqInv" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType getEqInv()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType)get_store().find_element_user(EQINV$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "eqInv" element
     */
    public boolean isSetEqInv()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQINV$6) != 0;
        }
    }
    
    /**
     * Sets the "eqInv" element
     */
    public void setEqInv(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType eqInv)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType)get_store().find_element_user(EQINV$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType)get_store().add_element_user(EQINV$6);
            }
            target.set(eqInv);
        }
    }
    
    /**
     * Appends and returns a new empty "eqInv" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType addNewEqInv()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType)get_store().add_element_user(EQINV$6);
            return target;
        }
    }
    
    /**
     * Unsets the "eqInv" element
     */
    public void unsetEqInv()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQINV$6, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$8) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$8);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$8);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$8, 0);
        }
    }
    /**
     * An XML ehList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class EhListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList
    {
        
        public EhListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EHINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ehInv");
        
        
        /**
         * Gets a List of "ehInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType> getEhInvList()
        {
            final class EhInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType get(int i)
                    { return EhListImpl.this.getEhInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType old = EhListImpl.this.getEhInvArray(i);
                    EhListImpl.this.setEhInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType o)
                    { EhListImpl.this.insertNewEhInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType old = EhListImpl.this.getEhInvArray(i);
                    EhListImpl.this.removeEhInv(i);
                    return old;
                }
                
                public int size()
                    { return EhListImpl.this.sizeOfEhInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new EhInvList();
            }
        }
        
        /**
         * Gets array of all "ehInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] getEhInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EHINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "ehInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType getEhInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType)get_store().find_element_user(EHINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "ehInv" element
         */
        public int sizeOfEhInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EHINV$0);
            }
        }
        
        /**
         * Sets array of all "ehInv" element
         */
        public void setEhInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] ehInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(ehInvArray, EHINV$0);
            }
        }
        
        /**
         * Sets ith "ehInv" element
         */
        public void setEhInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType ehInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType)get_store().find_element_user(EHINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(ehInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ehInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType insertNewEhInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType)get_store().insert_element_user(EHINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ehInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType addNewEhInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType)get_store().add_element_user(EHINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "ehInv" element
         */
        public void removeEhInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EHINV$0, i);
            }
        }
    }
}
