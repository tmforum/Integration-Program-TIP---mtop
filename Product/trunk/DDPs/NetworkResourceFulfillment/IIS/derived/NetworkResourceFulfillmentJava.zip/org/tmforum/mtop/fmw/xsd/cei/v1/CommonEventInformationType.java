/*
 * XML Type:  CommonEventInformationType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cei/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cei.v1;


/**
 * An XML CommonEventInformationType(@http://www.tmforum.org/mtop/fmw/xsd/cei/v1).
 *
 * This is a complex type.
 */
public interface CommonEventInformationType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CommonEventInformationType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("commoneventinformationtypeda35type");
    
    /**
     * Gets the "notificationId" element
     */
    java.lang.String getNotificationId();
    
    /**
     * Gets (as xml) the "notificationId" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType xgetNotificationId();
    
    /**
     * True if has "notificationId" element
     */
    boolean isSetNotificationId();
    
    /**
     * Sets the "notificationId" element
     */
    void setNotificationId(java.lang.String notificationId);
    
    /**
     * Sets (as xml) the "notificationId" element
     */
    void xsetNotificationId(org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType notificationId);
    
    /**
     * Unsets the "notificationId" element
     */
    void unsetNotificationId();
    
    /**
     * Gets the "sourceTime" element
     */
    java.util.Calendar getSourceTime();
    
    /**
     * Gets (as xml) the "sourceTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetSourceTime();
    
    /**
     * True if has "sourceTime" element
     */
    boolean isSetSourceTime();
    
    /**
     * Sets the "sourceTime" element
     */
    void setSourceTime(java.util.Calendar sourceTime);
    
    /**
     * Sets (as xml) the "sourceTime" element
     */
    void xsetSourceTime(org.apache.xmlbeans.XmlDateTime sourceTime);
    
    /**
     * Unsets the "sourceTime" element
     */
    void unsetSourceTime();
    
    /**
     * Gets the "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
    
    /**
     * True if has "vendorExtensions" element
     */
    boolean isSetVendorExtensions();
    
    /**
     * Sets the "vendorExtensions" element
     */
    void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
    
    /**
     * Unsets the "vendorExtensions" element
     */
    void unsetVendorExtensions();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        /** @deprecated No need to be able to create instances of abstract types */
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType newInstance() {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        /** @deprecated No need to be able to create instances of abstract types */
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
