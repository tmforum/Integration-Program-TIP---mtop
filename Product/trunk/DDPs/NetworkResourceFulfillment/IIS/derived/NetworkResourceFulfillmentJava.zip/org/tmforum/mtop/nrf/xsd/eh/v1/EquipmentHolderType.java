/*
 * XML Type:  EquipmentHolderType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/eh/v1
 * Java type: org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.eh.v1;


/**
 * An XML EquipmentHolderType(@http://www.tmforum.org/mtop/nrf/xsd/eh/v1).
 *
 * This is a complex type.
 */
public interface EquipmentHolderType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EquipmentHolderType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("equipmentholdertype4832type");
    
    /**
     * Gets the "isReportingAlarm" element
     */
    boolean getIsReportingAlarm();
    
    /**
     * Gets (as xml) the "isReportingAlarm" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsReportingAlarm();
    
    /**
     * Tests for nil "isReportingAlarm" element
     */
    boolean isNilIsReportingAlarm();
    
    /**
     * True if has "isReportingAlarm" element
     */
    boolean isSetIsReportingAlarm();
    
    /**
     * Sets the "isReportingAlarm" element
     */
    void setIsReportingAlarm(boolean isReportingAlarm);
    
    /**
     * Sets (as xml) the "isReportingAlarm" element
     */
    void xsetIsReportingAlarm(org.apache.xmlbeans.XmlBoolean isReportingAlarm);
    
    /**
     * Nils the "isReportingAlarm" element
     */
    void setNilIsReportingAlarm();
    
    /**
     * Unsets the "isReportingAlarm" element
     */
    void unsetIsReportingAlarm();
    
    /**
     * Gets the "holderType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType getHolderType();
    
    /**
     * Tests for nil "holderType" element
     */
    boolean isNilHolderType();
    
    /**
     * True if has "holderType" element
     */
    boolean isSetHolderType();
    
    /**
     * Sets the "holderType" element
     */
    void setHolderType(org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType holderType);
    
    /**
     * Appends and returns a new empty "holderType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType addNewHolderType();
    
    /**
     * Nils the "holderType" element
     */
    void setNilHolderType();
    
    /**
     * Unsets the "holderType" element
     */
    void unsetHolderType();
    
    /**
     * Gets the "acceptableEquipmentTypeList" element
     */
    org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList getAcceptableEquipmentTypeList();
    
    /**
     * Tests for nil "acceptableEquipmentTypeList" element
     */
    boolean isNilAcceptableEquipmentTypeList();
    
    /**
     * True if has "acceptableEquipmentTypeList" element
     */
    boolean isSetAcceptableEquipmentTypeList();
    
    /**
     * Sets the "acceptableEquipmentTypeList" element
     */
    void setAcceptableEquipmentTypeList(org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList acceptableEquipmentTypeList);
    
    /**
     * Appends and returns a new empty "acceptableEquipmentTypeList" element
     */
    org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList addNewAcceptableEquipmentTypeList();
    
    /**
     * Nils the "acceptableEquipmentTypeList" element
     */
    void setNilAcceptableEquipmentTypeList();
    
    /**
     * Unsets the "acceptableEquipmentTypeList" element
     */
    void unsetAcceptableEquipmentTypeList();
    
    /**
     * Gets the "expectedOrInstalledEquipmentRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getExpectedOrInstalledEquipmentRef();
    
    /**
     * Tests for nil "expectedOrInstalledEquipmentRef" element
     */
    boolean isNilExpectedOrInstalledEquipmentRef();
    
    /**
     * True if has "expectedOrInstalledEquipmentRef" element
     */
    boolean isSetExpectedOrInstalledEquipmentRef();
    
    /**
     * Sets the "expectedOrInstalledEquipmentRef" element
     */
    void setExpectedOrInstalledEquipmentRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType expectedOrInstalledEquipmentRef);
    
    /**
     * Appends and returns a new empty "expectedOrInstalledEquipmentRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewExpectedOrInstalledEquipmentRef();
    
    /**
     * Nils the "expectedOrInstalledEquipmentRef" element
     */
    void setNilExpectedOrInstalledEquipmentRef();
    
    /**
     * Unsets the "expectedOrInstalledEquipmentRef" element
     */
    void unsetExpectedOrInstalledEquipmentRef();
    
    /**
     * Gets the "holderState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType.Enum getHolderState();
    
    /**
     * Gets (as xml) the "holderState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType xgetHolderState();
    
    /**
     * Tests for nil "holderState" element
     */
    boolean isNilHolderState();
    
    /**
     * True if has "holderState" element
     */
    boolean isSetHolderState();
    
    /**
     * Sets the "holderState" element
     */
    void setHolderState(org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType.Enum holderState);
    
    /**
     * Sets (as xml) the "holderState" element
     */
    void xsetHolderState(org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType holderState);
    
    /**
     * Nils the "holderState" element
     */
    void setNilHolderState();
    
    /**
     * Unsets the "holderState" element
     */
    void unsetHolderState();
    
    /**
     * Gets the "location" element
     */
    java.lang.String getLocation();
    
    /**
     * Gets (as xml) the "location" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.LocationType xgetLocation();
    
    /**
     * Tests for nil "location" element
     */
    boolean isNilLocation();
    
    /**
     * True if has "location" element
     */
    boolean isSetLocation();
    
    /**
     * Sets the "location" element
     */
    void setLocation(java.lang.String location);
    
    /**
     * Sets (as xml) the "location" element
     */
    void xsetLocation(org.tmforum.mtop.fmw.xsd.gen.v1.LocationType location);
    
    /**
     * Nils the "location" element
     */
    void setNilLocation();
    
    /**
     * Unsets the "location" element
     */
    void unsetLocation();
    
    /**
     * Gets the "manufacturer" element
     */
    java.lang.String getManufacturer();
    
    /**
     * Gets (as xml) the "manufacturer" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType xgetManufacturer();
    
    /**
     * Tests for nil "manufacturer" element
     */
    boolean isNilManufacturer();
    
    /**
     * True if has "manufacturer" element
     */
    boolean isSetManufacturer();
    
    /**
     * Sets the "manufacturer" element
     */
    void setManufacturer(java.lang.String manufacturer);
    
    /**
     * Sets (as xml) the "manufacturer" element
     */
    void xsetManufacturer(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType manufacturer);
    
    /**
     * Nils the "manufacturer" element
     */
    void setNilManufacturer();
    
    /**
     * Unsets the "manufacturer" element
     */
    void unsetManufacturer();
    
    /**
     * Gets the "manufactureDate" element
     */
    java.util.Calendar getManufactureDate();
    
    /**
     * Gets (as xml) the "manufactureDate" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType xgetManufactureDate();
    
    /**
     * Tests for nil "manufactureDate" element
     */
    boolean isNilManufactureDate();
    
    /**
     * True if has "manufactureDate" element
     */
    boolean isSetManufactureDate();
    
    /**
     * Sets the "manufactureDate" element
     */
    void setManufactureDate(java.util.Calendar manufactureDate);
    
    /**
     * Sets (as xml) the "manufactureDate" element
     */
    void xsetManufactureDate(org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType manufactureDate);
    
    /**
     * Nils the "manufactureDate" element
     */
    void setNilManufactureDate();
    
    /**
     * Unsets the "manufactureDate" element
     */
    void unsetManufactureDate();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * An XML acceptableEquipmentTypeList(@http://www.tmforum.org/mtop/nrf/xsd/eh/v1).
     *
     * This is a complex type.
     */
    public interface AcceptableEquipmentTypeList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AcceptableEquipmentTypeList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("acceptableequipmenttypelist8d02elemtype");
        
        /**
         * Gets a List of "acceptableEquipmentType" elements
         */
        java.util.List<java.lang.String> getAcceptableEquipmentTypeList();
        
        /**
         * Gets array of all "acceptableEquipmentType" elements
         * @deprecated
         */
        java.lang.String[] getAcceptableEquipmentTypeArray();
        
        /**
         * Gets ith "acceptableEquipmentType" element
         */
        java.lang.String getAcceptableEquipmentTypeArray(int i);
        
        /**
         * Gets (as xml) a List of "acceptableEquipmentType" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType> xgetAcceptableEquipmentTypeList();
        
        /**
         * Gets (as xml) array of all "acceptableEquipmentType" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType[] xgetAcceptableEquipmentTypeArray();
        
        /**
         * Gets (as xml) ith "acceptableEquipmentType" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType xgetAcceptableEquipmentTypeArray(int i);
        
        /**
         * Returns number of "acceptableEquipmentType" element
         */
        int sizeOfAcceptableEquipmentTypeArray();
        
        /**
         * Sets array of all "acceptableEquipmentType" element
         */
        void setAcceptableEquipmentTypeArray(java.lang.String[] acceptableEquipmentTypeArray);
        
        /**
         * Sets ith "acceptableEquipmentType" element
         */
        void setAcceptableEquipmentTypeArray(int i, java.lang.String acceptableEquipmentType);
        
        /**
         * Sets (as xml) array of all "acceptableEquipmentType" element
         */
        void xsetAcceptableEquipmentTypeArray(org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType[] acceptableEquipmentTypeArray);
        
        /**
         * Sets (as xml) ith "acceptableEquipmentType" element
         */
        void xsetAcceptableEquipmentTypeArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType acceptableEquipmentType);
        
        /**
         * Inserts the value as the ith "acceptableEquipmentType" element
         */
        void insertAcceptableEquipmentType(int i, java.lang.String acceptableEquipmentType);
        
        /**
         * Appends the value as the last "acceptableEquipmentType" element
         */
        void addAcceptableEquipmentType(java.lang.String acceptableEquipmentType);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "acceptableEquipmentType" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType insertNewAcceptableEquipmentType(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "acceptableEquipmentType" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType addNewAcceptableEquipmentType();
        
        /**
         * Removes the ith "acceptableEquipmentType" element
         */
        void removeAcceptableEquipmentType(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
