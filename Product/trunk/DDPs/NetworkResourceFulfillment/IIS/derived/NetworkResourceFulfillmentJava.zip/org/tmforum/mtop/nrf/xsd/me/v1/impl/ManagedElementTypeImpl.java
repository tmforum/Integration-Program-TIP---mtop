/*
 * XML Type:  ManagedElementType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/me/v1
 * Java type: org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.me.v1.impl;
/**
 * An XML ManagedElementType(@http://www.tmforum.org/mtop/nrf/xsd/me/v1).
 *
 * This is a complex type.
 */
public class ManagedElementTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType
{
    
    public ManagedElementTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LOCATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "location");
    private static final javax.xml.namespace.QName MANUFACTURER$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "manufacturer");
    private static final javax.xml.namespace.QName MANUFACTUREDATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "manufactureDate");
    private static final javax.xml.namespace.QName PRODUCTNAME$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "productName");
    private static final javax.xml.namespace.QName SOFTWAREVERSION$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "softwareVersion");
    private static final javax.xml.namespace.QName ISINSYNCSTATE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "isInSyncState");
    private static final javax.xml.namespace.QName SUPPORTEDCONNECTIONLAYERRATELIST$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "supportedConnectionLayerRateList");
    private static final javax.xml.namespace.QName COMMUNICATIONSTATE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "communicationState");
    private static final javax.xml.namespace.QName ASAPREF$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "asapRef");
    
    
    /**
     * Gets the "location" element
     */
    public java.lang.String getLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOCATION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "location" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.LocationType xgetLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(LOCATION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "location" element
     */
    public boolean isNilLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(LOCATION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "location" element
     */
    public boolean isSetLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LOCATION$0) != 0;
        }
    }
    
    /**
     * Sets the "location" element
     */
    public void setLocation(java.lang.String location)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOCATION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LOCATION$0);
            }
            target.setStringValue(location);
        }
    }
    
    /**
     * Sets (as xml) the "location" element
     */
    public void xsetLocation(org.tmforum.mtop.fmw.xsd.gen.v1.LocationType location)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(LOCATION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().add_element_user(LOCATION$0);
            }
            target.set(location);
        }
    }
    
    /**
     * Nils the "location" element
     */
    public void setNilLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(LOCATION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().add_element_user(LOCATION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "location" element
     */
    public void unsetLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LOCATION$0, 0);
        }
    }
    
    /**
     * Gets the "manufacturer" element
     */
    public java.lang.String getManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURER$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "manufacturer" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType xgetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "manufacturer" element
     */
    public boolean isNilManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "manufacturer" element
     */
    public boolean isSetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANUFACTURER$2) != 0;
        }
    }
    
    /**
     * Sets the "manufacturer" element
     */
    public void setManufacturer(java.lang.String manufacturer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MANUFACTURER$2);
            }
            target.setStringValue(manufacturer);
        }
    }
    
    /**
     * Sets (as xml) the "manufacturer" element
     */
    public void xsetManufacturer(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType manufacturer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().add_element_user(MANUFACTURER$2);
            }
            target.set(manufacturer);
        }
    }
    
    /**
     * Nils the "manufacturer" element
     */
    public void setNilManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().add_element_user(MANUFACTURER$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "manufacturer" element
     */
    public void unsetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANUFACTURER$2, 0);
        }
    }
    
    /**
     * Gets the "manufactureDate" element
     */
    public java.util.Calendar getManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTUREDATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "manufactureDate" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType xgetManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().find_element_user(MANUFACTUREDATE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "manufactureDate" element
     */
    public boolean isNilManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().find_element_user(MANUFACTUREDATE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "manufactureDate" element
     */
    public boolean isSetManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANUFACTUREDATE$4) != 0;
        }
    }
    
    /**
     * Sets the "manufactureDate" element
     */
    public void setManufactureDate(java.util.Calendar manufactureDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTUREDATE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MANUFACTUREDATE$4);
            }
            target.setCalendarValue(manufactureDate);
        }
    }
    
    /**
     * Sets (as xml) the "manufactureDate" element
     */
    public void xsetManufactureDate(org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType manufactureDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().find_element_user(MANUFACTUREDATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().add_element_user(MANUFACTUREDATE$4);
            }
            target.set(manufactureDate);
        }
    }
    
    /**
     * Nils the "manufactureDate" element
     */
    public void setNilManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().find_element_user(MANUFACTUREDATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().add_element_user(MANUFACTUREDATE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "manufactureDate" element
     */
    public void unsetManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANUFACTUREDATE$4, 0);
        }
    }
    
    /**
     * Gets the "productName" element
     */
    public java.lang.String getProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUCTNAME$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "productName" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType xgetProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().find_element_user(PRODUCTNAME$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "productName" element
     */
    public boolean isNilProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().find_element_user(PRODUCTNAME$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "productName" element
     */
    public boolean isSetProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUCTNAME$6) != 0;
        }
    }
    
    /**
     * Sets the "productName" element
     */
    public void setProductName(java.lang.String productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUCTNAME$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRODUCTNAME$6);
            }
            target.setStringValue(productName);
        }
    }
    
    /**
     * Sets (as xml) the "productName" element
     */
    public void xsetProductName(org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().find_element_user(PRODUCTNAME$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().add_element_user(PRODUCTNAME$6);
            }
            target.set(productName);
        }
    }
    
    /**
     * Nils the "productName" element
     */
    public void setNilProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().find_element_user(PRODUCTNAME$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().add_element_user(PRODUCTNAME$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "productName" element
     */
    public void unsetProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUCTNAME$6, 0);
        }
    }
    
    /**
     * Gets the "softwareVersion" element
     */
    public java.lang.String getSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOFTWAREVERSION$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "softwareVersion" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.VersionType xgetSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.VersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.VersionType)get_store().find_element_user(SOFTWAREVERSION$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "softwareVersion" element
     */
    public boolean isNilSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.VersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.VersionType)get_store().find_element_user(SOFTWAREVERSION$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "softwareVersion" element
     */
    public boolean isSetSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SOFTWAREVERSION$8) != 0;
        }
    }
    
    /**
     * Sets the "softwareVersion" element
     */
    public void setSoftwareVersion(java.lang.String softwareVersion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOFTWAREVERSION$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SOFTWAREVERSION$8);
            }
            target.setStringValue(softwareVersion);
        }
    }
    
    /**
     * Sets (as xml) the "softwareVersion" element
     */
    public void xsetSoftwareVersion(org.tmforum.mtop.nrf.xsd.me.v1.VersionType softwareVersion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.VersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.VersionType)get_store().find_element_user(SOFTWAREVERSION$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.me.v1.VersionType)get_store().add_element_user(SOFTWAREVERSION$8);
            }
            target.set(softwareVersion);
        }
    }
    
    /**
     * Nils the "softwareVersion" element
     */
    public void setNilSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.VersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.VersionType)get_store().find_element_user(SOFTWAREVERSION$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.me.v1.VersionType)get_store().add_element_user(SOFTWAREVERSION$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "softwareVersion" element
     */
    public void unsetSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SOFTWAREVERSION$8, 0);
        }
    }
    
    /**
     * Gets the "isInSyncState" element
     */
    public boolean getIsInSyncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISINSYNCSTATE$10, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isInSyncState" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsInSyncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISINSYNCSTATE$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isInSyncState" element
     */
    public boolean isNilIsInSyncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISINSYNCSTATE$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isInSyncState" element
     */
    public boolean isSetIsInSyncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISINSYNCSTATE$10) != 0;
        }
    }
    
    /**
     * Sets the "isInSyncState" element
     */
    public void setIsInSyncState(boolean isInSyncState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISINSYNCSTATE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISINSYNCSTATE$10);
            }
            target.setBooleanValue(isInSyncState);
        }
    }
    
    /**
     * Sets (as xml) the "isInSyncState" element
     */
    public void xsetIsInSyncState(org.apache.xmlbeans.XmlBoolean isInSyncState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISINSYNCSTATE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISINSYNCSTATE$10);
            }
            target.set(isInSyncState);
        }
    }
    
    /**
     * Nils the "isInSyncState" element
     */
    public void setNilIsInSyncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISINSYNCSTATE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISINSYNCSTATE$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isInSyncState" element
     */
    public void unsetIsInSyncState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISINSYNCSTATE$10, 0);
        }
    }
    
    /**
     * Gets the "supportedConnectionLayerRateList" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getSupportedConnectionLayerRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(SUPPORTEDCONNECTIONLAYERRATELIST$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "supportedConnectionLayerRateList" element
     */
    public boolean isNilSupportedConnectionLayerRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(SUPPORTEDCONNECTIONLAYERRATELIST$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "supportedConnectionLayerRateList" element
     */
    public boolean isSetSupportedConnectionLayerRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTEDCONNECTIONLAYERRATELIST$12) != 0;
        }
    }
    
    /**
     * Sets the "supportedConnectionLayerRateList" element
     */
    public void setSupportedConnectionLayerRateList(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType supportedConnectionLayerRateList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(SUPPORTEDCONNECTIONLAYERRATELIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(SUPPORTEDCONNECTIONLAYERRATELIST$12);
            }
            target.set(supportedConnectionLayerRateList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportedConnectionLayerRateList" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewSupportedConnectionLayerRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(SUPPORTEDCONNECTIONLAYERRATELIST$12);
            return target;
        }
    }
    
    /**
     * Nils the "supportedConnectionLayerRateList" element
     */
    public void setNilSupportedConnectionLayerRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(SUPPORTEDCONNECTIONLAYERRATELIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(SUPPORTEDCONNECTIONLAYERRATELIST$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "supportedConnectionLayerRateList" element
     */
    public void unsetSupportedConnectionLayerRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTEDCONNECTIONLAYERRATELIST$12, 0);
        }
    }
    
    /**
     * Gets the "communicationState" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType.Enum getCommunicationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMMUNICATIONSTATE$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "communicationState" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType xgetCommunicationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType)get_store().find_element_user(COMMUNICATIONSTATE$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "communicationState" element
     */
    public boolean isNilCommunicationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType)get_store().find_element_user(COMMUNICATIONSTATE$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "communicationState" element
     */
    public boolean isSetCommunicationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(COMMUNICATIONSTATE$14) != 0;
        }
    }
    
    /**
     * Sets the "communicationState" element
     */
    public void setCommunicationState(org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType.Enum communicationState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMMUNICATIONSTATE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COMMUNICATIONSTATE$14);
            }
            target.setEnumValue(communicationState);
        }
    }
    
    /**
     * Sets (as xml) the "communicationState" element
     */
    public void xsetCommunicationState(org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType communicationState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType)get_store().find_element_user(COMMUNICATIONSTATE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType)get_store().add_element_user(COMMUNICATIONSTATE$14);
            }
            target.set(communicationState);
        }
    }
    
    /**
     * Nils the "communicationState" element
     */
    public void setNilCommunicationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType)get_store().find_element_user(COMMUNICATIONSTATE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType)get_store().add_element_user(COMMUNICATIONSTATE$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "communicationState" element
     */
    public void unsetCommunicationState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(COMMUNICATIONSTATE$14, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$16) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$16);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$16);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$16, 0);
        }
    }
}
