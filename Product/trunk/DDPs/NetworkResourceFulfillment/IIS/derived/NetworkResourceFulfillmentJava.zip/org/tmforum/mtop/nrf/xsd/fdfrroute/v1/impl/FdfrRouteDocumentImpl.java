/*
 * An XML document type.
 * Localname: fdfrRoute
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/fdfrroute/v1
 * Java type: org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.fdfrroute.v1.impl;
/**
 * A document containing one fdfrRoute(@http://www.tmforum.org/mtop/nrf/xsd/fdfrroute/v1) element.
 *
 * This is a complex type.
 */
public class FdfrRouteDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteDocument
{
    
    public FdfrRouteDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FDFRROUTE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/fdfrroute/v1", "fdfrRoute");
    
    
    /**
     * Gets the "fdfrRoute" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType getFdfrRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().find_element_user(FDFRROUTE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "fdfrRoute" element
     */
    public void setFdfrRoute(org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType fdfrRoute)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().find_element_user(FDFRROUTE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().add_element_user(FDFRROUTE$0);
            }
            target.set(fdfrRoute);
        }
    }
    
    /**
     * Appends and returns a new empty "fdfrRoute" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType addNewFdfrRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().add_element_user(FDFRROUTE$0);
            return target;
        }
    }
}
