/*
 * XML Type:  MatrixFlowDomainInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML MatrixFlowDomainInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class MatrixFlowDomainInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType
{
    
    public MatrixFlowDomainInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MFDNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mfdNm");
    private static final javax.xml.namespace.QName MFDATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mfdAttrs");
    private static final javax.xml.namespace.QName MFDFRINVLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mfdfrInvList");
    private static final javax.xml.namespace.QName PTPREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ptpRefList");
    private static final javax.xml.namespace.QName FTPREFLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ftpRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "mfdNm" element
     */
    public java.lang.String getMfdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MFDNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "mfdNm" element
     */
    public org.apache.xmlbeans.XmlString xgetMfdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MFDNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "mfdNm" element
     */
    public boolean isSetMfdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFDNM$0) != 0;
        }
    }
    
    /**
     * Sets the "mfdNm" element
     */
    public void setMfdNm(java.lang.String mfdNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MFDNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MFDNM$0);
            }
            target.setStringValue(mfdNm);
        }
    }
    
    /**
     * Sets (as xml) the "mfdNm" element
     */
    public void xsetMfdNm(org.apache.xmlbeans.XmlString mfdNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MFDNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MFDNM$0);
            }
            target.set(mfdNm);
        }
    }
    
    /**
     * Unsets the "mfdNm" element
     */
    public void unsetMfdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFDNM$0, 0);
        }
    }
    
    /**
     * Gets the "mfdAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType getMfdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFDATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mfdAttrs" element
     */
    public boolean isSetMfdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFDATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "mfdAttrs" element
     */
    public void setMfdAttrs(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType mfdAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFDATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFDATTRS$2);
            }
            target.set(mfdAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "mfdAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType addNewMfdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFDATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "mfdAttrs" element
     */
    public void unsetMfdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFDATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "mfdfrInvList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList getMfdfrInvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList)get_store().find_element_user(MFDFRINVLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mfdfrInvList" element
     */
    public boolean isSetMfdfrInvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFDFRINVLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "mfdfrInvList" element
     */
    public void setMfdfrInvList(org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList mfdfrInvList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList)get_store().find_element_user(MFDFRINVLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList)get_store().add_element_user(MFDFRINVLIST$4);
            }
            target.set(mfdfrInvList);
        }
    }
    
    /**
     * Appends and returns a new empty "mfdfrInvList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList addNewMfdfrInvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList)get_store().add_element_user(MFDFRINVLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "mfdfrInvList" element
     */
    public void unsetMfdfrInvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFDFRINVLIST$4, 0);
        }
    }
    
    /**
     * Gets the "ptpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PTPREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ptpRefList" element
     */
    public boolean isSetPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PTPREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "ptpRefList" element
     */
    public void setPtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ptpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PTPREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PTPREFLIST$6);
            }
            target.set(ptpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "ptpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PTPREFLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "ptpRefList" element
     */
    public void unsetPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PTPREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "ftpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(FTPREFLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ftpRefList" element
     */
    public boolean isSetFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FTPREFLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "ftpRefList" element
     */
    public void setFtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ftpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(FTPREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(FTPREFLIST$8);
            }
            target.set(ftpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "ftpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(FTPREFLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "ftpRefList" element
     */
    public void unsetFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FTPREFLIST$8, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$10) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$10);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$10);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$10, 0);
        }
    }
    /**
     * An XML mfdfrInvList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class MfdfrInvListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList
    {
        
        public MfdfrInvListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFDFRINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mfdfrInv");
        
        
        /**
         * Gets a List of "mfdfrInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType> getMfdfrInvList()
        {
            final class MfdfrInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType get(int i)
                    { return MfdfrInvListImpl.this.getMfdfrInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType old = MfdfrInvListImpl.this.getMfdfrInvArray(i);
                    MfdfrInvListImpl.this.setMfdfrInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType o)
                    { MfdfrInvListImpl.this.insertNewMfdfrInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType old = MfdfrInvListImpl.this.getMfdfrInvArray(i);
                    MfdfrInvListImpl.this.removeMfdfrInv(i);
                    return old;
                }
                
                public int size()
                    { return MfdfrInvListImpl.this.sizeOfMfdfrInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MfdfrInvList();
            }
        }
        
        /**
         * Gets array of all "mfdfrInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType[] getMfdfrInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MFDFRINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "mfdfrInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType getMfdfrInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType)get_store().find_element_user(MFDFRINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "mfdfrInv" element
         */
        public int sizeOfMfdfrInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFDFRINV$0);
            }
        }
        
        /**
         * Sets array of all "mfdfrInv" element
         */
        public void setMfdfrInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType[] mfdfrInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(mfdfrInvArray, MFDFRINV$0);
            }
        }
        
        /**
         * Sets ith "mfdfrInv" element
         */
        public void setMfdfrInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType mfdfrInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType)get_store().find_element_user(MFDFRINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(mfdfrInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "mfdfrInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType insertNewMfdfrInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType)get_store().insert_element_user(MFDFRINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "mfdfrInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType addNewMfdfrInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType)get_store().add_element_user(MFDFRINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "mfdfrInv" element
         */
        public void removeMfdfrInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFDFRINV$0, i);
            }
        }
    }
}
