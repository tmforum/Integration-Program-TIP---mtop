/*
 * XML Type:  MatrixFlowDomainType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mfd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mfd.v1.impl;
/**
 * An XML MatrixFlowDomainType(@http://www.tmforum.org/mtop/nrf/xsd/mfd/v1).
 *
 * This is a complex type.
 */
public class MatrixFlowDomainTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType
{
    
    public MatrixFlowDomainTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TRANSMISSIONPARAMETERLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfd/v1", "transmissionParameterList");
    private static final javax.xml.namespace.QName ISFLEXIBLE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfd/v1", "isFlexible");
    
    
    /**
     * Gets the "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    public boolean isNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "transmissionParameterList" element
     */
    public boolean isSetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSMISSIONPARAMETERLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "transmissionParameterList" element
     */
    public void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            }
            target.set(transmissionParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            return target;
        }
    }
    
    /**
     * Nils the "transmissionParameterList" element
     */
    public void setNilTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().find_element_user(TRANSMISSIONPARAMETERLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType)get_store().add_element_user(TRANSMISSIONPARAMETERLIST$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    public void unsetTransmissionParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSMISSIONPARAMETERLIST$0, 0);
        }
    }
    
    /**
     * Gets the "isFlexible" element
     */
    public boolean getIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFLEXIBLE$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isFlexible" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "isFlexible" element
     */
    public boolean isSetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISFLEXIBLE$2) != 0;
        }
    }
    
    /**
     * Sets the "isFlexible" element
     */
    public void setIsFlexible(boolean isFlexible)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISFLEXIBLE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISFLEXIBLE$2);
            }
            target.setBooleanValue(isFlexible);
        }
    }
    
    /**
     * Sets (as xml) the "isFlexible" element
     */
    public void xsetIsFlexible(org.apache.xmlbeans.XmlBoolean isFlexible)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISFLEXIBLE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISFLEXIBLE$2);
            }
            target.set(isFlexible);
        }
    }
    
    /**
     * Unsets the "isFlexible" element
     */
    public void unsetIsFlexible()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISFLEXIBLE$2, 0);
        }
    }
}
