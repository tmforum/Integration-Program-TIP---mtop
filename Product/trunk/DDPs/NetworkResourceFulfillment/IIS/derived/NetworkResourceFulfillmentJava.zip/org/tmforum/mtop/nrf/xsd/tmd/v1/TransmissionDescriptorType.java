/*
 * XML Type:  TransmissionDescriptorType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tmd/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tmd.v1;


/**
 * An XML TransmissionDescriptorType(@http://www.tmforum.org/mtop/nrf/xsd/tmd/v1).
 *
 * This is a complex type.
 */
public interface TransmissionDescriptorType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TransmissionDescriptorType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("transmissiondescriptortype4429type");
    
    /**
     * Gets the "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType getTransmissionParameterList();
    
    /**
     * Tests for nil "transmissionParameterList" element
     */
    boolean isNilTransmissionParameterList();
    
    /**
     * True if has "transmissionParameterList" element
     */
    boolean isSetTransmissionParameterList();
    
    /**
     * Sets the "transmissionParameterList" element
     */
    void setTransmissionParameterList(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType transmissionParameterList);
    
    /**
     * Appends and returns a new empty "transmissionParameterList" element
     */
    org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType addNewTransmissionParameterList();
    
    /**
     * Nils the "transmissionParameterList" element
     */
    void setNilTransmissionParameterList();
    
    /**
     * Unsets the "transmissionParameterList" element
     */
    void unsetTransmissionParameterList();
    
    /**
     * Gets the "additionalObjectInfo" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType getAdditionalObjectInfo();
    
    /**
     * Tests for nil "additionalObjectInfo" element
     */
    boolean isNilAdditionalObjectInfo();
    
    /**
     * True if has "additionalObjectInfo" element
     */
    boolean isSetAdditionalObjectInfo();
    
    /**
     * Sets the "additionalObjectInfo" element
     */
    void setAdditionalObjectInfo(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType additionalObjectInfo);
    
    /**
     * Appends and returns a new empty "additionalObjectInfo" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType addNewAdditionalObjectInfo();
    
    /**
     * Nils the "additionalObjectInfo" element
     */
    void setNilAdditionalObjectInfo();
    
    /**
     * Unsets the "additionalObjectInfo" element
     */
    void unsetAdditionalObjectInfo();
    
    /**
     * Gets the "containingTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getContainingTmdRef();
    
    /**
     * Tests for nil "containingTmdRef" element
     */
    boolean isNilContainingTmdRef();
    
    /**
     * True if has "containingTmdRef" element
     */
    boolean isSetContainingTmdRef();
    
    /**
     * Sets the "containingTmdRef" element
     */
    void setContainingTmdRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType containingTmdRef);
    
    /**
     * Appends and returns a new empty "containingTmdRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewContainingTmdRef();
    
    /**
     * Nils the "containingTmdRef" element
     */
    void setNilContainingTmdRef();
    
    /**
     * Unsets the "containingTmdRef" element
     */
    void unsetContainingTmdRef();
    
    /**
     * Gets the "externalRepresentationReference" element
     */
    java.lang.String getExternalRepresentationReference();
    
    /**
     * Gets (as xml) the "externalRepresentationReference" element
     */
    org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType xgetExternalRepresentationReference();
    
    /**
     * Tests for nil "externalRepresentationReference" element
     */
    boolean isNilExternalRepresentationReference();
    
    /**
     * True if has "externalRepresentationReference" element
     */
    boolean isSetExternalRepresentationReference();
    
    /**
     * Sets the "externalRepresentationReference" element
     */
    void setExternalRepresentationReference(java.lang.String externalRepresentationReference);
    
    /**
     * Sets (as xml) the "externalRepresentationReference" element
     */
    void xsetExternalRepresentationReference(org.tmforum.mtop.nrf.xsd.tmd.v1.ExternalRepresentationReferenceType externalRepresentationReference);
    
    /**
     * Nils the "externalRepresentationReference" element
     */
    void setNilExternalRepresentationReference();
    
    /**
     * Unsets the "externalRepresentationReference" element
     */
    void unsetExternalRepresentationReference();
    
    /**
     * Gets the "conformanceDefinition" element
     */
    java.lang.String getConformanceDefinition();
    
    /**
     * Gets (as xml) the "conformanceDefinition" element
     */
    org.apache.xmlbeans.XmlString xgetConformanceDefinition();
    
    /**
     * Tests for nil "conformanceDefinition" element
     */
    boolean isNilConformanceDefinition();
    
    /**
     * True if has "conformanceDefinition" element
     */
    boolean isSetConformanceDefinition();
    
    /**
     * Sets the "conformanceDefinition" element
     */
    void setConformanceDefinition(java.lang.String conformanceDefinition);
    
    /**
     * Sets (as xml) the "conformanceDefinition" element
     */
    void xsetConformanceDefinition(org.apache.xmlbeans.XmlString conformanceDefinition);
    
    /**
     * Nils the "conformanceDefinition" element
     */
    void setNilConformanceDefinition();
    
    /**
     * Unsets the "conformanceDefinition" element
     */
    void unsetConformanceDefinition();
    
    /**
     * Gets the "serviceCategory" element
     */
    java.lang.String getServiceCategory();
    
    /**
     * Gets (as xml) the "serviceCategory" element
     */
    org.apache.xmlbeans.XmlString xgetServiceCategory();
    
    /**
     * Tests for nil "serviceCategory" element
     */
    boolean isNilServiceCategory();
    
    /**
     * True if has "serviceCategory" element
     */
    boolean isSetServiceCategory();
    
    /**
     * Sets the "serviceCategory" element
     */
    void setServiceCategory(java.lang.String serviceCategory);
    
    /**
     * Sets (as xml) the "serviceCategory" element
     */
    void xsetServiceCategory(org.apache.xmlbeans.XmlString serviceCategory);
    
    /**
     * Nils the "serviceCategory" element
     */
    void setNilServiceCategory();
    
    /**
     * Unsets the "serviceCategory" element
     */
    void unsetServiceCategory();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
