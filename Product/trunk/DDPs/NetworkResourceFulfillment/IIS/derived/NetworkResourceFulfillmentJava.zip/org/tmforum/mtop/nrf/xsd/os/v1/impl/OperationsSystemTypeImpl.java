/*
 * XML Type:  OperationsSystemType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/os/v1
 * Java type: org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.os.v1.impl;
/**
 * An XML OperationsSystemType(@http://www.tmforum.org/mtop/nrf/xsd/os/v1).
 *
 * This is a complex type.
 */
public class OperationsSystemTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType
{
    
    public OperationsSystemTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SOFTWAREVERSION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/os/v1", "softwareVersion");
    private static final javax.xml.namespace.QName PRODUCTNAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/os/v1", "productName");
    private static final javax.xml.namespace.QName MANUFACTURER$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/os/v1", "manufacturer");
    private static final javax.xml.namespace.QName RESOURCEFULFILLMENTSTATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/os/v1", "resourceFulfillmentState");
    private static final javax.xml.namespace.QName ISSUBORDINATEOS$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/os/v1", "isSubordinateOs");
    private static final javax.xml.namespace.QName ASAPREF$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/os/v1", "asapRef");
    
    
    /**
     * Gets the "softwareVersion" element
     */
    public java.lang.String getSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOFTWAREVERSION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "softwareVersion" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType xgetSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType)get_store().find_element_user(SOFTWAREVERSION$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "softwareVersion" element
     */
    public boolean isNilSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType)get_store().find_element_user(SOFTWAREVERSION$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "softwareVersion" element
     */
    public boolean isSetSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SOFTWAREVERSION$0) != 0;
        }
    }
    
    /**
     * Sets the "softwareVersion" element
     */
    public void setSoftwareVersion(java.lang.String softwareVersion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOFTWAREVERSION$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SOFTWAREVERSION$0);
            }
            target.setStringValue(softwareVersion);
        }
    }
    
    /**
     * Sets (as xml) the "softwareVersion" element
     */
    public void xsetSoftwareVersion(org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType softwareVersion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType)get_store().find_element_user(SOFTWAREVERSION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType)get_store().add_element_user(SOFTWAREVERSION$0);
            }
            target.set(softwareVersion);
        }
    }
    
    /**
     * Nils the "softwareVersion" element
     */
    public void setNilSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType)get_store().find_element_user(SOFTWAREVERSION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType)get_store().add_element_user(SOFTWAREVERSION$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "softwareVersion" element
     */
    public void unsetSoftwareVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SOFTWAREVERSION$0, 0);
        }
    }
    
    /**
     * Gets the "productName" element
     */
    public java.lang.String getProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "productName" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType xgetProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().find_element_user(PRODUCTNAME$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "productName" element
     */
    public boolean isNilProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "productName" element
     */
    public boolean isSetProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUCTNAME$2) != 0;
        }
    }
    
    /**
     * Sets the "productName" element
     */
    public void setProductName(java.lang.String productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRODUCTNAME$2);
            }
            target.setStringValue(productName);
        }
    }
    
    /**
     * Sets (as xml) the "productName" element
     */
    public void xsetProductName(org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().add_element_user(PRODUCTNAME$2);
            }
            target.set(productName);
        }
    }
    
    /**
     * Nils the "productName" element
     */
    public void setNilProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType)get_store().add_element_user(PRODUCTNAME$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "productName" element
     */
    public void unsetProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUCTNAME$2, 0);
        }
    }
    
    /**
     * Gets the "manufacturer" element
     */
    public java.lang.String getManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURER$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "manufacturer" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType xgetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "manufacturer" element
     */
    public boolean isNilManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "manufacturer" element
     */
    public boolean isSetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANUFACTURER$4) != 0;
        }
    }
    
    /**
     * Sets the "manufacturer" element
     */
    public void setManufacturer(java.lang.String manufacturer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MANUFACTURER$4);
            }
            target.setStringValue(manufacturer);
        }
    }
    
    /**
     * Sets (as xml) the "manufacturer" element
     */
    public void xsetManufacturer(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType manufacturer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().add_element_user(MANUFACTURER$4);
            }
            target.set(manufacturer);
        }
    }
    
    /**
     * Nils the "manufacturer" element
     */
    public void setNilManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().add_element_user(MANUFACTURER$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "manufacturer" element
     */
    public void unsetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANUFACTURER$4, 0);
        }
    }
    
    /**
     * Gets the "resourceFulfillmentState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum getResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "resourceFulfillmentState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType xgetResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "resourceFulfillmentState" element
     */
    public boolean isNilResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "resourceFulfillmentState" element
     */
    public boolean isSetResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RESOURCEFULFILLMENTSTATE$6) != 0;
        }
    }
    
    /**
     * Sets the "resourceFulfillmentState" element
     */
    public void setResourceFulfillmentState(org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum resourceFulfillmentState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RESOURCEFULFILLMENTSTATE$6);
            }
            target.setEnumValue(resourceFulfillmentState);
        }
    }
    
    /**
     * Sets (as xml) the "resourceFulfillmentState" element
     */
    public void xsetResourceFulfillmentState(org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType resourceFulfillmentState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().add_element_user(RESOURCEFULFILLMENTSTATE$6);
            }
            target.set(resourceFulfillmentState);
        }
    }
    
    /**
     * Nils the "resourceFulfillmentState" element
     */
    public void setNilResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().find_element_user(RESOURCEFULFILLMENTSTATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType)get_store().add_element_user(RESOURCEFULFILLMENTSTATE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "resourceFulfillmentState" element
     */
    public void unsetResourceFulfillmentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RESOURCEFULFILLMENTSTATE$6, 0);
        }
    }
    
    /**
     * Gets the "isSubordinateOs" element
     */
    public boolean getIsSubordinateOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSUBORDINATEOS$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isSubordinateOs" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsSubordinateOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSUBORDINATEOS$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isSubordinateOs" element
     */
    public boolean isNilIsSubordinateOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSUBORDINATEOS$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isSubordinateOs" element
     */
    public boolean isSetIsSubordinateOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISSUBORDINATEOS$8) != 0;
        }
    }
    
    /**
     * Sets the "isSubordinateOs" element
     */
    public void setIsSubordinateOs(boolean isSubordinateOs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSUBORDINATEOS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISSUBORDINATEOS$8);
            }
            target.setBooleanValue(isSubordinateOs);
        }
    }
    
    /**
     * Sets (as xml) the "isSubordinateOs" element
     */
    public void xsetIsSubordinateOs(org.apache.xmlbeans.XmlBoolean isSubordinateOs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSUBORDINATEOS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISSUBORDINATEOS$8);
            }
            target.set(isSubordinateOs);
        }
    }
    
    /**
     * Nils the "isSubordinateOs" element
     */
    public void setNilIsSubordinateOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSUBORDINATEOS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISSUBORDINATEOS$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isSubordinateOs" element
     */
    public void unsetIsSubordinateOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISSUBORDINATEOS$8, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$10) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$10);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$10);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$10, 0);
        }
    }
}
