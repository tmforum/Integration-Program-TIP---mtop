/*
 * XML Type:  PerceivedSeverityListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1;


/**
 * An XML PerceivedSeverityListType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is a complex type.
 */
public interface PerceivedSeverityListType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PerceivedSeverityListType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("perceivedseveritylisttypef1f7type");
    
    /**
     * Gets a List of "perceivedSeverity" elements
     */
    java.util.List<org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum> getPerceivedSeverityList();
    
    /**
     * Gets array of all "perceivedSeverity" elements
     * @deprecated
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum[] getPerceivedSeverityArray();
    
    /**
     * Gets ith "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum getPerceivedSeverityArray(int i);
    
    /**
     * Gets (as xml) a List of "perceivedSeverity" elements
     */
    java.util.List<org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType> xgetPerceivedSeverityList();
    
    /**
     * Gets (as xml) array of all "perceivedSeverity" elements
     * @deprecated
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType[] xgetPerceivedSeverityArray();
    
    /**
     * Gets (as xml) ith "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType xgetPerceivedSeverityArray(int i);
    
    /**
     * Returns number of "perceivedSeverity" element
     */
    int sizeOfPerceivedSeverityArray();
    
    /**
     * Sets array of all "perceivedSeverity" element
     */
    void setPerceivedSeverityArray(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum[] perceivedSeverityArray);
    
    /**
     * Sets ith "perceivedSeverity" element
     */
    void setPerceivedSeverityArray(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity);
    
    /**
     * Sets (as xml) array of all "perceivedSeverity" element
     */
    void xsetPerceivedSeverityArray(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType[] perceivedSeverityArray);
    
    /**
     * Sets (as xml) ith "perceivedSeverity" element
     */
    void xsetPerceivedSeverityArray(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType perceivedSeverity);
    
    /**
     * Inserts the value as the ith "perceivedSeverity" element
     */
    void insertPerceivedSeverity(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity);
    
    /**
     * Appends the value as the last "perceivedSeverity" element
     */
    void addPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType insertNewPerceivedSeverity(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType addNewPerceivedSeverity();
    
    /**
     * Removes the ith "perceivedSeverity" element
     */
    void removePerceivedSeverity(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType newInstance() {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
