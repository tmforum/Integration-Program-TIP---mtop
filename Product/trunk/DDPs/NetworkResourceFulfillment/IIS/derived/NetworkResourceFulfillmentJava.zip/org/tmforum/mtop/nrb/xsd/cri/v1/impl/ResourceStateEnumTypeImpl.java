/*
 * XML Type:  ResourceStateEnumType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/cri/v1
 * Java type: org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.cri.v1.impl;
/**
 * An XML ResourceStateEnumType(@http://www.tmforum.org/mtop/nrb/xsd/cri/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType.
 */
public class ResourceStateEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType
{
    
    public ResourceStateEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ResourceStateEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
