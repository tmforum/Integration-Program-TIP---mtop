/*
 * XML Type:  FloatingTerminationPointInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML FloatingTerminationPointInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class FloatingTerminationPointInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType
{
    
    public FloatingTerminationPointInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FTPNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ftpNm");
    private static final javax.xml.namespace.QName FTPATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ftpAttrs");
    private static final javax.xml.namespace.QName CTPLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ctpList");
    private static final javax.xml.namespace.QName SUPPORTINGEQUIPMENTREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "supportingEquipmentRefList");
    private static final javax.xml.namespace.QName SUPPORTEDFIXEDSNCREFLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "supportedFixedSncRefList");
    private static final javax.xml.namespace.QName ALLSUPPORTEDSNCREFLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "allSupportedSncRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "ftpNm" element
     */
    public java.lang.String getFtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FTPNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ftpNm" element
     */
    public org.apache.xmlbeans.XmlString xgetFtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FTPNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "ftpNm" element
     */
    public boolean isSetFtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FTPNM$0) != 0;
        }
    }
    
    /**
     * Sets the "ftpNm" element
     */
    public void setFtpNm(java.lang.String ftpNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FTPNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FTPNM$0);
            }
            target.setStringValue(ftpNm);
        }
    }
    
    /**
     * Sets (as xml) the "ftpNm" element
     */
    public void xsetFtpNm(org.apache.xmlbeans.XmlString ftpNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FTPNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FTPNM$0);
            }
            target.set(ftpNm);
        }
    }
    
    /**
     * Unsets the "ftpNm" element
     */
    public void unsetFtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FTPNM$0, 0);
        }
    }
    
    /**
     * Gets the "ftpAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType getFtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().find_element_user(FTPATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ftpAttrs" element
     */
    public boolean isSetFtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FTPATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "ftpAttrs" element
     */
    public void setFtpAttrs(org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType ftpAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().find_element_user(FTPATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().add_element_user(FTPATTRS$2);
            }
            target.set(ftpAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "ftpAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType addNewFtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().add_element_user(FTPATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "ftpAttrs" element
     */
    public void unsetFtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FTPATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "ctpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList getCtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList)get_store().find_element_user(CTPLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ctpList" element
     */
    public boolean isSetCtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CTPLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "ctpList" element
     */
    public void setCtpList(org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList ctpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList)get_store().find_element_user(CTPLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList)get_store().add_element_user(CTPLIST$4);
            }
            target.set(ctpList);
        }
    }
    
    /**
     * Appends and returns a new empty "ctpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList addNewCtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList)get_store().add_element_user(CTPLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ctpList" element
     */
    public void unsetCtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CTPLIST$4, 0);
        }
    }
    
    /**
     * Gets the "supportingEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTINGEQUIPMENTREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "supportingEquipmentRefList" element
     */
    public boolean isSetSupportingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTINGEQUIPMENTREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "supportingEquipmentRefList" element
     */
    public void setSupportingEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportingEquipmentRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTINGEQUIPMENTREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTINGEQUIPMENTREFLIST$6);
            }
            target.set(supportingEquipmentRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportingEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTINGEQUIPMENTREFLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "supportingEquipmentRefList" element
     */
    public void unsetSupportingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTINGEQUIPMENTREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "supportedFixedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDFIXEDSNCREFLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "supportedFixedSncRefList" element
     */
    public boolean isSetSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTEDFIXEDSNCREFLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "supportedFixedSncRefList" element
     */
    public void setSupportedFixedSncRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportedFixedSncRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDFIXEDSNCREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDFIXEDSNCREFLIST$8);
            }
            target.set(supportedFixedSncRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportedFixedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDFIXEDSNCREFLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "supportedFixedSncRefList" element
     */
    public void unsetSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTEDFIXEDSNCREFLIST$8, 0);
        }
    }
    
    /**
     * Gets the "allSupportedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ALLSUPPORTEDSNCREFLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "allSupportedSncRefList" element
     */
    public boolean isSetAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALLSUPPORTEDSNCREFLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "allSupportedSncRefList" element
     */
    public void setAllSupportedSncRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType allSupportedSncRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ALLSUPPORTEDSNCREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ALLSUPPORTEDSNCREFLIST$10);
            }
            target.set(allSupportedSncRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "allSupportedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ALLSUPPORTEDSNCREFLIST$10);
            return target;
        }
    }
    
    /**
     * Unsets the "allSupportedSncRefList" element
     */
    public void unsetAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALLSUPPORTEDSNCREFLIST$10, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$12) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$12);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$12);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$12, 0);
        }
    }
    /**
     * An XML ctpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class CtpListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList
    {
        
        public CtpListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CTPINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ctpInv");
        
        
        /**
         * Gets a List of "ctpInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType> getCtpInvList()
        {
            final class CtpInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType get(int i)
                    { return CtpListImpl.this.getCtpInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType old = CtpListImpl.this.getCtpInvArray(i);
                    CtpListImpl.this.setCtpInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType o)
                    { CtpListImpl.this.insertNewCtpInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType old = CtpListImpl.this.getCtpInvArray(i);
                    CtpListImpl.this.removeCtpInv(i);
                    return old;
                }
                
                public int size()
                    { return CtpListImpl.this.sizeOfCtpInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new CtpInvList();
            }
        }
        
        /**
         * Gets array of all "ctpInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType[] getCtpInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CTPINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "ctpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType getCtpInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType)get_store().find_element_user(CTPINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "ctpInv" element
         */
        public int sizeOfCtpInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CTPINV$0);
            }
        }
        
        /**
         * Sets array of all "ctpInv" element
         */
        public void setCtpInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType[] ctpInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(ctpInvArray, CTPINV$0);
            }
        }
        
        /**
         * Sets ith "ctpInv" element
         */
        public void setCtpInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType ctpInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType)get_store().find_element_user(CTPINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(ctpInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ctpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType insertNewCtpInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType)get_store().insert_element_user(CTPINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ctpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType addNewCtpInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType)get_store().add_element_user(CTPINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "ctpInv" element
         */
        public void removeCtpInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CTPINV$0, i);
            }
        }
    }
}
