/*
 * XML Type:  ManagementDomainInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML ManagementDomainInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface ManagementDomainInventoryType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ManagementDomainInventoryType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("managementdomaininventorytype6b89type");
    
    /**
     * Gets the "mdNm" element
     */
    java.lang.String getMdNm();
    
    /**
     * Gets (as xml) the "mdNm" element
     */
    org.apache.xmlbeans.XmlString xgetMdNm();
    
    /**
     * True if has "mdNm" element
     */
    boolean isSetMdNm();
    
    /**
     * Sets the "mdNm" element
     */
    void setMdNm(java.lang.String mdNm);
    
    /**
     * Sets (as xml) the "mdNm" element
     */
    void xsetMdNm(org.apache.xmlbeans.XmlString mdNm);
    
    /**
     * Unsets the "mdNm" element
     */
    void unsetMdNm();
    
    /**
     * Gets the "mdAttrs" element
     */
    org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType getMdAttrs();
    
    /**
     * True if has "mdAttrs" element
     */
    boolean isSetMdAttrs();
    
    /**
     * Sets the "mdAttrs" element
     */
    void setMdAttrs(org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType mdAttrs);
    
    /**
     * Appends and returns a new empty "mdAttrs" element
     */
    org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType addNewMdAttrs();
    
    /**
     * Unsets the "mdAttrs" element
     */
    void unsetMdAttrs();
    
    /**
     * Gets the "supportingOsRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportingOsRefList();
    
    /**
     * True if has "supportingOsRefList" element
     */
    boolean isSetSupportingOsRefList();
    
    /**
     * Sets the "supportingOsRefList" element
     */
    void setSupportingOsRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportingOsRefList);
    
    /**
     * Appends and returns a new empty "supportingOsRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportingOsRefList();
    
    /**
     * Unsets the "supportingOsRefList" element
     */
    void unsetSupportingOsRefList();
    
    /**
     * Gets the "meList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList getMeList();
    
    /**
     * True if has "meList" element
     */
    boolean isSetMeList();
    
    /**
     * Sets the "meList" element
     */
    void setMeList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList meList);
    
    /**
     * Appends and returns a new empty "meList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList addNewMeList();
    
    /**
     * Unsets the "meList" element
     */
    void unsetMeList();
    
    /**
     * Gets the "mlsnList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList getMlsnList();
    
    /**
     * True if has "mlsnList" element
     */
    boolean isSetMlsnList();
    
    /**
     * Sets the "mlsnList" element
     */
    void setMlsnList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList mlsnList);
    
    /**
     * Appends and returns a new empty "mlsnList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList addNewMlsnList();
    
    /**
     * Unsets the "mlsnList" element
     */
    void unsetMlsnList();
    
    /**
     * Gets the "fdList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList getFdList();
    
    /**
     * True if has "fdList" element
     */
    boolean isSetFdList();
    
    /**
     * Sets the "fdList" element
     */
    void setFdList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList fdList);
    
    /**
     * Appends and returns a new empty "fdList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList addNewFdList();
    
    /**
     * Unsets the "fdList" element
     */
    void unsetFdList();
    
    /**
     * Gets the "tlList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList getTlList();
    
    /**
     * True if has "tlList" element
     */
    boolean isSetTlList();
    
    /**
     * Sets the "tlList" element
     */
    void setTlList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList tlList);
    
    /**
     * Appends and returns a new empty "tlList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList addNewTlList();
    
    /**
     * Unsets the "tlList" element
     */
    void unsetTlList();
    
    /**
     * Gets the "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator();
    
    /**
     * True if has "qualityIndicator" element
     */
    boolean isSetQualityIndicator();
    
    /**
     * Sets the "qualityIndicator" element
     */
    void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator);
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator();
    
    /**
     * Unsets the "qualityIndicator" element
     */
    void unsetQualityIndicator();
    
    /**
     * An XML meList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface MeList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MeList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("melist5c57elemtype");
        
        /**
         * Gets a List of "meInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType> getMeInvList();
        
        /**
         * Gets array of all "meInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType[] getMeInvArray();
        
        /**
         * Gets ith "meInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType getMeInvArray(int i);
        
        /**
         * Returns number of "meInv" element
         */
        int sizeOfMeInvArray();
        
        /**
         * Sets array of all "meInv" element
         */
        void setMeInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType[] meInvArray);
        
        /**
         * Sets ith "meInv" element
         */
        void setMeInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType meInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "meInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType insertNewMeInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "meInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType addNewMeInv();
        
        /**
         * Removes the ith "meInv" element
         */
        void removeMeInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML mlsnList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface MlsnList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MlsnList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("mlsnlistb875elemtype");
        
        /**
         * Gets a List of "mlsnInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType> getMlsnInvList();
        
        /**
         * Gets array of all "mlsnInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType[] getMlsnInvArray();
        
        /**
         * Gets ith "mlsnInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType getMlsnInvArray(int i);
        
        /**
         * Returns number of "mlsnInv" element
         */
        int sizeOfMlsnInvArray();
        
        /**
         * Sets array of all "mlsnInv" element
         */
        void setMlsnInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType[] mlsnInvArray);
        
        /**
         * Sets ith "mlsnInv" element
         */
        void setMlsnInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType mlsnInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "mlsnInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType insertNewMlsnInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "mlsnInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType addNewMlsnInv();
        
        /**
         * Removes the ith "mlsnInv" element
         */
        void removeMlsnInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML fdList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface FdList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FdList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("fdlistff71elemtype");
        
        /**
         * Gets a List of "fdInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType> getFdInvList();
        
        /**
         * Gets array of all "fdInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType[] getFdInvArray();
        
        /**
         * Gets ith "fdInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType getFdInvArray(int i);
        
        /**
         * Returns number of "fdInv" element
         */
        int sizeOfFdInvArray();
        
        /**
         * Sets array of all "fdInv" element
         */
        void setFdInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType[] fdInvArray);
        
        /**
         * Sets ith "fdInv" element
         */
        void setFdInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType fdInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "fdInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType insertNewFdInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "fdInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType addNewFdInv();
        
        /**
         * Removes the ith "fdInv" element
         */
        void removeFdInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML tlList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface TlList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TlList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("tllistef77elemtype");
        
        /**
         * Gets a List of "tlInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType> getTlInvList();
        
        /**
         * Gets array of all "tlInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType[] getTlInvArray();
        
        /**
         * Gets ith "tlInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType getTlInvArray(int i);
        
        /**
         * Returns number of "tlInv" element
         */
        int sizeOfTlInvArray();
        
        /**
         * Sets array of all "tlInv" element
         */
        void setTlInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType[] tlInvArray);
        
        /**
         * Sets ith "tlInv" element
         */
        void setTlInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType tlInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "tlInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType insertNewTlInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "tlInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType addNewTlInv();
        
        /**
         * Removes the ith "tlInv" element
         */
        void removeTlInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
