/*
 * XML Type:  TransmissionDescriptorInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML TransmissionDescriptorInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class TransmissionDescriptorInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType
{
    
    public TransmissionDescriptorInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TMDNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tmdNm");
    private static final javax.xml.namespace.QName TMDATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tmdAttrs");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "tmdNm" element
     */
    public java.lang.String getTmdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TMDNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "tmdNm" element
     */
    public org.apache.xmlbeans.XmlString xgetTmdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TMDNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "tmdNm" element
     */
    public boolean isSetTmdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TMDNM$0) != 0;
        }
    }
    
    /**
     * Sets the "tmdNm" element
     */
    public void setTmdNm(java.lang.String tmdNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TMDNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TMDNM$0);
            }
            target.setStringValue(tmdNm);
        }
    }
    
    /**
     * Sets (as xml) the "tmdNm" element
     */
    public void xsetTmdNm(org.apache.xmlbeans.XmlString tmdNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TMDNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TMDNM$0);
            }
            target.set(tmdNm);
        }
    }
    
    /**
     * Unsets the "tmdNm" element
     */
    public void unsetTmdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TMDNM$0, 0);
        }
    }
    
    /**
     * Gets the "tmdAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType getTmdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().find_element_user(TMDATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tmdAttrs" element
     */
    public boolean isSetTmdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TMDATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "tmdAttrs" element
     */
    public void setTmdAttrs(org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType tmdAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().find_element_user(TMDATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().add_element_user(TMDATTRS$2);
            }
            target.set(tmdAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "tmdAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType addNewTmdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tmd.v1.TransmissionDescriptorType)get_store().add_element_user(TMDATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "tmdAttrs" element
     */
    public void unsetTmdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TMDATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$4) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$4);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$4);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$4, 0);
        }
    }
}
