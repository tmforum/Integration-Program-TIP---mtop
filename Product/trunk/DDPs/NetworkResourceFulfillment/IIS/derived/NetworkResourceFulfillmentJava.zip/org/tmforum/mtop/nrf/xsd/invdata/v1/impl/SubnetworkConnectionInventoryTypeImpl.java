/*
 * XML Type:  SubnetworkConnectionInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML SubnetworkConnectionInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class SubnetworkConnectionInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType
{
    
    public SubnetworkConnectionInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SNCNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "sncNm");
    private static final javax.xml.namespace.QName SNCATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "sncAttrs");
    private static final javax.xml.namespace.QName ROUTE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "route");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "sncNm" element
     */
    public java.lang.String getSncNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "sncNm" element
     */
    public org.apache.xmlbeans.XmlString xgetSncNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SNCNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "sncNm" element
     */
    public boolean isSetSncNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SNCNM$0) != 0;
        }
    }
    
    /**
     * Sets the "sncNm" element
     */
    public void setSncNm(java.lang.String sncNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SNCNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SNCNM$0);
            }
            target.setStringValue(sncNm);
        }
    }
    
    /**
     * Sets (as xml) the "sncNm" element
     */
    public void xsetSncNm(org.apache.xmlbeans.XmlString sncNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SNCNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SNCNM$0);
            }
            target.set(sncNm);
        }
    }
    
    /**
     * Unsets the "sncNm" element
     */
    public void unsetSncNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SNCNM$0, 0);
        }
    }
    
    /**
     * Gets the "sncAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getSncAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNCATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "sncAttrs" element
     */
    public boolean isSetSncAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SNCATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "sncAttrs" element
     */
    public void setSncAttrs(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType sncAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNCATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNCATTRS$2);
            }
            target.set(sncAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "sncAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewSncAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNCATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "sncAttrs" element
     */
    public void unsetSncAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SNCATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType getRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "route" element
     */
    public boolean isSetRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTE$4) != 0;
        }
    }
    
    /**
     * Sets the "route" element
     */
    public void setRoute(org.tmforum.mtop.nrf.xsd.route.v1.RouteType route)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$4);
            }
            target.set(route);
        }
    }
    
    /**
     * Appends and returns a new empty "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType addNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$4);
            return target;
        }
    }
    
    /**
     * Unsets the "route" element
     */
    public void unsetRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTE$4, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$6) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$6, 0);
        }
    }
}
