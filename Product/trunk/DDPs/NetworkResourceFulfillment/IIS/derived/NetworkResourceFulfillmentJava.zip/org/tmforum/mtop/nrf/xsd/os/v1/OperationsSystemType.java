/*
 * XML Type:  OperationsSystemType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/os/v1
 * Java type: org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.os.v1;


/**
 * An XML OperationsSystemType(@http://www.tmforum.org/mtop/nrf/xsd/os/v1).
 *
 * This is a complex type.
 */
public interface OperationsSystemType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(OperationsSystemType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("operationssystemtype70a4type");
    
    /**
     * Gets the "softwareVersion" element
     */
    java.lang.String getSoftwareVersion();
    
    /**
     * Gets (as xml) the "softwareVersion" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType xgetSoftwareVersion();
    
    /**
     * Tests for nil "softwareVersion" element
     */
    boolean isNilSoftwareVersion();
    
    /**
     * True if has "softwareVersion" element
     */
    boolean isSetSoftwareVersion();
    
    /**
     * Sets the "softwareVersion" element
     */
    void setSoftwareVersion(java.lang.String softwareVersion);
    
    /**
     * Sets (as xml) the "softwareVersion" element
     */
    void xsetSoftwareVersion(org.tmforum.mtop.nrf.xsd.com.v1.SoftwareVersionType softwareVersion);
    
    /**
     * Nils the "softwareVersion" element
     */
    void setNilSoftwareVersion();
    
    /**
     * Unsets the "softwareVersion" element
     */
    void unsetSoftwareVersion();
    
    /**
     * Gets the "productName" element
     */
    java.lang.String getProductName();
    
    /**
     * Gets (as xml) the "productName" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType xgetProductName();
    
    /**
     * Tests for nil "productName" element
     */
    boolean isNilProductName();
    
    /**
     * True if has "productName" element
     */
    boolean isSetProductName();
    
    /**
     * Sets the "productName" element
     */
    void setProductName(java.lang.String productName);
    
    /**
     * Sets (as xml) the "productName" element
     */
    void xsetProductName(org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType productName);
    
    /**
     * Nils the "productName" element
     */
    void setNilProductName();
    
    /**
     * Unsets the "productName" element
     */
    void unsetProductName();
    
    /**
     * Gets the "manufacturer" element
     */
    java.lang.String getManufacturer();
    
    /**
     * Gets (as xml) the "manufacturer" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType xgetManufacturer();
    
    /**
     * Tests for nil "manufacturer" element
     */
    boolean isNilManufacturer();
    
    /**
     * True if has "manufacturer" element
     */
    boolean isSetManufacturer();
    
    /**
     * Sets the "manufacturer" element
     */
    void setManufacturer(java.lang.String manufacturer);
    
    /**
     * Sets (as xml) the "manufacturer" element
     */
    void xsetManufacturer(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType manufacturer);
    
    /**
     * Nils the "manufacturer" element
     */
    void setNilManufacturer();
    
    /**
     * Unsets the "manufacturer" element
     */
    void unsetManufacturer();
    
    /**
     * Gets the "resourceFulfillmentState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum getResourceFulfillmentState();
    
    /**
     * Gets (as xml) the "resourceFulfillmentState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType xgetResourceFulfillmentState();
    
    /**
     * Tests for nil "resourceFulfillmentState" element
     */
    boolean isNilResourceFulfillmentState();
    
    /**
     * True if has "resourceFulfillmentState" element
     */
    boolean isSetResourceFulfillmentState();
    
    /**
     * Sets the "resourceFulfillmentState" element
     */
    void setResourceFulfillmentState(org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType.Enum resourceFulfillmentState);
    
    /**
     * Sets (as xml) the "resourceFulfillmentState" element
     */
    void xsetResourceFulfillmentState(org.tmforum.mtop.nrf.xsd.com.v1.ResourceFulfillmentStateEnumType resourceFulfillmentState);
    
    /**
     * Nils the "resourceFulfillmentState" element
     */
    void setNilResourceFulfillmentState();
    
    /**
     * Unsets the "resourceFulfillmentState" element
     */
    void unsetResourceFulfillmentState();
    
    /**
     * Gets the "isSubordinateOs" element
     */
    boolean getIsSubordinateOs();
    
    /**
     * Gets (as xml) the "isSubordinateOs" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsSubordinateOs();
    
    /**
     * Tests for nil "isSubordinateOs" element
     */
    boolean isNilIsSubordinateOs();
    
    /**
     * True if has "isSubordinateOs" element
     */
    boolean isSetIsSubordinateOs();
    
    /**
     * Sets the "isSubordinateOs" element
     */
    void setIsSubordinateOs(boolean isSubordinateOs);
    
    /**
     * Sets (as xml) the "isSubordinateOs" element
     */
    void xsetIsSubordinateOs(org.apache.xmlbeans.XmlBoolean isSubordinateOs);
    
    /**
     * Nils the "isSubordinateOs" element
     */
    void setNilIsSubordinateOs();
    
    /**
     * Unsets the "isSubordinateOs" element
     */
    void unsetIsSubordinateOs();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
