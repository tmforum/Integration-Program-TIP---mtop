/*
 * XML Type:  SubnetworkConnectionType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/snc/v1
 * Java type: org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.snc.v1;


/**
 * An XML SubnetworkConnectionType(@http://www.tmforum.org/mtop/nrf/xsd/snc/v1).
 *
 * This is a complex type.
 */
public interface SubnetworkConnectionType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SubnetworkConnectionType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("subnetworkconnectiontypee253type");
    
    /**
     * Gets the "sncState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum getSncState();
    
    /**
     * Gets (as xml) the "sncState" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType xgetSncState();
    
    /**
     * Tests for nil "sncState" element
     */
    boolean isNilSncState();
    
    /**
     * True if has "sncState" element
     */
    boolean isSetSncState();
    
    /**
     * Sets the "sncState" element
     */
    void setSncState(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType.Enum sncState);
    
    /**
     * Sets (as xml) the "sncState" element
     */
    void xsetSncState(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionStateType sncState);
    
    /**
     * Nils the "sncState" element
     */
    void setNilSncState();
    
    /**
     * Unsets the "sncState" element
     */
    void unsetSncState();
    
    /**
     * Gets the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum getDirection();
    
    /**
     * Gets (as xml) the "direction" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType xgetDirection();
    
    /**
     * Tests for nil "direction" element
     */
    boolean isNilDirection();
    
    /**
     * True if has "direction" element
     */
    boolean isSetDirection();
    
    /**
     * Sets the "direction" element
     */
    void setDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType.Enum direction);
    
    /**
     * Sets (as xml) the "direction" element
     */
    void xsetDirection(org.tmforum.mtop.nrf.xsd.com.v1.ConnectionDirectionType direction);
    
    /**
     * Nils the "direction" element
     */
    void setNilDirection();
    
    /**
     * Unsets the "direction" element
     */
    void unsetDirection();
    
    /**
     * Gets the "rate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getRate();
    
    /**
     * Tests for nil "rate" element
     */
    boolean isNilRate();
    
    /**
     * True if has "rate" element
     */
    boolean isSetRate();
    
    /**
     * Sets the "rate" element
     */
    void setRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType rate);
    
    /**
     * Appends and returns a new empty "rate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewRate();
    
    /**
     * Nils the "rate" element
     */
    void setNilRate();
    
    /**
     * Unsets the "rate" element
     */
    void unsetRate();
    
    /**
     * Gets the "staticProtectionLevel" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType getStaticProtectionLevel();
    
    /**
     * Tests for nil "staticProtectionLevel" element
     */
    boolean isNilStaticProtectionLevel();
    
    /**
     * True if has "staticProtectionLevel" element
     */
    boolean isSetStaticProtectionLevel();
    
    /**
     * Sets the "staticProtectionLevel" element
     */
    void setStaticProtectionLevel(org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType staticProtectionLevel);
    
    /**
     * Appends and returns a new empty "staticProtectionLevel" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.StaticProtectionLevelType addNewStaticProtectionLevel();
    
    /**
     * Nils the "staticProtectionLevel" element
     */
    void setNilStaticProtectionLevel();
    
    /**
     * Unsets the "staticProtectionLevel" element
     */
    void unsetStaticProtectionLevel();
    
    /**
     * Gets the "sncType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType.Enum getSncType();
    
    /**
     * Gets (as xml) the "sncType" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType xgetSncType();
    
    /**
     * Tests for nil "sncType" element
     */
    boolean isNilSncType();
    
    /**
     * True if has "sncType" element
     */
    boolean isSetSncType();
    
    /**
     * Sets the "sncType" element
     */
    void setSncType(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType.Enum sncType);
    
    /**
     * Sets (as xml) the "sncType" element
     */
    void xsetSncType(org.tmforum.mtop.nrf.xsd.com.v1.SubnetworkConnectionTypeType sncType);
    
    /**
     * Nils the "sncType" element
     */
    void setNilSncType();
    
    /**
     * Unsets the "sncType" element
     */
    void unsetSncType();
    
    /**
     * Gets the "aEndTpDataList" element
     */
    org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getAEndTpDataList();
    
    /**
     * Tests for nil "aEndTpDataList" element
     */
    boolean isNilAEndTpDataList();
    
    /**
     * True if has "aEndTpDataList" element
     */
    boolean isSetAEndTpDataList();
    
    /**
     * Sets the "aEndTpDataList" element
     */
    void setAEndTpDataList(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType aEndTpDataList);
    
    /**
     * Appends and returns a new empty "aEndTpDataList" element
     */
    org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewAEndTpDataList();
    
    /**
     * Nils the "aEndTpDataList" element
     */
    void setNilAEndTpDataList();
    
    /**
     * Unsets the "aEndTpDataList" element
     */
    void unsetAEndTpDataList();
    
    /**
     * Gets the "zEndTpDataList" element
     */
    org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType getZEndTpDataList();
    
    /**
     * Tests for nil "zEndTpDataList" element
     */
    boolean isNilZEndTpDataList();
    
    /**
     * True if has "zEndTpDataList" element
     */
    boolean isSetZEndTpDataList();
    
    /**
     * Sets the "zEndTpDataList" element
     */
    void setZEndTpDataList(org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType zEndTpDataList);
    
    /**
     * Appends and returns a new empty "zEndTpDataList" element
     */
    org.tmforum.mtop.nrf.xsd.tpdata.v1.TerminationPointDataListType addNewZEndTpDataList();
    
    /**
     * Nils the "zEndTpDataList" element
     */
    void setNilZEndTpDataList();
    
    /**
     * Unsets the "zEndTpDataList" element
     */
    void unsetZEndTpDataList();
    
    /**
     * Gets the "rerouteAllowed" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum getRerouteAllowed();
    
    /**
     * Gets (as xml) the "rerouteAllowed" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.RerouteType xgetRerouteAllowed();
    
    /**
     * Tests for nil "rerouteAllowed" element
     */
    boolean isNilRerouteAllowed();
    
    /**
     * True if has "rerouteAllowed" element
     */
    boolean isSetRerouteAllowed();
    
    /**
     * Sets the "rerouteAllowed" element
     */
    void setRerouteAllowed(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum rerouteAllowed);
    
    /**
     * Sets (as xml) the "rerouteAllowed" element
     */
    void xsetRerouteAllowed(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType rerouteAllowed);
    
    /**
     * Nils the "rerouteAllowed" element
     */
    void setNilRerouteAllowed();
    
    /**
     * Unsets the "rerouteAllowed" element
     */
    void unsetRerouteAllowed();
    
    /**
     * Gets the "networkRouted" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum getNetworkRouted();
    
    /**
     * Gets (as xml) the "networkRouted" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType xgetNetworkRouted();
    
    /**
     * Tests for nil "networkRouted" element
     */
    boolean isNilNetworkRouted();
    
    /**
     * True if has "networkRouted" element
     */
    boolean isSetNetworkRouted();
    
    /**
     * Sets the "networkRouted" element
     */
    void setNetworkRouted(org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType.Enum networkRouted);
    
    /**
     * Sets (as xml) the "networkRouted" element
     */
    void xsetNetworkRouted(org.tmforum.mtop.nrf.xsd.com.v1.NetworkRoutedType networkRouted);
    
    /**
     * Nils the "networkRouted" element
     */
    void setNilNetworkRouted();
    
    /**
     * Unsets the "networkRouted" element
     */
    void unsetNetworkRouted();
    
    /**
     * Gets the "isReportingAlarm" element
     */
    boolean getIsReportingAlarm();
    
    /**
     * Gets (as xml) the "isReportingAlarm" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsReportingAlarm();
    
    /**
     * Tests for nil "isReportingAlarm" element
     */
    boolean isNilIsReportingAlarm();
    
    /**
     * True if has "isReportingAlarm" element
     */
    boolean isSetIsReportingAlarm();
    
    /**
     * Sets the "isReportingAlarm" element
     */
    void setIsReportingAlarm(boolean isReportingAlarm);
    
    /**
     * Sets (as xml) the "isReportingAlarm" element
     */
    void xsetIsReportingAlarm(org.apache.xmlbeans.XmlBoolean isReportingAlarm);
    
    /**
     * Nils the "isReportingAlarm" element
     */
    void setNilIsReportingAlarm();
    
    /**
     * Unsets the "isReportingAlarm" element
     */
    void unsetIsReportingAlarm();
    
    /**
     * Gets the "isFixed" element
     */
    boolean getIsFixed();
    
    /**
     * Gets (as xml) the "isFixed" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsFixed();
    
    /**
     * Tests for nil "isFixed" element
     */
    boolean isNilIsFixed();
    
    /**
     * True if has "isFixed" element
     */
    boolean isSetIsFixed();
    
    /**
     * Sets the "isFixed" element
     */
    void setIsFixed(boolean isFixed);
    
    /**
     * Sets (as xml) the "isFixed" element
     */
    void xsetIsFixed(org.apache.xmlbeans.XmlBoolean isFixed);
    
    /**
     * Nils the "isFixed" element
     */
    void setNilIsFixed();
    
    /**
     * Unsets the "isFixed" element
     */
    void unsetIsFixed();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * Gets the "correlationId" element
     */
    java.lang.String getCorrelationId();
    
    /**
     * Gets (as xml) the "correlationId" element
     */
    org.apache.xmlbeans.XmlString xgetCorrelationId();
    
    /**
     * Tests for nil "correlationId" element
     */
    boolean isNilCorrelationId();
    
    /**
     * True if has "correlationId" element
     */
    boolean isSetCorrelationId();
    
    /**
     * Sets the "correlationId" element
     */
    void setCorrelationId(java.lang.String correlationId);
    
    /**
     * Sets (as xml) the "correlationId" element
     */
    void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId);
    
    /**
     * Nils the "correlationId" element
     */
    void setNilCorrelationId();
    
    /**
     * Unsets the "correlationId" element
     */
    void unsetCorrelationId();
    
    /**
     * Gets the "networkReroute" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum getNetworkReroute();
    
    /**
     * Gets (as xml) the "networkReroute" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.RerouteType xgetNetworkReroute();
    
    /**
     * Tests for nil "networkReroute" element
     */
    boolean isNilNetworkReroute();
    
    /**
     * True if has "networkReroute" element
     */
    boolean isSetNetworkReroute();
    
    /**
     * Sets the "networkReroute" element
     */
    void setNetworkReroute(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType.Enum networkReroute);
    
    /**
     * Sets (as xml) the "networkReroute" element
     */
    void xsetNetworkReroute(org.tmforum.mtop.nrf.xsd.com.v1.RerouteType networkReroute);
    
    /**
     * Nils the "networkReroute" element
     */
    void setNilNetworkReroute();
    
    /**
     * Unsets the "networkReroute" element
     */
    void unsetNetworkReroute();
    
    /**
     * Gets the "priority" element
     */
    long getPriority();
    
    /**
     * Gets (as xml) the "priority" element
     */
    org.apache.xmlbeans.XmlUnsignedInt xgetPriority();
    
    /**
     * Tests for nil "priority" element
     */
    boolean isNilPriority();
    
    /**
     * True if has "priority" element
     */
    boolean isSetPriority();
    
    /**
     * Sets the "priority" element
     */
    void setPriority(long priority);
    
    /**
     * Sets (as xml) the "priority" element
     */
    void xsetPriority(org.apache.xmlbeans.XmlUnsignedInt priority);
    
    /**
     * Nils the "priority" element
     */
    void setNilPriority();
    
    /**
     * Unsets the "priority" element
     */
    void unsetPriority();
    
    /**
     * Gets the "revertive" element
     */
    boolean getRevertive();
    
    /**
     * Gets (as xml) the "revertive" element
     */
    org.apache.xmlbeans.XmlBoolean xgetRevertive();
    
    /**
     * Tests for nil "revertive" element
     */
    boolean isNilRevertive();
    
    /**
     * True if has "revertive" element
     */
    boolean isSetRevertive();
    
    /**
     * Sets the "revertive" element
     */
    void setRevertive(boolean revertive);
    
    /**
     * Sets (as xml) the "revertive" element
     */
    void xsetRevertive(org.apache.xmlbeans.XmlBoolean revertive);
    
    /**
     * Nils the "revertive" element
     */
    void setNilRevertive();
    
    /**
     * Unsets the "revertive" element
     */
    void unsetRevertive();
    
    /**
     * Gets the "aRoles" element
     */
    org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles getARoles();
    
    /**
     * Tests for nil "aRoles" element
     */
    boolean isNilARoles();
    
    /**
     * True if has "aRoles" element
     */
    boolean isSetARoles();
    
    /**
     * Sets the "aRoles" element
     */
    void setARoles(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles aRoles);
    
    /**
     * Appends and returns a new empty "aRoles" element
     */
    org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles addNewARoles();
    
    /**
     * Nils the "aRoles" element
     */
    void setNilARoles();
    
    /**
     * Unsets the "aRoles" element
     */
    void unsetARoles();
    
    /**
     * Gets the "aEndTpList" element
     */
    java.lang.String getAEndTpList();
    
    /**
     * Gets (as xml) the "aEndTpList" element
     */
    org.apache.xmlbeans.XmlString xgetAEndTpList();
    
    /**
     * Tests for nil "aEndTpList" element
     */
    boolean isNilAEndTpList();
    
    /**
     * True if has "aEndTpList" element
     */
    boolean isSetAEndTpList();
    
    /**
     * Sets the "aEndTpList" element
     */
    void setAEndTpList(java.lang.String aEndTpList);
    
    /**
     * Sets (as xml) the "aEndTpList" element
     */
    void xsetAEndTpList(org.apache.xmlbeans.XmlString aEndTpList);
    
    /**
     * Nils the "aEndTpList" element
     */
    void setNilAEndTpList();
    
    /**
     * Unsets the "aEndTpList" element
     */
    void unsetAEndTpList();
    
    /**
     * Gets the "aEndTnaNameOrGroupTnaName" element
     */
    java.lang.String getAEndTnaNameOrGroupTnaName();
    
    /**
     * Gets (as xml) the "aEndTnaNameOrGroupTnaName" element
     */
    org.apache.xmlbeans.XmlString xgetAEndTnaNameOrGroupTnaName();
    
    /**
     * Tests for nil "aEndTnaNameOrGroupTnaName" element
     */
    boolean isNilAEndTnaNameOrGroupTnaName();
    
    /**
     * True if has "aEndTnaNameOrGroupTnaName" element
     */
    boolean isSetAEndTnaNameOrGroupTnaName();
    
    /**
     * Sets the "aEndTnaNameOrGroupTnaName" element
     */
    void setAEndTnaNameOrGroupTnaName(java.lang.String aEndTnaNameOrGroupTnaName);
    
    /**
     * Sets (as xml) the "aEndTnaNameOrGroupTnaName" element
     */
    void xsetAEndTnaNameOrGroupTnaName(org.apache.xmlbeans.XmlString aEndTnaNameOrGroupTnaName);
    
    /**
     * Nils the "aEndTnaNameOrGroupTnaName" element
     */
    void setNilAEndTnaNameOrGroupTnaName();
    
    /**
     * Unsets the "aEndTnaNameOrGroupTnaName" element
     */
    void unsetAEndTnaNameOrGroupTnaName();
    
    /**
     * Gets the "isBundledSnc" element
     */
    boolean getIsBundledSnc();
    
    /**
     * Gets (as xml) the "isBundledSnc" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsBundledSnc();
    
    /**
     * Tests for nil "isBundledSnc" element
     */
    boolean isNilIsBundledSnc();
    
    /**
     * True if has "isBundledSnc" element
     */
    boolean isSetIsBundledSnc();
    
    /**
     * Sets the "isBundledSnc" element
     */
    void setIsBundledSnc(boolean isBundledSnc);
    
    /**
     * Sets (as xml) the "isBundledSnc" element
     */
    void xsetIsBundledSnc(org.apache.xmlbeans.XmlBoolean isBundledSnc);
    
    /**
     * Nils the "isBundledSnc" element
     */
    void setNilIsBundledSnc();
    
    /**
     * Unsets the "isBundledSnc" element
     */
    void unsetIsBundledSnc();
    
    /**
     * Gets the "callId" element
     */
    java.lang.String getCallId();
    
    /**
     * Gets (as xml) the "callId" element
     */
    org.apache.xmlbeans.XmlString xgetCallId();
    
    /**
     * Tests for nil "callId" element
     */
    boolean isNilCallId();
    
    /**
     * True if has "callId" element
     */
    boolean isSetCallId();
    
    /**
     * Sets the "callId" element
     */
    void setCallId(java.lang.String callId);
    
    /**
     * Sets (as xml) the "callId" element
     */
    void xsetCallId(org.apache.xmlbeans.XmlString callId);
    
    /**
     * Nils the "callId" element
     */
    void setNilCallId();
    
    /**
     * Unsets the "callId" element
     */
    void unsetCallId();
    
    /**
     * Gets the "callName" element
     */
    java.lang.String getCallName();
    
    /**
     * Gets (as xml) the "callName" element
     */
    org.apache.xmlbeans.XmlString xgetCallName();
    
    /**
     * Tests for nil "callName" element
     */
    boolean isNilCallName();
    
    /**
     * True if has "callName" element
     */
    boolean isSetCallName();
    
    /**
     * Sets the "callName" element
     */
    void setCallName(java.lang.String callName);
    
    /**
     * Sets (as xml) the "callName" element
     */
    void xsetCallName(org.apache.xmlbeans.XmlString callName);
    
    /**
     * Nils the "callName" element
     */
    void setNilCallName();
    
    /**
     * Unsets the "callName" element
     */
    void unsetCallName();
    
    /**
     * Gets the "connectionId" element
     */
    java.lang.String getConnectionId();
    
    /**
     * Gets (as xml) the "connectionId" element
     */
    org.apache.xmlbeans.XmlString xgetConnectionId();
    
    /**
     * Tests for nil "connectionId" element
     */
    boolean isNilConnectionId();
    
    /**
     * True if has "connectionId" element
     */
    boolean isSetConnectionId();
    
    /**
     * Sets the "connectionId" element
     */
    void setConnectionId(java.lang.String connectionId);
    
    /**
     * Sets (as xml) the "connectionId" element
     */
    void xsetConnectionId(org.apache.xmlbeans.XmlString connectionId);
    
    /**
     * Nils the "connectionId" element
     */
    void setNilConnectionId();
    
    /**
     * Unsets the "connectionId" element
     */
    void unsetConnectionId();
    
    /**
     * Gets the "connectionSetUpType" element
     */
    java.lang.String getConnectionSetUpType();
    
    /**
     * Gets (as xml) the "connectionSetUpType" element
     */
    org.apache.xmlbeans.XmlString xgetConnectionSetUpType();
    
    /**
     * Tests for nil "connectionSetUpType" element
     */
    boolean isNilConnectionSetUpType();
    
    /**
     * True if has "connectionSetUpType" element
     */
    boolean isSetConnectionSetUpType();
    
    /**
     * Sets the "connectionSetUpType" element
     */
    void setConnectionSetUpType(java.lang.String connectionSetUpType);
    
    /**
     * Sets (as xml) the "connectionSetUpType" element
     */
    void xsetConnectionSetUpType(org.apache.xmlbeans.XmlString connectionSetUpType);
    
    /**
     * Nils the "connectionSetUpType" element
     */
    void setNilConnectionSetUpType();
    
    /**
     * Unsets the "connectionSetUpType" element
     */
    void unsetConnectionSetUpType();
    
    /**
     * Gets the "connectionState" element
     */
    java.lang.String getConnectionState();
    
    /**
     * Gets (as xml) the "connectionState" element
     */
    org.apache.xmlbeans.XmlString xgetConnectionState();
    
    /**
     * Tests for nil "connectionState" element
     */
    boolean isNilConnectionState();
    
    /**
     * True if has "connectionState" element
     */
    boolean isSetConnectionState();
    
    /**
     * Sets the "connectionState" element
     */
    void setConnectionState(java.lang.String connectionState);
    
    /**
     * Sets (as xml) the "connectionState" element
     */
    void xsetConnectionState(org.apache.xmlbeans.XmlString connectionState);
    
    /**
     * Nils the "connectionState" element
     */
    void setNilConnectionState();
    
    /**
     * Unsets the "connectionState" element
     */
    void unsetConnectionState();
    
    /**
     * Gets the "maximumCost" element
     */
    java.lang.String getMaximumCost();
    
    /**
     * Gets (as xml) the "maximumCost" element
     */
    org.apache.xmlbeans.XmlString xgetMaximumCost();
    
    /**
     * Tests for nil "maximumCost" element
     */
    boolean isNilMaximumCost();
    
    /**
     * True if has "maximumCost" element
     */
    boolean isSetMaximumCost();
    
    /**
     * Sets the "maximumCost" element
     */
    void setMaximumCost(java.lang.String maximumCost);
    
    /**
     * Sets (as xml) the "maximumCost" element
     */
    void xsetMaximumCost(org.apache.xmlbeans.XmlString maximumCost);
    
    /**
     * Nils the "maximumCost" element
     */
    void setNilMaximumCost();
    
    /**
     * Unsets the "maximumCost" element
     */
    void unsetMaximumCost();
    
    /**
     * Gets the "isMustRemoveGtpList" element
     */
    boolean getIsMustRemoveGtpList();
    
    /**
     * Gets (as xml) the "isMustRemoveGtpList" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsMustRemoveGtpList();
    
    /**
     * Tests for nil "isMustRemoveGtpList" element
     */
    boolean isNilIsMustRemoveGtpList();
    
    /**
     * True if has "isMustRemoveGtpList" element
     */
    boolean isSetIsMustRemoveGtpList();
    
    /**
     * Sets the "isMustRemoveGtpList" element
     */
    void setIsMustRemoveGtpList(boolean isMustRemoveGtpList);
    
    /**
     * Sets (as xml) the "isMustRemoveGtpList" element
     */
    void xsetIsMustRemoveGtpList(org.apache.xmlbeans.XmlBoolean isMustRemoveGtpList);
    
    /**
     * Nils the "isMustRemoveGtpList" element
     */
    void setNilIsMustRemoveGtpList();
    
    /**
     * Unsets the "isMustRemoveGtpList" element
     */
    void unsetIsMustRemoveGtpList();
    
    /**
     * Gets the "protectionEffort" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum getProtectionEffort();
    
    /**
     * Gets (as xml) the "protectionEffort" element
     */
    org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType xgetProtectionEffort();
    
    /**
     * Tests for nil "protectionEffort" element
     */
    boolean isNilProtectionEffort();
    
    /**
     * True if has "protectionEffort" element
     */
    boolean isSetProtectionEffort();
    
    /**
     * Sets the "protectionEffort" element
     */
    void setProtectionEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType.Enum protectionEffort);
    
    /**
     * Sets (as xml) the "protectionEffort" element
     */
    void xsetProtectionEffort(org.tmforum.mtop.nrf.xsd.com.v1.ProtectionEffortType protectionEffort);
    
    /**
     * Nils the "protectionEffort" element
     */
    void setNilProtectionEffort();
    
    /**
     * Unsets the "protectionEffort" element
     */
    void unsetProtectionEffort();
    
    /**
     * Gets the "routeGroupLabel" element
     */
    java.lang.String getRouteGroupLabel();
    
    /**
     * Gets (as xml) the "routeGroupLabel" element
     */
    org.apache.xmlbeans.XmlString xgetRouteGroupLabel();
    
    /**
     * Tests for nil "routeGroupLabel" element
     */
    boolean isNilRouteGroupLabel();
    
    /**
     * True if has "routeGroupLabel" element
     */
    boolean isSetRouteGroupLabel();
    
    /**
     * Sets the "routeGroupLabel" element
     */
    void setRouteGroupLabel(java.lang.String routeGroupLabel);
    
    /**
     * Sets (as xml) the "routeGroupLabel" element
     */
    void xsetRouteGroupLabel(org.apache.xmlbeans.XmlString routeGroupLabel);
    
    /**
     * Nils the "routeGroupLabel" element
     */
    void setNilRouteGroupLabel();
    
    /**
     * Unsets the "routeGroupLabel" element
     */
    void unsetRouteGroupLabel();
    
    /**
     * Gets the "routingConstraintEffort" element
     */
    java.lang.String getRoutingConstraintEffort();
    
    /**
     * Gets (as xml) the "routingConstraintEffort" element
     */
    org.apache.xmlbeans.XmlString xgetRoutingConstraintEffort();
    
    /**
     * Tests for nil "routingConstraintEffort" element
     */
    boolean isNilRoutingConstraintEffort();
    
    /**
     * True if has "routingConstraintEffort" element
     */
    boolean isSetRoutingConstraintEffort();
    
    /**
     * Sets the "routingConstraintEffort" element
     */
    void setRoutingConstraintEffort(java.lang.String routingConstraintEffort);
    
    /**
     * Sets (as xml) the "routingConstraintEffort" element
     */
    void xsetRoutingConstraintEffort(org.apache.xmlbeans.XmlString routingConstraintEffort);
    
    /**
     * Nils the "routingConstraintEffort" element
     */
    void setNilRoutingConstraintEffort();
    
    /**
     * Unsets the "routingConstraintEffort" element
     */
    void unsetRoutingConstraintEffort();
    
    /**
     * Gets the "srg" element
     */
    java.lang.String getSrg();
    
    /**
     * Gets (as xml) the "srg" element
     */
    org.apache.xmlbeans.XmlString xgetSrg();
    
    /**
     * Tests for nil "srg" element
     */
    boolean isNilSrg();
    
    /**
     * True if has "srg" element
     */
    boolean isSetSrg();
    
    /**
     * Sets the "srg" element
     */
    void setSrg(java.lang.String srg);
    
    /**
     * Sets (as xml) the "srg" element
     */
    void xsetSrg(org.apache.xmlbeans.XmlString srg);
    
    /**
     * Nils the "srg" element
     */
    void setNilSrg();
    
    /**
     * Unsets the "srg" element
     */
    void unsetSrg();
    
    /**
     * Gets the "supportedConnectionName" element
     */
    java.lang.String getSupportedConnectionName();
    
    /**
     * Gets (as xml) the "supportedConnectionName" element
     */
    org.apache.xmlbeans.XmlString xgetSupportedConnectionName();
    
    /**
     * Tests for nil "supportedConnectionName" element
     */
    boolean isNilSupportedConnectionName();
    
    /**
     * True if has "supportedConnectionName" element
     */
    boolean isSetSupportedConnectionName();
    
    /**
     * Sets the "supportedConnectionName" element
     */
    void setSupportedConnectionName(java.lang.String supportedConnectionName);
    
    /**
     * Sets (as xml) the "supportedConnectionName" element
     */
    void xsetSupportedConnectionName(org.apache.xmlbeans.XmlString supportedConnectionName);
    
    /**
     * Nils the "supportedConnectionName" element
     */
    void setNilSupportedConnectionName();
    
    /**
     * Unsets the "supportedConnectionName" element
     */
    void unsetSupportedConnectionName();
    
    /**
     * Gets the "supportingSncList" element
     */
    java.lang.String getSupportingSncList();
    
    /**
     * Gets (as xml) the "supportingSncList" element
     */
    org.apache.xmlbeans.XmlString xgetSupportingSncList();
    
    /**
     * Tests for nil "supportingSncList" element
     */
    boolean isNilSupportingSncList();
    
    /**
     * True if has "supportingSncList" element
     */
    boolean isSetSupportingSncList();
    
    /**
     * Sets the "supportingSncList" element
     */
    void setSupportingSncList(java.lang.String supportingSncList);
    
    /**
     * Sets (as xml) the "supportingSncList" element
     */
    void xsetSupportingSncList(org.apache.xmlbeans.XmlString supportingSncList);
    
    /**
     * Nils the "supportingSncList" element
     */
    void setNilSupportingSncList();
    
    /**
     * Unsets the "supportingSncList" element
     */
    void unsetSupportingSncList();
    
    /**
     * Gets the "isUsingHomeRoute" element
     */
    boolean getIsUsingHomeRoute();
    
    /**
     * Gets (as xml) the "isUsingHomeRoute" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsUsingHomeRoute();
    
    /**
     * Tests for nil "isUsingHomeRoute" element
     */
    boolean isNilIsUsingHomeRoute();
    
    /**
     * True if has "isUsingHomeRoute" element
     */
    boolean isSetIsUsingHomeRoute();
    
    /**
     * Sets the "isUsingHomeRoute" element
     */
    void setIsUsingHomeRoute(boolean isUsingHomeRoute);
    
    /**
     * Sets (as xml) the "isUsingHomeRoute" element
     */
    void xsetIsUsingHomeRoute(org.apache.xmlbeans.XmlBoolean isUsingHomeRoute);
    
    /**
     * Nils the "isUsingHomeRoute" element
     */
    void setNilIsUsingHomeRoute();
    
    /**
     * Unsets the "isUsingHomeRoute" element
     */
    void unsetIsUsingHomeRoute();
    
    /**
     * Gets the "zRoles" element
     */
    org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles getZRoles();
    
    /**
     * Tests for nil "zRoles" element
     */
    boolean isNilZRoles();
    
    /**
     * True if has "zRoles" element
     */
    boolean isSetZRoles();
    
    /**
     * Sets the "zRoles" element
     */
    void setZRoles(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles zRoles);
    
    /**
     * Appends and returns a new empty "zRoles" element
     */
    org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles addNewZRoles();
    
    /**
     * Nils the "zRoles" element
     */
    void setNilZRoles();
    
    /**
     * Unsets the "zRoles" element
     */
    void unsetZRoles();
    
    /**
     * Gets the "zEndTpList" element
     */
    java.lang.String getZEndTpList();
    
    /**
     * Gets (as xml) the "zEndTpList" element
     */
    org.apache.xmlbeans.XmlString xgetZEndTpList();
    
    /**
     * Tests for nil "zEndTpList" element
     */
    boolean isNilZEndTpList();
    
    /**
     * True if has "zEndTpList" element
     */
    boolean isSetZEndTpList();
    
    /**
     * Sets the "zEndTpList" element
     */
    void setZEndTpList(java.lang.String zEndTpList);
    
    /**
     * Sets (as xml) the "zEndTpList" element
     */
    void xsetZEndTpList(org.apache.xmlbeans.XmlString zEndTpList);
    
    /**
     * Nils the "zEndTpList" element
     */
    void setNilZEndTpList();
    
    /**
     * Unsets the "zEndTpList" element
     */
    void unsetZEndTpList();
    
    /**
     * Gets the "zEndTnaNameOrGroupTnaName" element
     */
    java.lang.String getZEndTnaNameOrGroupTnaName();
    
    /**
     * Gets (as xml) the "zEndTnaNameOrGroupTnaName" element
     */
    org.apache.xmlbeans.XmlString xgetZEndTnaNameOrGroupTnaName();
    
    /**
     * Tests for nil "zEndTnaNameOrGroupTnaName" element
     */
    boolean isNilZEndTnaNameOrGroupTnaName();
    
    /**
     * True if has "zEndTnaNameOrGroupTnaName" element
     */
    boolean isSetZEndTnaNameOrGroupTnaName();
    
    /**
     * Sets the "zEndTnaNameOrGroupTnaName" element
     */
    void setZEndTnaNameOrGroupTnaName(java.lang.String zEndTnaNameOrGroupTnaName);
    
    /**
     * Sets (as xml) the "zEndTnaNameOrGroupTnaName" element
     */
    void xsetZEndTnaNameOrGroupTnaName(org.apache.xmlbeans.XmlString zEndTnaNameOrGroupTnaName);
    
    /**
     * Nils the "zEndTnaNameOrGroupTnaName" element
     */
    void setNilZEndTnaNameOrGroupTnaName();
    
    /**
     * Unsets the "zEndTnaNameOrGroupTnaName" element
     */
    void unsetZEndTnaNameOrGroupTnaName();
    
    /**
     * An XML aRoles(@http://www.tmforum.org/mtop/nrf/xsd/snc/v1).
     *
     * This is a complex type.
     */
    public interface ARoles extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ARoles.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("aroles11cbelemtype");
        
        /**
         * Gets a List of "role" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum> getRoleList();
        
        /**
         * Gets array of all "role" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum[] getRoleArray();
        
        /**
         * Gets ith "role" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum getRoleArray(int i);
        
        /**
         * Gets (as xml) a List of "role" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType> xgetRoleList();
        
        /**
         * Gets (as xml) array of all "role" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType[] xgetRoleArray();
        
        /**
         * Gets (as xml) ith "role" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType xgetRoleArray(int i);
        
        /**
         * Returns number of "role" element
         */
        int sizeOfRoleArray();
        
        /**
         * Sets array of all "role" element
         */
        void setRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum[] roleArray);
        
        /**
         * Sets ith "role" element
         */
        void setRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum role);
        
        /**
         * Sets (as xml) array of all "role" element
         */
        void xsetRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType[] roleArray);
        
        /**
         * Sets (as xml) ith "role" element
         */
        void xsetRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType role);
        
        /**
         * Inserts the value as the ith "role" element
         */
        void insertRole(int i, org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum role);
        
        /**
         * Appends the value as the last "role" element
         */
        void addRole(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum role);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "role" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType insertNewRole(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "role" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType addNewRole();
        
        /**
         * Removes the ith "role" element
         */
        void removeRole(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles newInstance() {
              return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ARoles) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML zRoles(@http://www.tmforum.org/mtop/nrf/xsd/snc/v1).
     *
     * This is a complex type.
     */
    public interface ZRoles extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ZRoles.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("zroles8012elemtype");
        
        /**
         * Gets a List of "role" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum> getRoleList();
        
        /**
         * Gets array of all "role" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum[] getRoleArray();
        
        /**
         * Gets ith "role" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum getRoleArray(int i);
        
        /**
         * Gets (as xml) a List of "role" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType> xgetRoleList();
        
        /**
         * Gets (as xml) array of all "role" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType[] xgetRoleArray();
        
        /**
         * Gets (as xml) ith "role" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType xgetRoleArray(int i);
        
        /**
         * Returns number of "role" element
         */
        int sizeOfRoleArray();
        
        /**
         * Sets array of all "role" element
         */
        void setRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum[] roleArray);
        
        /**
         * Sets ith "role" element
         */
        void setRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum role);
        
        /**
         * Sets (as xml) array of all "role" element
         */
        void xsetRoleArray(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType[] roleArray);
        
        /**
         * Sets (as xml) ith "role" element
         */
        void xsetRoleArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType role);
        
        /**
         * Inserts the value as the ith "role" element
         */
        void insertRole(int i, org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum role);
        
        /**
         * Appends the value as the last "role" element
         */
        void addRole(org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType.Enum role);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "role" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType insertNewRole(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "role" element
         */
        org.tmforum.mtop.nrf.xsd.com.v1.TerminationPointRoleInSubnetworkConnectionType addNewRole();
        
        /**
         * Removes the ith "role" element
         */
        void removeRole(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles newInstance() {
              return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType.ZRoles) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
