/*
 * XML Type:  FloatingTerminationPointInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML FloatingTerminationPointInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface FloatingTerminationPointInventoryType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FloatingTerminationPointInventoryType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("floatingterminationpointinventorytype6e34type");
    
    /**
     * Gets the "ftpNm" element
     */
    java.lang.String getFtpNm();
    
    /**
     * Gets (as xml) the "ftpNm" element
     */
    org.apache.xmlbeans.XmlString xgetFtpNm();
    
    /**
     * True if has "ftpNm" element
     */
    boolean isSetFtpNm();
    
    /**
     * Sets the "ftpNm" element
     */
    void setFtpNm(java.lang.String ftpNm);
    
    /**
     * Sets (as xml) the "ftpNm" element
     */
    void xsetFtpNm(org.apache.xmlbeans.XmlString ftpNm);
    
    /**
     * Unsets the "ftpNm" element
     */
    void unsetFtpNm();
    
    /**
     * Gets the "ftpAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType getFtpAttrs();
    
    /**
     * True if has "ftpAttrs" element
     */
    boolean isSetFtpAttrs();
    
    /**
     * Sets the "ftpAttrs" element
     */
    void setFtpAttrs(org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType ftpAttrs);
    
    /**
     * Appends and returns a new empty "ftpAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType addNewFtpAttrs();
    
    /**
     * Unsets the "ftpAttrs" element
     */
    void unsetFtpAttrs();
    
    /**
     * Gets the "ctpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList getCtpList();
    
    /**
     * True if has "ctpList" element
     */
    boolean isSetCtpList();
    
    /**
     * Sets the "ctpList" element
     */
    void setCtpList(org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList ctpList);
    
    /**
     * Appends and returns a new empty "ctpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList addNewCtpList();
    
    /**
     * Unsets the "ctpList" element
     */
    void unsetCtpList();
    
    /**
     * Gets the "supportingEquipmentRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportingEquipmentRefList();
    
    /**
     * True if has "supportingEquipmentRefList" element
     */
    boolean isSetSupportingEquipmentRefList();
    
    /**
     * Sets the "supportingEquipmentRefList" element
     */
    void setSupportingEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportingEquipmentRefList);
    
    /**
     * Appends and returns a new empty "supportingEquipmentRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportingEquipmentRefList();
    
    /**
     * Unsets the "supportingEquipmentRefList" element
     */
    void unsetSupportingEquipmentRefList();
    
    /**
     * Gets the "supportedFixedSncRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportedFixedSncRefList();
    
    /**
     * True if has "supportedFixedSncRefList" element
     */
    boolean isSetSupportedFixedSncRefList();
    
    /**
     * Sets the "supportedFixedSncRefList" element
     */
    void setSupportedFixedSncRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportedFixedSncRefList);
    
    /**
     * Appends and returns a new empty "supportedFixedSncRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportedFixedSncRefList();
    
    /**
     * Unsets the "supportedFixedSncRefList" element
     */
    void unsetSupportedFixedSncRefList();
    
    /**
     * Gets the "allSupportedSncRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAllSupportedSncRefList();
    
    /**
     * True if has "allSupportedSncRefList" element
     */
    boolean isSetAllSupportedSncRefList();
    
    /**
     * Sets the "allSupportedSncRefList" element
     */
    void setAllSupportedSncRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType allSupportedSncRefList);
    
    /**
     * Appends and returns a new empty "allSupportedSncRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAllSupportedSncRefList();
    
    /**
     * Unsets the "allSupportedSncRefList" element
     */
    void unsetAllSupportedSncRefList();
    
    /**
     * Gets the "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator();
    
    /**
     * True if has "qualityIndicator" element
     */
    boolean isSetQualityIndicator();
    
    /**
     * Sets the "qualityIndicator" element
     */
    void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator);
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator();
    
    /**
     * Unsets the "qualityIndicator" element
     */
    void unsetQualityIndicator();
    
    /**
     * An XML ctpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface CtpList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CtpList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("ctpliste84belemtype");
        
        /**
         * Gets a List of "ctpInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType> getCtpInvList();
        
        /**
         * Gets array of all "ctpInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType[] getCtpInvArray();
        
        /**
         * Gets ith "ctpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType getCtpInvArray(int i);
        
        /**
         * Returns number of "ctpInv" element
         */
        int sizeOfCtpInvArray();
        
        /**
         * Sets array of all "ctpInv" element
         */
        void setCtpInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType[] ctpInvArray);
        
        /**
         * Sets ith "ctpInv" element
         */
        void setCtpInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType ctpInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ctpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType insertNewCtpInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ctpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType addNewCtpInv();
        
        /**
         * Removes the ith "ctpInv" element
         */
        void removeCtpInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType.CtpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
