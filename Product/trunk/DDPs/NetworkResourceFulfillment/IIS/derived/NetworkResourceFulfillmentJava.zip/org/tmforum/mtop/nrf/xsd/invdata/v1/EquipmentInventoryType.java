/*
 * XML Type:  EquipmentInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML EquipmentInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface EquipmentInventoryType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EquipmentInventoryType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("equipmentinventorytypeefbetype");
    
    /**
     * Gets the "eqNm" element
     */
    java.lang.String getEqNm();
    
    /**
     * Gets (as xml) the "eqNm" element
     */
    org.apache.xmlbeans.XmlString xgetEqNm();
    
    /**
     * True if has "eqNm" element
     */
    boolean isSetEqNm();
    
    /**
     * Sets the "eqNm" element
     */
    void setEqNm(java.lang.String eqNm);
    
    /**
     * Sets (as xml) the "eqNm" element
     */
    void xsetEqNm(org.apache.xmlbeans.XmlString eqNm);
    
    /**
     * Unsets the "eqNm" element
     */
    void unsetEqNm();
    
    /**
     * Gets the "eqAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType getEqAttrs();
    
    /**
     * True if has "eqAttrs" element
     */
    boolean isSetEqAttrs();
    
    /**
     * Sets the "eqAttrs" element
     */
    void setEqAttrs(org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType eqAttrs);
    
    /**
     * Appends and returns a new empty "eqAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType addNewEqAttrs();
    
    /**
     * Unsets the "eqAttrs" element
     */
    void unsetEqAttrs();
    
    /**
     * Gets the "supportedPtpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportedPtpRefList();
    
    /**
     * True if has "supportedPtpRefList" element
     */
    boolean isSetSupportedPtpRefList();
    
    /**
     * Sets the "supportedPtpRefList" element
     */
    void setSupportedPtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportedPtpRefList);
    
    /**
     * Appends and returns a new empty "supportedPtpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportedPtpRefList();
    
    /**
     * Unsets the "supportedPtpRefList" element
     */
    void unsetSupportedPtpRefList();
    
    /**
     * Gets the "supportedEquipmentRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportedEquipmentRefList();
    
    /**
     * True if has "supportedEquipmentRefList" element
     */
    boolean isSetSupportedEquipmentRefList();
    
    /**
     * Sets the "supportedEquipmentRefList" element
     */
    void setSupportedEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportedEquipmentRefList);
    
    /**
     * Appends and returns a new empty "supportedEquipmentRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportedEquipmentRefList();
    
    /**
     * Unsets the "supportedEquipmentRefList" element
     */
    void unsetSupportedEquipmentRefList();
    
    /**
     * Gets the "supportingEquipmentRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportingEquipmentRefList();
    
    /**
     * True if has "supportingEquipmentRefList" element
     */
    boolean isSetSupportingEquipmentRefList();
    
    /**
     * Sets the "supportingEquipmentRefList" element
     */
    void setSupportingEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportingEquipmentRefList);
    
    /**
     * Appends and returns a new empty "supportingEquipmentRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportingEquipmentRefList();
    
    /**
     * Unsets the "supportingEquipmentRefList" element
     */
    void unsetSupportingEquipmentRefList();
    
    /**
     * Gets the "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator();
    
    /**
     * True if has "qualityIndicator" element
     */
    boolean isSetQualityIndicator();
    
    /**
     * Sets the "qualityIndicator" element
     */
    void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator);
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator();
    
    /**
     * Unsets the "qualityIndicator" element
     */
    void unsetQualityIndicator();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
