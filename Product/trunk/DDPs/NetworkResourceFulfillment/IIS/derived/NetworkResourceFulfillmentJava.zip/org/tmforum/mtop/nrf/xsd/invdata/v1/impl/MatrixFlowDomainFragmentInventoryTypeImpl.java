/*
 * XML Type:  MatrixFlowDomainFragmentInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML MatrixFlowDomainFragmentInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class MatrixFlowDomainFragmentInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType
{
    
    public MatrixFlowDomainFragmentInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MFDFRATTRS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mfdfrAttrs");
    private static final javax.xml.namespace.QName CTPREFLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ctpRefList");
    private static final javax.xml.namespace.QName FTPREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ftpRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "mfdfrAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType getMfdfrAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().find_element_user(MFDFRATTRS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mfdfrAttrs" element
     */
    public boolean isSetMfdfrAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFDFRATTRS$0) != 0;
        }
    }
    
    /**
     * Sets the "mfdfrAttrs" element
     */
    public void setMfdfrAttrs(org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType mfdfrAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().find_element_user(MFDFRATTRS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().add_element_user(MFDFRATTRS$0);
            }
            target.set(mfdfrAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "mfdfrAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType addNewMfdfrAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().add_element_user(MFDFRATTRS$0);
            return target;
        }
    }
    
    /**
     * Unsets the "mfdfrAttrs" element
     */
    public void unsetMfdfrAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFDFRATTRS$0, 0);
        }
    }
    
    /**
     * Gets the "ctpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getCtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CTPREFLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ctpRefList" element
     */
    public boolean isSetCtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CTPREFLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "ctpRefList" element
     */
    public void setCtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ctpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CTPREFLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CTPREFLIST$2);
            }
            target.set(ctpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "ctpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewCtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CTPREFLIST$2);
            return target;
        }
    }
    
    /**
     * Unsets the "ctpRefList" element
     */
    public void unsetCtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CTPREFLIST$2, 0);
        }
    }
    
    /**
     * Gets the "ftpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(FTPREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ftpRefList" element
     */
    public boolean isSetFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FTPREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "ftpRefList" element
     */
    public void setFtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ftpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(FTPREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(FTPREFLIST$4);
            }
            target.set(ftpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "ftpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(FTPREFLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ftpRefList" element
     */
    public void unsetFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FTPREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$6) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$6, 0);
        }
    }
}
