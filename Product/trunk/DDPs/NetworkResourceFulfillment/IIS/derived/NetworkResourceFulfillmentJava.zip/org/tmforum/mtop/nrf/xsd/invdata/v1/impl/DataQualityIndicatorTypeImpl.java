/*
 * XML Type:  DataQualityIndicatorType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML DataQualityIndicatorType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class DataQualityIndicatorTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType
{
    
    public DataQualityIndicatorTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ISSUSPECT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "isSuspect");
    private static final javax.xml.namespace.QName ISDESCENDANT$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "isDescendant");
    private static final javax.xml.namespace.QName REASON$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "reason");
    
    
    /**
     * Gets the "isSuspect" element
     */
    public boolean getIsSuspect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSUSPECT$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isSuspect" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsSuspect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSUSPECT$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "isSuspect" element
     */
    public boolean isSetIsSuspect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISSUSPECT$0) != 0;
        }
    }
    
    /**
     * Sets the "isSuspect" element
     */
    public void setIsSuspect(boolean isSuspect)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSUSPECT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISSUSPECT$0);
            }
            target.setBooleanValue(isSuspect);
        }
    }
    
    /**
     * Sets (as xml) the "isSuspect" element
     */
    public void xsetIsSuspect(org.apache.xmlbeans.XmlBoolean isSuspect)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSUSPECT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISSUSPECT$0);
            }
            target.set(isSuspect);
        }
    }
    
    /**
     * Unsets the "isSuspect" element
     */
    public void unsetIsSuspect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISSUSPECT$0, 0);
        }
    }
    
    /**
     * Gets the "isDescendant" element
     */
    public boolean getIsDescendant()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISDESCENDANT$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isDescendant" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsDescendant()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISDESCENDANT$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "isDescendant" element
     */
    public boolean isSetIsDescendant()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISDESCENDANT$2) != 0;
        }
    }
    
    /**
     * Sets the "isDescendant" element
     */
    public void setIsDescendant(boolean isDescendant)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISDESCENDANT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISDESCENDANT$2);
            }
            target.setBooleanValue(isDescendant);
        }
    }
    
    /**
     * Sets (as xml) the "isDescendant" element
     */
    public void xsetIsDescendant(org.apache.xmlbeans.XmlBoolean isDescendant)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISDESCENDANT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISDESCENDANT$2);
            }
            target.set(isDescendant);
        }
    }
    
    /**
     * Unsets the "isDescendant" element
     */
    public void unsetIsDescendant()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISDESCENDANT$2, 0);
        }
    }
    
    /**
     * Gets the "reason" element
     */
    public java.lang.String getReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REASON$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "reason" element
     */
    public org.apache.xmlbeans.XmlString xgetReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REASON$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "reason" element
     */
    public boolean isSetReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REASON$4) != 0;
        }
    }
    
    /**
     * Sets the "reason" element
     */
    public void setReason(java.lang.String reason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REASON$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REASON$4);
            }
            target.setStringValue(reason);
        }
    }
    
    /**
     * Sets (as xml) the "reason" element
     */
    public void xsetReason(org.apache.xmlbeans.XmlString reason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REASON$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(REASON$4);
            }
            target.set(reason);
        }
    }
    
    /**
     * Unsets the "reason" element
     */
    public void unsetReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REASON$4, 0);
        }
    }
}
