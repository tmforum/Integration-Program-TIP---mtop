/*
 * XML Type:  ProtectionGroupInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML ProtectionGroupInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class ProtectionGroupInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType
{
    
    public ProtectionGroupInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PGNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "pgNm");
    private static final javax.xml.namespace.QName PGATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "pgAttrs");
    private static final javax.xml.namespace.QName PROTECTEDPTPREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "protectedPtpRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "pgNm" element
     */
    public java.lang.String getPgNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PGNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pgNm" element
     */
    public org.apache.xmlbeans.XmlString xgetPgNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PGNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "pgNm" element
     */
    public boolean isSetPgNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PGNM$0) != 0;
        }
    }
    
    /**
     * Sets the "pgNm" element
     */
    public void setPgNm(java.lang.String pgNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PGNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PGNM$0);
            }
            target.setStringValue(pgNm);
        }
    }
    
    /**
     * Sets (as xml) the "pgNm" element
     */
    public void xsetPgNm(org.apache.xmlbeans.XmlString pgNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PGNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PGNM$0);
            }
            target.set(pgNm);
        }
    }
    
    /**
     * Unsets the "pgNm" element
     */
    public void unsetPgNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PGNM$0, 0);
        }
    }
    
    /**
     * Gets the "pgAttrs" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType getPgAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PGATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "pgAttrs" element
     */
    public boolean isSetPgAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PGATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "pgAttrs" element
     */
    public void setPgAttrs(org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType pgAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PGATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().add_element_user(PGATTRS$2);
            }
            target.set(pgAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "pgAttrs" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType addNewPgAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().add_element_user(PGATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "pgAttrs" element
     */
    public void unsetPgAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PGATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "protectedPtpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getProtectedPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTEDPTPREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "protectedPtpRefList" element
     */
    public boolean isSetProtectedPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTEDPTPREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "protectedPtpRefList" element
     */
    public void setProtectedPtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType protectedPtpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTEDPTPREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTEDPTPREFLIST$4);
            }
            target.set(protectedPtpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "protectedPtpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewProtectedPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTEDPTPREFLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "protectedPtpRefList" element
     */
    public void unsetProtectedPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTEDPTPREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$6) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$6, 0);
        }
    }
}
