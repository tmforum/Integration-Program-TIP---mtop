/*
 * An XML document type.
 * Localname: mfdfr
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1
 * Java type: org.tmforum.mtop.nrf.xsd.mfdfr.v1.MfdfrDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.mfdfr.v1.impl;
/**
 * A document containing one mfdfr(@http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1) element.
 *
 * This is a complex type.
 */
public class MfdfrDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.mfdfr.v1.MfdfrDocument
{
    
    public MfdfrDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MFDFR$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/mfdfr/v1", "mfdfr");
    
    
    /**
     * Gets the "mfdfr" element
     */
    public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType getMfdfr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().find_element_user(MFDFR$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "mfdfr" element
     */
    public void setMfdfr(org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType mfdfr)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().find_element_user(MFDFR$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().add_element_user(MFDFR$0);
            }
            target.set(mfdfr);
        }
    }
    
    /**
     * Appends and returns a new empty "mfdfr" element
     */
    public org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType addNewMfdfr()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mfdfr.v1.MatrixFlowDomainFragmentType)get_store().add_element_user(MFDFR$0);
            return target;
        }
    }
}
