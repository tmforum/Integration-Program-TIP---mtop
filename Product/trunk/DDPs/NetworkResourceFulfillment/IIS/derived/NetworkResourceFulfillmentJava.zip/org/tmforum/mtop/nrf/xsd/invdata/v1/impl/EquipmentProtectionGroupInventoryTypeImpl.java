/*
 * XML Type:  EquipmentProtectionGroupInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML EquipmentProtectionGroupInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class EquipmentProtectionGroupInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType
{
    
    public EquipmentProtectionGroupInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EPGNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "epgNm");
    private static final javax.xml.namespace.QName EPGATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "epgAttrs");
    private static final javax.xml.namespace.QName PROTECTEDEQUIPMENTREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "protectedEquipmentRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "epgNm" element
     */
    public java.lang.String getEpgNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EPGNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "epgNm" element
     */
    public org.apache.xmlbeans.XmlString xgetEpgNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EPGNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "epgNm" element
     */
    public boolean isSetEpgNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGNM$0) != 0;
        }
    }
    
    /**
     * Sets the "epgNm" element
     */
    public void setEpgNm(java.lang.String epgNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EPGNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EPGNM$0);
            }
            target.setStringValue(epgNm);
        }
    }
    
    /**
     * Sets (as xml) the "epgNm" element
     */
    public void xsetEpgNm(org.apache.xmlbeans.XmlString epgNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EPGNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EPGNM$0);
            }
            target.set(epgNm);
        }
    }
    
    /**
     * Unsets the "epgNm" element
     */
    public void unsetEpgNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGNM$0, 0);
        }
    }
    
    /**
     * Gets the "epgAttrs" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType getEpgAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().find_element_user(EPGATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "epgAttrs" element
     */
    public boolean isSetEpgAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "epgAttrs" element
     */
    public void setEpgAttrs(org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType epgAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().find_element_user(EPGATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().add_element_user(EPGATTRS$2);
            }
            target.set(epgAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "epgAttrs" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType addNewEpgAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().add_element_user(EPGATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "epgAttrs" element
     */
    public void unsetEpgAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "protectedEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTEDEQUIPMENTREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "protectedEquipmentRefList" element
     */
    public boolean isSetProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTEDEQUIPMENTREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "protectedEquipmentRefList" element
     */
    public void setProtectedEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType protectedEquipmentRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTEDEQUIPMENTREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTEDEQUIPMENTREFLIST$4);
            }
            target.set(protectedEquipmentRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "protectedEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTEDEQUIPMENTREFLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "protectedEquipmentRefList" element
     */
    public void unsetProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTEDEQUIPMENTREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$6) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$6, 0);
        }
    }
}
