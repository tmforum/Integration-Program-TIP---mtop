/*
 * XML Type:  ManagedElementType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/me/v1
 * Java type: org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.me.v1;


/**
 * An XML ManagedElementType(@http://www.tmforum.org/mtop/nrf/xsd/me/v1).
 *
 * This is a complex type.
 */
public interface ManagedElementType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ManagedElementType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("managedelementtypee852type");
    
    /**
     * Gets the "location" element
     */
    java.lang.String getLocation();
    
    /**
     * Gets (as xml) the "location" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.LocationType xgetLocation();
    
    /**
     * Tests for nil "location" element
     */
    boolean isNilLocation();
    
    /**
     * True if has "location" element
     */
    boolean isSetLocation();
    
    /**
     * Sets the "location" element
     */
    void setLocation(java.lang.String location);
    
    /**
     * Sets (as xml) the "location" element
     */
    void xsetLocation(org.tmforum.mtop.fmw.xsd.gen.v1.LocationType location);
    
    /**
     * Nils the "location" element
     */
    void setNilLocation();
    
    /**
     * Unsets the "location" element
     */
    void unsetLocation();
    
    /**
     * Gets the "manufacturer" element
     */
    java.lang.String getManufacturer();
    
    /**
     * Gets (as xml) the "manufacturer" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType xgetManufacturer();
    
    /**
     * Tests for nil "manufacturer" element
     */
    boolean isNilManufacturer();
    
    /**
     * True if has "manufacturer" element
     */
    boolean isSetManufacturer();
    
    /**
     * Sets the "manufacturer" element
     */
    void setManufacturer(java.lang.String manufacturer);
    
    /**
     * Sets (as xml) the "manufacturer" element
     */
    void xsetManufacturer(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType manufacturer);
    
    /**
     * Nils the "manufacturer" element
     */
    void setNilManufacturer();
    
    /**
     * Unsets the "manufacturer" element
     */
    void unsetManufacturer();
    
    /**
     * Gets the "manufactureDate" element
     */
    java.util.Calendar getManufactureDate();
    
    /**
     * Gets (as xml) the "manufactureDate" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType xgetManufactureDate();
    
    /**
     * Tests for nil "manufactureDate" element
     */
    boolean isNilManufactureDate();
    
    /**
     * True if has "manufactureDate" element
     */
    boolean isSetManufactureDate();
    
    /**
     * Sets the "manufactureDate" element
     */
    void setManufactureDate(java.util.Calendar manufactureDate);
    
    /**
     * Sets (as xml) the "manufactureDate" element
     */
    void xsetManufactureDate(org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType manufactureDate);
    
    /**
     * Nils the "manufactureDate" element
     */
    void setNilManufactureDate();
    
    /**
     * Unsets the "manufactureDate" element
     */
    void unsetManufactureDate();
    
    /**
     * Gets the "productName" element
     */
    java.lang.String getProductName();
    
    /**
     * Gets (as xml) the "productName" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType xgetProductName();
    
    /**
     * Tests for nil "productName" element
     */
    boolean isNilProductName();
    
    /**
     * True if has "productName" element
     */
    boolean isSetProductName();
    
    /**
     * Sets the "productName" element
     */
    void setProductName(java.lang.String productName);
    
    /**
     * Sets (as xml) the "productName" element
     */
    void xsetProductName(org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType productName);
    
    /**
     * Nils the "productName" element
     */
    void setNilProductName();
    
    /**
     * Unsets the "productName" element
     */
    void unsetProductName();
    
    /**
     * Gets the "softwareVersion" element
     */
    java.lang.String getSoftwareVersion();
    
    /**
     * Gets (as xml) the "softwareVersion" element
     */
    org.tmforum.mtop.nrf.xsd.me.v1.VersionType xgetSoftwareVersion();
    
    /**
     * Tests for nil "softwareVersion" element
     */
    boolean isNilSoftwareVersion();
    
    /**
     * True if has "softwareVersion" element
     */
    boolean isSetSoftwareVersion();
    
    /**
     * Sets the "softwareVersion" element
     */
    void setSoftwareVersion(java.lang.String softwareVersion);
    
    /**
     * Sets (as xml) the "softwareVersion" element
     */
    void xsetSoftwareVersion(org.tmforum.mtop.nrf.xsd.me.v1.VersionType softwareVersion);
    
    /**
     * Nils the "softwareVersion" element
     */
    void setNilSoftwareVersion();
    
    /**
     * Unsets the "softwareVersion" element
     */
    void unsetSoftwareVersion();
    
    /**
     * Gets the "isInSyncState" element
     */
    boolean getIsInSyncState();
    
    /**
     * Gets (as xml) the "isInSyncState" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsInSyncState();
    
    /**
     * Tests for nil "isInSyncState" element
     */
    boolean isNilIsInSyncState();
    
    /**
     * True if has "isInSyncState" element
     */
    boolean isSetIsInSyncState();
    
    /**
     * Sets the "isInSyncState" element
     */
    void setIsInSyncState(boolean isInSyncState);
    
    /**
     * Sets (as xml) the "isInSyncState" element
     */
    void xsetIsInSyncState(org.apache.xmlbeans.XmlBoolean isInSyncState);
    
    /**
     * Nils the "isInSyncState" element
     */
    void setNilIsInSyncState();
    
    /**
     * Unsets the "isInSyncState" element
     */
    void unsetIsInSyncState();
    
    /**
     * Gets the "supportedConnectionLayerRateList" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getSupportedConnectionLayerRateList();
    
    /**
     * Tests for nil "supportedConnectionLayerRateList" element
     */
    boolean isNilSupportedConnectionLayerRateList();
    
    /**
     * True if has "supportedConnectionLayerRateList" element
     */
    boolean isSetSupportedConnectionLayerRateList();
    
    /**
     * Sets the "supportedConnectionLayerRateList" element
     */
    void setSupportedConnectionLayerRateList(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType supportedConnectionLayerRateList);
    
    /**
     * Appends and returns a new empty "supportedConnectionLayerRateList" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewSupportedConnectionLayerRateList();
    
    /**
     * Nils the "supportedConnectionLayerRateList" element
     */
    void setNilSupportedConnectionLayerRateList();
    
    /**
     * Unsets the "supportedConnectionLayerRateList" element
     */
    void unsetSupportedConnectionLayerRateList();
    
    /**
     * Gets the "communicationState" element
     */
    org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType.Enum getCommunicationState();
    
    /**
     * Gets (as xml) the "communicationState" element
     */
    org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType xgetCommunicationState();
    
    /**
     * Tests for nil "communicationState" element
     */
    boolean isNilCommunicationState();
    
    /**
     * True if has "communicationState" element
     */
    boolean isSetCommunicationState();
    
    /**
     * Sets the "communicationState" element
     */
    void setCommunicationState(org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType.Enum communicationState);
    
    /**
     * Sets (as xml) the "communicationState" element
     */
    void xsetCommunicationState(org.tmforum.mtop.nrf.xsd.me.v1.CommunicationStateType communicationState);
    
    /**
     * Nils the "communicationState" element
     */
    void setNilCommunicationState();
    
    /**
     * Unsets the "communicationState" element
     */
    void unsetCommunicationState();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
