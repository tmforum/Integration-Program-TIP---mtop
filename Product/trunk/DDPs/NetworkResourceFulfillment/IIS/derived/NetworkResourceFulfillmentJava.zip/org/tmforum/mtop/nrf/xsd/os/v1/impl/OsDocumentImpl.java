/*
 * An XML document type.
 * Localname: os
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/os/v1
 * Java type: org.tmforum.mtop.nrf.xsd.os.v1.OsDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.os.v1.impl;
/**
 * A document containing one os(@http://www.tmforum.org/mtop/nrf/xsd/os/v1) element.
 *
 * This is a complex type.
 */
public class OsDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.os.v1.OsDocument
{
    
    public OsDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/os/v1", "os");
    
    
    /**
     * Gets the "os" element
     */
    public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType getOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().find_element_user(OS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "os" element
     */
    public void setOs(org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType os)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().find_element_user(OS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().add_element_user(OS$0);
            }
            target.set(os);
        }
    }
    
    /**
     * Appends and returns a new empty "os" element
     */
    public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType addNewOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().add_element_user(OS$0);
            return target;
        }
    }
}
