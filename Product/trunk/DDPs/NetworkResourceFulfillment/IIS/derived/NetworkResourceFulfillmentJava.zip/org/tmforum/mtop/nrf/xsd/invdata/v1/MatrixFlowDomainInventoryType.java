/*
 * XML Type:  MatrixFlowDomainInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML MatrixFlowDomainInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface MatrixFlowDomainInventoryType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MatrixFlowDomainInventoryType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("matrixflowdomaininventorytypef4d5type");
    
    /**
     * Gets the "mfdNm" element
     */
    java.lang.String getMfdNm();
    
    /**
     * Gets (as xml) the "mfdNm" element
     */
    org.apache.xmlbeans.XmlString xgetMfdNm();
    
    /**
     * True if has "mfdNm" element
     */
    boolean isSetMfdNm();
    
    /**
     * Sets the "mfdNm" element
     */
    void setMfdNm(java.lang.String mfdNm);
    
    /**
     * Sets (as xml) the "mfdNm" element
     */
    void xsetMfdNm(org.apache.xmlbeans.XmlString mfdNm);
    
    /**
     * Unsets the "mfdNm" element
     */
    void unsetMfdNm();
    
    /**
     * Gets the "mfdAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType getMfdAttrs();
    
    /**
     * True if has "mfdAttrs" element
     */
    boolean isSetMfdAttrs();
    
    /**
     * Sets the "mfdAttrs" element
     */
    void setMfdAttrs(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType mfdAttrs);
    
    /**
     * Appends and returns a new empty "mfdAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType addNewMfdAttrs();
    
    /**
     * Unsets the "mfdAttrs" element
     */
    void unsetMfdAttrs();
    
    /**
     * Gets the "mfdfrInvList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList getMfdfrInvList();
    
    /**
     * True if has "mfdfrInvList" element
     */
    boolean isSetMfdfrInvList();
    
    /**
     * Sets the "mfdfrInvList" element
     */
    void setMfdfrInvList(org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList mfdfrInvList);
    
    /**
     * Appends and returns a new empty "mfdfrInvList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList addNewMfdfrInvList();
    
    /**
     * Unsets the "mfdfrInvList" element
     */
    void unsetMfdfrInvList();
    
    /**
     * Gets the "ptpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getPtpRefList();
    
    /**
     * True if has "ptpRefList" element
     */
    boolean isSetPtpRefList();
    
    /**
     * Sets the "ptpRefList" element
     */
    void setPtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ptpRefList);
    
    /**
     * Appends and returns a new empty "ptpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewPtpRefList();
    
    /**
     * Unsets the "ptpRefList" element
     */
    void unsetPtpRefList();
    
    /**
     * Gets the "ftpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getFtpRefList();
    
    /**
     * True if has "ftpRefList" element
     */
    boolean isSetFtpRefList();
    
    /**
     * Sets the "ftpRefList" element
     */
    void setFtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ftpRefList);
    
    /**
     * Appends and returns a new empty "ftpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewFtpRefList();
    
    /**
     * Unsets the "ftpRefList" element
     */
    void unsetFtpRefList();
    
    /**
     * Gets the "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator();
    
    /**
     * True if has "qualityIndicator" element
     */
    boolean isSetQualityIndicator();
    
    /**
     * Sets the "qualityIndicator" element
     */
    void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator);
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator();
    
    /**
     * Unsets the "qualityIndicator" element
     */
    void unsetQualityIndicator();
    
    /**
     * An XML mfdfrInvList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface MfdfrInvList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MfdfrInvList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("mfdfrinvlist7181elemtype");
        
        /**
         * Gets a List of "mfdfrInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType> getMfdfrInvList();
        
        /**
         * Gets array of all "mfdfrInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType[] getMfdfrInvArray();
        
        /**
         * Gets ith "mfdfrInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType getMfdfrInvArray(int i);
        
        /**
         * Returns number of "mfdfrInv" element
         */
        int sizeOfMfdfrInvArray();
        
        /**
         * Sets array of all "mfdfrInv" element
         */
        void setMfdfrInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType[] mfdfrInvArray);
        
        /**
         * Sets ith "mfdfrInv" element
         */
        void setMfdfrInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType mfdfrInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "mfdfrInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType insertNewMfdfrInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "mfdfrInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainFragmentInventoryType addNewMfdfrInv();
        
        /**
         * Removes the ith "mfdfrInv" element
         */
        void removeMfdfrInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType.MfdfrInvList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
