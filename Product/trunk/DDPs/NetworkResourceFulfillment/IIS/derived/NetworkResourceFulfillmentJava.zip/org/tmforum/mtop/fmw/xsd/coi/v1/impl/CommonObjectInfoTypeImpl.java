/*
 * XML Type:  CommonObjectInfoType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coi/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coi.v1.impl;
/**
 * An XML CommonObjectInfoType(@http://www.tmforum.org/mtop/fmw/xsd/coi/v1).
 *
 * This is a complex type.
 */
public class CommonObjectInfoTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType
{
    
    public CommonObjectInfoTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coi/v1", "name");
    private static final javax.xml.namespace.QName USERLABEL$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coi/v1", "userLabel");
    private static final javax.xml.namespace.QName DISCOVEREDNAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coi/v1", "discoveredName");
    private static final javax.xml.namespace.QName NAMINGOS$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coi/v1", "namingOs");
    private static final javax.xml.namespace.QName OWNER$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coi/v1", "owner");
    private static final javax.xml.namespace.QName ALIASNAMELIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coi/v1", "aliasNameList");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coi/v1", "vendorExtensions");
    
    
    /**
     * Gets the "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "name" element
     */
    public boolean isNilName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "name" element
     */
    public boolean isSetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NAME$0) != 0;
        }
    }
    
    /**
     * Sets the "name" element
     */
    public void setName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            }
            target.set(name);
        }
    }
    
    /**
     * Appends and returns a new empty "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            return target;
        }
    }
    
    /**
     * Nils the "name" element
     */
    public void setNilName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "name" element
     */
    public void unsetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NAME$0, 0);
        }
    }
    
    /**
     * Gets the "userLabel" element
     */
    public java.lang.String getUserLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "userLabel" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType xgetUserLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "userLabel" element
     */
    public boolean isNilUserLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "userLabel" element
     */
    public boolean isSetUserLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(USERLABEL$2) != 0;
        }
    }
    
    /**
     * Sets the "userLabel" element
     */
    public void setUserLabel(java.lang.String userLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERLABEL$2);
            }
            target.setStringValue(userLabel);
        }
    }
    
    /**
     * Sets (as xml) the "userLabel" element
     */
    public void xsetUserLabel(org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType userLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().add_element_user(USERLABEL$2);
            }
            target.set(userLabel);
        }
    }
    
    /**
     * Nils the "userLabel" element
     */
    public void setNilUserLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().add_element_user(USERLABEL$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "userLabel" element
     */
    public void unsetUserLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(USERLABEL$2, 0);
        }
    }
    
    /**
     * Gets the "discoveredName" element
     */
    public java.lang.String getDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCOVEREDNAME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "discoveredName" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType xgetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().find_element_user(DISCOVEREDNAME$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "discoveredName" element
     */
    public boolean isSetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DISCOVEREDNAME$4) != 0;
        }
    }
    
    /**
     * Sets the "discoveredName" element
     */
    public void setDiscoveredName(java.lang.String discoveredName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCOVEREDNAME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DISCOVEREDNAME$4);
            }
            target.setStringValue(discoveredName);
        }
    }
    
    /**
     * Sets (as xml) the "discoveredName" element
     */
    public void xsetDiscoveredName(org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType discoveredName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().find_element_user(DISCOVEREDNAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().add_element_user(DISCOVEREDNAME$4);
            }
            target.set(discoveredName);
        }
    }
    
    /**
     * Unsets the "discoveredName" element
     */
    public void unsetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DISCOVEREDNAME$4, 0);
        }
    }
    
    /**
     * Gets the "namingOs" element
     */
    public java.lang.String getNamingOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NAMINGOS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "namingOs" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType xgetNamingOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType)get_store().find_element_user(NAMINGOS$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "namingOs" element
     */
    public boolean isNilNamingOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType)get_store().find_element_user(NAMINGOS$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "namingOs" element
     */
    public boolean isSetNamingOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NAMINGOS$6) != 0;
        }
    }
    
    /**
     * Sets the "namingOs" element
     */
    public void setNamingOs(java.lang.String namingOs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NAMINGOS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NAMINGOS$6);
            }
            target.setStringValue(namingOs);
        }
    }
    
    /**
     * Sets (as xml) the "namingOs" element
     */
    public void xsetNamingOs(org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType namingOs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType)get_store().find_element_user(NAMINGOS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType)get_store().add_element_user(NAMINGOS$6);
            }
            target.set(namingOs);
        }
    }
    
    /**
     * Nils the "namingOs" element
     */
    public void setNilNamingOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType)get_store().find_element_user(NAMINGOS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NamingOperationsSystemType)get_store().add_element_user(NAMINGOS$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "namingOs" element
     */
    public void unsetNamingOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NAMINGOS$6, 0);
        }
    }
    
    /**
     * Gets the "owner" element
     */
    public java.lang.String getOwner()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OWNER$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "owner" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType xgetOwner()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().find_element_user(OWNER$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "owner" element
     */
    public boolean isNilOwner()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().find_element_user(OWNER$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "owner" element
     */
    public boolean isSetOwner()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OWNER$8) != 0;
        }
    }
    
    /**
     * Sets the "owner" element
     */
    public void setOwner(java.lang.String owner)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OWNER$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OWNER$8);
            }
            target.setStringValue(owner);
        }
    }
    
    /**
     * Sets (as xml) the "owner" element
     */
    public void xsetOwner(org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType owner)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().find_element_user(OWNER$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().add_element_user(OWNER$8);
            }
            target.set(owner);
        }
    }
    
    /**
     * Nils the "owner" element
     */
    public void setNilOwner()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().find_element_user(OWNER$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().add_element_user(OWNER$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "owner" element
     */
    public void unsetOwner()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OWNER$8, 0);
        }
    }
    
    /**
     * Gets the "aliasNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "aliasNameList" element
     */
    public boolean isNilAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "aliasNameList" element
     */
    public boolean isSetAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALIASNAMELIST$10) != 0;
        }
    }
    
    /**
     * Sets the "aliasNameList" element
     */
    public void setAliasNameList(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNameList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$10);
            }
            target.set(aliasNameList);
        }
    }
    
    /**
     * Appends and returns a new empty "aliasNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$10);
            return target;
        }
    }
    
    /**
     * Nils the "aliasNameList" element
     */
    public void setNilAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "aliasNameList" element
     */
    public void unsetAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALIASNAMELIST$10, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "vendorExtensions" element
     */
    public boolean isNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$12) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$12);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$12);
            return target;
        }
    }
    
    /**
     * Nils the "vendorExtensions" element
     */
    public void setNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$12, 0);
        }
    }
}
