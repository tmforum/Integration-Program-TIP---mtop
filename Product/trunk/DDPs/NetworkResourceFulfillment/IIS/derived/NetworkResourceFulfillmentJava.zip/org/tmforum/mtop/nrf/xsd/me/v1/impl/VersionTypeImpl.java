/*
 * XML Type:  VersionType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/me/v1
 * Java type: org.tmforum.mtop.nrf.xsd.me.v1.VersionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.me.v1.impl;
/**
 * An XML VersionType(@http://www.tmforum.org/mtop/nrf/xsd/me/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrf.xsd.me.v1.VersionType.
 */
public class VersionTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.nrf.xsd.me.v1.VersionType
{
    
    public VersionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected VersionTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
