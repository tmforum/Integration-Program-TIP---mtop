/*
 * XML Type:  FlowDomainInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML FlowDomainInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface FlowDomainInventoryType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FlowDomainInventoryType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("flowdomaininventorytype4874type");
    
    /**
     * Gets the "fdNm" element
     */
    java.lang.String getFdNm();
    
    /**
     * Gets (as xml) the "fdNm" element
     */
    org.apache.xmlbeans.XmlString xgetFdNm();
    
    /**
     * True if has "fdNm" element
     */
    boolean isSetFdNm();
    
    /**
     * Sets the "fdNm" element
     */
    void setFdNm(java.lang.String fdNm);
    
    /**
     * Sets (as xml) the "fdNm" element
     */
    void xsetFdNm(org.apache.xmlbeans.XmlString fdNm);
    
    /**
     * Unsets the "fdNm" element
     */
    void unsetFdNm();
    
    /**
     * Gets the "fdAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType getFdAttrs();
    
    /**
     * True if has "fdAttrs" element
     */
    boolean isSetFdAttrs();
    
    /**
     * Sets the "fdAttrs" element
     */
    void setFdAttrs(org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType fdAttrs);
    
    /**
     * Appends and returns a new empty "fdAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType addNewFdAttrs();
    
    /**
     * Unsets the "fdAttrs" element
     */
    void unsetFdAttrs();
    
    /**
     * Gets the "fdfrInvList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList getFdfrInvList();
    
    /**
     * True if has "fdfrInvList" element
     */
    boolean isSetFdfrInvList();
    
    /**
     * Sets the "fdfrInvList" element
     */
    void setFdfrInvList(org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList fdfrInvList);
    
    /**
     * Appends and returns a new empty "fdfrInvList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList addNewFdfrInvList();
    
    /**
     * Unsets the "fdfrInvList" element
     */
    void unsetFdfrInvList();
    
    /**
     * Gets the "ptpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getPtpRefList();
    
    /**
     * True if has "ptpRefList" element
     */
    boolean isSetPtpRefList();
    
    /**
     * Sets the "ptpRefList" element
     */
    void setPtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ptpRefList);
    
    /**
     * Appends and returns a new empty "ptpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewPtpRefList();
    
    /**
     * Unsets the "ptpRefList" element
     */
    void unsetPtpRefList();
    
    /**
     * Gets the "ftpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getFtpRefList();
    
    /**
     * True if has "ftpRefList" element
     */
    boolean isSetFtpRefList();
    
    /**
     * Sets the "ftpRefList" element
     */
    void setFtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ftpRefList);
    
    /**
     * Appends and returns a new empty "ftpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewFtpRefList();
    
    /**
     * Unsets the "ftpRefList" element
     */
    void unsetFtpRefList();
    
    /**
     * Gets the "internalTlRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getInternalTlRefList();
    
    /**
     * True if has "internalTlRefList" element
     */
    boolean isSetInternalTlRefList();
    
    /**
     * Sets the "internalTlRefList" element
     */
    void setInternalTlRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType internalTlRefList);
    
    /**
     * Appends and returns a new empty "internalTlRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewInternalTlRefList();
    
    /**
     * Unsets the "internalTlRefList" element
     */
    void unsetInternalTlRefList();
    
    /**
     * Gets the "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator();
    
    /**
     * True if has "qualityIndicator" element
     */
    boolean isSetQualityIndicator();
    
    /**
     * Sets the "qualityIndicator" element
     */
    void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator);
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator();
    
    /**
     * Unsets the "qualityIndicator" element
     */
    void unsetQualityIndicator();
    
    /**
     * An XML fdfrInvList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface FdfrInvList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FdfrInvList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("fdfrinvlist9c63elemtype");
        
        /**
         * Gets a List of "fdfrInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType> getFdfrInvList();
        
        /**
         * Gets array of all "fdfrInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType[] getFdfrInvArray();
        
        /**
         * Gets ith "fdfrInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType getFdfrInvArray(int i);
        
        /**
         * Returns number of "fdfrInv" element
         */
        int sizeOfFdfrInvArray();
        
        /**
         * Sets array of all "fdfrInv" element
         */
        void setFdfrInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType[] fdfrInvArray);
        
        /**
         * Sets ith "fdfrInv" element
         */
        void setFdfrInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType fdfrInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "fdfrInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType insertNewFdfrInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "fdfrInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType addNewFdfrInv();
        
        /**
         * Removes the ith "fdfrInv" element
         */
        void removeFdfrInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
