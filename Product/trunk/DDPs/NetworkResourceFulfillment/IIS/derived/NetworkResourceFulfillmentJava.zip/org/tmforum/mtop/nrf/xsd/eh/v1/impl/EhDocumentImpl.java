/*
 * An XML document type.
 * Localname: eh
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/eh/v1
 * Java type: org.tmforum.mtop.nrf.xsd.eh.v1.EhDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.eh.v1.impl;
/**
 * A document containing one eh(@http://www.tmforum.org/mtop/nrf/xsd/eh/v1) element.
 *
 * This is a complex type.
 */
public class EhDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.eh.v1.EhDocument
{
    
    public EhDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EH$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "eh");
    
    
    /**
     * Gets the "eh" element
     */
    public org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType getEh()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().find_element_user(EH$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "eh" element
     */
    public void setEh(org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType eh)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().find_element_user(EH$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().add_element_user(EH$0);
            }
            target.set(eh);
        }
    }
    
    /**
     * Appends and returns a new empty "eh" element
     */
    public org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType addNewEh()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().add_element_user(EH$0);
            return target;
        }
    }
}
