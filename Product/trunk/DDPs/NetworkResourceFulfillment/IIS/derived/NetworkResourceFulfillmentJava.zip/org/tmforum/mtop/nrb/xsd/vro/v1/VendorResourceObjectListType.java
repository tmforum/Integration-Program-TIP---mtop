/*
 * XML Type:  VendorResourceObjectListType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/vro/v1
 * Java type: org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.vro.v1;


/**
 * An XML VendorResourceObjectListType(@http://www.tmforum.org/mtop/nrb/xsd/vro/v1).
 *
 * This is a complex type.
 */
public interface VendorResourceObjectListType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(VendorResourceObjectListType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("vendorresourceobjectlisttypeb5a5type");
    
    /**
     * Gets a List of "vendorResourceObject" elements
     */
    java.util.List<org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType> getVendorResourceObjectList();
    
    /**
     * Gets array of all "vendorResourceObject" elements
     * @deprecated
     */
    org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType[] getVendorResourceObjectArray();
    
    /**
     * Gets ith "vendorResourceObject" element
     */
    org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType getVendorResourceObjectArray(int i);
    
    /**
     * Returns number of "vendorResourceObject" element
     */
    int sizeOfVendorResourceObjectArray();
    
    /**
     * Sets array of all "vendorResourceObject" element
     */
    void setVendorResourceObjectArray(org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType[] vendorResourceObjectArray);
    
    /**
     * Sets ith "vendorResourceObject" element
     */
    void setVendorResourceObjectArray(int i, org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType vendorResourceObject);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "vendorResourceObject" element
     */
    org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType insertNewVendorResourceObject(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "vendorResourceObject" element
     */
    org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType addNewVendorResourceObject();
    
    /**
     * Removes the ith "vendorResourceObject" element
     */
    void removeVendorResourceObject(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType newInstance() {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
