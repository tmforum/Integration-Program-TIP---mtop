/*
 * XML Type:  EquipmentOrHolderListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/eq-inv/v1
 * Java type: org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.eqInv.v1.impl;
/**
 * An XML EquipmentOrHolderListType(@http://www.tmforum.org/mtop/nrf/xsd/eq-inv/v1).
 *
 * This is a complex type.
 */
public class EquipmentOrHolderListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType
{
    
    public EquipmentOrHolderListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EOH$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq-inv/v1", "eoh");
    
    
    /**
     * Gets a List of "eoh" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType> getEohList()
    {
        final class EohList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType>
        {
            public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType get(int i)
                { return EquipmentOrHolderListTypeImpl.this.getEohArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType set(int i, org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType o)
            {
                org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType old = EquipmentOrHolderListTypeImpl.this.getEohArray(i);
                EquipmentOrHolderListTypeImpl.this.setEohArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType o)
                { EquipmentOrHolderListTypeImpl.this.insertNewEoh(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType old = EquipmentOrHolderListTypeImpl.this.getEohArray(i);
                EquipmentOrHolderListTypeImpl.this.removeEoh(i);
                return old;
            }
            
            public int size()
                { return EquipmentOrHolderListTypeImpl.this.sizeOfEohArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new EohList();
        }
    }
    
    /**
     * Gets array of all "eoh" elements
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType[] getEohArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EOH$0, targetList);
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType[] result = new org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "eoh" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType getEohArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType)get_store().find_element_user(EOH$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "eoh" element
     */
    public int sizeOfEohArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EOH$0);
        }
    }
    
    /**
     * Sets array of all "eoh" element
     */
    public void setEohArray(org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType[] eohArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(eohArray, EOH$0);
        }
    }
    
    /**
     * Sets ith "eoh" element
     */
    public void setEohArray(int i, org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType eoh)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType)get_store().find_element_user(EOH$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(eoh);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "eoh" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType insertNewEoh(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType)get_store().insert_element_user(EOH$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "eoh" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType addNewEoh()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType)get_store().add_element_user(EOH$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "eoh" element
     */
    public void removeEoh(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EOH$0, i);
        }
    }
}
