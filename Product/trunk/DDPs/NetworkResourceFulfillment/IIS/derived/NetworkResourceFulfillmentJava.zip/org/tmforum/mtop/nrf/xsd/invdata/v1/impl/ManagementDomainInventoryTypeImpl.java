/*
 * XML Type:  ManagementDomainInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML ManagementDomainInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class ManagementDomainInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType
{
    
    public ManagementDomainInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MDNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mdNm");
    private static final javax.xml.namespace.QName MDATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mdAttrs");
    private static final javax.xml.namespace.QName SUPPORTINGOSREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "supportingOsRefList");
    private static final javax.xml.namespace.QName MELIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "meList");
    private static final javax.xml.namespace.QName MLSNLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mlsnList");
    private static final javax.xml.namespace.QName FDLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "fdList");
    private static final javax.xml.namespace.QName TLLIST$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tlList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "mdNm" element
     */
    public java.lang.String getMdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MDNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "mdNm" element
     */
    public org.apache.xmlbeans.XmlString xgetMdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MDNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "mdNm" element
     */
    public boolean isSetMdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MDNM$0) != 0;
        }
    }
    
    /**
     * Sets the "mdNm" element
     */
    public void setMdNm(java.lang.String mdNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MDNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MDNM$0);
            }
            target.setStringValue(mdNm);
        }
    }
    
    /**
     * Sets (as xml) the "mdNm" element
     */
    public void xsetMdNm(org.apache.xmlbeans.XmlString mdNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MDNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MDNM$0);
            }
            target.set(mdNm);
        }
    }
    
    /**
     * Unsets the "mdNm" element
     */
    public void unsetMdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MDNM$0, 0);
        }
    }
    
    /**
     * Gets the "mdAttrs" element
     */
    public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType getMdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType)get_store().find_element_user(MDATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mdAttrs" element
     */
    public boolean isSetMdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MDATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "mdAttrs" element
     */
    public void setMdAttrs(org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType mdAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType)get_store().find_element_user(MDATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType)get_store().add_element_user(MDATTRS$2);
            }
            target.set(mdAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "mdAttrs" element
     */
    public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType addNewMdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType)get_store().add_element_user(MDATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "mdAttrs" element
     */
    public void unsetMdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MDATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "supportingOsRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportingOsRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTINGOSREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "supportingOsRefList" element
     */
    public boolean isSetSupportingOsRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTINGOSREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "supportingOsRefList" element
     */
    public void setSupportingOsRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportingOsRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTINGOSREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTINGOSREFLIST$4);
            }
            target.set(supportingOsRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportingOsRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportingOsRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTINGOSREFLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "supportingOsRefList" element
     */
    public void unsetSupportingOsRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTINGOSREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "meList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList getMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList)get_store().find_element_user(MELIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "meList" element
     */
    public boolean isSetMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MELIST$6) != 0;
        }
    }
    
    /**
     * Sets the "meList" element
     */
    public void setMeList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList meList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList)get_store().find_element_user(MELIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList)get_store().add_element_user(MELIST$6);
            }
            target.set(meList);
        }
    }
    
    /**
     * Appends and returns a new empty "meList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList addNewMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList)get_store().add_element_user(MELIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "meList" element
     */
    public void unsetMeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MELIST$6, 0);
        }
    }
    
    /**
     * Gets the "mlsnList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList getMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList)get_store().find_element_user(MLSNLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mlsnList" element
     */
    public boolean isSetMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MLSNLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "mlsnList" element
     */
    public void setMlsnList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList mlsnList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList)get_store().find_element_user(MLSNLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList)get_store().add_element_user(MLSNLIST$8);
            }
            target.set(mlsnList);
        }
    }
    
    /**
     * Appends and returns a new empty "mlsnList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList addNewMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList)get_store().add_element_user(MLSNLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "mlsnList" element
     */
    public void unsetMlsnList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MLSNLIST$8, 0);
        }
    }
    
    /**
     * Gets the "fdList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList getFdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList)get_store().find_element_user(FDLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "fdList" element
     */
    public boolean isSetFdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "fdList" element
     */
    public void setFdList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList fdList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList)get_store().find_element_user(FDLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList)get_store().add_element_user(FDLIST$10);
            }
            target.set(fdList);
        }
    }
    
    /**
     * Appends and returns a new empty "fdList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList addNewFdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList)get_store().add_element_user(FDLIST$10);
            return target;
        }
    }
    
    /**
     * Unsets the "fdList" element
     */
    public void unsetFdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDLIST$10, 0);
        }
    }
    
    /**
     * Gets the "tlList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList getTlList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList)get_store().find_element_user(TLLIST$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tlList" element
     */
    public boolean isSetTlList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TLLIST$12) != 0;
        }
    }
    
    /**
     * Sets the "tlList" element
     */
    public void setTlList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList tlList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList)get_store().find_element_user(TLLIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList)get_store().add_element_user(TLLIST$12);
            }
            target.set(tlList);
        }
    }
    
    /**
     * Appends and returns a new empty "tlList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList addNewTlList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList)get_store().add_element_user(TLLIST$12);
            return target;
        }
    }
    
    /**
     * Unsets the "tlList" element
     */
    public void unsetTlList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TLLIST$12, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$14) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$14);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$14);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$14, 0);
        }
    }
    /**
     * An XML meList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class MeListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MeList
    {
        
        public MeListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MEINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "meInv");
        
        
        /**
         * Gets a List of "meInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType> getMeInvList()
        {
            final class MeInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType get(int i)
                    { return MeListImpl.this.getMeInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType old = MeListImpl.this.getMeInvArray(i);
                    MeListImpl.this.setMeInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType o)
                    { MeListImpl.this.insertNewMeInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType old = MeListImpl.this.getMeInvArray(i);
                    MeListImpl.this.removeMeInv(i);
                    return old;
                }
                
                public int size()
                    { return MeListImpl.this.sizeOfMeInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MeInvList();
            }
        }
        
        /**
         * Gets array of all "meInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType[] getMeInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MEINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "meInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType getMeInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType)get_store().find_element_user(MEINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "meInv" element
         */
        public int sizeOfMeInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MEINV$0);
            }
        }
        
        /**
         * Sets array of all "meInv" element
         */
        public void setMeInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType[] meInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(meInvArray, MEINV$0);
            }
        }
        
        /**
         * Sets ith "meInv" element
         */
        public void setMeInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType meInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType)get_store().find_element_user(MEINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(meInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "meInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType insertNewMeInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType)get_store().insert_element_user(MEINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "meInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType addNewMeInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType)get_store().add_element_user(MEINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "meInv" element
         */
        public void removeMeInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MEINV$0, i);
            }
        }
    }
    /**
     * An XML mlsnList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class MlsnListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.MlsnList
    {
        
        public MlsnListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MLSNINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mlsnInv");
        
        
        /**
         * Gets a List of "mlsnInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType> getMlsnInvList()
        {
            final class MlsnInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType get(int i)
                    { return MlsnListImpl.this.getMlsnInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType old = MlsnListImpl.this.getMlsnInvArray(i);
                    MlsnListImpl.this.setMlsnInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType o)
                    { MlsnListImpl.this.insertNewMlsnInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType old = MlsnListImpl.this.getMlsnInvArray(i);
                    MlsnListImpl.this.removeMlsnInv(i);
                    return old;
                }
                
                public int size()
                    { return MlsnListImpl.this.sizeOfMlsnInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MlsnInvList();
            }
        }
        
        /**
         * Gets array of all "mlsnInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType[] getMlsnInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MLSNINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "mlsnInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType getMlsnInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType)get_store().find_element_user(MLSNINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "mlsnInv" element
         */
        public int sizeOfMlsnInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MLSNINV$0);
            }
        }
        
        /**
         * Sets array of all "mlsnInv" element
         */
        public void setMlsnInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType[] mlsnInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(mlsnInvArray, MLSNINV$0);
            }
        }
        
        /**
         * Sets ith "mlsnInv" element
         */
        public void setMlsnInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType mlsnInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType)get_store().find_element_user(MLSNINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(mlsnInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "mlsnInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType insertNewMlsnInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType)get_store().insert_element_user(MLSNINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "mlsnInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType addNewMlsnInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType)get_store().add_element_user(MLSNINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "mlsnInv" element
         */
        public void removeMlsnInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MLSNINV$0, i);
            }
        }
    }
    /**
     * An XML fdList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class FdListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.FdList
    {
        
        public FdListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "fdInv");
        
        
        /**
         * Gets a List of "fdInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType> getFdInvList()
        {
            final class FdInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType get(int i)
                    { return FdListImpl.this.getFdInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType old = FdListImpl.this.getFdInvArray(i);
                    FdListImpl.this.setFdInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType o)
                    { FdListImpl.this.insertNewFdInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType old = FdListImpl.this.getFdInvArray(i);
                    FdListImpl.this.removeFdInv(i);
                    return old;
                }
                
                public int size()
                    { return FdListImpl.this.sizeOfFdInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new FdInvList();
            }
        }
        
        /**
         * Gets array of all "fdInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType[] getFdInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(FDINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "fdInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType getFdInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType)get_store().find_element_user(FDINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "fdInv" element
         */
        public int sizeOfFdInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDINV$0);
            }
        }
        
        /**
         * Sets array of all "fdInv" element
         */
        public void setFdInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType[] fdInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(fdInvArray, FDINV$0);
            }
        }
        
        /**
         * Sets ith "fdInv" element
         */
        public void setFdInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType fdInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType)get_store().find_element_user(FDINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(fdInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "fdInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType insertNewFdInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType)get_store().insert_element_user(FDINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "fdInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType addNewFdInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType)get_store().add_element_user(FDINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "fdInv" element
         */
        public void removeFdInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDINV$0, i);
            }
        }
    }
    /**
     * An XML tlList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class TlListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType.TlList
    {
        
        public TlListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TLINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tlInv");
        
        
        /**
         * Gets a List of "tlInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType> getTlInvList()
        {
            final class TlInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType get(int i)
                    { return TlListImpl.this.getTlInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType old = TlListImpl.this.getTlInvArray(i);
                    TlListImpl.this.setTlInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType o)
                    { TlListImpl.this.insertNewTlInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType old = TlListImpl.this.getTlInvArray(i);
                    TlListImpl.this.removeTlInv(i);
                    return old;
                }
                
                public int size()
                    { return TlListImpl.this.sizeOfTlInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new TlInvList();
            }
        }
        
        /**
         * Gets array of all "tlInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType[] getTlInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(TLINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "tlInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType getTlInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType)get_store().find_element_user(TLINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "tlInv" element
         */
        public int sizeOfTlInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TLINV$0);
            }
        }
        
        /**
         * Sets array of all "tlInv" element
         */
        public void setTlInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType[] tlInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(tlInvArray, TLINV$0);
            }
        }
        
        /**
         * Sets ith "tlInv" element
         */
        public void setTlInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType tlInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType)get_store().find_element_user(TLINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(tlInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "tlInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType insertNewTlInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType)get_store().insert_element_user(TLINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "tlInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType addNewTlInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType)get_store().add_element_user(TLINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "tlInv" element
         */
        public void removeTlInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TLINV$0, i);
            }
        }
    }
}
