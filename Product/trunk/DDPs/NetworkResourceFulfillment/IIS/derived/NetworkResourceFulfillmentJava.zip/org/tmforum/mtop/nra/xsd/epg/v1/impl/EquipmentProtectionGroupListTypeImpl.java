/*
 * XML Type:  EquipmentProtectionGroupListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/epg/v1
 * Java type: org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.epg.v1.impl;
/**
 * An XML EquipmentProtectionGroupListType(@http://www.tmforum.org/mtop/nra/xsd/epg/v1).
 *
 * This is a complex type.
 */
public class EquipmentProtectionGroupListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupListType
{
    
    public EquipmentProtectionGroupListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EPGP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "epgp");
    
    
    /**
     * Gets a List of "epgp" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType> getEpgpList()
    {
        final class EpgpList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType>
        {
            public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType get(int i)
                { return EquipmentProtectionGroupListTypeImpl.this.getEpgpArray(i); }
            
            public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType set(int i, org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType o)
            {
                org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType old = EquipmentProtectionGroupListTypeImpl.this.getEpgpArray(i);
                EquipmentProtectionGroupListTypeImpl.this.setEpgpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType o)
                { EquipmentProtectionGroupListTypeImpl.this.insertNewEpgp(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType old = EquipmentProtectionGroupListTypeImpl.this.getEpgpArray(i);
                EquipmentProtectionGroupListTypeImpl.this.removeEpgp(i);
                return old;
            }
            
            public int size()
                { return EquipmentProtectionGroupListTypeImpl.this.sizeOfEpgpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new EpgpList();
        }
    }
    
    /**
     * Gets array of all "epgp" elements
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType[] getEpgpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EPGP$0, targetList);
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType[] result = new org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "epgp" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType getEpgpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().find_element_user(EPGP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "epgp" element
     */
    public int sizeOfEpgpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGP$0);
        }
    }
    
    /**
     * Sets array of all "epgp" element
     */
    public void setEpgpArray(org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType[] epgpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(epgpArray, EPGP$0);
        }
    }
    
    /**
     * Sets ith "epgp" element
     */
    public void setEpgpArray(int i, org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType epgp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().find_element_user(EPGP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(epgp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "epgp" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType insertNewEpgp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().insert_element_user(EPGP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "epgp" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType addNewEpgp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().add_element_user(EPGP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "epgp" element
     */
    public void removeEpgp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGP$0, i);
        }
    }
}
