/*
 * An XML document type.
 * Localname: routeChange
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/routec/v1
 * Java type: org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.routec.v1.impl;
/**
 * A document containing one routeChange(@http://www.tmforum.org/mtop/nrf/xsd/routec/v1) element.
 *
 * This is a complex type.
 */
public class RouteChangeDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeDocument
{
    
    public RouteChangeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ROUTECHANGE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routec/v1", "routeChange");
    
    
    /**
     * Gets the "routeChange" element
     */
    public org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType getRouteChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType)get_store().find_element_user(ROUTECHANGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "routeChange" element
     */
    public void setRouteChange(org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType routeChange)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType)get_store().find_element_user(ROUTECHANGE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType)get_store().add_element_user(ROUTECHANGE$0);
            }
            target.set(routeChange);
        }
    }
    
    /**
     * Appends and returns a new empty "routeChange" element
     */
    public org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType addNewRouteChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType)get_store().add_element_user(ROUTECHANGE$0);
            return target;
        }
    }
}
