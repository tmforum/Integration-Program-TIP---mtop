/*
 * XML Type:  ConnectionTerminationPointInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML ConnectionTerminationPointInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class ConnectionTerminationPointInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ConnectionTerminationPointInventoryType
{
    
    public ConnectionTerminationPointInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CTPNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ctpNm");
    private static final javax.xml.namespace.QName CTPATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ctpAttrs");
    private static final javax.xml.namespace.QName SUPPORTEDFIXEDSNCREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "supportedFixedSncRefList");
    private static final javax.xml.namespace.QName ALLSUPPORTEDSNCREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "allSupportedSncRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "ctpNm" element
     */
    public java.lang.String getCtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CTPNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "ctpNm" element
     */
    public org.apache.xmlbeans.XmlString xgetCtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CTPNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "ctpNm" element
     */
    public boolean isSetCtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CTPNM$0) != 0;
        }
    }
    
    /**
     * Sets the "ctpNm" element
     */
    public void setCtpNm(java.lang.String ctpNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CTPNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CTPNM$0);
            }
            target.setStringValue(ctpNm);
        }
    }
    
    /**
     * Sets (as xml) the "ctpNm" element
     */
    public void xsetCtpNm(org.apache.xmlbeans.XmlString ctpNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CTPNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CTPNM$0);
            }
            target.set(ctpNm);
        }
    }
    
    /**
     * Unsets the "ctpNm" element
     */
    public void unsetCtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CTPNM$0, 0);
        }
    }
    
    /**
     * Gets the "ctpAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType getCtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().find_element_user(CTPATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ctpAttrs" element
     */
    public boolean isSetCtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CTPATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "ctpAttrs" element
     */
    public void setCtpAttrs(org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType ctpAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().find_element_user(CTPATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().add_element_user(CTPATTRS$2);
            }
            target.set(ctpAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "ctpAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType addNewCtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().add_element_user(CTPATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "ctpAttrs" element
     */
    public void unsetCtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CTPATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "supportedFixedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDFIXEDSNCREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "supportedFixedSncRefList" element
     */
    public boolean isSetSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTEDFIXEDSNCREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "supportedFixedSncRefList" element
     */
    public void setSupportedFixedSncRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportedFixedSncRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDFIXEDSNCREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDFIXEDSNCREFLIST$4);
            }
            target.set(supportedFixedSncRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportedFixedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDFIXEDSNCREFLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "supportedFixedSncRefList" element
     */
    public void unsetSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTEDFIXEDSNCREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "allSupportedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ALLSUPPORTEDSNCREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "allSupportedSncRefList" element
     */
    public boolean isSetAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALLSUPPORTEDSNCREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "allSupportedSncRefList" element
     */
    public void setAllSupportedSncRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType allSupportedSncRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ALLSUPPORTEDSNCREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ALLSUPPORTEDSNCREFLIST$6);
            }
            target.set(allSupportedSncRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "allSupportedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ALLSUPPORTEDSNCREFLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "allSupportedSncRefList" element
     */
    public void unsetAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALLSUPPORTEDSNCREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$8) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$8);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$8);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$8, 0);
        }
    }
}
