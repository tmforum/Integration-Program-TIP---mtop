/*
 * XML Type:  ExerciseOnType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pgp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pgp.v1.impl;
/**
 * An XML ExerciseOnType(@http://www.tmforum.org/mtop/nra/xsd/pgp/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType.
 */
public class ExerciseOnTypeImpl extends org.apache.xmlbeans.impl.values.JavaBooleanHolderEx implements org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType
{
    
    public ExerciseOnTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ExerciseOnTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
