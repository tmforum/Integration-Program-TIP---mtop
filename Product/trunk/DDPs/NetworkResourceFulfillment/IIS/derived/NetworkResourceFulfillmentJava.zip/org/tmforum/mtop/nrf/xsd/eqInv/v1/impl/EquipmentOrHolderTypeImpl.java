/*
 * XML Type:  EquipmentOrHolderType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/eq-inv/v1
 * Java type: org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.eqInv.v1.impl;
/**
 * An XML EquipmentOrHolderType(@http://www.tmforum.org/mtop/nrf/xsd/eq-inv/v1).
 *
 * This is a complex type.
 */
public class EquipmentOrHolderTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType
{
    
    public EquipmentOrHolderTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EQ$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eq/v1", "eq");
    private static final javax.xml.namespace.QName EH$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "eh");
    
    
    /**
     * Gets the "eq" element
     */
    public org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType getEq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().find_element_user(EQ$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "eq" element
     */
    public boolean isSetEq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQ$0) != 0;
        }
    }
    
    /**
     * Sets the "eq" element
     */
    public void setEq(org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType eq)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().find_element_user(EQ$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().add_element_user(EQ$0);
            }
            target.set(eq);
        }
    }
    
    /**
     * Appends and returns a new empty "eq" element
     */
    public org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType addNewEq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().add_element_user(EQ$0);
            return target;
        }
    }
    
    /**
     * Unsets the "eq" element
     */
    public void unsetEq()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQ$0, 0);
        }
    }
    
    /**
     * Gets the "eh" element
     */
    public org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType getEh()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().find_element_user(EH$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "eh" element
     */
    public boolean isSetEh()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EH$2) != 0;
        }
    }
    
    /**
     * Sets the "eh" element
     */
    public void setEh(org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType eh)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().find_element_user(EH$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().add_element_user(EH$2);
            }
            target.set(eh);
        }
    }
    
    /**
     * Appends and returns a new empty "eh" element
     */
    public org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType addNewEh()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType)get_store().add_element_user(EH$2);
            return target;
        }
    }
    
    /**
     * Unsets the "eh" element
     */
    public void unsetEh()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EH$2, 0);
        }
    }
}
