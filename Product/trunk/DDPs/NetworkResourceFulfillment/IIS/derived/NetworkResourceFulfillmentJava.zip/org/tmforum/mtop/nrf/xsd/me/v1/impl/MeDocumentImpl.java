/*
 * An XML document type.
 * Localname: me
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/me/v1
 * Java type: org.tmforum.mtop.nrf.xsd.me.v1.MeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.me.v1.impl;
/**
 * A document containing one me(@http://www.tmforum.org/mtop/nrf/xsd/me/v1) element.
 *
 * This is a complex type.
 */
public class MeDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.me.v1.MeDocument
{
    
    public MeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "me");
    
    
    /**
     * Gets the "me" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType getMe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().find_element_user(ME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "me" element
     */
    public void setMe(org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType me)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().find_element_user(ME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().add_element_user(ME$0);
            }
            target.set(me);
        }
    }
    
    /**
     * Appends and returns a new empty "me" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType addNewMe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().add_element_user(ME$0);
            return target;
        }
    }
}
