/*
 * XML Type:  FlowDomainFragmentInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML FlowDomainFragmentInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class FlowDomainFragmentInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType
{
    
    public FlowDomainFragmentInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FDFRNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "fdfrNm");
    private static final javax.xml.namespace.QName FDFRATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "fdfrAttrs");
    private static final javax.xml.namespace.QName ROUTE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "route");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "fdfrNm" element
     */
    public java.lang.String getFdfrNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FDFRNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "fdfrNm" element
     */
    public org.apache.xmlbeans.XmlString xgetFdfrNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FDFRNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "fdfrNm" element
     */
    public boolean isSetFdfrNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDFRNM$0) != 0;
        }
    }
    
    /**
     * Sets the "fdfrNm" element
     */
    public void setFdfrNm(java.lang.String fdfrNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FDFRNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FDFRNM$0);
            }
            target.setStringValue(fdfrNm);
        }
    }
    
    /**
     * Sets (as xml) the "fdfrNm" element
     */
    public void xsetFdfrNm(org.apache.xmlbeans.XmlString fdfrNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FDFRNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FDFRNM$0);
            }
            target.set(fdfrNm);
        }
    }
    
    /**
     * Unsets the "fdfrNm" element
     */
    public void unsetFdfrNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDFRNM$0, 0);
        }
    }
    
    /**
     * Gets the "fdfrAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType getFdfrAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().find_element_user(FDFRATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "fdfrAttrs" element
     */
    public boolean isSetFdfrAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDFRATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "fdfrAttrs" element
     */
    public void setFdfrAttrs(org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType fdfrAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().find_element_user(FDFRATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().add_element_user(FDFRATTRS$2);
            }
            target.set(fdfrAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "fdfrAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType addNewFdfrAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().add_element_user(FDFRATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "fdfrAttrs" element
     */
    public void unsetFdfrAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDFRATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "route" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType getRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().find_element_user(ROUTE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "route" element
     */
    public boolean isSetRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTE$4) != 0;
        }
    }
    
    /**
     * Sets the "route" element
     */
    public void setRoute(org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType route)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().find_element_user(ROUTE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().add_element_user(ROUTE$4);
            }
            target.set(route);
        }
    }
    
    /**
     * Appends and returns a new empty "route" element
     */
    public org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType addNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().add_element_user(ROUTE$4);
            return target;
        }
    }
    
    /**
     * Unsets the "route" element
     */
    public void unsetRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTE$4, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$6) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$6);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$6, 0);
        }
    }
}
