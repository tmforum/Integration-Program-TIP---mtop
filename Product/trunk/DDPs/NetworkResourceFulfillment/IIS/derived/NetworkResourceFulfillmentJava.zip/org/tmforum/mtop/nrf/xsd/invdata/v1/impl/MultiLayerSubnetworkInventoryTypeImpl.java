/*
 * XML Type:  MultiLayerSubnetworkInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML MultiLayerSubnetworkInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class MultiLayerSubnetworkInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType
{
    
    public MultiLayerSubnetworkInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MLSNNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mlsnNm");
    private static final javax.xml.namespace.QName MLSNATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mlsnAttrs");
    private static final javax.xml.namespace.QName SNCLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "sncList");
    private static final javax.xml.namespace.QName TPPOOLLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tpPoolList");
    private static final javax.xml.namespace.QName ASSOCIATEDMEREFLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "associatedMeRefList");
    private static final javax.xml.namespace.QName INTERNALTLREFLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "internalTlRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "mlsnNm" element
     */
    public java.lang.String getMlsnNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MLSNNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "mlsnNm" element
     */
    public org.apache.xmlbeans.XmlString xgetMlsnNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MLSNNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "mlsnNm" element
     */
    public boolean isSetMlsnNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MLSNNM$0) != 0;
        }
    }
    
    /**
     * Sets the "mlsnNm" element
     */
    public void setMlsnNm(java.lang.String mlsnNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MLSNNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MLSNNM$0);
            }
            target.setStringValue(mlsnNm);
        }
    }
    
    /**
     * Sets (as xml) the "mlsnNm" element
     */
    public void xsetMlsnNm(org.apache.xmlbeans.XmlString mlsnNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MLSNNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MLSNNM$0);
            }
            target.set(mlsnNm);
        }
    }
    
    /**
     * Unsets the "mlsnNm" element
     */
    public void unsetMlsnNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MLSNNM$0, 0);
        }
    }
    
    /**
     * Gets the "mlsnAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType getMlsnAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().find_element_user(MLSNATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mlsnAttrs" element
     */
    public boolean isSetMlsnAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MLSNATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "mlsnAttrs" element
     */
    public void setMlsnAttrs(org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType mlsnAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().find_element_user(MLSNATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().add_element_user(MLSNATTRS$2);
            }
            target.set(mlsnAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "mlsnAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType addNewMlsnAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType)get_store().add_element_user(MLSNATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "mlsnAttrs" element
     */
    public void unsetMlsnAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MLSNATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "sncList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList getSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList)get_store().find_element_user(SNCLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "sncList" element
     */
    public boolean isSetSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SNCLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "sncList" element
     */
    public void setSncList(org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList sncList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList)get_store().find_element_user(SNCLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList)get_store().add_element_user(SNCLIST$4);
            }
            target.set(sncList);
        }
    }
    
    /**
     * Appends and returns a new empty "sncList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList addNewSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList)get_store().add_element_user(SNCLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "sncList" element
     */
    public void unsetSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SNCLIST$4, 0);
        }
    }
    
    /**
     * Gets the "tpPoolList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList getTpPoolList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList)get_store().find_element_user(TPPOOLLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tpPoolList" element
     */
    public boolean isSetTpPoolList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPPOOLLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "tpPoolList" element
     */
    public void setTpPoolList(org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList tpPoolList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList)get_store().find_element_user(TPPOOLLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList)get_store().add_element_user(TPPOOLLIST$6);
            }
            target.set(tpPoolList);
        }
    }
    
    /**
     * Appends and returns a new empty "tpPoolList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList addNewTpPoolList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList)get_store().add_element_user(TPPOOLLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "tpPoolList" element
     */
    public void unsetTpPoolList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPPOOLLIST$6, 0);
        }
    }
    
    /**
     * Gets the "associatedMeRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAssociatedMeRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ASSOCIATEDMEREFLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "associatedMeRefList" element
     */
    public boolean isSetAssociatedMeRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASSOCIATEDMEREFLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "associatedMeRefList" element
     */
    public void setAssociatedMeRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType associatedMeRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ASSOCIATEDMEREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ASSOCIATEDMEREFLIST$8);
            }
            target.set(associatedMeRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "associatedMeRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAssociatedMeRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ASSOCIATEDMEREFLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "associatedMeRefList" element
     */
    public void unsetAssociatedMeRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASSOCIATEDMEREFLIST$8, 0);
        }
    }
    
    /**
     * Gets the "internalTlRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INTERNALTLREFLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "internalTlRefList" element
     */
    public boolean isSetInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTERNALTLREFLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "internalTlRefList" element
     */
    public void setInternalTlRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType internalTlRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INTERNALTLREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INTERNALTLREFLIST$10);
            }
            target.set(internalTlRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "internalTlRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INTERNALTLREFLIST$10);
            return target;
        }
    }
    
    /**
     * Unsets the "internalTlRefList" element
     */
    public void unsetInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTERNALTLREFLIST$10, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$12) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$12);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$12);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$12, 0);
        }
    }
    /**
     * An XML sncList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class SncListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList
    {
        
        public SncListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNCINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "sncInv");
        
        
        /**
         * Gets a List of "sncInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType> getSncInvList()
        {
            final class SncInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType get(int i)
                    { return SncListImpl.this.getSncInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType old = SncListImpl.this.getSncInvArray(i);
                    SncListImpl.this.setSncInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType o)
                    { SncListImpl.this.insertNewSncInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType old = SncListImpl.this.getSncInvArray(i);
                    SncListImpl.this.removeSncInv(i);
                    return old;
                }
                
                public int size()
                    { return SncListImpl.this.sizeOfSncInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new SncInvList();
            }
        }
        
        /**
         * Gets array of all "sncInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType[] getSncInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(SNCINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "sncInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType getSncInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType)get_store().find_element_user(SNCINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "sncInv" element
         */
        public int sizeOfSncInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNCINV$0);
            }
        }
        
        /**
         * Sets array of all "sncInv" element
         */
        public void setSncInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType[] sncInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(sncInvArray, SNCINV$0);
            }
        }
        
        /**
         * Sets ith "sncInv" element
         */
        public void setSncInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType sncInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType)get_store().find_element_user(SNCINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(sncInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "sncInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType insertNewSncInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType)get_store().insert_element_user(SNCINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "sncInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType addNewSncInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType)get_store().add_element_user(SNCINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "sncInv" element
         */
        public void removeSncInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNCINV$0, i);
            }
        }
    }
    /**
     * An XML tpPoolList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class TpPoolListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList
    {
        
        public TpPoolListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPPOOLINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tpPoolInv");
        
        
        /**
         * Gets a List of "tpPoolInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType> getTpPoolInvList()
        {
            final class TpPoolInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType get(int i)
                    { return TpPoolListImpl.this.getTpPoolInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType old = TpPoolListImpl.this.getTpPoolInvArray(i);
                    TpPoolListImpl.this.setTpPoolInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType o)
                    { TpPoolListImpl.this.insertNewTpPoolInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType old = TpPoolListImpl.this.getTpPoolInvArray(i);
                    TpPoolListImpl.this.removeTpPoolInv(i);
                    return old;
                }
                
                public int size()
                    { return TpPoolListImpl.this.sizeOfTpPoolInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new TpPoolInvList();
            }
        }
        
        /**
         * Gets array of all "tpPoolInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType[] getTpPoolInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(TPPOOLINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "tpPoolInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType getTpPoolInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType)get_store().find_element_user(TPPOOLINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "tpPoolInv" element
         */
        public int sizeOfTpPoolInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPPOOLINV$0);
            }
        }
        
        /**
         * Sets array of all "tpPoolInv" element
         */
        public void setTpPoolInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType[] tpPoolInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(tpPoolInvArray, TPPOOLINV$0);
            }
        }
        
        /**
         * Sets ith "tpPoolInv" element
         */
        public void setTpPoolInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType tpPoolInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType)get_store().find_element_user(TPPOOLINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(tpPoolInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "tpPoolInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType insertNewTpPoolInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType)get_store().insert_element_user(TPPOOLINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "tpPoolInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType addNewTpPoolInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType)get_store().add_element_user(TPPOOLINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "tpPoolInv" element
         */
        public void removeTpPoolInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPPOOLINV$0, i);
            }
        }
    }
}
