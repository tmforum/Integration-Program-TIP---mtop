/*
 * An XML document type.
 * Localname: gtp
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/gtp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.gtp.v1.GtpDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.gtp.v1.impl;
/**
 * A document containing one gtp(@http://www.tmforum.org/mtop/nrf/xsd/gtp/v1) element.
 *
 * This is a complex type.
 */
public class GtpDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.gtp.v1.GtpDocument
{
    
    public GtpDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/gtp/v1", "gtp");
    
    
    /**
     * Gets the "gtp" element
     */
    public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType getGtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().find_element_user(GTP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "gtp" element
     */
    public void setGtp(org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType gtp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().find_element_user(GTP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().add_element_user(GTP$0);
            }
            target.set(gtp);
        }
    }
    
    /**
     * Appends and returns a new empty "gtp" element
     */
    public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType addNewGtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().add_element_user(GTP$0);
            return target;
        }
    }
}
