/*
 * XML Type:  SwitchModeEnumType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pgp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pgp.v1.impl;
/**
 * An XML SwitchModeEnumType(@http://www.tmforum.org/mtop/nra/xsd/pgp/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeEnumType.
 */
public class SwitchModeEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeEnumType
{
    
    public SwitchModeEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected SwitchModeEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
