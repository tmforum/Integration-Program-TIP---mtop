/*
 * XML Type:  TopologicalLinkInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML TopologicalLinkInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class TopologicalLinkInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.TopologicalLinkInventoryType
{
    
    public TopologicalLinkInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TLNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tlNm");
    private static final javax.xml.namespace.QName TLATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tlAttrs");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "tlNm" element
     */
    public java.lang.String getTlNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TLNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "tlNm" element
     */
    public org.apache.xmlbeans.XmlString xgetTlNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TLNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "tlNm" element
     */
    public boolean isSetTlNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TLNM$0) != 0;
        }
    }
    
    /**
     * Sets the "tlNm" element
     */
    public void setTlNm(java.lang.String tlNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TLNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TLNM$0);
            }
            target.setStringValue(tlNm);
        }
    }
    
    /**
     * Sets (as xml) the "tlNm" element
     */
    public void xsetTlNm(org.apache.xmlbeans.XmlString tlNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TLNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TLNM$0);
            }
            target.set(tlNm);
        }
    }
    
    /**
     * Unsets the "tlNm" element
     */
    public void unsetTlNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TLNM$0, 0);
        }
    }
    
    /**
     * Gets the "tlAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType getTlAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().find_element_user(TLATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tlAttrs" element
     */
    public boolean isSetTlAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TLATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "tlAttrs" element
     */
    public void setTlAttrs(org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType tlAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().find_element_user(TLATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().add_element_user(TLATTRS$2);
            }
            target.set(tlAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "tlAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType addNewTlAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tl.v1.TopologicalLinkType)get_store().add_element_user(TLATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "tlAttrs" element
     */
    public void unsetTlAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TLATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$4) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$4);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$4);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$4, 0);
        }
    }
}
