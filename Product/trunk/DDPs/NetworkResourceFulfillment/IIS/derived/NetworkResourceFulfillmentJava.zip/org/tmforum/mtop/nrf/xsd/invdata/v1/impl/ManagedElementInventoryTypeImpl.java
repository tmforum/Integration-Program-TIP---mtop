/*
 * XML Type:  ManagedElementInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML ManagedElementInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class ManagedElementInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType
{
    
    public ManagedElementInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MENM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "meNm");
    private static final javax.xml.namespace.QName MEATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "meAttrs");
    private static final javax.xml.namespace.QName EHLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ehList");
    private static final javax.xml.namespace.QName PTPLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ptpList");
    private static final javax.xml.namespace.QName FTPLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ftpList");
    private static final javax.xml.namespace.QName CCLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ccList");
    private static final javax.xml.namespace.QName PGPLIST$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "pgpList");
    private static final javax.xml.namespace.QName EPGLIST$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "epgList");
    private static final javax.xml.namespace.QName GTPLIST$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "gtpList");
    private static final javax.xml.namespace.QName MFDLIST$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mfdList");
    private static final javax.xml.namespace.QName INTERNALTLREFLIST$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "internalTlRefList");
    private static final javax.xml.namespace.QName CONTAININGMLSNREFLIST$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "containingMlsnRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "meNm" element
     */
    public java.lang.String getMeNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "meNm" element
     */
    public org.apache.xmlbeans.XmlString xgetMeNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "meNm" element
     */
    public boolean isSetMeNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MENM$0) != 0;
        }
    }
    
    /**
     * Sets the "meNm" element
     */
    public void setMeNm(java.lang.String meNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MENM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MENM$0);
            }
            target.setStringValue(meNm);
        }
    }
    
    /**
     * Sets (as xml) the "meNm" element
     */
    public void xsetMeNm(org.apache.xmlbeans.XmlString meNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MENM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MENM$0);
            }
            target.set(meNm);
        }
    }
    
    /**
     * Unsets the "meNm" element
     */
    public void unsetMeNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MENM$0, 0);
        }
    }
    
    /**
     * Gets the "meAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType getMeAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().find_element_user(MEATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "meAttrs" element
     */
    public boolean isSetMeAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MEATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "meAttrs" element
     */
    public void setMeAttrs(org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType meAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().find_element_user(MEATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().add_element_user(MEATTRS$2);
            }
            target.set(meAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "meAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType addNewMeAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().add_element_user(MEATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "meAttrs" element
     */
    public void unsetMeAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MEATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "ehList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList getEhList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList)get_store().find_element_user(EHLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ehList" element
     */
    public boolean isSetEhList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EHLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "ehList" element
     */
    public void setEhList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList ehList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList)get_store().find_element_user(EHLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList)get_store().add_element_user(EHLIST$4);
            }
            target.set(ehList);
        }
    }
    
    /**
     * Appends and returns a new empty "ehList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList addNewEhList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList)get_store().add_element_user(EHLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ehList" element
     */
    public void unsetEhList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EHLIST$4, 0);
        }
    }
    
    /**
     * Gets the "ptpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList getPtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList)get_store().find_element_user(PTPLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ptpList" element
     */
    public boolean isSetPtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PTPLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "ptpList" element
     */
    public void setPtpList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList ptpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList)get_store().find_element_user(PTPLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList)get_store().add_element_user(PTPLIST$6);
            }
            target.set(ptpList);
        }
    }
    
    /**
     * Appends and returns a new empty "ptpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList addNewPtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList)get_store().add_element_user(PTPLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "ptpList" element
     */
    public void unsetPtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PTPLIST$6, 0);
        }
    }
    
    /**
     * Gets the "ftpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList getFtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList)get_store().find_element_user(FTPLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ftpList" element
     */
    public boolean isSetFtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FTPLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "ftpList" element
     */
    public void setFtpList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList ftpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList)get_store().find_element_user(FTPLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList)get_store().add_element_user(FTPLIST$8);
            }
            target.set(ftpList);
        }
    }
    
    /**
     * Appends and returns a new empty "ftpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList addNewFtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList)get_store().add_element_user(FTPLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "ftpList" element
     */
    public void unsetFtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FTPLIST$8, 0);
        }
    }
    
    /**
     * Gets the "ccList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType getCcList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ccList" element
     */
    public boolean isSetCcList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CCLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "ccList" element
     */
    public void setCcList(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType ccList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCLIST$10);
            }
            target.set(ccList);
        }
    }
    
    /**
     * Appends and returns a new empty "ccList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType addNewCcList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCLIST$10);
            return target;
        }
    }
    
    /**
     * Unsets the "ccList" element
     */
    public void unsetCcList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CCLIST$10, 0);
        }
    }
    
    /**
     * Gets the "pgpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList getPgpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList)get_store().find_element_user(PGPLIST$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "pgpList" element
     */
    public boolean isSetPgpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PGPLIST$12) != 0;
        }
    }
    
    /**
     * Sets the "pgpList" element
     */
    public void setPgpList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList pgpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList)get_store().find_element_user(PGPLIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList)get_store().add_element_user(PGPLIST$12);
            }
            target.set(pgpList);
        }
    }
    
    /**
     * Appends and returns a new empty "pgpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList addNewPgpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList)get_store().add_element_user(PGPLIST$12);
            return target;
        }
    }
    
    /**
     * Unsets the "pgpList" element
     */
    public void unsetPgpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PGPLIST$12, 0);
        }
    }
    
    /**
     * Gets the "epgList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList getEpgList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList)get_store().find_element_user(EPGLIST$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "epgList" element
     */
    public boolean isSetEpgList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGLIST$14) != 0;
        }
    }
    
    /**
     * Sets the "epgList" element
     */
    public void setEpgList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList epgList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList)get_store().find_element_user(EPGLIST$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList)get_store().add_element_user(EPGLIST$14);
            }
            target.set(epgList);
        }
    }
    
    /**
     * Appends and returns a new empty "epgList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList addNewEpgList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList)get_store().add_element_user(EPGLIST$14);
            return target;
        }
    }
    
    /**
     * Unsets the "epgList" element
     */
    public void unsetEpgList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGLIST$14, 0);
        }
    }
    
    /**
     * Gets the "gtpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList getGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList)get_store().find_element_user(GTPLIST$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gtpList" element
     */
    public boolean isSetGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GTPLIST$16) != 0;
        }
    }
    
    /**
     * Sets the "gtpList" element
     */
    public void setGtpList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList gtpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList)get_store().find_element_user(GTPLIST$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList)get_store().add_element_user(GTPLIST$16);
            }
            target.set(gtpList);
        }
    }
    
    /**
     * Appends and returns a new empty "gtpList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList addNewGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList)get_store().add_element_user(GTPLIST$16);
            return target;
        }
    }
    
    /**
     * Unsets the "gtpList" element
     */
    public void unsetGtpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GTPLIST$16, 0);
        }
    }
    
    /**
     * Gets the "mfdList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList getMfdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList)get_store().find_element_user(MFDLIST$18, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mfdList" element
     */
    public boolean isSetMfdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MFDLIST$18) != 0;
        }
    }
    
    /**
     * Sets the "mfdList" element
     */
    public void setMfdList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList mfdList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList)get_store().find_element_user(MFDLIST$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList)get_store().add_element_user(MFDLIST$18);
            }
            target.set(mfdList);
        }
    }
    
    /**
     * Appends and returns a new empty "mfdList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList addNewMfdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList)get_store().add_element_user(MFDLIST$18);
            return target;
        }
    }
    
    /**
     * Unsets the "mfdList" element
     */
    public void unsetMfdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MFDLIST$18, 0);
        }
    }
    
    /**
     * Gets the "internalTlRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INTERNALTLREFLIST$20, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "internalTlRefList" element
     */
    public boolean isSetInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTERNALTLREFLIST$20) != 0;
        }
    }
    
    /**
     * Sets the "internalTlRefList" element
     */
    public void setInternalTlRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType internalTlRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INTERNALTLREFLIST$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INTERNALTLREFLIST$20);
            }
            target.set(internalTlRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "internalTlRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INTERNALTLREFLIST$20);
            return target;
        }
    }
    
    /**
     * Unsets the "internalTlRefList" element
     */
    public void unsetInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTERNALTLREFLIST$20, 0);
        }
    }
    
    /**
     * Gets the "containingMlsnRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getContainingMlsnRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CONTAININGMLSNREFLIST$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "containingMlsnRefList" element
     */
    public boolean isSetContainingMlsnRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTAININGMLSNREFLIST$22) != 0;
        }
    }
    
    /**
     * Sets the "containingMlsnRefList" element
     */
    public void setContainingMlsnRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType containingMlsnRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CONTAININGMLSNREFLIST$22, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CONTAININGMLSNREFLIST$22);
            }
            target.set(containingMlsnRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "containingMlsnRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewContainingMlsnRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CONTAININGMLSNREFLIST$22);
            return target;
        }
    }
    
    /**
     * Unsets the "containingMlsnRefList" element
     */
    public void unsetContainingMlsnRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTAININGMLSNREFLIST$22, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$24, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$24) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$24, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$24);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$24);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$24, 0);
        }
    }
    /**
     * An XML ehList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class EhListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList
    {
        
        public EhListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EHINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ehInv");
        
        
        /**
         * Gets a List of "ehInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType> getEhInvList()
        {
            final class EhInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType get(int i)
                    { return EhListImpl.this.getEhInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType old = EhListImpl.this.getEhInvArray(i);
                    EhListImpl.this.setEhInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType o)
                    { EhListImpl.this.insertNewEhInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType old = EhListImpl.this.getEhInvArray(i);
                    EhListImpl.this.removeEhInv(i);
                    return old;
                }
                
                public int size()
                    { return EhListImpl.this.sizeOfEhInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new EhInvList();
            }
        }
        
        /**
         * Gets array of all "ehInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] getEhInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EHINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "ehInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType getEhInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType)get_store().find_element_user(EHINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "ehInv" element
         */
        public int sizeOfEhInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EHINV$0);
            }
        }
        
        /**
         * Sets array of all "ehInv" element
         */
        public void setEhInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] ehInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(ehInvArray, EHINV$0);
            }
        }
        
        /**
         * Sets ith "ehInv" element
         */
        public void setEhInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType ehInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType)get_store().find_element_user(EHINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(ehInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ehInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType insertNewEhInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType)get_store().insert_element_user(EHINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ehInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType addNewEhInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType)get_store().add_element_user(EHINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "ehInv" element
         */
        public void removeEhInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EHINV$0, i);
            }
        }
    }
    /**
     * An XML ptpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class PtpListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList
    {
        
        public PtpListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PTPINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ptpInv");
        
        
        /**
         * Gets a List of "ptpInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType> getPtpInvList()
        {
            final class PtpInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType get(int i)
                    { return PtpListImpl.this.getPtpInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType old = PtpListImpl.this.getPtpInvArray(i);
                    PtpListImpl.this.setPtpInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType o)
                    { PtpListImpl.this.insertNewPtpInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType old = PtpListImpl.this.getPtpInvArray(i);
                    PtpListImpl.this.removePtpInv(i);
                    return old;
                }
                
                public int size()
                    { return PtpListImpl.this.sizeOfPtpInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new PtpInvList();
            }
        }
        
        /**
         * Gets array of all "ptpInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType[] getPtpInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(PTPINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "ptpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType getPtpInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType)get_store().find_element_user(PTPINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "ptpInv" element
         */
        public int sizeOfPtpInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PTPINV$0);
            }
        }
        
        /**
         * Sets array of all "ptpInv" element
         */
        public void setPtpInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType[] ptpInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(ptpInvArray, PTPINV$0);
            }
        }
        
        /**
         * Sets ith "ptpInv" element
         */
        public void setPtpInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType ptpInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType)get_store().find_element_user(PTPINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(ptpInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ptpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType insertNewPtpInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType)get_store().insert_element_user(PTPINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ptpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType addNewPtpInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType)get_store().add_element_user(PTPINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "ptpInv" element
         */
        public void removePtpInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PTPINV$0, i);
            }
        }
    }
    /**
     * An XML ftpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class FtpListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList
    {
        
        public FtpListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FTPINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ftpInv");
        
        
        /**
         * Gets a List of "ftpInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType> getFtpInvList()
        {
            final class FtpInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType get(int i)
                    { return FtpListImpl.this.getFtpInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType old = FtpListImpl.this.getFtpInvArray(i);
                    FtpListImpl.this.setFtpInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType o)
                    { FtpListImpl.this.insertNewFtpInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType old = FtpListImpl.this.getFtpInvArray(i);
                    FtpListImpl.this.removeFtpInv(i);
                    return old;
                }
                
                public int size()
                    { return FtpListImpl.this.sizeOfFtpInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new FtpInvList();
            }
        }
        
        /**
         * Gets array of all "ftpInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType[] getFtpInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(FTPINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "ftpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType getFtpInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType)get_store().find_element_user(FTPINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "ftpInv" element
         */
        public int sizeOfFtpInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FTPINV$0);
            }
        }
        
        /**
         * Sets array of all "ftpInv" element
         */
        public void setFtpInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType[] ftpInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(ftpInvArray, FTPINV$0);
            }
        }
        
        /**
         * Sets ith "ftpInv" element
         */
        public void setFtpInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType ftpInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType)get_store().find_element_user(FTPINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(ftpInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ftpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType insertNewFtpInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType)get_store().insert_element_user(FTPINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ftpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType addNewFtpInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType)get_store().add_element_user(FTPINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "ftpInv" element
         */
        public void removeFtpInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FTPINV$0, i);
            }
        }
    }
    /**
     * An XML pgpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class PgpListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList
    {
        
        public PgpListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PGINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "pgInv");
        
        
        /**
         * Gets a List of "pgInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType> getPgInvList()
        {
            final class PgInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType get(int i)
                    { return PgpListImpl.this.getPgInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType old = PgpListImpl.this.getPgInvArray(i);
                    PgpListImpl.this.setPgInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType o)
                    { PgpListImpl.this.insertNewPgInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType old = PgpListImpl.this.getPgInvArray(i);
                    PgpListImpl.this.removePgInv(i);
                    return old;
                }
                
                public int size()
                    { return PgpListImpl.this.sizeOfPgInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new PgInvList();
            }
        }
        
        /**
         * Gets array of all "pgInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType[] getPgInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(PGINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "pgInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType getPgInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType)get_store().find_element_user(PGINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "pgInv" element
         */
        public int sizeOfPgInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PGINV$0);
            }
        }
        
        /**
         * Sets array of all "pgInv" element
         */
        public void setPgInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType[] pgInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(pgInvArray, PGINV$0);
            }
        }
        
        /**
         * Sets ith "pgInv" element
         */
        public void setPgInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType pgInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType)get_store().find_element_user(PGINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(pgInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "pgInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType insertNewPgInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType)get_store().insert_element_user(PGINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "pgInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType addNewPgInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType)get_store().add_element_user(PGINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "pgInv" element
         */
        public void removePgInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PGINV$0, i);
            }
        }
    }
    /**
     * An XML epgList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class EpgListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList
    {
        
        public EpgListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EPGINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "epgInv");
        
        
        /**
         * Gets a List of "epgInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType> getEpgInvList()
        {
            final class EpgInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType get(int i)
                    { return EpgListImpl.this.getEpgInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType old = EpgListImpl.this.getEpgInvArray(i);
                    EpgListImpl.this.setEpgInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType o)
                    { EpgListImpl.this.insertNewEpgInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType old = EpgListImpl.this.getEpgInvArray(i);
                    EpgListImpl.this.removeEpgInv(i);
                    return old;
                }
                
                public int size()
                    { return EpgListImpl.this.sizeOfEpgInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new EpgInvList();
            }
        }
        
        /**
         * Gets array of all "epgInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType[] getEpgInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EPGINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "epgInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType getEpgInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType)get_store().find_element_user(EPGINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "epgInv" element
         */
        public int sizeOfEpgInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EPGINV$0);
            }
        }
        
        /**
         * Sets array of all "epgInv" element
         */
        public void setEpgInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType[] epgInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(epgInvArray, EPGINV$0);
            }
        }
        
        /**
         * Sets ith "epgInv" element
         */
        public void setEpgInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType epgInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType)get_store().find_element_user(EPGINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(epgInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "epgInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType insertNewEpgInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType)get_store().insert_element_user(EPGINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "epgInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType addNewEpgInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType)get_store().add_element_user(EPGINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "epgInv" element
         */
        public void removeEpgInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EPGINV$0, i);
            }
        }
    }
    /**
     * An XML gtpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class GtpListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList
    {
        
        public GtpListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName GTPINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "gtpInv");
        
        
        /**
         * Gets a List of "gtpInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType> getGtpInvList()
        {
            final class GtpInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType get(int i)
                    { return GtpListImpl.this.getGtpInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType old = GtpListImpl.this.getGtpInvArray(i);
                    GtpListImpl.this.setGtpInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType o)
                    { GtpListImpl.this.insertNewGtpInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType old = GtpListImpl.this.getGtpInvArray(i);
                    GtpListImpl.this.removeGtpInv(i);
                    return old;
                }
                
                public int size()
                    { return GtpListImpl.this.sizeOfGtpInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new GtpInvList();
            }
        }
        
        /**
         * Gets array of all "gtpInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType[] getGtpInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(GTPINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "gtpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType getGtpInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType)get_store().find_element_user(GTPINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "gtpInv" element
         */
        public int sizeOfGtpInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(GTPINV$0);
            }
        }
        
        /**
         * Sets array of all "gtpInv" element
         */
        public void setGtpInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType[] gtpInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(gtpInvArray, GTPINV$0);
            }
        }
        
        /**
         * Sets ith "gtpInv" element
         */
        public void setGtpInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType gtpInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType)get_store().find_element_user(GTPINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(gtpInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "gtpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType insertNewGtpInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType)get_store().insert_element_user(GTPINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "gtpInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType addNewGtpInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType)get_store().add_element_user(GTPINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "gtpInv" element
         */
        public void removeGtpInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(GTPINV$0, i);
            }
        }
    }
    /**
     * An XML mfdList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class MfdListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList
    {
        
        public MfdListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFDINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mfdInv");
        
        
        /**
         * Gets a List of "mfdInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType> getMfdInvList()
        {
            final class MfdInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType get(int i)
                    { return MfdListImpl.this.getMfdInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType old = MfdListImpl.this.getMfdInvArray(i);
                    MfdListImpl.this.setMfdInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType o)
                    { MfdListImpl.this.insertNewMfdInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType old = MfdListImpl.this.getMfdInvArray(i);
                    MfdListImpl.this.removeMfdInv(i);
                    return old;
                }
                
                public int size()
                    { return MfdListImpl.this.sizeOfMfdInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MfdInvList();
            }
        }
        
        /**
         * Gets array of all "mfdInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType[] getMfdInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MFDINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "mfdInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType getMfdInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType)get_store().find_element_user(MFDINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "mfdInv" element
         */
        public int sizeOfMfdInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFDINV$0);
            }
        }
        
        /**
         * Sets array of all "mfdInv" element
         */
        public void setMfdInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType[] mfdInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(mfdInvArray, MFDINV$0);
            }
        }
        
        /**
         * Sets ith "mfdInv" element
         */
        public void setMfdInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType mfdInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType)get_store().find_element_user(MFDINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(mfdInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "mfdInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType insertNewMfdInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType)get_store().insert_element_user(MFDINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "mfdInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType addNewMfdInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType)get_store().add_element_user(MFDINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "mfdInv" element
         */
        public void removeMfdInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFDINV$0, i);
            }
        }
    }
}
