/*
 * XML Type:  ManagedElementListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/me/v1
 * Java type: org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.me.v1.impl;
/**
 * An XML ManagedElementListType(@http://www.tmforum.org/mtop/nrf/xsd/me/v1).
 *
 * This is a complex type.
 */
public class ManagedElementListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementListType
{
    
    public ManagedElementListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/me/v1", "me");
    
    
    /**
     * Gets a List of "me" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType> getMeList()
    {
        final class MeList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType>
        {
            public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType get(int i)
                { return ManagedElementListTypeImpl.this.getMeArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType set(int i, org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType o)
            {
                org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType old = ManagedElementListTypeImpl.this.getMeArray(i);
                ManagedElementListTypeImpl.this.setMeArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType o)
                { ManagedElementListTypeImpl.this.insertNewMe(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType old = ManagedElementListTypeImpl.this.getMeArray(i);
                ManagedElementListTypeImpl.this.removeMe(i);
                return old;
            }
            
            public int size()
                { return ManagedElementListTypeImpl.this.sizeOfMeArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new MeList();
        }
    }
    
    /**
     * Gets array of all "me" elements
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType[] getMeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ME$0, targetList);
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType[] result = new org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "me" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType getMeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().find_element_user(ME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "me" element
     */
    public int sizeOfMeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ME$0);
        }
    }
    
    /**
     * Sets array of all "me" element
     */
    public void setMeArray(org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType[] meArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(meArray, ME$0);
        }
    }
    
    /**
     * Sets ith "me" element
     */
    public void setMeArray(int i, org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType me)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().find_element_user(ME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(me);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "me" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType insertNewMe(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().insert_element_user(ME$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "me" element
     */
    public org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType addNewMe()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType target = null;
            target = (org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType)get_store().add_element_user(ME$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "me" element
     */
    public void removeMe(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ME$0, i);
        }
    }
}
