/*
 * XML Type:  InventoryDataType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML InventoryDataType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface InventoryDataType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(InventoryDataType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("inventorydatatype2878type");
    
    /**
     * Gets the "mdList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList getMdList();
    
    /**
     * True if has "mdList" element
     */
    boolean isSetMdList();
    
    /**
     * Sets the "mdList" element
     */
    void setMdList(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList mdList);
    
    /**
     * Appends and returns a new empty "mdList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList addNewMdList();
    
    /**
     * Unsets the "mdList" element
     */
    void unsetMdList();
    
    /**
     * Gets the "tmdList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList getTmdList();
    
    /**
     * True if has "tmdList" element
     */
    boolean isSetTmdList();
    
    /**
     * Sets the "tmdList" element
     */
    void setTmdList(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList tmdList);
    
    /**
     * Appends and returns a new empty "tmdList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList addNewTmdList();
    
    /**
     * Unsets the "tmdList" element
     */
    void unsetTmdList();
    
    /**
     * Gets the "osList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList getOsList();
    
    /**
     * True if has "osList" element
     */
    boolean isSetOsList();
    
    /**
     * Sets the "osList" element
     */
    void setOsList(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList osList);
    
    /**
     * Appends and returns a new empty "osList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList addNewOsList();
    
    /**
     * Unsets the "osList" element
     */
    void unsetOsList();
    
    /**
     * Gets the "voList" element
     */
    org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType getVoList();
    
    /**
     * True if has "voList" element
     */
    boolean isSetVoList();
    
    /**
     * Sets the "voList" element
     */
    void setVoList(org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType voList);
    
    /**
     * Appends and returns a new empty "voList" element
     */
    org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType addNewVoList();
    
    /**
     * Unsets the "voList" element
     */
    void unsetVoList();
    
    /**
     * An XML mdList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface MdList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MdList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("mdlista967elemtype");
        
        /**
         * Gets a List of "md" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType> getMdList();
        
        /**
         * Gets array of all "md" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType[] getMdArray();
        
        /**
         * Gets ith "md" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType getMdArray(int i);
        
        /**
         * Returns number of "md" element
         */
        int sizeOfMdArray();
        
        /**
         * Sets array of all "md" element
         */
        void setMdArray(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType[] mdArray);
        
        /**
         * Sets ith "md" element
         */
        void setMdArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType md);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "md" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType insertNewMd(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "md" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType addNewMd();
        
        /**
         * Removes the ith "md" element
         */
        void removeMd(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML tmdList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface TmdList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TmdList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("tmdlist13a3elemtype");
        
        /**
         * Gets a List of "tmd" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType> getTmdList();
        
        /**
         * Gets array of all "tmd" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType[] getTmdArray();
        
        /**
         * Gets ith "tmd" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType getTmdArray(int i);
        
        /**
         * Returns number of "tmd" element
         */
        int sizeOfTmdArray();
        
        /**
         * Sets array of all "tmd" element
         */
        void setTmdArray(org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType[] tmdArray);
        
        /**
         * Sets ith "tmd" element
         */
        void setTmdArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType tmd);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "tmd" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType insertNewTmd(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "tmd" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType addNewTmd();
        
        /**
         * Removes the ith "tmd" element
         */
        void removeTmd(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML osList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface OsList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(OsList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("oslist107aelemtype");
        
        /**
         * Gets a List of "os" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType> getOsList();
        
        /**
         * Gets array of all "os" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType[] getOsArray();
        
        /**
         * Gets ith "os" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType getOsArray(int i);
        
        /**
         * Returns number of "os" element
         */
        int sizeOfOsArray();
        
        /**
         * Sets array of all "os" element
         */
        void setOsArray(org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType[] osArray);
        
        /**
         * Sets ith "os" element
         */
        void setOsArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType os);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "os" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType insertNewOs(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "os" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType addNewOs();
        
        /**
         * Removes the ith "os" element
         */
        void removeOs(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
