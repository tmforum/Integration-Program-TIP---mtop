/*
 * XML Type:  ManagedElementInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML ManagedElementInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface ManagedElementInventoryType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ManagedElementInventoryType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("managedelementinventorytype803ftype");
    
    /**
     * Gets the "meNm" element
     */
    java.lang.String getMeNm();
    
    /**
     * Gets (as xml) the "meNm" element
     */
    org.apache.xmlbeans.XmlString xgetMeNm();
    
    /**
     * True if has "meNm" element
     */
    boolean isSetMeNm();
    
    /**
     * Sets the "meNm" element
     */
    void setMeNm(java.lang.String meNm);
    
    /**
     * Sets (as xml) the "meNm" element
     */
    void xsetMeNm(org.apache.xmlbeans.XmlString meNm);
    
    /**
     * Unsets the "meNm" element
     */
    void unsetMeNm();
    
    /**
     * Gets the "meAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType getMeAttrs();
    
    /**
     * True if has "meAttrs" element
     */
    boolean isSetMeAttrs();
    
    /**
     * Sets the "meAttrs" element
     */
    void setMeAttrs(org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType meAttrs);
    
    /**
     * Appends and returns a new empty "meAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.me.v1.ManagedElementType addNewMeAttrs();
    
    /**
     * Unsets the "meAttrs" element
     */
    void unsetMeAttrs();
    
    /**
     * Gets the "ehList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList getEhList();
    
    /**
     * True if has "ehList" element
     */
    boolean isSetEhList();
    
    /**
     * Sets the "ehList" element
     */
    void setEhList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList ehList);
    
    /**
     * Appends and returns a new empty "ehList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList addNewEhList();
    
    /**
     * Unsets the "ehList" element
     */
    void unsetEhList();
    
    /**
     * Gets the "ptpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList getPtpList();
    
    /**
     * True if has "ptpList" element
     */
    boolean isSetPtpList();
    
    /**
     * Sets the "ptpList" element
     */
    void setPtpList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList ptpList);
    
    /**
     * Appends and returns a new empty "ptpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList addNewPtpList();
    
    /**
     * Unsets the "ptpList" element
     */
    void unsetPtpList();
    
    /**
     * Gets the "ftpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList getFtpList();
    
    /**
     * True if has "ftpList" element
     */
    boolean isSetFtpList();
    
    /**
     * Sets the "ftpList" element
     */
    void setFtpList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList ftpList);
    
    /**
     * Appends and returns a new empty "ftpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList addNewFtpList();
    
    /**
     * Unsets the "ftpList" element
     */
    void unsetFtpList();
    
    /**
     * Gets the "ccList" element
     */
    org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType getCcList();
    
    /**
     * True if has "ccList" element
     */
    boolean isSetCcList();
    
    /**
     * Sets the "ccList" element
     */
    void setCcList(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType ccList);
    
    /**
     * Appends and returns a new empty "ccList" element
     */
    org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType addNewCcList();
    
    /**
     * Unsets the "ccList" element
     */
    void unsetCcList();
    
    /**
     * Gets the "pgpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList getPgpList();
    
    /**
     * True if has "pgpList" element
     */
    boolean isSetPgpList();
    
    /**
     * Sets the "pgpList" element
     */
    void setPgpList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList pgpList);
    
    /**
     * Appends and returns a new empty "pgpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList addNewPgpList();
    
    /**
     * Unsets the "pgpList" element
     */
    void unsetPgpList();
    
    /**
     * Gets the "epgList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList getEpgList();
    
    /**
     * True if has "epgList" element
     */
    boolean isSetEpgList();
    
    /**
     * Sets the "epgList" element
     */
    void setEpgList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList epgList);
    
    /**
     * Appends and returns a new empty "epgList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList addNewEpgList();
    
    /**
     * Unsets the "epgList" element
     */
    void unsetEpgList();
    
    /**
     * Gets the "gtpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList getGtpList();
    
    /**
     * True if has "gtpList" element
     */
    boolean isSetGtpList();
    
    /**
     * Sets the "gtpList" element
     */
    void setGtpList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList gtpList);
    
    /**
     * Appends and returns a new empty "gtpList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList addNewGtpList();
    
    /**
     * Unsets the "gtpList" element
     */
    void unsetGtpList();
    
    /**
     * Gets the "mfdList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList getMfdList();
    
    /**
     * True if has "mfdList" element
     */
    boolean isSetMfdList();
    
    /**
     * Sets the "mfdList" element
     */
    void setMfdList(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList mfdList);
    
    /**
     * Appends and returns a new empty "mfdList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList addNewMfdList();
    
    /**
     * Unsets the "mfdList" element
     */
    void unsetMfdList();
    
    /**
     * Gets the "internalTlRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getInternalTlRefList();
    
    /**
     * True if has "internalTlRefList" element
     */
    boolean isSetInternalTlRefList();
    
    /**
     * Sets the "internalTlRefList" element
     */
    void setInternalTlRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType internalTlRefList);
    
    /**
     * Appends and returns a new empty "internalTlRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewInternalTlRefList();
    
    /**
     * Unsets the "internalTlRefList" element
     */
    void unsetInternalTlRefList();
    
    /**
     * Gets the "containingMlsnRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getContainingMlsnRefList();
    
    /**
     * True if has "containingMlsnRefList" element
     */
    boolean isSetContainingMlsnRefList();
    
    /**
     * Sets the "containingMlsnRefList" element
     */
    void setContainingMlsnRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType containingMlsnRefList);
    
    /**
     * Appends and returns a new empty "containingMlsnRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewContainingMlsnRefList();
    
    /**
     * Unsets the "containingMlsnRefList" element
     */
    void unsetContainingMlsnRefList();
    
    /**
     * Gets the "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator();
    
    /**
     * True if has "qualityIndicator" element
     */
    boolean isSetQualityIndicator();
    
    /**
     * Sets the "qualityIndicator" element
     */
    void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator);
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator();
    
    /**
     * Unsets the "qualityIndicator" element
     */
    void unsetQualityIndicator();
    
    /**
     * An XML ehList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface EhList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EhList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("ehlistbce2elemtype");
        
        /**
         * Gets a List of "ehInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType> getEhInvList();
        
        /**
         * Gets array of all "ehInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] getEhInvArray();
        
        /**
         * Gets ith "ehInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType getEhInvArray(int i);
        
        /**
         * Returns number of "ehInv" element
         */
        int sizeOfEhInvArray();
        
        /**
         * Sets array of all "ehInv" element
         */
        void setEhInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] ehInvArray);
        
        /**
         * Sets ith "ehInv" element
         */
        void setEhInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType ehInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ehInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType insertNewEhInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ehInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType addNewEhInv();
        
        /**
         * Removes the ith "ehInv" element
         */
        void removeEhInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EhList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML ptpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface PtpList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PtpList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("ptplist25e9elemtype");
        
        /**
         * Gets a List of "ptpInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType> getPtpInvList();
        
        /**
         * Gets array of all "ptpInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType[] getPtpInvArray();
        
        /**
         * Gets ith "ptpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType getPtpInvArray(int i);
        
        /**
         * Returns number of "ptpInv" element
         */
        int sizeOfPtpInvArray();
        
        /**
         * Sets array of all "ptpInv" element
         */
        void setPtpInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType[] ptpInvArray);
        
        /**
         * Sets ith "ptpInv" element
         */
        void setPtpInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType ptpInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ptpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType insertNewPtpInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ptpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.PhysicalTerminationPointInventoryType addNewPtpInv();
        
        /**
         * Removes the ith "ptpInv" element
         */
        void removePtpInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PtpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML ftpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface FtpList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FtpList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("ftplist7633elemtype");
        
        /**
         * Gets a List of "ftpInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType> getFtpInvList();
        
        /**
         * Gets array of all "ftpInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType[] getFtpInvArray();
        
        /**
         * Gets ith "ftpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType getFtpInvArray(int i);
        
        /**
         * Returns number of "ftpInv" element
         */
        int sizeOfFtpInvArray();
        
        /**
         * Sets array of all "ftpInv" element
         */
        void setFtpInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType[] ftpInvArray);
        
        /**
         * Sets ith "ftpInv" element
         */
        void setFtpInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType ftpInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ftpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType insertNewFtpInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ftpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.FloatingTerminationPointInventoryType addNewFtpInv();
        
        /**
         * Removes the ith "ftpInv" element
         */
        void removeFtpInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.FtpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML pgpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface PgpList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PgpList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("pgplist171celemtype");
        
        /**
         * Gets a List of "pgInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType> getPgInvList();
        
        /**
         * Gets array of all "pgInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType[] getPgInvArray();
        
        /**
         * Gets ith "pgInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType getPgInvArray(int i);
        
        /**
         * Returns number of "pgInv" element
         */
        int sizeOfPgInvArray();
        
        /**
         * Sets array of all "pgInv" element
         */
        void setPgInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType[] pgInvArray);
        
        /**
         * Sets ith "pgInv" element
         */
        void setPgInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType pgInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "pgInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType insertNewPgInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "pgInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.ProtectionGroupInventoryType addNewPgInv();
        
        /**
         * Removes the ith "pgInv" element
         */
        void removePgInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.PgpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML epgList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface EpgList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EpgList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("epglistf5b9elemtype");
        
        /**
         * Gets a List of "epgInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType> getEpgInvList();
        
        /**
         * Gets array of all "epgInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType[] getEpgInvArray();
        
        /**
         * Gets ith "epgInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType getEpgInvArray(int i);
        
        /**
         * Returns number of "epgInv" element
         */
        int sizeOfEpgInvArray();
        
        /**
         * Sets array of all "epgInv" element
         */
        void setEpgInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType[] epgInvArray);
        
        /**
         * Sets ith "epgInv" element
         */
        void setEpgInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType epgInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "epgInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType insertNewEpgInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "epgInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentProtectionGroupInventoryType addNewEpgInv();
        
        /**
         * Removes the ith "epgInv" element
         */
        void removeEpgInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.EpgList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML gtpList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface GtpList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GtpList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("gtplistd492elemtype");
        
        /**
         * Gets a List of "gtpInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType> getGtpInvList();
        
        /**
         * Gets array of all "gtpInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType[] getGtpInvArray();
        
        /**
         * Gets ith "gtpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType getGtpInvArray(int i);
        
        /**
         * Returns number of "gtpInv" element
         */
        int sizeOfGtpInvArray();
        
        /**
         * Sets array of all "gtpInv" element
         */
        void setGtpInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType[] gtpInvArray);
        
        /**
         * Sets ith "gtpInv" element
         */
        void setGtpInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType gtpInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "gtpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType insertNewGtpInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "gtpInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType addNewGtpInv();
        
        /**
         * Removes the ith "gtpInv" element
         */
        void removeGtpInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.GtpList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML mfdList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface MfdList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MfdList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("mfdlist28caelemtype");
        
        /**
         * Gets a List of "mfdInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType> getMfdInvList();
        
        /**
         * Gets array of all "mfdInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType[] getMfdInvArray();
        
        /**
         * Gets ith "mfdInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType getMfdInvArray(int i);
        
        /**
         * Returns number of "mfdInv" element
         */
        int sizeOfMfdInvArray();
        
        /**
         * Sets array of all "mfdInv" element
         */
        void setMfdInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType[] mfdInvArray);
        
        /**
         * Sets ith "mfdInv" element
         */
        void setMfdInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType mfdInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "mfdInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType insertNewMfdInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "mfdInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.MatrixFlowDomainInventoryType addNewMfdInv();
        
        /**
         * Removes the ith "mfdInv" element
         */
        void removeMfdInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType.MfdList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagedElementInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
