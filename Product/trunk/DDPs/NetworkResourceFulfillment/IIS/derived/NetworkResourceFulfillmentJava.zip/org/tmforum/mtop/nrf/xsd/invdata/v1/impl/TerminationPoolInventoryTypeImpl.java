/*
 * XML Type:  TerminationPoolInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML TerminationPoolInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class TerminationPoolInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType
{
    
    public TerminationPoolInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPPOOLNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tppoolNm");
    private static final javax.xml.namespace.QName TPPOOLATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tppoolAttrs");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "tppoolNm" element
     */
    public java.lang.String getTppoolNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPPOOLNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "tppoolNm" element
     */
    public org.apache.xmlbeans.XmlString xgetTppoolNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TPPOOLNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "tppoolNm" element
     */
    public boolean isSetTppoolNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPPOOLNM$0) != 0;
        }
    }
    
    /**
     * Sets the "tppoolNm" element
     */
    public void setTppoolNm(java.lang.String tppoolNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TPPOOLNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TPPOOLNM$0);
            }
            target.setStringValue(tppoolNm);
        }
    }
    
    /**
     * Sets (as xml) the "tppoolNm" element
     */
    public void xsetTppoolNm(org.apache.xmlbeans.XmlString tppoolNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TPPOOLNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TPPOOLNM$0);
            }
            target.set(tppoolNm);
        }
    }
    
    /**
     * Unsets the "tppoolNm" element
     */
    public void unsetTppoolNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPPOOLNM$0, 0);
        }
    }
    
    /**
     * Gets the "tppoolAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType getTppoolAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType)get_store().find_element_user(TPPOOLATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tppoolAttrs" element
     */
    public boolean isSetTppoolAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPPOOLATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "tppoolAttrs" element
     */
    public void setTppoolAttrs(org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType tppoolAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType)get_store().find_element_user(TPPOOLATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType)get_store().add_element_user(TPPOOLATTRS$2);
            }
            target.set(tppoolAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "tppoolAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType addNewTppoolAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType target = null;
            target = (org.tmforum.mtop.nrf.xsd.tppool.v1.TerminationPointPoolType)get_store().add_element_user(TPPOOLATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "tppoolAttrs" element
     */
    public void unsetTppoolAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPPOOLATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$4) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$4);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$4);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$4, 0);
        }
    }
}
