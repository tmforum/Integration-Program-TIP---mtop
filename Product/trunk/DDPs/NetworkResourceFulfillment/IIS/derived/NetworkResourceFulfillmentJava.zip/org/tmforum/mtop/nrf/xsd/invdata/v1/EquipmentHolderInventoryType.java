/*
 * XML Type:  EquipmentHolderInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML EquipmentHolderInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface EquipmentHolderInventoryType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EquipmentHolderInventoryType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("equipmentholderinventorytypeffcatype");
    
    /**
     * Gets the "ehNm" element
     */
    java.lang.String getEhNm();
    
    /**
     * Gets (as xml) the "ehNm" element
     */
    org.apache.xmlbeans.XmlString xgetEhNm();
    
    /**
     * True if has "ehNm" element
     */
    boolean isSetEhNm();
    
    /**
     * Sets the "ehNm" element
     */
    void setEhNm(java.lang.String ehNm);
    
    /**
     * Sets (as xml) the "ehNm" element
     */
    void xsetEhNm(org.apache.xmlbeans.XmlString ehNm);
    
    /**
     * Unsets the "ehNm" element
     */
    void unsetEhNm();
    
    /**
     * Gets the "ehAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType getEhAttrs();
    
    /**
     * True if has "ehAttrs" element
     */
    boolean isSetEhAttrs();
    
    /**
     * Sets the "ehAttrs" element
     */
    void setEhAttrs(org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType ehAttrs);
    
    /**
     * Appends and returns a new empty "ehAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType addNewEhAttrs();
    
    /**
     * Unsets the "ehAttrs" element
     */
    void unsetEhAttrs();
    
    /**
     * Gets the "ehList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList getEhList();
    
    /**
     * True if has "ehList" element
     */
    boolean isSetEhList();
    
    /**
     * Sets the "ehList" element
     */
    void setEhList(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList ehList);
    
    /**
     * Appends and returns a new empty "ehList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList addNewEhList();
    
    /**
     * Unsets the "ehList" element
     */
    void unsetEhList();
    
    /**
     * Gets the "eqInv" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType getEqInv();
    
    /**
     * True if has "eqInv" element
     */
    boolean isSetEqInv();
    
    /**
     * Sets the "eqInv" element
     */
    void setEqInv(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType eqInv);
    
    /**
     * Appends and returns a new empty "eqInv" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType addNewEqInv();
    
    /**
     * Unsets the "eqInv" element
     */
    void unsetEqInv();
    
    /**
     * Gets the "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator();
    
    /**
     * True if has "qualityIndicator" element
     */
    boolean isSetQualityIndicator();
    
    /**
     * Sets the "qualityIndicator" element
     */
    void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator);
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator();
    
    /**
     * Unsets the "qualityIndicator" element
     */
    void unsetQualityIndicator();
    
    /**
     * An XML ehList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface EhList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EhList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("ehlist5787elemtype");
        
        /**
         * Gets a List of "ehInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType> getEhInvList();
        
        /**
         * Gets array of all "ehInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] getEhInvArray();
        
        /**
         * Gets ith "ehInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType getEhInvArray(int i);
        
        /**
         * Returns number of "ehInv" element
         */
        int sizeOfEhInvArray();
        
        /**
         * Sets array of all "ehInv" element
         */
        void setEhInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType[] ehInvArray);
        
        /**
         * Sets ith "ehInv" element
         */
        void setEhInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType ehInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "ehInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType insertNewEhInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "ehInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType addNewEhInv();
        
        /**
         * Removes the ith "ehInv" element
         */
        void removeEhInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType.EhList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentHolderInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
