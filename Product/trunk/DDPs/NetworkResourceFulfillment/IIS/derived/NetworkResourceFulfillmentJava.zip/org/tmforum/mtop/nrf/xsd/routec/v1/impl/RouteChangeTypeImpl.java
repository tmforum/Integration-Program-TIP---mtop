/*
 * XML Type:  RouteChangeType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/routec/v1
 * Java type: org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.routec.v1.impl;
/**
 * An XML RouteChangeType(@http://www.tmforum.org/mtop/nrf/xsd/routec/v1).
 *
 * This is a complex type.
 */
public class RouteChangeTypeImpl extends org.tmforum.mtop.fmw.xsd.ei.v1.impl.EventInformationTypeImpl implements org.tmforum.mtop.nrf.xsd.routec.v1.RouteChangeType
{
    
    public RouteChangeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ROUTECHANGEEVENT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routec/v1", "routeChangeEvent");
    private static final javax.xml.namespace.QName ROUTE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/routec/v1", "route");
    
    
    /**
     * Gets the "routeChangeEvent" element
     */
    public java.lang.String getRouteChangeEvent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTECHANGEEVENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "routeChangeEvent" element
     */
    public org.tmforum.mtop.nrf.xsd.routec.v1.RerouteChangeEventType xgetRouteChangeEvent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routec.v1.RerouteChangeEventType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routec.v1.RerouteChangeEventType)get_store().find_element_user(ROUTECHANGEEVENT$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "routeChangeEvent" element
     */
    public boolean isSetRouteChangeEvent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTECHANGEEVENT$0) != 0;
        }
    }
    
    /**
     * Sets the "routeChangeEvent" element
     */
    public void setRouteChangeEvent(java.lang.String routeChangeEvent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTECHANGEEVENT$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTECHANGEEVENT$0);
            }
            target.setStringValue(routeChangeEvent);
        }
    }
    
    /**
     * Sets (as xml) the "routeChangeEvent" element
     */
    public void xsetRouteChangeEvent(org.tmforum.mtop.nrf.xsd.routec.v1.RerouteChangeEventType routeChangeEvent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.routec.v1.RerouteChangeEventType target = null;
            target = (org.tmforum.mtop.nrf.xsd.routec.v1.RerouteChangeEventType)get_store().find_element_user(ROUTECHANGEEVENT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.routec.v1.RerouteChangeEventType)get_store().add_element_user(ROUTECHANGEEVENT$0);
            }
            target.set(routeChangeEvent);
        }
    }
    
    /**
     * Unsets the "routeChangeEvent" element
     */
    public void unsetRouteChangeEvent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTECHANGEEVENT$0, 0);
        }
    }
    
    /**
     * Gets the "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType getRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "route" element
     */
    public boolean isSetRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROUTE$2) != 0;
        }
    }
    
    /**
     * Sets the "route" element
     */
    public void setRoute(org.tmforum.mtop.nrf.xsd.route.v1.RouteType route)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$2);
            }
            target.set(route);
        }
    }
    
    /**
     * Appends and returns a new empty "route" element
     */
    public org.tmforum.mtop.nrf.xsd.route.v1.RouteType addNewRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
            target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "route" element
     */
    public void unsetRoute()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROUTE$2, 0);
        }
    }
}
