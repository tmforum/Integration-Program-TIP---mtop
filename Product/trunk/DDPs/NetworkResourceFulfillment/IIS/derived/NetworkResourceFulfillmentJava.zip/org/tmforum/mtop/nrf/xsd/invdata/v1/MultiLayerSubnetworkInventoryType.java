/*
 * XML Type:  MultiLayerSubnetworkInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1;


/**
 * An XML MultiLayerSubnetworkInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public interface MultiLayerSubnetworkInventoryType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MultiLayerSubnetworkInventoryType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("multilayersubnetworkinventorytype8148type");
    
    /**
     * Gets the "mlsnNm" element
     */
    java.lang.String getMlsnNm();
    
    /**
     * Gets (as xml) the "mlsnNm" element
     */
    org.apache.xmlbeans.XmlString xgetMlsnNm();
    
    /**
     * True if has "mlsnNm" element
     */
    boolean isSetMlsnNm();
    
    /**
     * Sets the "mlsnNm" element
     */
    void setMlsnNm(java.lang.String mlsnNm);
    
    /**
     * Sets (as xml) the "mlsnNm" element
     */
    void xsetMlsnNm(org.apache.xmlbeans.XmlString mlsnNm);
    
    /**
     * Unsets the "mlsnNm" element
     */
    void unsetMlsnNm();
    
    /**
     * Gets the "mlsnAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType getMlsnAttrs();
    
    /**
     * True if has "mlsnAttrs" element
     */
    boolean isSetMlsnAttrs();
    
    /**
     * Sets the "mlsnAttrs" element
     */
    void setMlsnAttrs(org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType mlsnAttrs);
    
    /**
     * Appends and returns a new empty "mlsnAttrs" element
     */
    org.tmforum.mtop.nrf.xsd.mlsn.v1.MultiLayerSubnetworkType addNewMlsnAttrs();
    
    /**
     * Unsets the "mlsnAttrs" element
     */
    void unsetMlsnAttrs();
    
    /**
     * Gets the "sncList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList getSncList();
    
    /**
     * True if has "sncList" element
     */
    boolean isSetSncList();
    
    /**
     * Sets the "sncList" element
     */
    void setSncList(org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList sncList);
    
    /**
     * Appends and returns a new empty "sncList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList addNewSncList();
    
    /**
     * Unsets the "sncList" element
     */
    void unsetSncList();
    
    /**
     * Gets the "tpPoolList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList getTpPoolList();
    
    /**
     * True if has "tpPoolList" element
     */
    boolean isSetTpPoolList();
    
    /**
     * Sets the "tpPoolList" element
     */
    void setTpPoolList(org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList tpPoolList);
    
    /**
     * Appends and returns a new empty "tpPoolList" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList addNewTpPoolList();
    
    /**
     * Unsets the "tpPoolList" element
     */
    void unsetTpPoolList();
    
    /**
     * Gets the "associatedMeRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAssociatedMeRefList();
    
    /**
     * True if has "associatedMeRefList" element
     */
    boolean isSetAssociatedMeRefList();
    
    /**
     * Sets the "associatedMeRefList" element
     */
    void setAssociatedMeRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType associatedMeRefList);
    
    /**
     * Appends and returns a new empty "associatedMeRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAssociatedMeRefList();
    
    /**
     * Unsets the "associatedMeRefList" element
     */
    void unsetAssociatedMeRefList();
    
    /**
     * Gets the "internalTlRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getInternalTlRefList();
    
    /**
     * True if has "internalTlRefList" element
     */
    boolean isSetInternalTlRefList();
    
    /**
     * Sets the "internalTlRefList" element
     */
    void setInternalTlRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType internalTlRefList);
    
    /**
     * Appends and returns a new empty "internalTlRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewInternalTlRefList();
    
    /**
     * Unsets the "internalTlRefList" element
     */
    void unsetInternalTlRefList();
    
    /**
     * Gets the "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator();
    
    /**
     * True if has "qualityIndicator" element
     */
    boolean isSetQualityIndicator();
    
    /**
     * Sets the "qualityIndicator" element
     */
    void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator);
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator();
    
    /**
     * Unsets the "qualityIndicator" element
     */
    void unsetQualityIndicator();
    
    /**
     * An XML sncList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface SncList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SncList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("snclist8976elemtype");
        
        /**
         * Gets a List of "sncInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType> getSncInvList();
        
        /**
         * Gets array of all "sncInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType[] getSncInvArray();
        
        /**
         * Gets ith "sncInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType getSncInvArray(int i);
        
        /**
         * Returns number of "sncInv" element
         */
        int sizeOfSncInvArray();
        
        /**
         * Sets array of all "sncInv" element
         */
        void setSncInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType[] sncInvArray);
        
        /**
         * Sets ith "sncInv" element
         */
        void setSncInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType sncInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "sncInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType insertNewSncInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "sncInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.SubnetworkConnectionInventoryType addNewSncInv();
        
        /**
         * Removes the ith "sncInv" element
         */
        void removeSncInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.SncList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * An XML tpPoolList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public interface TpPoolList extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TpPoolList.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3085B7600858B29318A2E095CDCEE5E5").resolveHandle("tppoollist73f6elemtype");
        
        /**
         * Gets a List of "tpPoolInv" elements
         */
        java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType> getTpPoolInvList();
        
        /**
         * Gets array of all "tpPoolInv" elements
         * @deprecated
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType[] getTpPoolInvArray();
        
        /**
         * Gets ith "tpPoolInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType getTpPoolInvArray(int i);
        
        /**
         * Returns number of "tpPoolInv" element
         */
        int sizeOfTpPoolInvArray();
        
        /**
         * Sets array of all "tpPoolInv" element
         */
        void setTpPoolInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType[] tpPoolInvArray);
        
        /**
         * Sets ith "tpPoolInv" element
         */
        void setTpPoolInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType tpPoolInv);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "tpPoolInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType insertNewTpPoolInv(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "tpPoolInv" element
         */
        org.tmforum.mtop.nrf.xsd.invdata.v1.TerminationPoolInventoryType addNewTpPoolInv();
        
        /**
         * Removes the ith "tpPoolInv" element
         */
        void removeTpPoolInv(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList newInstance() {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType.TpPoolList) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType newInstance() {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrf.xsd.invdata.v1.MultiLayerSubnetworkInventoryType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
