/*
 * XML Type:  EquipmentInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML EquipmentInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class EquipmentInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.EquipmentInventoryType
{
    
    public EquipmentInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EQNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "eqNm");
    private static final javax.xml.namespace.QName EQATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "eqAttrs");
    private static final javax.xml.namespace.QName SUPPORTEDPTPREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "supportedPtpRefList");
    private static final javax.xml.namespace.QName SUPPORTEDEQUIPMENTREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "supportedEquipmentRefList");
    private static final javax.xml.namespace.QName SUPPORTINGEQUIPMENTREFLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "supportingEquipmentRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "eqNm" element
     */
    public java.lang.String getEqNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EQNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "eqNm" element
     */
    public org.apache.xmlbeans.XmlString xgetEqNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EQNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "eqNm" element
     */
    public boolean isSetEqNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQNM$0) != 0;
        }
    }
    
    /**
     * Sets the "eqNm" element
     */
    public void setEqNm(java.lang.String eqNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EQNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EQNM$0);
            }
            target.setStringValue(eqNm);
        }
    }
    
    /**
     * Sets (as xml) the "eqNm" element
     */
    public void xsetEqNm(org.apache.xmlbeans.XmlString eqNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EQNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EQNM$0);
            }
            target.set(eqNm);
        }
    }
    
    /**
     * Unsets the "eqNm" element
     */
    public void unsetEqNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQNM$0, 0);
        }
    }
    
    /**
     * Gets the "eqAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType getEqAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().find_element_user(EQATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "eqAttrs" element
     */
    public boolean isSetEqAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "eqAttrs" element
     */
    public void setEqAttrs(org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType eqAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().find_element_user(EQATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().add_element_user(EQATTRS$2);
            }
            target.set(eqAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "eqAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType addNewEqAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eq.v1.EquipmentType)get_store().add_element_user(EQATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "eqAttrs" element
     */
    public void unsetEqAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "supportedPtpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportedPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDPTPREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "supportedPtpRefList" element
     */
    public boolean isSetSupportedPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTEDPTPREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "supportedPtpRefList" element
     */
    public void setSupportedPtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportedPtpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDPTPREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDPTPREFLIST$4);
            }
            target.set(supportedPtpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportedPtpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportedPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDPTPREFLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "supportedPtpRefList" element
     */
    public void unsetSupportedPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTEDPTPREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "supportedEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDEQUIPMENTREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "supportedEquipmentRefList" element
     */
    public boolean isSetSupportedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTEDEQUIPMENTREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "supportedEquipmentRefList" element
     */
    public void setSupportedEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportedEquipmentRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDEQUIPMENTREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDEQUIPMENTREFLIST$6);
            }
            target.set(supportedEquipmentRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportedEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDEQUIPMENTREFLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "supportedEquipmentRefList" element
     */
    public void unsetSupportedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTEDEQUIPMENTREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "supportingEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTINGEQUIPMENTREFLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "supportingEquipmentRefList" element
     */
    public boolean isSetSupportingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTINGEQUIPMENTREFLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "supportingEquipmentRefList" element
     */
    public void setSupportingEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportingEquipmentRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTINGEQUIPMENTREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTINGEQUIPMENTREFLIST$8);
            }
            target.set(supportingEquipmentRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportingEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTINGEQUIPMENTREFLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "supportingEquipmentRefList" element
     */
    public void unsetSupportingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTINGEQUIPMENTREFLIST$8, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$10) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$10);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$10);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$10, 0);
        }
    }
}
