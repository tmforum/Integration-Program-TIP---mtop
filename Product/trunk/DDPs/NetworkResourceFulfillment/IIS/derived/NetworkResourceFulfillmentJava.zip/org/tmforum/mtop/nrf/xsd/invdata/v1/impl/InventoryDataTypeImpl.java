/*
 * XML Type:  InventoryDataType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML InventoryDataType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class InventoryDataTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType
{
    
    public InventoryDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MDLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "mdList");
    private static final javax.xml.namespace.QName TMDLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tmdList");
    private static final javax.xml.namespace.QName OSLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "osList");
    private static final javax.xml.namespace.QName VOLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "voList");
    
    
    /**
     * Gets the "mdList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList getMdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList)get_store().find_element_user(MDLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mdList" element
     */
    public boolean isSetMdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MDLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "mdList" element
     */
    public void setMdList(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList mdList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList)get_store().find_element_user(MDLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList)get_store().add_element_user(MDLIST$0);
            }
            target.set(mdList);
        }
    }
    
    /**
     * Appends and returns a new empty "mdList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList addNewMdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList)get_store().add_element_user(MDLIST$0);
            return target;
        }
    }
    
    /**
     * Unsets the "mdList" element
     */
    public void unsetMdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MDLIST$0, 0);
        }
    }
    
    /**
     * Gets the "tmdList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList getTmdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList)get_store().find_element_user(TMDLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tmdList" element
     */
    public boolean isSetTmdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TMDLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "tmdList" element
     */
    public void setTmdList(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList tmdList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList)get_store().find_element_user(TMDLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList)get_store().add_element_user(TMDLIST$2);
            }
            target.set(tmdList);
        }
    }
    
    /**
     * Appends and returns a new empty "tmdList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList addNewTmdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList)get_store().add_element_user(TMDLIST$2);
            return target;
        }
    }
    
    /**
     * Unsets the "tmdList" element
     */
    public void unsetTmdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TMDLIST$2, 0);
        }
    }
    
    /**
     * Gets the "osList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList getOsList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList)get_store().find_element_user(OSLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "osList" element
     */
    public boolean isSetOsList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OSLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "osList" element
     */
    public void setOsList(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList osList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList)get_store().find_element_user(OSLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList)get_store().add_element_user(OSLIST$4);
            }
            target.set(osList);
        }
    }
    
    /**
     * Appends and returns a new empty "osList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList addNewOsList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList)get_store().add_element_user(OSLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "osList" element
     */
    public void unsetOsList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OSLIST$4, 0);
        }
    }
    
    /**
     * Gets the "voList" element
     */
    public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType getVoList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType)get_store().find_element_user(VOLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "voList" element
     */
    public boolean isSetVoList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VOLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "voList" element
     */
    public void setVoList(org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType voList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType)get_store().find_element_user(VOLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType)get_store().add_element_user(VOLIST$6);
            }
            target.set(voList);
        }
    }
    
    /**
     * Appends and returns a new empty "voList" element
     */
    public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType addNewVoList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType)get_store().add_element_user(VOLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "voList" element
     */
    public void unsetVoList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VOLIST$6, 0);
        }
    }
    /**
     * An XML mdList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class MdListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.MdList
    {
        
        public MdListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MD$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "md");
        
        
        /**
         * Gets a List of "md" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType> getMdList()
        {
            final class MdList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType get(int i)
                    { return MdListImpl.this.getMdArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType old = MdListImpl.this.getMdArray(i);
                    MdListImpl.this.setMdArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType o)
                    { MdListImpl.this.insertNewMd(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType old = MdListImpl.this.getMdArray(i);
                    MdListImpl.this.removeMd(i);
                    return old;
                }
                
                public int size()
                    { return MdListImpl.this.sizeOfMdArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new MdList();
            }
        }
        
        /**
         * Gets array of all "md" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType[] getMdArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(MD$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "md" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType getMdArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType)get_store().find_element_user(MD$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "md" element
         */
        public int sizeOfMdArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MD$0);
            }
        }
        
        /**
         * Sets array of all "md" element
         */
        public void setMdArray(org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType[] mdArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(mdArray, MD$0);
            }
        }
        
        /**
         * Sets ith "md" element
         */
        public void setMdArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType md)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType)get_store().find_element_user(MD$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(md);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "md" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType insertNewMd(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType)get_store().insert_element_user(MD$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "md" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType addNewMd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.ManagementDomainInventoryType)get_store().add_element_user(MD$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "md" element
         */
        public void removeMd(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MD$0, i);
            }
        }
    }
    /**
     * An XML tmdList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class TmdListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.TmdList
    {
        
        public TmdListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TMD$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "tmd");
        
        
        /**
         * Gets a List of "tmd" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType> getTmdList()
        {
            final class TmdList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType get(int i)
                    { return TmdListImpl.this.getTmdArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType old = TmdListImpl.this.getTmdArray(i);
                    TmdListImpl.this.setTmdArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType o)
                    { TmdListImpl.this.insertNewTmd(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType old = TmdListImpl.this.getTmdArray(i);
                    TmdListImpl.this.removeTmd(i);
                    return old;
                }
                
                public int size()
                    { return TmdListImpl.this.sizeOfTmdArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new TmdList();
            }
        }
        
        /**
         * Gets array of all "tmd" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType[] getTmdArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(TMD$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "tmd" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType getTmdArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType)get_store().find_element_user(TMD$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "tmd" element
         */
        public int sizeOfTmdArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TMD$0);
            }
        }
        
        /**
         * Sets array of all "tmd" element
         */
        public void setTmdArray(org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType[] tmdArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(tmdArray, TMD$0);
            }
        }
        
        /**
         * Sets ith "tmd" element
         */
        public void setTmdArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType tmd)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType)get_store().find_element_user(TMD$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(tmd);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "tmd" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType insertNewTmd(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType)get_store().insert_element_user(TMD$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "tmd" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType addNewTmd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.TransmissionDescriptorInventoryType)get_store().add_element_user(TMD$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "tmd" element
         */
        public void removeTmd(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TMD$0, i);
            }
        }
    }
    /**
     * An XML osList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class OsListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType.OsList
    {
        
        public OsListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "os");
        
        
        /**
         * Gets a List of "os" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType> getOsList()
        {
            final class OsList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType get(int i)
                    { return OsListImpl.this.getOsArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType old = OsListImpl.this.getOsArray(i);
                    OsListImpl.this.setOsArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType o)
                    { OsListImpl.this.insertNewOs(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType old = OsListImpl.this.getOsArray(i);
                    OsListImpl.this.removeOs(i);
                    return old;
                }
                
                public int size()
                    { return OsListImpl.this.sizeOfOsArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new OsList();
            }
        }
        
        /**
         * Gets array of all "os" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType[] getOsArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(OS$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "os" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType getOsArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType)get_store().find_element_user(OS$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "os" element
         */
        public int sizeOfOsArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OS$0);
            }
        }
        
        /**
         * Sets array of all "os" element
         */
        public void setOsArray(org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType[] osArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(osArray, OS$0);
            }
        }
        
        /**
         * Sets ith "os" element
         */
        public void setOsArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType os)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType)get_store().find_element_user(OS$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(os);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "os" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType insertNewOs(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType)get_store().insert_element_user(OS$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "os" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType addNewOs()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType)get_store().add_element_user(OS$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "os" element
         */
        public void removeOs(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OS$0, i);
            }
        }
    }
}
