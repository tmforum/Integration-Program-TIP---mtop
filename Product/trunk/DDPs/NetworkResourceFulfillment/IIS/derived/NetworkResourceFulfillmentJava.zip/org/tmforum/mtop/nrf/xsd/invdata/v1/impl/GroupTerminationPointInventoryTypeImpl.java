/*
 * XML Type:  GroupTerminationPointInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML GroupTerminationPointInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class GroupTerminationPointInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.GroupTerminationPointInventoryType
{
    
    public GroupTerminationPointInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GTPNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "gtpNm");
    private static final javax.xml.namespace.QName GTPATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "gtpAttrs");
    private static final javax.xml.namespace.QName CTPREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ctpRefList");
    private static final javax.xml.namespace.QName SUPPORTEDFIXEDSNCREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "supportedFixedSncRefList");
    private static final javax.xml.namespace.QName ALLSUPPORTEDSNCREFLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "allSupportedSncRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "gtpNm" element
     */
    public java.lang.String getGtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GTPNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "gtpNm" element
     */
    public org.apache.xmlbeans.XmlString xgetGtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(GTPNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "gtpNm" element
     */
    public boolean isSetGtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GTPNM$0) != 0;
        }
    }
    
    /**
     * Sets the "gtpNm" element
     */
    public void setGtpNm(java.lang.String gtpNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GTPNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(GTPNM$0);
            }
            target.setStringValue(gtpNm);
        }
    }
    
    /**
     * Sets (as xml) the "gtpNm" element
     */
    public void xsetGtpNm(org.apache.xmlbeans.XmlString gtpNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(GTPNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(GTPNM$0);
            }
            target.set(gtpNm);
        }
    }
    
    /**
     * Unsets the "gtpNm" element
     */
    public void unsetGtpNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GTPNM$0, 0);
        }
    }
    
    /**
     * Gets the "gtpAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType getGtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().find_element_user(GTPATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "gtpAttrs" element
     */
    public boolean isSetGtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GTPATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "gtpAttrs" element
     */
    public void setGtpAttrs(org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType gtpAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().find_element_user(GTPATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().add_element_user(GTPATTRS$2);
            }
            target.set(gtpAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "gtpAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType addNewGtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.gtp.v1.GroupTerminationPointType)get_store().add_element_user(GTPATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "gtpAttrs" element
     */
    public void unsetGtpAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GTPATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "ctpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getCtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CTPREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ctpRefList" element
     */
    public boolean isSetCtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CTPREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "ctpRefList" element
     */
    public void setCtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ctpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(CTPREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CTPREFLIST$4);
            }
            target.set(ctpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "ctpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewCtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(CTPREFLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ctpRefList" element
     */
    public void unsetCtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CTPREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "supportedFixedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDFIXEDSNCREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "supportedFixedSncRefList" element
     */
    public boolean isSetSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPPORTEDFIXEDSNCREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "supportedFixedSncRefList" element
     */
    public void setSupportedFixedSncRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType supportedFixedSncRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUPPORTEDFIXEDSNCREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDFIXEDSNCREFLIST$6);
            }
            target.set(supportedFixedSncRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "supportedFixedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUPPORTEDFIXEDSNCREFLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "supportedFixedSncRefList" element
     */
    public void unsetSupportedFixedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPPORTEDFIXEDSNCREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "allSupportedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ALLSUPPORTEDSNCREFLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "allSupportedSncRefList" element
     */
    public boolean isSetAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALLSUPPORTEDSNCREFLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "allSupportedSncRefList" element
     */
    public void setAllSupportedSncRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType allSupportedSncRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ALLSUPPORTEDSNCREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ALLSUPPORTEDSNCREFLIST$8);
            }
            target.set(allSupportedSncRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "allSupportedSncRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ALLSUPPORTEDSNCREFLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "allSupportedSncRefList" element
     */
    public void unsetAllSupportedSncRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALLSUPPORTEDSNCREFLIST$8, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$10) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$10);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$10);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$10, 0);
        }
    }
}
