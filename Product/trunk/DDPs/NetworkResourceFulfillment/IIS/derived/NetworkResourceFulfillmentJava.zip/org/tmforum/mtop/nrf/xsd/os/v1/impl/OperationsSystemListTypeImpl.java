/*
 * XML Type:  OperationsSystemListType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/os/v1
 * Java type: org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.os.v1.impl;
/**
 * An XML OperationsSystemListType(@http://www.tmforum.org/mtop/nrf/xsd/os/v1).
 *
 * This is a complex type.
 */
public class OperationsSystemListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemListType
{
    
    public OperationsSystemListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/os/v1", "os");
    
    
    /**
     * Gets a List of "os" elements
     */
    public java.util.List<org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType> getOsList()
    {
        final class OsList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType>
        {
            public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType get(int i)
                { return OperationsSystemListTypeImpl.this.getOsArray(i); }
            
            public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType set(int i, org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType o)
            {
                org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType old = OperationsSystemListTypeImpl.this.getOsArray(i);
                OperationsSystemListTypeImpl.this.setOsArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType o)
                { OperationsSystemListTypeImpl.this.insertNewOs(i).set(o); }
            
            public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType remove(int i)
            {
                org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType old = OperationsSystemListTypeImpl.this.getOsArray(i);
                OperationsSystemListTypeImpl.this.removeOs(i);
                return old;
            }
            
            public int size()
                { return OperationsSystemListTypeImpl.this.sizeOfOsArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new OsList();
        }
    }
    
    /**
     * Gets array of all "os" elements
     */
    public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType[] getOsArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(OS$0, targetList);
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType[] result = new org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "os" element
     */
    public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType getOsArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().find_element_user(OS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "os" element
     */
    public int sizeOfOsArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OS$0);
        }
    }
    
    /**
     * Sets array of all "os" element
     */
    public void setOsArray(org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType[] osArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(osArray, OS$0);
        }
    }
    
    /**
     * Sets ith "os" element
     */
    public void setOsArray(int i, org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType os)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().find_element_user(OS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(os);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "os" element
     */
    public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType insertNewOs(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().insert_element_user(OS$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "os" element
     */
    public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType addNewOs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().add_element_user(OS$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "os" element
     */
    public void removeOs(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OS$0, i);
        }
    }
}
