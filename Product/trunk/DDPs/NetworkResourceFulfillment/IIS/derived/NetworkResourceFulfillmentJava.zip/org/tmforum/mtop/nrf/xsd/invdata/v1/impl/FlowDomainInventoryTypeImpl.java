/*
 * XML Type:  FlowDomainInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML FlowDomainInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class FlowDomainInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType
{
    
    public FlowDomainInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FDNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "fdNm");
    private static final javax.xml.namespace.QName FDATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "fdAttrs");
    private static final javax.xml.namespace.QName FDFRINVLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "fdfrInvList");
    private static final javax.xml.namespace.QName PTPREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ptpRefList");
    private static final javax.xml.namespace.QName FTPREFLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "ftpRefList");
    private static final javax.xml.namespace.QName INTERNALTLREFLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "internalTlRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "fdNm" element
     */
    public java.lang.String getFdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FDNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "fdNm" element
     */
    public org.apache.xmlbeans.XmlString xgetFdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FDNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "fdNm" element
     */
    public boolean isSetFdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDNM$0) != 0;
        }
    }
    
    /**
     * Sets the "fdNm" element
     */
    public void setFdNm(java.lang.String fdNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FDNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FDNM$0);
            }
            target.setStringValue(fdNm);
        }
    }
    
    /**
     * Sets (as xml) the "fdNm" element
     */
    public void xsetFdNm(org.apache.xmlbeans.XmlString fdNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FDNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FDNM$0);
            }
            target.set(fdNm);
        }
    }
    
    /**
     * Unsets the "fdNm" element
     */
    public void unsetFdNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDNM$0, 0);
        }
    }
    
    /**
     * Gets the "fdAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType getFdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FDATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "fdAttrs" element
     */
    public boolean isSetFdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "fdAttrs" element
     */
    public void setFdAttrs(org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType fdAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FDATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FDATTRS$2);
            }
            target.set(fdAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "fdAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType addNewFdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FDATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "fdAttrs" element
     */
    public void unsetFdAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "fdfrInvList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList getFdfrInvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList)get_store().find_element_user(FDFRINVLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "fdfrInvList" element
     */
    public boolean isSetFdfrInvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FDFRINVLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "fdfrInvList" element
     */
    public void setFdfrInvList(org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList fdfrInvList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList)get_store().find_element_user(FDFRINVLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList)get_store().add_element_user(FDFRINVLIST$4);
            }
            target.set(fdfrInvList);
        }
    }
    
    /**
     * Appends and returns a new empty "fdfrInvList" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList addNewFdfrInvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList)get_store().add_element_user(FDFRINVLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "fdfrInvList" element
     */
    public void unsetFdfrInvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FDFRINVLIST$4, 0);
        }
    }
    
    /**
     * Gets the "ptpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PTPREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ptpRefList" element
     */
    public boolean isSetPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PTPREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "ptpRefList" element
     */
    public void setPtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ptpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PTPREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PTPREFLIST$6);
            }
            target.set(ptpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "ptpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PTPREFLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "ptpRefList" element
     */
    public void unsetPtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PTPREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "ftpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(FTPREFLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ftpRefList" element
     */
    public boolean isSetFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FTPREFLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "ftpRefList" element
     */
    public void setFtpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType ftpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(FTPREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(FTPREFLIST$8);
            }
            target.set(ftpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "ftpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(FTPREFLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "ftpRefList" element
     */
    public void unsetFtpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FTPREFLIST$8, 0);
        }
    }
    
    /**
     * Gets the "internalTlRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INTERNALTLREFLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "internalTlRefList" element
     */
    public boolean isSetInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTERNALTLREFLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "internalTlRefList" element
     */
    public void setInternalTlRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType internalTlRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(INTERNALTLREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INTERNALTLREFLIST$10);
            }
            target.set(internalTlRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "internalTlRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(INTERNALTLREFLIST$10);
            return target;
        }
    }
    
    /**
     * Unsets the "internalTlRefList" element
     */
    public void unsetInternalTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTERNALTLREFLIST$10, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$12) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$12);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$12);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$12, 0);
        }
    }
    /**
     * An XML fdfrInvList(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
     *
     * This is a complex type.
     */
    public static class FdfrInvListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainInventoryType.FdfrInvList
    {
        
        public FdfrInvListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRINV$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "fdfrInv");
        
        
        /**
         * Gets a List of "fdfrInv" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType> getFdfrInvList()
        {
            final class FdfrInvList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType>
            {
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType get(int i)
                    { return FdfrInvListImpl.this.getFdfrInvArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType set(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType o)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType old = FdfrInvListImpl.this.getFdfrInvArray(i);
                    FdfrInvListImpl.this.setFdfrInvArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType o)
                    { FdfrInvListImpl.this.insertNewFdfrInv(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType old = FdfrInvListImpl.this.getFdfrInvArray(i);
                    FdfrInvListImpl.this.removeFdfrInv(i);
                    return old;
                }
                
                public int size()
                    { return FdfrInvListImpl.this.sizeOfFdfrInvArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new FdfrInvList();
            }
        }
        
        /**
         * Gets array of all "fdfrInv" elements
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType[] getFdfrInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(FDFRINV$0, targetList);
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType[] result = new org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "fdfrInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType getFdfrInvArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType)get_store().find_element_user(FDFRINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "fdfrInv" element
         */
        public int sizeOfFdfrInvArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDFRINV$0);
            }
        }
        
        /**
         * Sets array of all "fdfrInv" element
         */
        public void setFdfrInvArray(org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType[] fdfrInvArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(fdfrInvArray, FDFRINV$0);
            }
        }
        
        /**
         * Sets ith "fdfrInv" element
         */
        public void setFdfrInvArray(int i, org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType fdfrInv)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType)get_store().find_element_user(FDFRINV$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(fdfrInv);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "fdfrInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType insertNewFdfrInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType)get_store().insert_element_user(FDFRINV$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "fdfrInv" element
         */
        public org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType addNewFdfrInv()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType target = null;
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.FlowDomainFragmentInventoryType)get_store().add_element_user(FDFRINV$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "fdfrInv" element
         */
        public void removeFdfrInv(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDFRINV$0, i);
            }
        }
    }
}
