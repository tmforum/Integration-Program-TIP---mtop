/*
 * XML Type:  OperationsSystemInventoryType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/invdata/v1
 * Java type: org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.invdata.v1.impl;
/**
 * An XML OperationsSystemInventoryType(@http://www.tmforum.org/mtop/nrf/xsd/invdata/v1).
 *
 * This is a complex type.
 */
public class OperationsSystemInventoryTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.invdata.v1.OperationsSystemInventoryType
{
    
    public OperationsSystemInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OSNM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "osNm");
    private static final javax.xml.namespace.QName OSATTRS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "osAttrs");
    private static final javax.xml.namespace.QName SUBORDINATEOSREFLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "subordinateOsRefList");
    private static final javax.xml.namespace.QName MANAGESMDREFLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "managesMdRefList");
    private static final javax.xml.namespace.QName MANAGESMEREFLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "managesMeRefList");
    private static final javax.xml.namespace.QName MANAGESTLREFLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "managesTlRefList");
    private static final javax.xml.namespace.QName OFFERSTMDREFLIST$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "offersTmdRefList");
    private static final javax.xml.namespace.QName MANAGESMLSNREFLIST$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "managesMlsnRefList");
    private static final javax.xml.namespace.QName QUALITYINDICATOR$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/invdata/v1", "qualityIndicator");
    
    
    /**
     * Gets the "osNm" element
     */
    public java.lang.String getOsNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSNM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "osNm" element
     */
    public org.apache.xmlbeans.XmlString xgetOsNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OSNM$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "osNm" element
     */
    public boolean isSetOsNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OSNM$0) != 0;
        }
    }
    
    /**
     * Sets the "osNm" element
     */
    public void setOsNm(java.lang.String osNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSNM$0);
            }
            target.setStringValue(osNm);
        }
    }
    
    /**
     * Sets (as xml) the "osNm" element
     */
    public void xsetOsNm(org.apache.xmlbeans.XmlString osNm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OSNM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OSNM$0);
            }
            target.set(osNm);
        }
    }
    
    /**
     * Unsets the "osNm" element
     */
    public void unsetOsNm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OSNM$0, 0);
        }
    }
    
    /**
     * Gets the "osAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType getOsAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().find_element_user(OSATTRS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "osAttrs" element
     */
    public boolean isSetOsAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OSATTRS$2) != 0;
        }
    }
    
    /**
     * Sets the "osAttrs" element
     */
    public void setOsAttrs(org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType osAttrs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().find_element_user(OSATTRS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().add_element_user(OSATTRS$2);
            }
            target.set(osAttrs);
        }
    }
    
    /**
     * Appends and returns a new empty "osAttrs" element
     */
    public org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType addNewOsAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType target = null;
            target = (org.tmforum.mtop.nrf.xsd.os.v1.OperationsSystemType)get_store().add_element_user(OSATTRS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "osAttrs" element
     */
    public void unsetOsAttrs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OSATTRS$2, 0);
        }
    }
    
    /**
     * Gets the "subordinateOsRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSubordinateOsRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUBORDINATEOSREFLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "subordinateOsRefList" element
     */
    public boolean isSetSubordinateOsRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUBORDINATEOSREFLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "subordinateOsRefList" element
     */
    public void setSubordinateOsRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType subordinateOsRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUBORDINATEOSREFLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUBORDINATEOSREFLIST$4);
            }
            target.set(subordinateOsRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "subordinateOsRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSubordinateOsRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUBORDINATEOSREFLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "subordinateOsRefList" element
     */
    public void unsetSubordinateOsRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUBORDINATEOSREFLIST$4, 0);
        }
    }
    
    /**
     * Gets the "managesMdRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getManagesMdRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(MANAGESMDREFLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "managesMdRefList" element
     */
    public boolean isSetManagesMdRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANAGESMDREFLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "managesMdRefList" element
     */
    public void setManagesMdRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType managesMdRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(MANAGESMDREFLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(MANAGESMDREFLIST$6);
            }
            target.set(managesMdRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "managesMdRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewManagesMdRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(MANAGESMDREFLIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "managesMdRefList" element
     */
    public void unsetManagesMdRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANAGESMDREFLIST$6, 0);
        }
    }
    
    /**
     * Gets the "managesMeRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getManagesMeRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(MANAGESMEREFLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "managesMeRefList" element
     */
    public boolean isSetManagesMeRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANAGESMEREFLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "managesMeRefList" element
     */
    public void setManagesMeRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType managesMeRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(MANAGESMEREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(MANAGESMEREFLIST$8);
            }
            target.set(managesMeRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "managesMeRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewManagesMeRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(MANAGESMEREFLIST$8);
            return target;
        }
    }
    
    /**
     * Unsets the "managesMeRefList" element
     */
    public void unsetManagesMeRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANAGESMEREFLIST$8, 0);
        }
    }
    
    /**
     * Gets the "managesTlRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getManagesTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(MANAGESTLREFLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "managesTlRefList" element
     */
    public boolean isSetManagesTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANAGESTLREFLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "managesTlRefList" element
     */
    public void setManagesTlRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType managesTlRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(MANAGESTLREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(MANAGESTLREFLIST$10);
            }
            target.set(managesTlRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "managesTlRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewManagesTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(MANAGESTLREFLIST$10);
            return target;
        }
    }
    
    /**
     * Unsets the "managesTlRefList" element
     */
    public void unsetManagesTlRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANAGESTLREFLIST$10, 0);
        }
    }
    
    /**
     * Gets the "offersTmdRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getOffersTmdRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(OFFERSTMDREFLIST$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "offersTmdRefList" element
     */
    public boolean isSetOffersTmdRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OFFERSTMDREFLIST$12) != 0;
        }
    }
    
    /**
     * Sets the "offersTmdRefList" element
     */
    public void setOffersTmdRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType offersTmdRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(OFFERSTMDREFLIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(OFFERSTMDREFLIST$12);
            }
            target.set(offersTmdRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "offersTmdRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewOffersTmdRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(OFFERSTMDREFLIST$12);
            return target;
        }
    }
    
    /**
     * Unsets the "offersTmdRefList" element
     */
    public void unsetOffersTmdRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OFFERSTMDREFLIST$12, 0);
        }
    }
    
    /**
     * Gets the "managesMlsnRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getManagesMlsnRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(MANAGESMLSNREFLIST$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "managesMlsnRefList" element
     */
    public boolean isSetManagesMlsnRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANAGESMLSNREFLIST$14) != 0;
        }
    }
    
    /**
     * Sets the "managesMlsnRefList" element
     */
    public void setManagesMlsnRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType managesMlsnRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(MANAGESMLSNREFLIST$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(MANAGESMLSNREFLIST$14);
            }
            target.set(managesMlsnRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "managesMlsnRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewManagesMlsnRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(MANAGESMLSNREFLIST$14);
            return target;
        }
    }
    
    /**
     * Unsets the "managesMlsnRefList" element
     */
    public void unsetManagesMlsnRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANAGESMLSNREFLIST$14, 0);
        }
    }
    
    /**
     * Gets the "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType getQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "qualityIndicator" element
     */
    public boolean isSetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(QUALITYINDICATOR$16) != 0;
        }
    }
    
    /**
     * Sets the "qualityIndicator" element
     */
    public void setQualityIndicator(org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType qualityIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().find_element_user(QUALITYINDICATOR$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$16);
            }
            target.set(qualityIndicator);
        }
    }
    
    /**
     * Appends and returns a new empty "qualityIndicator" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType addNewQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.DataQualityIndicatorType)get_store().add_element_user(QUALITYINDICATOR$16);
            return target;
        }
    }
    
    /**
     * Unsets the "qualityIndicator" element
     */
    public void unsetQualityIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(QUALITYINDICATOR$16, 0);
        }
    }
}
