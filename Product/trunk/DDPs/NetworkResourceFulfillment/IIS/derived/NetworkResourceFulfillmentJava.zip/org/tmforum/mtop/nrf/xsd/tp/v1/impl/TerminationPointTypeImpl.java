/*
 * XML Type:  TerminationPointType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/tp/v1
 * Java type: org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.tp.v1.impl;
/**
 * An XML TerminationPointType(@http://www.tmforum.org/mtop/nrf/xsd/tp/v1).
 *
 * This is a complex type.
 */
public class TerminationPointTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.tp.v1.TerminationPointType
{
    
    public TerminationPointTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PTP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ptp/v1", "ptp");
    private static final javax.xml.namespace.QName FTP$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ftp/v1", "ftp");
    private static final javax.xml.namespace.QName CTP$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/ctp/v1", "ctp");
    
    
    /**
     * Gets the "ptp" element
     */
    public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType getPtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().find_element_user(PTP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ptp" element
     */
    public boolean isSetPtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PTP$0) != 0;
        }
    }
    
    /**
     * Sets the "ptp" element
     */
    public void setPtp(org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType ptp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().find_element_user(PTP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().add_element_user(PTP$0);
            }
            target.set(ptp);
        }
    }
    
    /**
     * Appends and returns a new empty "ptp" element
     */
    public org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType addNewPtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ptp.v1.PhysicalTerminationPointType)get_store().add_element_user(PTP$0);
            return target;
        }
    }
    
    /**
     * Unsets the "ptp" element
     */
    public void unsetPtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PTP$0, 0);
        }
    }
    
    /**
     * Gets the "ftp" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType getFtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().find_element_user(FTP$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ftp" element
     */
    public boolean isSetFtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FTP$2) != 0;
        }
    }
    
    /**
     * Sets the "ftp" element
     */
    public void setFtp(org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType ftp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().find_element_user(FTP$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().add_element_user(FTP$2);
            }
            target.set(ftp);
        }
    }
    
    /**
     * Appends and returns a new empty "ftp" element
     */
    public org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType addNewFtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ftp.v1.FloatingTerminationPointType)get_store().add_element_user(FTP$2);
            return target;
        }
    }
    
    /**
     * Unsets the "ftp" element
     */
    public void unsetFtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FTP$2, 0);
        }
    }
    
    /**
     * Gets the "ctp" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType getCtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().find_element_user(CTP$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ctp" element
     */
    public boolean isSetCtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CTP$4) != 0;
        }
    }
    
    /**
     * Sets the "ctp" element
     */
    public void setCtp(org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType ctp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().find_element_user(CTP$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().add_element_user(CTP$4);
            }
            target.set(ctp);
        }
    }
    
    /**
     * Appends and returns a new empty "ctp" element
     */
    public org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType addNewCtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType target = null;
            target = (org.tmforum.mtop.nrf.xsd.ctp.v1.ConnectionTerminationPointType)get_store().add_element_user(CTP$4);
            return target;
        }
    }
    
    /**
     * Unsets the "ctp" element
     */
    public void unsetCtp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CTP$4, 0);
        }
    }
}
