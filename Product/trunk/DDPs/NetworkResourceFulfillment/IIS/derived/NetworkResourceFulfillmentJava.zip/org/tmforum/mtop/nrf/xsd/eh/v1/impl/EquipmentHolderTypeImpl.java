/*
 * XML Type:  EquipmentHolderType
 * Namespace: http://www.tmforum.org/mtop/nrf/xsd/eh/v1
 * Java type: org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrf.xsd.eh.v1.impl;
/**
 * An XML EquipmentHolderType(@http://www.tmforum.org/mtop/nrf/xsd/eh/v1).
 *
 * This is a complex type.
 */
public class EquipmentHolderTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType
{
    
    public EquipmentHolderTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ISREPORTINGALARM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "isReportingAlarm");
    private static final javax.xml.namespace.QName HOLDERTYPE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "holderType");
    private static final javax.xml.namespace.QName ACCEPTABLEEQUIPMENTTYPELIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "acceptableEquipmentTypeList");
    private static final javax.xml.namespace.QName EXPECTEDORINSTALLEDEQUIPMENTREF$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "expectedOrInstalledEquipmentRef");
    private static final javax.xml.namespace.QName HOLDERSTATE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "holderState");
    private static final javax.xml.namespace.QName LOCATION$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "location");
    private static final javax.xml.namespace.QName MANUFACTURER$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "manufacturer");
    private static final javax.xml.namespace.QName MANUFACTUREDATE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "manufactureDate");
    private static final javax.xml.namespace.QName ASAPREF$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "asapRef");
    
    
    /**
     * Gets the "isReportingAlarm" element
     */
    public boolean getIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isReportingAlarm" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "isReportingAlarm" element
     */
    public boolean isNilIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "isReportingAlarm" element
     */
    public boolean isSetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISREPORTINGALARM$0) != 0;
        }
    }
    
    /**
     * Sets the "isReportingAlarm" element
     */
    public void setIsReportingAlarm(boolean isReportingAlarm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISREPORTINGALARM$0);
            }
            target.setBooleanValue(isReportingAlarm);
        }
    }
    
    /**
     * Sets (as xml) the "isReportingAlarm" element
     */
    public void xsetIsReportingAlarm(org.apache.xmlbeans.XmlBoolean isReportingAlarm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREPORTINGALARM$0);
            }
            target.set(isReportingAlarm);
        }
    }
    
    /**
     * Nils the "isReportingAlarm" element
     */
    public void setNilIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISREPORTINGALARM$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISREPORTINGALARM$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "isReportingAlarm" element
     */
    public void unsetIsReportingAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISREPORTINGALARM$0, 0);
        }
    }
    
    /**
     * Gets the "holderType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType getHolderType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType)get_store().find_element_user(HOLDERTYPE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "holderType" element
     */
    public boolean isNilHolderType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType)get_store().find_element_user(HOLDERTYPE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "holderType" element
     */
    public boolean isSetHolderType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(HOLDERTYPE$2) != 0;
        }
    }
    
    /**
     * Sets the "holderType" element
     */
    public void setHolderType(org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType holderType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType)get_store().find_element_user(HOLDERTYPE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType)get_store().add_element_user(HOLDERTYPE$2);
            }
            target.set(holderType);
        }
    }
    
    /**
     * Appends and returns a new empty "holderType" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType addNewHolderType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType)get_store().add_element_user(HOLDERTYPE$2);
            return target;
        }
    }
    
    /**
     * Nils the "holderType" element
     */
    public void setNilHolderType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType)get_store().find_element_user(HOLDERTYPE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentHolderTypeType)get_store().add_element_user(HOLDERTYPE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "holderType" element
     */
    public void unsetHolderType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(HOLDERTYPE$2, 0);
        }
    }
    
    /**
     * Gets the "acceptableEquipmentTypeList" element
     */
    public org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList getAcceptableEquipmentTypeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList)get_store().find_element_user(ACCEPTABLEEQUIPMENTTYPELIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "acceptableEquipmentTypeList" element
     */
    public boolean isNilAcceptableEquipmentTypeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList)get_store().find_element_user(ACCEPTABLEEQUIPMENTTYPELIST$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "acceptableEquipmentTypeList" element
     */
    public boolean isSetAcceptableEquipmentTypeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACCEPTABLEEQUIPMENTTYPELIST$4) != 0;
        }
    }
    
    /**
     * Sets the "acceptableEquipmentTypeList" element
     */
    public void setAcceptableEquipmentTypeList(org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList acceptableEquipmentTypeList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList)get_store().find_element_user(ACCEPTABLEEQUIPMENTTYPELIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList)get_store().add_element_user(ACCEPTABLEEQUIPMENTTYPELIST$4);
            }
            target.set(acceptableEquipmentTypeList);
        }
    }
    
    /**
     * Appends and returns a new empty "acceptableEquipmentTypeList" element
     */
    public org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList addNewAcceptableEquipmentTypeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList)get_store().add_element_user(ACCEPTABLEEQUIPMENTTYPELIST$4);
            return target;
        }
    }
    
    /**
     * Nils the "acceptableEquipmentTypeList" element
     */
    public void setNilAcceptableEquipmentTypeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList target = null;
            target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList)get_store().find_element_user(ACCEPTABLEEQUIPMENTTYPELIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList)get_store().add_element_user(ACCEPTABLEEQUIPMENTTYPELIST$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "acceptableEquipmentTypeList" element
     */
    public void unsetAcceptableEquipmentTypeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACCEPTABLEEQUIPMENTTYPELIST$4, 0);
        }
    }
    
    /**
     * Gets the "expectedOrInstalledEquipmentRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getExpectedOrInstalledEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EXPECTEDORINSTALLEDEQUIPMENTREF$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "expectedOrInstalledEquipmentRef" element
     */
    public boolean isNilExpectedOrInstalledEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EXPECTEDORINSTALLEDEQUIPMENTREF$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "expectedOrInstalledEquipmentRef" element
     */
    public boolean isSetExpectedOrInstalledEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXPECTEDORINSTALLEDEQUIPMENTREF$6) != 0;
        }
    }
    
    /**
     * Sets the "expectedOrInstalledEquipmentRef" element
     */
    public void setExpectedOrInstalledEquipmentRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType expectedOrInstalledEquipmentRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EXPECTEDORINSTALLEDEQUIPMENTREF$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EXPECTEDORINSTALLEDEQUIPMENTREF$6);
            }
            target.set(expectedOrInstalledEquipmentRef);
        }
    }
    
    /**
     * Appends and returns a new empty "expectedOrInstalledEquipmentRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewExpectedOrInstalledEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EXPECTEDORINSTALLEDEQUIPMENTREF$6);
            return target;
        }
    }
    
    /**
     * Nils the "expectedOrInstalledEquipmentRef" element
     */
    public void setNilExpectedOrInstalledEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EXPECTEDORINSTALLEDEQUIPMENTREF$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EXPECTEDORINSTALLEDEQUIPMENTREF$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "expectedOrInstalledEquipmentRef" element
     */
    public void unsetExpectedOrInstalledEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXPECTEDORINSTALLEDEQUIPMENTREF$6, 0);
        }
    }
    
    /**
     * Gets the "holderState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType.Enum getHolderState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HOLDERSTATE$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "holderState" element
     */
    public org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType xgetHolderState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType)get_store().find_element_user(HOLDERSTATE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "holderState" element
     */
    public boolean isNilHolderState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType)get_store().find_element_user(HOLDERSTATE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "holderState" element
     */
    public boolean isSetHolderState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(HOLDERSTATE$8) != 0;
        }
    }
    
    /**
     * Sets the "holderState" element
     */
    public void setHolderState(org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType.Enum holderState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HOLDERSTATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(HOLDERSTATE$8);
            }
            target.setEnumValue(holderState);
        }
    }
    
    /**
     * Sets (as xml) the "holderState" element
     */
    public void xsetHolderState(org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType holderState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType)get_store().find_element_user(HOLDERSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType)get_store().add_element_user(HOLDERSTATE$8);
            }
            target.set(holderState);
        }
    }
    
    /**
     * Nils the "holderState" element
     */
    public void setNilHolderState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType target = null;
            target = (org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType)get_store().find_element_user(HOLDERSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.com.v1.HolderStateType)get_store().add_element_user(HOLDERSTATE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "holderState" element
     */
    public void unsetHolderState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(HOLDERSTATE$8, 0);
        }
    }
    
    /**
     * Gets the "location" element
     */
    public java.lang.String getLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOCATION$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "location" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.LocationType xgetLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(LOCATION$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "location" element
     */
    public boolean isNilLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(LOCATION$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "location" element
     */
    public boolean isSetLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LOCATION$10) != 0;
        }
    }
    
    /**
     * Sets the "location" element
     */
    public void setLocation(java.lang.String location)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LOCATION$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LOCATION$10);
            }
            target.setStringValue(location);
        }
    }
    
    /**
     * Sets (as xml) the "location" element
     */
    public void xsetLocation(org.tmforum.mtop.fmw.xsd.gen.v1.LocationType location)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(LOCATION$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().add_element_user(LOCATION$10);
            }
            target.set(location);
        }
    }
    
    /**
     * Nils the "location" element
     */
    public void setNilLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(LOCATION$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().add_element_user(LOCATION$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "location" element
     */
    public void unsetLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LOCATION$10, 0);
        }
    }
    
    /**
     * Gets the "manufacturer" element
     */
    public java.lang.String getManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURER$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "manufacturer" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType xgetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "manufacturer" element
     */
    public boolean isNilManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "manufacturer" element
     */
    public boolean isSetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANUFACTURER$12) != 0;
        }
    }
    
    /**
     * Sets the "manufacturer" element
     */
    public void setManufacturer(java.lang.String manufacturer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTURER$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MANUFACTURER$12);
            }
            target.setStringValue(manufacturer);
        }
    }
    
    /**
     * Sets (as xml) the "manufacturer" element
     */
    public void xsetManufacturer(org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType manufacturer)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().add_element_user(MANUFACTURER$12);
            }
            target.set(manufacturer);
        }
    }
    
    /**
     * Nils the "manufacturer" element
     */
    public void setNilManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().find_element_user(MANUFACTURER$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerType)get_store().add_element_user(MANUFACTURER$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "manufacturer" element
     */
    public void unsetManufacturer()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANUFACTURER$12, 0);
        }
    }
    
    /**
     * Gets the "manufactureDate" element
     */
    public java.util.Calendar getManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTUREDATE$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "manufactureDate" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType xgetManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().find_element_user(MANUFACTUREDATE$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "manufactureDate" element
     */
    public boolean isNilManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().find_element_user(MANUFACTUREDATE$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "manufactureDate" element
     */
    public boolean isSetManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MANUFACTUREDATE$14) != 0;
        }
    }
    
    /**
     * Sets the "manufactureDate" element
     */
    public void setManufactureDate(java.util.Calendar manufactureDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MANUFACTUREDATE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MANUFACTUREDATE$14);
            }
            target.setCalendarValue(manufactureDate);
        }
    }
    
    /**
     * Sets (as xml) the "manufactureDate" element
     */
    public void xsetManufactureDate(org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType manufactureDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().find_element_user(MANUFACTUREDATE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().add_element_user(MANUFACTUREDATE$14);
            }
            target.set(manufactureDate);
        }
    }
    
    /**
     * Nils the "manufactureDate" element
     */
    public void setNilManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().find_element_user(MANUFACTUREDATE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ManufactureDateType)get_store().add_element_user(MANUFACTUREDATE$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "manufactureDate" element
     */
    public void unsetManufactureDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MANUFACTUREDATE$14, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$16) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$16);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$16);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$16, 0);
        }
    }
    /**
     * An XML acceptableEquipmentTypeList(@http://www.tmforum.org/mtop/nrf/xsd/eh/v1).
     *
     * This is a complex type.
     */
    public static class AcceptableEquipmentTypeListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrf.xsd.eh.v1.EquipmentHolderType.AcceptableEquipmentTypeList
    {
        
        public AcceptableEquipmentTypeListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ACCEPTABLEEQUIPMENTTYPE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrf/xsd/eh/v1", "acceptableEquipmentType");
        
        
        /**
         * Gets a List of "acceptableEquipmentType" elements
         */
        public java.util.List<java.lang.String> getAcceptableEquipmentTypeList()
        {
            final class AcceptableEquipmentTypeList extends java.util.AbstractList<java.lang.String>
            {
                public java.lang.String get(int i)
                    { return AcceptableEquipmentTypeListImpl.this.getAcceptableEquipmentTypeArray(i); }
                
                public java.lang.String set(int i, java.lang.String o)
                {
                    java.lang.String old = AcceptableEquipmentTypeListImpl.this.getAcceptableEquipmentTypeArray(i);
                    AcceptableEquipmentTypeListImpl.this.setAcceptableEquipmentTypeArray(i, o);
                    return old;
                }
                
                public void add(int i, java.lang.String o)
                    { AcceptableEquipmentTypeListImpl.this.insertAcceptableEquipmentType(i, o); }
                
                public java.lang.String remove(int i)
                {
                    java.lang.String old = AcceptableEquipmentTypeListImpl.this.getAcceptableEquipmentTypeArray(i);
                    AcceptableEquipmentTypeListImpl.this.removeAcceptableEquipmentType(i);
                    return old;
                }
                
                public int size()
                    { return AcceptableEquipmentTypeListImpl.this.sizeOfAcceptableEquipmentTypeArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new AcceptableEquipmentTypeList();
            }
        }
        
        /**
         * Gets array of all "acceptableEquipmentType" elements
         */
        public java.lang.String[] getAcceptableEquipmentTypeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ACCEPTABLEEQUIPMENTTYPE$0, targetList);
                java.lang.String[] result = new java.lang.String[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
                return result;
            }
        }
        
        /**
         * Gets ith "acceptableEquipmentType" element
         */
        public java.lang.String getAcceptableEquipmentTypeArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACCEPTABLEEQUIPMENTTYPE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "acceptableEquipmentType" elements
         */
        public java.util.List<org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType> xgetAcceptableEquipmentTypeList()
        {
            final class AcceptableEquipmentTypeList extends java.util.AbstractList<org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType>
            {
                public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType get(int i)
                    { return AcceptableEquipmentTypeListImpl.this.xgetAcceptableEquipmentTypeArray(i); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType set(int i, org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType o)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType old = AcceptableEquipmentTypeListImpl.this.xgetAcceptableEquipmentTypeArray(i);
                    AcceptableEquipmentTypeListImpl.this.xsetAcceptableEquipmentTypeArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType o)
                    { AcceptableEquipmentTypeListImpl.this.insertNewAcceptableEquipmentType(i).set(o); }
                
                public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType remove(int i)
                {
                    org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType old = AcceptableEquipmentTypeListImpl.this.xgetAcceptableEquipmentTypeArray(i);
                    AcceptableEquipmentTypeListImpl.this.removeAcceptableEquipmentType(i);
                    return old;
                }
                
                public int size()
                    { return AcceptableEquipmentTypeListImpl.this.sizeOfAcceptableEquipmentTypeArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new AcceptableEquipmentTypeList();
            }
        }
        
        /**
         * Gets (as xml) array of all "acceptableEquipmentType" elements
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType[] xgetAcceptableEquipmentTypeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(ACCEPTABLEEQUIPMENTTYPE$0, targetList);
                org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType[] result = new org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "acceptableEquipmentType" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType xgetAcceptableEquipmentTypeArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(ACCEPTABLEEQUIPMENTTYPE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)target;
            }
        }
        
        /**
         * Returns number of "acceptableEquipmentType" element
         */
        public int sizeOfAcceptableEquipmentTypeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ACCEPTABLEEQUIPMENTTYPE$0);
            }
        }
        
        /**
         * Sets array of all "acceptableEquipmentType" element
         */
        public void setAcceptableEquipmentTypeArray(java.lang.String[] acceptableEquipmentTypeArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(acceptableEquipmentTypeArray, ACCEPTABLEEQUIPMENTTYPE$0);
            }
        }
        
        /**
         * Sets ith "acceptableEquipmentType" element
         */
        public void setAcceptableEquipmentTypeArray(int i, java.lang.String acceptableEquipmentType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACCEPTABLEEQUIPMENTTYPE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setStringValue(acceptableEquipmentType);
            }
        }
        
        /**
         * Sets (as xml) array of all "acceptableEquipmentType" element
         */
        public void xsetAcceptableEquipmentTypeArray(org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType[]acceptableEquipmentTypeArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(acceptableEquipmentTypeArray, ACCEPTABLEEQUIPMENTTYPE$0);
            }
        }
        
        /**
         * Sets (as xml) ith "acceptableEquipmentType" element
         */
        public void xsetAcceptableEquipmentTypeArray(int i, org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType acceptableEquipmentType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().find_element_user(ACCEPTABLEEQUIPMENTTYPE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(acceptableEquipmentType);
            }
        }
        
        /**
         * Inserts the value as the ith "acceptableEquipmentType" element
         */
        public void insertAcceptableEquipmentType(int i, java.lang.String acceptableEquipmentType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(ACCEPTABLEEQUIPMENTTYPE$0, i);
                target.setStringValue(acceptableEquipmentType);
            }
        }
        
        /**
         * Appends the value as the last "acceptableEquipmentType" element
         */
        public void addAcceptableEquipmentType(java.lang.String acceptableEquipmentType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACCEPTABLEEQUIPMENTTYPE$0);
                target.setStringValue(acceptableEquipmentType);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "acceptableEquipmentType" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType insertNewAcceptableEquipmentType(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().insert_element_user(ACCEPTABLEEQUIPMENTTYPE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "acceptableEquipmentType" element
         */
        public org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType addNewAcceptableEquipmentType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType target = null;
                target = (org.tmforum.mtop.nrf.xsd.com.v1.EquipmentObjectTypeType)get_store().add_element_user(ACCEPTABLEEQUIPMENTTYPE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "acceptableEquipmentType" element
         */
        public void removeAcceptableEquipmentType(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ACCEPTABLEEQUIPMENTTYPE$0, i);
            }
        }
    }
}
