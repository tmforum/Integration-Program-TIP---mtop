﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_tiFileName = "typeTreeIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function TN (href, prefix, ns, name, relation, simpletypeflag, children) {
	this.href = href;
	this.prefix = prefix;
	this.namespace = ns;
	this.name = name;
	this.relation = relation;
	this.simpletypeflag = simpletypeflag;
	this.children = children;

	this.hasChild = (children != null) && (children.length>0);	
}

function T (typeTree)
{
	this.typeTree = typeTree;
}

function typetree_showAllTypes() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_tiFileName;
}

function typetree_filterTypes () {
	parent._href = "xsd/" + xsd_tiFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");
}

function typetree_showTypes() {
	if (parent._xsdNsFilter == null) {
		typetree_setFilterToAll();
	}

	var nsList = parent._xsdNsFilter;
	var typetrees = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		typetrees [i] = typetreeDB [nsList[i]];	
		nss[i] = nsList[i];
	}		
	
	typetree_showTree (nss, typetrees); 
}

function typetree_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in typetreeDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}


	parent._xsdNsFilter = nsList;
}


function typetree_showTree (nsList, typetrees) {
	for (var i=0; i<nsList.length; i++) {
		var fpath = typetreeNSMap[nsList[i]];
		
		var str = '<div class="nsBox"><div class="itemNS">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+fpath+
			'" title="'+encodeURI(nsList[i])+
			'" target="'+target+'">'+encodeURI(nsList[i])+'</a></nobr></div>'+
			'<div style="margin-left: 0.5em">';		

		document.write (str);

		typetree_outputList (typetrees[i].typeTree);
		

		document.write ('</div></div>');
	}
} 

function typetree_outputList (list) {
	for (var i=0; i<list.length; i++) {
		typetree_outputTree (list[i]);
	}
}

function typetree_outputTree (node) {
	if (node.hasChild == false) {
		typetree_outputLeaf (node);
	} else {
		typetree_outputNonLeaf (node);
	}
}


function typetree_outputLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node)
	} else {
		nodeStr = anchorString (node)
	}

	str = '<span class="leaf"><nobr>' +
		  '<img src="img/leaf.gif" hspace="2" align="middle">' + 
		  nodeStr + '</nobr></span><br />';

	document.write (str);
}

function prefixedAnchorString (node) {
	return  '<a class="chref" href="'+node.href+
			'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+
			node.prefix+':'+'</a>'+
			'<a class="chref" href="'+node.href+'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);
}

function anchorString (node) {
	return 	'<a class="chref" href="'+node.href+'" target="'+target+'"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);

}

function typetree_outputNonLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node);
	} else {
		nodeStr = anchorString (node);
	}
		
	str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			nodeStr +
			'</nobr></div>'+
			'<div style="margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		typetree_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function typetree_getNodeIcon(node) {
	var rStr = null;
	if (node.relation == "none") {
		rStr = "";
	} else if (node.relation == "extension") {
		rStr = '<img alt="derived by extension" border="0" hspace="2" align="middle" src="img/extension.gif">';
	
	} else if (node.relation == "restriction") {
		rStr = '<img alt="derived by restriction" border="0" hspace="2" align="middle" src="img/restriction.gif">';
	
	} else if (node.relation == "list") {
		rStr = '<img alt="derived by list" border="0" hspace="2" align="middle" src="img/list.gif">';
	
	} else if (node.relation == "union") {
		rStr = '<img alt="derived by union" border="0" hspace="2" align="middle" src="img/union.gif">';
	
	}
	
	var typeStr = null;
	
	if (node.simpletypeflag) {
		typeStr = '<img alt="simple type" border="0" hspace="2" align="middle" src="img/simple.gif">'; 
	} else {
		typeStr = '<img alt="complex type" border="0" hspace="2" align="middle" src="img/complex.gif">';	
	} 

	return typeStr + rStr;
}

var typetreeDB = new Array();
var typetreeNSMap = new Array();

typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new T (new Array (new TN("3/complextype/CommonObjectInfoType.html","","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("6/complextype/CommonServiceInfoType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","CommonServiceInfoType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "3/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new T (new Array (new TN("5/complextype/AliasNameListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AliasNameListType","none",false,null),new TN("5/complextype/AnyListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AnyListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#anyURI","xsd","http://www.w3.org/2001/XMLSchema","anyURI","none",true,new Array(new TN("5/simpletype/QueryDialectEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryDialectEnumType","restriction",true,null),new TN("5/simpletype/QueryDialectTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryDialectTypeType","restriction",true,null))),new TN("http://www.w3.org/TR/xmlschema-2/#date","xsd","http://www.w3.org/2001/XMLSchema","date","none",true,new Array(new TN("5/simpletype/ManufactureDateType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufactureDateType","restriction",true,null))),new TN("5/complextype/MultiEventInventoryAttributesType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","MultiEventInventoryAttributesType","none",false,null),new TN("5/complextype/NameAndAnyValueListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndAnyValueListType","none",false,null),new TN("5/complextype/NameAndAnyValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndAnyValueType","none",false,null),new TN("5/complextype/NameAndStringValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndStringValueType","none",false,null),new TN("5/complextype/NameAndValueStringListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndValueStringListType","none",false,null),new TN("5/complextype/NotificationIdentifierListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierListType","none",false,null),new TN("5/complextype/QueryExpressionType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryExpressionType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("5/simpletype/DiscoveredNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","DiscoveredNameType","restriction",true,null),new TN("5/simpletype/LocationType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","LocationType","restriction",true,null),new TN("5/simpletype/ManufacturerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufacturerType","restriction",true,null),new TN("5/simpletype/NetworkAccessDomainType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NetworkAccessDomainType","restriction",true,null),new TN("5/simpletype/NotificationIdentifierType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierType","restriction",true,null),new TN("5/simpletype/ObjectEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectEnumType","restriction",true,null),new TN("5/simpletype/ObjectTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectTypeType","restriction",true,null),new TN("5/simpletype/OwnerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","OwnerType","restriction",true,null),new TN("5/simpletype/ProductNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ProductNameType","restriction",true,null),new TN("5/simpletype/UserLabelType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","UserLabelType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "5/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] =  new T (new Array (new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("8/simpletype/ActivityStatusEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","ActivityStatusEnumType","restriction",true,new Array(new TN("8/complextype/ActivityStatusType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","ActivityStatusType","restriction",false,null))),new TN("8/simpletype/CommunicationPatternType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","CommunicationPatternType","restriction",true,null),new TN("8/simpletype/CommunicationStyleType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","CommunicationStyleType","restriction",true,null),new TN("8/simpletype/CompressionEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","CompressionEnumType","restriction",true,new Array(new TN("8/complextype/CompressionTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","CompressionTypeType","restriction",false,null))),new TN("8/simpletype/MessageTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","MessageTypeType","restriction",true,null),new TN("8/simpletype/PackingEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","PackingEnumType","restriction",true,new Array(new TN("8/complextype/PackingTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","PackingTypeType","restriction",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] = "8/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] =  new T (new Array (new TN("7/complextype/AllExceptionsType.html","","http://www.tmforum.org/mtop/fmw/xsd/msg/v1","AllExceptionsType","none",false,new Array(new TN("7/complextype/GetAllDataIteratorExceptionType.html","","http://www.tmforum.org/mtop/fmw/xsd/msg/v1","GetAllDataIteratorExceptionType","restriction",false,null))),new TN("7/complextype/BaseExceptionMessageType.html","","http://www.tmforum.org/mtop/fmw/xsd/msg/v1","BaseExceptionMessageType","none",false,null),new TN("7/complextype/GetAllDataIteratorRequestType.html","","http://www.tmforum.org/mtop/fmw/xsd/msg/v1","GetAllDataIteratorRequestType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] = "7/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new T (new Array (new TN("1/complextype/NamingAttributeListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeListType","none",false,null),new TN("1/complextype/NamingAttributeType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeType","none",false,null),new TN("1/complextype/RelativeDistinguishNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","RelativeDistinguishNameType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "1/index.html";
typetreeDB ["http://www.tmforum.org/mtop/msi/xsd/sir/v1"] =  new T (new Array (new TN("4/complextype/ServiceInventoryDataType.html","","http://www.tmforum.org/mtop/msi/xsd/sir/v1","ServiceInventoryDataType","none",false,null),new TN("4/complextype/SimpleServiceFilterType.html","","http://www.tmforum.org/mtop/msi/xsd/sir/v1","SimpleServiceFilterType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("4/simpletype/GranularityType.html","","http://www.tmforum.org/mtop/msi/xsd/sir/v1","GranularityType","restriction",true,null),new TN("4/simpletype/ServiceObjectEnumType.html","","http://www.tmforum.org/mtop/msi/xsd/sir/v1","ServiceObjectEnumType","restriction",true,null),new TN("4/simpletype/ServiceObjectTypeType.html","","http://www.tmforum.org/mtop/msi/xsd/sir/v1","ServiceObjectTypeType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/msi/xsd/sir/v1"] = "4/index.html";
typetreeDB ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] =  new T (new Array (new TN("3/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("6/complextype/CommonServiceInfoType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","CommonServiceInfoType","restriction",false,new Array(new TN("2/complextype/SapSpecificationType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","SapSpecificationType","extension",false,null),new TN("2/complextype/ServiceAccessPointType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceAccessPointType","extension",false,null),new TN("2/complextype/ServiceCatalogType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceCatalogType","extension",false,null),new TN("2/complextype/ServiceSpecCharacteristicType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceSpecCharacteristicType","extension",false,null),new TN("2/complextype/ServiceSpecificationType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceSpecificationType","extension",false,null),new TN("2/complextype/ServiceType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] = "6/index.html";
typetreeDB ["http://www.tmforum.org/mtop/sb/xsd/svc/v1"] =  new T (new Array (new TN("3/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("6/complextype/CommonServiceInfoType.html","csi","http://www.tmforum.org/mtop/sb/xsd/csi/v1","CommonServiceInfoType","restriction",false,new Array(new TN("2/complextype/SapSpecificationType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","SapSpecificationType","extension",false,null),new TN("2/complextype/ServiceAccessPointType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceAccessPointType","extension",false,null),new TN("2/complextype/ServiceCatalogType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceCatalogType","extension",false,null),new TN("2/complextype/ServiceSpecCharacteristicType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceSpecCharacteristicType","extension",false,null),new TN("2/complextype/ServiceSpecificationType.html","tns","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceSpecificationType","extension",false,new Array(new TN("2/complextype/ServiceDefinitionType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceDefinitionType","extension",false,null),new TN("2/complextype/ServiceTemplateType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceTemplateType","extension",false,null))),new TN("2/complextype/ServiceType.html","tns","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceType","extension",false,new Array(new TN("2/complextype/CustomerFacingServiceType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","CustomerFacingServiceType","extension",false,null),new TN("2/complextype/ResourceFacingServiceType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ResourceFacingServiceType","extension",false,null))))))),new TN("2/complextype/PartyRoleType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","PartyRoleType","none",false,new Array(new TN("2/complextype/SubscriberType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","SubscriberType","restriction",false,null),new TN("2/complextype/UserType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","UserType","restriction",false,null))),new TN("2/complextype/ServiceCharacteristicValueType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceCharacteristicValueType","none",false,null),new TN("2/complextype/ServiceSpecCharacteristicUseType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceSpecCharacteristicUseType","none",false,null),new TN("2/complextype/ServiceSpecCharacteristicValueType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceSpecCharacteristicValueType","none",false,null),new TN("2/complextype/ServiceSpecCharInUseType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceSpecCharInUseType","none",false,null),new TN("2/complextype/ServiceSpecificationTypeType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceSpecificationTypeType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("2/simpletype/AdminStateType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","AdminStateType","restriction",true,null),new TN("2/simpletype/OperationalStateType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","OperationalStateType","restriction",true,null),new TN("2/simpletype/ServiceDefinitionStatusType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceDefinitionStatusType","restriction",true,null),new TN("2/simpletype/ServiceStateType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceStateType","restriction",true,null),new TN("2/simpletype/ServiceTemplateStatusType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","ServiceTemplateStatusType","restriction",true,null),new TN("2/simpletype/StartModeType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","StartModeType","restriction",true,null))),new TN("2/complextype/TimePeriodType.html","","http://www.tmforum.org/mtop/sb/xsd/svc/v1","TimePeriodType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/sb/xsd/svc/v1"] = "2/index.html";
								   


