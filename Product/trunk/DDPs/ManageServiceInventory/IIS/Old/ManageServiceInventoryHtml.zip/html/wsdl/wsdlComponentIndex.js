﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/msi/wsdl/sir/v1-0"] =  new WC (
					new Array(new WCN("9/service/ServiceInventoryRetrievalHttp.html","ServiceInventoryRetrievalHttp",false,null),new WCN("9/service/ServiceInventoryRetrievalJms.html","ServiceInventoryRetrievalJms",false,null)),
					new Array(new WCN("9/message/getServiceInventoryException.html","getServiceInventoryException",false,null),new WCN("9/message/getServiceInventoryIteratorException.html","getServiceInventoryIteratorException",false,null),new WCN("9/message/getServiceInventoryIteratorRequest.html","getServiceInventoryIteratorRequest",false,null),new WCN("9/message/getServiceInventoryIteratorResponse.html","getServiceInventoryIteratorResponse",false,null),new WCN("9/message/getServiceInventoryRequest.html","getServiceInventoryRequest",false,null),new WCN("9/message/getServiceInventoryResponse.html","getServiceInventoryResponse",false,null)),
					new Array(new WCN("9/porttype/ServiceInventoryRetrieval_MSG.html","ServiceInventoryRetrieval_MSG",false,new Array(new WCN("9/operation/getServiceInventory_2.html","getServiceInventory",false,null),new WCN("9/operation/getServiceInventoryIterator_3.html","getServiceInventoryIterator",false,null))),new WCN("9/porttype/ServiceInventoryRetrieval_RPC.html","ServiceInventoryRetrieval_RPC",false,new Array(new WCN("9/operation/getServiceInventory_0.html","getServiceInventory",false,null),new WCN("9/operation/getServiceInventoryIterator_1.html","getServiceInventoryIterator",false,null)))),
					new Array(new WCN("9/binding/ServiceInventoryRetrievalSoapHttpBinding.html","ServiceInventoryRetrievalSoapHttpBinding",false,new Array(new WCN("9/operation/getServiceInventory_0.html","getServiceInventory",false,null),new WCN("9/operation/getServiceInventoryIterator_1.html","getServiceInventoryIterator",false,null))),new WCN("9/binding/ServiceInventoryRetrievalSoapJmsBinding.html","ServiceInventoryRetrievalSoapJmsBinding",false,new Array(new WCN("9/operation/getServiceInventory_2.html","getServiceInventory",false,null),new WCN("9/operation/getServiceInventoryIterator_3.html","getServiceInventoryIterator",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/msi/wsdl/sir/v1-0"] = "9/index.html";
