/*
 * XML Type:  ObjectDiscoveryType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/odis/v1
 * Java type: org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.odis.v1.impl;
/**
 * An XML ObjectDiscoveryType(@http://www.tmforum.org/mtop/fmw/xsd/odis/v1).
 *
 * This is a complex type.
 */
public class ObjectDiscoveryTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationTypeImpl implements org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType
{
    
    public ObjectDiscoveryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DISCOVEREDNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odis/v1", "discoveredName");
    private static final javax.xml.namespace.QName OSTIME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odis/v1", "osTime");
    
    
    /**
     * Gets the "discoveredName" element
     */
    public java.lang.String getDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCOVEREDNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "discoveredName" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType xgetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().find_element_user(DISCOVEREDNAME$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "discoveredName" element
     */
    public boolean isSetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DISCOVEREDNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "discoveredName" element
     */
    public void setDiscoveredName(java.lang.String discoveredName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCOVEREDNAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DISCOVEREDNAME$0);
            }
            target.setStringValue(discoveredName);
        }
    }
    
    /**
     * Sets (as xml) the "discoveredName" element
     */
    public void xsetDiscoveredName(org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType discoveredName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().find_element_user(DISCOVEREDNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().add_element_user(DISCOVEREDNAME$0);
            }
            target.set(discoveredName);
        }
    }
    
    /**
     * Unsets the "discoveredName" element
     */
    public void unsetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DISCOVEREDNAME$0, 0);
        }
    }
    
    /**
     * Gets the "osTime" element
     */
    public java.util.Calendar getOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSTIME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "osTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(OSTIME$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "osTime" element
     */
    public boolean isSetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OSTIME$2) != 0;
        }
    }
    
    /**
     * Sets the "osTime" element
     */
    public void setOsTime(java.util.Calendar osTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSTIME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSTIME$2);
            }
            target.setCalendarValue(osTime);
        }
    }
    
    /**
     * Sets (as xml) the "osTime" element
     */
    public void xsetOsTime(org.apache.xmlbeans.XmlDateTime osTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(OSTIME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(OSTIME$2);
            }
            target.set(osTime);
        }
    }
    
    /**
     * Unsets the "osTime" element
     */
    public void unsetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OSTIME$2, 0);
        }
    }
}
