/*
 * XML Type:  LayeredParametersListType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/lp/v1
 * Java type: org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.lp.v1.impl;
/**
 * An XML LayeredParametersListType(@http://www.tmforum.org/mtop/nrb/xsd/lp/v1).
 *
 * This is a complex type.
 */
public class LayeredParametersListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersListType
{
    
    public LayeredParametersListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LAYEREDPARAMETERS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/lp/v1", "layeredParameters");
    
    
    /**
     * Gets a List of "layeredParameters" elements
     */
    public java.util.List<org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType> getLayeredParametersList()
    {
        final class LayeredParametersList extends java.util.AbstractList<org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType>
        {
            public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType get(int i)
                { return LayeredParametersListTypeImpl.this.getLayeredParametersArray(i); }
            
            public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType set(int i, org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType o)
            {
                org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType old = LayeredParametersListTypeImpl.this.getLayeredParametersArray(i);
                LayeredParametersListTypeImpl.this.setLayeredParametersArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType o)
                { LayeredParametersListTypeImpl.this.insertNewLayeredParameters(i).set(o); }
            
            public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType remove(int i)
            {
                org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType old = LayeredParametersListTypeImpl.this.getLayeredParametersArray(i);
                LayeredParametersListTypeImpl.this.removeLayeredParameters(i);
                return old;
            }
            
            public int size()
                { return LayeredParametersListTypeImpl.this.sizeOfLayeredParametersArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new LayeredParametersList();
        }
    }
    
    /**
     * Gets array of all "layeredParameters" elements
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType[] getLayeredParametersArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(LAYEREDPARAMETERS$0, targetList);
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType[] result = new org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "layeredParameters" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType getLayeredParametersArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(LAYEREDPARAMETERS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "layeredParameters" element
     */
    public int sizeOfLayeredParametersArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYEREDPARAMETERS$0);
        }
    }
    
    /**
     * Sets array of all "layeredParameters" element
     */
    public void setLayeredParametersArray(org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType[] layeredParametersArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(layeredParametersArray, LAYEREDPARAMETERS$0);
        }
    }
    
    /**
     * Sets ith "layeredParameters" element
     */
    public void setLayeredParametersArray(int i, org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType layeredParameters)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().find_element_user(LAYEREDPARAMETERS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(layeredParameters);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "layeredParameters" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType insertNewLayeredParameters(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().insert_element_user(LAYEREDPARAMETERS$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "layeredParameters" element
     */
    public org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType addNewLayeredParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lp.v1.LayeredParametersType)get_store().add_element_user(LAYEREDPARAMETERS$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "layeredParameters" element
     */
    public void removeLayeredParameters(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYEREDPARAMETERS$0, i);
        }
    }
}
