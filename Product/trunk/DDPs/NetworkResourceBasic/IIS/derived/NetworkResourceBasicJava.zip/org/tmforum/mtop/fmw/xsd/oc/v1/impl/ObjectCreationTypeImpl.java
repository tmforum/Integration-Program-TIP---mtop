/*
 * XML Type:  ObjectCreationType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/oc/v1
 * Java type: org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.oc.v1.impl;
/**
 * An XML ObjectCreationType(@http://www.tmforum.org/mtop/fmw/xsd/oc/v1).
 *
 * This is a complex type.
 */
public class ObjectCreationTypeImpl extends org.tmforum.mtop.fmw.xsd.ei.v1.impl.EventInformationTypeImpl implements org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType
{
    
    public ObjectCreationTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/oc/v1", "object");
    
    
    /**
     * Gets the "object" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(OBJECT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "object" element
     */
    public boolean isSetObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECT$0) != 0;
        }
    }
    
    /**
     * Sets the "object" element
     */
    public void setObject(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType object)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(OBJECT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(OBJECT$0);
            }
            target.set(object);
        }
    }
    
    /**
     * Appends and returns a new empty "object" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(OBJECT$0);
            return target;
        }
    }
    
    /**
     * Unsets the "object" element
     */
    public void unsetObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECT$0, 0);
        }
    }
}
