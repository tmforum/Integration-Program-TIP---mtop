/*
 * XML Type:  VendorResourceObjectListType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/vro/v1
 * Java type: org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.vro.v1.impl;
/**
 * An XML VendorResourceObjectListType(@http://www.tmforum.org/mtop/nrb/xsd/vro/v1).
 *
 * This is a complex type.
 */
public class VendorResourceObjectListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectListType
{
    
    public VendorResourceObjectListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VENDORRESOURCEOBJECT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/vro/v1", "vendorResourceObject");
    
    
    /**
     * Gets a List of "vendorResourceObject" elements
     */
    public java.util.List<org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType> getVendorResourceObjectList()
    {
        final class VendorResourceObjectList extends java.util.AbstractList<org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType>
        {
            public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType get(int i)
                { return VendorResourceObjectListTypeImpl.this.getVendorResourceObjectArray(i); }
            
            public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType set(int i, org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType o)
            {
                org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType old = VendorResourceObjectListTypeImpl.this.getVendorResourceObjectArray(i);
                VendorResourceObjectListTypeImpl.this.setVendorResourceObjectArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType o)
                { VendorResourceObjectListTypeImpl.this.insertNewVendorResourceObject(i).set(o); }
            
            public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType remove(int i)
            {
                org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType old = VendorResourceObjectListTypeImpl.this.getVendorResourceObjectArray(i);
                VendorResourceObjectListTypeImpl.this.removeVendorResourceObject(i);
                return old;
            }
            
            public int size()
                { return VendorResourceObjectListTypeImpl.this.sizeOfVendorResourceObjectArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new VendorResourceObjectList();
        }
    }
    
    /**
     * Gets array of all "vendorResourceObject" elements
     */
    public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType[] getVendorResourceObjectArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(VENDORRESOURCEOBJECT$0, targetList);
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType[] result = new org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "vendorResourceObject" element
     */
    public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType getVendorResourceObjectArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType)get_store().find_element_user(VENDORRESOURCEOBJECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "vendorResourceObject" element
     */
    public int sizeOfVendorResourceObjectArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDORRESOURCEOBJECT$0);
        }
    }
    
    /**
     * Sets array of all "vendorResourceObject" element
     */
    public void setVendorResourceObjectArray(org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType[] vendorResourceObjectArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(vendorResourceObjectArray, VENDORRESOURCEOBJECT$0);
        }
    }
    
    /**
     * Sets ith "vendorResourceObject" element
     */
    public void setVendorResourceObjectArray(int i, org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType vendorResourceObject)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType)get_store().find_element_user(VENDORRESOURCEOBJECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(vendorResourceObject);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "vendorResourceObject" element
     */
    public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType insertNewVendorResourceObject(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType)get_store().insert_element_user(VENDORRESOURCEOBJECT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "vendorResourceObject" element
     */
    public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType addNewVendorResourceObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType)get_store().add_element_user(VENDORRESOURCEOBJECT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "vendorResourceObject" element
     */
    public void removeVendorResourceObject(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDORRESOURCEOBJECT$0, i);
        }
    }
}
