/*
 * An XML document type.
 * Localname: resourceAttributeValueChange
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1
 * Java type: org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.rscavc.v1.impl;
/**
 * A document containing one resourceAttributeValueChange(@http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1) element.
 *
 * This is a complex type.
 */
public class ResourceAttributeValueChangeDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeDocument
{
    
    public ResourceAttributeValueChangeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RESOURCEATTRIBUTEVALUECHANGE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1", "resourceAttributeValueChange");
    
    
    /**
     * Gets the "resourceAttributeValueChange" element
     */
    public org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType getResourceAttributeValueChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType)get_store().find_element_user(RESOURCEATTRIBUTEVALUECHANGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "resourceAttributeValueChange" element
     */
    public void setResourceAttributeValueChange(org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType resourceAttributeValueChange)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType)get_store().find_element_user(RESOURCEATTRIBUTEVALUECHANGE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType)get_store().add_element_user(RESOURCEATTRIBUTEVALUECHANGE$0);
            }
            target.set(resourceAttributeValueChange);
        }
    }
    
    /**
     * Appends and returns a new empty "resourceAttributeValueChange" element
     */
    public org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType addNewResourceAttributeValueChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType)get_store().add_element_user(RESOURCEATTRIBUTEVALUECHANGE$0);
            return target;
        }
    }
}
