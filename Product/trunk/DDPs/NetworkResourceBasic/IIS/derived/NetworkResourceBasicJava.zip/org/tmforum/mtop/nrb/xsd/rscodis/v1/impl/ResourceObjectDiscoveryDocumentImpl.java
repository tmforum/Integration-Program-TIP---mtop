/*
 * An XML document type.
 * Localname: resourceObjectDiscovery
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1
 * Java type: org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.rscodis.v1.impl;
/**
 * A document containing one resourceObjectDiscovery(@http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1) element.
 *
 * This is a complex type.
 */
public class ResourceObjectDiscoveryDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryDocument
{
    
    public ResourceObjectDiscoveryDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RESOURCEOBJECTDISCOVERY$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1", "resourceObjectDiscovery");
    
    
    /**
     * Gets the "resourceObjectDiscovery" element
     */
    public org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType getResourceObjectDiscovery()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType)get_store().find_element_user(RESOURCEOBJECTDISCOVERY$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "resourceObjectDiscovery" element
     */
    public void setResourceObjectDiscovery(org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType resourceObjectDiscovery)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType)get_store().find_element_user(RESOURCEOBJECTDISCOVERY$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType)get_store().add_element_user(RESOURCEOBJECTDISCOVERY$0);
            }
            target.set(resourceObjectDiscovery);
        }
    }
    
    /**
     * Appends and returns a new empty "resourceObjectDiscovery" element
     */
    public org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType addNewResourceObjectDiscovery()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscodis.v1.ResourceObjectDiscoveryType)get_store().add_element_user(RESOURCEOBJECTDISCOVERY$0);
            return target;
        }
    }
}
