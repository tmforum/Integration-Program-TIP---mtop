/*
 * An XML document type.
 * Localname: commonObjectSetData
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cosd/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cosd.v1.impl;
/**
 * A document containing one commonObjectSetData(@http://www.tmforum.org/mtop/fmw/xsd/cosd/v1) element.
 *
 * This is a complex type.
 */
public class CommonObjectSetDataDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataDocument
{
    
    public CommonObjectSetDataDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONOBJECTSETDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cosd/v1", "commonObjectSetData");
    
    
    /**
     * Gets the "commonObjectSetData" element
     */
    public org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType getCommonObjectSetData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType)get_store().find_element_user(COMMONOBJECTSETDATA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonObjectSetData" element
     */
    public void setCommonObjectSetData(org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType commonObjectSetData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType)get_store().find_element_user(COMMONOBJECTSETDATA$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType)get_store().add_element_user(COMMONOBJECTSETDATA$0);
            }
            target.set(commonObjectSetData);
        }
    }
    
    /**
     * Appends and returns a new empty "commonObjectSetData" element
     */
    public org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType addNewCommonObjectSetData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType)get_store().add_element_user(COMMONOBJECTSETDATA$0);
            return target;
        }
    }
}
