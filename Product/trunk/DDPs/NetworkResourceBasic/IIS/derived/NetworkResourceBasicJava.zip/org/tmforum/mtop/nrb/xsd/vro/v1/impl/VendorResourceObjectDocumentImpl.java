/*
 * An XML document type.
 * Localname: vendorResourceObject
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/vro/v1
 * Java type: org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.vro.v1.impl;
/**
 * A document containing one vendorResourceObject(@http://www.tmforum.org/mtop/nrb/xsd/vro/v1) element.
 *
 * This is a complex type.
 */
public class VendorResourceObjectDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectDocument
{
    
    public VendorResourceObjectDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VENDORRESOURCEOBJECT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/vro/v1", "vendorResourceObject");
    
    
    /**
     * Gets the "vendorResourceObject" element
     */
    public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType getVendorResourceObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType)get_store().find_element_user(VENDORRESOURCEOBJECT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "vendorResourceObject" element
     */
    public void setVendorResourceObject(org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType vendorResourceObject)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType)get_store().find_element_user(VENDORRESOURCEOBJECT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType)get_store().add_element_user(VENDORRESOURCEOBJECT$0);
            }
            target.set(vendorResourceObject);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorResourceObject" element
     */
    public org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType addNewVendorResourceObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType target = null;
            target = (org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType)get_store().add_element_user(VENDORRESOURCEOBJECT$0);
            return target;
        }
    }
}
