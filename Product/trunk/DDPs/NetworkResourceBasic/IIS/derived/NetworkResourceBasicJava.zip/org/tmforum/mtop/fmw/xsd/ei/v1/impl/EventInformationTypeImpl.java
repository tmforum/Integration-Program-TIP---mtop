/*
 * XML Type:  EventInformationType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/ei/v1
 * Java type: org.tmforum.mtop.fmw.xsd.ei.v1.EventInformationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.ei.v1.impl;
/**
 * An XML EventInformationType(@http://www.tmforum.org/mtop/fmw/xsd/ei/v1).
 *
 * This is a complex type.
 */
public class EventInformationTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationTypeImpl implements org.tmforum.mtop.fmw.xsd.ei.v1.EventInformationType
{
    
    public EventInformationTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/ei/v1", "objectType");
    private static final javax.xml.namespace.QName OBJECTNAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/ei/v1", "objectName");
    private static final javax.xml.namespace.QName OSTIME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/ei/v1", "osTime");
    
    
    /**
     * Gets the "objectType" element
     */
    public java.lang.String getObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "objectType" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "objectType" element
     */
    public boolean isSetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "objectType" element
     */
    public void setObjectType(java.lang.String objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OBJECTTYPE$0);
            }
            target.setStringValue(objectType);
        }
    }
    
    /**
     * Sets (as xml) the "objectType" element
     */
    public void xsetObjectType(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().add_element_user(OBJECTTYPE$0);
            }
            target.set(objectType);
        }
    }
    
    /**
     * Unsets the "objectType" element
     */
    public void unsetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OBJECTNAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "objectName" element
     */
    public boolean isSetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTNAME$2) != 0;
        }
    }
    
    /**
     * Sets the "objectName" element
     */
    public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType objectName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OBJECTNAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OBJECTNAME$2);
            }
            target.set(objectName);
        }
    }
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OBJECTNAME$2);
            return target;
        }
    }
    
    /**
     * Unsets the "objectName" element
     */
    public void unsetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTNAME$2, 0);
        }
    }
    
    /**
     * Gets the "osTime" element
     */
    public java.util.Calendar getOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSTIME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "osTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(OSTIME$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "osTime" element
     */
    public boolean isSetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OSTIME$4) != 0;
        }
    }
    
    /**
     * Sets the "osTime" element
     */
    public void setOsTime(java.util.Calendar osTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSTIME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSTIME$4);
            }
            target.setCalendarValue(osTime);
        }
    }
    
    /**
     * Sets (as xml) the "osTime" element
     */
    public void xsetOsTime(org.apache.xmlbeans.XmlDateTime osTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(OSTIME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(OSTIME$4);
            }
            target.set(osTime);
        }
    }
    
    /**
     * Unsets the "osTime" element
     */
    public void unsetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OSTIME$4, 0);
        }
    }
}
