/*
 * An XML document type.
 * Localname: resourceObjectDeletion
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1
 * Java type: org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.rscodel.v1.impl;
/**
 * A document containing one resourceObjectDeletion(@http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1) element.
 *
 * This is a complex type.
 */
public class ResourceObjectDeletionDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionDocument
{
    
    public ResourceObjectDeletionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RESOURCEOBJECTDELETION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1", "resourceObjectDeletion");
    
    
    /**
     * Gets the "resourceObjectDeletion" element
     */
    public org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType getResourceObjectDeletion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType)get_store().find_element_user(RESOURCEOBJECTDELETION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "resourceObjectDeletion" element
     */
    public void setResourceObjectDeletion(org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType resourceObjectDeletion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType)get_store().find_element_user(RESOURCEOBJECTDELETION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType)get_store().add_element_user(RESOURCEOBJECTDELETION$0);
            }
            target.set(resourceObjectDeletion);
        }
    }
    
    /**
     * Appends and returns a new empty "resourceObjectDeletion" element
     */
    public org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType addNewResourceObjectDeletion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType target = null;
            target = (org.tmforum.mtop.nrb.xsd.rscodel.v1.ResourceObjectDeletionType)get_store().add_element_user(RESOURCEOBJECTDELETION$0);
            return target;
        }
    }
}
