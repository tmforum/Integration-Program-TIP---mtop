/*
 * XML Type:  AttributeValueChangeType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/avc/v1
 * Java type: org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.avc.v1.impl;
/**
 * An XML AttributeValueChangeType(@http://www.tmforum.org/mtop/fmw/xsd/avc/v1).
 *
 * This is a complex type.
 */
public class AttributeValueChangeTypeImpl extends org.tmforum.mtop.fmw.xsd.ei.v1.impl.EventInformationTypeImpl implements org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType
{
    
    public AttributeValueChangeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ATTRIBUTELIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/avc/v1", "attributeList");
    
    
    /**
     * Gets the "attributeList" element
     */
    public org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList getAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList target = null;
            target = (org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList)get_store().find_element_user(ATTRIBUTELIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "attributeList" element
     */
    public boolean isSetAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ATTRIBUTELIST$0) != 0;
        }
    }
    
    /**
     * Sets the "attributeList" element
     */
    public void setAttributeList(org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList attributeList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList target = null;
            target = (org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList)get_store().find_element_user(ATTRIBUTELIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList)get_store().add_element_user(ATTRIBUTELIST$0);
            }
            target.set(attributeList);
        }
    }
    
    /**
     * Appends and returns a new empty "attributeList" element
     */
    public org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList addNewAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList target = null;
            target = (org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList)get_store().add_element_user(ATTRIBUTELIST$0);
            return target;
        }
    }
    
    /**
     * Unsets the "attributeList" element
     */
    public void unsetAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ATTRIBUTELIST$0, 0);
        }
    }
    /**
     * An XML attributeList(@http://www.tmforum.org/mtop/fmw/xsd/avc/v1).
     *
     * This is a complex type.
     */
    public static class AttributeListImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType.AttributeList
    {
        
        public AttributeListImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
