/*
 * XML Type:  M3100.NALMTIIntervalType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1.impl;
/**
 * An XML M3100.NALMTIIntervalType(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
 *
 * This is a union type. Instances are of one of the following types:
 *     org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType$Member
 *     org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType$Member2
 */
public class M3100NALMTIIntervalTypeImpl extends org.apache.xmlbeans.impl.values.XmlUnionImpl implements org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType, org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType.Member, org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType.Member2
{
    
    public M3100NALMTIIntervalTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected M3100NALMTIIntervalTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
    /**
     * An anonymous inner XML type.
     *
     * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType$Member.
     */
    public static class MemberImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType.Member
    {
        
        public MemberImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType, false);
        }
        
        protected MemberImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
        {
            super(sType, b);
        }
    }
    /**
     * An anonymous inner XML type.
     *
     * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType$Member2.
     */
    public static class MemberImpl2 extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements org.tmforum.mtop.nrb.xsd.itu.v1.M3100NALMTIIntervalType.Member2
    {
        
        public MemberImpl2(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType, false);
        }
        
        protected MemberImpl2(org.apache.xmlbeans.SchemaType sType, boolean b)
        {
            super(sType, b);
        }
    }
}
