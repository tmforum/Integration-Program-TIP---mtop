/*
 * XML Type:  VendorResourceObjectType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/vro/v1
 * Java type: org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.vro.v1.impl;
/**
 * An XML VendorResourceObjectType(@http://www.tmforum.org/mtop/nrb/xsd/vro/v1).
 *
 * This is a complex type.
 */
public class VendorResourceObjectTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nrb.xsd.vro.v1.VendorResourceObjectType
{
    
    public VendorResourceObjectTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VENDOROBJECTTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/vro/v1", "vendorObjectType");
    
    
    /**
     * Gets the "vendorObjectType" element
     */
    public java.lang.String getVendorObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VENDOROBJECTTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "vendorObjectType" element
     */
    public org.apache.xmlbeans.XmlString xgetVendorObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VENDOROBJECTTYPE$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "vendorObjectType" element
     */
    public void setVendorObjectType(java.lang.String vendorObjectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VENDOROBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VENDOROBJECTTYPE$0);
            }
            target.setStringValue(vendorObjectType);
        }
    }
    
    /**
     * Sets (as xml) the "vendorObjectType" element
     */
    public void xsetVendorObjectType(org.apache.xmlbeans.XmlString vendorObjectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VENDOROBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VENDOROBJECTTYPE$0);
            }
            target.set(vendorObjectType);
        }
    }
}
