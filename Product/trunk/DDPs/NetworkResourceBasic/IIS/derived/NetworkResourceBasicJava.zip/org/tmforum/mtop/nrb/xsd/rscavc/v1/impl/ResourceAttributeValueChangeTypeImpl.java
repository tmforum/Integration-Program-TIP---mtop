/*
 * XML Type:  ResourceAttributeValueChangeType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1
 * Java type: org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.rscavc.v1.impl;
/**
 * An XML ResourceAttributeValueChangeType(@http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1).
 *
 * This is a complex type.
 */
public class ResourceAttributeValueChangeTypeImpl extends org.tmforum.mtop.fmw.xsd.avc.v1.impl.AttributeValueChangeTypeImpl implements org.tmforum.mtop.nrb.xsd.rscavc.v1.ResourceAttributeValueChangeType
{
    
    public ResourceAttributeValueChangeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ISEDGEPOINTRELATED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1", "isEdgePointRelated");
    
    
    /**
     * Gets the "isEdgePointRelated" element
     */
    public boolean getIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEDGEPOINTRELATED$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isEdgePointRelated" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINTRELATED$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "isEdgePointRelated" element
     */
    public boolean isSetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISEDGEPOINTRELATED$0) != 0;
        }
    }
    
    /**
     * Sets the "isEdgePointRelated" element
     */
    public void setIsEdgePointRelated(boolean isEdgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEDGEPOINTRELATED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISEDGEPOINTRELATED$0);
            }
            target.setBooleanValue(isEdgePointRelated);
        }
    }
    
    /**
     * Sets (as xml) the "isEdgePointRelated" element
     */
    public void xsetIsEdgePointRelated(org.apache.xmlbeans.XmlBoolean isEdgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINTRELATED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISEDGEPOINTRELATED$0);
            }
            target.set(isEdgePointRelated);
        }
    }
    
    /**
     * Unsets the "isEdgePointRelated" element
     */
    public void unsetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISEDGEPOINTRELATED$0, 0);
        }
    }
}
