/*
 * XML Type:  ObjectDeletionType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/odel/v1
 * Java type: org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.odel.v1.impl;
/**
 * An XML ObjectDeletionType(@http://www.tmforum.org/mtop/fmw/xsd/odel/v1).
 *
 * This is a complex type.
 */
public class ObjectDeletionTypeImpl extends org.tmforum.mtop.fmw.xsd.ei.v1.impl.EventInformationTypeImpl implements org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType
{
    
    public ObjectDeletionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
