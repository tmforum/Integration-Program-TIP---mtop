/*
 * XML Type:  ResourceStateEnumType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/cri/v1
 * Java type: org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.cri.v1;


/**
 * An XML ResourceStateEnumType(@http://www.tmforum.org/mtop/nrb/xsd/cri/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType.
 */
public interface ResourceStateEnumType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ResourceStateEnumType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sF5E72DAAE08B190C350260D1EBBE059E").resolveHandle("resourcestateenumtypeda7ftype");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum INSTALLING = Enum.forString("INSTALLING");
    static final Enum INSTALLING_ACCEPTED = Enum.forString("INSTALLING_ACCEPTED");
    static final Enum INSTALLING_COMMISSIONED = Enum.forString("INSTALLING_COMMISSIONED");
    static final Enum INSTALLING_DELIVERED = Enum.forString("INSTALLING_DELIVERED");
    static final Enum INSTALLING_INSTALLED = Enum.forString("INSTALLING_INSTALLED");
    static final Enum INSTALLING_INTEGRATED = Enum.forString("INSTALLING_INTEGRATED");
    static final Enum INSTALLING_REJECTED = Enum.forString("INSTALLING_REJECTED");
    static final Enum NON_WORKING = Enum.forString("NON_WORKING");
    static final Enum PLANNING = Enum.forString("PLANNING");
    static final Enum PLANNING_INITIAL_PLAN = Enum.forString("PLANNING_INITIAL_PLAN");
    static final Enum PLANNING_ORDERED = Enum.forString("PLANNING_ORDERED");
    static final Enum PLANNING_PLANNED = Enum.forString("PLANNING_PLANNED");
    static final Enum RETIRING = Enum.forString("RETIRING");
    static final Enum RETIRING_DECOMMISSIONED = Enum.forString("RETIRING_DECOMMISSIONED");
    static final Enum RETIRING_DEINSTALLED = Enum.forString("RETIRING_DEINSTALLED");
    static final Enum RETIRING_DEINTEGRATED = Enum.forString("RETIRING_DEINTEGRATED");
    static final Enum RETIRING_RECOVERED = Enum.forString("RETIRING_RECOVERED");
    static final Enum RETIRING_STORED = Enum.forString("RETIRING_STORED");
    static final Enum RETIRING_WITHDRAWN_ACTIVE = Enum.forString("RETIRING_WITHDRAWN_ACTIVE");
    static final Enum RETIRING_WITHDRAWN_UNAVAILABLE = Enum.forString("RETIRING_WITHDRAWN_UNAVAILABLE");
    static final Enum UNKNOWN = Enum.forString("UNKNOWN");
    static final Enum WORKING = Enum.forString("WORKING");
    static final Enum WORKING_ACTIVATED = Enum.forString("WORKING_ACTIVATED");
    static final Enum WORKING_DEACTIVATED = Enum.forString("WORKING_DEACTIVATED");
    
    static final int INT_INSTALLING = Enum.INT_INSTALLING;
    static final int INT_INSTALLING_ACCEPTED = Enum.INT_INSTALLING_ACCEPTED;
    static final int INT_INSTALLING_COMMISSIONED = Enum.INT_INSTALLING_COMMISSIONED;
    static final int INT_INSTALLING_DELIVERED = Enum.INT_INSTALLING_DELIVERED;
    static final int INT_INSTALLING_INSTALLED = Enum.INT_INSTALLING_INSTALLED;
    static final int INT_INSTALLING_INTEGRATED = Enum.INT_INSTALLING_INTEGRATED;
    static final int INT_INSTALLING_REJECTED = Enum.INT_INSTALLING_REJECTED;
    static final int INT_NON_WORKING = Enum.INT_NON_WORKING;
    static final int INT_PLANNING = Enum.INT_PLANNING;
    static final int INT_PLANNING_INITIAL_PLAN = Enum.INT_PLANNING_INITIAL_PLAN;
    static final int INT_PLANNING_ORDERED = Enum.INT_PLANNING_ORDERED;
    static final int INT_PLANNING_PLANNED = Enum.INT_PLANNING_PLANNED;
    static final int INT_RETIRING = Enum.INT_RETIRING;
    static final int INT_RETIRING_DECOMMISSIONED = Enum.INT_RETIRING_DECOMMISSIONED;
    static final int INT_RETIRING_DEINSTALLED = Enum.INT_RETIRING_DEINSTALLED;
    static final int INT_RETIRING_DEINTEGRATED = Enum.INT_RETIRING_DEINTEGRATED;
    static final int INT_RETIRING_RECOVERED = Enum.INT_RETIRING_RECOVERED;
    static final int INT_RETIRING_STORED = Enum.INT_RETIRING_STORED;
    static final int INT_RETIRING_WITHDRAWN_ACTIVE = Enum.INT_RETIRING_WITHDRAWN_ACTIVE;
    static final int INT_RETIRING_WITHDRAWN_UNAVAILABLE = Enum.INT_RETIRING_WITHDRAWN_UNAVAILABLE;
    static final int INT_UNKNOWN = Enum.INT_UNKNOWN;
    static final int INT_WORKING = Enum.INT_WORKING;
    static final int INT_WORKING_ACTIVATED = Enum.INT_WORKING_ACTIVATED;
    static final int INT_WORKING_DEACTIVATED = Enum.INT_WORKING_DEACTIVATED;
    
    /**
     * Enumeration value class for org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_INSTALLING
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_INSTALLING = 1;
        static final int INT_INSTALLING_ACCEPTED = 2;
        static final int INT_INSTALLING_COMMISSIONED = 3;
        static final int INT_INSTALLING_DELIVERED = 4;
        static final int INT_INSTALLING_INSTALLED = 5;
        static final int INT_INSTALLING_INTEGRATED = 6;
        static final int INT_INSTALLING_REJECTED = 7;
        static final int INT_NON_WORKING = 8;
        static final int INT_PLANNING = 9;
        static final int INT_PLANNING_INITIAL_PLAN = 10;
        static final int INT_PLANNING_ORDERED = 11;
        static final int INT_PLANNING_PLANNED = 12;
        static final int INT_RETIRING = 13;
        static final int INT_RETIRING_DECOMMISSIONED = 14;
        static final int INT_RETIRING_DEINSTALLED = 15;
        static final int INT_RETIRING_DEINTEGRATED = 16;
        static final int INT_RETIRING_RECOVERED = 17;
        static final int INT_RETIRING_STORED = 18;
        static final int INT_RETIRING_WITHDRAWN_ACTIVE = 19;
        static final int INT_RETIRING_WITHDRAWN_UNAVAILABLE = 20;
        static final int INT_UNKNOWN = 21;
        static final int INT_WORKING = 22;
        static final int INT_WORKING_ACTIVATED = 23;
        static final int INT_WORKING_DEACTIVATED = 24;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("INSTALLING", INT_INSTALLING),
                new Enum("INSTALLING_ACCEPTED", INT_INSTALLING_ACCEPTED),
                new Enum("INSTALLING_COMMISSIONED", INT_INSTALLING_COMMISSIONED),
                new Enum("INSTALLING_DELIVERED", INT_INSTALLING_DELIVERED),
                new Enum("INSTALLING_INSTALLED", INT_INSTALLING_INSTALLED),
                new Enum("INSTALLING_INTEGRATED", INT_INSTALLING_INTEGRATED),
                new Enum("INSTALLING_REJECTED", INT_INSTALLING_REJECTED),
                new Enum("NON_WORKING", INT_NON_WORKING),
                new Enum("PLANNING", INT_PLANNING),
                new Enum("PLANNING_INITIAL_PLAN", INT_PLANNING_INITIAL_PLAN),
                new Enum("PLANNING_ORDERED", INT_PLANNING_ORDERED),
                new Enum("PLANNING_PLANNED", INT_PLANNING_PLANNED),
                new Enum("RETIRING", INT_RETIRING),
                new Enum("RETIRING_DECOMMISSIONED", INT_RETIRING_DECOMMISSIONED),
                new Enum("RETIRING_DEINSTALLED", INT_RETIRING_DEINSTALLED),
                new Enum("RETIRING_DEINTEGRATED", INT_RETIRING_DEINTEGRATED),
                new Enum("RETIRING_RECOVERED", INT_RETIRING_RECOVERED),
                new Enum("RETIRING_STORED", INT_RETIRING_STORED),
                new Enum("RETIRING_WITHDRAWN_ACTIVE", INT_RETIRING_WITHDRAWN_ACTIVE),
                new Enum("RETIRING_WITHDRAWN_UNAVAILABLE", INT_RETIRING_WITHDRAWN_UNAVAILABLE),
                new Enum("UNKNOWN", INT_UNKNOWN),
                new Enum("WORKING", INT_WORKING),
                new Enum("WORKING_ACTIVATED", INT_WORKING_ACTIVATED),
                new Enum("WORKING_DEACTIVATED", INT_WORKING_DEACTIVATED),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType newValue(java.lang.Object obj) {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) type.newValue( obj ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType newInstance() {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
