/*
 * XML Type:  MultiEventInventoryAttributesType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1.impl;
/**
 * An XML MultiEventInventoryAttributesType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is a complex type.
 */
public class MultiEventInventoryAttributesTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType
{
    
    public MultiEventInventoryAttributesTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NETIME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/gen/v1", "neTime");
    private static final javax.xml.namespace.QName EVENTINDICATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/gen/v1", "eventIndication");
    
    
    /**
     * Gets the "neTime" element
     */
    public java.util.Calendar getNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETIME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "neTime" element
     */
    public org.apache.xmlbeans.XmlDate xgetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(NETIME$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "neTime" element
     */
    public boolean isNilNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(NETIME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "neTime" element
     */
    public boolean isSetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETIME$0) != 0;
        }
    }
    
    /**
     * Sets the "neTime" element
     */
    public void setNeTime(java.util.Calendar neTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETIME$0);
            }
            target.setCalendarValue(neTime);
        }
    }
    
    /**
     * Sets (as xml) the "neTime" element
     */
    public void xsetNeTime(org.apache.xmlbeans.XmlDate neTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(NETIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(NETIME$0);
            }
            target.set(neTime);
        }
    }
    
    /**
     * Nils the "neTime" element
     */
    public void setNilNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(NETIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(NETIME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "neTime" element
     */
    public void unsetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETIME$0, 0);
        }
    }
    
    /**
     * Gets the "eventIndication" element
     */
    public java.lang.String getEventIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EVENTINDICATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "eventIndication" element
     */
    public org.apache.xmlbeans.XmlString xgetEventIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EVENTINDICATION$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "eventIndication" element
     */
    public void setEventIndication(java.lang.String eventIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EVENTINDICATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EVENTINDICATION$2);
            }
            target.setStringValue(eventIndication);
        }
    }
    
    /**
     * Sets (as xml) the "eventIndication" element
     */
    public void xsetEventIndication(org.apache.xmlbeans.XmlString eventIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(EVENTINDICATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(EVENTINDICATION$2);
            }
            target.set(eventIndication);
        }
    }
}
