/*
 * XML Type:  NotificationIdentifierListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1;


/**
 * An XML NotificationIdentifierListType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is a complex type.
 */
public interface NotificationIdentifierListType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(NotificationIdentifierListType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sF5E72DAAE08B190C350260D1EBBE059E").resolveHandle("notificationidentifierlisttype85f7type");
    
    /**
     * Gets a List of "notificationId" elements
     */
    java.util.List<java.lang.String> getNotificationIdList();
    
    /**
     * Gets array of all "notificationId" elements
     * @deprecated
     */
    java.lang.String[] getNotificationIdArray();
    
    /**
     * Gets ith "notificationId" element
     */
    java.lang.String getNotificationIdArray(int i);
    
    /**
     * Gets (as xml) a List of "notificationId" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType> xgetNotificationIdList();
    
    /**
     * Gets (as xml) array of all "notificationId" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType[] xgetNotificationIdArray();
    
    /**
     * Gets (as xml) ith "notificationId" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType xgetNotificationIdArray(int i);
    
    /**
     * Returns number of "notificationId" element
     */
    int sizeOfNotificationIdArray();
    
    /**
     * Sets array of all "notificationId" element
     */
    void setNotificationIdArray(java.lang.String[] notificationIdArray);
    
    /**
     * Sets ith "notificationId" element
     */
    void setNotificationIdArray(int i, java.lang.String notificationId);
    
    /**
     * Sets (as xml) array of all "notificationId" element
     */
    void xsetNotificationIdArray(org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType[] notificationIdArray);
    
    /**
     * Sets (as xml) ith "notificationId" element
     */
    void xsetNotificationIdArray(int i, org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType notificationId);
    
    /**
     * Inserts the value as the ith "notificationId" element
     */
    void insertNotificationId(int i, java.lang.String notificationId);
    
    /**
     * Appends the value as the last "notificationId" element
     */
    void addNotificationId(java.lang.String notificationId);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "notificationId" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType insertNewNotificationId(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "notificationId" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierType addNewNotificationId();
    
    /**
     * Removes the ith "notificationId" element
     */
    void removeNotificationId(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType newInstance() {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
