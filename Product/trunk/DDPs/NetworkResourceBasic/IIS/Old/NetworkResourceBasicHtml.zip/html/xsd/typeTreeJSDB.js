﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_tiFileName = "typeTreeIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function TN (href, prefix, ns, name, relation, simpletypeflag, children) {
	this.href = href;
	this.prefix = prefix;
	this.namespace = ns;
	this.name = name;
	this.relation = relation;
	this.simpletypeflag = simpletypeflag;
	this.children = children;

	this.hasChild = (children != null) && (children.length>0);	
}

function T (typeTree)
{
	this.typeTree = typeTree;
}

function typetree_showAllTypes() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_tiFileName;
}

function typetree_filterTypes () {
	parent._href = "xsd/" + xsd_tiFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");
}

function typetree_showTypes() {
	if (parent._xsdNsFilter == null) {
		typetree_setFilterToAll();
	}

	var nsList = parent._xsdNsFilter;
	var typetrees = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		typetrees [i] = typetreeDB [nsList[i]];	
		nss[i] = nsList[i];
	}		
	
	typetree_showTree (nss, typetrees); 
}

function typetree_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in typetreeDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}


	parent._xsdNsFilter = nsList;
}


function typetree_showTree (nsList, typetrees) {
	for (var i=0; i<nsList.length; i++) {
		var fpath = typetreeNSMap[nsList[i]];
		
		var str = '<div class="nsBox"><div class="itemNS">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+fpath+
			'" title="'+encodeURI(nsList[i])+
			'" target="'+target+'">'+encodeURI(nsList[i])+'</a></nobr></div>'+
			'<div style="margin-left: 0.5em">';		

		document.write (str);

		typetree_outputList (typetrees[i].typeTree);
		

		document.write ('</div></div>');
	}
} 

function typetree_outputList (list) {
	for (var i=0; i<list.length; i++) {
		typetree_outputTree (list[i]);
	}
}

function typetree_outputTree (node) {
	if (node.hasChild == false) {
		typetree_outputLeaf (node);
	} else {
		typetree_outputNonLeaf (node);
	}
}


function typetree_outputLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node)
	} else {
		nodeStr = anchorString (node)
	}

	str = '<span class="leaf"><nobr>' +
		  '<img src="img/leaf.gif" hspace="2" align="middle">' + 
		  nodeStr + '</nobr></span><br />';

	document.write (str);
}

function prefixedAnchorString (node) {
	return  '<a class="chref" href="'+node.href+
			'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+
			node.prefix+':'+'</a>'+
			'<a class="chref" href="'+node.href+'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);
}

function anchorString (node) {
	return 	'<a class="chref" href="'+node.href+'" target="'+target+'"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);

}

function typetree_outputNonLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node);
	} else {
		nodeStr = anchorString (node);
	}
		
	str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			nodeStr +
			'</nobr></div>'+
			'<div style="margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		typetree_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function typetree_getNodeIcon(node) {
	var rStr = null;
	if (node.relation == "none") {
		rStr = "";
	} else if (node.relation == "extension") {
		rStr = '<img alt="derived by extension" border="0" hspace="2" align="middle" src="img/extension.gif">';
	
	} else if (node.relation == "restriction") {
		rStr = '<img alt="derived by restriction" border="0" hspace="2" align="middle" src="img/restriction.gif">';
	
	} else if (node.relation == "list") {
		rStr = '<img alt="derived by list" border="0" hspace="2" align="middle" src="img/list.gif">';
	
	} else if (node.relation == "union") {
		rStr = '<img alt="derived by union" border="0" hspace="2" align="middle" src="img/union.gif">';
	
	}
	
	var typeStr = null;
	
	if (node.simpletypeflag) {
		typeStr = '<img alt="simple type" border="0" hspace="2" align="middle" src="img/simple.gif">'; 
	} else {
		typeStr = '<img alt="complex type" border="0" hspace="2" align="middle" src="img/complex.gif">';	
	} 

	return typeStr + rStr;
}

var typetreeDB = new Array();
var typetreeNSMap = new Array();

typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("10/complextype/AttributeValueChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/avc/v1","AttributeValueChangeType","extension",false,new Array(new TN("8/complextype/ResourceAttributeValueChangeType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1","ResourceAttributeValueChangeType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] = "10/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","extension",false,null),new TN("4/complextype/ObjectDiscoveryType.html","","http://www.tmforum.org/mtop/fmw/xsd/odis/v1","ObjectDiscoveryType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "5/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cocd/v1"] =  new T (new Array (new TN("15/complextype/CommonObjectSetDataType.html","cosd","http://www.tmforum.org/mtop/fmw/xsd/cosd/v1","CommonObjectSetDataType","none",false,new Array(new TN("20/complextype/CommonObjectCreateDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/cocd/v1","CommonObjectCreateDataType","restriction",false,new Array(new TN("25/complextype/CommonResourceCreateDataType.html","","http://www.tmforum.org/mtop/nrb/xsd/crcd/v1","CommonResourceCreateDataType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cocd/v1"] = "20/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new T (new Array (new TN("23/complextype/CommonObjectInfoType.html","","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("24/complextype/CommonResourceInfoType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "23/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/comd/v1"] =  new T (new Array (new TN("15/complextype/CommonObjectSetDataType.html","cosd","http://www.tmforum.org/mtop/fmw/xsd/cosd/v1","CommonObjectSetDataType","none",false,new Array(new TN("16/complextype/CommonObjectModifyDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/comd/v1","CommonObjectModifyDataType","restriction",false,new Array(new TN("14/complextype/CommonResourceModifyDataType.html","","http://www.tmforum.org/mtop/nrb/xsd/crmd/v1","CommonResourceModifyDataType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/comd/v1"] = "16/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cosd/v1"] =  new T (new Array (new TN("15/complextype/CommonObjectSetDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/cosd/v1","CommonObjectSetDataType","none",false,new Array(new TN("20/complextype/CommonObjectCreateDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/cocd/v1","CommonObjectCreateDataType","extension",false,null),new TN("16/complextype/CommonObjectModifyDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/comd/v1","CommonObjectModifyDataType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cosd/v1"] = "15/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("10/complextype/AttributeValueChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/avc/v1","AttributeValueChangeType","extension",false,null),new TN("22/complextype/ObjectCreationType.html","","http://www.tmforum.org/mtop/fmw/xsd/oc/v1","ObjectCreationType","extension",false,null),new TN("12/complextype/ObjectDeletionType.html","","http://www.tmforum.org/mtop/fmw/xsd/odel/v1","ObjectDeletionType","extension",false,null),new TN("17/complextype/StateChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/sc/v1","StateChangeType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "9/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new T (new Array (new TN("3/complextype/AliasNameListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AliasNameListType","none",false,null),new TN("3/complextype/AnyListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AnyListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#anyURI","xsd","http://www.w3.org/2001/XMLSchema","anyURI","none",true,new Array(new TN("3/simpletype/QueryDialectEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryDialectEnumType","restriction",true,null),new TN("3/simpletype/QueryDialectTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryDialectTypeType","restriction",true,null))),new TN("http://www.w3.org/TR/xmlschema-2/#date","xsd","http://www.w3.org/2001/XMLSchema","date","none",true,new Array(new TN("3/simpletype/ManufactureDateType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufactureDateType","restriction",true,null))),new TN("3/complextype/MultiEventInventoryAttributesType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","MultiEventInventoryAttributesType","none",false,null),new TN("3/complextype/NameAndAnyValueListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndAnyValueListType","none",false,null),new TN("3/complextype/NameAndAnyValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndAnyValueType","none",false,null),new TN("3/complextype/NameAndStringValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndStringValueType","none",false,null),new TN("3/complextype/NameAndValueStringListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndValueStringListType","none",false,null),new TN("3/complextype/NotificationIdentifierListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierListType","none",false,null),new TN("3/complextype/QueryExpressionType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryExpressionType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("3/simpletype/DiscoveredNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","DiscoveredNameType","restriction",true,null),new TN("3/simpletype/LocationType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","LocationType","restriction",true,null),new TN("3/simpletype/ManufacturerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufacturerType","restriction",true,null),new TN("3/simpletype/NamingOperationsSystemType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NamingOperationsSystemType","restriction",true,null),new TN("3/simpletype/NetworkAccessDomainType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NetworkAccessDomainType","restriction",true,null),new TN("3/simpletype/NotificationIdentifierType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierType","restriction",true,null),new TN("3/simpletype/ObjectEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectEnumType","restriction",true,null),new TN("3/simpletype/ObjectTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectTypeType","restriction",true,null),new TN("3/simpletype/OwnerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","OwnerType","restriction",true,null),new TN("3/simpletype/ProductNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ProductNameType","restriction",true,null),new TN("3/simpletype/UserLabelType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","UserLabelType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "3/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new T (new Array (new TN("11/complextype/NamingAttributeListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeListType","none",false,null),new TN("11/complextype/NamingAttributeType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeType","none",false,null),new TN("11/complextype/RelativeDistinguishNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","RelativeDistinguishNameType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "11/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("22/complextype/ObjectCreationType.html","","http://www.tmforum.org/mtop/fmw/xsd/oc/v1","ObjectCreationType","extension",false,new Array(new TN("21/complextype/ResourceObjectCreationType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscoc/v1","ResourceObjectCreationType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] = "22/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("12/complextype/ObjectDeletionType.html","","http://www.tmforum.org/mtop/fmw/xsd/odel/v1","ObjectDeletionType","extension",false,new Array(new TN("13/complextype/ResourceObjectDeletionType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1","ResourceObjectDeletionType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] = "12/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("4/complextype/ObjectDiscoveryType.html","","http://www.tmforum.org/mtop/fmw/xsd/odis/v1","ObjectDiscoveryType","restriction",false,new Array(new TN("6/complextype/ResourceObjectDiscoveryType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1","ResourceObjectDiscoveryType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] = "4/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("17/complextype/StateChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/sc/v1","StateChangeType","extension",false,new Array(new TN("18/complextype/ResourceStateChangeType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscsc/v1","ResourceStateChangeType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] = "17/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/com/v1"] =  new T (new Array (new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("7/simpletype/ProtectionSchemeStateEnumType.html","","http://www.tmforum.org/mtop/nrb/xsd/com/v1","ProtectionSchemeStateEnumType","restriction",true,new Array(new TN("7/complextype/ProtectionSchemeStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/com/v1","ProtectionSchemeStateType","restriction",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/com/v1"] = "7/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/crcd/v1"] =  new T (new Array (new TN("15/complextype/CommonObjectSetDataType.html","cosd","http://www.tmforum.org/mtop/fmw/xsd/cosd/v1","CommonObjectSetDataType","none",false,new Array(new TN("20/complextype/CommonObjectCreateDataType.html","cocd","http://www.tmforum.org/mtop/fmw/xsd/cocd/v1","CommonObjectCreateDataType","restriction",false,new Array(new TN("25/complextype/CommonResourceCreateDataType.html","","http://www.tmforum.org/mtop/nrb/xsd/crcd/v1","CommonResourceCreateDataType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/crcd/v1"] = "25/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/cri/v1"] =  new T (new Array (new TN("23/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("24/complextype/CommonResourceInfoType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","restriction",false,null))),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("24/simpletype/ResourceStateEnumType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","ResourceStateEnumType","restriction",true,new Array(new TN("24/complextype/ResourceStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","ResourceStateType","restriction",false,null))),new TN("24/simpletype/SourceEnumType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","SourceEnumType","restriction",true,new Array(new TN("24/complextype/SourceType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","SourceType","restriction",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/cri/v1"] = "24/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/crmd/v1"] =  new T (new Array (new TN("15/complextype/CommonObjectSetDataType.html","cosd","http://www.tmforum.org/mtop/fmw/xsd/cosd/v1","CommonObjectSetDataType","none",false,new Array(new TN("16/complextype/CommonObjectModifyDataType.html","comd","http://www.tmforum.org/mtop/fmw/xsd/comd/v1","CommonObjectModifyDataType","restriction",false,new Array(new TN("14/complextype/CommonResourceModifyDataType.html","","http://www.tmforum.org/mtop/nrb/xsd/crmd/v1","CommonResourceModifyDataType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/crmd/v1"] = "14/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/itu/v1"] =  new T (new Array (new TN("http://www.w3.org/TR/xmlschema-2/#boolean","xsd","http://www.w3.org/2001/XMLSchema","boolean","none",true,new Array(new TN("19/simpletype/X721.OperationalStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.OperationalStateType","restriction",true,null),new TN("19/simpletype/X721.UnkownstatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.UnkownstatusType","restriction",true,null))),new TN("19/simpletype/M3100.NALMQIIntervalType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.NALMQIIntervalType","none",true,null),new TN("19/simpletype/M3100.NALMTIIntervalType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.NALMTIIntervalType","none",true,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("19/simpletype/M3100.AlarmStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.AlarmStatusType","restriction",true,null),new TN("19/simpletype/M3100.ArcQIStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.ArcQIStatusType","restriction",true,null),new TN("19/simpletype/M3100.ArcStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.ArcStateType","restriction",true,null),new TN("19/simpletype/M3100.CircuitPackTypeType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.CircuitPackTypeType","restriction",true,null),new TN("19/simpletype/M3100.HolderStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.HolderStatusType","restriction",true,null),new TN("19/simpletype/X721.AdministrativeStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.AdministrativeStateType","restriction",true,null),new TN("19/simpletype/X721.AvailabilityStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.AvailabilityStatusType","restriction",true,null),new TN("19/simpletype/X721.ControlStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.ControlStatusType","restriction",true,null),new TN("19/simpletype/X721.UsageStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.UsageStateType","restriction",true,null))),new TN("19/complextype/X721.StateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.StateType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/itu/v1"] = "19/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/lay/v1"] =  new T (new Array (new TN("2/complextype/LayerRateListType.html","","http://www.tmforum.org/mtop/nrb/xsd/lay/v1","LayerRateListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("2/simpletype/LayerRateEnumType.html","","http://www.tmforum.org/mtop/nrb/xsd/lay/v1","LayerRateEnumType","restriction",true,new Array(new TN("2/complextype/LayerRateType.html","","http://www.tmforum.org/mtop/nrb/xsd/lay/v1","LayerRateType","restriction",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/lay/v1"] = "2/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/lp/v1"] =  new T (new Array (new TN("1/complextype/LayeredParametersListType.html","","http://www.tmforum.org/mtop/nrb/xsd/lp/v1","LayeredParametersListType","none",false,null),new TN("1/complextype/LayeredParametersType.html","","http://www.tmforum.org/mtop/nrb/xsd/lp/v1","LayeredParametersType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/lp/v1"] = "1/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("10/complextype/AttributeValueChangeType.html","avc","http://www.tmforum.org/mtop/fmw/xsd/avc/v1","AttributeValueChangeType","extension",false,new Array(new TN("8/complextype/ResourceAttributeValueChangeType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1","ResourceAttributeValueChangeType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1"] = "8/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/rscoc/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("22/complextype/ObjectCreationType.html","oc","http://www.tmforum.org/mtop/fmw/xsd/oc/v1","ObjectCreationType","extension",false,new Array(new TN("21/complextype/ResourceObjectCreationType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscoc/v1","ResourceObjectCreationType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscoc/v1"] = "21/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("12/complextype/ObjectDeletionType.html","odel","http://www.tmforum.org/mtop/fmw/xsd/odel/v1","ObjectDeletionType","extension",false,new Array(new TN("13/complextype/ResourceObjectDeletionType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1","ResourceObjectDeletionType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1"] = "13/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("4/complextype/ObjectDiscoveryType.html","odis","http://www.tmforum.org/mtop/fmw/xsd/odis/v1","ObjectDiscoveryType","restriction",false,new Array(new TN("6/complextype/ResourceObjectDiscoveryType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1","ResourceObjectDiscoveryType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1"] = "6/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/rscsc/v1"] =  new T (new Array (new TN("5/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("17/complextype/StateChangeType.html","sc","http://www.tmforum.org/mtop/fmw/xsd/sc/v1","StateChangeType","extension",false,new Array(new TN("18/complextype/ResourceStateChangeType.html","","http://www.tmforum.org/mtop/nrb/xsd/rscsc/v1","ResourceStateChangeType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscsc/v1"] = "18/index.html";
								   


