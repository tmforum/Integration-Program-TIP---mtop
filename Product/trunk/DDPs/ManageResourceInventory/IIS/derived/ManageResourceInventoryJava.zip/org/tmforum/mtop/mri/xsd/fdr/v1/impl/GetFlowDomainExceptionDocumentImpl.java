/*
 * An XML document type.
 * Localname: getFlowDomainException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument
{
    
    public GetFlowDomainExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainException");
    
    
    /**
     * Gets the "getFlowDomainException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException getGetFlowDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException)get_store().find_element_user(GETFLOWDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainException" element
     */
    public void setGetFlowDomainException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException getFlowDomainException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException)get_store().find_element_user(GETFLOWDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException)get_store().add_element_user(GETFLOWDOMAINEXCEPTION$0);
            }
            target.set(getFlowDomainException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException addNewGetFlowDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException)get_store().add_element_user(GETFLOWDOMAINEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainExceptionDocument.GetFlowDomainException
    {
        
        public GetFlowDomainExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
