/*
 * An XML document type.
 * Localname: getAllFixedSubnetworkConnectionsWithTpRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedSubnetworkConnectionsWithTpRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedSubnetworkConnectionsWithTpRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpRequestDocument
{
    
    public GetAllFixedSubnetworkConnectionsWithTpRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedSubnetworkConnectionsWithTpRequest");
    
    
    /**
     * Gets the "getAllFixedSubnetworkConnectionsWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType getGetAllFixedSubnetworkConnectionsWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedSubnetworkConnectionsWithTpRequest" element
     */
    public void setGetAllFixedSubnetworkConnectionsWithTpRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType getAllFixedSubnetworkConnectionsWithTpRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPREQUEST$0);
            }
            target.set(getAllFixedSubnetworkConnectionsWithTpRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedSubnetworkConnectionsWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType addNewGetAllFixedSubnetworkConnectionsWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPREQUEST$0);
            return target;
        }
    }
}
