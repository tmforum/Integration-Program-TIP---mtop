/*
 * An XML document type.
 * Localname: getFlowDomainFragmentsByUserLabelResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentsByUserLabelResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentsByUserLabelResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument
{
    
    public GetFlowDomainFragmentsByUserLabelResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTSBYUSERLABELRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentsByUserLabelResponse");
    
    
    /**
     * Gets the "getFlowDomainFragmentsByUserLabelResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse getGetFlowDomainFragmentsByUserLabelResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentsByUserLabelResponse" element
     */
    public void setGetFlowDomainFragmentsByUserLabelResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse getFlowDomainFragmentsByUserLabelResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELRESPONSE$0);
            }
            target.set(getFlowDomainFragmentsByUserLabelResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentsByUserLabelResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse addNewGetFlowDomainFragmentsByUserLabelResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentsByUserLabelResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentsByUserLabelResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelResponseDocument.GetFlowDomainFragmentsByUserLabelResponse
    {
        
        public GetFlowDomainFragmentsByUserLabelResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrList");
        
        
        /**
         * Gets the "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType getFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fdfrList" element
         */
        public boolean isSetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDFRLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "fdfrList" element
         */
        public void setFdfrList(org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType fdfrList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().add_element_user(FDFRLIST$0);
                }
                target.set(fdfrList);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType addNewFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().add_element_user(FDFRLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fdfrList" element
         */
        public void unsetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDFRLIST$0, 0);
            }
        }
    }
}
