/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionNamesRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionNamesRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesRequestDocument
{
    
    public GetAllSubnetworkConnectionNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionNamesRequest");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType getGetAllSubnetworkConnectionNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionNamesRequest" element
     */
    public void setGetAllSubnetworkConnectionNamesRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType getAllSubnetworkConnectionNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESREQUEST$0);
            }
            target.set(getAllSubnetworkConnectionNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType addNewGetAllSubnetworkConnectionNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESREQUEST$0);
            return target;
        }
    }
}
