/*
 * An XML document type.
 * Localname: getAllSupportedMatrixFlowDomainsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllSupportedMatrixFlowDomainsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportedMatrixFlowDomainsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument
{
    
    public GetAllSupportedMatrixFlowDomainsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTEDMATRIXFLOWDOMAINSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllSupportedMatrixFlowDomainsException");
    
    
    /**
     * Gets the "getAllSupportedMatrixFlowDomainsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException getGetAllSupportedMatrixFlowDomainsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException)get_store().find_element_user(GETALLSUPPORTEDMATRIXFLOWDOMAINSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportedMatrixFlowDomainsException" element
     */
    public void setGetAllSupportedMatrixFlowDomainsException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException getAllSupportedMatrixFlowDomainsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException)get_store().find_element_user(GETALLSUPPORTEDMATRIXFLOWDOMAINSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException)get_store().add_element_user(GETALLSUPPORTEDMATRIXFLOWDOMAINSEXCEPTION$0);
            }
            target.set(getAllSupportedMatrixFlowDomainsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportedMatrixFlowDomainsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException addNewGetAllSupportedMatrixFlowDomainsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException)get_store().add_element_user(GETALLSUPPORTEDMATRIXFLOWDOMAINSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllSupportedMatrixFlowDomainsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSupportedMatrixFlowDomainsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsExceptionDocument.GetAllSupportedMatrixFlowDomainsException
    {
        
        public GetAllSupportedMatrixFlowDomainsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
