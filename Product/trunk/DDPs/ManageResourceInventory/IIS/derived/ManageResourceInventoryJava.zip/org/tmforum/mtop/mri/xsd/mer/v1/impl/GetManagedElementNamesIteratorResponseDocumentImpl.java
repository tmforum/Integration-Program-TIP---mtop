/*
 * An XML document type.
 * Localname: getManagedElementNamesIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementNamesIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getManagedElementNamesIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetManagedElementNamesIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementNamesIteratorResponseDocument
{
    
    public GetManagedElementNamesIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMANAGEDELEMENTNAMESITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getManagedElementNamesIteratorResponse");
    
    
    /**
     * Gets the "getManagedElementNamesIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType getGetManagedElementNamesIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().find_element_user(GETMANAGEDELEMENTNAMESITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getManagedElementNamesIteratorResponse" element
     */
    public void setGetManagedElementNamesIteratorResponse(org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType getManagedElementNamesIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().find_element_user(GETMANAGEDELEMENTNAMESITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().add_element_user(GETMANAGEDELEMENTNAMESITERATORRESPONSE$0);
            }
            target.set(getManagedElementNamesIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getManagedElementNamesIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType addNewGetManagedElementNamesIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().add_element_user(GETMANAGEDELEMENTNAMESITERATORRESPONSE$0);
            return target;
        }
    }
}
