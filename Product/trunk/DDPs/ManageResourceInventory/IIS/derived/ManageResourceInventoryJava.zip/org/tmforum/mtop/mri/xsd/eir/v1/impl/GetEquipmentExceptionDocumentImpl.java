/*
 * An XML document type.
 * Localname: getEquipmentException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetEquipmentExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument
{
    
    public GetEquipmentExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETEQUIPMENTEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getEquipmentException");
    
    
    /**
     * Gets the "getEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException getGetEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException)get_store().find_element_user(GETEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getEquipmentException" element
     */
    public void setGetEquipmentException(org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException getEquipmentException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException)get_store().find_element_user(GETEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException)get_store().add_element_user(GETEQUIPMENTEXCEPTION$0);
            }
            target.set(getEquipmentException);
        }
    }
    
    /**
     * Appends and returns a new empty "getEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException addNewGetEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException)get_store().add_element_user(GETEQUIPMENTEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetEquipmentExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentExceptionDocument.GetEquipmentException
    {
        
        public GetEquipmentExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
