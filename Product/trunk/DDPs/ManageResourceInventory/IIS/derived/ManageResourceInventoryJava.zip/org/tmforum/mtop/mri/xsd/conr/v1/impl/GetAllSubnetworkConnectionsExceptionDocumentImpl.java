/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument
{
    
    public GetAllSubnetworkConnectionsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionsException");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException getGetAllSubnetworkConnectionsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionsException" element
     */
    public void setGetAllSubnetworkConnectionsException(org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException getAllSubnetworkConnectionsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSEXCEPTION$0);
            }
            target.set(getAllSubnetworkConnectionsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException addNewGetAllSubnetworkConnectionsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllSubnetworkConnectionsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSubnetworkConnectionsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsExceptionDocument.GetAllSubnetworkConnectionsException
    {
        
        public GetAllSubnetworkConnectionsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
