/*
 * An XML document type.
 * Localname: getFlowDomainFragmentRouteException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentRouteException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentRouteExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument
{
    
    public GetFlowDomainFragmentRouteExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTROUTEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentRouteException");
    
    
    /**
     * Gets the "getFlowDomainFragmentRouteException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException getGetFlowDomainFragmentRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException)get_store().find_element_user(GETFLOWDOMAINFRAGMENTROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentRouteException" element
     */
    public void setGetFlowDomainFragmentRouteException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException getFlowDomainFragmentRouteException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException)get_store().find_element_user(GETFLOWDOMAINFRAGMENTROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException)get_store().add_element_user(GETFLOWDOMAINFRAGMENTROUTEEXCEPTION$0);
            }
            target.set(getFlowDomainFragmentRouteException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentRouteException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException addNewGetFlowDomainFragmentRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException)get_store().add_element_user(GETFLOWDOMAINFRAGMENTROUTEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentRouteException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentRouteExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteExceptionDocument.GetFlowDomainFragmentRouteException
    {
        
        public GetFlowDomainFragmentRouteExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
