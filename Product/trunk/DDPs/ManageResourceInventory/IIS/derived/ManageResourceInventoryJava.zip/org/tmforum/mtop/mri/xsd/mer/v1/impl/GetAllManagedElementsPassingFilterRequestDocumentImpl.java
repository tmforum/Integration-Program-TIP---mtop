/*
 * An XML document type.
 * Localname: getAllManagedElementsPassingFilterRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsPassingFilterRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsPassingFilterRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument
{
    
    public GetAllManagedElementsPassingFilterRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSPASSINGFILTERREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsPassingFilterRequest");
    
    
    /**
     * Gets the "getAllManagedElementsPassingFilterRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest getGetAllManagedElementsPassingFilterRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest)get_store().find_element_user(GETALLMANAGEDELEMENTSPASSINGFILTERREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsPassingFilterRequest" element
     */
    public void setGetAllManagedElementsPassingFilterRequest(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest getAllManagedElementsPassingFilterRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest)get_store().find_element_user(GETALLMANAGEDELEMENTSPASSINGFILTERREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest)get_store().add_element_user(GETALLMANAGEDELEMENTSPASSINGFILTERREQUEST$0);
            }
            target.set(getAllManagedElementsPassingFilterRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsPassingFilterRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest addNewGetAllManagedElementsPassingFilterRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest)get_store().add_element_user(GETALLMANAGEDELEMENTSPASSINGFILTERREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementsPassingFilterRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementsPassingFilterRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterRequestDocument.GetAllManagedElementsPassingFilterRequest
    {
        
        public GetAllManagedElementsPassingFilterRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "mdName");
        private static final javax.xml.namespace.QName FILTER$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "filter");
        
        
        /**
         * Gets the "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MDNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mdName" element
         */
        public void setMdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType mdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MDNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MDNAME$0);
                }
                target.set(mdName);
            }
        }
        
        /**
         * Appends and returns a new empty "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MDNAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "filter" element
         */
        public org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType getFilter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType target = null;
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType)get_store().find_element_user(FILTER$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "filter" element
         */
        public void setFilter(org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType filter)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType target = null;
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType)get_store().find_element_user(FILTER$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType)get_store().add_element_user(FILTER$2);
                }
                target.set(filter);
            }
        }
        
        /**
         * Appends and returns a new empty "filter" element
         */
        public org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType addNewFilter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType target = null;
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType)get_store().add_element_user(FILTER$2);
                return target;
            }
        }
    }
}
