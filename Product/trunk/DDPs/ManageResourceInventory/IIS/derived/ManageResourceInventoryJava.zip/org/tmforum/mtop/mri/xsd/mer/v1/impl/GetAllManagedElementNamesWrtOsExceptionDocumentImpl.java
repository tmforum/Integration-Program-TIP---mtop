/*
 * An XML document type.
 * Localname: getAllManagedElementNamesWrtOsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesWrtOsException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesWrtOsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument
{
    
    public GetAllManagedElementNamesWrtOsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESWRTOSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesWrtOsException");
    
    
    /**
     * Gets the "getAllManagedElementNamesWrtOsException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException getGetAllManagedElementNamesWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesWrtOsException" element
     */
    public void setGetAllManagedElementNamesWrtOsException(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException getAllManagedElementNamesWrtOsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTOSEXCEPTION$0);
            }
            target.set(getAllManagedElementNamesWrtOsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesWrtOsException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException addNewGetAllManagedElementNamesWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTOSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementNamesWrtOsException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementNamesWrtOsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException
    {
        
        public GetAllManagedElementNamesWrtOsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
