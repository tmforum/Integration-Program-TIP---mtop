/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionsWithTpException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionsWithTpException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionsWithTpExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument
{
    
    public GetAllSubnetworkConnectionsWithTpExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionsWithTpException");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionsWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException getGetAllSubnetworkConnectionsWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionsWithTpException" element
     */
    public void setGetAllSubnetworkConnectionsWithTpException(org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException getAllSubnetworkConnectionsWithTpException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0);
            }
            target.set(getAllSubnetworkConnectionsWithTpException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionsWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException addNewGetAllSubnetworkConnectionsWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllSubnetworkConnectionsWithTpException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSubnetworkConnectionsWithTpExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpExceptionDocument.GetAllSubnetworkConnectionsWithTpException
    {
        
        public GetAllSubnetworkConnectionsWithTpExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
