/*
 * An XML document type.
 * Localname: getSupportedEquipmentNamesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportedEquipmentNamesResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportedEquipmentNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesResponseDocument
{
    
    public GetSupportedEquipmentNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTEDEQUIPMENTNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportedEquipmentNamesResponse");
    
    
    /**
     * Gets the "getSupportedEquipmentNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType getGetSupportedEquipmentNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETSUPPORTEDEQUIPMENTNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportedEquipmentNamesResponse" element
     */
    public void setGetSupportedEquipmentNamesResponse(org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType getSupportedEquipmentNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETSUPPORTEDEQUIPMENTNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETSUPPORTEDEQUIPMENTNAMESRESPONSE$0);
            }
            target.set(getSupportedEquipmentNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportedEquipmentNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType addNewGetSupportedEquipmentNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETSUPPORTEDEQUIPMENTNAMESRESPONSE$0);
            return target;
        }
    }
}
