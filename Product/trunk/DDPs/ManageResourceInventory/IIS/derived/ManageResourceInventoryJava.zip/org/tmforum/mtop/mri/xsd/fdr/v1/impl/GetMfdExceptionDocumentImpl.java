/*
 * An XML document type.
 * Localname: getMfdException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getMfdException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetMfdExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument
{
    
    public GetMfdExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMFDEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getMfdException");
    
    
    /**
     * Gets the "getMfdException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException getGetMfdException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException)get_store().find_element_user(GETMFDEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getMfdException" element
     */
    public void setGetMfdException(org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException getMfdException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException)get_store().find_element_user(GETMFDEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException)get_store().add_element_user(GETMFDEXCEPTION$0);
            }
            target.set(getMfdException);
        }
    }
    
    /**
     * Appends and returns a new empty "getMfdException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException addNewGetMfdException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException)get_store().add_element_user(GETMFDEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getMfdException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetMfdExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdExceptionDocument.GetMfdException
    {
        
        public GetMfdExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
