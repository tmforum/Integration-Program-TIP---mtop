/*
 * An XML document type.
 * Localname: getAllManagedElementNamesWrtMlsnRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesWrtMlsnRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesWrtMlsnRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument
{
    
    public GetAllManagedElementNamesWrtMlsnRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESWRTMLSNREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesWrtMlsnRequest");
    
    
    /**
     * Gets the "getAllManagedElementNamesWrtMlsnRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest getGetAllManagedElementNamesWrtMlsnRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTMLSNREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesWrtMlsnRequest" element
     */
    public void setGetAllManagedElementNamesWrtMlsnRequest(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest getAllManagedElementNamesWrtMlsnRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTMLSNREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTMLSNREQUEST$0);
            }
            target.set(getAllManagedElementNamesWrtMlsnRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesWrtMlsnRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest addNewGetAllManagedElementNamesWrtMlsnRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTMLSNREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementNamesWrtMlsnRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementNamesWrtMlsnRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnRequestDocument.GetAllManagedElementNamesWrtMlsnRequest
    {
        
        public GetAllManagedElementNamesWrtMlsnRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MLSNNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "mlsnName");
        
        
        /**
         * Gets the "mlsnName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getMlsnName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(MLSNNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mlsnName" element
         */
        public void setMlsnName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType mlsnName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(MLSNNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(MLSNNAME$0);
                }
                target.set(mlsnName);
            }
        }
        
        /**
         * Appends and returns a new empty "mlsnName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewMlsnName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(MLSNNAME$0);
                return target;
            }
        }
    }
}
