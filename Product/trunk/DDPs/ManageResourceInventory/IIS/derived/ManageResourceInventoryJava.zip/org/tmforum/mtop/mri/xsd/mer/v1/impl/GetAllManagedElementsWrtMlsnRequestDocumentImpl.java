/*
 * An XML document type.
 * Localname: getAllManagedElementsWrtMlsnRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsWrtMlsnRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsWrtMlsnRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument
{
    
    public GetAllManagedElementsWrtMlsnRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSWRTMLSNREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsWrtMlsnRequest");
    
    
    /**
     * Gets the "getAllManagedElementsWrtMlsnRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest getGetAllManagedElementsWrtMlsnRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTMLSNREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsWrtMlsnRequest" element
     */
    public void setGetAllManagedElementsWrtMlsnRequest(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest getAllManagedElementsWrtMlsnRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTMLSNREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTMLSNREQUEST$0);
            }
            target.set(getAllManagedElementsWrtMlsnRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsWrtMlsnRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest addNewGetAllManagedElementsWrtMlsnRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTMLSNREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementsWrtMlsnRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementsWrtMlsnRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnRequestDocument.GetAllManagedElementsWrtMlsnRequest
    {
        
        public GetAllManagedElementsWrtMlsnRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MLSNNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "mlsnName");
        
        
        /**
         * Gets the "mlsnName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMlsnName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MLSNNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mlsnName" element
         */
        public void setMlsnName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType mlsnName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MLSNNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MLSNNAME$0);
                }
                target.set(mlsnName);
            }
        }
        
        /**
         * Appends and returns a new empty "mlsnName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMlsnName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MLSNNAME$0);
                return target;
            }
        }
    }
}
