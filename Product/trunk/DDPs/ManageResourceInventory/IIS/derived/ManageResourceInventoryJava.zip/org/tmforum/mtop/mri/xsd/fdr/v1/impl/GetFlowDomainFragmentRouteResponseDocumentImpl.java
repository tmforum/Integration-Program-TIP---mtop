/*
 * An XML document type.
 * Localname: getFlowDomainFragmentRouteResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentRouteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument
{
    
    public GetFlowDomainFragmentRouteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTROUTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentRouteResponse");
    
    
    /**
     * Gets the "getFlowDomainFragmentRouteResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse getGetFlowDomainFragmentRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse)get_store().find_element_user(GETFLOWDOMAINFRAGMENTROUTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentRouteResponse" element
     */
    public void setGetFlowDomainFragmentRouteResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse getFlowDomainFragmentRouteResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse)get_store().find_element_user(GETFLOWDOMAINFRAGMENTROUTERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse)get_store().add_element_user(GETFLOWDOMAINFRAGMENTROUTERESPONSE$0);
            }
            target.set(getFlowDomainFragmentRouteResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentRouteResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse addNewGetFlowDomainFragmentRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse)get_store().add_element_user(GETFLOWDOMAINFRAGMENTROUTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentRouteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteResponseDocument.GetFlowDomainFragmentRouteResponse
    {
        
        public GetFlowDomainFragmentRouteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROUTE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "route");
        
        
        /**
         * Gets the "route" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType getRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().find_element_user(ROUTE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "route" element
         */
        public void setRoute(org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType route)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().find_element_user(ROUTE$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().add_element_user(ROUTE$0);
                }
                target.set(route);
            }
        }
        
        /**
         * Appends and returns a new empty "route" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType addNewRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FlowDomainFragmentRouteType)get_store().add_element_user(ROUTE$0);
                return target;
            }
        }
    }
}
