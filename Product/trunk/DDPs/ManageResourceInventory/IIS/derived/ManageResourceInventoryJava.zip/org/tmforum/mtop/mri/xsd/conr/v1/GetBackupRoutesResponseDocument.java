/*
 * An XML document type.
 * Localname: getBackupRoutesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1;


/**
 * A document containing one getBackupRoutesResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public interface GetBackupRoutesResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetBackupRoutesResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s091C586F22B0BAF206F639150ED2BB5B").resolveHandle("getbackuproutesresponse4866doctype");
    
    /**
     * Gets the "getBackupRoutesResponse" element
     */
    org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse getGetBackupRoutesResponse();
    
    /**
     * Sets the "getBackupRoutesResponse" element
     */
    void setGetBackupRoutesResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse getBackupRoutesResponse);
    
    /**
     * Appends and returns a new empty "getBackupRoutesResponse" element
     */
    org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse addNewGetBackupRoutesResponse();
    
    /**
     * An XML getBackupRoutesResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public interface GetBackupRoutesResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetBackupRoutesResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s091C586F22B0BAF206F639150ED2BB5B").resolveHandle("getbackuproutesresponse5615elemtype");
        
        /**
         * Gets the "additionalInfo" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType getAdditionalInfo();
        
        /**
         * Sets the "additionalInfo" element
         */
        void setAdditionalInfo(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType additionalInfo);
        
        /**
         * Appends and returns a new empty "additionalInfo" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType addNewAdditionalInfo();
        
        /**
         * Gets the "routeList" element
         */
        org.tmforum.mtop.nrf.xsd.route.v1.RouteListType getRouteList();
        
        /**
         * True if has "routeList" element
         */
        boolean isSetRouteList();
        
        /**
         * Sets the "routeList" element
         */
        void setRouteList(org.tmforum.mtop.nrf.xsd.route.v1.RouteListType routeList);
        
        /**
         * Appends and returns a new empty "routeList" element
         */
        org.tmforum.mtop.nrf.xsd.route.v1.RouteListType addNewRouteList();
        
        /**
         * Unsets the "routeList" element
         */
        void unsetRouteList();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse newInstance() {
              return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument newInstance() {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
