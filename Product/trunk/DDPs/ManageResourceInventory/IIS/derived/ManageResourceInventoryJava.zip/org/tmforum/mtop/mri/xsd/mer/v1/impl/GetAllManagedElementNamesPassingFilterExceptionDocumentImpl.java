/*
 * An XML document type.
 * Localname: getAllManagedElementNamesPassingFilterException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesPassingFilterException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesPassingFilterExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument
{
    
    public GetAllManagedElementNamesPassingFilterExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESPASSINGFILTEREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesPassingFilterException");
    
    
    /**
     * Gets the "getAllManagedElementNamesPassingFilterException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException getGetAllManagedElementNamesPassingFilterException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESPASSINGFILTEREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesPassingFilterException" element
     */
    public void setGetAllManagedElementNamesPassingFilterException(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException getAllManagedElementNamesPassingFilterException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESPASSINGFILTEREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESPASSINGFILTEREXCEPTION$0);
            }
            target.set(getAllManagedElementNamesPassingFilterException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesPassingFilterException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException addNewGetAllManagedElementNamesPassingFilterException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESPASSINGFILTEREXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementNamesPassingFilterException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementNamesPassingFilterExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterExceptionDocument.GetAllManagedElementNamesPassingFilterException
    {
        
        public GetAllManagedElementNamesPassingFilterExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
