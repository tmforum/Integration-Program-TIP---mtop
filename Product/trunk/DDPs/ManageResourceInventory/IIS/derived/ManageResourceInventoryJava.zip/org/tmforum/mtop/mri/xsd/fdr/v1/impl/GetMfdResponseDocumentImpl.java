/*
 * An XML document type.
 * Localname: getMfdResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getMfdResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetMfdResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument
{
    
    public GetMfdResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMFDRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getMfdResponse");
    
    
    /**
     * Gets the "getMfdResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse getGetMfdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse)get_store().find_element_user(GETMFDRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getMfdResponse" element
     */
    public void setGetMfdResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse getMfdResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse)get_store().find_element_user(GETMFDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse)get_store().add_element_user(GETMFDRESPONSE$0);
            }
            target.set(getMfdResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getMfdResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse addNewGetMfdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse)get_store().add_element_user(GETMFDRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getMfdResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetMfdResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetMfdResponseDocument.GetMfdResponse
    {
        
        public GetMfdResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFD$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfd");
        
        
        /**
         * Gets the "mfd" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType getMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "mfd" element
         */
        public boolean isSetMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFD$0) != 0;
            }
        }
        
        /**
         * Sets the "mfd" element
         */
        public void setMfd(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType mfd)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
                }
                target.set(mfd);
            }
        }
        
        /**
         * Appends and returns a new empty "mfd" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType addNewMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
                return target;
            }
        }
        
        /**
         * Unsets the "mfd" element
         */
        public void unsetMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFD$0, 0);
            }
        }
    }
}
