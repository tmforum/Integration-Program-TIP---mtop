/*
 * An XML document type.
 * Localname: getSupportedEquipmentRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportedEquipmentRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportedEquipmentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentRequestDocument
{
    
    public GetSupportedEquipmentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTEDEQUIPMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportedEquipmentRequest");
    
    
    /**
     * Gets the "getSupportedEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType getGetSupportedEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().find_element_user(GETSUPPORTEDEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportedEquipmentRequest" element
     */
    public void setGetSupportedEquipmentRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType getSupportedEquipmentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().find_element_user(GETSUPPORTEDEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().add_element_user(GETSUPPORTEDEQUIPMENTREQUEST$0);
            }
            target.set(getSupportedEquipmentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportedEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType addNewGetSupportedEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().add_element_user(GETSUPPORTEDEQUIPMENTREQUEST$0);
            return target;
        }
    }
}
