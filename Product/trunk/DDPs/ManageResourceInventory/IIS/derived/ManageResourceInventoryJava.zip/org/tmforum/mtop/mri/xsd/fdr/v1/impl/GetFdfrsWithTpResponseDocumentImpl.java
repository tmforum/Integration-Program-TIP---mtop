/*
 * An XML document type.
 * Localname: getFdfrsWithTpResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrsWithTpResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrsWithTpResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument
{
    
    public GetFdfrsWithTpResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRSWITHTPRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrsWithTpResponse");
    
    
    /**
     * Gets the "getFdfrsWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse getGetFdfrsWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse)get_store().find_element_user(GETFDFRSWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrsWithTpResponse" element
     */
    public void setGetFdfrsWithTpResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse getFdfrsWithTpResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse)get_store().find_element_user(GETFDFRSWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse)get_store().add_element_user(GETFDFRSWITHTPRESPONSE$0);
            }
            target.set(getFdfrsWithTpResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrsWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse addNewGetFdfrsWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse)get_store().add_element_user(GETFDFRSWITHTPRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFdfrsWithTpResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrsWithTpResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpResponseDocument.GetFdfrsWithTpResponse
    {
        
        public GetFdfrsWithTpResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrList");
        
        
        /**
         * Gets the "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType getFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fdfrList" element
         */
        public boolean isSetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDFRLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "fdfrList" element
         */
        public void setFdfrList(org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType fdfrList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType)get_store().add_element_user(FDFRLIST$0);
                }
                target.set(fdfrList);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType addNewFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType)get_store().add_element_user(FDFRLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fdfrList" element
         */
        public void unsetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDFRLIST$0, 0);
            }
        }
    }
}
