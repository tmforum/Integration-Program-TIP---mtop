/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionNamesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionNamesResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesResponseDocument
{
    
    public GetAllSubnetworkConnectionNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionNamesResponse");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType getGetAllSubnetworkConnectionNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionNamesResponse" element
     */
    public void setGetAllSubnetworkConnectionNamesResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType getAllSubnetworkConnectionNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESRESPONSE$0);
            }
            target.set(getAllSubnetworkConnectionNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType addNewGetAllSubnetworkConnectionNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESRESPONSE$0);
            return target;
        }
    }
}
