/*
 * An XML document type.
 * Localname: getSupportedEquipmentNamesException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportedEquipmentNamesException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportedEquipmentNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument
{
    
    public GetSupportedEquipmentNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTEDEQUIPMENTNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportedEquipmentNamesException");
    
    
    /**
     * Gets the "getSupportedEquipmentNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException getGetSupportedEquipmentNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException)get_store().find_element_user(GETSUPPORTEDEQUIPMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportedEquipmentNamesException" element
     */
    public void setGetSupportedEquipmentNamesException(org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException getSupportedEquipmentNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException)get_store().find_element_user(GETSUPPORTEDEQUIPMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException)get_store().add_element_user(GETSUPPORTEDEQUIPMENTNAMESEXCEPTION$0);
            }
            target.set(getSupportedEquipmentNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportedEquipmentNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException addNewGetSupportedEquipmentNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException)get_store().add_element_user(GETSUPPORTEDEQUIPMENTNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getSupportedEquipmentNamesException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetSupportedEquipmentNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesExceptionDocument.GetSupportedEquipmentNamesException
    {
        
        public GetSupportedEquipmentNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
