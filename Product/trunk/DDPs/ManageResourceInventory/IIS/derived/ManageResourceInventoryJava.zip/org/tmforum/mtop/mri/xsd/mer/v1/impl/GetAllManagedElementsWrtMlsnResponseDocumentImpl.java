/*
 * An XML document type.
 * Localname: getAllManagedElementsWrtMlsnResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsWrtMlsnResponse(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsWrtMlsnResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnResponseDocument
{
    
    public GetAllManagedElementsWrtMlsnResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSWRTMLSNRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsWrtMlsnResponse");
    
    
    /**
     * Gets the "getAllManagedElementsWrtMlsnResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType getGetAllManagedElementsWrtMlsnResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTMLSNRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsWrtMlsnResponse" element
     */
    public void setGetAllManagedElementsWrtMlsnResponse(org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType getAllManagedElementsWrtMlsnResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTMLSNRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTMLSNRESPONSE$0);
            }
            target.set(getAllManagedElementsWrtMlsnResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsWrtMlsnResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType addNewGetAllManagedElementsWrtMlsnResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTMLSNRESPONSE$0);
            return target;
        }
    }
}
