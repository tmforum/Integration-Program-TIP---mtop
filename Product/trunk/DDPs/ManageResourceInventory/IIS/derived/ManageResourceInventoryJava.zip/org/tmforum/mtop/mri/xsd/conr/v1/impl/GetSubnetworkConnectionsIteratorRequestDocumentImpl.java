/*
 * An XML document type.
 * Localname: getSubnetworkConnectionsIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionsIteratorRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionsIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsIteratorRequestDocument
{
    
    public GetSubnetworkConnectionsIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONSITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionsIteratorRequest");
    
    
    /**
     * Gets the "getSubnetworkConnectionsIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getGetSubnetworkConnectionsIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETSUBNETWORKCONNECTIONSITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionsIteratorRequest" element
     */
    public void setGetSubnetworkConnectionsIteratorRequest(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getSubnetworkConnectionsIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETSUBNETWORKCONNECTIONSITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETSUBNETWORKCONNECTIONSITERATORREQUEST$0);
            }
            target.set(getSubnetworkConnectionsIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionsIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType addNewGetSubnetworkConnectionsIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETSUBNETWORKCONNECTIONSITERATORREQUEST$0);
            return target;
        }
    }
}
