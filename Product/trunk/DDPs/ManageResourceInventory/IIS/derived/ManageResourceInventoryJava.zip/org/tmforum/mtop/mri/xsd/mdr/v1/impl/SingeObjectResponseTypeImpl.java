/*
 * XML Type:  SingeObjectResponseType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * An XML SingeObjectResponseType(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1).
 *
 * This is a complex type.
 */
public class SingeObjectResponseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType
{
    
    public SingeObjectResponseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "md");
    
    
    /**
     * Gets the "md" element
     */
    public org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType getMd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType)get_store().find_element_user(MD$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "md" element
     */
    public boolean isSetMd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MD$0) != 0;
        }
    }
    
    /**
     * Sets the "md" element
     */
    public void setMd(org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType md)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType)get_store().find_element_user(MD$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType)get_store().add_element_user(MD$0);
            }
            target.set(md);
        }
    }
    
    /**
     * Appends and returns a new empty "md" element
     */
    public org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType addNewMd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainType)get_store().add_element_user(MD$0);
            return target;
        }
    }
    
    /**
     * Unsets the "md" element
     */
    public void unsetMd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MD$0, 0);
        }
    }
}
