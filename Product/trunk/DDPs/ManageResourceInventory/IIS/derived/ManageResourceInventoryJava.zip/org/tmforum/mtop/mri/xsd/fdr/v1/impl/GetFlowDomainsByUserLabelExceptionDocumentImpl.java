/*
 * An XML document type.
 * Localname: getFlowDomainsByUserLabelException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainsByUserLabelExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument
{
    
    public GetFlowDomainsByUserLabelExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINSBYUSERLABELEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainsByUserLabelException");
    
    
    /**
     * Gets the "getFlowDomainsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException getGetFlowDomainsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException)get_store().find_element_user(GETFLOWDOMAINSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainsByUserLabelException" element
     */
    public void setGetFlowDomainsByUserLabelException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException getFlowDomainsByUserLabelException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException)get_store().find_element_user(GETFLOWDOMAINSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException)get_store().add_element_user(GETFLOWDOMAINSBYUSERLABELEXCEPTION$0);
            }
            target.set(getFlowDomainsByUserLabelException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException addNewGetFlowDomainsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException)get_store().add_element_user(GETFLOWDOMAINSBYUSERLABELEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainsByUserLabelExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelExceptionDocument.GetFlowDomainsByUserLabelException
    {
        
        public GetFlowDomainsByUserLabelExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
