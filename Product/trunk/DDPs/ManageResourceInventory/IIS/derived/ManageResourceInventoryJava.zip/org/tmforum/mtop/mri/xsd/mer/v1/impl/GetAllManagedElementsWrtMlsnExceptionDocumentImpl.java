/*
 * An XML document type.
 * Localname: getAllManagedElementsWrtMlsnException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsWrtMlsnException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsWrtMlsnExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument
{
    
    public GetAllManagedElementsWrtMlsnExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSWRTMLSNEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsWrtMlsnException");
    
    
    /**
     * Gets the "getAllManagedElementsWrtMlsnException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException getGetAllManagedElementsWrtMlsnException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTMLSNEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsWrtMlsnException" element
     */
    public void setGetAllManagedElementsWrtMlsnException(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException getAllManagedElementsWrtMlsnException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTMLSNEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTMLSNEXCEPTION$0);
            }
            target.set(getAllManagedElementsWrtMlsnException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsWrtMlsnException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException addNewGetAllManagedElementsWrtMlsnException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTMLSNEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementsWrtMlsnException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementsWrtMlsnExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtMlsnExceptionDocument.GetAllManagedElementsWrtMlsnException
    {
        
        public GetAllManagedElementsWrtMlsnExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
