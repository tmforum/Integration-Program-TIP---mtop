/*
 * An XML document type.
 * Localname: getAllManagedElementNamesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesResponse(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesResponseDocument
{
    
    public GetAllManagedElementNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesResponse");
    
    
    /**
     * Gets the "getAllManagedElementNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType getGetAllManagedElementNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesResponse" element
     */
    public void setGetAllManagedElementNamesResponse(org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType getAllManagedElementNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESRESPONSE$0);
            }
            target.set(getAllManagedElementNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType addNewGetAllManagedElementNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESRESPONSE$0);
            return target;
        }
    }
}
