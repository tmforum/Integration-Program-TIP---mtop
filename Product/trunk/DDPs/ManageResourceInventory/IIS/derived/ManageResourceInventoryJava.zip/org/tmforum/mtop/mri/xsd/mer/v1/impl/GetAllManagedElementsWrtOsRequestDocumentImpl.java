/*
 * An XML document type.
 * Localname: getAllManagedElementsWrtOsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsWrtOsRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsWrtOsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument
{
    
    public GetAllManagedElementsWrtOsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSWRTOSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsWrtOsRequest");
    
    
    /**
     * Gets the "getAllManagedElementsWrtOsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest getGetAllManagedElementsWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTOSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsWrtOsRequest" element
     */
    public void setGetAllManagedElementsWrtOsRequest(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest getAllManagedElementsWrtOsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTOSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTOSREQUEST$0);
            }
            target.set(getAllManagedElementsWrtOsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsWrtOsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest addNewGetAllManagedElementsWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTOSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementsWrtOsRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementsWrtOsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsRequestDocument.GetAllManagedElementsWrtOsRequest
    {
        
        public GetAllManagedElementsWrtOsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OSNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "osName");
        private static final javax.xml.namespace.QName MDNAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "mdName");
        
        
        /**
         * Gets the "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "osName" element
         */
        public void setOsName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType osName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OSNAME$0);
                }
                target.set(osName);
            }
        }
        
        /**
         * Appends and returns a new empty "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OSNAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(MDNAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mdName" element
         */
        public void setMdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType mdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(MDNAME$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(MDNAME$2);
                }
                target.set(mdName);
            }
        }
        
        /**
         * Appends and returns a new empty "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(MDNAME$2);
                return target;
            }
        }
    }
}
