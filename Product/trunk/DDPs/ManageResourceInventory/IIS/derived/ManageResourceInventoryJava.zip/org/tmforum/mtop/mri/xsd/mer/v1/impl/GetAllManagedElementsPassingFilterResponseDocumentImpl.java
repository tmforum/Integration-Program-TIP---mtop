/*
 * An XML document type.
 * Localname: getAllManagedElementsPassingFilterResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsPassingFilterResponse(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsPassingFilterResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsPassingFilterResponseDocument
{
    
    public GetAllManagedElementsPassingFilterResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSPASSINGFILTERRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsPassingFilterResponse");
    
    
    /**
     * Gets the "getAllManagedElementsPassingFilterResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType getGetAllManagedElementsPassingFilterResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTSPASSINGFILTERRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsPassingFilterResponse" element
     */
    public void setGetAllManagedElementsPassingFilterResponse(org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType getAllManagedElementsPassingFilterResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTSPASSINGFILTERRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTSPASSINGFILTERRESPONSE$0);
            }
            target.set(getAllManagedElementsPassingFilterResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsPassingFilterResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType addNewGetAllManagedElementsPassingFilterResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTSPASSINGFILTERRESPONSE$0);
            return target;
        }
    }
}
