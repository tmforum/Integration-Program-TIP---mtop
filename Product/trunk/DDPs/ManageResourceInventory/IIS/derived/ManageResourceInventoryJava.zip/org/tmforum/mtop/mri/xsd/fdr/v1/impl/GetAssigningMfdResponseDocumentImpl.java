/*
 * An XML document type.
 * Localname: getAssigningMfdResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssigningMfdResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssigningMfdResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument
{
    
    public GetAssigningMfdResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSIGNINGMFDRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssigningMfdResponse");
    
    
    /**
     * Gets the "getAssigningMfdResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse getGetAssigningMfdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse)get_store().find_element_user(GETASSIGNINGMFDRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssigningMfdResponse" element
     */
    public void setGetAssigningMfdResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse getAssigningMfdResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse)get_store().find_element_user(GETASSIGNINGMFDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse)get_store().add_element_user(GETASSIGNINGMFDRESPONSE$0);
            }
            target.set(getAssigningMfdResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssigningMfdResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse addNewGetAssigningMfdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse)get_store().add_element_user(GETASSIGNINGMFDRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAssigningMfdResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssigningMfdResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdResponseDocument.GetAssigningMfdResponse
    {
        
        public GetAssigningMfdResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFD$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfd");
        
        
        /**
         * Gets the "mfd" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType getMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "mfd" element
         */
        public boolean isSetMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFD$0) != 0;
            }
        }
        
        /**
         * Sets the "mfd" element
         */
        public void setMfd(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType mfd)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
                }
                target.set(mfd);
            }
        }
        
        /**
         * Appends and returns a new empty "mfd" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType addNewMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
                return target;
            }
        }
        
        /**
         * Unsets the "mfd" element
         */
        public void unsetMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFD$0, 0);
            }
        }
    }
}
