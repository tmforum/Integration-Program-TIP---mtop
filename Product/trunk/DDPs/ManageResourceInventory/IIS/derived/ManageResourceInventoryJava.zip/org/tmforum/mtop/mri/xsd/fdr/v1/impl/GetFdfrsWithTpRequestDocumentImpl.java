/*
 * An XML document type.
 * Localname: getFdfrsWithTpRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrsWithTpRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrsWithTpRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument
{
    
    public GetFdfrsWithTpRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRSWITHTPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrsWithTpRequest");
    
    
    /**
     * Gets the "getFdfrsWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest getGetFdfrsWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest)get_store().find_element_user(GETFDFRSWITHTPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrsWithTpRequest" element
     */
    public void setGetFdfrsWithTpRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest getFdfrsWithTpRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest)get_store().find_element_user(GETFDFRSWITHTPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest)get_store().add_element_user(GETFDFRSWITHTPREQUEST$0);
            }
            target.set(getFdfrsWithTpRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrsWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest addNewGetFdfrsWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest)get_store().add_element_user(GETFDFRSWITHTPREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFdfrsWithTpRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrsWithTpRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpRequestDocument.GetFdfrsWithTpRequest
    {
        
        public GetFdfrsWithTpRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "tpName");
        
        
        /**
         * Gets the "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "tpName" element
         */
        public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
                }
                target.set(tpName);
            }
        }
        
        /**
         * Appends and returns a new empty "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
                return target;
            }
        }
    }
}
