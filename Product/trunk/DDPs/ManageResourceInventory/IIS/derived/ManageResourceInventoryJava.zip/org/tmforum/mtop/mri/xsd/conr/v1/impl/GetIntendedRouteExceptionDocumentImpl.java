/*
 * An XML document type.
 * Localname: getIntendedRouteException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getIntendedRouteException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetIntendedRouteExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument
{
    
    public GetIntendedRouteExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETINTENDEDROUTEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getIntendedRouteException");
    
    
    /**
     * Gets the "getIntendedRouteException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException getGetIntendedRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException)get_store().find_element_user(GETINTENDEDROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getIntendedRouteException" element
     */
    public void setGetIntendedRouteException(org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException getIntendedRouteException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException)get_store().find_element_user(GETINTENDEDROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException)get_store().add_element_user(GETINTENDEDROUTEEXCEPTION$0);
            }
            target.set(getIntendedRouteException);
        }
    }
    
    /**
     * Appends and returns a new empty "getIntendedRouteException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException addNewGetIntendedRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException)get_store().add_element_user(GETINTENDEDROUTEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getIntendedRouteException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetIntendedRouteExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteExceptionDocument.GetIntendedRouteException
    {
        
        public GetIntendedRouteExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
