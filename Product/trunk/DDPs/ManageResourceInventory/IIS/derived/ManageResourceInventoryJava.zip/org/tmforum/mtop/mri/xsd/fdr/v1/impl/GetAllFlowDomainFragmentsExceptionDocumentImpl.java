/*
 * An XML document type.
 * Localname: getAllFlowDomainFragmentsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllFlowDomainFragmentsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFlowDomainFragmentsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument
{
    
    public GetAllFlowDomainFragmentsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFLOWDOMAINFRAGMENTSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllFlowDomainFragmentsException");
    
    
    /**
     * Gets the "getAllFlowDomainFragmentsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException getGetAllFlowDomainFragmentsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException)get_store().find_element_user(GETALLFLOWDOMAINFRAGMENTSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFlowDomainFragmentsException" element
     */
    public void setGetAllFlowDomainFragmentsException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException getAllFlowDomainFragmentsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException)get_store().find_element_user(GETALLFLOWDOMAINFRAGMENTSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException)get_store().add_element_user(GETALLFLOWDOMAINFRAGMENTSEXCEPTION$0);
            }
            target.set(getAllFlowDomainFragmentsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFlowDomainFragmentsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException addNewGetAllFlowDomainFragmentsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException)get_store().add_element_user(GETALLFLOWDOMAINFRAGMENTSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllFlowDomainFragmentsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFlowDomainFragmentsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsExceptionDocument.GetAllFlowDomainFragmentsException
    {
        
        public GetAllFlowDomainFragmentsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
