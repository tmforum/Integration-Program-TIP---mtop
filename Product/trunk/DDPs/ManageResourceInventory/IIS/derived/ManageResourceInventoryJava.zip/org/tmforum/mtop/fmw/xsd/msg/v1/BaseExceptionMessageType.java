/*
 * XML Type:  BaseExceptionMessageType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1;


/**
 * An XML BaseExceptionMessageType(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1).
 *
 * This is a complex type.
 */
public interface BaseExceptionMessageType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(BaseExceptionMessageType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s31584E972C2E29737D22CA318C5A30E3").resolveHandle("baseexceptionmessagetype698ftype");
    
    /**
     * Gets the "header" element
     */
    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header getHeader();
    
    /**
     * True if has "header" element
     */
    boolean isSetHeader();
    
    /**
     * Sets the "header" element
     */
    void setHeader(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header header);
    
    /**
     * Appends and returns a new empty "header" element
     */
    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header addNewHeader();
    
    /**
     * Unsets the "header" element
     */
    void unsetHeader();
    
    /**
     * Gets the "reason" element
     */
    java.lang.String getReason();
    
    /**
     * Gets (as xml) the "reason" element
     */
    org.apache.xmlbeans.XmlString xgetReason();
    
    /**
     * True if has "reason" element
     */
    boolean isSetReason();
    
    /**
     * Sets the "reason" element
     */
    void setReason(java.lang.String reason);
    
    /**
     * Sets (as xml) the "reason" element
     */
    void xsetReason(org.apache.xmlbeans.XmlString reason);
    
    /**
     * Unsets the "reason" element
     */
    void unsetReason();
    
    /**
     * Gets the "vendorExtension" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType.VendorExtension getVendorExtension();
    
    /**
     * True if has "vendorExtension" element
     */
    boolean isSetVendorExtension();
    
    /**
     * Sets the "vendorExtension" element
     */
    void setVendorExtension(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType.VendorExtension vendorExtension);
    
    /**
     * Appends and returns a new empty "vendorExtension" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType.VendorExtension addNewVendorExtension();
    
    /**
     * Unsets the "vendorExtension" element
     */
    void unsetVendorExtension();
    
    /**
     * An XML vendorExtension(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1).
     *
     * This is a complex type.
     */
    public interface VendorExtension extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(VendorExtension.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s31584E972C2E29737D22CA318C5A30E3").resolveHandle("vendorextension0f92elemtype");
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType.VendorExtension newInstance() {
              return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType.VendorExtension) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType.VendorExtension newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType.VendorExtension) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType newInstance() {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
