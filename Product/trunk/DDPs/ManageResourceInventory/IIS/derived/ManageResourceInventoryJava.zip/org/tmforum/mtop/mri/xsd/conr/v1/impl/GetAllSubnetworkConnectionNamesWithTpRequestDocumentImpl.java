/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionNamesWithTpRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionNamesWithTpRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionNamesWithTpRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpRequestDocument
{
    
    public GetAllSubnetworkConnectionNamesWithTpRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionNamesWithTpRequest");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionNamesWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType getGetAllSubnetworkConnectionNamesWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionNamesWithTpRequest" element
     */
    public void setGetAllSubnetworkConnectionNamesWithTpRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType getAllSubnetworkConnectionNamesWithTpRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0);
            }
            target.set(getAllSubnetworkConnectionNamesWithTpRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionNamesWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType addNewGetAllSubnetworkConnectionNamesWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0);
            return target;
        }
    }
}
