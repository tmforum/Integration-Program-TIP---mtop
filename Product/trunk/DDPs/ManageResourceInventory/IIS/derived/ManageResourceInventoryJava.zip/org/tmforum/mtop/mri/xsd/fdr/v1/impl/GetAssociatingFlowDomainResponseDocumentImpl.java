/*
 * An XML document type.
 * Localname: getAssociatingFlowDomainResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssociatingFlowDomainResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssociatingFlowDomainResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument
{
    
    public GetAssociatingFlowDomainResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSOCIATINGFLOWDOMAINRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssociatingFlowDomainResponse");
    
    
    /**
     * Gets the "getAssociatingFlowDomainResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse getGetAssociatingFlowDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse)get_store().find_element_user(GETASSOCIATINGFLOWDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssociatingFlowDomainResponse" element
     */
    public void setGetAssociatingFlowDomainResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse getAssociatingFlowDomainResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse)get_store().find_element_user(GETASSOCIATINGFLOWDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse)get_store().add_element_user(GETASSOCIATINGFLOWDOMAINRESPONSE$0);
            }
            target.set(getAssociatingFlowDomainResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssociatingFlowDomainResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse addNewGetAssociatingFlowDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse)get_store().add_element_user(GETASSOCIATINGFLOWDOMAINRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAssociatingFlowDomainResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssociatingFlowDomainResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainResponseDocument.GetAssociatingFlowDomainResponse
    {
        
        public GetAssociatingFlowDomainResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FD$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fd");
        
        
        /**
         * Gets the "fd" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType getFd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FD$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fd" element
         */
        public boolean isSetFd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FD$0) != 0;
            }
        }
        
        /**
         * Sets the "fd" element
         */
        public void setFd(org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType fd)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FD$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FD$0);
                }
                target.set(fd);
            }
        }
        
        /**
         * Appends and returns a new empty "fd" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType addNewFd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FD$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fd" element
         */
        public void unsetFd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FD$0, 0);
            }
        }
    }
}
