/*
 * An XML document type.
 * Localname: getCrossConnectionsIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetCrossConnectionsIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getCrossConnectionsIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetCrossConnectionsIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetCrossConnectionsIteratorResponseDocument
{
    
    public GetCrossConnectionsIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETCROSSCONNECTIONSITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getCrossConnectionsIteratorResponse");
    
    
    /**
     * Gets the "getCrossConnectionsIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType getGetCrossConnectionsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType)get_store().find_element_user(GETCROSSCONNECTIONSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getCrossConnectionsIteratorResponse" element
     */
    public void setGetCrossConnectionsIteratorResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType getCrossConnectionsIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType)get_store().find_element_user(GETCROSSCONNECTIONSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType)get_store().add_element_user(GETCROSSCONNECTIONSITERATORRESPONSE$0);
            }
            target.set(getCrossConnectionsIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getCrossConnectionsIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType addNewGetCrossConnectionsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType)get_store().add_element_user(GETCROSSCONNECTIONSITERATORRESPONSE$0);
            return target;
        }
    }
}
