/*
 * An XML document type.
 * Localname: getAllFixedSubnetworkConnectionsWithTpResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedSubnetworkConnectionsWithTpResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedSubnetworkConnectionsWithTpResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpResponseDocument
{
    
    public GetAllFixedSubnetworkConnectionsWithTpResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedSubnetworkConnectionsWithTpResponse");
    
    
    /**
     * Gets the "getAllFixedSubnetworkConnectionsWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType getGetAllFixedSubnetworkConnectionsWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedSubnetworkConnectionsWithTpResponse" element
     */
    public void setGetAllFixedSubnetworkConnectionsWithTpResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType getAllFixedSubnetworkConnectionsWithTpResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPRESPONSE$0);
            }
            target.set(getAllFixedSubnetworkConnectionsWithTpResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedSubnetworkConnectionsWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType addNewGetAllFixedSubnetworkConnectionsWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPRESPONSE$0);
            return target;
        }
    }
}
