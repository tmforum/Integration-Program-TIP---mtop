/*
 * An XML document type.
 * Localname: getEquipmentIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getEquipmentIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetEquipmentIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorResponseDocument
{
    
    public GetEquipmentIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETEQUIPMENTITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getEquipmentIteratorResponse");
    
    
    /**
     * Gets the "getEquipmentIteratorResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getGetEquipmentIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETEQUIPMENTITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getEquipmentIteratorResponse" element
     */
    public void setGetEquipmentIteratorResponse(org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getEquipmentIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETEQUIPMENTITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETEQUIPMENTITERATORRESPONSE$0);
            }
            target.set(getEquipmentIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getEquipmentIteratorResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType addNewGetEquipmentIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETEQUIPMENTITERATORRESPONSE$0);
            return target;
        }
    }
}
