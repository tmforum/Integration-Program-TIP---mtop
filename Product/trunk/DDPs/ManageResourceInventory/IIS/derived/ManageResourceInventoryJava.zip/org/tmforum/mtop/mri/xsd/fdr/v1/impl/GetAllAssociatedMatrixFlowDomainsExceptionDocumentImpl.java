/*
 * An XML document type.
 * Localname: getAllAssociatedMatrixFlowDomainsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllAssociatedMatrixFlowDomainsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAssociatedMatrixFlowDomainsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument
{
    
    public GetAllAssociatedMatrixFlowDomainsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLASSOCIATEDMATRIXFLOWDOMAINSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllAssociatedMatrixFlowDomainsException");
    
    
    /**
     * Gets the "getAllAssociatedMatrixFlowDomainsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException getGetAllAssociatedMatrixFlowDomainsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException)get_store().find_element_user(GETALLASSOCIATEDMATRIXFLOWDOMAINSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAssociatedMatrixFlowDomainsException" element
     */
    public void setGetAllAssociatedMatrixFlowDomainsException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException getAllAssociatedMatrixFlowDomainsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException)get_store().find_element_user(GETALLASSOCIATEDMATRIXFLOWDOMAINSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException)get_store().add_element_user(GETALLASSOCIATEDMATRIXFLOWDOMAINSEXCEPTION$0);
            }
            target.set(getAllAssociatedMatrixFlowDomainsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAssociatedMatrixFlowDomainsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException addNewGetAllAssociatedMatrixFlowDomainsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException)get_store().add_element_user(GETALLASSOCIATEDMATRIXFLOWDOMAINSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllAssociatedMatrixFlowDomainsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAssociatedMatrixFlowDomainsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsExceptionDocument.GetAllAssociatedMatrixFlowDomainsException
    {
        
        public GetAllAssociatedMatrixFlowDomainsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
