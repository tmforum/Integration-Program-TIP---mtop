/*
 * An XML document type.
 * Localname: getAssigningMatrixFlowDomainRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssigningMatrixFlowDomainRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssigningMatrixFlowDomainRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument
{
    
    public GetAssigningMatrixFlowDomainRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSIGNINGMATRIXFLOWDOMAINREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssigningMatrixFlowDomainRequest");
    
    
    /**
     * Gets the "getAssigningMatrixFlowDomainRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest getGetAssigningMatrixFlowDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest)get_store().find_element_user(GETASSIGNINGMATRIXFLOWDOMAINREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssigningMatrixFlowDomainRequest" element
     */
    public void setGetAssigningMatrixFlowDomainRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest getAssigningMatrixFlowDomainRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest)get_store().find_element_user(GETASSIGNINGMATRIXFLOWDOMAINREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest)get_store().add_element_user(GETASSIGNINGMATRIXFLOWDOMAINREQUEST$0);
            }
            target.set(getAssigningMatrixFlowDomainRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssigningMatrixFlowDomainRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest addNewGetAssigningMatrixFlowDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest)get_store().add_element_user(GETASSIGNINGMATRIXFLOWDOMAINREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAssigningMatrixFlowDomainRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssigningMatrixFlowDomainRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainRequestDocument.GetAssigningMatrixFlowDomainRequest
    {
        
        public GetAssigningMatrixFlowDomainRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CPTPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "cptpName");
        
        
        /**
         * Gets the "cptpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getCptpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CPTPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "cptpName" element
         */
        public void setCptpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType cptpName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CPTPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CPTPNAME$0);
                }
                target.set(cptpName);
            }
        }
        
        /**
         * Appends and returns a new empty "cptpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewCptpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CPTPNAME$0);
                return target;
            }
        }
    }
}
