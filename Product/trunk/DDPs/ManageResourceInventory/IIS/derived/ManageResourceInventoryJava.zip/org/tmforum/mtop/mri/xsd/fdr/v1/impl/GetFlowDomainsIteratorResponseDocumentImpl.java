/*
 * An XML document type.
 * Localname: getFlowDomainsIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainsIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainsIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument
{
    
    public GetFlowDomainsIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINSITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainsIteratorResponse");
    
    
    /**
     * Gets the "getFlowDomainsIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse getGetFlowDomainsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse)get_store().find_element_user(GETFLOWDOMAINSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainsIteratorResponse" element
     */
    public void setGetFlowDomainsIteratorResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse getFlowDomainsIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse)get_store().find_element_user(GETFLOWDOMAINSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse)get_store().add_element_user(GETFLOWDOMAINSITERATORRESPONSE$0);
            }
            target.set(getFlowDomainsIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainsIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse addNewGetFlowDomainsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse)get_store().add_element_user(GETFLOWDOMAINSITERATORRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainsIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainsIteratorResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsIteratorResponseDocument.GetFlowDomainsIteratorResponse
    {
        
        public GetFlowDomainsIteratorResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdList");
        
        
        /**
         * Gets the "fdList" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FdListType getFdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().find_element_user(FDLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fdList" element
         */
        public boolean isSetFdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "fdList" element
         */
        public void setFdList(org.tmforum.mtop.nrf.xsd.fd.v1.FdListType fdList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().find_element_user(FDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().add_element_user(FDLIST$0);
                }
                target.set(fdList);
            }
        }
        
        /**
         * Appends and returns a new empty "fdList" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FdListType addNewFdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().add_element_user(FDLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fdList" element
         */
        public void unsetFdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDLIST$0, 0);
            }
        }
    }
}
