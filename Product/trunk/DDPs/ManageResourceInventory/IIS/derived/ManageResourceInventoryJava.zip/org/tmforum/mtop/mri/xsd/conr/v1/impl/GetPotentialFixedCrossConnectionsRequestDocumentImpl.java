/*
 * An XML document type.
 * Localname: getPotentialFixedCrossConnectionsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getPotentialFixedCrossConnectionsRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetPotentialFixedCrossConnectionsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument
{
    
    public GetPotentialFixedCrossConnectionsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPOTENTIALFIXEDCROSSCONNECTIONSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getPotentialFixedCrossConnectionsRequest");
    
    
    /**
     * Gets the "getPotentialFixedCrossConnectionsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest getGetPotentialFixedCrossConnectionsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest)get_store().find_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPotentialFixedCrossConnectionsRequest" element
     */
    public void setGetPotentialFixedCrossConnectionsRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest getPotentialFixedCrossConnectionsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest)get_store().find_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest)get_store().add_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSREQUEST$0);
            }
            target.set(getPotentialFixedCrossConnectionsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getPotentialFixedCrossConnectionsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest addNewGetPotentialFixedCrossConnectionsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest)get_store().add_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getPotentialFixedCrossConnectionsRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetPotentialFixedCrossConnectionsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsRequestDocument.GetPotentialFixedCrossConnectionsRequest
    {
        
        public GetPotentialFixedCrossConnectionsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INPUTTP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "inputTp");
        
        
        /**
         * Gets the "inputTp" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getInputTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INPUTTP$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "inputTp" element
         */
        public void setInputTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType inputTp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(INPUTTP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(INPUTTP$0);
                }
                target.set(inputTp);
            }
        }
        
        /**
         * Appends and returns a new empty "inputTp" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewInputTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(INPUTTP$0);
                return target;
            }
        }
    }
}
