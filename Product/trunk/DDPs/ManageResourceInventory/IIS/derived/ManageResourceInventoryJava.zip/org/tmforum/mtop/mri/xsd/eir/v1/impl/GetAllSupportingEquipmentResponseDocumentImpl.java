/*
 * An XML document type.
 * Localname: getAllSupportingEquipmentResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllSupportingEquipmentResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportingEquipmentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentResponseDocument
{
    
    public GetAllSupportingEquipmentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTINGEQUIPMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllSupportingEquipmentResponse");
    
    
    /**
     * Gets the "getAllSupportingEquipmentResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getGetAllSupportingEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportingEquipmentResponse" element
     */
    public void setGetAllSupportingEquipmentResponse(org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getAllSupportingEquipmentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTRESPONSE$0);
            }
            target.set(getAllSupportingEquipmentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportingEquipmentResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType addNewGetAllSupportingEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTRESPONSE$0);
            return target;
        }
    }
}
