/*
 * An XML document type.
 * Localname: getAllSupportingEquipmentNamesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllSupportingEquipmentNamesResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportingEquipmentNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesResponseDocument
{
    
    public GetAllSupportingEquipmentNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTINGEQUIPMENTNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllSupportingEquipmentNamesResponse");
    
    
    /**
     * Gets the "getAllSupportingEquipmentNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType getGetAllSupportingEquipmentNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportingEquipmentNamesResponse" element
     */
    public void setGetAllSupportingEquipmentNamesResponse(org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType getAllSupportingEquipmentNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTNAMESRESPONSE$0);
            }
            target.set(getAllSupportingEquipmentNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportingEquipmentNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType addNewGetAllSupportingEquipmentNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTNAMESRESPONSE$0);
            return target;
        }
    }
}
