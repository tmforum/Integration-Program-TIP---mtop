/*
 * An XML document type.
 * Localname: getSubnetworkConnectionNamesIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionNamesIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionNamesIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionNamesIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionNamesIteratorResponseDocument
{
    
    public GetSubnetworkConnectionNamesIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONNAMESITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionNamesIteratorResponse");
    
    
    /**
     * Gets the "getSubnetworkConnectionNamesIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType getGetSubnetworkConnectionNamesIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETSUBNETWORKCONNECTIONNAMESITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionNamesIteratorResponse" element
     */
    public void setGetSubnetworkConnectionNamesIteratorResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType getSubnetworkConnectionNamesIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETSUBNETWORKCONNECTIONNAMESITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETSUBNETWORKCONNECTIONNAMESITERATORRESPONSE$0);
            }
            target.set(getSubnetworkConnectionNamesIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionNamesIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType addNewGetSubnetworkConnectionNamesIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETSUBNETWORKCONNECTIONNAMESITERATORRESPONSE$0);
            return target;
        }
    }
}
