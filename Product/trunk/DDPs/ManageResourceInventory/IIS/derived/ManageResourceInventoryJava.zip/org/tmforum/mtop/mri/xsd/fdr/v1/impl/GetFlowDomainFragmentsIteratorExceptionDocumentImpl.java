/*
 * An XML document type.
 * Localname: getFlowDomainFragmentsIteratorException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsIteratorExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentsIteratorException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentsIteratorExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsIteratorExceptionDocument
{
    
    public GetFlowDomainFragmentsIteratorExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTSITERATOREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentsIteratorException");
    
    
    /**
     * Gets the "getFlowDomainFragmentsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getGetFlowDomainFragmentsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentsIteratorException" element
     */
    public void setGetFlowDomainFragmentsIteratorException(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getFlowDomainFragmentsIteratorException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSITERATOREXCEPTION$0);
            }
            target.set(getFlowDomainFragmentsIteratorException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType addNewGetFlowDomainFragmentsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSITERATOREXCEPTION$0);
            return target;
        }
    }
}
