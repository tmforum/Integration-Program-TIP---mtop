/*
 * An XML document type.
 * Localname: getCrossConnectionsIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetCrossConnectionsIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getCrossConnectionsIteratorRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetCrossConnectionsIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetCrossConnectionsIteratorRequestDocument
{
    
    public GetCrossConnectionsIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETCROSSCONNECTIONSITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getCrossConnectionsIteratorRequest");
    
    
    /**
     * Gets the "getCrossConnectionsIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getGetCrossConnectionsIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETCROSSCONNECTIONSITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getCrossConnectionsIteratorRequest" element
     */
    public void setGetCrossConnectionsIteratorRequest(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getCrossConnectionsIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETCROSSCONNECTIONSITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETCROSSCONNECTIONSITERATORREQUEST$0);
            }
            target.set(getCrossConnectionsIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getCrossConnectionsIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType addNewGetCrossConnectionsIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETCROSSCONNECTIONSITERATORREQUEST$0);
            return target;
        }
    }
}
