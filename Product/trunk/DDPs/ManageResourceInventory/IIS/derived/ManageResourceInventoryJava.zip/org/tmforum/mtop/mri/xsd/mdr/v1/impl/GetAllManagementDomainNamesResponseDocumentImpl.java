/*
 * An XML document type.
 * Localname: getAllManagementDomainNamesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getAllManagementDomainNamesResponse(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagementDomainNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesResponseDocument
{
    
    public GetAllManagementDomainNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEMENTDOMAINNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getAllManagementDomainNamesResponse");
    
    
    /**
     * Gets the "getAllManagementDomainNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType getGetAllManagementDomainNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETALLMANAGEMENTDOMAINNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagementDomainNamesResponse" element
     */
    public void setGetAllManagementDomainNamesResponse(org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType getAllManagementDomainNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETALLMANAGEMENTDOMAINNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETALLMANAGEMENTDOMAINNAMESRESPONSE$0);
            }
            target.set(getAllManagementDomainNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagementDomainNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType addNewGetAllManagementDomainNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETALLMANAGEMENTDOMAINNAMESRESPONSE$0);
            return target;
        }
    }
}
