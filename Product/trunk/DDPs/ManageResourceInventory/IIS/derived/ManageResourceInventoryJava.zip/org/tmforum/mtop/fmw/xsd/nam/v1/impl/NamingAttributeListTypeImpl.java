/*
 * XML Type:  NamingAttributeListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/nam/v1
 * Java type: org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.nam.v1.impl;
/**
 * An XML NamingAttributeListType(@http://www.tmforum.org/mtop/fmw/xsd/nam/v1).
 *
 * This is a complex type.
 */
public class NamingAttributeListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType
{
    
    public NamingAttributeListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "name");
    
    
    /**
     * Gets a List of "name" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getNameList()
    {
        final class NameList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return NamingAttributeListTypeImpl.this.getNameArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = NamingAttributeListTypeImpl.this.getNameArray(i);
                NamingAttributeListTypeImpl.this.setNameArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { NamingAttributeListTypeImpl.this.insertNewName(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = NamingAttributeListTypeImpl.this.getNameArray(i);
                NamingAttributeListTypeImpl.this.removeName(i);
                return old;
            }
            
            public int size()
                { return NamingAttributeListTypeImpl.this.sizeOfNameArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new NameList();
        }
    }
    
    /**
     * Gets array of all "name" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(NAME$0, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getNameArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "name" element
     */
    public int sizeOfNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NAME$0);
        }
    }
    
    /**
     * Sets array of all "name" element
     */
    public void setNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] nameArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(nameArray, NAME$0);
        }
    }
    
    /**
     * Sets ith "name" element
     */
    public void setNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(name);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewName(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(NAME$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "name" element
     */
    public void removeName(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NAME$0, i);
        }
    }
}
