/*
 * An XML document type.
 * Localname: getBackupRoutesRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getBackupRoutesRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetBackupRoutesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument
{
    
    public GetBackupRoutesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETBACKUPROUTESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getBackupRoutesRequest");
    
    
    /**
     * Gets the "getBackupRoutesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest getGetBackupRoutesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest)get_store().find_element_user(GETBACKUPROUTESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getBackupRoutesRequest" element
     */
    public void setGetBackupRoutesRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest getBackupRoutesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest)get_store().find_element_user(GETBACKUPROUTESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest)get_store().add_element_user(GETBACKUPROUTESREQUEST$0);
            }
            target.set(getBackupRoutesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getBackupRoutesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest addNewGetBackupRoutesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest)get_store().add_element_user(GETBACKUPROUTESREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getBackupRoutesRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetBackupRoutesRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesRequestDocument.GetBackupRoutesRequest
    {
        
        public GetBackupRoutesRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNCNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "sncName");
        private static final javax.xml.namespace.QName ROUTEID$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "routeId");
        private static final javax.xml.namespace.QName ISHIGHERORDERCCLISTINCLUDED$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "isHigherOrderCcListIncluded");
        private static final javax.xml.namespace.QName ADDITIONALINFO$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "additionalInfo");
        
        
        /**
         * Gets the "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "sncName" element
         */
        public void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType sncName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SNCNAME$0);
                }
                target.set(sncName);
            }
        }
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SNCNAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "routeId" element
         */
        public java.lang.String getRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "routeId" element
         */
        public org.apache.xmlbeans.XmlString xgetRouteId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "routeId" element
         */
        public void setRouteId(java.lang.String routeId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROUTEID$2);
                }
                target.setStringValue(routeId);
            }
        }
        
        /**
         * Sets (as xml) the "routeId" element
         */
        public void xsetRouteId(org.apache.xmlbeans.XmlString routeId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ROUTEID$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ROUTEID$2);
                }
                target.set(routeId);
            }
        }
        
        /**
         * Gets the "isHigherOrderCcListIncluded" element
         */
        public boolean getIsHigherOrderCcListIncluded()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISHIGHERORDERCCLISTINCLUDED$4, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "isHigherOrderCcListIncluded" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetIsHigherOrderCcListIncluded()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISHIGHERORDERCCLISTINCLUDED$4, 0);
                return target;
            }
        }
        
        /**
         * Sets the "isHigherOrderCcListIncluded" element
         */
        public void setIsHigherOrderCcListIncluded(boolean isHigherOrderCcListIncluded)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISHIGHERORDERCCLISTINCLUDED$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISHIGHERORDERCCLISTINCLUDED$4);
                }
                target.setBooleanValue(isHigherOrderCcListIncluded);
            }
        }
        
        /**
         * Sets (as xml) the "isHigherOrderCcListIncluded" element
         */
        public void xsetIsHigherOrderCcListIncluded(org.apache.xmlbeans.XmlBoolean isHigherOrderCcListIncluded)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISHIGHERORDERCCLISTINCLUDED$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISHIGHERORDERCCLISTINCLUDED$4);
                }
                target.set(isHigherOrderCcListIncluded);
            }
        }
        
        /**
         * Gets the "additionalInfo" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType getAdditionalInfo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().find_element_user(ADDITIONALINFO$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "additionalInfo" element
         */
        public void setAdditionalInfo(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType additionalInfo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().find_element_user(ADDITIONALINFO$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().add_element_user(ADDITIONALINFO$6);
                }
                target.set(additionalInfo);
            }
        }
        
        /**
         * Appends and returns a new empty "additionalInfo" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType addNewAdditionalInfo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().add_element_user(ADDITIONALINFO$6);
                return target;
            }
        }
    }
}
