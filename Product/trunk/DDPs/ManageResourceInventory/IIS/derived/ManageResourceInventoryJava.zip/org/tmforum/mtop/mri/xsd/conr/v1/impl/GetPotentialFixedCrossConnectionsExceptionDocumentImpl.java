/*
 * An XML document type.
 * Localname: getPotentialFixedCrossConnectionsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getPotentialFixedCrossConnectionsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetPotentialFixedCrossConnectionsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument
{
    
    public GetPotentialFixedCrossConnectionsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPOTENTIALFIXEDCROSSCONNECTIONSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getPotentialFixedCrossConnectionsException");
    
    
    /**
     * Gets the "getPotentialFixedCrossConnectionsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException getGetPotentialFixedCrossConnectionsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException)get_store().find_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPotentialFixedCrossConnectionsException" element
     */
    public void setGetPotentialFixedCrossConnectionsException(org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException getPotentialFixedCrossConnectionsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException)get_store().find_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException)get_store().add_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSEXCEPTION$0);
            }
            target.set(getPotentialFixedCrossConnectionsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getPotentialFixedCrossConnectionsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException addNewGetPotentialFixedCrossConnectionsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException)get_store().add_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getPotentialFixedCrossConnectionsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetPotentialFixedCrossConnectionsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsExceptionDocument.GetPotentialFixedCrossConnectionsException
    {
        
        public GetPotentialFixedCrossConnectionsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
