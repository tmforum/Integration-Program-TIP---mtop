/*
 * An XML document type.
 * Localname: getAssociatingFlowDomainRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssociatingFlowDomainRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssociatingFlowDomainRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument
{
    
    public GetAssociatingFlowDomainRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSOCIATINGFLOWDOMAINREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssociatingFlowDomainRequest");
    
    
    /**
     * Gets the "getAssociatingFlowDomainRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest getGetAssociatingFlowDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest)get_store().find_element_user(GETASSOCIATINGFLOWDOMAINREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssociatingFlowDomainRequest" element
     */
    public void setGetAssociatingFlowDomainRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest getAssociatingFlowDomainRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest)get_store().find_element_user(GETASSOCIATINGFLOWDOMAINREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest)get_store().add_element_user(GETASSOCIATINGFLOWDOMAINREQUEST$0);
            }
            target.set(getAssociatingFlowDomainRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssociatingFlowDomainRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest addNewGetAssociatingFlowDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest)get_store().add_element_user(GETASSOCIATINGFLOWDOMAINREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAssociatingFlowDomainRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssociatingFlowDomainRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainRequestDocument.GetAssociatingFlowDomainRequest
    {
        
        public GetAssociatingFlowDomainRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfdName");
        
        
        /**
         * Gets the "mfdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getMfdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(MFDNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mfdName" element
         */
        public void setMfdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType mfdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(MFDNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(MFDNAME$0);
                }
                target.set(mfdName);
            }
        }
        
        /**
         * Appends and returns a new empty "mfdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewMfdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(MFDNAME$0);
                return target;
            }
        }
    }
}
