/*
 * An XML document type.
 * Localname: getAllSupportedMatrixFlowDomainsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllSupportedMatrixFlowDomainsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportedMatrixFlowDomainsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument
{
    
    public GetAllSupportedMatrixFlowDomainsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTEDMATRIXFLOWDOMAINSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllSupportedMatrixFlowDomainsResponse");
    
    
    /**
     * Gets the "getAllSupportedMatrixFlowDomainsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse getGetAllSupportedMatrixFlowDomainsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse)get_store().find_element_user(GETALLSUPPORTEDMATRIXFLOWDOMAINSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportedMatrixFlowDomainsResponse" element
     */
    public void setGetAllSupportedMatrixFlowDomainsResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse getAllSupportedMatrixFlowDomainsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse)get_store().find_element_user(GETALLSUPPORTEDMATRIXFLOWDOMAINSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse)get_store().add_element_user(GETALLSUPPORTEDMATRIXFLOWDOMAINSRESPONSE$0);
            }
            target.set(getAllSupportedMatrixFlowDomainsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportedMatrixFlowDomainsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse addNewGetAllSupportedMatrixFlowDomainsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse)get_store().add_element_user(GETALLSUPPORTEDMATRIXFLOWDOMAINSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAllSupportedMatrixFlowDomainsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSupportedMatrixFlowDomainsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMatrixFlowDomainsResponseDocument.GetAllSupportedMatrixFlowDomainsResponse
    {
        
        public GetAllSupportedMatrixFlowDomainsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFDLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfdList");
        
        
        /**
         * Gets the "mfdList" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType getMfdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType)get_store().find_element_user(MFDLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "mfdList" element
         */
        public boolean isSetMfdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFDLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "mfdList" element
         */
        public void setMfdList(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType mfdList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType)get_store().find_element_user(MFDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType)get_store().add_element_user(MFDLIST$0);
                }
                target.set(mfdList);
            }
        }
        
        /**
         * Appends and returns a new empty "mfdList" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType addNewMfdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType)get_store().add_element_user(MFDLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "mfdList" element
         */
        public void unsetMfdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFDLIST$0, 0);
            }
        }
    }
}
