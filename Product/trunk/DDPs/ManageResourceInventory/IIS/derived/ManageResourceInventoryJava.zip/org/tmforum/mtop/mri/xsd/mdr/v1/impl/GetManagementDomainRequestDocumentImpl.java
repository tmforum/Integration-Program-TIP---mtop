/*
 * An XML document type.
 * Localname: getManagementDomainRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getManagementDomainRequest(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetManagementDomainRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainRequestDocument
{
    
    public GetManagementDomainRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMANAGEMENTDOMAINREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getManagementDomainRequest");
    
    
    /**
     * Gets the "getManagementDomainRequest" element
     */
    public org.apache.xmlbeans.XmlObject getGetManagementDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(GETMANAGEMENTDOMAINREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getManagementDomainRequest" element
     */
    public void setGetManagementDomainRequest(org.apache.xmlbeans.XmlObject getManagementDomainRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(GETMANAGEMENTDOMAINREQUEST$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(GETMANAGEMENTDOMAINREQUEST$0);
            }
            target.set(getManagementDomainRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getManagementDomainRequest" element
     */
    public org.apache.xmlbeans.XmlObject addNewGetManagementDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(GETMANAGEMENTDOMAINREQUEST$0);
            return target;
        }
    }
}
