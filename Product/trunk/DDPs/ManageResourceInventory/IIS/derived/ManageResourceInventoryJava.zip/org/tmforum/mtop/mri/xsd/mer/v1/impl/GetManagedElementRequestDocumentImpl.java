/*
 * An XML document type.
 * Localname: getManagedElementRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getManagedElementRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetManagedElementRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument
{
    
    public GetManagedElementRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMANAGEDELEMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getManagedElementRequest");
    
    
    /**
     * Gets the "getManagedElementRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest getGetManagedElementRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest)get_store().find_element_user(GETMANAGEDELEMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getManagedElementRequest" element
     */
    public void setGetManagedElementRequest(org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest getManagedElementRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest)get_store().find_element_user(GETMANAGEDELEMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest)get_store().add_element_user(GETMANAGEDELEMENTREQUEST$0);
            }
            target.set(getManagedElementRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getManagedElementRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest addNewGetManagedElementRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest)get_store().add_element_user(GETMANAGEDELEMENTREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getManagedElementRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetManagedElementRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementRequestDocument.GetManagedElementRequest
    {
        
        public GetManagedElementRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "meName");
        
        
        /**
         * Gets the "meName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "meName" element
         */
        public void setMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType meName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$0);
                }
                target.set(meName);
            }
        }
        
        /**
         * Appends and returns a new empty "meName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$0);
                return target;
            }
        }
    }
}
