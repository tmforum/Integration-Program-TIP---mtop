/*
 * XML Type:  MultipleCrossConnectionObjectsResponseType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.MultipleCrossConnectionObjectsResponseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * An XML MultipleCrossConnectionObjectsResponseType(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
 *
 * This is a complex type.
 */
public class MultipleCrossConnectionObjectsResponseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.MultipleCrossConnectionObjectsResponseType
{
    
    public MultipleCrossConnectionObjectsResponseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CCLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "ccList");
    
    
    /**
     * Gets the "ccList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType getCcList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "ccList" element
     */
    public boolean isSetCcList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CCLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "ccList" element
     */
    public void setCcList(org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType ccList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().find_element_user(CCLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCLIST$0);
            }
            target.set(ccList);
        }
    }
    
    /**
     * Appends and returns a new empty "ccList" element
     */
    public org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType addNewCcList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.cc.v1.CrossConnectListType)get_store().add_element_user(CCLIST$0);
            return target;
        }
    }
    
    /**
     * Unsets the "ccList" element
     */
    public void unsetCcList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CCLIST$0, 0);
        }
    }
}
