/*
 * An XML document type.
 * Localname: getAllFlowDomainFragmentsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllFlowDomainFragmentsRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFlowDomainFragmentsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument
{
    
    public GetAllFlowDomainFragmentsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFLOWDOMAINFRAGMENTSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllFlowDomainFragmentsRequest");
    
    
    /**
     * Gets the "getAllFlowDomainFragmentsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest getGetAllFlowDomainFragmentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest)get_store().find_element_user(GETALLFLOWDOMAINFRAGMENTSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFlowDomainFragmentsRequest" element
     */
    public void setGetAllFlowDomainFragmentsRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest getAllFlowDomainFragmentsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest)get_store().find_element_user(GETALLFLOWDOMAINFRAGMENTSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest)get_store().add_element_user(GETALLFLOWDOMAINFRAGMENTSREQUEST$0);
            }
            target.set(getAllFlowDomainFragmentsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFlowDomainFragmentsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest addNewGetAllFlowDomainFragmentsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest)get_store().add_element_user(GETALLFLOWDOMAINFRAGMENTSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllFlowDomainFragmentsRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFlowDomainFragmentsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsRequestDocument.GetAllFlowDomainFragmentsRequest
    {
        
        public GetAllFlowDomainFragmentsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdName");
        private static final javax.xml.namespace.QName CONNECTIVITYRATELIST$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "connectivityRateList");
        
        
        /**
         * Gets the "fdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getFdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(FDNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "fdName" element
         */
        public void setFdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType fdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(FDNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(FDNAME$0);
                }
                target.set(fdName);
            }
        }
        
        /**
         * Appends and returns a new empty "fdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewFdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(FDNAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "connectivityRateList" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getConnectivityRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(CONNECTIVITYRATELIST$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "connectivityRateList" element
         */
        public void setConnectivityRateList(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType connectivityRateList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(CONNECTIVITYRATELIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(CONNECTIVITYRATELIST$2);
                }
                target.set(connectivityRateList);
            }
        }
        
        /**
         * Appends and returns a new empty "connectivityRateList" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewConnectivityRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(CONNECTIVITYRATELIST$2);
                return target;
            }
        }
    }
}
