/*
 * An XML document type.
 * Localname: getAllFixedCrossConnectionsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedCrossConnectionsRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedCrossConnectionsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsRequestDocument
{
    
    public GetAllFixedCrossConnectionsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDCROSSCONNECTIONSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedCrossConnectionsRequest");
    
    
    /**
     * Gets the "getAllFixedCrossConnectionsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType getGetAllFixedCrossConnectionsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType)get_store().find_element_user(GETALLFIXEDCROSSCONNECTIONSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedCrossConnectionsRequest" element
     */
    public void setGetAllFixedCrossConnectionsRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType getAllFixedCrossConnectionsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType)get_store().find_element_user(GETALLFIXEDCROSSCONNECTIONSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType)get_store().add_element_user(GETALLFIXEDCROSSCONNECTIONSREQUEST$0);
            }
            target.set(getAllFixedCrossConnectionsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedCrossConnectionsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType addNewGetAllFixedCrossConnectionsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType)get_store().add_element_user(GETALLFIXEDCROSSCONNECTIONSREQUEST$0);
            return target;
        }
    }
}
