/*
 * An XML document type.
 * Localname: getFlowDomainFragmentRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument
{
    
    public GetFlowDomainFragmentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentRequest");
    
    
    /**
     * Gets the "getFlowDomainFragmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest getGetFlowDomainFragmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest)get_store().find_element_user(GETFLOWDOMAINFRAGMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentRequest" element
     */
    public void setGetFlowDomainFragmentRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest getFlowDomainFragmentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest)get_store().find_element_user(GETFLOWDOMAINFRAGMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest)get_store().add_element_user(GETFLOWDOMAINFRAGMENTREQUEST$0);
            }
            target.set(getFlowDomainFragmentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest addNewGetFlowDomainFragmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest)get_store().add_element_user(GETFLOWDOMAINFRAGMENTREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRequestDocument.GetFlowDomainFragmentRequest
    {
        
        public GetFlowDomainFragmentRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrName");
        
        
        /**
         * Gets the "fdfrName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getFdfrName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(FDFRNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "fdfrName" element
         */
        public void setFdfrName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType fdfrName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(FDFRNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(FDFRNAME$0);
                }
                target.set(fdfrName);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewFdfrName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(FDFRNAME$0);
                return target;
            }
        }
    }
}
