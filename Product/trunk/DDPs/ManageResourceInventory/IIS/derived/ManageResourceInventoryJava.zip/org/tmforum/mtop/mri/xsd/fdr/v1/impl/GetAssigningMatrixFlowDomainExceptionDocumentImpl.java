/*
 * An XML document type.
 * Localname: getAssigningMatrixFlowDomainException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssigningMatrixFlowDomainException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssigningMatrixFlowDomainExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument
{
    
    public GetAssigningMatrixFlowDomainExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSIGNINGMATRIXFLOWDOMAINEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssigningMatrixFlowDomainException");
    
    
    /**
     * Gets the "getAssigningMatrixFlowDomainException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException getGetAssigningMatrixFlowDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException)get_store().find_element_user(GETASSIGNINGMATRIXFLOWDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssigningMatrixFlowDomainException" element
     */
    public void setGetAssigningMatrixFlowDomainException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException getAssigningMatrixFlowDomainException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException)get_store().find_element_user(GETASSIGNINGMATRIXFLOWDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException)get_store().add_element_user(GETASSIGNINGMATRIXFLOWDOMAINEXCEPTION$0);
            }
            target.set(getAssigningMatrixFlowDomainException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssigningMatrixFlowDomainException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException addNewGetAssigningMatrixFlowDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException)get_store().add_element_user(GETASSIGNINGMATRIXFLOWDOMAINEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAssigningMatrixFlowDomainException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssigningMatrixFlowDomainExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainExceptionDocument.GetAssigningMatrixFlowDomainException
    {
        
        public GetAssigningMatrixFlowDomainExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
