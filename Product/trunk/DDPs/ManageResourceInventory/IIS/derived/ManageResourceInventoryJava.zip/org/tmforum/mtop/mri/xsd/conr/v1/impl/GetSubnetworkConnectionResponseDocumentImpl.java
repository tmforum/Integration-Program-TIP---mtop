/*
 * An XML document type.
 * Localname: getSubnetworkConnectionResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument
{
    
    public GetSubnetworkConnectionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionResponse");
    
    
    /**
     * Gets the "getSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse getGetSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse)get_store().find_element_user(GETSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionResponse" element
     */
    public void setGetSubnetworkConnectionResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse getSubnetworkConnectionResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse)get_store().find_element_user(GETSUBNETWORKCONNECTIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse)get_store().add_element_user(GETSUBNETWORKCONNECTIONRESPONSE$0);
            }
            target.set(getSubnetworkConnectionResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse addNewGetSubnetworkConnectionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse)get_store().add_element_user(GETSUBNETWORKCONNECTIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getSubnetworkConnectionResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetSubnetworkConnectionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionResponseDocument.GetSubnetworkConnectionResponse
    {
        
        public GetSubnetworkConnectionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNC$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "snc");
        
        
        /**
         * Gets the "snc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNC$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "snc" element
         */
        public boolean isSetSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNC$0) != 0;
            }
        }
        
        /**
         * Sets the "snc" element
         */
        public void setSnc(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType snc)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNC$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNC$0);
                }
                target.set(snc);
            }
        }
        
        /**
         * Appends and returns a new empty "snc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNC$0);
                return target;
            }
        }
        
        /**
         * Unsets the "snc" element
         */
        public void unsetSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNC$0, 0);
            }
        }
    }
}
