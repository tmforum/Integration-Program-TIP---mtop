/*
 * An XML document type.
 * Localname: getContainedEquipmentResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getContainedEquipmentResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetContainedEquipmentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentResponseDocument
{
    
    public GetContainedEquipmentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETCONTAINEDEQUIPMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getContainedEquipmentResponse");
    
    
    /**
     * Gets the "getContainedEquipmentResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getGetContainedEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETCONTAINEDEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getContainedEquipmentResponse" element
     */
    public void setGetContainedEquipmentResponse(org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getContainedEquipmentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETCONTAINEDEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETCONTAINEDEQUIPMENTRESPONSE$0);
            }
            target.set(getContainedEquipmentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getContainedEquipmentResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType addNewGetContainedEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETCONTAINEDEQUIPMENTRESPONSE$0);
            return target;
        }
    }
}
