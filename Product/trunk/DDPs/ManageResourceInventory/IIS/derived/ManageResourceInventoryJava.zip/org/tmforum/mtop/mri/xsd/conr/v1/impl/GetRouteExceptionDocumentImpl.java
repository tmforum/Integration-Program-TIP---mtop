/*
 * An XML document type.
 * Localname: getRouteException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getRouteException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetRouteExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument
{
    
    public GetRouteExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETROUTEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getRouteException");
    
    
    /**
     * Gets the "getRouteException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException getGetRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException)get_store().find_element_user(GETROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getRouteException" element
     */
    public void setGetRouteException(org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException getRouteException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException)get_store().find_element_user(GETROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException)get_store().add_element_user(GETROUTEEXCEPTION$0);
            }
            target.set(getRouteException);
        }
    }
    
    /**
     * Appends and returns a new empty "getRouteException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException addNewGetRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException)get_store().add_element_user(GETROUTEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getRouteException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetRouteExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetRouteExceptionDocument.GetRouteException
    {
        
        public GetRouteExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
