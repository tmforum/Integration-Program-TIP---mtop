/*
 * XML Type:  PackingEnumType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/hdr/v1
 * Java type: org.tmforum.mtop.fmw.xsd.hdr.v1.PackingEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.hdr.v1.impl;
/**
 * An XML PackingEnumType(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.hdr.v1.PackingEnumType.
 */
public class PackingEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.hdr.v1.PackingEnumType
{
    
    public PackingEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected PackingEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
