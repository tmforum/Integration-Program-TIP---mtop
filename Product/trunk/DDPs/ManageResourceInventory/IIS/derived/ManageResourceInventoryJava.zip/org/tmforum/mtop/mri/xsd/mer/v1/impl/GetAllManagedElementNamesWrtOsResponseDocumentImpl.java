/*
 * An XML document type.
 * Localname: getAllManagedElementNamesWrtOsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesWrtOsResponse(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesWrtOsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsResponseDocument
{
    
    public GetAllManagedElementNamesWrtOsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESWRTOSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesWrtOsResponse");
    
    
    /**
     * Gets the "getAllManagedElementNamesWrtOsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType getGetAllManagedElementNamesWrtOsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTOSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesWrtOsResponse" element
     */
    public void setGetAllManagedElementNamesWrtOsResponse(org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType getAllManagedElementNamesWrtOsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTOSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTOSRESPONSE$0);
            }
            target.set(getAllManagedElementNamesWrtOsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesWrtOsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType addNewGetAllManagedElementNamesWrtOsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTOSRESPONSE$0);
            return target;
        }
    }
}
