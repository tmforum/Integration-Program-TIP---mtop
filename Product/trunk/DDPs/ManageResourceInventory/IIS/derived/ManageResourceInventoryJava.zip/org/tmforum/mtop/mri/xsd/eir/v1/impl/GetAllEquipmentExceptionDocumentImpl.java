/*
 * An XML document type.
 * Localname: getAllEquipmentException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllEquipmentExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument
{
    
    public GetAllEquipmentExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLEQUIPMENTEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllEquipmentException");
    
    
    /**
     * Gets the "getAllEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException getGetAllEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException)get_store().find_element_user(GETALLEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllEquipmentException" element
     */
    public void setGetAllEquipmentException(org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException getAllEquipmentException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException)get_store().find_element_user(GETALLEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException)get_store().add_element_user(GETALLEQUIPMENTEXCEPTION$0);
            }
            target.set(getAllEquipmentException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException addNewGetAllEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException)get_store().add_element_user(GETALLEQUIPMENTEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetAllEquipmentExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentExceptionDocument.GetAllEquipmentException
    {
        
        public GetAllEquipmentExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
