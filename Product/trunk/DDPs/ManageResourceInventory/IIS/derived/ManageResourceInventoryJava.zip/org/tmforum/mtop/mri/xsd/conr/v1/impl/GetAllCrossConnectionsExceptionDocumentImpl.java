/*
 * An XML document type.
 * Localname: getAllCrossConnectionsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllCrossConnectionsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllCrossConnectionsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument
{
    
    public GetAllCrossConnectionsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLCROSSCONNECTIONSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllCrossConnectionsException");
    
    
    /**
     * Gets the "getAllCrossConnectionsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException getGetAllCrossConnectionsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException)get_store().find_element_user(GETALLCROSSCONNECTIONSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllCrossConnectionsException" element
     */
    public void setGetAllCrossConnectionsException(org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException getAllCrossConnectionsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException)get_store().find_element_user(GETALLCROSSCONNECTIONSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException)get_store().add_element_user(GETALLCROSSCONNECTIONSEXCEPTION$0);
            }
            target.set(getAllCrossConnectionsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllCrossConnectionsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException addNewGetAllCrossConnectionsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException)get_store().add_element_user(GETALLCROSSCONNECTIONSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllCrossConnectionsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllCrossConnectionsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsExceptionDocument.GetAllCrossConnectionsException
    {
        
        public GetAllCrossConnectionsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
