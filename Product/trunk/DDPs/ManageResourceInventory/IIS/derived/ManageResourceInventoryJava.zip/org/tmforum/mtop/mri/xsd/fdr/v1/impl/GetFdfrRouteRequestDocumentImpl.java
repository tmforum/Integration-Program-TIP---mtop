/*
 * An XML document type.
 * Localname: getFdfrRouteRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrRouteRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrRouteRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument
{
    
    public GetFdfrRouteRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRROUTEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrRouteRequest");
    
    
    /**
     * Gets the "getFdfrRouteRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest getGetFdfrRouteRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest)get_store().find_element_user(GETFDFRROUTEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrRouteRequest" element
     */
    public void setGetFdfrRouteRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest getFdfrRouteRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest)get_store().find_element_user(GETFDFRROUTEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest)get_store().add_element_user(GETFDFRROUTEREQUEST$0);
            }
            target.set(getFdfrRouteRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrRouteRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest addNewGetFdfrRouteRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest)get_store().add_element_user(GETFDFRROUTEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFdfrRouteRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrRouteRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteRequestDocument.GetFdfrRouteRequest
    {
        
        public GetFdfrRouteRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrName");
        
        
        /**
         * Gets the "fdfrName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getFdfrName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FDFRNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "fdfrName" element
         */
        public void setFdfrName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType fdfrName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FDFRNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FDFRNAME$0);
                }
                target.set(fdfrName);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewFdfrName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FDFRNAME$0);
                return target;
            }
        }
    }
}
