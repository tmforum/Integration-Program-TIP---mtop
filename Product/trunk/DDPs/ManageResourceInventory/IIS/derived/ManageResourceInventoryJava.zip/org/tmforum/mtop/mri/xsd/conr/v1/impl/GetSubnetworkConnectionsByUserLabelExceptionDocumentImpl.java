/*
 * An XML document type.
 * Localname: getSubnetworkConnectionsByUserLabelException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionsByUserLabelExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument
{
    
    public GetSubnetworkConnectionsByUserLabelExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONSBYUSERLABELEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionsByUserLabelException");
    
    
    /**
     * Gets the "getSubnetworkConnectionsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException getGetSubnetworkConnectionsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException)get_store().find_element_user(GETSUBNETWORKCONNECTIONSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionsByUserLabelException" element
     */
    public void setGetSubnetworkConnectionsByUserLabelException(org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException getSubnetworkConnectionsByUserLabelException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException)get_store().find_element_user(GETSUBNETWORKCONNECTIONSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException)get_store().add_element_user(GETSUBNETWORKCONNECTIONSBYUSERLABELEXCEPTION$0);
            }
            target.set(getSubnetworkConnectionsByUserLabelException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException addNewGetSubnetworkConnectionsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException)get_store().add_element_user(GETSUBNETWORKCONNECTIONSBYUSERLABELEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getSubnetworkConnectionsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetSubnetworkConnectionsByUserLabelExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelExceptionDocument.GetSubnetworkConnectionsByUserLabelException
    {
        
        public GetSubnetworkConnectionsByUserLabelExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
