/*
 * An XML document type.
 * Localname: getManagedElementException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getManagedElementException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetManagedElementExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument
{
    
    public GetManagedElementExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMANAGEDELEMENTEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getManagedElementException");
    
    
    /**
     * Gets the "getManagedElementException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException getGetManagedElementException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException)get_store().find_element_user(GETMANAGEDELEMENTEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getManagedElementException" element
     */
    public void setGetManagedElementException(org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException getManagedElementException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException)get_store().find_element_user(GETMANAGEDELEMENTEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException)get_store().add_element_user(GETMANAGEDELEMENTEXCEPTION$0);
            }
            target.set(getManagedElementException);
        }
    }
    
    /**
     * Appends and returns a new empty "getManagedElementException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException addNewGetManagedElementException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException)get_store().add_element_user(GETMANAGEDELEMENTEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getManagedElementException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetManagedElementExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetManagedElementExceptionDocument.GetManagedElementException
    {
        
        public GetManagedElementExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
