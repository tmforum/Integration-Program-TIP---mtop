/*
 * An XML document type.
 * Localname: getAllManagedElementNamesPassingFilterRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesPassingFilterRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesPassingFilterRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument
{
    
    public GetAllManagedElementNamesPassingFilterRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESPASSINGFILTERREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesPassingFilterRequest");
    
    
    /**
     * Gets the "getAllManagedElementNamesPassingFilterRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest getGetAllManagedElementNamesPassingFilterRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESPASSINGFILTERREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesPassingFilterRequest" element
     */
    public void setGetAllManagedElementNamesPassingFilterRequest(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest getAllManagedElementNamesPassingFilterRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESPASSINGFILTERREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESPASSINGFILTERREQUEST$0);
            }
            target.set(getAllManagedElementNamesPassingFilterRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesPassingFilterRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest addNewGetAllManagedElementNamesPassingFilterRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESPASSINGFILTERREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementNamesPassingFilterRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementNamesPassingFilterRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesPassingFilterRequestDocument.GetAllManagedElementNamesPassingFilterRequest
    {
        
        public GetAllManagedElementNamesPassingFilterRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "mdName");
        private static final javax.xml.namespace.QName FILTER$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "filter");
        
        
        /**
         * Gets the "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MDNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mdName" element
         */
        public void setMdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType mdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MDNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MDNAME$0);
                }
                target.set(mdName);
            }
        }
        
        /**
         * Appends and returns a new empty "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MDNAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "filter" element
         */
        public org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType getFilter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType target = null;
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType)get_store().find_element_user(FILTER$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "filter" element
         */
        public void setFilter(org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType filter)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType target = null;
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType)get_store().find_element_user(FILTER$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType)get_store().add_element_user(FILTER$2);
                }
                target.set(filter);
            }
        }
        
        /**
         * Appends and returns a new empty "filter" element
         */
        public org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType addNewFilter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType target = null;
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MeFilterType)get_store().add_element_user(FILTER$2);
                return target;
            }
        }
    }
}
