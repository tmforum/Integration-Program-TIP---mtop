/*
 * An XML document type.
 * Localname: getFlowDomainFragmentsIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentsIteratorRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentsIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsIteratorRequestDocument
{
    
    public GetFlowDomainFragmentsIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTSITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentsIteratorRequest");
    
    
    /**
     * Gets the "getFlowDomainFragmentsIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getGetFlowDomainFragmentsIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentsIteratorRequest" element
     */
    public void setGetFlowDomainFragmentsIteratorRequest(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getFlowDomainFragmentsIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSITERATORREQUEST$0);
            }
            target.set(getFlowDomainFragmentsIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentsIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType addNewGetFlowDomainFragmentsIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSITERATORREQUEST$0);
            return target;
        }
    }
}
