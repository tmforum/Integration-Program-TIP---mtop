/*
 * An XML document type.
 * Localname: getAllFixedSubnetworkConnectionNamesWithTpResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionNamesWithTpResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedSubnetworkConnectionNamesWithTpResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedSubnetworkConnectionNamesWithTpResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionNamesWithTpResponseDocument
{
    
    public GetAllFixedSubnetworkConnectionNamesWithTpResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedSubnetworkConnectionNamesWithTpResponse");
    
    
    /**
     * Gets the "getAllFixedSubnetworkConnectionNamesWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType getGetAllFixedSubnetworkConnectionNamesWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedSubnetworkConnectionNamesWithTpResponse" element
     */
    public void setGetAllFixedSubnetworkConnectionNamesWithTpResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType getAllFixedSubnetworkConnectionNamesWithTpResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPRESPONSE$0);
            }
            target.set(getAllFixedSubnetworkConnectionNamesWithTpResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedSubnetworkConnectionNamesWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType addNewGetAllFixedSubnetworkConnectionNamesWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectNamesResponseType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPRESPONSE$0);
            return target;
        }
    }
}
