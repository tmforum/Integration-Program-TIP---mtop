/*
 * An XML document type.
 * Localname: getAllManagementDomainNamesException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getAllManagementDomainNamesException(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagementDomainNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument
{
    
    public GetAllManagementDomainNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEMENTDOMAINNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getAllManagementDomainNamesException");
    
    
    /**
     * Gets the "getAllManagementDomainNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException getGetAllManagementDomainNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException)get_store().find_element_user(GETALLMANAGEMENTDOMAINNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagementDomainNamesException" element
     */
    public void setGetAllManagementDomainNamesException(org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException getAllManagementDomainNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException)get_store().find_element_user(GETALLMANAGEMENTDOMAINNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException)get_store().add_element_user(GETALLMANAGEMENTDOMAINNAMESEXCEPTION$0);
            }
            target.set(getAllManagementDomainNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagementDomainNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException addNewGetAllManagementDomainNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException)get_store().add_element_user(GETALLMANAGEMENTDOMAINNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllManagementDomainNamesException(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagementDomainNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesExceptionDocument.GetAllManagementDomainNamesException
    {
        
        public GetAllManagementDomainNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
