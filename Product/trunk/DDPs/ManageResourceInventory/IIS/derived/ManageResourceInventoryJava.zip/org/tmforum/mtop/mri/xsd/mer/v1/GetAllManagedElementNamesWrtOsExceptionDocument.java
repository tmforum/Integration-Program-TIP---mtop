/*
 * An XML document type.
 * Localname: getAllManagedElementNamesWrtOsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1;


/**
 * A document containing one getAllManagedElementNamesWrtOsException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public interface GetAllManagedElementNamesWrtOsExceptionDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetAllManagedElementNamesWrtOsExceptionDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s539C0386C779F5E56ABF7BCD697D99A5").resolveHandle("getallmanagedelementnameswrtosexception2715doctype");
    
    /**
     * Gets the "getAllManagedElementNamesWrtOsException" element
     */
    org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException getGetAllManagedElementNamesWrtOsException();
    
    /**
     * Sets the "getAllManagedElementNamesWrtOsException" element
     */
    void setGetAllManagedElementNamesWrtOsException(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException getAllManagedElementNamesWrtOsException);
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesWrtOsException" element
     */
    org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException addNewGetAllManagedElementNamesWrtOsException();
    
    /**
     * An XML getAllManagedElementNamesWrtOsException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public interface GetAllManagedElementNamesWrtOsException extends org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetAllManagedElementNamesWrtOsException.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s539C0386C779F5E56ABF7BCD697D99A5").resolveHandle("getallmanagedelementnameswrtosexception4ab7elemtype");
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException newInstance() {
              return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument.GetAllManagedElementNamesWrtOsException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument newInstance() {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
