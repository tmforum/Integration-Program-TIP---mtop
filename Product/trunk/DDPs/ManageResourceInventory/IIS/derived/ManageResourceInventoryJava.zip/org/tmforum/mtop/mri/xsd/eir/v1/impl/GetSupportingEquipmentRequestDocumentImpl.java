/*
 * An XML document type.
 * Localname: getSupportingEquipmentRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportingEquipmentRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportingEquipmentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentRequestDocument
{
    
    public GetSupportingEquipmentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTINGEQUIPMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportingEquipmentRequest");
    
    
    /**
     * Gets the "getSupportingEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType getGetSupportingEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().find_element_user(GETSUPPORTINGEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportingEquipmentRequest" element
     */
    public void setGetSupportingEquipmentRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType getSupportingEquipmentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().find_element_user(GETSUPPORTINGEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().add_element_user(GETSUPPORTINGEQUIPMENTREQUEST$0);
            }
            target.set(getSupportingEquipmentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportingEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType addNewGetSupportingEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().add_element_user(GETSUPPORTINGEQUIPMENTREQUEST$0);
            return target;
        }
    }
}
