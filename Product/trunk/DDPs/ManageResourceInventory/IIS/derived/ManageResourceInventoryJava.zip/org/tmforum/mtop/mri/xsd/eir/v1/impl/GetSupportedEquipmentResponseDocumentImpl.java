/*
 * An XML document type.
 * Localname: getSupportedEquipmentResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportedEquipmentResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportedEquipmentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentResponseDocument
{
    
    public GetSupportedEquipmentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTEDEQUIPMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportedEquipmentResponse");
    
    
    /**
     * Gets the "getSupportedEquipmentResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getGetSupportedEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETSUPPORTEDEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportedEquipmentResponse" element
     */
    public void setGetSupportedEquipmentResponse(org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getSupportedEquipmentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETSUPPORTEDEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETSUPPORTEDEQUIPMENTRESPONSE$0);
            }
            target.set(getSupportedEquipmentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportedEquipmentResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType addNewGetSupportedEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETSUPPORTEDEQUIPMENTRESPONSE$0);
            return target;
        }
    }
}
