/*
 * XML Type:  ManagementDomainListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/md/v1
 * Java type: org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.md.v1.impl;
/**
 * An XML ManagementDomainListType(@http://www.tmforum.org/mtop/fmw/xsd/md/v1).
 *
 * This is a complex type.
 */
public class ManagementDomainListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainListType
{
    
    public ManagementDomainListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/md/v1", "md");
    
    
    /**
     * Gets a List of "md" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType> getMdList()
    {
        final class MdList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType>
        {
            public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType get(int i)
                { return ManagementDomainListTypeImpl.this.getMdArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType set(int i, org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType o)
            {
                org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType old = ManagementDomainListTypeImpl.this.getMdArray(i);
                ManagementDomainListTypeImpl.this.setMdArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType o)
                { ManagementDomainListTypeImpl.this.insertNewMd(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType old = ManagementDomainListTypeImpl.this.getMdArray(i);
                ManagementDomainListTypeImpl.this.removeMd(i);
                return old;
            }
            
            public int size()
                { return ManagementDomainListTypeImpl.this.sizeOfMdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new MdList();
        }
    }
    
    /**
     * Gets array of all "md" elements
     */
    public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType[] getMdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(MD$0, targetList);
            org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType[] result = new org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "md" element
     */
    public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType getMdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType)get_store().find_element_user(MD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "md" element
     */
    public int sizeOfMdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MD$0);
        }
    }
    
    /**
     * Sets array of all "md" element
     */
    public void setMdArray(org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType[] mdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(mdArray, MD$0);
        }
    }
    
    /**
     * Sets ith "md" element
     */
    public void setMdArray(int i, org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType md)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType)get_store().find_element_user(MD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(md);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "md" element
     */
    public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType insertNewMd(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType)get_store().insert_element_user(MD$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "md" element
     */
    public org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType addNewMd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType)get_store().add_element_user(MD$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "md" element
     */
    public void removeMd(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MD$0, i);
        }
    }
}
