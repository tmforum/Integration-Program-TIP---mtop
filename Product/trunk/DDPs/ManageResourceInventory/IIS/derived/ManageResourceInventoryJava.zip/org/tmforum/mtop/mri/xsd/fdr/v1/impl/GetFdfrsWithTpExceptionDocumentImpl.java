/*
 * An XML document type.
 * Localname: getFdfrsWithTpException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrsWithTpException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrsWithTpExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument
{
    
    public GetFdfrsWithTpExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRSWITHTPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrsWithTpException");
    
    
    /**
     * Gets the "getFdfrsWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException getGetFdfrsWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException)get_store().find_element_user(GETFDFRSWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrsWithTpException" element
     */
    public void setGetFdfrsWithTpException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException getFdfrsWithTpException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException)get_store().find_element_user(GETFDFRSWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException)get_store().add_element_user(GETFDFRSWITHTPEXCEPTION$0);
            }
            target.set(getFdfrsWithTpException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrsWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException addNewGetFdfrsWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException)get_store().add_element_user(GETFDFRSWITHTPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFdfrsWithTpException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrsWithTpExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsWithTpExceptionDocument.GetFdfrsWithTpException
    {
        
        public GetFdfrsWithTpExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
