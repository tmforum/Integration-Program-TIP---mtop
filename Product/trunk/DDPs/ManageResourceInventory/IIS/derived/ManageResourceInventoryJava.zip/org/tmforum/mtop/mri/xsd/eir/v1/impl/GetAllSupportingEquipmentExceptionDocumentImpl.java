/*
 * An XML document type.
 * Localname: getAllSupportingEquipmentException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllSupportingEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportingEquipmentExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument
{
    
    public GetAllSupportingEquipmentExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTINGEQUIPMENTEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllSupportingEquipmentException");
    
    
    /**
     * Gets the "getAllSupportingEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException getGetAllSupportingEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportingEquipmentException" element
     */
    public void setGetAllSupportingEquipmentException(org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException getAllSupportingEquipmentException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTEXCEPTION$0);
            }
            target.set(getAllSupportingEquipmentException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportingEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException addNewGetAllSupportingEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllSupportingEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSupportingEquipmentExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentExceptionDocument.GetAllSupportingEquipmentException
    {
        
        public GetAllSupportingEquipmentExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
