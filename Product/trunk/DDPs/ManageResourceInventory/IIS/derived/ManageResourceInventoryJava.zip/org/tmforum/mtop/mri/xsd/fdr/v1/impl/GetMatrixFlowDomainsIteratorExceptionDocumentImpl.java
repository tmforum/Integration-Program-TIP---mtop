/*
 * An XML document type.
 * Localname: getMatrixFlowDomainsIteratorException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getMatrixFlowDomainsIteratorException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetMatrixFlowDomainsIteratorExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorExceptionDocument
{
    
    public GetMatrixFlowDomainsIteratorExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMATRIXFLOWDOMAINSITERATOREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getMatrixFlowDomainsIteratorException");
    
    
    /**
     * Gets the "getMatrixFlowDomainsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getGetMatrixFlowDomainsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETMATRIXFLOWDOMAINSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getMatrixFlowDomainsIteratorException" element
     */
    public void setGetMatrixFlowDomainsIteratorException(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getMatrixFlowDomainsIteratorException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETMATRIXFLOWDOMAINSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETMATRIXFLOWDOMAINSITERATOREXCEPTION$0);
            }
            target.set(getMatrixFlowDomainsIteratorException);
        }
    }
    
    /**
     * Appends and returns a new empty "getMatrixFlowDomainsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType addNewGetMatrixFlowDomainsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETMATRIXFLOWDOMAINSITERATOREXCEPTION$0);
            return target;
        }
    }
}
