/*
 * An XML document type.
 * Localname: getFlowDomainFragmentsWithTpException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentsWithTpException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentsWithTpExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument
{
    
    public GetFlowDomainFragmentsWithTpExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTSWITHTPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentsWithTpException");
    
    
    /**
     * Gets the "getFlowDomainFragmentsWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException getGetFlowDomainFragmentsWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentsWithTpException" element
     */
    public void setGetFlowDomainFragmentsWithTpException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException getFlowDomainFragmentsWithTpException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSWITHTPEXCEPTION$0);
            }
            target.set(getFlowDomainFragmentsWithTpException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentsWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException addNewGetFlowDomainFragmentsWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSWITHTPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentsWithTpException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentsWithTpExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpExceptionDocument.GetFlowDomainFragmentsWithTpException
    {
        
        public GetFlowDomainFragmentsWithTpExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
