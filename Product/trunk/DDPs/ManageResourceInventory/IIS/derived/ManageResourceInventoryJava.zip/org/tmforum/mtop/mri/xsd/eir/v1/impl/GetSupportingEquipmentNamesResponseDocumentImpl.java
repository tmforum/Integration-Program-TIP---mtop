/*
 * An XML document type.
 * Localname: getSupportingEquipmentNamesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportingEquipmentNamesResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportingEquipmentNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesResponseDocument
{
    
    public GetSupportingEquipmentNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTINGEQUIPMENTNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportingEquipmentNamesResponse");
    
    
    /**
     * Gets the "getSupportingEquipmentNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType getGetSupportingEquipmentNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETSUPPORTINGEQUIPMENTNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportingEquipmentNamesResponse" element
     */
    public void setGetSupportingEquipmentNamesResponse(org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType getSupportingEquipmentNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().find_element_user(GETSUPPORTINGEQUIPMENTNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETSUPPORTINGEQUIPMENTNAMESRESPONSE$0);
            }
            target.set(getSupportingEquipmentNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportingEquipmentNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType addNewGetSupportingEquipmentNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.MultipleObjectNamesResponseType)get_store().add_element_user(GETSUPPORTINGEQUIPMENTNAMESRESPONSE$0);
            return target;
        }
    }
}
