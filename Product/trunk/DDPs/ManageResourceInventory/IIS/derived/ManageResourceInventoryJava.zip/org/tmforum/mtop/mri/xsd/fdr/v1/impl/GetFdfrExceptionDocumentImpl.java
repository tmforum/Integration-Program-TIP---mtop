/*
 * An XML document type.
 * Localname: getFdfrException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument
{
    
    public GetFdfrExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrException");
    
    
    /**
     * Gets the "getFdfrException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException getGetFdfrException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException)get_store().find_element_user(GETFDFREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrException" element
     */
    public void setGetFdfrException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException getFdfrException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException)get_store().find_element_user(GETFDFREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException)get_store().add_element_user(GETFDFREXCEPTION$0);
            }
            target.set(getFdfrException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException addNewGetFdfrException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException)get_store().add_element_user(GETFDFREXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFdfrException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrExceptionDocument.GetFdfrException
    {
        
        public GetFdfrExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
