/*
 * An XML document type.
 * Localname: getEquipmentRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getEquipmentRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetEquipmentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument
{
    
    public GetEquipmentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETEQUIPMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getEquipmentRequest");
    
    
    /**
     * Gets the "getEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest getGetEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest)get_store().find_element_user(GETEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getEquipmentRequest" element
     */
    public void setGetEquipmentRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest getEquipmentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest)get_store().find_element_user(GETEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest)get_store().add_element_user(GETEQUIPMENTREQUEST$0);
            }
            target.set(getEquipmentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest addNewGetEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest)get_store().add_element_user(GETEQUIPMENTREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getEquipmentRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetEquipmentRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentRequestDocument.GetEquipmentRequest
    {
        
        public GetEquipmentRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EQUIPMENTORHOLDERNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "equipmentOrHolderName");
        
        
        /**
         * Gets the "equipmentOrHolderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "equipmentOrHolderName" element
         */
        public void setEquipmentOrHolderName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType equipmentOrHolderName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EQUIPMENTORHOLDERNAME$0);
                }
                target.set(equipmentOrHolderName);
            }
        }
        
        /**
         * Appends and returns a new empty "equipmentOrHolderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EQUIPMENTORHOLDERNAME$0);
                return target;
            }
        }
    }
}
