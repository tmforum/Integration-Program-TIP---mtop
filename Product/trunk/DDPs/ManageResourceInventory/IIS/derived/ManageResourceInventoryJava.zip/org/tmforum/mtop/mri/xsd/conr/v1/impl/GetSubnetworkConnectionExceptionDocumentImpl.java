/*
 * An XML document type.
 * Localname: getSubnetworkConnectionException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument
{
    
    public GetSubnetworkConnectionExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionException");
    
    
    /**
     * Gets the "getSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException getGetSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException)get_store().find_element_user(GETSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionException" element
     */
    public void setGetSubnetworkConnectionException(org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException getSubnetworkConnectionException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException)get_store().find_element_user(GETSUBNETWORKCONNECTIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException)get_store().add_element_user(GETSUBNETWORKCONNECTIONEXCEPTION$0);
            }
            target.set(getSubnetworkConnectionException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException addNewGetSubnetworkConnectionException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException)get_store().add_element_user(GETSUBNETWORKCONNECTIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getSubnetworkConnectionException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetSubnetworkConnectionExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionExceptionDocument.GetSubnetworkConnectionException
    {
        
        public GetSubnetworkConnectionExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
