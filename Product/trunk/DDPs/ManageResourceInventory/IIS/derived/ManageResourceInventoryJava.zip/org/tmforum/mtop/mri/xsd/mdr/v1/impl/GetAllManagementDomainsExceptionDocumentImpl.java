/*
 * An XML document type.
 * Localname: getAllManagementDomainsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getAllManagementDomainsException(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagementDomainsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument
{
    
    public GetAllManagementDomainsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEMENTDOMAINSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getAllManagementDomainsException");
    
    
    /**
     * Gets the "getAllManagementDomainsException" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException getGetAllManagementDomainsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException)get_store().find_element_user(GETALLMANAGEMENTDOMAINSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagementDomainsException" element
     */
    public void setGetAllManagementDomainsException(org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException getAllManagementDomainsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException)get_store().find_element_user(GETALLMANAGEMENTDOMAINSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException)get_store().add_element_user(GETALLMANAGEMENTDOMAINSEXCEPTION$0);
            }
            target.set(getAllManagementDomainsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagementDomainsException" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException addNewGetAllManagementDomainsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException)get_store().add_element_user(GETALLMANAGEMENTDOMAINSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllManagementDomainsException(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagementDomainsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsExceptionDocument.GetAllManagementDomainsException
    {
        
        public GetAllManagementDomainsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
