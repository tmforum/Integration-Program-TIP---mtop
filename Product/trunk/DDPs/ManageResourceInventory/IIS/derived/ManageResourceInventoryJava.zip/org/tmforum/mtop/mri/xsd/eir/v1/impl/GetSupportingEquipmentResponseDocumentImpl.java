/*
 * An XML document type.
 * Localname: getSupportingEquipmentResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportingEquipmentResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportingEquipmentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentResponseDocument
{
    
    public GetSupportingEquipmentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTINGEQUIPMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportingEquipmentResponse");
    
    
    /**
     * Gets the "getSupportingEquipmentResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getGetSupportingEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETSUPPORTINGEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportingEquipmentResponse" element
     */
    public void setGetSupportingEquipmentResponse(org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType getSupportingEquipmentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().find_element_user(GETSUPPORTINGEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETSUPPORTINGEQUIPMENTRESPONSE$0);
            }
            target.set(getSupportingEquipmentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportingEquipmentResponse" element
     */
    public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType addNewGetSupportingEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderListType)get_store().add_element_user(GETSUPPORTINGEQUIPMENTRESPONSE$0);
            return target;
        }
    }
}
