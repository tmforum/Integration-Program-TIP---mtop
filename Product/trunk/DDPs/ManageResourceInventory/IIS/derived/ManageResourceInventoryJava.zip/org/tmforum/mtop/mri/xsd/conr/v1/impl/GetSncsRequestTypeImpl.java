/*
 * XML Type:  GetSncsRequestType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * An XML GetSncsRequestType(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
 *
 * This is a complex type.
 */
public class GetSncsRequestTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType
{
    
    public GetSncsRequestTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SUBNETNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "subnetName");
    private static final javax.xml.namespace.QName CONNECTIONRATELIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "connectionRateList");
    
    
    /**
     * Gets the "subnetName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getSubnetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SUBNETNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "subnetName" element
     */
    public void setSubnetName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType subnetName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SUBNETNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SUBNETNAME$0);
            }
            target.set(subnetName);
        }
    }
    
    /**
     * Appends and returns a new empty "subnetName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewSubnetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SUBNETNAME$0);
            return target;
        }
    }
    
    /**
     * Gets the "connectionRateList" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getConnectionRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(CONNECTIONRATELIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "connectionRateList" element
     */
    public boolean isSetConnectionRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONNECTIONRATELIST$2) != 0;
        }
    }
    
    /**
     * Sets the "connectionRateList" element
     */
    public void setConnectionRateList(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType connectionRateList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(CONNECTIONRATELIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(CONNECTIONRATELIST$2);
            }
            target.set(connectionRateList);
        }
    }
    
    /**
     * Appends and returns a new empty "connectionRateList" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewConnectionRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(CONNECTIONRATELIST$2);
            return target;
        }
    }
    
    /**
     * Unsets the "connectionRateList" element
     */
    public void unsetConnectionRateList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONNECTIONRATELIST$2, 0);
        }
    }
}
