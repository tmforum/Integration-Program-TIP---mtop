/*
 * An XML document type.
 * Localname: getPotentialFixedCrossConnectionsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getPotentialFixedCrossConnectionsResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetPotentialFixedCrossConnectionsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument
{
    
    public GetPotentialFixedCrossConnectionsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPOTENTIALFIXEDCROSSCONNECTIONSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getPotentialFixedCrossConnectionsResponse");
    
    
    /**
     * Gets the "getPotentialFixedCrossConnectionsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse getGetPotentialFixedCrossConnectionsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse)get_store().find_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPotentialFixedCrossConnectionsResponse" element
     */
    public void setGetPotentialFixedCrossConnectionsResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse getPotentialFixedCrossConnectionsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse)get_store().find_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse)get_store().add_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSRESPONSE$0);
            }
            target.set(getPotentialFixedCrossConnectionsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getPotentialFixedCrossConnectionsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse addNewGetPotentialFixedCrossConnectionsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse)get_store().add_element_user(GETPOTENTIALFIXEDCROSSCONNECTIONSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getPotentialFixedCrossConnectionsResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetPotentialFixedCrossConnectionsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCrossConnectionsResponseDocument.GetPotentialFixedCrossConnectionsResponse
    {
        
        public GetPotentialFixedCrossConnectionsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONTAININGTP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "containingTp");
        private static final javax.xml.namespace.QName PORTENTIALCCLIST$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "portentialCcList");
        
        
        /**
         * Gets the "containingTp" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getContainingTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CONTAININGTP$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "containingTp" element
         */
        public boolean isSetContainingTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONTAININGTP$0) != 0;
            }
        }
        
        /**
         * Sets the "containingTp" element
         */
        public void setContainingTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType containingTp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CONTAININGTP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CONTAININGTP$0);
                }
                target.set(containingTp);
            }
        }
        
        /**
         * Appends and returns a new empty "containingTp" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewContainingTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CONTAININGTP$0);
                return target;
            }
        }
        
        /**
         * Unsets the "containingTp" element
         */
        public void unsetContainingTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONTAININGTP$0, 0);
            }
        }
        
        /**
         * Gets the "portentialCcList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getPortentialCcList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PORTENTIALCCLIST$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "portentialCcList" element
         */
        public boolean isSetPortentialCcList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PORTENTIALCCLIST$2) != 0;
            }
        }
        
        /**
         * Sets the "portentialCcList" element
         */
        public void setPortentialCcList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType portentialCcList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PORTENTIALCCLIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PORTENTIALCCLIST$2);
                }
                target.set(portentialCcList);
            }
        }
        
        /**
         * Appends and returns a new empty "portentialCcList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewPortentialCcList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PORTENTIALCCLIST$2);
                return target;
            }
        }
        
        /**
         * Unsets the "portentialCcList" element
         */
        public void unsetPortentialCcList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PORTENTIALCCLIST$2, 0);
            }
        }
    }
}
