/*
 * An XML document type.
 * Localname: getAssigningMfdException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssigningMfdException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssigningMfdExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument
{
    
    public GetAssigningMfdExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSIGNINGMFDEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssigningMfdException");
    
    
    /**
     * Gets the "getAssigningMfdException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException getGetAssigningMfdException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException)get_store().find_element_user(GETASSIGNINGMFDEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssigningMfdException" element
     */
    public void setGetAssigningMfdException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException getAssigningMfdException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException)get_store().find_element_user(GETASSIGNINGMFDEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException)get_store().add_element_user(GETASSIGNINGMFDEXCEPTION$0);
            }
            target.set(getAssigningMfdException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssigningMfdException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException addNewGetAssigningMfdException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException)get_store().add_element_user(GETASSIGNINGMFDEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAssigningMfdException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssigningMfdExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdExceptionDocument.GetAssigningMfdException
    {
        
        public GetAssigningMfdExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
