/*
 * An XML document type.
 * Localname: getAllManagedElementsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument
{
    
    public GetAllManagedElementsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsRequest");
    
    
    /**
     * Gets the "getAllManagedElementsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest getGetAllManagedElementsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest)get_store().find_element_user(GETALLMANAGEDELEMENTSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsRequest" element
     */
    public void setGetAllManagedElementsRequest(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest getAllManagedElementsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest)get_store().find_element_user(GETALLMANAGEDELEMENTSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest)get_store().add_element_user(GETALLMANAGEDELEMENTSREQUEST$0);
            }
            target.set(getAllManagedElementsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest addNewGetAllManagedElementsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest)get_store().add_element_user(GETALLMANAGEDELEMENTSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementsRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsRequestDocument.GetAllManagedElementsRequest
    {
        
        public GetAllManagedElementsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "mdName");
        
        
        /**
         * Gets the "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MDNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mdName" element
         */
        public void setMdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType mdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MDNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MDNAME$0);
                }
                target.set(mdName);
            }
        }
        
        /**
         * Appends and returns a new empty "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MDNAME$0);
                return target;
            }
        }
    }
}
