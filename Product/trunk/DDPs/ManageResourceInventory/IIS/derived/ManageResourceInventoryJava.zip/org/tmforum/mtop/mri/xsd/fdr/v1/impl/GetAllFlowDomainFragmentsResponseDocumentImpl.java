/*
 * An XML document type.
 * Localname: getAllFlowDomainFragmentsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllFlowDomainFragmentsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFlowDomainFragmentsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument
{
    
    public GetAllFlowDomainFragmentsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFLOWDOMAINFRAGMENTSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllFlowDomainFragmentsResponse");
    
    
    /**
     * Gets the "getAllFlowDomainFragmentsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse getGetAllFlowDomainFragmentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse)get_store().find_element_user(GETALLFLOWDOMAINFRAGMENTSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFlowDomainFragmentsResponse" element
     */
    public void setGetAllFlowDomainFragmentsResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse getAllFlowDomainFragmentsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse)get_store().find_element_user(GETALLFLOWDOMAINFRAGMENTSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse)get_store().add_element_user(GETALLFLOWDOMAINFRAGMENTSRESPONSE$0);
            }
            target.set(getAllFlowDomainFragmentsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFlowDomainFragmentsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse addNewGetAllFlowDomainFragmentsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse)get_store().add_element_user(GETALLFLOWDOMAINFRAGMENTSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAllFlowDomainFragmentsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFlowDomainFragmentsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainFragmentsResponseDocument.GetAllFlowDomainFragmentsResponse
    {
        
        public GetAllFlowDomainFragmentsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrList");
        
        
        /**
         * Gets the "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType getFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fdfrList" element
         */
        public boolean isSetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDFRLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "fdfrList" element
         */
        public void setFdfrList(org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType fdfrList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().add_element_user(FDFRLIST$0);
                }
                target.set(fdfrList);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType addNewFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().add_element_user(FDFRLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fdfrList" element
         */
        public void unsetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDFRLIST$0, 0);
            }
        }
    }
}
