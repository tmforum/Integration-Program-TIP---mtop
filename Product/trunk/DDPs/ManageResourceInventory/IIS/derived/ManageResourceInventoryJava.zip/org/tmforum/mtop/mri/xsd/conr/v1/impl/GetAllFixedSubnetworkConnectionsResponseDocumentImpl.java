/*
 * An XML document type.
 * Localname: getAllFixedSubnetworkConnectionsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedSubnetworkConnectionsResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedSubnetworkConnectionsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsResponseDocument
{
    
    public GetAllFixedSubnetworkConnectionsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDSUBNETWORKCONNECTIONSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedSubnetworkConnectionsResponse");
    
    
    /**
     * Gets the "getAllFixedSubnetworkConnectionsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType getGetAllFixedSubnetworkConnectionsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedSubnetworkConnectionsResponse" element
     */
    public void setGetAllFixedSubnetworkConnectionsResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType getAllFixedSubnetworkConnectionsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSRESPONSE$0);
            }
            target.set(getAllFixedSubnetworkConnectionsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedSubnetworkConnectionsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType addNewGetAllFixedSubnetworkConnectionsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSRESPONSE$0);
            return target;
        }
    }
}
