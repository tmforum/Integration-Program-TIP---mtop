/*
 * XML Type:  NameAndValueStringListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/nam/v1
 * Java type: org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.nam.v1.impl;
/**
 * An XML NameAndValueStringListType(@http://www.tmforum.org/mtop/fmw/xsd/nam/v1).
 *
 * This is a complex type.
 */
public class NameAndValueStringListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType
{
    
    public NameAndValueStringListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NVS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "nvs");
    
    
    /**
     * Gets a List of "nvs" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType> getNvsList()
    {
        final class NvsList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType get(int i)
                { return NameAndValueStringListTypeImpl.this.getNvsArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType old = NameAndValueStringListTypeImpl.this.getNvsArray(i);
                NameAndValueStringListTypeImpl.this.setNvsArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType o)
                { NameAndValueStringListTypeImpl.this.insertNewNvs(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType old = NameAndValueStringListTypeImpl.this.getNvsArray(i);
                NameAndValueStringListTypeImpl.this.removeNvs(i);
                return old;
            }
            
            public int size()
                { return NameAndValueStringListTypeImpl.this.sizeOfNvsArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new NvsList();
        }
    }
    
    /**
     * Gets array of all "nvs" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType[] getNvsArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(NVS$0, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "nvs" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType getNvsArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType)get_store().find_element_user(NVS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "nvs" element
     */
    public int sizeOfNvsArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NVS$0);
        }
    }
    
    /**
     * Sets array of all "nvs" element
     */
    public void setNvsArray(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType[] nvsArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(nvsArray, NVS$0);
        }
    }
    
    /**
     * Sets ith "nvs" element
     */
    public void setNvsArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType nvs)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType)get_store().find_element_user(NVS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(nvs);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "nvs" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType insertNewNvs(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType)get_store().insert_element_user(NVS$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "nvs" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType addNewNvs()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndStringValueType)get_store().add_element_user(NVS$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "nvs" element
     */
    public void removeNvs(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NVS$0, i);
        }
    }
}
