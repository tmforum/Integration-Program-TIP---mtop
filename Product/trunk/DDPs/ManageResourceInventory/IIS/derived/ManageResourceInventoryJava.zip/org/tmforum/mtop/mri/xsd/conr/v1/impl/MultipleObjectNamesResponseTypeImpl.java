/*
 * XML Type:  MultipleObjectNamesResponseType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * An XML MultipleObjectNamesResponseType(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
 *
 * This is a complex type.
 */
public class MultipleObjectNamesResponseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.MultipleObjectNamesResponseType
{
    
    public MultipleObjectNamesResponseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NAMELIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "nameList");
    
    
    /**
     * Gets the "nameList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(NAMELIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "nameList" element
     */
    public boolean isSetNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NAMELIST$0) != 0;
        }
    }
    
    /**
     * Sets the "nameList" element
     */
    public void setNameList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType nameList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(NAMELIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(NAMELIST$0);
            }
            target.set(nameList);
        }
    }
    
    /**
     * Appends and returns a new empty "nameList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(NAMELIST$0);
            return target;
        }
    }
    
    /**
     * Unsets the "nameList" element
     */
    public void unsetNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NAMELIST$0, 0);
        }
    }
}
