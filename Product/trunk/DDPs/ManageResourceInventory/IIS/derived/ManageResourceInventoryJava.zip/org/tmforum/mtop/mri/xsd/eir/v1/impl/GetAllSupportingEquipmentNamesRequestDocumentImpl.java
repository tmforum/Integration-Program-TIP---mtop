/*
 * An XML document type.
 * Localname: getAllSupportingEquipmentNamesRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllSupportingEquipmentNamesRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportingEquipmentNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesRequestDocument
{
    
    public GetAllSupportingEquipmentNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTINGEQUIPMENTNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllSupportingEquipmentNamesRequest");
    
    
    /**
     * Gets the "getAllSupportingEquipmentNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType getGetAllSupportingEquipmentNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportingEquipmentNamesRequest" element
     */
    public void setGetAllSupportingEquipmentNamesRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType getAllSupportingEquipmentNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTNAMESREQUEST$0);
            }
            target.set(getAllSupportingEquipmentNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportingEquipmentNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType addNewGetAllSupportingEquipmentNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTNAMESREQUEST$0);
            return target;
        }
    }
}
