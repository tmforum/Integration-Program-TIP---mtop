/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionsWithTpResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionsWithTpResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionsWithTpResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpResponseDocument
{
    
    public GetAllSubnetworkConnectionsWithTpResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONSWITHTPRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionsWithTpResponse");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionsWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType getGetAllSubnetworkConnectionsWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionsWithTpResponse" element
     */
    public void setGetAllSubnetworkConnectionsWithTpResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType getAllSubnetworkConnectionsWithTpResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPRESPONSE$0);
            }
            target.set(getAllSubnetworkConnectionsWithTpResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionsWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType addNewGetAllSubnetworkConnectionsWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPRESPONSE$0);
            return target;
        }
    }
}
