/*
 * An XML document type.
 * Localname: getAllManagedElementNamesException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument
{
    
    public GetAllManagedElementNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesException");
    
    
    /**
     * Gets the "getAllManagedElementNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException getGetAllManagedElementNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesException" element
     */
    public void setGetAllManagedElementNamesException(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException getAllManagedElementNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESEXCEPTION$0);
            }
            target.set(getAllManagedElementNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException addNewGetAllManagedElementNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementNamesException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesExceptionDocument.GetAllManagedElementNamesException
    {
        
        public GetAllManagedElementNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
