/*
 * An XML document type.
 * Localname: getFlowDomainFragmentsWithTpRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentsWithTpRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentsWithTpRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument
{
    
    public GetFlowDomainFragmentsWithTpRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTSWITHTPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentsWithTpRequest");
    
    
    /**
     * Gets the "getFlowDomainFragmentsWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest getGetFlowDomainFragmentsWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSWITHTPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentsWithTpRequest" element
     */
    public void setGetFlowDomainFragmentsWithTpRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest getFlowDomainFragmentsWithTpRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSWITHTPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSWITHTPREQUEST$0);
            }
            target.set(getFlowDomainFragmentsWithTpRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentsWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest addNewGetFlowDomainFragmentsWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSWITHTPREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentsWithTpRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentsWithTpRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpRequestDocument.GetFlowDomainFragmentsWithTpRequest
    {
        
        public GetFlowDomainFragmentsWithTpRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "tpName");
        
        
        /**
         * Gets the "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "tpName" element
         */
        public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType tpName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(TPNAME$0);
                }
                target.set(tpName);
            }
        }
        
        /**
         * Appends and returns a new empty "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(TPNAME$0);
                return target;
            }
        }
    }
}
