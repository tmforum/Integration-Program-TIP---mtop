/*
 * An XML document type.
 * Localname: getAllManagedElementNamesWrtMlsnResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesWrtMlsnResponse(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesWrtMlsnResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtMlsnResponseDocument
{
    
    public GetAllManagedElementNamesWrtMlsnResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESWRTMLSNRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesWrtMlsnResponse");
    
    
    /**
     * Gets the "getAllManagedElementNamesWrtMlsnResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType getGetAllManagedElementNamesWrtMlsnResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTMLSNRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesWrtMlsnResponse" element
     */
    public void setGetAllManagedElementNamesWrtMlsnResponse(org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType getAllManagedElementNamesWrtMlsnResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTMLSNRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTMLSNRESPONSE$0);
            }
            target.set(getAllManagedElementNamesWrtMlsnResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesWrtMlsnResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType addNewGetAllManagedElementNamesWrtMlsnResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectNamesResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTMLSNRESPONSE$0);
            return target;
        }
    }
}
