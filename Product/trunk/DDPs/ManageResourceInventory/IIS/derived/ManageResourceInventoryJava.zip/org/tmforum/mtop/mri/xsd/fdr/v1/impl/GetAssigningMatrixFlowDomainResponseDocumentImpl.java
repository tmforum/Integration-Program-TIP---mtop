/*
 * An XML document type.
 * Localname: getAssigningMatrixFlowDomainResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssigningMatrixFlowDomainResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssigningMatrixFlowDomainResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument
{
    
    public GetAssigningMatrixFlowDomainResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSIGNINGMATRIXFLOWDOMAINRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssigningMatrixFlowDomainResponse");
    
    
    /**
     * Gets the "getAssigningMatrixFlowDomainResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse getGetAssigningMatrixFlowDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse)get_store().find_element_user(GETASSIGNINGMATRIXFLOWDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssigningMatrixFlowDomainResponse" element
     */
    public void setGetAssigningMatrixFlowDomainResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse getAssigningMatrixFlowDomainResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse)get_store().find_element_user(GETASSIGNINGMATRIXFLOWDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse)get_store().add_element_user(GETASSIGNINGMATRIXFLOWDOMAINRESPONSE$0);
            }
            target.set(getAssigningMatrixFlowDomainResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssigningMatrixFlowDomainResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse addNewGetAssigningMatrixFlowDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse)get_store().add_element_user(GETASSIGNINGMATRIXFLOWDOMAINRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAssigningMatrixFlowDomainResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssigningMatrixFlowDomainResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMatrixFlowDomainResponseDocument.GetAssigningMatrixFlowDomainResponse
    {
        
        public GetAssigningMatrixFlowDomainResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFD$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfd");
        
        
        /**
         * Gets the "mfd" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType getMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "mfd" element
         */
        public boolean isSetMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFD$0) != 0;
            }
        }
        
        /**
         * Sets the "mfd" element
         */
        public void setMfd(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType mfd)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().find_element_user(MFD$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
                }
                target.set(mfd);
            }
        }
        
        /**
         * Appends and returns a new empty "mfd" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType addNewMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainType)get_store().add_element_user(MFD$0);
                return target;
            }
        }
        
        /**
         * Unsets the "mfd" element
         */
        public void unsetMfd()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFD$0, 0);
            }
        }
    }
}
