/*
 * An XML document type.
 * Localname: getMatrixFlowDomainsIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getMatrixFlowDomainsIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetMatrixFlowDomainsIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument
{
    
    public GetMatrixFlowDomainsIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMATRIXFLOWDOMAINSITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getMatrixFlowDomainsIteratorResponse");
    
    
    /**
     * Gets the "getMatrixFlowDomainsIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse getGetMatrixFlowDomainsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse)get_store().find_element_user(GETMATRIXFLOWDOMAINSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getMatrixFlowDomainsIteratorResponse" element
     */
    public void setGetMatrixFlowDomainsIteratorResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse getMatrixFlowDomainsIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse)get_store().find_element_user(GETMATRIXFLOWDOMAINSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse)get_store().add_element_user(GETMATRIXFLOWDOMAINSITERATORRESPONSE$0);
            }
            target.set(getMatrixFlowDomainsIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getMatrixFlowDomainsIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse addNewGetMatrixFlowDomainsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse)get_store().add_element_user(GETMATRIXFLOWDOMAINSITERATORRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getMatrixFlowDomainsIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetMatrixFlowDomainsIteratorResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetMatrixFlowDomainsIteratorResponseDocument.GetMatrixFlowDomainsIteratorResponse
    {
        
        public GetMatrixFlowDomainsIteratorResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFDLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfdList");
        
        
        /**
         * Gets the "mfdList" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType getMfdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType)get_store().find_element_user(MFDLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "mfdList" element
         */
        public boolean isSetMfdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFDLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "mfdList" element
         */
        public void setMfdList(org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType mfdList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType)get_store().find_element_user(MFDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType)get_store().add_element_user(MFDLIST$0);
                }
                target.set(mfdList);
            }
        }
        
        /**
         * Appends and returns a new empty "mfdList" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType addNewMfdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MatrixFlowDomainListType)get_store().add_element_user(MFDLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "mfdList" element
         */
        public void unsetMfdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFDLIST$0, 0);
            }
        }
    }
}
