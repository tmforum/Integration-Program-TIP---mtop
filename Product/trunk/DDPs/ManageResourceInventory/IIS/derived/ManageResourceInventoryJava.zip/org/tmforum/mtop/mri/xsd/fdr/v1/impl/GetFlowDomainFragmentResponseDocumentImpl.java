/*
 * An XML document type.
 * Localname: getFlowDomainFragmentResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument
{
    
    public GetFlowDomainFragmentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentResponse");
    
    
    /**
     * Gets the "getFlowDomainFragmentResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse getGetFlowDomainFragmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse)get_store().find_element_user(GETFLOWDOMAINFRAGMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentResponse" element
     */
    public void setGetFlowDomainFragmentResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse getFlowDomainFragmentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse)get_store().find_element_user(GETFLOWDOMAINFRAGMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse)get_store().add_element_user(GETFLOWDOMAINFRAGMENTRESPONSE$0);
            }
            target.set(getFlowDomainFragmentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse addNewGetFlowDomainFragmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse)get_store().add_element_user(GETFLOWDOMAINFRAGMENTRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentResponseDocument.GetFlowDomainFragmentResponse
    {
        
        public GetFlowDomainFragmentResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFR$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfr");
        
        
        /**
         * Gets the "fdfr" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType getFdfr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().find_element_user(FDFR$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fdfr" element
         */
        public boolean isSetFdfr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDFR$0) != 0;
            }
        }
        
        /**
         * Sets the "fdfr" element
         */
        public void setFdfr(org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType fdfr)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().find_element_user(FDFR$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().add_element_user(FDFR$0);
                }
                target.set(fdfr);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfr" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType addNewFdfr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().add_element_user(FDFR$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fdfr" element
         */
        public void unsetFdfr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDFR$0, 0);
            }
        }
    }
}
