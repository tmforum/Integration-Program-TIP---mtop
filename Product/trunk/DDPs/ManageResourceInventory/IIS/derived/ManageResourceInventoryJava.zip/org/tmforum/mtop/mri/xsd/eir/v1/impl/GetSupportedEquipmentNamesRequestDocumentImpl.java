/*
 * An XML document type.
 * Localname: getSupportedEquipmentNamesRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportedEquipmentNamesRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportedEquipmentNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentNamesRequestDocument
{
    
    public GetSupportedEquipmentNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTEDEQUIPMENTNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportedEquipmentNamesRequest");
    
    
    /**
     * Gets the "getSupportedEquipmentNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType getGetSupportedEquipmentNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().find_element_user(GETSUPPORTEDEQUIPMENTNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportedEquipmentNamesRequest" element
     */
    public void setGetSupportedEquipmentNamesRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType getSupportedEquipmentNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().find_element_user(GETSUPPORTEDEQUIPMENTNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().add_element_user(GETSUPPORTEDEQUIPMENTNAMESREQUEST$0);
            }
            target.set(getSupportedEquipmentNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportedEquipmentNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType addNewGetSupportedEquipmentNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().add_element_user(GETSUPPORTEDEQUIPMENTNAMESREQUEST$0);
            return target;
        }
    }
}
