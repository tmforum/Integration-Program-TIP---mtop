/*
 * An XML document type.
 * Localname: getAllEquipmentNamesException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllEquipmentNamesException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllEquipmentNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument
{
    
    public GetAllEquipmentNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLEQUIPMENTNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllEquipmentNamesException");
    
    
    /**
     * Gets the "getAllEquipmentNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException getGetAllEquipmentNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException)get_store().find_element_user(GETALLEQUIPMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllEquipmentNamesException" element
     */
    public void setGetAllEquipmentNamesException(org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException getAllEquipmentNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException)get_store().find_element_user(GETALLEQUIPMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException)get_store().add_element_user(GETALLEQUIPMENTNAMESEXCEPTION$0);
            }
            target.set(getAllEquipmentNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllEquipmentNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException addNewGetAllEquipmentNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException)get_store().add_element_user(GETALLEQUIPMENTNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllEquipmentNamesException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetAllEquipmentNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesExceptionDocument.GetAllEquipmentNamesException
    {
        
        public GetAllEquipmentNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
