/*
 * An XML document type.
 * Localname: getFdfrRouteException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrRouteException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrRouteExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument
{
    
    public GetFdfrRouteExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRROUTEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrRouteException");
    
    
    /**
     * Gets the "getFdfrRouteException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException getGetFdfrRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException)get_store().find_element_user(GETFDFRROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrRouteException" element
     */
    public void setGetFdfrRouteException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException getFdfrRouteException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException)get_store().find_element_user(GETFDFRROUTEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException)get_store().add_element_user(GETFDFRROUTEEXCEPTION$0);
            }
            target.set(getFdfrRouteException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrRouteException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException addNewGetFdfrRouteException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException)get_store().add_element_user(GETFDFRROUTEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFdfrRouteException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrRouteExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteExceptionDocument.GetFdfrRouteException
    {
        
        public GetFdfrRouteExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
