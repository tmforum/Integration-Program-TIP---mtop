/*
 * An XML document type.
 * Localname: getAllAssociatedMatrixFlowDomainsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllAssociatedMatrixFlowDomainsRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAssociatedMatrixFlowDomainsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument
{
    
    public GetAllAssociatedMatrixFlowDomainsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLASSOCIATEDMATRIXFLOWDOMAINSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllAssociatedMatrixFlowDomainsRequest");
    
    
    /**
     * Gets the "getAllAssociatedMatrixFlowDomainsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest getGetAllAssociatedMatrixFlowDomainsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest)get_store().find_element_user(GETALLASSOCIATEDMATRIXFLOWDOMAINSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAssociatedMatrixFlowDomainsRequest" element
     */
    public void setGetAllAssociatedMatrixFlowDomainsRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest getAllAssociatedMatrixFlowDomainsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest)get_store().find_element_user(GETALLASSOCIATEDMATRIXFLOWDOMAINSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest)get_store().add_element_user(GETALLASSOCIATEDMATRIXFLOWDOMAINSREQUEST$0);
            }
            target.set(getAllAssociatedMatrixFlowDomainsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAssociatedMatrixFlowDomainsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest addNewGetAllAssociatedMatrixFlowDomainsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest)get_store().add_element_user(GETALLASSOCIATEDMATRIXFLOWDOMAINSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllAssociatedMatrixFlowDomainsRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAssociatedMatrixFlowDomainsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMatrixFlowDomainsRequestDocument.GetAllAssociatedMatrixFlowDomainsRequest
    {
        
        public GetAllAssociatedMatrixFlowDomainsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName HOLDERNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "holderName");
        
        
        /**
         * Gets the "holderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(HOLDERNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "holderName" element
         */
        public void setHolderName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType holderName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(HOLDERNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(HOLDERNAME$0);
                }
                target.set(holderName);
            }
        }
        
        /**
         * Appends and returns a new empty "holderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(HOLDERNAME$0);
                return target;
            }
        }
    }
}
