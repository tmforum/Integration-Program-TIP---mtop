/*
 * An XML document type.
 * Localname: getRouteRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getRouteRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetRouteRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument
{
    
    public GetRouteRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETROUTEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getRouteRequest");
    
    
    /**
     * Gets the "getRouteRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest getGetRouteRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest)get_store().find_element_user(GETROUTEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getRouteRequest" element
     */
    public void setGetRouteRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest getRouteRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest)get_store().find_element_user(GETROUTEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest)get_store().add_element_user(GETROUTEREQUEST$0);
            }
            target.set(getRouteRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getRouteRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest addNewGetRouteRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest)get_store().add_element_user(GETROUTEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getRouteRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetRouteRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetRouteRequestDocument.GetRouteRequest
    {
        
        public GetRouteRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNCNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "sncName");
        private static final javax.xml.namespace.QName INCLUDEHIGHERORDERCCS$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "includeHigherOrderCCs");
        
        
        /**
         * Gets the "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "sncName" element
         */
        public void setSncName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType sncName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SNCNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SNCNAME$0);
                }
                target.set(sncName);
            }
        }
        
        /**
         * Appends and returns a new empty "sncName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewSncName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SNCNAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "includeHigherOrderCCs" element
         */
        public boolean getIncludeHigherOrderCCs()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INCLUDEHIGHERORDERCCS$2, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "includeHigherOrderCCs" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetIncludeHigherOrderCCs()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(INCLUDEHIGHERORDERCCS$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "includeHigherOrderCCs" element
         */
        public void setIncludeHigherOrderCCs(boolean includeHigherOrderCCs)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INCLUDEHIGHERORDERCCS$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INCLUDEHIGHERORDERCCS$2);
                }
                target.setBooleanValue(includeHigherOrderCCs);
            }
        }
        
        /**
         * Sets (as xml) the "includeHigherOrderCCs" element
         */
        public void xsetIncludeHigherOrderCCs(org.apache.xmlbeans.XmlBoolean includeHigherOrderCCs)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(INCLUDEHIGHERORDERCCS$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(INCLUDEHIGHERORDERCCS$2);
                }
                target.set(includeHigherOrderCCs);
            }
        }
    }
}
