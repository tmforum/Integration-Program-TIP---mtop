/*
 * An XML document type.
 * Localname: getAssociatingFlowDomainException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssociatingFlowDomainException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssociatingFlowDomainExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument
{
    
    public GetAssociatingFlowDomainExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSOCIATINGFLOWDOMAINEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssociatingFlowDomainException");
    
    
    /**
     * Gets the "getAssociatingFlowDomainException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException getGetAssociatingFlowDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException)get_store().find_element_user(GETASSOCIATINGFLOWDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssociatingFlowDomainException" element
     */
    public void setGetAssociatingFlowDomainException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException getAssociatingFlowDomainException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException)get_store().find_element_user(GETASSOCIATINGFLOWDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException)get_store().add_element_user(GETASSOCIATINGFLOWDOMAINEXCEPTION$0);
            }
            target.set(getAssociatingFlowDomainException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssociatingFlowDomainException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException addNewGetAssociatingFlowDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException)get_store().add_element_user(GETASSOCIATINGFLOWDOMAINEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAssociatingFlowDomainException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssociatingFlowDomainExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFlowDomainExceptionDocument.GetAssociatingFlowDomainException
    {
        
        public GetAssociatingFlowDomainExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
