/*
 * An XML document type.
 * Localname: getAllFixedCrossConnectionsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedCrossConnectionsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedCrossConnectionsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument
{
    
    public GetAllFixedCrossConnectionsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDCROSSCONNECTIONSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedCrossConnectionsException");
    
    
    /**
     * Gets the "getAllFixedCrossConnectionsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException getGetAllFixedCrossConnectionsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException)get_store().find_element_user(GETALLFIXEDCROSSCONNECTIONSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedCrossConnectionsException" element
     */
    public void setGetAllFixedCrossConnectionsException(org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException getAllFixedCrossConnectionsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException)get_store().find_element_user(GETALLFIXEDCROSSCONNECTIONSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException)get_store().add_element_user(GETALLFIXEDCROSSCONNECTIONSEXCEPTION$0);
            }
            target.set(getAllFixedCrossConnectionsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedCrossConnectionsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException addNewGetAllFixedCrossConnectionsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException)get_store().add_element_user(GETALLFIXEDCROSSCONNECTIONSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllFixedCrossConnectionsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFixedCrossConnectionsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsExceptionDocument.GetAllFixedCrossConnectionsException
    {
        
        public GetAllFixedCrossConnectionsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
