/*
 * An XML document type.
 * Localname: getManagementDomainResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getManagementDomainResponse(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetManagementDomainResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainResponseDocument
{
    
    public GetManagementDomainResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMANAGEMENTDOMAINRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getManagementDomainResponse");
    
    
    /**
     * Gets the "getManagementDomainResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType getGetManagementDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType)get_store().find_element_user(GETMANAGEMENTDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getManagementDomainResponse" element
     */
    public void setGetManagementDomainResponse(org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType getManagementDomainResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType)get_store().find_element_user(GETMANAGEMENTDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType)get_store().add_element_user(GETMANAGEMENTDOMAINRESPONSE$0);
            }
            target.set(getManagementDomainResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getManagementDomainResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType addNewGetManagementDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.SingeObjectResponseType)get_store().add_element_user(GETMANAGEMENTDOMAINRESPONSE$0);
            return target;
        }
    }
}
