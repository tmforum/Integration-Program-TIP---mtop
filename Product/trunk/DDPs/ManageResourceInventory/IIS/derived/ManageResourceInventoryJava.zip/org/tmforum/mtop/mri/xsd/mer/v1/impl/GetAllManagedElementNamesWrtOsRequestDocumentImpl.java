/*
 * An XML document type.
 * Localname: getAllManagedElementNamesWrtOsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementNamesWrtOsRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementNamesWrtOsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument
{
    
    public GetAllManagedElementNamesWrtOsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTNAMESWRTOSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementNamesWrtOsRequest");
    
    
    /**
     * Gets the "getAllManagedElementNamesWrtOsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest getGetAllManagedElementNamesWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTOSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementNamesWrtOsRequest" element
     */
    public void setGetAllManagedElementNamesWrtOsRequest(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest getAllManagedElementNamesWrtOsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest)get_store().find_element_user(GETALLMANAGEDELEMENTNAMESWRTOSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTOSREQUEST$0);
            }
            target.set(getAllManagedElementNamesWrtOsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementNamesWrtOsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest addNewGetAllManagedElementNamesWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest)get_store().add_element_user(GETALLMANAGEDELEMENTNAMESWRTOSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementNamesWrtOsRequest(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementNamesWrtOsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementNamesWrtOsRequestDocument.GetAllManagedElementNamesWrtOsRequest
    {
        
        public GetAllManagedElementNamesWrtOsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OSNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "osName");
        private static final javax.xml.namespace.QName MDNAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "mdName");
        
        
        /**
         * Gets the "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "osName" element
         */
        public void setOsName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType osName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OSNAME$0);
                }
                target.set(osName);
            }
        }
        
        /**
         * Appends and returns a new empty "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OSNAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MDNAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mdName" element
         */
        public void setMdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType mdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MDNAME$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MDNAME$2);
                }
                target.set(mdName);
            }
        }
        
        /**
         * Appends and returns a new empty "mdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MDNAME$2);
                return target;
            }
        }
    }
}
