/*
 * An XML document type.
 * Localname: getIntendedRouteResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getIntendedRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetIntendedRouteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument
{
    
    public GetIntendedRouteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETINTENDEDROUTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getIntendedRouteResponse");
    
    
    /**
     * Gets the "getIntendedRouteResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse getGetIntendedRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse)get_store().find_element_user(GETINTENDEDROUTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getIntendedRouteResponse" element
     */
    public void setGetIntendedRouteResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse getIntendedRouteResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse)get_store().find_element_user(GETINTENDEDROUTERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse)get_store().add_element_user(GETINTENDEDROUTERESPONSE$0);
            }
            target.set(getIntendedRouteResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getIntendedRouteResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse addNewGetIntendedRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse)get_store().add_element_user(GETINTENDEDROUTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getIntendedRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetIntendedRouteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse
    {
        
        public GetIntendedRouteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ADDITIONALINFO$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "additionalInfo");
        private static final javax.xml.namespace.QName ROUTE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "route");
        
        
        /**
         * Gets the "additionalInfo" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType getAdditionalInfo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(ADDITIONALINFO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "additionalInfo" element
         */
        public void setAdditionalInfo(org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType additionalInfo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(ADDITIONALINFO$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(ADDITIONALINFO$0);
                }
                target.set(additionalInfo);
            }
        }
        
        /**
         * Appends and returns a new empty "additionalInfo" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType addNewAdditionalInfo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(ADDITIONALINFO$0);
                return target;
            }
        }
        
        /**
         * Gets the "route" element
         */
        public org.tmforum.mtop.nrf.xsd.route.v1.RouteType getRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "route" element
         */
        public boolean isSetRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROUTE$2) != 0;
            }
        }
        
        /**
         * Sets the "route" element
         */
        public void setRoute(org.tmforum.mtop.nrf.xsd.route.v1.RouteType route)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$2);
                }
                target.set(route);
            }
        }
        
        /**
         * Appends and returns a new empty "route" element
         */
        public org.tmforum.mtop.nrf.xsd.route.v1.RouteType addNewRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$2);
                return target;
            }
        }
        
        /**
         * Unsets the "route" element
         */
        public void unsetRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROUTE$2, 0);
            }
        }
    }
}
