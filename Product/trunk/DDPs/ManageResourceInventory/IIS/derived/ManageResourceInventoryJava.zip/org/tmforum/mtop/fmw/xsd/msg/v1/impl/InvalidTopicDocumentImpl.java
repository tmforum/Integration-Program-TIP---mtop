/*
 * An XML document type.
 * Localname: invalidTopic
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.InvalidTopicDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * A document containing one invalidTopic(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1) element.
 *
 * This is a complex type.
 */
public class InvalidTopicDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.InvalidTopicDocument
{
    
    public InvalidTopicDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INVALIDTOPIC$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "invalidTopic");
    
    
    /**
     * Gets the "invalidTopic" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInvalidTopic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDTOPIC$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "invalidTopic" element
     */
    public void setInvalidTopic(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType invalidTopic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(INVALIDTOPIC$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDTOPIC$0);
            }
            target.set(invalidTopic);
        }
    }
    
    /**
     * Appends and returns a new empty "invalidTopic" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInvalidTopic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(INVALIDTOPIC$0);
            return target;
        }
    }
}
