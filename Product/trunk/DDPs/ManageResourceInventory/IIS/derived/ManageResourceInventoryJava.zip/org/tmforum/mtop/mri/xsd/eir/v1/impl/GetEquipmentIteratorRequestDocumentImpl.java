/*
 * An XML document type.
 * Localname: getEquipmentIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getEquipmentIteratorRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetEquipmentIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorRequestDocument
{
    
    public GetEquipmentIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETEQUIPMENTITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getEquipmentIteratorRequest");
    
    
    /**
     * Gets the "getEquipmentIteratorRequest" element
     */
    public org.apache.xmlbeans.XmlObject getGetEquipmentIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(GETEQUIPMENTITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getEquipmentIteratorRequest" element
     */
    public void setGetEquipmentIteratorRequest(org.apache.xmlbeans.XmlObject getEquipmentIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(GETEQUIPMENTITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(GETEQUIPMENTITERATORREQUEST$0);
            }
            target.set(getEquipmentIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getEquipmentIteratorRequest" element
     */
    public org.apache.xmlbeans.XmlObject addNewGetEquipmentIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(GETEQUIPMENTITERATORREQUEST$0);
            return target;
        }
    }
}
