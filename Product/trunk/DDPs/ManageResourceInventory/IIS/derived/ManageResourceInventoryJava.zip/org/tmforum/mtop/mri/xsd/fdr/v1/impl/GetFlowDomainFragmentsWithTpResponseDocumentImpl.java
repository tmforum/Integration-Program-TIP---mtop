/*
 * An XML document type.
 * Localname: getFlowDomainFragmentsWithTpResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentsWithTpResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentsWithTpResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument
{
    
    public GetFlowDomainFragmentsWithTpResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTSWITHTPRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentsWithTpResponse");
    
    
    /**
     * Gets the "getFlowDomainFragmentsWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse getGetFlowDomainFragmentsWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentsWithTpResponse" element
     */
    public void setGetFlowDomainFragmentsWithTpResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse getFlowDomainFragmentsWithTpResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSWITHTPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSWITHTPRESPONSE$0);
            }
            target.set(getFlowDomainFragmentsWithTpResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentsWithTpResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse addNewGetFlowDomainFragmentsWithTpResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSWITHTPRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentsWithTpResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentsWithTpResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsWithTpResponseDocument.GetFlowDomainFragmentsWithTpResponse
    {
        
        public GetFlowDomainFragmentsWithTpResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrList");
        
        
        /**
         * Gets the "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType getFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fdfrList" element
         */
        public boolean isSetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDFRLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "fdfrList" element
         */
        public void setFdfrList(org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType fdfrList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().add_element_user(FDFRLIST$0);
                }
                target.set(fdfrList);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType addNewFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentListType)get_store().add_element_user(FDFRLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fdfrList" element
         */
        public void unsetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDFRLIST$0, 0);
            }
        }
    }
}
