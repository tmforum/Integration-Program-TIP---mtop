/*
 * An XML document type.
 * Localname: getAllManagementDomainsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getAllManagementDomainsRequest(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagementDomainsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsRequestDocument
{
    
    public GetAllManagementDomainsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEMENTDOMAINSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getAllManagementDomainsRequest");
    
    
    /**
     * Gets the "getAllManagementDomainsRequest" element
     */
    public org.apache.xmlbeans.XmlObject getGetAllManagementDomainsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(GETALLMANAGEMENTDOMAINSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagementDomainsRequest" element
     */
    public void setGetAllManagementDomainsRequest(org.apache.xmlbeans.XmlObject getAllManagementDomainsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(GETALLMANAGEMENTDOMAINSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(GETALLMANAGEMENTDOMAINSREQUEST$0);
            }
            target.set(getAllManagementDomainsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagementDomainsRequest" element
     */
    public org.apache.xmlbeans.XmlObject addNewGetAllManagementDomainsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(GETALLMANAGEMENTDOMAINSREQUEST$0);
            return target;
        }
    }
}
