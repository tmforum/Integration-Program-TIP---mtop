/*
 * XML Type:  AliasNameListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1.impl;
/**
 * An XML AliasNameListType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is a complex type.
 */
public class AliasNameListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType
{
    
    public AliasNameListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALIAS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/gen/v1", "alias");
    
    
    /**
     * Gets a List of "alias" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias> getAliasList()
    {
        final class AliasList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias>
        {
            public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias get(int i)
                { return AliasNameListTypeImpl.this.getAliasArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias set(int i, org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias o)
            {
                org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias old = AliasNameListTypeImpl.this.getAliasArray(i);
                AliasNameListTypeImpl.this.setAliasArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias o)
                { AliasNameListTypeImpl.this.insertNewAlias(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias old = AliasNameListTypeImpl.this.getAliasArray(i);
                AliasNameListTypeImpl.this.removeAlias(i);
                return old;
            }
            
            public int size()
                { return AliasNameListTypeImpl.this.sizeOfAliasArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new AliasList();
        }
    }
    
    /**
     * Gets array of all "alias" elements
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias[] getAliasArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ALIAS$0, targetList);
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias[] result = new org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "alias" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias getAliasArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias)get_store().find_element_user(ALIAS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "alias" element
     */
    public int sizeOfAliasArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALIAS$0);
        }
    }
    
    /**
     * Sets array of all "alias" element
     */
    public void setAliasArray(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias[] aliasArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(aliasArray, ALIAS$0);
        }
    }
    
    /**
     * Sets ith "alias" element
     */
    public void setAliasArray(int i, org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias alias)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias)get_store().find_element_user(ALIAS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(alias);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "alias" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias insertNewAlias(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias)get_store().insert_element_user(ALIAS$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "alias" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias addNewAlias()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias)get_store().add_element_user(ALIAS$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "alias" element
     */
    public void removeAlias(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALIAS$0, i);
        }
    }
    /**
     * An XML alias(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
     *
     * This is a complex type.
     */
    public static class AliasImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType.Alias
    {
        
        public AliasImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ALIASNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/gen/v1", "aliasName");
        private static final javax.xml.namespace.QName ALIASVALUE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/gen/v1", "aliasValue");
        
        
        /**
         * Gets the "aliasName" element
         */
        public java.lang.String getAliasName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIASNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "aliasName" element
         */
        public org.apache.xmlbeans.XmlString xgetAliasName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALIASNAME$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "aliasName" element
         */
        public void setAliasName(java.lang.String aliasName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIASNAME$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALIASNAME$0);
                }
                target.setStringValue(aliasName);
            }
        }
        
        /**
         * Sets (as xml) the "aliasName" element
         */
        public void xsetAliasName(org.apache.xmlbeans.XmlString aliasName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALIASNAME$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ALIASNAME$0);
                }
                target.set(aliasName);
            }
        }
        
        /**
         * Gets the "aliasValue" element
         */
        public java.lang.String getAliasValue()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIASVALUE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "aliasValue" element
         */
        public org.apache.xmlbeans.XmlString xgetAliasValue()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALIASVALUE$2, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "aliasValue" element
         */
        public boolean isNilAliasValue()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALIASVALUE$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * Sets the "aliasValue" element
         */
        public void setAliasValue(java.lang.String aliasValue)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ALIASVALUE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ALIASVALUE$2);
                }
                target.setStringValue(aliasValue);
            }
        }
        
        /**
         * Sets (as xml) the "aliasValue" element
         */
        public void xsetAliasValue(org.apache.xmlbeans.XmlString aliasValue)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALIASVALUE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ALIASVALUE$2);
                }
                target.set(aliasValue);
            }
        }
        
        /**
         * Nils the "aliasValue" element
         */
        public void setNilAliasValue()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ALIASVALUE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ALIASVALUE$2);
                }
                target.setNil();
            }
        }
    }
}
