/*
 * An XML document type.
 * Localname: getAllSupportingEquipmentNamesException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllSupportingEquipmentNamesException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportingEquipmentNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument
{
    
    public GetAllSupportingEquipmentNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTINGEQUIPMENTNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllSupportingEquipmentNamesException");
    
    
    /**
     * Gets the "getAllSupportingEquipmentNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException getGetAllSupportingEquipmentNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportingEquipmentNamesException" element
     */
    public void setGetAllSupportingEquipmentNamesException(org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException getAllSupportingEquipmentNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException)get_store().find_element_user(GETALLSUPPORTINGEQUIPMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTNAMESEXCEPTION$0);
            }
            target.set(getAllSupportingEquipmentNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportingEquipmentNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException addNewGetAllSupportingEquipmentNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException)get_store().add_element_user(GETALLSUPPORTINGEQUIPMENTNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllSupportingEquipmentNamesException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSupportingEquipmentNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllSupportingEquipmentNamesExceptionDocument.GetAllSupportingEquipmentNamesException
    {
        
        public GetAllSupportingEquipmentNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
