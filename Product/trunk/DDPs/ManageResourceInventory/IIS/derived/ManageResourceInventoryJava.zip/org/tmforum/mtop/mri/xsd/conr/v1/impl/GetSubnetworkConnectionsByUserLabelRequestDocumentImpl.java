/*
 * An XML document type.
 * Localname: getSubnetworkConnectionsByUserLabelRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionsByUserLabelRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionsByUserLabelRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument
{
    
    public GetSubnetworkConnectionsByUserLabelRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONSBYUSERLABELREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionsByUserLabelRequest");
    
    
    /**
     * Gets the "getSubnetworkConnectionsByUserLabelRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest getGetSubnetworkConnectionsByUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest)get_store().find_element_user(GETSUBNETWORKCONNECTIONSBYUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionsByUserLabelRequest" element
     */
    public void setGetSubnetworkConnectionsByUserLabelRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest getSubnetworkConnectionsByUserLabelRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest)get_store().find_element_user(GETSUBNETWORKCONNECTIONSBYUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest)get_store().add_element_user(GETSUBNETWORKCONNECTIONSBYUSERLABELREQUEST$0);
            }
            target.set(getSubnetworkConnectionsByUserLabelRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionsByUserLabelRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest addNewGetSubnetworkConnectionsByUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest)get_store().add_element_user(GETSUBNETWORKCONNECTIONSBYUSERLABELREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getSubnetworkConnectionsByUserLabelRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetSubnetworkConnectionsByUserLabelRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsByUserLabelRequestDocument.GetSubnetworkConnectionsByUserLabelRequest
    {
        
        public GetSubnetworkConnectionsByUserLabelRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName USERLABEL$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "userLabel");
        
        
        /**
         * Gets the "userLabel" element
         */
        public java.lang.String getUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "userLabel" element
         */
        public org.apache.xmlbeans.XmlString xgetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERLABEL$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "userLabel" element
         */
        public void setUserLabel(java.lang.String userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERLABEL$0);
                }
                target.setStringValue(userLabel);
            }
        }
        
        /**
         * Sets (as xml) the "userLabel" element
         */
        public void xsetUserLabel(org.apache.xmlbeans.XmlString userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERLABEL$0);
                }
                target.set(userLabel);
            }
        }
    }
}
