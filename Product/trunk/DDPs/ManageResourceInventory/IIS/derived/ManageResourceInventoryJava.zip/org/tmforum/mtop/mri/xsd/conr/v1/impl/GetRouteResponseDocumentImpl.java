/*
 * An XML document type.
 * Localname: getRouteResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetRouteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument
{
    
    public GetRouteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETROUTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getRouteResponse");
    
    
    /**
     * Gets the "getRouteResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse getGetRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse)get_store().find_element_user(GETROUTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getRouteResponse" element
     */
    public void setGetRouteResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse getRouteResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse)get_store().find_element_user(GETROUTERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse)get_store().add_element_user(GETROUTERESPONSE$0);
            }
            target.set(getRouteResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getRouteResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse addNewGetRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse)get_store().add_element_user(GETROUTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetRouteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetRouteResponseDocument.GetRouteResponse
    {
        
        public GetRouteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROUTE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "route");
        
        
        /**
         * Gets the "route" element
         */
        public org.tmforum.mtop.nrf.xsd.route.v1.RouteType getRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "route" element
         */
        public boolean isSetRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROUTE$0) != 0;
            }
        }
        
        /**
         * Sets the "route" element
         */
        public void setRoute(org.tmforum.mtop.nrf.xsd.route.v1.RouteType route)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().find_element_user(ROUTE$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$0);
                }
                target.set(route);
            }
        }
        
        /**
         * Appends and returns a new empty "route" element
         */
        public org.tmforum.mtop.nrf.xsd.route.v1.RouteType addNewRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteType)get_store().add_element_user(ROUTE$0);
                return target;
            }
        }
        
        /**
         * Unsets the "route" element
         */
        public void unsetRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROUTE$0, 0);
            }
        }
    }
}
