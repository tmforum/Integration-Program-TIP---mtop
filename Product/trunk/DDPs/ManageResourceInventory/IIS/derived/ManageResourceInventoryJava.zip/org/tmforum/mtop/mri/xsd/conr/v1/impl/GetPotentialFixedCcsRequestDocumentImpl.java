/*
 * An XML document type.
 * Localname: getPotentialFixedCcsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getPotentialFixedCcsRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetPotentialFixedCcsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument
{
    
    public GetPotentialFixedCcsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPOTENTIALFIXEDCCSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getPotentialFixedCcsRequest");
    
    
    /**
     * Gets the "getPotentialFixedCcsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest getGetPotentialFixedCcsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest)get_store().find_element_user(GETPOTENTIALFIXEDCCSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPotentialFixedCcsRequest" element
     */
    public void setGetPotentialFixedCcsRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest getPotentialFixedCcsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest)get_store().find_element_user(GETPOTENTIALFIXEDCCSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest)get_store().add_element_user(GETPOTENTIALFIXEDCCSREQUEST$0);
            }
            target.set(getPotentialFixedCcsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getPotentialFixedCcsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest addNewGetPotentialFixedCcsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest)get_store().add_element_user(GETPOTENTIALFIXEDCCSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getPotentialFixedCcsRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetPotentialFixedCcsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsRequestDocument.GetPotentialFixedCcsRequest
    {
        
        public GetPotentialFixedCcsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INPUTTP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "inputTP");
        
        
        /**
         * Gets the "inputTP" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getInputTP()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INPUTTP$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "inputTP" element
         */
        public void setInputTP(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType inputTP)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(INPUTTP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INPUTTP$0);
                }
                target.set(inputTP);
            }
        }
        
        /**
         * Appends and returns a new empty "inputTP" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewInputTP()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(INPUTTP$0);
                return target;
            }
        }
    }
}
