/*
 * An XML document type.
 * Localname: getAllFixedSubnetworkConnectionNamesRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedSubnetworkConnectionNamesRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedSubnetworkConnectionNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionNamesRequestDocument
{
    
    public GetAllFixedSubnetworkConnectionNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDSUBNETWORKCONNECTIONNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedSubnetworkConnectionNamesRequest");
    
    
    /**
     * Gets the "getAllFixedSubnetworkConnectionNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType getGetAllFixedSubnetworkConnectionNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedSubnetworkConnectionNamesRequest" element
     */
    public void setGetAllFixedSubnetworkConnectionNamesRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType getAllFixedSubnetworkConnectionNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESREQUEST$0);
            }
            target.set(getAllFixedSubnetworkConnectionNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedSubnetworkConnectionNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType addNewGetAllFixedSubnetworkConnectionNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsRequestType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESREQUEST$0);
            return target;
        }
    }
}
