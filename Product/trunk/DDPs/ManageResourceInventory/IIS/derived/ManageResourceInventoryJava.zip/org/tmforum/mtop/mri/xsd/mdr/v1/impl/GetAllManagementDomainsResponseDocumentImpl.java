/*
 * An XML document type.
 * Localname: getAllManagementDomainsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getAllManagementDomainsResponse(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagementDomainsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainsResponseDocument
{
    
    public GetAllManagementDomainsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEMENTDOMAINSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getAllManagementDomainsResponse");
    
    
    /**
     * Gets the "getAllManagementDomainsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType getGetAllManagementDomainsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType)get_store().find_element_user(GETALLMANAGEMENTDOMAINSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagementDomainsResponse" element
     */
    public void setGetAllManagementDomainsResponse(org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType getAllManagementDomainsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType)get_store().find_element_user(GETALLMANAGEMENTDOMAINSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType)get_store().add_element_user(GETALLMANAGEMENTDOMAINSRESPONSE$0);
            }
            target.set(getAllManagementDomainsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagementDomainsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType addNewGetAllManagementDomainsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType)get_store().add_element_user(GETALLMANAGEMENTDOMAINSRESPONSE$0);
            return target;
        }
    }
}
