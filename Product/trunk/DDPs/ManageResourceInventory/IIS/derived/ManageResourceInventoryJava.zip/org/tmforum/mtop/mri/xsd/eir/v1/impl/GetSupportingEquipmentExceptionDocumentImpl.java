/*
 * An XML document type.
 * Localname: getSupportingEquipmentException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportingEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportingEquipmentExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument
{
    
    public GetSupportingEquipmentExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTINGEQUIPMENTEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportingEquipmentException");
    
    
    /**
     * Gets the "getSupportingEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException getGetSupportingEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException)get_store().find_element_user(GETSUPPORTINGEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportingEquipmentException" element
     */
    public void setGetSupportingEquipmentException(org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException getSupportingEquipmentException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException)get_store().find_element_user(GETSUPPORTINGEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException)get_store().add_element_user(GETSUPPORTINGEQUIPMENTEXCEPTION$0);
            }
            target.set(getSupportingEquipmentException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportingEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException addNewGetSupportingEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException)get_store().add_element_user(GETSUPPORTINGEQUIPMENTEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getSupportingEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetSupportingEquipmentExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentExceptionDocument.GetSupportingEquipmentException
    {
        
        public GetSupportingEquipmentExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
