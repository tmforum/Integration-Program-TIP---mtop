/*
 * An XML document type.
 * Localname: getContainedEquipmentException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getContainedEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetContainedEquipmentExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument
{
    
    public GetContainedEquipmentExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETCONTAINEDEQUIPMENTEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getContainedEquipmentException");
    
    
    /**
     * Gets the "getContainedEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException getGetContainedEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException)get_store().find_element_user(GETCONTAINEDEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getContainedEquipmentException" element
     */
    public void setGetContainedEquipmentException(org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException getContainedEquipmentException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException)get_store().find_element_user(GETCONTAINEDEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException)get_store().add_element_user(GETCONTAINEDEQUIPMENTEXCEPTION$0);
            }
            target.set(getContainedEquipmentException);
        }
    }
    
    /**
     * Appends and returns a new empty "getContainedEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException addNewGetContainedEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException)get_store().add_element_user(GETCONTAINEDEQUIPMENTEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getContainedEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetContainedEquipmentExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentExceptionDocument.GetContainedEquipmentException
    {
        
        public GetContainedEquipmentExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
