/*
 * An XML document type.
 * Localname: getAllManagementDomainNamesRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getAllManagementDomainNamesRequest(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagementDomainNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetAllManagementDomainNamesRequestDocument
{
    
    public GetAllManagementDomainNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEMENTDOMAINNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getAllManagementDomainNamesRequest");
    
    
    /**
     * Gets the "getAllManagementDomainNamesRequest" element
     */
    public org.apache.xmlbeans.XmlObject getGetAllManagementDomainNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(GETALLMANAGEMENTDOMAINNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagementDomainNamesRequest" element
     */
    public void setGetAllManagementDomainNamesRequest(org.apache.xmlbeans.XmlObject getAllManagementDomainNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(GETALLMANAGEMENTDOMAINNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(GETALLMANAGEMENTDOMAINNAMESREQUEST$0);
            }
            target.set(getAllManagementDomainNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagementDomainNamesRequest" element
     */
    public org.apache.xmlbeans.XmlObject addNewGetAllManagementDomainNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(GETALLMANAGEMENTDOMAINNAMESREQUEST$0);
            return target;
        }
    }
}
