/*
 * An XML document type.
 * Localname: getSupportedEquipmentException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportedEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportedEquipmentExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument
{
    
    public GetSupportedEquipmentExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTEDEQUIPMENTEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportedEquipmentException");
    
    
    /**
     * Gets the "getSupportedEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException getGetSupportedEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException)get_store().find_element_user(GETSUPPORTEDEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportedEquipmentException" element
     */
    public void setGetSupportedEquipmentException(org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException getSupportedEquipmentException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException)get_store().find_element_user(GETSUPPORTEDEQUIPMENTEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException)get_store().add_element_user(GETSUPPORTEDEQUIPMENTEXCEPTION$0);
            }
            target.set(getSupportedEquipmentException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportedEquipmentException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException addNewGetSupportedEquipmentException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException)get_store().add_element_user(GETSUPPORTEDEQUIPMENTEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getSupportedEquipmentException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetSupportedEquipmentExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportedEquipmentExceptionDocument.GetSupportedEquipmentException
    {
        
        public GetSupportedEquipmentExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
