/*
 * An XML document type.
 * Localname: getAssociatingFdException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssociatingFdException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssociatingFdExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument
{
    
    public GetAssociatingFdExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSOCIATINGFDEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssociatingFdException");
    
    
    /**
     * Gets the "getAssociatingFdException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException getGetAssociatingFdException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException)get_store().find_element_user(GETASSOCIATINGFDEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssociatingFdException" element
     */
    public void setGetAssociatingFdException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException getAssociatingFdException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException)get_store().find_element_user(GETASSOCIATINGFDEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException)get_store().add_element_user(GETASSOCIATINGFDEXCEPTION$0);
            }
            target.set(getAssociatingFdException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssociatingFdException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException addNewGetAssociatingFdException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException)get_store().add_element_user(GETASSOCIATINGFDEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAssociatingFdException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssociatingFdExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdExceptionDocument.GetAssociatingFdException
    {
        
        public GetAssociatingFdExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
