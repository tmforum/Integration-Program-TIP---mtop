/*
 * An XML document type.
 * Localname: getPotentialFixedCcsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getPotentialFixedCcsResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetPotentialFixedCcsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument
{
    
    public GetPotentialFixedCcsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPOTENTIALFIXEDCCSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getPotentialFixedCcsResponse");
    
    
    /**
     * Gets the "getPotentialFixedCcsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse getGetPotentialFixedCcsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse)get_store().find_element_user(GETPOTENTIALFIXEDCCSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPotentialFixedCcsResponse" element
     */
    public void setGetPotentialFixedCcsResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse getPotentialFixedCcsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse)get_store().find_element_user(GETPOTENTIALFIXEDCCSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse)get_store().add_element_user(GETPOTENTIALFIXEDCCSRESPONSE$0);
            }
            target.set(getPotentialFixedCcsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getPotentialFixedCcsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse addNewGetPotentialFixedCcsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse)get_store().add_element_user(GETPOTENTIALFIXEDCCSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getPotentialFixedCcsResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetPotentialFixedCcsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsResponseDocument.GetPotentialFixedCcsResponse
    {
        
        public GetPotentialFixedCcsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CONTAININGTP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "containingTP");
        private static final javax.xml.namespace.QName PORTENTIALCCLIST$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "portentialCCList");
        
        
        /**
         * Gets the "containingTP" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getContainingTP()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(CONTAININGTP$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "containingTP" element
         */
        public boolean isSetContainingTP()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CONTAININGTP$0) != 0;
            }
        }
        
        /**
         * Sets the "containingTP" element
         */
        public void setContainingTP(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType containingTP)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(CONTAININGTP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(CONTAININGTP$0);
                }
                target.set(containingTP);
            }
        }
        
        /**
         * Appends and returns a new empty "containingTP" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewContainingTP()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(CONTAININGTP$0);
                return target;
            }
        }
        
        /**
         * Unsets the "containingTP" element
         */
        public void unsetContainingTP()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CONTAININGTP$0, 0);
            }
        }
        
        /**
         * Gets the "portentialCCList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getPortentialCCList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PORTENTIALCCLIST$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "portentialCCList" element
         */
        public boolean isSetPortentialCCList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PORTENTIALCCLIST$2) != 0;
            }
        }
        
        /**
         * Sets the "portentialCCList" element
         */
        public void setPortentialCCList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType portentialCCList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PORTENTIALCCLIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PORTENTIALCCLIST$2);
                }
                target.set(portentialCCList);
            }
        }
        
        /**
         * Appends and returns a new empty "portentialCCList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewPortentialCCList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PORTENTIALCCLIST$2);
                return target;
            }
        }
        
        /**
         * Unsets the "portentialCCList" element
         */
        public void unsetPortentialCCList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PORTENTIALCCLIST$2, 0);
            }
        }
    }
}
