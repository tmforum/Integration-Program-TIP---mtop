/*
 * An XML document type.
 * Localname: getFlowDomainFragmentRouteRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentRouteRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentRouteRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument
{
    
    public GetFlowDomainFragmentRouteRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTROUTEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentRouteRequest");
    
    
    /**
     * Gets the "getFlowDomainFragmentRouteRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest getGetFlowDomainFragmentRouteRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest)get_store().find_element_user(GETFLOWDOMAINFRAGMENTROUTEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentRouteRequest" element
     */
    public void setGetFlowDomainFragmentRouteRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest getFlowDomainFragmentRouteRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest)get_store().find_element_user(GETFLOWDOMAINFRAGMENTROUTEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest)get_store().add_element_user(GETFLOWDOMAINFRAGMENTROUTEREQUEST$0);
            }
            target.set(getFlowDomainFragmentRouteRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentRouteRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest addNewGetFlowDomainFragmentRouteRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest)get_store().add_element_user(GETFLOWDOMAINFRAGMENTROUTEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentRouteRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentRouteRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentRouteRequestDocument.GetFlowDomainFragmentRouteRequest
    {
        
        public GetFlowDomainFragmentRouteRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrName");
        
        
        /**
         * Gets the "fdfrName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getFdfrName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(FDFRNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "fdfrName" element
         */
        public void setFdfrName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType fdfrName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(FDFRNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(FDFRNAME$0);
                }
                target.set(fdfrName);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewFdfrName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(FDFRNAME$0);
                return target;
            }
        }
    }
}
