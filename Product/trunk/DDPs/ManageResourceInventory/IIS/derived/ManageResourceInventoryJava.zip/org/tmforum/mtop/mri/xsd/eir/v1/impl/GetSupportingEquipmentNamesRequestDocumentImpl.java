/*
 * An XML document type.
 * Localname: getSupportingEquipmentNamesRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportingEquipmentNamesRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportingEquipmentNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesRequestDocument
{
    
    public GetSupportingEquipmentNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTINGEQUIPMENTNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportingEquipmentNamesRequest");
    
    
    /**
     * Gets the "getSupportingEquipmentNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType getGetSupportingEquipmentNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().find_element_user(GETSUPPORTINGEQUIPMENTNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportingEquipmentNamesRequest" element
     */
    public void setGetSupportingEquipmentNamesRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType getSupportingEquipmentNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().find_element_user(GETSUPPORTINGEQUIPMENTNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().add_element_user(GETSUPPORTINGEQUIPMENTNAMESREQUEST$0);
            }
            target.set(getSupportingEquipmentNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportingEquipmentNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType addNewGetSupportingEquipmentNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportEquipmentRequestType)get_store().add_element_user(GETSUPPORTINGEQUIPMENTNAMESREQUEST$0);
            return target;
        }
    }
}
