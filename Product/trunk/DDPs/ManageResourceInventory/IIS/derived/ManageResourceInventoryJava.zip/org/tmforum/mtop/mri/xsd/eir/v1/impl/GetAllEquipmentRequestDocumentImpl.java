/*
 * An XML document type.
 * Localname: getAllEquipmentRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllEquipmentRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllEquipmentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestDocument
{
    
    public GetAllEquipmentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLEQUIPMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllEquipmentRequest");
    
    
    /**
     * Gets the "getAllEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType getGetAllEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType)get_store().find_element_user(GETALLEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllEquipmentRequest" element
     */
    public void setGetAllEquipmentRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType getAllEquipmentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType)get_store().find_element_user(GETALLEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType)get_store().add_element_user(GETALLEQUIPMENTREQUEST$0);
            }
            target.set(getAllEquipmentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType addNewGetAllEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType)get_store().add_element_user(GETALLEQUIPMENTREQUEST$0);
            return target;
        }
    }
}
