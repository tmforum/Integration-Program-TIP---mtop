/*
 * XML Type:  ProductNameType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1.impl;
/**
 * An XML ProductNameType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType.
 */
public class ProductNameTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.fmw.xsd.gen.v1.ProductNameType
{
    
    public ProductNameTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ProductNameTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
