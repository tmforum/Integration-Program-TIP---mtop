/*
 * An XML document type.
 * Localname: getAllEquipmentNamesRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getAllEquipmentNamesRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetAllEquipmentNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentNamesRequestDocument
{
    
    public GetAllEquipmentNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLEQUIPMENTNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getAllEquipmentNamesRequest");
    
    
    /**
     * Gets the "getAllEquipmentNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType getGetAllEquipmentNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType)get_store().find_element_user(GETALLEQUIPMENTNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllEquipmentNamesRequest" element
     */
    public void setGetAllEquipmentNamesRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType getAllEquipmentNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType)get_store().find_element_user(GETALLEQUIPMENTNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType)get_store().add_element_user(GETALLEQUIPMENTNAMESREQUEST$0);
            }
            target.set(getAllEquipmentNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllEquipmentNamesRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType addNewGetAllEquipmentNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType)get_store().add_element_user(GETALLEQUIPMENTNAMESREQUEST$0);
            return target;
        }
    }
}
