/*
 * An XML document type.
 * Localname: getFlowDomainFragmentsByUserLabelException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentsByUserLabelExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument
{
    
    public GetFlowDomainFragmentsByUserLabelExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTSBYUSERLABELEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentsByUserLabelException");
    
    
    /**
     * Gets the "getFlowDomainFragmentsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException getGetFlowDomainFragmentsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentsByUserLabelException" element
     */
    public void setGetFlowDomainFragmentsByUserLabelException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException getFlowDomainFragmentsByUserLabelException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELEXCEPTION$0);
            }
            target.set(getFlowDomainFragmentsByUserLabelException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException addNewGetFlowDomainFragmentsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentsByUserLabelExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelExceptionDocument.GetFlowDomainFragmentsByUserLabelException
    {
        
        public GetFlowDomainFragmentsByUserLabelExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
