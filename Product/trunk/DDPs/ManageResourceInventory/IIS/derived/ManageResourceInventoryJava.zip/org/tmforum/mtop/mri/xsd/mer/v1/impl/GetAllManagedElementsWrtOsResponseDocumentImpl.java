/*
 * An XML document type.
 * Localname: getAllManagedElementsWrtOsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsWrtOsResponse(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsWrtOsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsResponseDocument
{
    
    public GetAllManagedElementsWrtOsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSWRTOSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsWrtOsResponse");
    
    
    /**
     * Gets the "getAllManagedElementsWrtOsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType getGetAllManagedElementsWrtOsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTOSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsWrtOsResponse" element
     */
    public void setGetAllManagedElementsWrtOsResponse(org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType getAllManagedElementsWrtOsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTOSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTOSRESPONSE$0);
            }
            target.set(getAllManagedElementsWrtOsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsWrtOsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType addNewGetAllManagedElementsWrtOsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.MultipleMeObjectsResponseType)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTOSRESPONSE$0);
            return target;
        }
    }
}
