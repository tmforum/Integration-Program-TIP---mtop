/*
 * An XML document type.
 * Localname: getContainedEquipmentRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getContainedEquipmentRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetContainedEquipmentRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument
{
    
    public GetContainedEquipmentRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETCONTAINEDEQUIPMENTREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getContainedEquipmentRequest");
    
    
    /**
     * Gets the "getContainedEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest getGetContainedEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest)get_store().find_element_user(GETCONTAINEDEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getContainedEquipmentRequest" element
     */
    public void setGetContainedEquipmentRequest(org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest getContainedEquipmentRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest)get_store().find_element_user(GETCONTAINEDEQUIPMENTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest)get_store().add_element_user(GETCONTAINEDEQUIPMENTREQUEST$0);
            }
            target.set(getContainedEquipmentRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getContainedEquipmentRequest" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest addNewGetContainedEquipmentRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest)get_store().add_element_user(GETCONTAINEDEQUIPMENTREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getContainedEquipmentRequest(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetContainedEquipmentRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetContainedEquipmentRequestDocument.GetContainedEquipmentRequest
    {
        
        public GetContainedEquipmentRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EQUIPMENTHOLDERNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "equipmentHolderName");
        
        
        /**
         * Gets the "equipmentHolderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getEquipmentHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EQUIPMENTHOLDERNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "equipmentHolderName" element
         */
        public void setEquipmentHolderName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType equipmentHolderName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EQUIPMENTHOLDERNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EQUIPMENTHOLDERNAME$0);
                }
                target.set(equipmentHolderName);
            }
        }
        
        /**
         * Appends and returns a new empty "equipmentHolderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewEquipmentHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EQUIPMENTHOLDERNAME$0);
                return target;
            }
        }
    }
}
