/*
 * An XML document type.
 * Localname: getAllManagedElementsWrtOsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mer/v1
 * Java type: org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mer.v1.impl;
/**
 * A document containing one getAllManagedElementsWrtOsException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1) element.
 *
 * This is a complex type.
 */
public class GetAllManagedElementsWrtOsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument
{
    
    public GetAllManagedElementsWrtOsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLMANAGEDELEMENTSWRTOSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mer/v1", "getAllManagedElementsWrtOsException");
    
    
    /**
     * Gets the "getAllManagedElementsWrtOsException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException getGetAllManagedElementsWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllManagedElementsWrtOsException" element
     */
    public void setGetAllManagedElementsWrtOsException(org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException getAllManagedElementsWrtOsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException)get_store().find_element_user(GETALLMANAGEDELEMENTSWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTOSEXCEPTION$0);
            }
            target.set(getAllManagedElementsWrtOsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllManagedElementsWrtOsException" element
     */
    public org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException addNewGetAllManagedElementsWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException target = null;
            target = (org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException)get_store().add_element_user(GETALLMANAGEDELEMENTSWRTOSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllManagedElementsWrtOsException(@http://www.tmforum.org/mtop/mri/xsd/mer/v1).
     *
     * This is a complex type.
     */
    public static class GetAllManagedElementsWrtOsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mer.v1.GetAllManagedElementsWrtOsExceptionDocument.GetAllManagedElementsWrtOsException
    {
        
        public GetAllManagedElementsWrtOsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
