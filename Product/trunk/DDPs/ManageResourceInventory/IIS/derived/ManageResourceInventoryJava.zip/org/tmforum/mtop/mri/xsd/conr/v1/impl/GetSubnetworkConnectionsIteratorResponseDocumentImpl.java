/*
 * An XML document type.
 * Localname: getSubnetworkConnectionsIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionsIteratorResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionsIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsIteratorResponseDocument
{
    
    public GetSubnetworkConnectionsIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONSITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionsIteratorResponse");
    
    
    /**
     * Gets the "getSubnetworkConnectionsIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType getGetSubnetworkConnectionsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().find_element_user(GETSUBNETWORKCONNECTIONSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionsIteratorResponse" element
     */
    public void setGetSubnetworkConnectionsIteratorResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType getSubnetworkConnectionsIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().find_element_user(GETSUBNETWORKCONNECTIONSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().add_element_user(GETSUBNETWORKCONNECTIONSITERATORRESPONSE$0);
            }
            target.set(getSubnetworkConnectionsIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionsIteratorResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType addNewGetSubnetworkConnectionsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSubnetworkConnectionObjectsResponseType)get_store().add_element_user(GETSUBNETWORKCONNECTIONSITERATORRESPONSE$0);
            return target;
        }
    }
}
