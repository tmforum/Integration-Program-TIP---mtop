/*
 * XML Type:  GetAllEquipmentWithPtpRequestType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * An XML GetAllEquipmentWithPtpRequestType(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
 *
 * This is a complex type.
 */
public class GetAllEquipmentWithPtpRequestTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentWithPtpRequestType
{
    
    public GetAllEquipmentWithPtpRequestTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PTPNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "ptpName");
    
    
    /**
     * Gets the "ptpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getPtpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PTPNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ptpName" element
     */
    public void setPtpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType ptpName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PTPNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PTPNAME$0);
            }
            target.set(ptpName);
        }
    }
    
    /**
     * Appends and returns a new empty "ptpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewPtpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PTPNAME$0);
            return target;
        }
    }
}
