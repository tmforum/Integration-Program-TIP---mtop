/*
 * An XML document type.
 * Localname: getAllFlowDomainsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllFlowDomainsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFlowDomainsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument
{
    
    public GetAllFlowDomainsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFLOWDOMAINSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllFlowDomainsException");
    
    
    /**
     * Gets the "getAllFlowDomainsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException getGetAllFlowDomainsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException)get_store().find_element_user(GETALLFLOWDOMAINSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFlowDomainsException" element
     */
    public void setGetAllFlowDomainsException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException getAllFlowDomainsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException)get_store().find_element_user(GETALLFLOWDOMAINSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException)get_store().add_element_user(GETALLFLOWDOMAINSEXCEPTION$0);
            }
            target.set(getAllFlowDomainsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFlowDomainsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException addNewGetAllFlowDomainsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException)get_store().add_element_user(GETALLFLOWDOMAINSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllFlowDomainsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFlowDomainsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsExceptionDocument.GetAllFlowDomainsException
    {
        
        public GetAllFlowDomainsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
