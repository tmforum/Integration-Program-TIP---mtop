/*
 * An XML document type.
 * Localname: getSncsByUserLabelRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSncsByUserLabelRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSncsByUserLabelRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument
{
    
    public GetSncsByUserLabelRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSNCSBYUSERLABELREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSncsByUserLabelRequest");
    
    
    /**
     * Gets the "getSncsByUserLabelRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest getGetSncsByUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest)get_store().find_element_user(GETSNCSBYUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSncsByUserLabelRequest" element
     */
    public void setGetSncsByUserLabelRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest getSncsByUserLabelRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest)get_store().find_element_user(GETSNCSBYUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest)get_store().add_element_user(GETSNCSBYUSERLABELREQUEST$0);
            }
            target.set(getSncsByUserLabelRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getSncsByUserLabelRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest addNewGetSncsByUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest)get_store().add_element_user(GETSNCSBYUSERLABELREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getSncsByUserLabelRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetSncsByUserLabelRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelRequestDocument.GetSncsByUserLabelRequest
    {
        
        public GetSncsByUserLabelRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName USERLABEL$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "userLabel");
        
        
        /**
         * Gets the "userLabel" element
         */
        public java.lang.String getUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "userLabel" element
         */
        public org.apache.xmlbeans.XmlString xgetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERLABEL$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "userLabel" element
         */
        public void setUserLabel(java.lang.String userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERLABEL$0);
                }
                target.setStringValue(userLabel);
            }
        }
        
        /**
         * Sets (as xml) the "userLabel" element
         */
        public void xsetUserLabel(org.apache.xmlbeans.XmlString userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERLABEL$0);
                }
                target.set(userLabel);
            }
        }
    }
}
