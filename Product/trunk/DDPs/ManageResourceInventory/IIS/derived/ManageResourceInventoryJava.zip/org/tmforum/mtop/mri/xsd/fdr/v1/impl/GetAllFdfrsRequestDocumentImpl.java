/*
 * An XML document type.
 * Localname: getAllFdfrsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllFdfrsRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFdfrsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument
{
    
    public GetAllFdfrsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFDFRSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllFdfrsRequest");
    
    
    /**
     * Gets the "getAllFdfrsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest getGetAllFdfrsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest)get_store().find_element_user(GETALLFDFRSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFdfrsRequest" element
     */
    public void setGetAllFdfrsRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest getAllFdfrsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest)get_store().find_element_user(GETALLFDFRSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest)get_store().add_element_user(GETALLFDFRSREQUEST$0);
            }
            target.set(getAllFdfrsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFdfrsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest addNewGetAllFdfrsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest)get_store().add_element_user(GETALLFDFRSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllFdfrsRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFdfrsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsRequestDocument.GetAllFdfrsRequest
    {
        
        public GetAllFdfrsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdName");
        private static final javax.xml.namespace.QName CONNECTIVITYRATELIST$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "connectivityRateList");
        
        
        /**
         * Gets the "fdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getFdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FDNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "fdName" element
         */
        public void setFdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType fdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FDNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FDNAME$0);
                }
                target.set(fdName);
            }
        }
        
        /**
         * Appends and returns a new empty "fdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewFdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FDNAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "connectivityRateList" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getConnectivityRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(CONNECTIVITYRATELIST$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "connectivityRateList" element
         */
        public void setConnectivityRateList(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType connectivityRateList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(CONNECTIVITYRATELIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(CONNECTIVITYRATELIST$2);
                }
                target.set(connectivityRateList);
            }
        }
        
        /**
         * Appends and returns a new empty "connectivityRateList" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewConnectivityRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(CONNECTIVITYRATELIST$2);
                return target;
            }
        }
    }
}
