/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionsWithTpRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionsWithTpRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionsWithTpRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsWithTpRequestDocument
{
    
    public GetAllSubnetworkConnectionsWithTpRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONSWITHTPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionsWithTpRequest");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionsWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType getGetAllSubnetworkConnectionsWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionsWithTpRequest" element
     */
    public void setGetAllSubnetworkConnectionsWithTpRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType getAllSubnetworkConnectionsWithTpRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPREQUEST$0);
            }
            target.set(getAllSubnetworkConnectionsWithTpRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionsWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType addNewGetAllSubnetworkConnectionsWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsWithTpRequestType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSWITHTPREQUEST$0);
            return target;
        }
    }
}
