/*
 * An XML document type.
 * Localname: getFlowDomainFragmentsByUserLabelRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainFragmentsByUserLabelRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainFragmentsByUserLabelRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument
{
    
    public GetFlowDomainFragmentsByUserLabelRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINFRAGMENTSBYUSERLABELREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainFragmentsByUserLabelRequest");
    
    
    /**
     * Gets the "getFlowDomainFragmentsByUserLabelRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest getGetFlowDomainFragmentsByUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainFragmentsByUserLabelRequest" element
     */
    public void setGetFlowDomainFragmentsByUserLabelRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest getFlowDomainFragmentsByUserLabelRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest)get_store().find_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELREQUEST$0);
            }
            target.set(getFlowDomainFragmentsByUserLabelRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainFragmentsByUserLabelRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest addNewGetFlowDomainFragmentsByUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest)get_store().add_element_user(GETFLOWDOMAINFRAGMENTSBYUSERLABELREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainFragmentsByUserLabelRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainFragmentsByUserLabelRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainFragmentsByUserLabelRequestDocument.GetFlowDomainFragmentsByUserLabelRequest
    {
        
        public GetFlowDomainFragmentsByUserLabelRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName USERLABEL$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "userLabel");
        
        
        /**
         * Gets the "userLabel" element
         */
        public java.lang.String getUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "userLabel" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType xgetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "userLabel" element
         */
        public void setUserLabel(java.lang.String userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERLABEL$0);
                }
                target.setStringValue(userLabel);
            }
        }
        
        /**
         * Sets (as xml) the "userLabel" element
         */
        public void xsetUserLabel(org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().add_element_user(USERLABEL$0);
                }
                target.set(userLabel);
            }
        }
    }
}
