/*
 * An XML document type.
 * Localname: getAllAssociatedMfdsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllAssociatedMfdsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAssociatedMfdsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument
{
    
    public GetAllAssociatedMfdsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLASSOCIATEDMFDSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllAssociatedMfdsException");
    
    
    /**
     * Gets the "getAllAssociatedMfdsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException getGetAllAssociatedMfdsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException)get_store().find_element_user(GETALLASSOCIATEDMFDSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAssociatedMfdsException" element
     */
    public void setGetAllAssociatedMfdsException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException getAllAssociatedMfdsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException)get_store().find_element_user(GETALLASSOCIATEDMFDSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException)get_store().add_element_user(GETALLASSOCIATEDMFDSEXCEPTION$0);
            }
            target.set(getAllAssociatedMfdsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAssociatedMfdsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException addNewGetAllAssociatedMfdsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException)get_store().add_element_user(GETALLASSOCIATEDMFDSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllAssociatedMfdsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAssociatedMfdsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsExceptionDocument.GetAllAssociatedMfdsException
    {
        
        public GetAllAssociatedMfdsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
