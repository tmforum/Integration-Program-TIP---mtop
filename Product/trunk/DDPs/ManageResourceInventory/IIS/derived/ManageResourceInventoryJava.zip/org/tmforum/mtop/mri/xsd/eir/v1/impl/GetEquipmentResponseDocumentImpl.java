/*
 * An XML document type.
 * Localname: getEquipmentResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getEquipmentResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetEquipmentResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument
{
    
    public GetEquipmentResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETEQUIPMENTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getEquipmentResponse");
    
    
    /**
     * Gets the "getEquipmentResponse" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse getGetEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse)get_store().find_element_user(GETEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getEquipmentResponse" element
     */
    public void setGetEquipmentResponse(org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse getEquipmentResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse)get_store().find_element_user(GETEQUIPMENTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse)get_store().add_element_user(GETEQUIPMENTRESPONSE$0);
            }
            target.set(getEquipmentResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getEquipmentResponse" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse addNewGetEquipmentResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse)get_store().add_element_user(GETEQUIPMENTRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getEquipmentResponse(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetEquipmentResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentResponseDocument.GetEquipmentResponse
    {
        
        public GetEquipmentResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EQUIP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "equip");
        
        
        /**
         * Gets the "equip" element
         */
        public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType getEquip()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType target = null;
                target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType)get_store().find_element_user(EQUIP$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "equip" element
         */
        public boolean isSetEquip()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EQUIP$0) != 0;
            }
        }
        
        /**
         * Sets the "equip" element
         */
        public void setEquip(org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType equip)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType target = null;
                target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType)get_store().find_element_user(EQUIP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType)get_store().add_element_user(EQUIP$0);
                }
                target.set(equip);
            }
        }
        
        /**
         * Appends and returns a new empty "equip" element
         */
        public org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType addNewEquip()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType target = null;
                target = (org.tmforum.mtop.nrf.xsd.eqInv.v1.EquipmentOrHolderType)get_store().add_element_user(EQUIP$0);
                return target;
            }
        }
        
        /**
         * Unsets the "equip" element
         */
        public void unsetEquip()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EQUIP$0, 0);
            }
        }
    }
}
