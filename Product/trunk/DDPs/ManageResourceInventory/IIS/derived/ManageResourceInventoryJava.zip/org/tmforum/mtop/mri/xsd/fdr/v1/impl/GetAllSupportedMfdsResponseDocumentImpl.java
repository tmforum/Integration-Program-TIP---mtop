/*
 * An XML document type.
 * Localname: getAllSupportedMfdsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllSupportedMfdsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportedMfdsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument
{
    
    public GetAllSupportedMfdsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTEDMFDSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllSupportedMfdsResponse");
    
    
    /**
     * Gets the "getAllSupportedMfdsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse getGetAllSupportedMfdsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse)get_store().find_element_user(GETALLSUPPORTEDMFDSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportedMfdsResponse" element
     */
    public void setGetAllSupportedMfdsResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse getAllSupportedMfdsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse)get_store().find_element_user(GETALLSUPPORTEDMFDSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse)get_store().add_element_user(GETALLSUPPORTEDMFDSRESPONSE$0);
            }
            target.set(getAllSupportedMfdsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportedMfdsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse addNewGetAllSupportedMfdsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse)get_store().add_element_user(GETALLSUPPORTEDMFDSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAllSupportedMfdsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSupportedMfdsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsResponseDocument.GetAllSupportedMfdsResponse
    {
        
        public GetAllSupportedMfdsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFDS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfds");
        
        
        /**
         * Gets the "mfds" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType getMfds()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType)get_store().find_element_user(MFDS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "mfds" element
         */
        public boolean isSetMfds()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFDS$0) != 0;
            }
        }
        
        /**
         * Sets the "mfds" element
         */
        public void setMfds(org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType mfds)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType)get_store().find_element_user(MFDS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType)get_store().add_element_user(MFDS$0);
                }
                target.set(mfds);
            }
        }
        
        /**
         * Appends and returns a new empty "mfds" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType addNewMfds()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType)get_store().add_element_user(MFDS$0);
                return target;
            }
        }
        
        /**
         * Unsets the "mfds" element
         */
        public void unsetMfds()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFDS$0, 0);
            }
        }
    }
}
