/*
 * An XML document type.
 * Localname: getSubnetworkConnectionNamesIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionNamesIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionNamesIteratorRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionNamesIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionNamesIteratorRequestDocument
{
    
    public GetSubnetworkConnectionNamesIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONNAMESITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionNamesIteratorRequest");
    
    
    /**
     * Gets the "getSubnetworkConnectionNamesIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getGetSubnetworkConnectionNamesIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETSUBNETWORKCONNECTIONNAMESITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionNamesIteratorRequest" element
     */
    public void setGetSubnetworkConnectionNamesIteratorRequest(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getSubnetworkConnectionNamesIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETSUBNETWORKCONNECTIONNAMESITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETSUBNETWORKCONNECTIONNAMESITERATORREQUEST$0);
            }
            target.set(getSubnetworkConnectionNamesIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionNamesIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType addNewGetSubnetworkConnectionNamesIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETSUBNETWORKCONNECTIONNAMESITERATORREQUEST$0);
            return target;
        }
    }
}
