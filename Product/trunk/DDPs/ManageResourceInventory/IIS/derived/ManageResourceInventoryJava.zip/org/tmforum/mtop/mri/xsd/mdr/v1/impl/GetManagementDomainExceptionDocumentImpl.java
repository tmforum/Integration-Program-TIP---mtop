/*
 * An XML document type.
 * Localname: getManagementDomainException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * A document containing one getManagementDomainException(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1) element.
 *
 * This is a complex type.
 */
public class GetManagementDomainExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument
{
    
    public GetManagementDomainExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMANAGEMENTDOMAINEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "getManagementDomainException");
    
    
    /**
     * Gets the "getManagementDomainException" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException getGetManagementDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException)get_store().find_element_user(GETMANAGEMENTDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getManagementDomainException" element
     */
    public void setGetManagementDomainException(org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException getManagementDomainException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException)get_store().find_element_user(GETMANAGEMENTDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException)get_store().add_element_user(GETMANAGEMENTDOMAINEXCEPTION$0);
            }
            target.set(getManagementDomainException);
        }
    }
    
    /**
     * Appends and returns a new empty "getManagementDomainException" element
     */
    public org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException addNewGetManagementDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException target = null;
            target = (org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException)get_store().add_element_user(GETMANAGEMENTDOMAINEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getManagementDomainException(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1).
     *
     * This is a complex type.
     */
    public static class GetManagementDomainExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.GetManagementDomainExceptionDocument.GetManagementDomainException
    {
        
        public GetManagementDomainExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
