/*
 * XML Type:  OperationResultType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * An XML OperationResultType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
 *
 * This is a complex type.
 */
public class OperationResultTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType
{
    
    public OperationResultTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OPERATIONLABEL$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "operationLabel");
    private static final javax.xml.namespace.QName RESULT$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "result");
    private static final javax.xml.namespace.QName ERRORREASON$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "errorReason");
    
    
    /**
     * Gets the "operationLabel" element
     */
    public java.lang.String getOperationLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "operationLabel" element
     */
    public org.apache.xmlbeans.XmlString xgetOperationLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERATIONLABEL$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "operationLabel" element
     */
    public boolean isNilOperationLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "operationLabel" element
     */
    public void setOperationLabel(java.lang.String operationLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OPERATIONLABEL$0);
            }
            target.setStringValue(operationLabel);
        }
    }
    
    /**
     * Sets (as xml) the "operationLabel" element
     */
    public void xsetOperationLabel(org.apache.xmlbeans.XmlString operationLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OPERATIONLABEL$0);
            }
            target.set(operationLabel);
        }
    }
    
    /**
     * Nils the "operationLabel" element
     */
    public void setNilOperationLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OPERATIONLABEL$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "result" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.Enum getResult()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESULT$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "result" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.ResultType xgetResult()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.ResultType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().find_element_user(RESULT$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "result" element
     */
    public boolean isNilResult()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.ResultType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().find_element_user(RESULT$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "result" element
     */
    public void setResult(org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.Enum result)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESULT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RESULT$2);
            }
            target.setEnumValue(result);
        }
    }
    
    /**
     * Sets (as xml) the "result" element
     */
    public void xsetResult(org.tmforum.mtop.fmw.xsd.mart.v1.ResultType result)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.ResultType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().find_element_user(RESULT$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().add_element_user(RESULT$2);
            }
            target.set(result);
        }
    }
    
    /**
     * Nils the "result" element
     */
    public void setNilResult()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.ResultType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().find_element_user(RESULT$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().add_element_user(RESULT$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "errorReason" element
     */
    public java.lang.String getErrorReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "errorReason" element
     */
    public org.apache.xmlbeans.XmlString xgetErrorReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "errorReason" element
     */
    public boolean isNilErrorReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "errorReason" element
     */
    public void setErrorReason(java.lang.String errorReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ERRORREASON$4);
            }
            target.setStringValue(errorReason);
        }
    }
    
    /**
     * Sets (as xml) the "errorReason" element
     */
    public void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$4);
            }
            target.set(errorReason);
        }
    }
    
    /**
     * Nils the "errorReason" element
     */
    public void setNilErrorReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$4);
            }
            target.setNil();
        }
    }
}
