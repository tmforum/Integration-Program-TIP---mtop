/*
 * XML Type:  OperationType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.OperationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * An XML OperationType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
 *
 * This is a complex type.
 */
public class OperationTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.OperationType
{
    
    public OperationTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OPERATIONLABEL$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "operationLabel");
    private static final javax.xml.namespace.QName FAILPOLICY$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "failPolicy");
    private static final javax.xml.namespace.QName TEMPLATENAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "templateName");
    
    
    /**
     * Gets the "operationLabel" element
     */
    public java.lang.String getOperationLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "operationLabel" element
     */
    public org.apache.xmlbeans.XmlString xgetOperationLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERATIONLABEL$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "operationLabel" element
     */
    public boolean isNilOperationLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "operationLabel" element
     */
    public void setOperationLabel(java.lang.String operationLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OPERATIONLABEL$0);
            }
            target.setStringValue(operationLabel);
        }
    }
    
    /**
     * Sets (as xml) the "operationLabel" element
     */
    public void xsetOperationLabel(org.apache.xmlbeans.XmlString operationLabel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OPERATIONLABEL$0);
            }
            target.set(operationLabel);
        }
    }
    
    /**
     * Nils the "operationLabel" element
     */
    public void setNilOperationLabel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OPERATIONLABEL$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OPERATIONLABEL$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "failPolicy" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum getFailPolicy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILPOLICY$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "failPolicy" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType xgetFailPolicy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "failPolicy" element
     */
    public boolean isNilFailPolicy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "failPolicy" element
     */
    public void setFailPolicy(org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum failPolicy)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILPOLICY$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FAILPOLICY$2);
            }
            target.setEnumValue(failPolicy);
        }
    }
    
    /**
     * Sets (as xml) the "failPolicy" element
     */
    public void xsetFailPolicy(org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType failPolicy)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().add_element_user(FAILPOLICY$2);
            }
            target.set(failPolicy);
        }
    }
    
    /**
     * Nils the "failPolicy" element
     */
    public void setNilFailPolicy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().add_element_user(FAILPOLICY$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "templateName" element
     */
    public java.lang.String getTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TEMPLATENAME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "templateName" element
     */
    public org.apache.xmlbeans.XmlString xgetTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TEMPLATENAME$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "templateName" element
     */
    public boolean isNilTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TEMPLATENAME$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "templateName" element
     */
    public void setTemplateName(java.lang.String templateName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TEMPLATENAME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TEMPLATENAME$4);
            }
            target.setStringValue(templateName);
        }
    }
    
    /**
     * Sets (as xml) the "templateName" element
     */
    public void xsetTemplateName(org.apache.xmlbeans.XmlString templateName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TEMPLATENAME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TEMPLATENAME$4);
            }
            target.set(templateName);
        }
    }
    
    /**
     * Nils the "templateName" element
     */
    public void setNilTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TEMPLATENAME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TEMPLATENAME$4);
            }
            target.setNil();
        }
    }
}
