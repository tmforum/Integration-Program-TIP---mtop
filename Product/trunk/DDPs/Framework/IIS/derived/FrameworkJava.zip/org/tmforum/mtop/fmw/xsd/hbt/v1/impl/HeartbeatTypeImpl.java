/*
 * XML Type:  HeartbeatType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/hbt/v1
 * Java type: org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.hbt.v1.impl;
/**
 * An XML HeartbeatType(@http://www.tmforum.org/mtop/fmw/xsd/hbt/v1).
 *
 * This is a complex type.
 */
public class HeartbeatTypeImpl extends org.tmforum.mtop.fmw.xsd.ei.v1.impl.EventInformationTypeImpl implements org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType
{
    
    public HeartbeatTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
