/*
 * XML Type:  OrderType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.OrderType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * An XML OrderType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.
 */
public class OrderTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.mart.v1.OrderType
{
    
    public OrderTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected OrderTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
