/*
 * XML Type:  OperationEnumType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * An XML OperationEnumType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType.
 */
public class OperationEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType
{
    
    public OperationEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected OperationEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
