/*
 * An XML document type.
 * Localname: eventLossOccured
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/elo/v1
 * Java type: org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.elo.v1.impl;
/**
 * A document containing one eventLossOccured(@http://www.tmforum.org/mtop/fmw/xsd/elo/v1) element.
 *
 * This is a complex type.
 */
public class EventLossOccuredDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredDocument
{
    
    public EventLossOccuredDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EVENTLOSSOCCURED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/elo/v1", "eventLossOccured");
    
    
    /**
     * Gets the "eventLossOccured" element
     */
    public org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType getEventLossOccured()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType target = null;
            target = (org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType)get_store().find_element_user(EVENTLOSSOCCURED$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "eventLossOccured" element
     */
    public void setEventLossOccured(org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType eventLossOccured)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType target = null;
            target = (org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType)get_store().find_element_user(EVENTLOSSOCCURED$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType)get_store().add_element_user(EVENTLOSSOCCURED$0);
            }
            target.set(eventLossOccured);
        }
    }
    
    /**
     * Appends and returns a new empty "eventLossOccured" element
     */
    public org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType addNewEventLossOccured()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType target = null;
            target = (org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType)get_store().add_element_user(EVENTLOSSOCCURED$0);
            return target;
        }
    }
}
