/*
 * An XML document type.
 * Localname: setNetworkAccessDomainException
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setNetworkAccessDomainException(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetNetworkAccessDomainExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument
{
    
    public SetNetworkAccessDomainExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETNETWORKACCESSDOMAINEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setNetworkAccessDomainException");
    
    
    /**
     * Gets the "setNetworkAccessDomainException" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException getSetNetworkAccessDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException)get_store().find_element_user(SETNETWORKACCESSDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setNetworkAccessDomainException" element
     */
    public void setSetNetworkAccessDomainException(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException setNetworkAccessDomainException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException)get_store().find_element_user(SETNETWORKACCESSDOMAINEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException)get_store().add_element_user(SETNETWORKACCESSDOMAINEXCEPTION$0);
            }
            target.set(setNetworkAccessDomainException);
        }
    }
    
    /**
     * Appends and returns a new empty "setNetworkAccessDomainException" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException addNewSetNetworkAccessDomainException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException)get_store().add_element_user(SETNETWORKACCESSDOMAINEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setNetworkAccessDomainException(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetNetworkAccessDomainExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainExceptionDocument.SetNetworkAccessDomainException
    {
        
        public SetNetworkAccessDomainExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
