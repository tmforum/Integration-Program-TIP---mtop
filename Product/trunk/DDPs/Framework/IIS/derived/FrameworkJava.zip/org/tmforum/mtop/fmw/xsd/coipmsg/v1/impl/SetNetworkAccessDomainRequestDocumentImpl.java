/*
 * An XML document type.
 * Localname: setNetworkAccessDomainRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setNetworkAccessDomainRequest(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetNetworkAccessDomainRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument
{
    
    public SetNetworkAccessDomainRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETNETWORKACCESSDOMAINREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setNetworkAccessDomainRequest");
    
    
    /**
     * Gets the "setNetworkAccessDomainRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest getSetNetworkAccessDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest)get_store().find_element_user(SETNETWORKACCESSDOMAINREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setNetworkAccessDomainRequest" element
     */
    public void setSetNetworkAccessDomainRequest(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest setNetworkAccessDomainRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest)get_store().find_element_user(SETNETWORKACCESSDOMAINREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest)get_store().add_element_user(SETNETWORKACCESSDOMAINREQUEST$0);
            }
            target.set(setNetworkAccessDomainRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setNetworkAccessDomainRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest addNewSetNetworkAccessDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest)get_store().add_element_user(SETNETWORKACCESSDOMAINREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setNetworkAccessDomainRequest(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetNetworkAccessDomainRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainRequestDocument.SetNetworkAccessDomainRequest
    {
        
        public SetNetworkAccessDomainRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OBJECTNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "objectName");
        private static final javax.xml.namespace.QName NETWORKACCESSDOMAIN$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "networkAccessDomain");
        
        
        /**
         * Gets the "objectName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "objectName" element
         */
        public boolean isSetObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OBJECTNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "objectName" element
         */
        public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
                }
                target.set(objectName);
            }
        }
        
        /**
         * Appends and returns a new empty "objectName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "objectName" element
         */
        public void unsetObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OBJECTNAME$0, 0);
            }
        }
        
        /**
         * Gets the "networkAccessDomain" element
         */
        public java.lang.String getNetworkAccessDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "networkAccessDomain" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType xgetNetworkAccessDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "networkAccessDomain" element
         */
        public boolean isSetNetworkAccessDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NETWORKACCESSDOMAIN$2) != 0;
            }
        }
        
        /**
         * Sets the "networkAccessDomain" element
         */
        public void setNetworkAccessDomain(java.lang.String networkAccessDomain)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKACCESSDOMAIN$2);
                }
                target.setStringValue(networkAccessDomain);
            }
        }
        
        /**
         * Sets (as xml) the "networkAccessDomain" element
         */
        public void xsetNetworkAccessDomain(org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType networkAccessDomain)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().add_element_user(NETWORKACCESSDOMAIN$2);
                }
                target.set(networkAccessDomain);
            }
        }
        
        /**
         * Unsets the "networkAccessDomain" element
         */
        public void unsetNetworkAccessDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NETWORKACCESSDOMAIN$2, 0);
            }
        }
    }
}
