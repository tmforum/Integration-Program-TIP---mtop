/*
 * An XML document type.
 * Localname: doProcessResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * A document containing one doProcessResponse(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public class DoProcessResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument
{
    
    public DoProcessResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DOPROCESSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "doProcessResponse");
    
    
    /**
     * Gets the "doProcessResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse getDoProcessResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse)get_store().find_element_user(DOPROCESSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "doProcessResponse" element
     */
    public void setDoProcessResponse(org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse doProcessResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse)get_store().find_element_user(DOPROCESSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse)get_store().add_element_user(DOPROCESSRESPONSE$0);
            }
            target.set(doProcessResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "doProcessResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse addNewDoProcessResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse)get_store().add_element_user(DOPROCESSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML doProcessResponse(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public static class DoProcessResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse
    {
        
        public DoProcessResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CORRELATIONID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "correlationId");
        private static final javax.xml.namespace.QName RESULT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "result");
        private static final javax.xml.namespace.QName ERRORREASON$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "errorReason");
        private static final javax.xml.namespace.QName OPERATIONRESULT$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "operationResult");
        
        
        /**
         * Gets the "correlationId" element
         */
        public java.lang.String getCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        public org.apache.xmlbeans.XmlString xgetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "correlationId" element
         */
        public boolean isNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "correlationId" element
         */
        public boolean isSetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CORRELATIONID$0) != 0;
            }
        }
        
        /**
         * Sets the "correlationId" element
         */
        public void setCorrelationId(java.lang.String correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setStringValue(correlationId);
            }
        }
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        public void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.set(correlationId);
            }
        }
        
        /**
         * Nils the "correlationId" element
         */
        public void setNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "correlationId" element
         */
        public void unsetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CORRELATIONID$0, 0);
            }
        }
        
        /**
         * Gets the "result" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.Enum getResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESULT$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "result" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.ResultType xgetResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.ResultType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().find_element_user(RESULT$2, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "result" element
         */
        public boolean isNilResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.ResultType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().find_element_user(RESULT$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "result" element
         */
        public boolean isSetResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(RESULT$2) != 0;
            }
        }
        
        /**
         * Sets the "result" element
         */
        public void setResult(org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.Enum result)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RESULT$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RESULT$2);
                }
                target.setEnumValue(result);
            }
        }
        
        /**
         * Sets (as xml) the "result" element
         */
        public void xsetResult(org.tmforum.mtop.fmw.xsd.mart.v1.ResultType result)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.ResultType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().find_element_user(RESULT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().add_element_user(RESULT$2);
                }
                target.set(result);
            }
        }
        
        /**
         * Nils the "result" element
         */
        public void setNilResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.ResultType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().find_element_user(RESULT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.ResultType)get_store().add_element_user(RESULT$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "result" element
         */
        public void unsetResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(RESULT$2, 0);
            }
        }
        
        /**
         * Gets the "errorReason" element
         */
        public java.lang.String getErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "errorReason" element
         */
        public org.apache.xmlbeans.XmlString xgetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "errorReason" element
         */
        public boolean isNilErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "errorReason" element
         */
        public boolean isSetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ERRORREASON$4) != 0;
            }
        }
        
        /**
         * Sets the "errorReason" element
         */
        public void setErrorReason(java.lang.String errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ERRORREASON$4);
                }
                target.setStringValue(errorReason);
            }
        }
        
        /**
         * Sets (as xml) the "errorReason" element
         */
        public void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$4);
                }
                target.set(errorReason);
            }
        }
        
        /**
         * Nils the "errorReason" element
         */
        public void setNilErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ERRORREASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ERRORREASON$4);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "errorReason" element
         */
        public void unsetErrorReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ERRORREASON$4, 0);
            }
        }
        
        /**
         * Gets a List of "operationResult" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType> getOperationResultList()
        {
            final class OperationResultList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType>
            {
                public org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType get(int i)
                    { return DoProcessResponseImpl.this.getOperationResultArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType set(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType o)
                {
                    org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType old = DoProcessResponseImpl.this.getOperationResultArray(i);
                    DoProcessResponseImpl.this.setOperationResultArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType o)
                    { DoProcessResponseImpl.this.insertNewOperationResult(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType old = DoProcessResponseImpl.this.getOperationResultArray(i);
                    DoProcessResponseImpl.this.removeOperationResult(i);
                    return old;
                }
                
                public int size()
                    { return DoProcessResponseImpl.this.sizeOfOperationResultArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new OperationResultList();
            }
        }
        
        /**
         * Gets array of all "operationResult" elements
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType[] getOperationResultArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(OPERATIONRESULT$6, targetList);
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType[] result = new org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "operationResult" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType getOperationResultArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType)get_store().find_element_user(OPERATIONRESULT$6, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "operationResult" element
         */
        public int sizeOfOperationResultArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OPERATIONRESULT$6);
            }
        }
        
        /**
         * Sets array of all "operationResult" element
         */
        public void setOperationResultArray(org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType[] operationResultArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(operationResultArray, OPERATIONRESULT$6);
            }
        }
        
        /**
         * Sets ith "operationResult" element
         */
        public void setOperationResultArray(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType operationResult)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType)get_store().find_element_user(OPERATIONRESULT$6, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(operationResult);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "operationResult" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType insertNewOperationResult(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType)get_store().insert_element_user(OPERATIONRESULT$6, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "operationResult" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType addNewOperationResult()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType)get_store().add_element_user(OPERATIONRESULT$6);
                return target;
            }
        }
        
        /**
         * Removes the ith "operationResult" element
         */
        public void removeOperationResult(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OPERATIONRESULT$6, i);
            }
        }
    }
}
