/*
 * An XML document type.
 * Localname: doProcessRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1;


/**
 * A document containing one doProcessRequest(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public interface DoProcessRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DoProcessRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0AE75DA32A819DB783B25508F65BBD7E").resolveHandle("doprocessrequest0446doctype");
    
    /**
     * Gets the "doProcessRequest" element
     */
    org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest getDoProcessRequest();
    
    /**
     * Sets the "doProcessRequest" element
     */
    void setDoProcessRequest(org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest doProcessRequest);
    
    /**
     * Appends and returns a new empty "doProcessRequest" element
     */
    org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest addNewDoProcessRequest();
    
    /**
     * An XML doProcessRequest(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public interface DoProcessRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DoProcessRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0AE75DA32A819DB783B25508F65BBD7E").resolveHandle("doprocessrequestb83felemtype");
        
        /**
         * Gets the "correlationId" element
         */
        java.lang.String getCorrelationId();
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        org.apache.xmlbeans.XmlString xgetCorrelationId();
        
        /**
         * Tests for nil "correlationId" element
         */
        boolean isNilCorrelationId();
        
        /**
         * True if has "correlationId" element
         */
        boolean isSetCorrelationId();
        
        /**
         * Sets the "correlationId" element
         */
        void setCorrelationId(java.lang.String correlationId);
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId);
        
        /**
         * Nils the "correlationId" element
         */
        void setNilCorrelationId();
        
        /**
         * Unsets the "correlationId" element
         */
        void unsetCorrelationId();
        
        /**
         * Gets the "failPolicy" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum getFailPolicy();
        
        /**
         * Gets (as xml) the "failPolicy" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType xgetFailPolicy();
        
        /**
         * Tests for nil "failPolicy" element
         */
        boolean isNilFailPolicy();
        
        /**
         * True if has "failPolicy" element
         */
        boolean isSetFailPolicy();
        
        /**
         * Sets the "failPolicy" element
         */
        void setFailPolicy(org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum failPolicy);
        
        /**
         * Sets (as xml) the "failPolicy" element
         */
        void xsetFailPolicy(org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType failPolicy);
        
        /**
         * Nils the "failPolicy" element
         */
        void setNilFailPolicy();
        
        /**
         * Unsets the "failPolicy" element
         */
        void unsetFailPolicy();
        
        /**
         * Gets the "order" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.Enum getOrder();
        
        /**
         * Gets (as xml) the "order" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OrderType xgetOrder();
        
        /**
         * Tests for nil "order" element
         */
        boolean isNilOrder();
        
        /**
         * True if has "order" element
         */
        boolean isSetOrder();
        
        /**
         * Sets the "order" element
         */
        void setOrder(org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.Enum order);
        
        /**
         * Sets (as xml) the "order" element
         */
        void xsetOrder(org.tmforum.mtop.fmw.xsd.mart.v1.OrderType order);
        
        /**
         * Nils the "order" element
         */
        void setNilOrder();
        
        /**
         * Unsets the "order" element
         */
        void unsetOrder();
        
        /**
         * Gets the "templateList" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType getTemplateList();
        
        /**
         * Tests for nil "templateList" element
         */
        boolean isNilTemplateList();
        
        /**
         * True if has "templateList" element
         */
        boolean isSetTemplateList();
        
        /**
         * Sets the "templateList" element
         */
        void setTemplateList(org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType templateList);
        
        /**
         * Appends and returns a new empty "templateList" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType addNewTemplateList();
        
        /**
         * Nils the "templateList" element
         */
        void setNilTemplateList();
        
        /**
         * Unsets the "templateList" element
         */
        void unsetTemplateList();
        
        /**
         * Gets a List of "operationSet" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType> getOperationSetList();
        
        /**
         * Gets array of all "operationSet" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType[] getOperationSetArray();
        
        /**
         * Gets ith "operationSet" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType getOperationSetArray(int i);
        
        /**
         * Returns number of "operationSet" element
         */
        int sizeOfOperationSetArray();
        
        /**
         * Sets array of all "operationSet" element
         */
        void setOperationSetArray(org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType[] operationSetArray);
        
        /**
         * Sets ith "operationSet" element
         */
        void setOperationSetArray(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType operationSet);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "operationSet" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType insertNewOperationSet(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "operationSet" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType addNewOperationSet();
        
        /**
         * Removes the ith "operationSet" element
         */
        void removeOperationSet(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest newInstance() {
              return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument newInstance() {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
