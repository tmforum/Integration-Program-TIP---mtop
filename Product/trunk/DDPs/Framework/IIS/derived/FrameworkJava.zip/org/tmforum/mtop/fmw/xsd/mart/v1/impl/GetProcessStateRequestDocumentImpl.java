/*
 * An XML document type.
 * Localname: getProcessStateRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * A document containing one getProcessStateRequest(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public class GetProcessStateRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument
{
    
    public GetProcessStateRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROCESSSTATEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "getProcessStateRequest");
    
    
    /**
     * Gets the "getProcessStateRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest getGetProcessStateRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest)get_store().find_element_user(GETPROCESSSTATEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getProcessStateRequest" element
     */
    public void setGetProcessStateRequest(org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest getProcessStateRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest)get_store().find_element_user(GETPROCESSSTATEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest)get_store().add_element_user(GETPROCESSSTATEREQUEST$0);
            }
            target.set(getProcessStateRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getProcessStateRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest addNewGetProcessStateRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest)get_store().add_element_user(GETPROCESSSTATEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getProcessStateRequest(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public static class GetProcessStateRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateRequestDocument.GetProcessStateRequest
    {
        
        public GetProcessStateRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CORRELATIONID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "correlationId");
        
        
        /**
         * Gets the "correlationId" element
         */
        public java.lang.String getCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        public org.apache.xmlbeans.XmlString xgetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "correlationId" element
         */
        public boolean isNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * Sets the "correlationId" element
         */
        public void setCorrelationId(java.lang.String correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setStringValue(correlationId);
            }
        }
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        public void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.set(correlationId);
            }
        }
        
        /**
         * Nils the "correlationId" element
         */
        public void setNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setNil();
            }
        }
    }
}
