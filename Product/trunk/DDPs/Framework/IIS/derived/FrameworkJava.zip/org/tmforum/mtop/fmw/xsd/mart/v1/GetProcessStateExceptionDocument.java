/*
 * An XML document type.
 * Localname: getProcessStateException
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1;


/**
 * A document containing one getProcessStateException(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public interface GetProcessStateExceptionDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetProcessStateExceptionDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0AE75DA32A819DB783B25508F65BBD7E").resolveHandle("getprocessstateexception5c12doctype");
    
    /**
     * Gets the "getProcessStateException" element
     */
    org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException getGetProcessStateException();
    
    /**
     * Sets the "getProcessStateException" element
     */
    void setGetProcessStateException(org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException getProcessStateException);
    
    /**
     * Appends and returns a new empty "getProcessStateException" element
     */
    org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException addNewGetProcessStateException();
    
    /**
     * An XML getProcessStateException(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public interface GetProcessStateException extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetProcessStateException.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0AE75DA32A819DB783B25508F65BBD7E").resolveHandle("getprocessstateexception9ebfelemtype");
        
        /**
         * Gets the "CorrelationId" element
         */
        java.lang.String getCorrelationId();
        
        /**
         * Gets (as xml) the "CorrelationId" element
         */
        org.apache.xmlbeans.XmlString xgetCorrelationId();
        
        /**
         * Tests for nil "CorrelationId" element
         */
        boolean isNilCorrelationId();
        
        /**
         * True if has "CorrelationId" element
         */
        boolean isSetCorrelationId();
        
        /**
         * Sets the "CorrelationId" element
         */
        void setCorrelationId(java.lang.String correlationId);
        
        /**
         * Sets (as xml) the "CorrelationId" element
         */
        void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId);
        
        /**
         * Nils the "CorrelationId" element
         */
        void setNilCorrelationId();
        
        /**
         * Unsets the "CorrelationId" element
         */
        void unsetCorrelationId();
        
        /**
         * Gets the "exceptionType" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException.ExceptionType getExceptionType();
        
        /**
         * Sets the "exceptionType" element
         */
        void setExceptionType(org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException.ExceptionType exceptionType);
        
        /**
         * Appends and returns a new empty "exceptionType" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException.ExceptionType addNewExceptionType();
        
        /**
         * An XML exceptionType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
         *
         * This is a complex type.
         */
        public interface ExceptionType extends org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ExceptionType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0AE75DA32A819DB783B25508F65BBD7E").resolveHandle("exceptiontype5414elemtype");
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException.ExceptionType newInstance() {
                  return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException.ExceptionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException.ExceptionType newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException.ExceptionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException newInstance() {
              return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument.GetProcessStateException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument newInstance() {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
