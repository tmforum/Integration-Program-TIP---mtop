/*
 * An XML document type.
 * Localname: subscribeResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * A document containing one subscribeResponse(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1) element.
 *
 * This is a complex type.
 */
public class SubscribeResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument
{
    
    public SubscribeResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SUBSCRIBERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "subscribeResponse");
    
    
    /**
     * Gets the "subscribeResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse getSubscribeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse)get_store().find_element_user(SUBSCRIBERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "subscribeResponse" element
     */
    public void setSubscribeResponse(org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse subscribeResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse)get_store().find_element_user(SUBSCRIBERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse)get_store().add_element_user(SUBSCRIBERESPONSE$0);
            }
            target.set(subscribeResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "subscribeResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse addNewSubscribeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse)get_store().add_element_user(SUBSCRIBERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML subscribeResponse(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public static class SubscribeResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeResponseDocument.SubscribeResponse
    {
        
        public SubscribeResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SUBSCRIPTIONID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "subscriptionID");
        
        
        /**
         * Gets the "subscriptionID" element
         */
        public java.lang.String getSubscriptionID()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUBSCRIPTIONID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "subscriptionID" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType xgetSubscriptionID()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType)get_store().find_element_user(SUBSCRIPTIONID$0, 0);
                return target;
            }
        }
        
        /**
         * True if has "subscriptionID" element
         */
        public boolean isSetSubscriptionID()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SUBSCRIPTIONID$0) != 0;
            }
        }
        
        /**
         * Sets the "subscriptionID" element
         */
        public void setSubscriptionID(java.lang.String subscriptionID)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUBSCRIPTIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUBSCRIPTIONID$0);
                }
                target.setStringValue(subscriptionID);
            }
        }
        
        /**
         * Sets (as xml) the "subscriptionID" element
         */
        public void xsetSubscriptionID(org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType subscriptionID)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType)get_store().find_element_user(SUBSCRIPTIONID$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType)get_store().add_element_user(SUBSCRIPTIONID$0);
                }
                target.set(subscriptionID);
            }
        }
        
        /**
         * Unsets the "subscriptionID" element
         */
        public void unsetSubscriptionID()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SUBSCRIPTIONID$0, 0);
            }
        }
    }
}
