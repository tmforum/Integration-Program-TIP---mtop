/*
 * XML Type:  AnyListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1.impl;
/**
 * An XML AnyListType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is a complex type.
 */
public class AnyListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType
{
    
    public AnyListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
