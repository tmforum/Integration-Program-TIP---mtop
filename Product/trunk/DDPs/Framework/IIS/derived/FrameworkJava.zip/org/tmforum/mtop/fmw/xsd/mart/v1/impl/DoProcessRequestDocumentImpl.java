/*
 * An XML document type.
 * Localname: doProcessRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * A document containing one doProcessRequest(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public class DoProcessRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument
{
    
    public DoProcessRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DOPROCESSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "doProcessRequest");
    
    
    /**
     * Gets the "doProcessRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest getDoProcessRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest)get_store().find_element_user(DOPROCESSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "doProcessRequest" element
     */
    public void setDoProcessRequest(org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest doProcessRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest)get_store().find_element_user(DOPROCESSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest)get_store().add_element_user(DOPROCESSREQUEST$0);
            }
            target.set(doProcessRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "doProcessRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest addNewDoProcessRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest)get_store().add_element_user(DOPROCESSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML doProcessRequest(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public static class DoProcessRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessRequestDocument.DoProcessRequest
    {
        
        public DoProcessRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CORRELATIONID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "correlationId");
        private static final javax.xml.namespace.QName FAILPOLICY$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "failPolicy");
        private static final javax.xml.namespace.QName ORDER$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "order");
        private static final javax.xml.namespace.QName TEMPLATELIST$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "templateList");
        private static final javax.xml.namespace.QName OPERATIONSET$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "operationSet");
        
        
        /**
         * Gets the "correlationId" element
         */
        public java.lang.String getCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        public org.apache.xmlbeans.XmlString xgetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "correlationId" element
         */
        public boolean isNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "correlationId" element
         */
        public boolean isSetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CORRELATIONID$0) != 0;
            }
        }
        
        /**
         * Sets the "correlationId" element
         */
        public void setCorrelationId(java.lang.String correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setStringValue(correlationId);
            }
        }
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        public void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.set(correlationId);
            }
        }
        
        /**
         * Nils the "correlationId" element
         */
        public void setNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "correlationId" element
         */
        public void unsetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CORRELATIONID$0, 0);
            }
        }
        
        /**
         * Gets the "failPolicy" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum getFailPolicy()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILPOLICY$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "failPolicy" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType xgetFailPolicy()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$2, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "failPolicy" element
         */
        public boolean isNilFailPolicy()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "failPolicy" element
         */
        public boolean isSetFailPolicy()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILPOLICY$2) != 0;
            }
        }
        
        /**
         * Sets the "failPolicy" element
         */
        public void setFailPolicy(org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum failPolicy)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILPOLICY$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FAILPOLICY$2);
                }
                target.setEnumValue(failPolicy);
            }
        }
        
        /**
         * Sets (as xml) the "failPolicy" element
         */
        public void xsetFailPolicy(org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType failPolicy)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().add_element_user(FAILPOLICY$2);
                }
                target.set(failPolicy);
            }
        }
        
        /**
         * Nils the "failPolicy" element
         */
        public void setNilFailPolicy()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().add_element_user(FAILPOLICY$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "failPolicy" element
         */
        public void unsetFailPolicy()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILPOLICY$2, 0);
            }
        }
        
        /**
         * Gets the "order" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.Enum getOrder()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ORDER$4, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "order" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OrderType xgetOrder()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OrderType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().find_element_user(ORDER$4, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "order" element
         */
        public boolean isNilOrder()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OrderType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().find_element_user(ORDER$4, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "order" element
         */
        public boolean isSetOrder()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ORDER$4) != 0;
            }
        }
        
        /**
         * Sets the "order" element
         */
        public void setOrder(org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.Enum order)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ORDER$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ORDER$4);
                }
                target.setEnumValue(order);
            }
        }
        
        /**
         * Sets (as xml) the "order" element
         */
        public void xsetOrder(org.tmforum.mtop.fmw.xsd.mart.v1.OrderType order)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OrderType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().find_element_user(ORDER$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().add_element_user(ORDER$4);
                }
                target.set(order);
            }
        }
        
        /**
         * Nils the "order" element
         */
        public void setNilOrder()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OrderType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().find_element_user(ORDER$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().add_element_user(ORDER$4);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "order" element
         */
        public void unsetOrder()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ORDER$4, 0);
            }
        }
        
        /**
         * Gets the "templateList" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType getTemplateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType)get_store().find_element_user(TEMPLATELIST$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "templateList" element
         */
        public boolean isNilTemplateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType)get_store().find_element_user(TEMPLATELIST$6, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "templateList" element
         */
        public boolean isSetTemplateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TEMPLATELIST$6) != 0;
            }
        }
        
        /**
         * Sets the "templateList" element
         */
        public void setTemplateList(org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType templateList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType)get_store().find_element_user(TEMPLATELIST$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType)get_store().add_element_user(TEMPLATELIST$6);
                }
                target.set(templateList);
            }
        }
        
        /**
         * Appends and returns a new empty "templateList" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType addNewTemplateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType)get_store().add_element_user(TEMPLATELIST$6);
                return target;
            }
        }
        
        /**
         * Nils the "templateList" element
         */
        public void setNilTemplateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType)get_store().find_element_user(TEMPLATELIST$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType)get_store().add_element_user(TEMPLATELIST$6);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "templateList" element
         */
        public void unsetTemplateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TEMPLATELIST$6, 0);
            }
        }
        
        /**
         * Gets a List of "operationSet" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType> getOperationSetList()
        {
            final class OperationSetList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType>
            {
                public org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType get(int i)
                    { return DoProcessRequestImpl.this.getOperationSetArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType set(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType o)
                {
                    org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType old = DoProcessRequestImpl.this.getOperationSetArray(i);
                    DoProcessRequestImpl.this.setOperationSetArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType o)
                    { DoProcessRequestImpl.this.insertNewOperationSet(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType old = DoProcessRequestImpl.this.getOperationSetArray(i);
                    DoProcessRequestImpl.this.removeOperationSet(i);
                    return old;
                }
                
                public int size()
                    { return DoProcessRequestImpl.this.sizeOfOperationSetArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new OperationSetList();
            }
        }
        
        /**
         * Gets array of all "operationSet" elements
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType[] getOperationSetArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(OPERATIONSET$8, targetList);
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType[] result = new org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "operationSet" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType getOperationSetArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType)get_store().find_element_user(OPERATIONSET$8, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "operationSet" element
         */
        public int sizeOfOperationSetArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OPERATIONSET$8);
            }
        }
        
        /**
         * Sets array of all "operationSet" element
         */
        public void setOperationSetArray(org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType[] operationSetArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(operationSetArray, OPERATIONSET$8);
            }
        }
        
        /**
         * Sets ith "operationSet" element
         */
        public void setOperationSetArray(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType operationSet)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType)get_store().find_element_user(OPERATIONSET$8, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(operationSet);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "operationSet" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType insertNewOperationSet(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType)get_store().insert_element_user(OPERATIONSET$8, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "operationSet" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType addNewOperationSet()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType)get_store().add_element_user(OPERATIONSET$8);
                return target;
            }
        }
        
        /**
         * Removes the ith "operationSet" element
         */
        public void removeOperationSet(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OPERATIONSET$8, i);
            }
        }
    }
}
