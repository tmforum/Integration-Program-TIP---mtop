/*
 * An XML document type.
 * Localname: doProcessResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1;


/**
 * A document containing one doProcessResponse(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public interface DoProcessResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DoProcessResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s847FF0AD3261530B646FDA7C8CDE68B2").resolveHandle("doprocessresponse1baedoctype");
    
    /**
     * Gets the "doProcessResponse" element
     */
    org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse getDoProcessResponse();
    
    /**
     * Sets the "doProcessResponse" element
     */
    void setDoProcessResponse(org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse doProcessResponse);
    
    /**
     * Appends and returns a new empty "doProcessResponse" element
     */
    org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse addNewDoProcessResponse();
    
    /**
     * An XML doProcessResponse(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public interface DoProcessResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DoProcessResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s847FF0AD3261530B646FDA7C8CDE68B2").resolveHandle("doprocessresponsea9dfelemtype");
        
        /**
         * Gets the "correlationId" element
         */
        java.lang.String getCorrelationId();
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        org.apache.xmlbeans.XmlString xgetCorrelationId();
        
        /**
         * Tests for nil "correlationId" element
         */
        boolean isNilCorrelationId();
        
        /**
         * True if has "correlationId" element
         */
        boolean isSetCorrelationId();
        
        /**
         * Sets the "correlationId" element
         */
        void setCorrelationId(java.lang.String correlationId);
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId);
        
        /**
         * Nils the "correlationId" element
         */
        void setNilCorrelationId();
        
        /**
         * Unsets the "correlationId" element
         */
        void unsetCorrelationId();
        
        /**
         * Gets the "result" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.Enum getResult();
        
        /**
         * Gets (as xml) the "result" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.ResultType xgetResult();
        
        /**
         * Tests for nil "result" element
         */
        boolean isNilResult();
        
        /**
         * True if has "result" element
         */
        boolean isSetResult();
        
        /**
         * Sets the "result" element
         */
        void setResult(org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.Enum result);
        
        /**
         * Sets (as xml) the "result" element
         */
        void xsetResult(org.tmforum.mtop.fmw.xsd.mart.v1.ResultType result);
        
        /**
         * Nils the "result" element
         */
        void setNilResult();
        
        /**
         * Unsets the "result" element
         */
        void unsetResult();
        
        /**
         * Gets the "errorReason" element
         */
        java.lang.String getErrorReason();
        
        /**
         * Gets (as xml) the "errorReason" element
         */
        org.apache.xmlbeans.XmlString xgetErrorReason();
        
        /**
         * Tests for nil "errorReason" element
         */
        boolean isNilErrorReason();
        
        /**
         * True if has "errorReason" element
         */
        boolean isSetErrorReason();
        
        /**
         * Sets the "errorReason" element
         */
        void setErrorReason(java.lang.String errorReason);
        
        /**
         * Sets (as xml) the "errorReason" element
         */
        void xsetErrorReason(org.apache.xmlbeans.XmlString errorReason);
        
        /**
         * Nils the "errorReason" element
         */
        void setNilErrorReason();
        
        /**
         * Unsets the "errorReason" element
         */
        void unsetErrorReason();
        
        /**
         * Gets a List of "operationResult" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType> getOperationResultList();
        
        /**
         * Gets array of all "operationResult" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType[] getOperationResultArray();
        
        /**
         * Gets ith "operationResult" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType getOperationResultArray(int i);
        
        /**
         * Returns number of "operationResult" element
         */
        int sizeOfOperationResultArray();
        
        /**
         * Sets array of all "operationResult" element
         */
        void setOperationResultArray(org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType[] operationResultArray);
        
        /**
         * Sets ith "operationResult" element
         */
        void setOperationResultArray(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType operationResult);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "operationResult" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType insertNewOperationResult(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "operationResult" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.OperationResultType addNewOperationResult();
        
        /**
         * Removes the ith "operationResult" element
         */
        void removeOperationResult(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse newInstance() {
              return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument.DoProcessResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument newInstance() {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.DoProcessResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
