/*
 * XML Type:  SubscriptionIdentifierType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * An XML SubscriptionIdentifierType(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType.
 */
public class SubscriptionIdentifierTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType
{
    
    public SubscriptionIdentifierTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected SubscriptionIdentifierTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
