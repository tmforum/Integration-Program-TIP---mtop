/*
 * An XML document type.
 * Localname: terminateProcessException
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1;


/**
 * A document containing one terminateProcessException(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public interface TerminateProcessExceptionDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TerminateProcessExceptionDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s847FF0AD3261530B646FDA7C8CDE68B2").resolveHandle("terminateprocessexceptionce0adoctype");
    
    /**
     * Gets the "terminateProcessException" element
     */
    org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException getTerminateProcessException();
    
    /**
     * Sets the "terminateProcessException" element
     */
    void setTerminateProcessException(org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException terminateProcessException);
    
    /**
     * Appends and returns a new empty "terminateProcessException" element
     */
    org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException addNewTerminateProcessException();
    
    /**
     * An XML terminateProcessException(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public interface TerminateProcessException extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TerminateProcessException.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s847FF0AD3261530B646FDA7C8CDE68B2").resolveHandle("terminateprocessexception1a97elemtype");
        
        /**
         * Gets the "CorrelationId" element
         */
        java.lang.String getCorrelationId();
        
        /**
         * Gets (as xml) the "CorrelationId" element
         */
        org.apache.xmlbeans.XmlString xgetCorrelationId();
        
        /**
         * Tests for nil "CorrelationId" element
         */
        boolean isNilCorrelationId();
        
        /**
         * True if has "CorrelationId" element
         */
        boolean isSetCorrelationId();
        
        /**
         * Sets the "CorrelationId" element
         */
        void setCorrelationId(java.lang.String correlationId);
        
        /**
         * Sets (as xml) the "CorrelationId" element
         */
        void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId);
        
        /**
         * Nils the "CorrelationId" element
         */
        void setNilCorrelationId();
        
        /**
         * Unsets the "CorrelationId" element
         */
        void unsetCorrelationId();
        
        /**
         * Gets the "exceptionType" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType getExceptionType();
        
        /**
         * Sets the "exceptionType" element
         */
        void setExceptionType(org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType exceptionType);
        
        /**
         * Appends and returns a new empty "exceptionType" element
         */
        org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType addNewExceptionType();
        
        /**
         * An XML exceptionType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
         *
         * This is a complex type.
         */
        public interface ExceptionType extends org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ExceptionType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s847FF0AD3261530B646FDA7C8CDE68B2").resolveHandle("exceptiontypeceacelemtype");
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType newInstance() {
                  return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException newInstance() {
              return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument newInstance() {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
