/*
 * An XML document type.
 * Localname: fileTransferStatus
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/fts/v1
 * Java type: org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.fts.v1.impl;
/**
 * A document containing one fileTransferStatus(@http://www.tmforum.org/mtop/fmw/xsd/fts/v1) element.
 *
 * This is a complex type.
 */
public class FileTransferStatusDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoDocumentImpl implements org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusDocument
{
    
    public FileTransferStatusDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FILETRANSFERSTATUS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/fts/v1", "fileTransferStatus");
    
    
    /**
     * Gets the "fileTransferStatus" element
     */
    public org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType getFileTransferStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType target = null;
            target = (org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType)get_store().find_element_user(FILETRANSFERSTATUS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "fileTransferStatus" element
     */
    public void setFileTransferStatus(org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType fileTransferStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType target = null;
            target = (org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType)get_store().find_element_user(FILETRANSFERSTATUS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType)get_store().add_element_user(FILETRANSFERSTATUS$0);
            }
            target.set(fileTransferStatus);
        }
    }
    
    /**
     * Appends and returns a new empty "fileTransferStatus" element
     */
    public org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType addNewFileTransferStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType target = null;
            target = (org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType)get_store().add_element_user(FILETRANSFERSTATUS$0);
            return target;
        }
    }
}
