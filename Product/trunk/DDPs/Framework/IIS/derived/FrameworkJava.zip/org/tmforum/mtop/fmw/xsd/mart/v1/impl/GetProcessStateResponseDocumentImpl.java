/*
 * An XML document type.
 * Localname: getProcessStateResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * A document containing one getProcessStateResponse(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public class GetProcessStateResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument
{
    
    public GetProcessStateResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROCESSSTATERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "getProcessStateResponse");
    
    
    /**
     * Gets the "getProcessStateResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse getGetProcessStateResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse)get_store().find_element_user(GETPROCESSSTATERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getProcessStateResponse" element
     */
    public void setGetProcessStateResponse(org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse getProcessStateResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse)get_store().find_element_user(GETPROCESSSTATERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse)get_store().add_element_user(GETPROCESSSTATERESPONSE$0);
            }
            target.set(getProcessStateResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getProcessStateResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse addNewGetProcessStateResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse)get_store().add_element_user(GETPROCESSSTATERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getProcessStateResponse(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public static class GetProcessStateResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.GetProcessStateResponseDocument.GetProcessStateResponse
    {
        
        public GetProcessStateResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CORRELATIONID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "correlationId");
        private static final javax.xml.namespace.QName STATE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "state");
        private static final javax.xml.namespace.QName REASON$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "reason");
        
        
        /**
         * Gets the "correlationId" element
         */
        public java.lang.String getCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        public org.apache.xmlbeans.XmlString xgetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "correlationId" element
         */
        public boolean isNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * Sets the "correlationId" element
         */
        public void setCorrelationId(java.lang.String correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setStringValue(correlationId);
            }
        }
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        public void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.set(correlationId);
            }
        }
        
        /**
         * Nils the "correlationId" element
         */
        public void setNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Gets the "state" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.StateType.Enum getState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.fmw.xsd.mart.v1.StateType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "state" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.StateType xgetState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.StateType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.StateType)get_store().find_element_user(STATE$2, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "state" element
         */
        public boolean isNilState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.StateType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.StateType)get_store().find_element_user(STATE$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * Sets the "state" element
         */
        public void setState(org.tmforum.mtop.fmw.xsd.mart.v1.StateType.Enum state)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STATE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STATE$2);
                }
                target.setEnumValue(state);
            }
        }
        
        /**
         * Sets (as xml) the "state" element
         */
        public void xsetState(org.tmforum.mtop.fmw.xsd.mart.v1.StateType state)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.StateType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.StateType)get_store().find_element_user(STATE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.StateType)get_store().add_element_user(STATE$2);
                }
                target.set(state);
            }
        }
        
        /**
         * Nils the "state" element
         */
        public void setNilState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.StateType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.StateType)get_store().find_element_user(STATE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.StateType)get_store().add_element_user(STATE$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Gets the "reason" element
         */
        public java.lang.String getReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REASON$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "reason" element
         */
        public org.apache.xmlbeans.XmlString xgetReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REASON$4, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "reason" element
         */
        public boolean isNilReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REASON$4, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "reason" element
         */
        public boolean isSetReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(REASON$4) != 0;
            }
        }
        
        /**
         * Sets the "reason" element
         */
        public void setReason(java.lang.String reason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REASON$4);
                }
                target.setStringValue(reason);
            }
        }
        
        /**
         * Sets (as xml) the "reason" element
         */
        public void xsetReason(org.apache.xmlbeans.XmlString reason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(REASON$4);
                }
                target.set(reason);
            }
        }
        
        /**
         * Nils the "reason" element
         */
        public void setNilReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(REASON$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(REASON$4);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "reason" element
         */
        public void unsetReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(REASON$4, 0);
            }
        }
    }
}
