/*
 * An XML document type.
 * Localname: terminateProcessException
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * A document containing one terminateProcessException(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public class TerminateProcessExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument
{
    
    public TerminateProcessExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TERMINATEPROCESSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "terminateProcessException");
    
    
    /**
     * Gets the "terminateProcessException" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException getTerminateProcessException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException)get_store().find_element_user(TERMINATEPROCESSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "terminateProcessException" element
     */
    public void setTerminateProcessException(org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException terminateProcessException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException)get_store().find_element_user(TERMINATEPROCESSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException)get_store().add_element_user(TERMINATEPROCESSEXCEPTION$0);
            }
            target.set(terminateProcessException);
        }
    }
    
    /**
     * Appends and returns a new empty "terminateProcessException" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException addNewTerminateProcessException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException)get_store().add_element_user(TERMINATEPROCESSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML terminateProcessException(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public static class TerminateProcessExceptionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException
    {
        
        public TerminateProcessExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CORRELATIONID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "CorrelationId");
        private static final javax.xml.namespace.QName EXCEPTIONTYPE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "exceptionType");
        
        
        /**
         * Gets the "CorrelationId" element
         */
        public java.lang.String getCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "CorrelationId" element
         */
        public org.apache.xmlbeans.XmlString xgetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "CorrelationId" element
         */
        public boolean isNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "CorrelationId" element
         */
        public boolean isSetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CORRELATIONID$0) != 0;
            }
        }
        
        /**
         * Sets the "CorrelationId" element
         */
        public void setCorrelationId(java.lang.String correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setStringValue(correlationId);
            }
        }
        
        /**
         * Sets (as xml) the "CorrelationId" element
         */
        public void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.set(correlationId);
            }
        }
        
        /**
         * Nils the "CorrelationId" element
         */
        public void setNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "CorrelationId" element
         */
        public void unsetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CORRELATIONID$0, 0);
            }
        }
        
        /**
         * Gets the "exceptionType" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType getExceptionType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType)get_store().find_element_user(EXCEPTIONTYPE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "exceptionType" element
         */
        public void setExceptionType(org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType exceptionType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType)get_store().find_element_user(EXCEPTIONTYPE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType)get_store().add_element_user(EXCEPTIONTYPE$2);
                }
                target.set(exceptionType);
            }
        }
        
        /**
         * Appends and returns a new empty "exceptionType" element
         */
        public org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType addNewExceptionType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType)get_store().add_element_user(EXCEPTIONTYPE$2);
                return target;
            }
        }
        /**
         * An XML exceptionType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
         *
         * This is a complex type.
         */
        public static class ExceptionTypeImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessExceptionDocument.TerminateProcessException.ExceptionType
        {
            
            public ExceptionTypeImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            
        }
    }
}
