/*
 * An XML document type.
 * Localname: nvsList
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/nam/v1
 * Java type: org.tmforum.mtop.fmw.xsd.nam.v1.NvsListDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.nam.v1.impl;
/**
 * A document containing one nvsList(@http://www.tmforum.org/mtop/fmw/xsd/nam/v1) element.
 *
 * This is a complex type.
 */
public class NvsListDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.nam.v1.NvsListDocument
{
    
    public NvsListDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NVSLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "nvsList");
    
    
    /**
     * Gets the "nvsList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType getNvsList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(NVSLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "nvsList" element
     */
    public void setNvsList(org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType nvsList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(NVSLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(NVSLIST$0);
            }
            target.set(nvsList);
        }
    }
    
    /**
     * Appends and returns a new empty "nvsList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType addNewNvsList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(NVSLIST$0);
            return target;
        }
    }
}
