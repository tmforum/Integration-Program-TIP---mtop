/*
 * An XML document type.
 * Localname: subscribeRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1;


/**
 * A document containing one subscribeRequest(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1) element.
 *
 * This is a complex type.
 */
public interface SubscribeRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SubscribeRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0AE75DA32A819DB783B25508F65BBD7E").resolveHandle("subscriberequest79a8doctype");
    
    /**
     * Gets the "subscribeRequest" element
     */
    org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest getSubscribeRequest();
    
    /**
     * Sets the "subscribeRequest" element
     */
    void setSubscribeRequest(org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest subscribeRequest);
    
    /**
     * Appends and returns a new empty "subscribeRequest" element
     */
    org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest addNewSubscribeRequest();
    
    /**
     * An XML subscribeRequest(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public interface SubscribeRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SubscribeRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0AE75DA32A819DB783B25508F65BBD7E").resolveHandle("subscriberequestf347elemtype");
        
        /**
         * Gets the "consumerEpr" element
         */
        java.lang.String getConsumerEpr();
        
        /**
         * Gets (as xml) the "consumerEpr" element
         */
        org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType xgetConsumerEpr();
        
        /**
         * Sets the "consumerEpr" element
         */
        void setConsumerEpr(java.lang.String consumerEpr);
        
        /**
         * Sets (as xml) the "consumerEpr" element
         */
        void xsetConsumerEpr(org.tmforum.mtop.fmw.xsd.notmsg.v1.EndPointReferenceType consumerEpr);
        
        /**
         * Gets the "topic" element
         */
        java.lang.String getTopic();
        
        /**
         * Gets (as xml) the "topic" element
         */
        org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType xgetTopic();
        
        /**
         * True if has "topic" element
         */
        boolean isSetTopic();
        
        /**
         * Sets the "topic" element
         */
        void setTopic(java.lang.String topic);
        
        /**
         * Sets (as xml) the "topic" element
         */
        void xsetTopic(org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType topic);
        
        /**
         * Unsets the "topic" element
         */
        void unsetTopic();
        
        /**
         * Gets the "selector" element
         */
        org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType getSelector();
        
        /**
         * True if has "selector" element
         */
        boolean isSetSelector();
        
        /**
         * Sets the "selector" element
         */
        void setSelector(org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType selector);
        
        /**
         * Appends and returns a new empty "selector" element
         */
        org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryExpressionType addNewSelector();
        
        /**
         * Unsets the "selector" element
         */
        void unsetSelector();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest newInstance() {
              return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument.SubscribeRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument newInstance() {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscribeRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
