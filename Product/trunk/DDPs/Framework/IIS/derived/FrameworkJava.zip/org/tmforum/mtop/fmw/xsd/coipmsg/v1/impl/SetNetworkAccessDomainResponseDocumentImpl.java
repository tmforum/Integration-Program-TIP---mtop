/*
 * An XML document type.
 * Localname: setNetworkAccessDomainResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setNetworkAccessDomainResponse(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetNetworkAccessDomainResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument
{
    
    public SetNetworkAccessDomainResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETNETWORKACCESSDOMAINRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setNetworkAccessDomainResponse");
    
    
    /**
     * Gets the "setNetworkAccessDomainResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse getSetNetworkAccessDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse)get_store().find_element_user(SETNETWORKACCESSDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setNetworkAccessDomainResponse" element
     */
    public void setSetNetworkAccessDomainResponse(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse setNetworkAccessDomainResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse)get_store().find_element_user(SETNETWORKACCESSDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse)get_store().add_element_user(SETNETWORKACCESSDOMAINRESPONSE$0);
            }
            target.set(setNetworkAccessDomainResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setNetworkAccessDomainResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse addNewSetNetworkAccessDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse)get_store().add_element_user(SETNETWORKACCESSDOMAINRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setNetworkAccessDomainResponse(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetNetworkAccessDomainResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetNetworkAccessDomainResponseDocument.SetNetworkAccessDomainResponse
    {
        
        public SetNetworkAccessDomainResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
