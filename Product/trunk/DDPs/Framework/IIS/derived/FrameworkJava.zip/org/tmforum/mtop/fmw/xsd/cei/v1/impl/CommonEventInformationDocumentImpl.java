/*
 * An XML document type.
 * Localname: commonEventInformation
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cei/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cei.v1.impl;
/**
 * A document containing one commonEventInformation(@http://www.tmforum.org/mtop/fmw/xsd/cei/v1) element.
 *
 * This is a complex type.
 */
public class CommonEventInformationDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationDocument
{
    
    public CommonEventInformationDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONEVENTINFORMATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "commonEventInformation");
    private static final org.apache.xmlbeans.QNameSet COMMONEVENTINFORMATION$1 = org.apache.xmlbeans.QNameSet.forArray( new javax.xml.namespace.QName[] { 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/sc/v1", "stateChange"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "commonEventInformation"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/elo/v1", "eventLossOccured"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hbt/v1", "heartbeat"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/avc/v1", "attributeValueChange"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/fts/v1", "fileTransferStatus"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/elc/v1", "eventLossCleared"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odel/v1", "objectDeletion"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odis/v1", "objectDiscovery"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/oc/v1", "objectCreation"),
    });
    
    
    /**
     * Gets the "commonEventInformation" element
     */
    public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType getCommonEventInformation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().find_element_user(COMMONEVENTINFORMATION$1, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonEventInformation" element
     */
    public void setCommonEventInformation(org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType commonEventInformation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().find_element_user(COMMONEVENTINFORMATION$1, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().add_element_user(COMMONEVENTINFORMATION$0);
            }
            target.set(commonEventInformation);
        }
    }
    
    /**
     * Appends and returns a new empty "commonEventInformation" element
     */
    public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType addNewCommonEventInformation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().add_element_user(COMMONEVENTINFORMATION$0);
            return target;
        }
    }
}
