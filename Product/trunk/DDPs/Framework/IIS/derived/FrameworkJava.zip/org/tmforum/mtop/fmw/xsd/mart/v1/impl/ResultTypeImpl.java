/*
 * XML Type:  ResultType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.ResultType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * An XML ResultType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.mart.v1.ResultType.
 */
public class ResultTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.mart.v1.ResultType
{
    
    public ResultTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ResultTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
