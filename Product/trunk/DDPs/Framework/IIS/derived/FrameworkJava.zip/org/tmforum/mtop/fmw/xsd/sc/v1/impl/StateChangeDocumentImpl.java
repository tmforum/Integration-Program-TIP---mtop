/*
 * An XML document type.
 * Localname: stateChange
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/sc/v1
 * Java type: org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.sc.v1.impl;
/**
 * A document containing one stateChange(@http://www.tmforum.org/mtop/fmw/xsd/sc/v1) element.
 *
 * This is a complex type.
 */
public class StateChangeDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoDocumentImpl implements org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeDocument
{
    
    public StateChangeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName STATECHANGE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/sc/v1", "stateChange");
    
    
    /**
     * Gets the "stateChange" element
     */
    public org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType getStateChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType)get_store().find_element_user(STATECHANGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "stateChange" element
     */
    public void setStateChange(org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType stateChange)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType)get_store().find_element_user(STATECHANGE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType)get_store().add_element_user(STATECHANGE$0);
            }
            target.set(stateChange);
        }
    }
    
    /**
     * Appends and returns a new empty "stateChange" element
     */
    public org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType addNewStateChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType)get_store().add_element_user(STATECHANGE$0);
            return target;
        }
    }
}
