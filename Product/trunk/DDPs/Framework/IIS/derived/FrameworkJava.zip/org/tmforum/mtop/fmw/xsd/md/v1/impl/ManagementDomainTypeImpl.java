/*
 * XML Type:  ManagementDomainType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/md/v1
 * Java type: org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.md.v1.impl;
/**
 * An XML ManagementDomainType(@http://www.tmforum.org/mtop/fmw/xsd/md/v1).
 *
 * This is a complex type.
 */
public class ManagementDomainTypeImpl extends org.tmforum.mtop.fmw.xsd.coi.v1.impl.CommonObjectInfoTypeImpl implements org.tmforum.mtop.fmw.xsd.md.v1.ManagementDomainType
{
    
    public ManagementDomainTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
