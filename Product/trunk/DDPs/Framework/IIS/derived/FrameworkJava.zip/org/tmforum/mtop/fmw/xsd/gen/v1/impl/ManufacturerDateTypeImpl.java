/*
 * XML Type:  ManufacturerDateType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1.impl;
/**
 * An XML ManufacturerDateType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType.
 */
public class ManufacturerDateTypeImpl extends org.apache.xmlbeans.impl.values.JavaGDateHolderEx implements org.tmforum.mtop.fmw.xsd.gen.v1.ManufacturerDateType
{
    
    public ManufacturerDateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ManufacturerDateTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
