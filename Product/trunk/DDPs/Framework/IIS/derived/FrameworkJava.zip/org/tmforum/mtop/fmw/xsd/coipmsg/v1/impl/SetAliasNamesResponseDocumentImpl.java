/*
 * An XML document type.
 * Localname: setAliasNamesResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setAliasNamesResponse(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetAliasNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument
{
    
    public SetAliasNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALIASNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setAliasNamesResponse");
    
    
    /**
     * Gets the "setAliasNamesResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse getSetAliasNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse)get_store().find_element_user(SETALIASNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAliasNamesResponse" element
     */
    public void setSetAliasNamesResponse(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse setAliasNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse)get_store().find_element_user(SETALIASNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse)get_store().add_element_user(SETALIASNAMESRESPONSE$0);
            }
            target.set(setAliasNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setAliasNamesResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse addNewSetAliasNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse)get_store().add_element_user(SETALIASNAMESRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setAliasNamesResponse(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetAliasNamesResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesResponseDocument.SetAliasNamesResponse
    {
        
        public SetAliasNamesResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ALIASNAMES$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "aliasNames");
        
        
        /**
         * Gets the "aliasNames" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNames()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMES$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "aliasNames" element
         */
        public boolean isSetAliasNames()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ALIASNAMES$0) != 0;
            }
        }
        
        /**
         * Sets the "aliasNames" element
         */
        public void setAliasNames(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNames)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMES$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMES$0);
                }
                target.set(aliasNames);
            }
        }
        
        /**
         * Appends and returns a new empty "aliasNames" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNames()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMES$0);
                return target;
            }
        }
        
        /**
         * Unsets the "aliasNames" element
         */
        public void unsetAliasNames()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ALIASNAMES$0, 0);
            }
        }
    }
}
