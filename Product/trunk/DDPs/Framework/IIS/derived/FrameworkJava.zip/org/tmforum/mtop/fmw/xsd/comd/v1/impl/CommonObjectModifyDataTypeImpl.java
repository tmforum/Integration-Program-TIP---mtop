/*
 * XML Type:  CommonObjectModifyDataType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/comd/v1
 * Java type: org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.comd.v1.impl;
/**
 * An XML CommonObjectModifyDataType(@http://www.tmforum.org/mtop/fmw/xsd/comd/v1).
 *
 * This is a complex type.
 */
public class CommonObjectModifyDataTypeImpl extends org.tmforum.mtop.fmw.xsd.cosd.v1.impl.CommonObjectSetDataTypeImpl implements org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType
{
    
    public CommonObjectModifyDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
