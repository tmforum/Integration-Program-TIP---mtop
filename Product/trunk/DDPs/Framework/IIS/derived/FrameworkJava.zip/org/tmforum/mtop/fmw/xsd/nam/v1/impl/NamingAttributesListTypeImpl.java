/*
 * XML Type:  NamingAttributesListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/nam/v1
 * Java type: org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.nam.v1.impl;
/**
 * An XML NamingAttributesListType(@http://www.tmforum.org/mtop/fmw/xsd/nam/v1).
 *
 * This is a complex type.
 */
public class NamingAttributesListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType
{
    
    public NamingAttributesListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "name");
    
    
    /**
     * Gets a List of "name" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getNameList()
    {
        final class NameList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType get(int i)
                { return NamingAttributesListTypeImpl.this.getNameArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = NamingAttributesListTypeImpl.this.getNameArray(i);
                NamingAttributesListTypeImpl.this.setNameArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                { NamingAttributesListTypeImpl.this.insertNewName(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = NamingAttributesListTypeImpl.this.getNameArray(i);
                NamingAttributesListTypeImpl.this.removeName(i);
                return old;
            }
            
            public int size()
                { return NamingAttributesListTypeImpl.this.sizeOfNameArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new NameList();
        }
    }
    
    /**
     * Gets array of all "name" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(NAME$0, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getNameArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(NAME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "name" element
     */
    public int sizeOfNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NAME$0);
        }
    }
    
    /**
     * Sets array of all "name" element
     */
    public void setNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] nameArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(nameArray, NAME$0);
        }
    }
    
    /**
     * Sets ith "name" element
     */
    public void setNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(NAME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(name);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewName(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().insert_element_user(NAME$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(NAME$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "name" element
     */
    public void removeName(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NAME$0, i);
        }
    }
}
