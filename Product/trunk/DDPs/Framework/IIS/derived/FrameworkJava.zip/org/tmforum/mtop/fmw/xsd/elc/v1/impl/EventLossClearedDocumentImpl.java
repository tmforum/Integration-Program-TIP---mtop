/*
 * An XML document type.
 * Localname: eventLossCleared
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/elc/v1
 * Java type: org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.elc.v1.impl;
/**
 * A document containing one eventLossCleared(@http://www.tmforum.org/mtop/fmw/xsd/elc/v1) element.
 *
 * This is a complex type.
 */
public class EventLossClearedDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedDocument
{
    
    public EventLossClearedDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EVENTLOSSCLEARED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/elc/v1", "eventLossCleared");
    
    
    /**
     * Gets the "eventLossCleared" element
     */
    public org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType getEventLossCleared()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType target = null;
            target = (org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType)get_store().find_element_user(EVENTLOSSCLEARED$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "eventLossCleared" element
     */
    public void setEventLossCleared(org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType eventLossCleared)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType target = null;
            target = (org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType)get_store().find_element_user(EVENTLOSSCLEARED$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType)get_store().add_element_user(EVENTLOSSCLEARED$0);
            }
            target.set(eventLossCleared);
        }
    }
    
    /**
     * Appends and returns a new empty "eventLossCleared" element
     */
    public org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType addNewEventLossCleared()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType target = null;
            target = (org.tmforum.mtop.fmw.xsd.elc.v1.EventLossClearedType)get_store().add_element_user(EVENTLOSSCLEARED$0);
            return target;
        }
    }
}
