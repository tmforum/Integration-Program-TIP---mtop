/*
 * An XML document type.
 * Localname: objectDiscovery
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/odis/v1
 * Java type: org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.odis.v1.impl;
/**
 * A document containing one objectDiscovery(@http://www.tmforum.org/mtop/fmw/xsd/odis/v1) element.
 *
 * This is a complex type.
 */
public class ObjectDiscoveryDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoDocumentImpl implements org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryDocument
{
    
    public ObjectDiscoveryDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTDISCOVERY$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odis/v1", "objectDiscovery");
    
    
    /**
     * Gets the "objectDiscovery" element
     */
    public org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType getObjectDiscovery()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType target = null;
            target = (org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType)get_store().find_element_user(OBJECTDISCOVERY$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "objectDiscovery" element
     */
    public void setObjectDiscovery(org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType objectDiscovery)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType target = null;
            target = (org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType)get_store().find_element_user(OBJECTDISCOVERY$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType)get_store().add_element_user(OBJECTDISCOVERY$0);
            }
            target.set(objectDiscovery);
        }
    }
    
    /**
     * Appends and returns a new empty "objectDiscovery" element
     */
    public org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType addNewObjectDiscovery()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType target = null;
            target = (org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType)get_store().add_element_user(OBJECTDISCOVERY$0);
            return target;
        }
    }
}
