/*
 * XML Type:  QueryDialectTypeType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * An XML QueryDialectTypeType(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType.
 */
public class QueryDialectTypeTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.notmsg.v1.QueryDialectTypeType
{
    
    public QueryDialectTypeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected QueryDialectTypeTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
