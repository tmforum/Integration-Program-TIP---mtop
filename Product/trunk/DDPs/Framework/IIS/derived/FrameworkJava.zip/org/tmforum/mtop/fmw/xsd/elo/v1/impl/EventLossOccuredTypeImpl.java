/*
 * XML Type:  EventLossOccuredType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/elo/v1
 * Java type: org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.elo.v1.impl;
/**
 * An XML EventLossOccuredType(@http://www.tmforum.org/mtop/fmw/xsd/elo/v1).
 *
 * This is a complex type.
 */
public class EventLossOccuredTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationTypeImpl implements org.tmforum.mtop.fmw.xsd.elo.v1.EventLossOccuredType
{
    
    public EventLossOccuredTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/elo/v1", "objectType");
    private static final javax.xml.namespace.QName OBJECTNAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/elo/v1", "objectName");
    private static final javax.xml.namespace.QName STARTTIME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/elo/v1", "startTime");
    private static final javax.xml.namespace.QName FIRSTEVENTLOSTNOTIFICATIONID$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/elo/v1", "firstEventLostNotificationId");
    
    
    /**
     * Gets the "objectType" element
     */
    public java.lang.String getObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "objectType" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "objectType" element
     */
    public boolean isSetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "objectType" element
     */
    public void setObjectType(java.lang.String objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OBJECTTYPE$0);
            }
            target.setStringValue(objectType);
        }
    }
    
    /**
     * Sets (as xml) the "objectType" element
     */
    public void xsetObjectType(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().add_element_user(OBJECTTYPE$0);
            }
            target.set(objectType);
        }
    }
    
    /**
     * Unsets the "objectType" element
     */
    public void unsetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "objectName" element
     */
    public boolean isSetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTNAME$2) != 0;
        }
    }
    
    /**
     * Sets the "objectName" element
     */
    public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$2);
            }
            target.set(objectName);
        }
    }
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$2);
            return target;
        }
    }
    
    /**
     * Unsets the "objectName" element
     */
    public void unsetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTNAME$2, 0);
        }
    }
    
    /**
     * Gets the "startTime" element
     */
    public java.util.Calendar getStartTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STARTTIME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "startTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetStartTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(STARTTIME$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "startTime" element
     */
    public boolean isSetStartTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STARTTIME$4) != 0;
        }
    }
    
    /**
     * Sets the "startTime" element
     */
    public void setStartTime(java.util.Calendar startTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STARTTIME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STARTTIME$4);
            }
            target.setCalendarValue(startTime);
        }
    }
    
    /**
     * Sets (as xml) the "startTime" element
     */
    public void xsetStartTime(org.apache.xmlbeans.XmlDateTime startTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(STARTTIME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(STARTTIME$4);
            }
            target.set(startTime);
        }
    }
    
    /**
     * Unsets the "startTime" element
     */
    public void unsetStartTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STARTTIME$4, 0);
        }
    }
    
    /**
     * Gets the "firstEventLostNotificationId" element
     */
    public java.lang.String getFirstEventLostNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FIRSTEVENTLOSTNOTIFICATIONID$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "firstEventLostNotificationId" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType xgetFirstEventLostNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType)get_store().find_element_user(FIRSTEVENTLOSTNOTIFICATIONID$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "firstEventLostNotificationId" element
     */
    public boolean isSetFirstEventLostNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FIRSTEVENTLOSTNOTIFICATIONID$6) != 0;
        }
    }
    
    /**
     * Sets the "firstEventLostNotificationId" element
     */
    public void setFirstEventLostNotificationId(java.lang.String firstEventLostNotificationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FIRSTEVENTLOSTNOTIFICATIONID$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FIRSTEVENTLOSTNOTIFICATIONID$6);
            }
            target.setStringValue(firstEventLostNotificationId);
        }
    }
    
    /**
     * Sets (as xml) the "firstEventLostNotificationId" element
     */
    public void xsetFirstEventLostNotificationId(org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType firstEventLostNotificationId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType)get_store().find_element_user(FIRSTEVENTLOSTNOTIFICATIONID$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdType)get_store().add_element_user(FIRSTEVENTLOSTNOTIFICATIONID$6);
            }
            target.set(firstEventLostNotificationId);
        }
    }
    
    /**
     * Unsets the "firstEventLostNotificationId" element
     */
    public void unsetFirstEventLostNotificationId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FIRSTEVENTLOSTNOTIFICATIONID$6, 0);
        }
    }
}
