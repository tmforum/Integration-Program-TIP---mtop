/*
 * XML Type:  ObjectDiscoveryType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/odis/v1
 * Java type: org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.odis.v1.impl;
/**
 * An XML ObjectDiscoveryType(@http://www.tmforum.org/mtop/fmw/xsd/odis/v1).
 *
 * This is a complex type.
 */
public class ObjectDiscoveryTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationTypeImpl implements org.tmforum.mtop.fmw.xsd.odis.v1.ObjectDiscoveryType
{
    
    public ObjectDiscoveryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DISCOVEREDNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odis/v1", "discoveredName");
    private static final javax.xml.namespace.QName OBJECTTYPE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odis/v1", "objectType");
    private static final javax.xml.namespace.QName NETIME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odis/v1", "neTime");
    private static final javax.xml.namespace.QName EDGEPOINTRELATED$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odis/v1", "edgePointRelated");
    
    
    /**
     * Gets the "discoveredName" element
     */
    public java.lang.String getDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCOVEREDNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "discoveredName" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType xgetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().find_element_user(DISCOVEREDNAME$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "discoveredName" element
     */
    public boolean isSetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DISCOVEREDNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "discoveredName" element
     */
    public void setDiscoveredName(java.lang.String discoveredName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DISCOVEREDNAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DISCOVEREDNAME$0);
            }
            target.setStringValue(discoveredName);
        }
    }
    
    /**
     * Sets (as xml) the "discoveredName" element
     */
    public void xsetDiscoveredName(org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType discoveredName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().find_element_user(DISCOVEREDNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType)get_store().add_element_user(DISCOVEREDNAME$0);
            }
            target.set(discoveredName);
        }
    }
    
    /**
     * Unsets the "discoveredName" element
     */
    public void unsetDiscoveredName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DISCOVEREDNAME$0, 0);
        }
    }
    
    /**
     * Gets the "objectType" element
     */
    public java.lang.String getObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "objectType" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "objectType" element
     */
    public boolean isSetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTTYPE$2) != 0;
        }
    }
    
    /**
     * Sets the "objectType" element
     */
    public void setObjectType(java.lang.String objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OBJECTTYPE$2);
            }
            target.setStringValue(objectType);
        }
    }
    
    /**
     * Sets (as xml) the "objectType" element
     */
    public void xsetObjectType(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().add_element_user(OBJECTTYPE$2);
            }
            target.set(objectType);
        }
    }
    
    /**
     * Unsets the "objectType" element
     */
    public void unsetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTTYPE$2, 0);
        }
    }
    
    /**
     * Gets the "neTime" element
     */
    public java.util.Calendar getNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETIME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "neTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(NETIME$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "neTime" element
     */
    public boolean isSetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETIME$4) != 0;
        }
    }
    
    /**
     * Sets the "neTime" element
     */
    public void setNeTime(java.util.Calendar neTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETIME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETIME$4);
            }
            target.setCalendarValue(neTime);
        }
    }
    
    /**
     * Sets (as xml) the "neTime" element
     */
    public void xsetNeTime(org.apache.xmlbeans.XmlDateTime neTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(NETIME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(NETIME$4);
            }
            target.set(neTime);
        }
    }
    
    /**
     * Unsets the "neTime" element
     */
    public void unsetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETIME$4, 0);
        }
    }
    
    /**
     * Gets the "edgePointRelated" element
     */
    public boolean getEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EDGEPOINTRELATED$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "edgePointRelated" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINTRELATED$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "edgePointRelated" element
     */
    public boolean isSetEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EDGEPOINTRELATED$6) != 0;
        }
    }
    
    /**
     * Sets the "edgePointRelated" element
     */
    public void setEdgePointRelated(boolean edgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EDGEPOINTRELATED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EDGEPOINTRELATED$6);
            }
            target.setBooleanValue(edgePointRelated);
        }
    }
    
    /**
     * Sets (as xml) the "edgePointRelated" element
     */
    public void xsetEdgePointRelated(org.apache.xmlbeans.XmlBoolean edgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINTRELATED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EDGEPOINTRELATED$6);
            }
            target.set(edgePointRelated);
        }
    }
    
    /**
     * Unsets the "edgePointRelated" element
     */
    public void unsetEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EDGEPOINTRELATED$6, 0);
        }
    }
}
