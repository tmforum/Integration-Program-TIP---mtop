/*
 * XML Type:  FileTransferStatusEnumType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/fts/v1
 * Java type: org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.fts.v1.impl;
/**
 * An XML FileTransferStatusEnumType(@http://www.tmforum.org/mtop/fmw/xsd/fts/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType.
 */
public class FileTransferStatusEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType
{
    
    public FileTransferStatusEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected FileTransferStatusEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
