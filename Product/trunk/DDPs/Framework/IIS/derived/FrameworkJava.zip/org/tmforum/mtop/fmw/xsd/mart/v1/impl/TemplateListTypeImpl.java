/*
 * XML Type:  TemplateListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * An XML TemplateListType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
 *
 * This is a complex type.
 */
public class TemplateListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.TemplateListType
{
    
    public TemplateListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TEMPLATENAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "templateName");
    private static final javax.xml.namespace.QName TEMPLATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "template");
    
    
    /**
     * Gets the "templateName" element
     */
    public java.lang.String getTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TEMPLATENAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "templateName" element
     */
    public org.apache.xmlbeans.XmlString xgetTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TEMPLATENAME$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "templateName" element
     */
    public boolean isNilTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TEMPLATENAME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "templateName" element
     */
    public boolean isSetTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TEMPLATENAME$0) != 0;
        }
    }
    
    /**
     * Sets the "templateName" element
     */
    public void setTemplateName(java.lang.String templateName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TEMPLATENAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TEMPLATENAME$0);
            }
            target.setStringValue(templateName);
        }
    }
    
    /**
     * Sets (as xml) the "templateName" element
     */
    public void xsetTemplateName(org.apache.xmlbeans.XmlString templateName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TEMPLATENAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TEMPLATENAME$0);
            }
            target.set(templateName);
        }
    }
    
    /**
     * Nils the "templateName" element
     */
    public void setNilTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TEMPLATENAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TEMPLATENAME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "templateName" element
     */
    public void unsetTemplateName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TEMPLATENAME$0, 0);
        }
    }
    
    /**
     * Gets a List of "template" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.mart.v1.OperationType> getTemplateList()
    {
        final class TemplateList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.mart.v1.OperationType>
        {
            public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType get(int i)
                { return TemplateListTypeImpl.this.getTemplateArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType set(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationType o)
            {
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationType old = TemplateListTypeImpl.this.getTemplateArray(i);
                TemplateListTypeImpl.this.setTemplateArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationType o)
                { TemplateListTypeImpl.this.insertNewTemplate(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationType old = TemplateListTypeImpl.this.getTemplateArray(i);
                TemplateListTypeImpl.this.removeTemplate(i);
                return old;
            }
            
            public int size()
                { return TemplateListTypeImpl.this.sizeOfTemplateArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TemplateList();
        }
    }
    
    /**
     * Gets array of all "template" elements
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType[] getTemplateArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TEMPLATE$2, targetList);
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType[] result = new org.tmforum.mtop.fmw.xsd.mart.v1.OperationType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "template" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType getTemplateArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationType)get_store().find_element_user(TEMPLATE$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "template" element
     */
    public int sizeOfTemplateArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TEMPLATE$2);
        }
    }
    
    /**
     * Sets array of all "template" element
     */
    public void setTemplateArray(org.tmforum.mtop.fmw.xsd.mart.v1.OperationType[] templateArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(templateArray, TEMPLATE$2);
        }
    }
    
    /**
     * Sets ith "template" element
     */
    public void setTemplateArray(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationType template)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationType)get_store().find_element_user(TEMPLATE$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(template);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "template" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType insertNewTemplate(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationType)get_store().insert_element_user(TEMPLATE$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "template" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType addNewTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationType)get_store().add_element_user(TEMPLATE$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "template" element
     */
    public void removeTemplate(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TEMPLATE$2, i);
        }
    }
}
