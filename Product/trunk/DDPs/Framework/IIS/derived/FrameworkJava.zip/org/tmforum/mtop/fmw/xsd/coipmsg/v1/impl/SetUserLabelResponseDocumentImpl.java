/*
 * An XML document type.
 * Localname: setUserLabelResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setUserLabelResponse(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetUserLabelResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument
{
    
    public SetUserLabelResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETUSERLABELRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setUserLabelResponse");
    
    
    /**
     * Gets the "setUserLabelResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse getSetUserLabelResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse)get_store().find_element_user(SETUSERLABELRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setUserLabelResponse" element
     */
    public void setSetUserLabelResponse(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse setUserLabelResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse)get_store().find_element_user(SETUSERLABELRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse)get_store().add_element_user(SETUSERLABELRESPONSE$0);
            }
            target.set(setUserLabelResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setUserLabelResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse addNewSetUserLabelResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse)get_store().add_element_user(SETUSERLABELRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setUserLabelResponse(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetUserLabelResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelResponseDocument.SetUserLabelResponse
    {
        
        public SetUserLabelResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
