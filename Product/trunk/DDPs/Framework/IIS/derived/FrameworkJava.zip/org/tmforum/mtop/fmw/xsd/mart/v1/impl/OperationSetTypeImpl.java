/*
 * XML Type:  OperationSetType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * An XML OperationSetType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
 *
 * This is a complex type.
 */
public class OperationSetTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.OperationSetType
{
    
    public OperationSetTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FAILPOLICY$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "failPolicy");
    private static final javax.xml.namespace.QName ORDER$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "order");
    private static final javax.xml.namespace.QName OPERATION$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "operation");
    
    
    /**
     * Gets the "failPolicy" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum getFailPolicy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILPOLICY$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "failPolicy" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType xgetFailPolicy()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "failPolicy" element
     */
    public void setFailPolicy(org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType.Enum failPolicy)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILPOLICY$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FAILPOLICY$0);
            }
            target.setEnumValue(failPolicy);
        }
    }
    
    /**
     * Sets (as xml) the "failPolicy" element
     */
    public void xsetFailPolicy(org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType failPolicy)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().find_element_user(FAILPOLICY$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.FailPolicyType)get_store().add_element_user(FAILPOLICY$0);
            }
            target.set(failPolicy);
        }
    }
    
    /**
     * Gets the "order" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.Enum getOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ORDER$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "order" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OrderType xgetOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OrderType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().find_element_user(ORDER$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "order" element
     */
    public boolean isNilOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OrderType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().find_element_user(ORDER$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "order" element
     */
    public boolean isSetOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ORDER$2) != 0;
        }
    }
    
    /**
     * Sets the "order" element
     */
    public void setOrder(org.tmforum.mtop.fmw.xsd.mart.v1.OrderType.Enum order)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ORDER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ORDER$2);
            }
            target.setEnumValue(order);
        }
    }
    
    /**
     * Sets (as xml) the "order" element
     */
    public void xsetOrder(org.tmforum.mtop.fmw.xsd.mart.v1.OrderType order)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OrderType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().find_element_user(ORDER$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().add_element_user(ORDER$2);
            }
            target.set(order);
        }
    }
    
    /**
     * Nils the "order" element
     */
    public void setNilOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OrderType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().find_element_user(ORDER$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.OrderType)get_store().add_element_user(ORDER$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "order" element
     */
    public void unsetOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ORDER$2, 0);
        }
    }
    
    /**
     * Gets a List of "operation" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.mart.v1.OperationType> getOperationList()
    {
        final class OperationList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.mart.v1.OperationType>
        {
            public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType get(int i)
                { return OperationSetTypeImpl.this.getOperationArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType set(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationType o)
            {
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationType old = OperationSetTypeImpl.this.getOperationArray(i);
                OperationSetTypeImpl.this.setOperationArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationType o)
                { OperationSetTypeImpl.this.insertNewOperation(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.mart.v1.OperationType old = OperationSetTypeImpl.this.getOperationArray(i);
                OperationSetTypeImpl.this.removeOperation(i);
                return old;
            }
            
            public int size()
                { return OperationSetTypeImpl.this.sizeOfOperationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new OperationList();
        }
    }
    
    /**
     * Gets array of all "operation" elements
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType[] getOperationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(OPERATION$4, targetList);
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType[] result = new org.tmforum.mtop.fmw.xsd.mart.v1.OperationType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "operation" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType getOperationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationType)get_store().find_element_user(OPERATION$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "operation" element
     */
    public int sizeOfOperationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OPERATION$4);
        }
    }
    
    /**
     * Sets array of all "operation" element
     */
    public void setOperationArray(org.tmforum.mtop.fmw.xsd.mart.v1.OperationType[] operationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(operationArray, OPERATION$4);
        }
    }
    
    /**
     * Sets ith "operation" element
     */
    public void setOperationArray(int i, org.tmforum.mtop.fmw.xsd.mart.v1.OperationType operation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationType)get_store().find_element_user(OPERATION$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(operation);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "operation" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType insertNewOperation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationType)get_store().insert_element_user(OPERATION$4, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "operation" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.OperationType addNewOperation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.OperationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.OperationType)get_store().add_element_user(OPERATION$4);
            return target;
        }
    }
    
    /**
     * Removes the ith "operation" element
     */
    public void removeOperation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OPERATION$4, i);
        }
    }
}
