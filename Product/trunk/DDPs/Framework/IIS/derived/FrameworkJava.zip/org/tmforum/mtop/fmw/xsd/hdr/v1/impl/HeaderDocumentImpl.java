/*
 * An XML document type.
 * Localname: header
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/hdr/v1
 * Java type: org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.hdr.v1.impl;
/**
 * A document containing one header(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1) element.
 *
 * This is a complex type.
 */
public class HeaderDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument
{
    
    public HeaderDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName HEADER$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "header");
    
    
    /**
     * Gets the "header" element
     */
    public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header getHeader()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header target = null;
            target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header)get_store().find_element_user(HEADER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "header" element
     */
    public void setHeader(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header header)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header target = null;
            target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header)get_store().find_element_user(HEADER$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header)get_store().add_element_user(HEADER$0);
            }
            target.set(header);
        }
    }
    
    /**
     * Appends and returns a new empty "header" element
     */
    public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header addNewHeader()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header target = null;
            target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header)get_store().add_element_user(HEADER$0);
            return target;
        }
    }
    /**
     * An XML header(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
     *
     * This is a complex type.
     */
    public static class HeaderImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header
    {
        
        public HeaderImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ACTIVITYNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "activityName");
        private static final javax.xml.namespace.QName MSGNAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "msgName");
        private static final javax.xml.namespace.QName MSGTYPE$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "msgType");
        private static final javax.xml.namespace.QName SENDERURI$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "senderURI");
        private static final javax.xml.namespace.QName DESTINATIONURI$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "destinationURI");
        private static final javax.xml.namespace.QName REPLYTOURI$10 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "replyToURI");
        private static final javax.xml.namespace.QName ORIGINATORURI$12 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "originatorURI");
        private static final javax.xml.namespace.QName FAILUREREPLYTOURI$14 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "failureReplytoURI");
        private static final javax.xml.namespace.QName ACTIVITYSTATUS$16 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "activityStatus");
        private static final javax.xml.namespace.QName CORRELATIONID$18 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "correlationId");
        private static final javax.xml.namespace.QName SECURITY$20 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "security");
        private static final javax.xml.namespace.QName SECURITYTYPE$22 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "securityType");
        private static final javax.xml.namespace.QName PRIORITY$24 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "priority");
        private static final javax.xml.namespace.QName MSGSPECIFICPROPERTIES$26 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "msgSpecificProperties");
        private static final javax.xml.namespace.QName COMMUNICATIONPATTERN$28 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "communicationPattern");
        private static final javax.xml.namespace.QName COMMUNICATIONSTYLE$30 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "communicationStyle");
        private static final javax.xml.namespace.QName REQUESTEDBATCHSIZE$32 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "requestedBatchSize");
        private static final javax.xml.namespace.QName BATCHSEQUENCENUMBER$34 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "batchSequenceNumber");
        private static final javax.xml.namespace.QName BATCHSEQUENCEENDOFREPLY$36 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "batchSequenceEndOfReply");
        private static final javax.xml.namespace.QName ITERATORREFERENCEURI$38 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "iteratorReferenceURI");
        private static final javax.xml.namespace.QName FILELOCATIONURI$40 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "fileLocationURI");
        private static final javax.xml.namespace.QName COMPRESSIONTYPE$42 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "compressionType");
        private static final javax.xml.namespace.QName PACKINGTYPE$44 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "packingType");
        private static final javax.xml.namespace.QName TIMESTAMP$46 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "timestamp");
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$48 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "vendorExtensions");
        
        
        /**
         * Gets the "activityName" element
         */
        public java.lang.String getActivityName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVITYNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "activityName" element
         */
        public org.apache.xmlbeans.XmlString xgetActivityName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ACTIVITYNAME$0, 0);
                return target;
            }
        }
        
        /**
         * True if has "activityName" element
         */
        public boolean isSetActivityName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ACTIVITYNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "activityName" element
         */
        public void setActivityName(java.lang.String activityName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVITYNAME$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACTIVITYNAME$0);
                }
                target.setStringValue(activityName);
            }
        }
        
        /**
         * Sets (as xml) the "activityName" element
         */
        public void xsetActivityName(org.apache.xmlbeans.XmlString activityName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ACTIVITYNAME$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ACTIVITYNAME$0);
                }
                target.set(activityName);
            }
        }
        
        /**
         * Unsets the "activityName" element
         */
        public void unsetActivityName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ACTIVITYNAME$0, 0);
            }
        }
        
        /**
         * Gets the "msgName" element
         */
        public java.lang.String getMsgName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MSGNAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "msgName" element
         */
        public org.apache.xmlbeans.XmlString xgetMsgName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MSGNAME$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "msgName" element
         */
        public boolean isSetMsgName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MSGNAME$2) != 0;
            }
        }
        
        /**
         * Sets the "msgName" element
         */
        public void setMsgName(java.lang.String msgName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MSGNAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MSGNAME$2);
                }
                target.setStringValue(msgName);
            }
        }
        
        /**
         * Sets (as xml) the "msgName" element
         */
        public void xsetMsgName(org.apache.xmlbeans.XmlString msgName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MSGNAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MSGNAME$2);
                }
                target.set(msgName);
            }
        }
        
        /**
         * Unsets the "msgName" element
         */
        public void unsetMsgName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MSGNAME$2, 0);
            }
        }
        
        /**
         * Gets the "msgType" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType.Enum getMsgType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MSGTYPE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "msgType" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType xgetMsgType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType)get_store().find_element_user(MSGTYPE$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "msgType" element
         */
        public boolean isSetMsgType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MSGTYPE$4) != 0;
            }
        }
        
        /**
         * Sets the "msgType" element
         */
        public void setMsgType(org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType.Enum msgType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MSGTYPE$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MSGTYPE$4);
                }
                target.setEnumValue(msgType);
            }
        }
        
        /**
         * Sets (as xml) the "msgType" element
         */
        public void xsetMsgType(org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType msgType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType)get_store().find_element_user(MSGTYPE$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType)get_store().add_element_user(MSGTYPE$4);
                }
                target.set(msgType);
            }
        }
        
        /**
         * Unsets the "msgType" element
         */
        public void unsetMsgType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MSGTYPE$4, 0);
            }
        }
        
        /**
         * Gets the "senderURI" element
         */
        public java.lang.String getSenderURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SENDERURI$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "senderURI" element
         */
        public org.apache.xmlbeans.XmlAnyURI xgetSenderURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(SENDERURI$6, 0);
                return target;
            }
        }
        
        /**
         * True if has "senderURI" element
         */
        public boolean isSetSenderURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SENDERURI$6) != 0;
            }
        }
        
        /**
         * Sets the "senderURI" element
         */
        public void setSenderURI(java.lang.String senderURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SENDERURI$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SENDERURI$6);
                }
                target.setStringValue(senderURI);
            }
        }
        
        /**
         * Sets (as xml) the "senderURI" element
         */
        public void xsetSenderURI(org.apache.xmlbeans.XmlAnyURI senderURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(SENDERURI$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlAnyURI)get_store().add_element_user(SENDERURI$6);
                }
                target.set(senderURI);
            }
        }
        
        /**
         * Unsets the "senderURI" element
         */
        public void unsetSenderURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SENDERURI$6, 0);
            }
        }
        
        /**
         * Gets the "destinationURI" element
         */
        public java.lang.String getDestinationURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESTINATIONURI$8, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "destinationURI" element
         */
        public org.apache.xmlbeans.XmlAnyURI xgetDestinationURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(DESTINATIONURI$8, 0);
                return target;
            }
        }
        
        /**
         * True if has "destinationURI" element
         */
        public boolean isSetDestinationURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(DESTINATIONURI$8) != 0;
            }
        }
        
        /**
         * Sets the "destinationURI" element
         */
        public void setDestinationURI(java.lang.String destinationURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESTINATIONURI$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESTINATIONURI$8);
                }
                target.setStringValue(destinationURI);
            }
        }
        
        /**
         * Sets (as xml) the "destinationURI" element
         */
        public void xsetDestinationURI(org.apache.xmlbeans.XmlAnyURI destinationURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(DESTINATIONURI$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlAnyURI)get_store().add_element_user(DESTINATIONURI$8);
                }
                target.set(destinationURI);
            }
        }
        
        /**
         * Unsets the "destinationURI" element
         */
        public void unsetDestinationURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(DESTINATIONURI$8, 0);
            }
        }
        
        /**
         * Gets the "replyToURI" element
         */
        public java.lang.String getReplyToURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REPLYTOURI$10, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "replyToURI" element
         */
        public org.apache.xmlbeans.XmlAnyURI xgetReplyToURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(REPLYTOURI$10, 0);
                return target;
            }
        }
        
        /**
         * True if has "replyToURI" element
         */
        public boolean isSetReplyToURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(REPLYTOURI$10) != 0;
            }
        }
        
        /**
         * Sets the "replyToURI" element
         */
        public void setReplyToURI(java.lang.String replyToURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REPLYTOURI$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REPLYTOURI$10);
                }
                target.setStringValue(replyToURI);
            }
        }
        
        /**
         * Sets (as xml) the "replyToURI" element
         */
        public void xsetReplyToURI(org.apache.xmlbeans.XmlAnyURI replyToURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(REPLYTOURI$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlAnyURI)get_store().add_element_user(REPLYTOURI$10);
                }
                target.set(replyToURI);
            }
        }
        
        /**
         * Unsets the "replyToURI" element
         */
        public void unsetReplyToURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(REPLYTOURI$10, 0);
            }
        }
        
        /**
         * Gets the "originatorURI" element
         */
        public java.lang.String getOriginatorURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ORIGINATORURI$12, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "originatorURI" element
         */
        public org.apache.xmlbeans.XmlAnyURI xgetOriginatorURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(ORIGINATORURI$12, 0);
                return target;
            }
        }
        
        /**
         * True if has "originatorURI" element
         */
        public boolean isSetOriginatorURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ORIGINATORURI$12) != 0;
            }
        }
        
        /**
         * Sets the "originatorURI" element
         */
        public void setOriginatorURI(java.lang.String originatorURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ORIGINATORURI$12, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ORIGINATORURI$12);
                }
                target.setStringValue(originatorURI);
            }
        }
        
        /**
         * Sets (as xml) the "originatorURI" element
         */
        public void xsetOriginatorURI(org.apache.xmlbeans.XmlAnyURI originatorURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(ORIGINATORURI$12, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlAnyURI)get_store().add_element_user(ORIGINATORURI$12);
                }
                target.set(originatorURI);
            }
        }
        
        /**
         * Unsets the "originatorURI" element
         */
        public void unsetOriginatorURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ORIGINATORURI$12, 0);
            }
        }
        
        /**
         * Gets the "failureReplytoURI" element
         */
        public java.lang.String getFailureReplytoURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILUREREPLYTOURI$14, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "failureReplytoURI" element
         */
        public org.apache.xmlbeans.XmlAnyURI xgetFailureReplytoURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(FAILUREREPLYTOURI$14, 0);
                return target;
            }
        }
        
        /**
         * True if has "failureReplytoURI" element
         */
        public boolean isSetFailureReplytoURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILUREREPLYTOURI$14) != 0;
            }
        }
        
        /**
         * Sets the "failureReplytoURI" element
         */
        public void setFailureReplytoURI(java.lang.String failureReplytoURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILUREREPLYTOURI$14, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FAILUREREPLYTOURI$14);
                }
                target.setStringValue(failureReplytoURI);
            }
        }
        
        /**
         * Sets (as xml) the "failureReplytoURI" element
         */
        public void xsetFailureReplytoURI(org.apache.xmlbeans.XmlAnyURI failureReplytoURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(FAILUREREPLYTOURI$14, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlAnyURI)get_store().add_element_user(FAILUREREPLYTOURI$14);
                }
                target.set(failureReplytoURI);
            }
        }
        
        /**
         * Unsets the "failureReplytoURI" element
         */
        public void unsetFailureReplytoURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILUREREPLYTOURI$14, 0);
            }
        }
        
        /**
         * Gets the "activityStatus" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType getActivityStatus()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType)get_store().find_element_user(ACTIVITYSTATUS$16, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "activityStatus" element
         */
        public boolean isSetActivityStatus()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ACTIVITYSTATUS$16) != 0;
            }
        }
        
        /**
         * Sets the "activityStatus" element
         */
        public void setActivityStatus(org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType activityStatus)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType)get_store().find_element_user(ACTIVITYSTATUS$16, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType)get_store().add_element_user(ACTIVITYSTATUS$16);
                }
                target.set(activityStatus);
            }
        }
        
        /**
         * Appends and returns a new empty "activityStatus" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType addNewActivityStatus()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType)get_store().add_element_user(ACTIVITYSTATUS$16);
                return target;
            }
        }
        
        /**
         * Unsets the "activityStatus" element
         */
        public void unsetActivityStatus()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ACTIVITYSTATUS$16, 0);
            }
        }
        
        /**
         * Gets the "correlationId" element
         */
        public java.lang.String getCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$18, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        public org.apache.xmlbeans.XmlString xgetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$18, 0);
                return target;
            }
        }
        
        /**
         * True if has "correlationId" element
         */
        public boolean isSetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CORRELATIONID$18) != 0;
            }
        }
        
        /**
         * Sets the "correlationId" element
         */
        public void setCorrelationId(java.lang.String correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$18, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRELATIONID$18);
                }
                target.setStringValue(correlationId);
            }
        }
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        public void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$18, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$18);
                }
                target.set(correlationId);
            }
        }
        
        /**
         * Unsets the "correlationId" element
         */
        public void unsetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CORRELATIONID$18, 0);
            }
        }
        
        /**
         * Gets the "security" element
         */
        public java.lang.String getSecurity()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SECURITY$20, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "security" element
         */
        public org.apache.xmlbeans.XmlString xgetSecurity()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SECURITY$20, 0);
                return target;
            }
        }
        
        /**
         * True if has "security" element
         */
        public boolean isSetSecurity()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SECURITY$20) != 0;
            }
        }
        
        /**
         * Sets the "security" element
         */
        public void setSecurity(java.lang.String security)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SECURITY$20, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SECURITY$20);
                }
                target.setStringValue(security);
            }
        }
        
        /**
         * Sets (as xml) the "security" element
         */
        public void xsetSecurity(org.apache.xmlbeans.XmlString security)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SECURITY$20, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SECURITY$20);
                }
                target.set(security);
            }
        }
        
        /**
         * Unsets the "security" element
         */
        public void unsetSecurity()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SECURITY$20, 0);
            }
        }
        
        /**
         * Gets the "securityType" element
         */
        public java.lang.String getSecurityType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SECURITYTYPE$22, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "securityType" element
         */
        public org.apache.xmlbeans.XmlString xgetSecurityType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SECURITYTYPE$22, 0);
                return target;
            }
        }
        
        /**
         * True if has "securityType" element
         */
        public boolean isSetSecurityType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SECURITYTYPE$22) != 0;
            }
        }
        
        /**
         * Sets the "securityType" element
         */
        public void setSecurityType(java.lang.String securityType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SECURITYTYPE$22, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SECURITYTYPE$22);
                }
                target.setStringValue(securityType);
            }
        }
        
        /**
         * Sets (as xml) the "securityType" element
         */
        public void xsetSecurityType(org.apache.xmlbeans.XmlString securityType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SECURITYTYPE$22, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SECURITYTYPE$22);
                }
                target.set(securityType);
            }
        }
        
        /**
         * Unsets the "securityType" element
         */
        public void unsetSecurityType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SECURITYTYPE$22, 0);
            }
        }
        
        /**
         * Gets the "priority" element
         */
        public java.lang.String getPriority()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$24, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "priority" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority xgetPriority()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority)get_store().find_element_user(PRIORITY$24, 0);
                return target;
            }
        }
        
        /**
         * True if has "priority" element
         */
        public boolean isSetPriority()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PRIORITY$24) != 0;
            }
        }
        
        /**
         * Sets the "priority" element
         */
        public void setPriority(java.lang.String priority)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$24, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRIORITY$24);
                }
                target.setStringValue(priority);
            }
        }
        
        /**
         * Sets (as xml) the "priority" element
         */
        public void xsetPriority(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority priority)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority)get_store().find_element_user(PRIORITY$24, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority)get_store().add_element_user(PRIORITY$24);
                }
                target.set(priority);
            }
        }
        
        /**
         * Unsets the "priority" element
         */
        public void unsetPriority()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PRIORITY$24, 0);
            }
        }
        
        /**
         * Gets the "msgSpecificProperties" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties getMsgSpecificProperties()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties)get_store().find_element_user(MSGSPECIFICPROPERTIES$26, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "msgSpecificProperties" element
         */
        public boolean isSetMsgSpecificProperties()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MSGSPECIFICPROPERTIES$26) != 0;
            }
        }
        
        /**
         * Sets the "msgSpecificProperties" element
         */
        public void setMsgSpecificProperties(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties msgSpecificProperties)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties)get_store().find_element_user(MSGSPECIFICPROPERTIES$26, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties)get_store().add_element_user(MSGSPECIFICPROPERTIES$26);
                }
                target.set(msgSpecificProperties);
            }
        }
        
        /**
         * Appends and returns a new empty "msgSpecificProperties" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties addNewMsgSpecificProperties()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties)get_store().add_element_user(MSGSPECIFICPROPERTIES$26);
                return target;
            }
        }
        
        /**
         * Unsets the "msgSpecificProperties" element
         */
        public void unsetMsgSpecificProperties()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MSGSPECIFICPROPERTIES$26, 0);
            }
        }
        
        /**
         * Gets the "communicationPattern" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType.Enum getCommunicationPattern()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMMUNICATIONPATTERN$28, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "communicationPattern" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType xgetCommunicationPattern()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType)get_store().find_element_user(COMMUNICATIONPATTERN$28, 0);
                return target;
            }
        }
        
        /**
         * True if has "communicationPattern" element
         */
        public boolean isSetCommunicationPattern()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(COMMUNICATIONPATTERN$28) != 0;
            }
        }
        
        /**
         * Sets the "communicationPattern" element
         */
        public void setCommunicationPattern(org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType.Enum communicationPattern)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMMUNICATIONPATTERN$28, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COMMUNICATIONPATTERN$28);
                }
                target.setEnumValue(communicationPattern);
            }
        }
        
        /**
         * Sets (as xml) the "communicationPattern" element
         */
        public void xsetCommunicationPattern(org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType communicationPattern)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType)get_store().find_element_user(COMMUNICATIONPATTERN$28, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType)get_store().add_element_user(COMMUNICATIONPATTERN$28);
                }
                target.set(communicationPattern);
            }
        }
        
        /**
         * Unsets the "communicationPattern" element
         */
        public void unsetCommunicationPattern()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(COMMUNICATIONPATTERN$28, 0);
            }
        }
        
        /**
         * Gets the "communicationStyle" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType.Enum getCommunicationStyle()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMMUNICATIONSTYLE$30, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "communicationStyle" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType xgetCommunicationStyle()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType)get_store().find_element_user(COMMUNICATIONSTYLE$30, 0);
                return target;
            }
        }
        
        /**
         * True if has "communicationStyle" element
         */
        public boolean isSetCommunicationStyle()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(COMMUNICATIONSTYLE$30) != 0;
            }
        }
        
        /**
         * Sets the "communicationStyle" element
         */
        public void setCommunicationStyle(org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType.Enum communicationStyle)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMMUNICATIONSTYLE$30, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COMMUNICATIONSTYLE$30);
                }
                target.setEnumValue(communicationStyle);
            }
        }
        
        /**
         * Sets (as xml) the "communicationStyle" element
         */
        public void xsetCommunicationStyle(org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType communicationStyle)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType)get_store().find_element_user(COMMUNICATIONSTYLE$30, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType)get_store().add_element_user(COMMUNICATIONSTYLE$30);
                }
                target.set(communicationStyle);
            }
        }
        
        /**
         * Unsets the "communicationStyle" element
         */
        public void unsetCommunicationStyle()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(COMMUNICATIONSTYLE$30, 0);
            }
        }
        
        /**
         * Gets the "requestedBatchSize" element
         */
        public long getRequestedBatchSize()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REQUESTEDBATCHSIZE$32, 0);
                if (target == null)
                {
                    return 0L;
                }
                return target.getLongValue();
            }
        }
        
        /**
         * Gets (as xml) the "requestedBatchSize" element
         */
        public org.apache.xmlbeans.XmlUnsignedInt xgetRequestedBatchSize()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlUnsignedInt target = null;
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(REQUESTEDBATCHSIZE$32, 0);
                return target;
            }
        }
        
        /**
         * True if has "requestedBatchSize" element
         */
        public boolean isSetRequestedBatchSize()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(REQUESTEDBATCHSIZE$32) != 0;
            }
        }
        
        /**
         * Sets the "requestedBatchSize" element
         */
        public void setRequestedBatchSize(long requestedBatchSize)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REQUESTEDBATCHSIZE$32, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REQUESTEDBATCHSIZE$32);
                }
                target.setLongValue(requestedBatchSize);
            }
        }
        
        /**
         * Sets (as xml) the "requestedBatchSize" element
         */
        public void xsetRequestedBatchSize(org.apache.xmlbeans.XmlUnsignedInt requestedBatchSize)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlUnsignedInt target = null;
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(REQUESTEDBATCHSIZE$32, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(REQUESTEDBATCHSIZE$32);
                }
                target.set(requestedBatchSize);
            }
        }
        
        /**
         * Unsets the "requestedBatchSize" element
         */
        public void unsetRequestedBatchSize()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(REQUESTEDBATCHSIZE$32, 0);
            }
        }
        
        /**
         * Gets the "batchSequenceNumber" element
         */
        public long getBatchSequenceNumber()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BATCHSEQUENCENUMBER$34, 0);
                if (target == null)
                {
                    return 0L;
                }
                return target.getLongValue();
            }
        }
        
        /**
         * Gets (as xml) the "batchSequenceNumber" element
         */
        public org.apache.xmlbeans.XmlUnsignedInt xgetBatchSequenceNumber()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlUnsignedInt target = null;
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(BATCHSEQUENCENUMBER$34, 0);
                return target;
            }
        }
        
        /**
         * True if has "batchSequenceNumber" element
         */
        public boolean isSetBatchSequenceNumber()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BATCHSEQUENCENUMBER$34) != 0;
            }
        }
        
        /**
         * Sets the "batchSequenceNumber" element
         */
        public void setBatchSequenceNumber(long batchSequenceNumber)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BATCHSEQUENCENUMBER$34, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BATCHSEQUENCENUMBER$34);
                }
                target.setLongValue(batchSequenceNumber);
            }
        }
        
        /**
         * Sets (as xml) the "batchSequenceNumber" element
         */
        public void xsetBatchSequenceNumber(org.apache.xmlbeans.XmlUnsignedInt batchSequenceNumber)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlUnsignedInt target = null;
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(BATCHSEQUENCENUMBER$34, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(BATCHSEQUENCENUMBER$34);
                }
                target.set(batchSequenceNumber);
            }
        }
        
        /**
         * Unsets the "batchSequenceNumber" element
         */
        public void unsetBatchSequenceNumber()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BATCHSEQUENCENUMBER$34, 0);
            }
        }
        
        /**
         * Gets the "batchSequenceEndOfReply" element
         */
        public boolean getBatchSequenceEndOfReply()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BATCHSEQUENCEENDOFREPLY$36, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "batchSequenceEndOfReply" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetBatchSequenceEndOfReply()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BATCHSEQUENCEENDOFREPLY$36, 0);
                return target;
            }
        }
        
        /**
         * True if has "batchSequenceEndOfReply" element
         */
        public boolean isSetBatchSequenceEndOfReply()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BATCHSEQUENCEENDOFREPLY$36) != 0;
            }
        }
        
        /**
         * Sets the "batchSequenceEndOfReply" element
         */
        public void setBatchSequenceEndOfReply(boolean batchSequenceEndOfReply)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BATCHSEQUENCEENDOFREPLY$36, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BATCHSEQUENCEENDOFREPLY$36);
                }
                target.setBooleanValue(batchSequenceEndOfReply);
            }
        }
        
        /**
         * Sets (as xml) the "batchSequenceEndOfReply" element
         */
        public void xsetBatchSequenceEndOfReply(org.apache.xmlbeans.XmlBoolean batchSequenceEndOfReply)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(BATCHSEQUENCEENDOFREPLY$36, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(BATCHSEQUENCEENDOFREPLY$36);
                }
                target.set(batchSequenceEndOfReply);
            }
        }
        
        /**
         * Unsets the "batchSequenceEndOfReply" element
         */
        public void unsetBatchSequenceEndOfReply()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BATCHSEQUENCEENDOFREPLY$36, 0);
            }
        }
        
        /**
         * Gets the "iteratorReferenceURI" element
         */
        public java.lang.String getIteratorReferenceURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ITERATORREFERENCEURI$38, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "iteratorReferenceURI" element
         */
        public org.apache.xmlbeans.XmlAnyURI xgetIteratorReferenceURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(ITERATORREFERENCEURI$38, 0);
                return target;
            }
        }
        
        /**
         * True if has "iteratorReferenceURI" element
         */
        public boolean isSetIteratorReferenceURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ITERATORREFERENCEURI$38) != 0;
            }
        }
        
        /**
         * Sets the "iteratorReferenceURI" element
         */
        public void setIteratorReferenceURI(java.lang.String iteratorReferenceURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ITERATORREFERENCEURI$38, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ITERATORREFERENCEURI$38);
                }
                target.setStringValue(iteratorReferenceURI);
            }
        }
        
        /**
         * Sets (as xml) the "iteratorReferenceURI" element
         */
        public void xsetIteratorReferenceURI(org.apache.xmlbeans.XmlAnyURI iteratorReferenceURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(ITERATORREFERENCEURI$38, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlAnyURI)get_store().add_element_user(ITERATORREFERENCEURI$38);
                }
                target.set(iteratorReferenceURI);
            }
        }
        
        /**
         * Unsets the "iteratorReferenceURI" element
         */
        public void unsetIteratorReferenceURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ITERATORREFERENCEURI$38, 0);
            }
        }
        
        /**
         * Gets the "fileLocationURI" element
         */
        public java.lang.String getFileLocationURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FILELOCATIONURI$40, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "fileLocationURI" element
         */
        public org.apache.xmlbeans.XmlAnyURI xgetFileLocationURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(FILELOCATIONURI$40, 0);
                return target;
            }
        }
        
        /**
         * True if has "fileLocationURI" element
         */
        public boolean isSetFileLocationURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FILELOCATIONURI$40) != 0;
            }
        }
        
        /**
         * Sets the "fileLocationURI" element
         */
        public void setFileLocationURI(java.lang.String fileLocationURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FILELOCATIONURI$40, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FILELOCATIONURI$40);
                }
                target.setStringValue(fileLocationURI);
            }
        }
        
        /**
         * Sets (as xml) the "fileLocationURI" element
         */
        public void xsetFileLocationURI(org.apache.xmlbeans.XmlAnyURI fileLocationURI)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlAnyURI target = null;
                target = (org.apache.xmlbeans.XmlAnyURI)get_store().find_element_user(FILELOCATIONURI$40, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlAnyURI)get_store().add_element_user(FILELOCATIONURI$40);
                }
                target.set(fileLocationURI);
            }
        }
        
        /**
         * Unsets the "fileLocationURI" element
         */
        public void unsetFileLocationURI()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FILELOCATIONURI$40, 0);
            }
        }
        
        /**
         * Gets the "compressionType" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType getCompressionType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType)get_store().find_element_user(COMPRESSIONTYPE$42, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "compressionType" element
         */
        public boolean isSetCompressionType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(COMPRESSIONTYPE$42) != 0;
            }
        }
        
        /**
         * Sets the "compressionType" element
         */
        public void setCompressionType(org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType compressionType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType)get_store().find_element_user(COMPRESSIONTYPE$42, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType)get_store().add_element_user(COMPRESSIONTYPE$42);
                }
                target.set(compressionType);
            }
        }
        
        /**
         * Appends and returns a new empty "compressionType" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType addNewCompressionType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType)get_store().add_element_user(COMPRESSIONTYPE$42);
                return target;
            }
        }
        
        /**
         * Unsets the "compressionType" element
         */
        public void unsetCompressionType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(COMPRESSIONTYPE$42, 0);
            }
        }
        
        /**
         * Gets the "packingType" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType getPackingType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType)get_store().find_element_user(PACKINGTYPE$44, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "packingType" element
         */
        public boolean isSetPackingType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PACKINGTYPE$44) != 0;
            }
        }
        
        /**
         * Sets the "packingType" element
         */
        public void setPackingType(org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType packingType)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType)get_store().find_element_user(PACKINGTYPE$44, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType)get_store().add_element_user(PACKINGTYPE$44);
                }
                target.set(packingType);
            }
        }
        
        /**
         * Appends and returns a new empty "packingType" element
         */
        public org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType addNewPackingType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType)get_store().add_element_user(PACKINGTYPE$44);
                return target;
            }
        }
        
        /**
         * Unsets the "packingType" element
         */
        public void unsetPackingType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PACKINGTYPE$44, 0);
            }
        }
        
        /**
         * Gets the "timestamp" element
         */
        public java.util.Calendar getTimestamp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIMESTAMP$46, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getCalendarValue();
            }
        }
        
        /**
         * Gets (as xml) the "timestamp" element
         */
        public org.apache.xmlbeans.XmlDateTime xgetTimestamp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(TIMESTAMP$46, 0);
                return target;
            }
        }
        
        /**
         * True if has "timestamp" element
         */
        public boolean isSetTimestamp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TIMESTAMP$46) != 0;
            }
        }
        
        /**
         * Sets the "timestamp" element
         */
        public void setTimestamp(java.util.Calendar timestamp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TIMESTAMP$46, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TIMESTAMP$46);
                }
                target.setCalendarValue(timestamp);
            }
        }
        
        /**
         * Sets (as xml) the "timestamp" element
         */
        public void xsetTimestamp(org.apache.xmlbeans.XmlDateTime timestamp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(TIMESTAMP$46, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(TIMESTAMP$46);
                }
                target.set(timestamp);
            }
        }
        
        /**
         * Unsets the "timestamp" element
         */
        public void unsetTimestamp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TIMESTAMP$46, 0);
            }
        }
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$48, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$48) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$48, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$48);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$48);
                return target;
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$48, 0);
            }
        }
        /**
         * An XML priority(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
         *
         * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument$Header$Priority.
         */
        public static class PriorityImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority
        {
            
            public PriorityImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType, false);
            }
            
            protected PriorityImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
            {
                super(sType, b);
            }
        }
        /**
         * An XML msgSpecificProperties(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
         *
         * This is a complex type.
         */
        public static class MsgSpecificPropertiesImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties
        {
            
            public MsgSpecificPropertiesImpl(org.apache.xmlbeans.SchemaType sType)
            {
                super(sType);
            }
            
            private static final javax.xml.namespace.QName PROPERTY$0 = 
                new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "property");
            
            
            /**
             * Gets a List of "property" elements
             */
            public java.util.List<org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property> getPropertyList()
            {
                final class PropertyList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property>
                {
                    public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property get(int i)
                        { return MsgSpecificPropertiesImpl.this.getPropertyArray(i); }
                    
                    public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property set(int i, org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property o)
                    {
                      org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property old = MsgSpecificPropertiesImpl.this.getPropertyArray(i);
                      MsgSpecificPropertiesImpl.this.setPropertyArray(i, o);
                      return old;
                    }
                    
                    public void add(int i, org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property o)
                        { MsgSpecificPropertiesImpl.this.insertNewProperty(i).set(o); }
                    
                    public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property remove(int i)
                    {
                      org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property old = MsgSpecificPropertiesImpl.this.getPropertyArray(i);
                      MsgSpecificPropertiesImpl.this.removeProperty(i);
                      return old;
                    }
                    
                    public int size()
                        { return MsgSpecificPropertiesImpl.this.sizeOfPropertyArray(); }
                    
                }
                
                synchronized (monitor())
                {
                    check_orphaned();
                    return new PropertyList();
                }
            }
            
            /**
             * Gets array of all "property" elements
             */
            public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property[] getPropertyArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    java.util.List targetList = new java.util.ArrayList();
                    get_store().find_all_element_users(PROPERTY$0, targetList);
                    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property[] result = new org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property[targetList.size()];
                    targetList.toArray(result);
                    return result;
                }
            }
            
            /**
             * Gets ith "property" element
             */
            public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property getPropertyArray(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property target = null;
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property)get_store().find_element_user(PROPERTY$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    return target;
                }
            }
            
            /**
             * Returns number of "property" element
             */
            public int sizeOfPropertyArray()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    return get_store().count_elements(PROPERTY$0);
                }
            }
            
            /**
             * Sets array of all "property" element
             */
            public void setPropertyArray(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property[] propertyArray)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    arraySetterHelper(propertyArray, PROPERTY$0);
                }
            }
            
            /**
             * Sets ith "property" element
             */
            public void setPropertyArray(int i, org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property property)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property target = null;
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property)get_store().find_element_user(PROPERTY$0, i);
                    if (target == null)
                    {
                      throw new IndexOutOfBoundsException();
                    }
                    target.set(property);
                }
            }
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "property" element
             */
            public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property insertNewProperty(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property target = null;
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property)get_store().insert_element_user(PROPERTY$0, i);
                    return target;
                }
            }
            
            /**
             * Appends and returns a new empty value (as xml) as the last "property" element
             */
            public org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property addNewProperty()
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property target = null;
                    target = (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property)get_store().add_element_user(PROPERTY$0);
                    return target;
                }
            }
            
            /**
             * Removes the ith "property" element
             */
            public void removeProperty(int i)
            {
                synchronized (monitor())
                {
                    check_orphaned();
                    get_store().remove_element(PROPERTY$0, i);
                }
            }
            /**
             * An XML property(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
             *
             * This is a complex type.
             */
            public static class PropertyImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property
            {
                
                public PropertyImpl(org.apache.xmlbeans.SchemaType sType)
                {
                    super(sType);
                }
                
                private static final javax.xml.namespace.QName PROPNAME$0 = 
                    new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "propName");
                private static final javax.xml.namespace.QName PROPVALUE$2 = 
                    new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hdr/v1", "propValue");
                
                
                /**
                 * Gets the "propName" element
                 */
                public java.lang.String getPropName()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROPNAME$0, 0);
                      if (target == null)
                      {
                        return null;
                      }
                      return target.getStringValue();
                    }
                }
                
                /**
                 * Gets (as xml) the "propName" element
                 */
                public org.apache.xmlbeans.XmlString xgetPropName()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlString target = null;
                      target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROPNAME$0, 0);
                      return target;
                    }
                }
                
                /**
                 * Sets the "propName" element
                 */
                public void setPropName(java.lang.String propName)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROPNAME$0, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROPNAME$0);
                      }
                      target.setStringValue(propName);
                    }
                }
                
                /**
                 * Sets (as xml) the "propName" element
                 */
                public void xsetPropName(org.apache.xmlbeans.XmlString propName)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlString target = null;
                      target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROPNAME$0, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROPNAME$0);
                      }
                      target.set(propName);
                    }
                }
                
                /**
                 * Gets the "propValue" element
                 */
                public java.lang.String getPropValue()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROPVALUE$2, 0);
                      if (target == null)
                      {
                        return null;
                      }
                      return target.getStringValue();
                    }
                }
                
                /**
                 * Gets (as xml) the "propValue" element
                 */
                public org.apache.xmlbeans.XmlString xgetPropValue()
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlString target = null;
                      target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROPVALUE$2, 0);
                      return target;
                    }
                }
                
                /**
                 * Sets the "propValue" element
                 */
                public void setPropValue(java.lang.String propValue)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.SimpleValue target = null;
                      target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROPVALUE$2, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROPVALUE$2);
                      }
                      target.setStringValue(propValue);
                    }
                }
                
                /**
                 * Sets (as xml) the "propValue" element
                 */
                public void xsetPropValue(org.apache.xmlbeans.XmlString propValue)
                {
                    synchronized (monitor())
                    {
                      check_orphaned();
                      org.apache.xmlbeans.XmlString target = null;
                      target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROPVALUE$2, 0);
                      if (target == null)
                      {
                        target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROPVALUE$2);
                      }
                      target.set(propValue);
                    }
                }
            }
        }
    }
}
