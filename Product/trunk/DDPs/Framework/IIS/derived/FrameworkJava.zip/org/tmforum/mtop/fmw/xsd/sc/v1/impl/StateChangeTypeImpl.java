/*
 * XML Type:  StateChangeType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/sc/v1
 * Java type: org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.sc.v1.impl;
/**
 * An XML StateChangeType(@http://www.tmforum.org/mtop/fmw/xsd/sc/v1).
 *
 * This is a complex type.
 */
public class StateChangeTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoTypeImpl implements org.tmforum.mtop.fmw.xsd.sc.v1.StateChangeType
{
    
    public StateChangeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/sc/v1", "objectType");
    private static final javax.xml.namespace.QName OBJECTNAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/sc/v1", "objectName");
    private static final javax.xml.namespace.QName ATTRIBUTELIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/sc/v1", "attributeList");
    
    
    /**
     * Gets the "objectType" element
     */
    public java.lang.String getObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "objectType" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "objectType" element
     */
    public boolean isSetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "objectType" element
     */
    public void setObjectType(java.lang.String objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OBJECTTYPE$0);
            }
            target.setStringValue(objectType);
        }
    }
    
    /**
     * Sets (as xml) the "objectType" element
     */
    public void xsetObjectType(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().add_element_user(OBJECTTYPE$0);
            }
            target.set(objectType);
        }
    }
    
    /**
     * Unsets the "objectType" element
     */
    public void unsetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "objectName" element
     */
    public boolean isSetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTNAME$2) != 0;
        }
    }
    
    /**
     * Sets the "objectName" element
     */
    public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$2);
            }
            target.set(objectName);
        }
    }
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$2);
            return target;
        }
    }
    
    /**
     * Unsets the "objectName" element
     */
    public void unsetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTNAME$2, 0);
        }
    }
    
    /**
     * Gets the "attributeList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(ATTRIBUTELIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "attributeList" element
     */
    public boolean isSetAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ATTRIBUTELIST$4) != 0;
        }
    }
    
    /**
     * Sets the "attributeList" element
     */
    public void setAttributeList(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType attributeList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(ATTRIBUTELIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(ATTRIBUTELIST$4);
            }
            target.set(attributeList);
        }
    }
    
    /**
     * Appends and returns a new empty "attributeList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(ATTRIBUTELIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "attributeList" element
     */
    public void unsetAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ATTRIBUTELIST$4, 0);
        }
    }
}
