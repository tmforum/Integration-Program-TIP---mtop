/*
 * An XML document type.
 * Localname: setOwnerRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setOwnerRequest(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetOwnerRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument
{
    
    public SetOwnerRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETOWNERREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setOwnerRequest");
    
    
    /**
     * Gets the "setOwnerRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest getSetOwnerRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest)get_store().find_element_user(SETOWNERREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setOwnerRequest" element
     */
    public void setSetOwnerRequest(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest setOwnerRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest)get_store().find_element_user(SETOWNERREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest)get_store().add_element_user(SETOWNERREQUEST$0);
            }
            target.set(setOwnerRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setOwnerRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest addNewSetOwnerRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest)get_store().add_element_user(SETOWNERREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setOwnerRequest(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetOwnerRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerRequestDocument.SetOwnerRequest
    {
        
        public SetOwnerRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OBJECTNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "objectName");
        private static final javax.xml.namespace.QName OWNER$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "owner");
        
        
        /**
         * Gets the "objectName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "objectName" element
         */
        public boolean isSetObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OBJECTNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "objectName" element
         */
        public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
                }
                target.set(objectName);
            }
        }
        
        /**
         * Appends and returns a new empty "objectName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "objectName" element
         */
        public void unsetObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OBJECTNAME$0, 0);
            }
        }
        
        /**
         * Gets the "owner" element
         */
        public java.lang.String getOwner()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OWNER$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "owner" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType xgetOwner()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().find_element_user(OWNER$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "owner" element
         */
        public boolean isSetOwner()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OWNER$2) != 0;
            }
        }
        
        /**
         * Sets the "owner" element
         */
        public void setOwner(java.lang.String owner)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OWNER$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OWNER$2);
                }
                target.setStringValue(owner);
            }
        }
        
        /**
         * Sets (as xml) the "owner" element
         */
        public void xsetOwner(org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType owner)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().find_element_user(OWNER$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType)get_store().add_element_user(OWNER$2);
                }
                target.set(owner);
            }
        }
        
        /**
         * Unsets the "owner" element
         */
        public void unsetOwner()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OWNER$2, 0);
            }
        }
    }
}
