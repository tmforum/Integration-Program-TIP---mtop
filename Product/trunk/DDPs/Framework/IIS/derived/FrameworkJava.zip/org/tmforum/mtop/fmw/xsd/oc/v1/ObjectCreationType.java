/*
 * XML Type:  ObjectCreationType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/oc/v1
 * Java type: org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.oc.v1;


/**
 * An XML ObjectCreationType(@http://www.tmforum.org/mtop/fmw/xsd/oc/v1).
 *
 * This is a complex type.
 */
public interface ObjectCreationType extends org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ObjectCreationType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3EE8A2FA8C194D077953FE56598A3278").resolveHandle("objectcreationtype5da5type");
    
    /**
     * Gets the "objectType" element
     */
    java.lang.String getObjectType();
    
    /**
     * Gets (as xml) the "objectType" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetObjectType();
    
    /**
     * True if has "objectType" element
     */
    boolean isSetObjectType();
    
    /**
     * Sets the "objectType" element
     */
    void setObjectType(java.lang.String objectType);
    
    /**
     * Sets (as xml) the "objectType" element
     */
    void xsetObjectType(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType objectType);
    
    /**
     * Unsets the "objectType" element
     */
    void unsetObjectType();
    
    /**
     * Gets the "objectName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName();
    
    /**
     * True if has "objectName" element
     */
    boolean isSetObjectName();
    
    /**
     * Sets the "objectName" element
     */
    void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName);
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName();
    
    /**
     * Unsets the "objectName" element
     */
    void unsetObjectName();
    
    /**
     * Gets the "object" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getObject();
    
    /**
     * True if has "object" element
     */
    boolean isSetObject();
    
    /**
     * Sets the "object" element
     */
    void setObject(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType object);
    
    /**
     * Appends and returns a new empty "object" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewObject();
    
    /**
     * Unsets the "object" element
     */
    void unsetObject();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType newInstance() {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
