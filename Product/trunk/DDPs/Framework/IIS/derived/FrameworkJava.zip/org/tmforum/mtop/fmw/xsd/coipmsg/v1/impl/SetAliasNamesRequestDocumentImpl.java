/*
 * An XML document type.
 * Localname: setAliasNamesRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setAliasNamesRequest(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetAliasNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument
{
    
    public SetAliasNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALIASNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setAliasNamesRequest");
    
    
    /**
     * Gets the "setAliasNamesRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest getSetAliasNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest)get_store().find_element_user(SETALIASNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAliasNamesRequest" element
     */
    public void setSetAliasNamesRequest(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest setAliasNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest)get_store().find_element_user(SETALIASNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest)get_store().add_element_user(SETALIASNAMESREQUEST$0);
            }
            target.set(setAliasNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setAliasNamesRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest addNewSetAliasNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest)get_store().add_element_user(SETALIASNAMESREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setAliasNamesRequest(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetAliasNamesRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesRequestDocument.SetAliasNamesRequest
    {
        
        public SetAliasNamesRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OBJECTNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "objectName");
        private static final javax.xml.namespace.QName ALIASNAMES$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "aliasNames");
        
        
        /**
         * Gets the "objectName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "objectName" element
         */
        public boolean isSetObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OBJECTNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "objectName" element
         */
        public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
                }
                target.set(objectName);
            }
        }
        
        /**
         * Appends and returns a new empty "objectName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "objectName" element
         */
        public void unsetObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OBJECTNAME$0, 0);
            }
        }
        
        /**
         * Gets the "aliasNames" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNames()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMES$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "aliasNames" element
         */
        public boolean isSetAliasNames()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ALIASNAMES$2) != 0;
            }
        }
        
        /**
         * Sets the "aliasNames" element
         */
        public void setAliasNames(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNames)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMES$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMES$2);
                }
                target.set(aliasNames);
            }
        }
        
        /**
         * Appends and returns a new empty "aliasNames" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNames()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMES$2);
                return target;
            }
        }
        
        /**
         * Unsets the "aliasNames" element
         */
        public void unsetAliasNames()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ALIASNAMES$2, 0);
            }
        }
    }
}
