/*
 * An XML document type.
 * Localname: unsubscribeRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.notmsg.v1.impl;
/**
 * A document containing one unsubscribeRequest(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1) element.
 *
 * This is a complex type.
 */
public class UnsubscribeRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument
{
    
    public UnsubscribeRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UNSUBSCRIBEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "unsubscribeRequest");
    
    
    /**
     * Gets the "unsubscribeRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest getUnsubscribeRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest)get_store().find_element_user(UNSUBSCRIBEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "unsubscribeRequest" element
     */
    public void setUnsubscribeRequest(org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest unsubscribeRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest)get_store().find_element_user(UNSUBSCRIBEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest)get_store().add_element_user(UNSUBSCRIBEREQUEST$0);
            }
            target.set(unsubscribeRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "unsubscribeRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest addNewUnsubscribeRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest)get_store().add_element_user(UNSUBSCRIBEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML unsubscribeRequest(@http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1).
     *
     * This is a complex type.
     */
    public static class UnsubscribeRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.notmsg.v1.UnsubscribeRequestDocument.UnsubscribeRequest
    {
        
        public UnsubscribeRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SUBSCRIPTIONID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "subscriptionID");
        private static final javax.xml.namespace.QName TOPIC$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1", "topic");
        
        
        /**
         * Gets the "subscriptionID" element
         */
        public java.lang.String getSubscriptionID()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUBSCRIPTIONID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "subscriptionID" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType xgetSubscriptionID()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType)get_store().find_element_user(SUBSCRIPTIONID$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "subscriptionID" element
         */
        public void setSubscriptionID(java.lang.String subscriptionID)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUBSCRIPTIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUBSCRIPTIONID$0);
                }
                target.setStringValue(subscriptionID);
            }
        }
        
        /**
         * Sets (as xml) the "subscriptionID" element
         */
        public void xsetSubscriptionID(org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType subscriptionID)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType)get_store().find_element_user(SUBSCRIPTIONID$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.SubscriptionIdentifierType)get_store().add_element_user(SUBSCRIPTIONID$0);
                }
                target.set(subscriptionID);
            }
        }
        
        /**
         * Gets the "topic" element
         */
        public java.lang.String getTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOPIC$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "topic" element
         */
        public org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType xgetTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().find_element_user(TOPIC$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "topic" element
         */
        public boolean isSetTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOPIC$2) != 0;
            }
        }
        
        /**
         * Sets the "topic" element
         */
        public void setTopic(java.lang.String topic)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TOPIC$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TOPIC$2);
                }
                target.setStringValue(topic);
            }
        }
        
        /**
         * Sets (as xml) the "topic" element
         */
        public void xsetTopic(org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType topic)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType target = null;
                target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().find_element_user(TOPIC$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.notmsg.v1.TopicExpressionType)get_store().add_element_user(TOPIC$2);
                }
                target.set(topic);
            }
        }
        
        /**
         * Unsets the "topic" element
         */
        public void unsetTopic()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOPIC$2, 0);
            }
        }
    }
}
