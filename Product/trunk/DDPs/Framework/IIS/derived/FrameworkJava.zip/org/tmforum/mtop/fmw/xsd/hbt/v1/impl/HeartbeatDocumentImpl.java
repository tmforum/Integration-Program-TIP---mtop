/*
 * An XML document type.
 * Localname: heartbeat
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/hbt/v1
 * Java type: org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.hbt.v1.impl;
/**
 * A document containing one heartbeat(@http://www.tmforum.org/mtop/fmw/xsd/hbt/v1) element.
 *
 * This is a complex type.
 */
public class HeartbeatDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatDocument
{
    
    public HeartbeatDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName HEARTBEAT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/hbt/v1", "heartbeat");
    
    
    /**
     * Gets the "heartbeat" element
     */
    public org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType getHeartbeat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType target = null;
            target = (org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType)get_store().find_element_user(HEARTBEAT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "heartbeat" element
     */
    public void setHeartbeat(org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType heartbeat)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType target = null;
            target = (org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType)get_store().find_element_user(HEARTBEAT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType)get_store().add_element_user(HEARTBEAT$0);
            }
            target.set(heartbeat);
        }
    }
    
    /**
     * Appends and returns a new empty "heartbeat" element
     */
    public org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType addNewHeartbeat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType target = null;
            target = (org.tmforum.mtop.fmw.xsd.hbt.v1.HeartbeatType)get_store().add_element_user(HEARTBEAT$0);
            return target;
        }
    }
}
