/*
 * An XML document type.
 * Localname: commonObjectInfo
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coi/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coi.v1.impl;
/**
 * A document containing one commonObjectInfo(@http://www.tmforum.org/mtop/fmw/xsd/coi/v1) element.
 *
 * This is a complex type.
 */
public class CommonObjectInfoDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoDocument
{
    
    public CommonObjectInfoDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONOBJECTINFO$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coi/v1", "commonObjectInfo");
    
    
    /**
     * Gets the "commonObjectInfo" element
     */
    public org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType getCommonObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType target = null;
            target = (org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType)get_store().find_element_user(COMMONOBJECTINFO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonObjectInfo" element
     */
    public void setCommonObjectInfo(org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType commonObjectInfo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType target = null;
            target = (org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType)get_store().find_element_user(COMMONOBJECTINFO$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType)get_store().add_element_user(COMMONOBJECTINFO$0);
            }
            target.set(commonObjectInfo);
        }
    }
    
    /**
     * Appends and returns a new empty "commonObjectInfo" element
     */
    public org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType addNewCommonObjectInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType target = null;
            target = (org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType)get_store().add_element_user(COMMONOBJECTINFO$0);
            return target;
        }
    }
}
