/*
 * XML Type:  ServiceStateEnumType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.ServiceStateEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1.impl;
/**
 * An XML ServiceStateEnumType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.gen.v1.ServiceStateEnumType.
 */
public class ServiceStateEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.fmw.xsd.gen.v1.ServiceStateEnumType
{
    
    public ServiceStateEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ServiceStateEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
