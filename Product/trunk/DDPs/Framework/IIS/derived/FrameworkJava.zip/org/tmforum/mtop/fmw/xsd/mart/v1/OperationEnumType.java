/*
 * XML Type:  OperationEnumType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1;


/**
 * An XML OperationEnumType(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType.
 */
public interface OperationEnumType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(OperationEnumType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s847FF0AD3261530B646FDA7C8CDE68B2").resolveHandle("operationenumtype4ebbtype");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum PROVISION_EQUIPMENT = Enum.forString("provisionEquipment");
    static final Enum UNPROVISION_EQUIPMENT = Enum.forString("unprovisionEquipment");
    static final Enum VERIFY_TMD_ASSIGNMENT = Enum.forString("verifyTMDAssignment");
    static final Enum CREATE_FTP = Enum.forString("createFTP");
    static final Enum DELETE_FTP = Enum.forString("deleteFTP");
    static final Enum SET_TP_DATA = Enum.forString("setTPData");
    static final Enum CREATE_SNC = Enum.forString("createSNC");
    static final Enum ACTIVATE_SNC = Enum.forString("activateSNC");
    static final Enum CREATE_AND_ACTIVATE_SNC = Enum.forString("createAndActivateSNC");
    static final Enum DEACTIVATE_SNC = Enum.forString("deactivateSNC");
    static final Enum DELETE_SNC = Enum.forString("deleteSNC");
    static final Enum DEACTIVATE_AND_DELETE_SNC = Enum.forString("deactivateAndDeleteSNC");
    static final Enum CHECK_VALID_SNC = Enum.forString("checkValidSNC");
    static final Enum CREATE_MODIFIED_SNC = Enum.forString("createModifiedSNC");
    static final Enum MODIFY_SNC = Enum.forString("modifySNC");
    static final Enum CREATE_TOPOLOGICAL_LINK = Enum.forString("createTopologicalLink");
    static final Enum DELETE_TOPOLOGICAL_LINK = Enum.forString("deleteTopologicalLink");
    static final Enum CREATE_TRANSMISSION_DESCRIPTOR = Enum.forString("createTransmissionDescriptor");
    static final Enum DELETE_TRANSMISSION_DESCRIPTOR = Enum.forString("deleteTransmissionDescriptor");
    static final Enum MODIFY_TRANSMISSION_DESCRIPTOR = Enum.forString("modifyTransmissionDescriptor");
    static final Enum CREATE_FLOW_DOMAIN = Enum.forString("createFlowDomain");
    static final Enum DELETE_FLOW_DOMAIN = Enum.forString("deleteFlowDomain");
    static final Enum MODIFY_FLOW_DOMAIN = Enum.forString("modifyFlowDomain");
    static final Enum CREATE_MFD = Enum.forString("createMFD");
    static final Enum DELETE_MFD = Enum.forString("deleteMFD");
    static final Enum MODIFY_MFD = Enum.forString("modifyMFD");
    static final Enum VALIDATE_TMD_ASSIGNMENT_TO_MFD = Enum.forString("validateTMDAssignmentToMFD");
    static final Enum CREATE_AND_ACTIVATE_FD_FR = Enum.forString("createAndActivateFDFr");
    static final Enum DEACTIVATE_AND_DELETE_FD_FR = Enum.forString("deactivateAndDeleteFDFr");
    static final Enum MODIFY_FD_FR = Enum.forString("modifyFDFr");
    static final Enum ASSOCIATE_MF_DS_WITH_FLOW_DOMAIN = Enum.forString("associateMFDsWithFlowDomain");
    static final Enum DE_ASSOCIATE_MF_DS_FROM_FLOW_DOMAIN = Enum.forString("deAssociateMFDsFromFlowDomain");
    static final Enum ASSOCIATE_CPT_PS_WITH_FLOW_DOMAIN = Enum.forString("associateCPTPsWithFlowDomain");
    static final Enum DE_ASSOCIATE_CPT_PS_FROM_FLOW_DOMAIN = Enum.forString("deAssociateCPTPsFromFlowDomain");
    static final Enum ADD_F_PS_TO_FD_FR = Enum.forString("addFPsToFDFr");
    static final Enum REMOVE_F_PS_FROM_FD_FR = Enum.forString("removeFPsFromFDFr");
    static final Enum CREATE_TP_POOL = Enum.forString("createTPPool");
    static final Enum DELETE_TP_POOL = Enum.forString("deleteTPPool");
    static final Enum MODIFY_TP_POOL = Enum.forString("modifyTPPool");
    static final Enum ASSIGN_CPT_PS_TO_MFD = Enum.forString("assignCPTPsToMFD");
    static final Enum UNASSIGN_CPT_PS_FROM_MFD = Enum.forString("unassignCPTPsFromMFD");
    static final Enum CREATE_GTP = Enum.forString("createGTP");
    static final Enum DELETE_GTP = Enum.forString("deleteGTP");
    static final Enum MODIFY_GTP = Enum.forString("modifyGTP");
    static final Enum CREATE_TCA_PARAMETER_PROFILE = Enum.forString("createTCAParameterProfile");
    static final Enum DELETE_TCA_PARAMETER_PROFILE = Enum.forString("deleteTCAParameterProfile");
    static final Enum SET_TCA_PARAMETER_PROFILE = Enum.forString("setTCAParameterProfile");
    static final Enum SET_TCA_PARAMETER_PROFILE_POINTER = Enum.forString("setTCAParameterProfilePointer");
    static final Enum CREATE_ASAP = Enum.forString("createASAP");
    static final Enum DELETE_ASAP = Enum.forString("deleteASAP");
    static final Enum ASSIGN_ASAP = Enum.forString("assignASAP");
    static final Enum DEASSIGN_ASAP = Enum.forString("deassignASAP");
    static final Enum ESTABLISH_CALL = Enum.forString("establishCall");
    static final Enum RELEASE_CALL = Enum.forString("releaseCall");
    
    static final int INT_PROVISION_EQUIPMENT = Enum.INT_PROVISION_EQUIPMENT;
    static final int INT_UNPROVISION_EQUIPMENT = Enum.INT_UNPROVISION_EQUIPMENT;
    static final int INT_VERIFY_TMD_ASSIGNMENT = Enum.INT_VERIFY_TMD_ASSIGNMENT;
    static final int INT_SET_TP_DATA = Enum.INT_SET_TP_DATA;
    static final int INT_CREATE_SNC = Enum.INT_CREATE_SNC;
    static final int INT_ACTIVATE_SNC = Enum.INT_ACTIVATE_SNC;
    static final int INT_CREATE_AND_ACTIVATE_SNC = Enum.INT_CREATE_AND_ACTIVATE_SNC;
    static final int INT_DEACTIVATE_SNC = Enum.INT_DEACTIVATE_SNC;
    static final int INT_DELETE_SNC = Enum.INT_DELETE_SNC;
    static final int INT_DEACTIVATE_AND_DELETE_SNC = Enum.INT_DEACTIVATE_AND_DELETE_SNC;
    static final int INT_CHECK_VALID_SNC = Enum.INT_CHECK_VALID_SNC;
    static final int INT_CREATE_MODIFIED_SNC = Enum.INT_CREATE_MODIFIED_SNC;
    static final int INT_MODIFY_SNC = Enum.INT_MODIFY_SNC;
    static final int INT_CREATE_TOPOLOGICAL_LINK = Enum.INT_CREATE_TOPOLOGICAL_LINK;
    static final int INT_DELETE_TOPOLOGICAL_LINK = Enum.INT_DELETE_TOPOLOGICAL_LINK;
    static final int INT_CREATE_TRANSMISSION_DESCRIPTOR = Enum.INT_CREATE_TRANSMISSION_DESCRIPTOR;
    static final int INT_DELETE_TRANSMISSION_DESCRIPTOR = Enum.INT_DELETE_TRANSMISSION_DESCRIPTOR;
    static final int INT_MODIFY_TRANSMISSION_DESCRIPTOR = Enum.INT_MODIFY_TRANSMISSION_DESCRIPTOR;
    static final int INT_CREATE_FLOW_DOMAIN = Enum.INT_CREATE_FLOW_DOMAIN;
    static final int INT_DELETE_FLOW_DOMAIN = Enum.INT_DELETE_FLOW_DOMAIN;
    static final int INT_MODIFY_FLOW_DOMAIN = Enum.INT_MODIFY_FLOW_DOMAIN;
    static final int INT_CREATE_MFD = Enum.INT_CREATE_MFD;
    static final int INT_DELETE_MFD = Enum.INT_DELETE_MFD;
    static final int INT_MODIFY_MFD = Enum.INT_MODIFY_MFD;
    static final int INT_VALIDATE_TMD_ASSIGNMENT_TO_MFD = Enum.INT_VALIDATE_TMD_ASSIGNMENT_TO_MFD;
    static final int INT_CREATE_AND_ACTIVATE_FD_FR = Enum.INT_CREATE_AND_ACTIVATE_FD_FR;
    static final int INT_DEACTIVATE_AND_DELETE_FD_FR = Enum.INT_DEACTIVATE_AND_DELETE_FD_FR;
    static final int INT_MODIFY_FD_FR = Enum.INT_MODIFY_FD_FR;
    static final int INT_ASSOCIATE_MF_DS_WITH_FLOW_DOMAIN = Enum.INT_ASSOCIATE_MF_DS_WITH_FLOW_DOMAIN;
    static final int INT_DE_ASSOCIATE_MF_DS_FROM_FLOW_DOMAIN = Enum.INT_DE_ASSOCIATE_MF_DS_FROM_FLOW_DOMAIN;
    static final int INT_ASSOCIATE_CPT_PS_WITH_FLOW_DOMAIN = Enum.INT_ASSOCIATE_CPT_PS_WITH_FLOW_DOMAIN;
    static final int INT_DE_ASSOCIATE_CPT_PS_FROM_FLOW_DOMAIN = Enum.INT_DE_ASSOCIATE_CPT_PS_FROM_FLOW_DOMAIN;
    static final int INT_ADD_F_PS_TO_FD_FR = Enum.INT_ADD_F_PS_TO_FD_FR;
    static final int INT_REMOVE_F_PS_FROM_FD_FR = Enum.INT_REMOVE_F_PS_FROM_FD_FR;
    static final int INT_CREATE_TP_POOL = Enum.INT_CREATE_TP_POOL;
    static final int INT_DELETE_TP_POOL = Enum.INT_DELETE_TP_POOL;
    static final int INT_MODIFY_TP_POOL = Enum.INT_MODIFY_TP_POOL;
    static final int INT_ASSIGN_CPT_PS_TO_MFD = Enum.INT_ASSIGN_CPT_PS_TO_MFD;
    static final int INT_UNASSIGN_CPT_PS_FROM_MFD = Enum.INT_UNASSIGN_CPT_PS_FROM_MFD;
    static final int INT_CREATE_GTP = Enum.INT_CREATE_GTP;
    static final int INT_DELETE_GTP = Enum.INT_DELETE_GTP;
    static final int INT_MODIFY_GTP = Enum.INT_MODIFY_GTP;
    static final int INT_CREATE_TCA_PARAMETER_PROFILE = Enum.INT_CREATE_TCA_PARAMETER_PROFILE;
    static final int INT_DELETE_TCA_PARAMETER_PROFILE = Enum.INT_DELETE_TCA_PARAMETER_PROFILE;
    static final int INT_SET_TCA_PARAMETER_PROFILE = Enum.INT_SET_TCA_PARAMETER_PROFILE;
    static final int INT_SET_TCA_PARAMETER_PROFILE_POINTER = Enum.INT_SET_TCA_PARAMETER_PROFILE_POINTER;
    static final int INT_CREATE_ASAP = Enum.INT_CREATE_ASAP;
    static final int INT_DELETE_ASAP = Enum.INT_DELETE_ASAP;
    static final int INT_ASSIGN_ASAP = Enum.INT_ASSIGN_ASAP;
    static final int INT_DEASSIGN_ASAP = Enum.INT_DEASSIGN_ASAP;
    static final int INT_ESTABLISH_CALL = Enum.INT_ESTABLISH_CALL;
    static final int INT_RELEASE_CALL = Enum.INT_RELEASE_CALL;
    
    /**
     * Enumeration value class for org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_PROVISION_EQUIPMENT
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_PROVISION_EQUIPMENT = 1;
        static final int INT_UNPROVISION_EQUIPMENT = 2;
        static final int INT_VERIFY_TMD_ASSIGNMENT = 3;
        static final int INT_CREATE_FTP = 4;
        static final int INT_DELETE_FTP = 5;
        static final int INT_SET_TP_DATA = 6;
        static final int INT_CREATE_SNC = 7;
        static final int INT_ACTIVATE_SNC = 8;
        static final int INT_CREATE_AND_ACTIVATE_SNC = 9;
        static final int INT_DEACTIVATE_SNC = 10;
        static final int INT_DELETE_SNC = 11;
        static final int INT_DEACTIVATE_AND_DELETE_SNC = 12;
        static final int INT_CHECK_VALID_SNC = 13;
        static final int INT_CREATE_MODIFIED_SNC = 14;
        static final int INT_MODIFY_SNC = 15;
        static final int INT_CREATE_TOPOLOGICAL_LINK = 16;
        static final int INT_DELETE_TOPOLOGICAL_LINK = 17;
        static final int INT_CREATE_TRANSMISSION_DESCRIPTOR = 18;
        static final int INT_DELETE_TRANSMISSION_DESCRIPTOR = 19;
        static final int INT_MODIFY_TRANSMISSION_DESCRIPTOR = 20;
        static final int INT_CREATE_FLOW_DOMAIN = 21;
        static final int INT_DELETE_FLOW_DOMAIN = 22;
        static final int INT_MODIFY_FLOW_DOMAIN = 23;
        static final int INT_CREATE_MFD = 24;
        static final int INT_DELETE_MFD = 25;
        static final int INT_MODIFY_MFD = 26;
        static final int INT_VALIDATE_TMD_ASSIGNMENT_TO_MFD = 27;
        static final int INT_CREATE_AND_ACTIVATE_FD_FR = 28;
        static final int INT_DEACTIVATE_AND_DELETE_FD_FR = 29;
        static final int INT_MODIFY_FD_FR = 30;
        static final int INT_ASSOCIATE_MF_DS_WITH_FLOW_DOMAIN = 31;
        static final int INT_DE_ASSOCIATE_MF_DS_FROM_FLOW_DOMAIN = 32;
        static final int INT_ASSOCIATE_CPT_PS_WITH_FLOW_DOMAIN = 33;
        static final int INT_DE_ASSOCIATE_CPT_PS_FROM_FLOW_DOMAIN = 34;
        static final int INT_ADD_F_PS_TO_FD_FR = 35;
        static final int INT_REMOVE_F_PS_FROM_FD_FR = 36;
        static final int INT_CREATE_FTP_2 = 37;
        static final int INT_DELETE_FTP_2 = 38;
        static final int INT_CREATE_TP_POOL = 39;
        static final int INT_DELETE_TP_POOL = 40;
        static final int INT_MODIFY_TP_POOL = 41;
        static final int INT_ASSIGN_CPT_PS_TO_MFD = 42;
        static final int INT_UNASSIGN_CPT_PS_FROM_MFD = 43;
        static final int INT_CREATE_GTP = 44;
        static final int INT_DELETE_GTP = 45;
        static final int INT_MODIFY_GTP = 46;
        static final int INT_CREATE_TCA_PARAMETER_PROFILE = 47;
        static final int INT_DELETE_TCA_PARAMETER_PROFILE = 48;
        static final int INT_SET_TCA_PARAMETER_PROFILE = 49;
        static final int INT_SET_TCA_PARAMETER_PROFILE_POINTER = 50;
        static final int INT_CREATE_ASAP = 51;
        static final int INT_DELETE_ASAP = 52;
        static final int INT_ASSIGN_ASAP = 53;
        static final int INT_DEASSIGN_ASAP = 54;
        static final int INT_ESTABLISH_CALL = 55;
        static final int INT_RELEASE_CALL = 56;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("provisionEquipment", INT_PROVISION_EQUIPMENT),
                new Enum("unprovisionEquipment", INT_UNPROVISION_EQUIPMENT),
                new Enum("verifyTMDAssignment", INT_VERIFY_TMD_ASSIGNMENT),
                new Enum("createFTP", INT_CREATE_FTP),
                new Enum("deleteFTP", INT_DELETE_FTP),
                new Enum("setTPData", INT_SET_TP_DATA),
                new Enum("createSNC", INT_CREATE_SNC),
                new Enum("activateSNC", INT_ACTIVATE_SNC),
                new Enum("createAndActivateSNC", INT_CREATE_AND_ACTIVATE_SNC),
                new Enum("deactivateSNC", INT_DEACTIVATE_SNC),
                new Enum("deleteSNC", INT_DELETE_SNC),
                new Enum("deactivateAndDeleteSNC", INT_DEACTIVATE_AND_DELETE_SNC),
                new Enum("checkValidSNC", INT_CHECK_VALID_SNC),
                new Enum("createModifiedSNC", INT_CREATE_MODIFIED_SNC),
                new Enum("modifySNC", INT_MODIFY_SNC),
                new Enum("createTopologicalLink", INT_CREATE_TOPOLOGICAL_LINK),
                new Enum("deleteTopologicalLink", INT_DELETE_TOPOLOGICAL_LINK),
                new Enum("createTransmissionDescriptor", INT_CREATE_TRANSMISSION_DESCRIPTOR),
                new Enum("deleteTransmissionDescriptor", INT_DELETE_TRANSMISSION_DESCRIPTOR),
                new Enum("modifyTransmissionDescriptor", INT_MODIFY_TRANSMISSION_DESCRIPTOR),
                new Enum("createFlowDomain", INT_CREATE_FLOW_DOMAIN),
                new Enum("deleteFlowDomain", INT_DELETE_FLOW_DOMAIN),
                new Enum("modifyFlowDomain", INT_MODIFY_FLOW_DOMAIN),
                new Enum("createMFD", INT_CREATE_MFD),
                new Enum("deleteMFD", INT_DELETE_MFD),
                new Enum("modifyMFD", INT_MODIFY_MFD),
                new Enum("validateTMDAssignmentToMFD", INT_VALIDATE_TMD_ASSIGNMENT_TO_MFD),
                new Enum("createAndActivateFDFr", INT_CREATE_AND_ACTIVATE_FD_FR),
                new Enum("deactivateAndDeleteFDFr", INT_DEACTIVATE_AND_DELETE_FD_FR),
                new Enum("modifyFDFr", INT_MODIFY_FD_FR),
                new Enum("associateMFDsWithFlowDomain", INT_ASSOCIATE_MF_DS_WITH_FLOW_DOMAIN),
                new Enum("deAssociateMFDsFromFlowDomain", INT_DE_ASSOCIATE_MF_DS_FROM_FLOW_DOMAIN),
                new Enum("associateCPTPsWithFlowDomain", INT_ASSOCIATE_CPT_PS_WITH_FLOW_DOMAIN),
                new Enum("deAssociateCPTPsFromFlowDomain", INT_DE_ASSOCIATE_CPT_PS_FROM_FLOW_DOMAIN),
                new Enum("addFPsToFDFr", INT_ADD_F_PS_TO_FD_FR),
                new Enum("removeFPsFromFDFr", INT_REMOVE_F_PS_FROM_FD_FR),
                new Enum("createFTP", INT_CREATE_FTP_2),
                new Enum("deleteFTP", INT_DELETE_FTP_2),
                new Enum("createTPPool", INT_CREATE_TP_POOL),
                new Enum("deleteTPPool", INT_DELETE_TP_POOL),
                new Enum("modifyTPPool", INT_MODIFY_TP_POOL),
                new Enum("assignCPTPsToMFD", INT_ASSIGN_CPT_PS_TO_MFD),
                new Enum("unassignCPTPsFromMFD", INT_UNASSIGN_CPT_PS_FROM_MFD),
                new Enum("createGTP", INT_CREATE_GTP),
                new Enum("deleteGTP", INT_DELETE_GTP),
                new Enum("modifyGTP", INT_MODIFY_GTP),
                new Enum("createTCAParameterProfile", INT_CREATE_TCA_PARAMETER_PROFILE),
                new Enum("deleteTCAParameterProfile", INT_DELETE_TCA_PARAMETER_PROFILE),
                new Enum("setTCAParameterProfile", INT_SET_TCA_PARAMETER_PROFILE),
                new Enum("setTCAParameterProfilePointer", INT_SET_TCA_PARAMETER_PROFILE_POINTER),
                new Enum("createASAP", INT_CREATE_ASAP),
                new Enum("deleteASAP", INT_DELETE_ASAP),
                new Enum("assignASAP", INT_ASSIGN_ASAP),
                new Enum("deassignASAP", INT_DEASSIGN_ASAP),
                new Enum("establishCall", INT_ESTABLISH_CALL),
                new Enum("releaseCall", INT_RELEASE_CALL),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType newValue(java.lang.Object obj) {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) type.newValue( obj ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType newInstance() {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.mart.v1.OperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
