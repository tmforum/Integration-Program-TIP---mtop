/*
 * An XML document type.
 * Localname: attributeValueChange
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/avc/v1
 * Java type: org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.avc.v1.impl;
/**
 * A document containing one attributeValueChange(@http://www.tmforum.org/mtop/fmw/xsd/avc/v1) element.
 *
 * This is a complex type.
 */
public class AttributeValueChangeDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeDocument
{
    
    public AttributeValueChangeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ATTRIBUTEVALUECHANGE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/avc/v1", "attributeValueChange");
    
    
    /**
     * Gets the "attributeValueChange" element
     */
    public org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType getAttributeValueChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType)get_store().find_element_user(ATTRIBUTEVALUECHANGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "attributeValueChange" element
     */
    public void setAttributeValueChange(org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType attributeValueChange)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType)get_store().find_element_user(ATTRIBUTEVALUECHANGE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType)get_store().add_element_user(ATTRIBUTEVALUECHANGE$0);
            }
            target.set(attributeValueChange);
        }
    }
    
    /**
     * Appends and returns a new empty "attributeValueChange" element
     */
    public org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType addNewAttributeValueChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.avc.v1.AttributeValueChangeType)get_store().add_element_user(ATTRIBUTEVALUECHANGE$0);
            return target;
        }
    }
}
