/*
 * An XML document type.
 * Localname: setOwnerResponse
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setOwnerResponse(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetOwnerResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument
{
    
    public SetOwnerResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETOWNERRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setOwnerResponse");
    
    
    /**
     * Gets the "setOwnerResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse getSetOwnerResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse)get_store().find_element_user(SETOWNERRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setOwnerResponse" element
     */
    public void setSetOwnerResponse(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse setOwnerResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse)get_store().find_element_user(SETOWNERRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse)get_store().add_element_user(SETOWNERRESPONSE$0);
            }
            target.set(setOwnerResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setOwnerResponse" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse addNewSetOwnerResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse)get_store().add_element_user(SETOWNERRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setOwnerResponse(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetOwnerResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetOwnerResponseDocument.SetOwnerResponse
    {
        
        public SetOwnerResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
