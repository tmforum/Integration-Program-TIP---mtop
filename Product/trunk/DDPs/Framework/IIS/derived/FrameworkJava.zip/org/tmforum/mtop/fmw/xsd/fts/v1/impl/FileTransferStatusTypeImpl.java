/*
 * XML Type:  FileTransferStatusType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/fts/v1
 * Java type: org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.fts.v1.impl;
/**
 * An XML FileTransferStatusType(@http://www.tmforum.org/mtop/fmw/xsd/fts/v1).
 *
 * This is a complex type.
 */
public class FileTransferStatusTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoTypeImpl implements org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusType
{
    
    public FileTransferStatusTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FILENAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/fts/v1", "fileName");
    private static final javax.xml.namespace.QName TRANSFERSTATUS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/fts/v1", "transferStatus");
    private static final javax.xml.namespace.QName PERCENTCOMPLETE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/fts/v1", "percentComplete");
    private static final javax.xml.namespace.QName FAILUREREASON$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/fts/v1", "failureReason");
    
    
    /**
     * Gets the "fileName" element
     */
    public java.lang.String getFileName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FILENAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "fileName" element
     */
    public org.apache.xmlbeans.XmlString xgetFileName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FILENAME$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "fileName" element
     */
    public boolean isSetFileName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FILENAME$0) != 0;
        }
    }
    
    /**
     * Sets the "fileName" element
     */
    public void setFileName(java.lang.String fileName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FILENAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FILENAME$0);
            }
            target.setStringValue(fileName);
        }
    }
    
    /**
     * Sets (as xml) the "fileName" element
     */
    public void xsetFileName(org.apache.xmlbeans.XmlString fileName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FILENAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FILENAME$0);
            }
            target.set(fileName);
        }
    }
    
    /**
     * Unsets the "fileName" element
     */
    public void unsetFileName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FILENAME$0, 0);
        }
    }
    
    /**
     * Gets the "transferStatus" element
     */
    public org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType.Enum getTransferStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRANSFERSTATUS$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "transferStatus" element
     */
    public org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType xgetTransferStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType target = null;
            target = (org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType)get_store().find_element_user(TRANSFERSTATUS$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "transferStatus" element
     */
    public boolean isSetTransferStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRANSFERSTATUS$2) != 0;
        }
    }
    
    /**
     * Sets the "transferStatus" element
     */
    public void setTransferStatus(org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType.Enum transferStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRANSFERSTATUS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TRANSFERSTATUS$2);
            }
            target.setEnumValue(transferStatus);
        }
    }
    
    /**
     * Sets (as xml) the "transferStatus" element
     */
    public void xsetTransferStatus(org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType transferStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType target = null;
            target = (org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType)get_store().find_element_user(TRANSFERSTATUS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.fts.v1.FileTransferStatusEnumType)get_store().add_element_user(TRANSFERSTATUS$2);
            }
            target.set(transferStatus);
        }
    }
    
    /**
     * Unsets the "transferStatus" element
     */
    public void unsetTransferStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRANSFERSTATUS$2, 0);
        }
    }
    
    /**
     * Gets the "percentComplete" element
     */
    public long getPercentComplete()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCENTCOMPLETE$4, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "percentComplete" element
     */
    public org.apache.xmlbeans.XmlUnsignedInt xgetPercentComplete()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PERCENTCOMPLETE$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "percentComplete" element
     */
    public boolean isSetPercentComplete()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PERCENTCOMPLETE$4) != 0;
        }
    }
    
    /**
     * Sets the "percentComplete" element
     */
    public void setPercentComplete(long percentComplete)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCENTCOMPLETE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PERCENTCOMPLETE$4);
            }
            target.setLongValue(percentComplete);
        }
    }
    
    /**
     * Sets (as xml) the "percentComplete" element
     */
    public void xsetPercentComplete(org.apache.xmlbeans.XmlUnsignedInt percentComplete)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlUnsignedInt target = null;
            target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(PERCENTCOMPLETE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(PERCENTCOMPLETE$4);
            }
            target.set(percentComplete);
        }
    }
    
    /**
     * Unsets the "percentComplete" element
     */
    public void unsetPercentComplete()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PERCENTCOMPLETE$4, 0);
        }
    }
    
    /**
     * Gets the "failureReason" element
     */
    public java.lang.String getFailureReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILUREREASON$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "failureReason" element
     */
    public org.apache.xmlbeans.XmlString xgetFailureReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FAILUREREASON$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "failureReason" element
     */
    public boolean isSetFailureReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FAILUREREASON$6) != 0;
        }
    }
    
    /**
     * Sets the "failureReason" element
     */
    public void setFailureReason(java.lang.String failureReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILUREREASON$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FAILUREREASON$6);
            }
            target.setStringValue(failureReason);
        }
    }
    
    /**
     * Sets (as xml) the "failureReason" element
     */
    public void xsetFailureReason(org.apache.xmlbeans.XmlString failureReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FAILUREREASON$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FAILUREREASON$6);
            }
            target.set(failureReason);
        }
    }
    
    /**
     * Unsets the "failureReason" element
     */
    public void unsetFailureReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FAILUREREASON$6, 0);
        }
    }
}
