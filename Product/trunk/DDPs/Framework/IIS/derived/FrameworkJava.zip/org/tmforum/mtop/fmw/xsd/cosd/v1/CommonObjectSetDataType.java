/*
 * XML Type:  CommonObjectSetDataType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cosd/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cosd.v1;


/**
 * An XML CommonObjectSetDataType(@http://www.tmforum.org/mtop/fmw/xsd/cosd/v1).
 *
 * This is a complex type.
 */
public interface CommonObjectSetDataType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CommonObjectSetDataType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s847FF0AD3261530B646FDA7C8CDE68B2").resolveHandle("commonobjectsetdatatype06eetype");
    
    /**
     * Gets the "userLabel" element
     */
    java.lang.String getUserLabel();
    
    /**
     * Gets (as xml) the "userLabel" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType xgetUserLabel();
    
    /**
     * Tests for nil "userLabel" element
     */
    boolean isNilUserLabel();
    
    /**
     * True if has "userLabel" element
     */
    boolean isSetUserLabel();
    
    /**
     * Sets the "userLabel" element
     */
    void setUserLabel(java.lang.String userLabel);
    
    /**
     * Sets (as xml) the "userLabel" element
     */
    void xsetUserLabel(org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType userLabel);
    
    /**
     * Nils the "userLabel" element
     */
    void setNilUserLabel();
    
    /**
     * Unsets the "userLabel" element
     */
    void unsetUserLabel();
    
    /**
     * Gets the "forceUniqueness" element
     */
    boolean getForceUniqueness();
    
    /**
     * Gets (as xml) the "forceUniqueness" element
     */
    org.apache.xmlbeans.XmlBoolean xgetForceUniqueness();
    
    /**
     * Tests for nil "forceUniqueness" element
     */
    boolean isNilForceUniqueness();
    
    /**
     * True if has "forceUniqueness" element
     */
    boolean isSetForceUniqueness();
    
    /**
     * Sets the "forceUniqueness" element
     */
    void setForceUniqueness(boolean forceUniqueness);
    
    /**
     * Sets (as xml) the "forceUniqueness" element
     */
    void xsetForceUniqueness(org.apache.xmlbeans.XmlBoolean forceUniqueness);
    
    /**
     * Nils the "forceUniqueness" element
     */
    void setNilForceUniqueness();
    
    /**
     * Unsets the "forceUniqueness" element
     */
    void unsetForceUniqueness();
    
    /**
     * Gets the "owner" element
     */
    java.lang.String getOwner();
    
    /**
     * Gets (as xml) the "owner" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType xgetOwner();
    
    /**
     * Tests for nil "owner" element
     */
    boolean isNilOwner();
    
    /**
     * True if has "owner" element
     */
    boolean isSetOwner();
    
    /**
     * Sets the "owner" element
     */
    void setOwner(java.lang.String owner);
    
    /**
     * Sets (as xml) the "owner" element
     */
    void xsetOwner(org.tmforum.mtop.fmw.xsd.gen.v1.OwnerType owner);
    
    /**
     * Nils the "owner" element
     */
    void setNilOwner();
    
    /**
     * Unsets the "owner" element
     */
    void unsetOwner();
    
    /**
     * Gets the "aliasNameList" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNameList();
    
    /**
     * Tests for nil "aliasNameList" element
     */
    boolean isNilAliasNameList();
    
    /**
     * True if has "aliasNameList" element
     */
    boolean isSetAliasNameList();
    
    /**
     * Sets the "aliasNameList" element
     */
    void setAliasNameList(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNameList);
    
    /**
     * Appends and returns a new empty "aliasNameList" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNameList();
    
    /**
     * Nils the "aliasNameList" element
     */
    void setNilAliasNameList();
    
    /**
     * Unsets the "aliasNameList" element
     */
    void unsetAliasNameList();
    
    /**
     * Gets the "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
    
    /**
     * Tests for nil "vendorExtensions" element
     */
    boolean isNilVendorExtensions();
    
    /**
     * True if has "vendorExtensions" element
     */
    boolean isSetVendorExtensions();
    
    /**
     * Sets the "vendorExtensions" element
     */
    void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
    
    /**
     * Nils the "vendorExtensions" element
     */
    void setNilVendorExtensions();
    
    /**
     * Unsets the "vendorExtensions" element
     */
    void unsetVendorExtensions();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        /** @deprecated No need to be able to create instances of abstract types */
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType newInstance() {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        /** @deprecated No need to be able to create instances of abstract types */
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.cosd.v1.CommonObjectSetDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
