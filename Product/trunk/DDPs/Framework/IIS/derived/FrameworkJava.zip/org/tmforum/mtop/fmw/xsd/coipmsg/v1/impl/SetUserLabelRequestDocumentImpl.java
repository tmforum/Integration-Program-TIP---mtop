/*
 * An XML document type.
 * Localname: setUserLabelRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setUserLabelRequest(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetUserLabelRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument
{
    
    public SetUserLabelRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETUSERLABELREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setUserLabelRequest");
    
    
    /**
     * Gets the "setUserLabelRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest getSetUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest)get_store().find_element_user(SETUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setUserLabelRequest" element
     */
    public void setSetUserLabelRequest(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest setUserLabelRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest)get_store().find_element_user(SETUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest)get_store().add_element_user(SETUSERLABELREQUEST$0);
            }
            target.set(setUserLabelRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setUserLabelRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest addNewSetUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest)get_store().add_element_user(SETUSERLABELREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setUserLabelRequest(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetUserLabelRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetUserLabelRequestDocument.SetUserLabelRequest
    {
        
        public SetUserLabelRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OBJECTNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "objectName");
        private static final javax.xml.namespace.QName USERLABEL$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "userLabel");
        private static final javax.xml.namespace.QName ENFORCEUNIQUENESS$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "enforceUniqueness");
        
        
        /**
         * Gets the "objectName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "objectName" element
         */
        public boolean isSetObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OBJECTNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "objectName" element
         */
        public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
                }
                target.set(objectName);
            }
        }
        
        /**
         * Appends and returns a new empty "objectName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "objectName" element
         */
        public void unsetObjectName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OBJECTNAME$0, 0);
            }
        }
        
        /**
         * Gets the "userLabel" element
         */
        public java.lang.String getUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "userLabel" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType xgetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$2, 0);
                return target;
            }
        }
        
        /**
         * True if has "userLabel" element
         */
        public boolean isSetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(USERLABEL$2) != 0;
            }
        }
        
        /**
         * Sets the "userLabel" element
         */
        public void setUserLabel(java.lang.String userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERLABEL$2);
                }
                target.setStringValue(userLabel);
            }
        }
        
        /**
         * Sets (as xml) the "userLabel" element
         */
        public void xsetUserLabel(org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().add_element_user(USERLABEL$2);
                }
                target.set(userLabel);
            }
        }
        
        /**
         * Unsets the "userLabel" element
         */
        public void unsetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(USERLABEL$2, 0);
            }
        }
        
        /**
         * Gets the "enforceUniqueness" element
         */
        public boolean getEnforceUniqueness()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ENFORCEUNIQUENESS$4, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "enforceUniqueness" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetEnforceUniqueness()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ENFORCEUNIQUENESS$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "enforceUniqueness" element
         */
        public boolean isSetEnforceUniqueness()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ENFORCEUNIQUENESS$4) != 0;
            }
        }
        
        /**
         * Sets the "enforceUniqueness" element
         */
        public void setEnforceUniqueness(boolean enforceUniqueness)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ENFORCEUNIQUENESS$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ENFORCEUNIQUENESS$4);
                }
                target.setBooleanValue(enforceUniqueness);
            }
        }
        
        /**
         * Sets (as xml) the "enforceUniqueness" element
         */
        public void xsetEnforceUniqueness(org.apache.xmlbeans.XmlBoolean enforceUniqueness)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ENFORCEUNIQUENESS$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ENFORCEUNIQUENESS$4);
                }
                target.set(enforceUniqueness);
            }
        }
        
        /**
         * Unsets the "enforceUniqueness" element
         */
        public void unsetEnforceUniqueness()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ENFORCEUNIQUENESS$4, 0);
            }
        }
    }
}
