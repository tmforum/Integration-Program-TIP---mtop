/*
 * An XML document type.
 * Localname: header
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/hdr/v1
 * Java type: org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.hdr.v1;


/**
 * A document containing one header(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1) element.
 *
 * This is a complex type.
 */
public interface HeaderDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(HeaderDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sDDAC7565F6271814B423C17ADF79C595").resolveHandle("headerb580doctype");
    
    /**
     * Gets the "header" element
     */
    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header getHeader();
    
    /**
     * Sets the "header" element
     */
    void setHeader(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header header);
    
    /**
     * Appends and returns a new empty "header" element
     */
    org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header addNewHeader();
    
    /**
     * An XML header(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
     *
     * This is a complex type.
     */
    public interface Header extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Header.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sDDAC7565F6271814B423C17ADF79C595").resolveHandle("headerbc29elemtype");
        
        /**
         * Gets the "activityName" element
         */
        java.lang.String getActivityName();
        
        /**
         * Gets (as xml) the "activityName" element
         */
        org.apache.xmlbeans.XmlString xgetActivityName();
        
        /**
         * True if has "activityName" element
         */
        boolean isSetActivityName();
        
        /**
         * Sets the "activityName" element
         */
        void setActivityName(java.lang.String activityName);
        
        /**
         * Sets (as xml) the "activityName" element
         */
        void xsetActivityName(org.apache.xmlbeans.XmlString activityName);
        
        /**
         * Unsets the "activityName" element
         */
        void unsetActivityName();
        
        /**
         * Gets the "msgName" element
         */
        java.lang.String getMsgName();
        
        /**
         * Gets (as xml) the "msgName" element
         */
        org.apache.xmlbeans.XmlString xgetMsgName();
        
        /**
         * True if has "msgName" element
         */
        boolean isSetMsgName();
        
        /**
         * Sets the "msgName" element
         */
        void setMsgName(java.lang.String msgName);
        
        /**
         * Sets (as xml) the "msgName" element
         */
        void xsetMsgName(org.apache.xmlbeans.XmlString msgName);
        
        /**
         * Unsets the "msgName" element
         */
        void unsetMsgName();
        
        /**
         * Gets the "msgType" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType.Enum getMsgType();
        
        /**
         * Gets (as xml) the "msgType" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType xgetMsgType();
        
        /**
         * True if has "msgType" element
         */
        boolean isSetMsgType();
        
        /**
         * Sets the "msgType" element
         */
        void setMsgType(org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType.Enum msgType);
        
        /**
         * Sets (as xml) the "msgType" element
         */
        void xsetMsgType(org.tmforum.mtop.fmw.xsd.hdr.v1.MsgTypeType msgType);
        
        /**
         * Unsets the "msgType" element
         */
        void unsetMsgType();
        
        /**
         * Gets the "senderURI" element
         */
        java.lang.String getSenderURI();
        
        /**
         * Gets (as xml) the "senderURI" element
         */
        org.apache.xmlbeans.XmlAnyURI xgetSenderURI();
        
        /**
         * True if has "senderURI" element
         */
        boolean isSetSenderURI();
        
        /**
         * Sets the "senderURI" element
         */
        void setSenderURI(java.lang.String senderURI);
        
        /**
         * Sets (as xml) the "senderURI" element
         */
        void xsetSenderURI(org.apache.xmlbeans.XmlAnyURI senderURI);
        
        /**
         * Unsets the "senderURI" element
         */
        void unsetSenderURI();
        
        /**
         * Gets the "destinationURI" element
         */
        java.lang.String getDestinationURI();
        
        /**
         * Gets (as xml) the "destinationURI" element
         */
        org.apache.xmlbeans.XmlAnyURI xgetDestinationURI();
        
        /**
         * True if has "destinationURI" element
         */
        boolean isSetDestinationURI();
        
        /**
         * Sets the "destinationURI" element
         */
        void setDestinationURI(java.lang.String destinationURI);
        
        /**
         * Sets (as xml) the "destinationURI" element
         */
        void xsetDestinationURI(org.apache.xmlbeans.XmlAnyURI destinationURI);
        
        /**
         * Unsets the "destinationURI" element
         */
        void unsetDestinationURI();
        
        /**
         * Gets the "replyToURI" element
         */
        java.lang.String getReplyToURI();
        
        /**
         * Gets (as xml) the "replyToURI" element
         */
        org.apache.xmlbeans.XmlAnyURI xgetReplyToURI();
        
        /**
         * True if has "replyToURI" element
         */
        boolean isSetReplyToURI();
        
        /**
         * Sets the "replyToURI" element
         */
        void setReplyToURI(java.lang.String replyToURI);
        
        /**
         * Sets (as xml) the "replyToURI" element
         */
        void xsetReplyToURI(org.apache.xmlbeans.XmlAnyURI replyToURI);
        
        /**
         * Unsets the "replyToURI" element
         */
        void unsetReplyToURI();
        
        /**
         * Gets the "originatorURI" element
         */
        java.lang.String getOriginatorURI();
        
        /**
         * Gets (as xml) the "originatorURI" element
         */
        org.apache.xmlbeans.XmlAnyURI xgetOriginatorURI();
        
        /**
         * True if has "originatorURI" element
         */
        boolean isSetOriginatorURI();
        
        /**
         * Sets the "originatorURI" element
         */
        void setOriginatorURI(java.lang.String originatorURI);
        
        /**
         * Sets (as xml) the "originatorURI" element
         */
        void xsetOriginatorURI(org.apache.xmlbeans.XmlAnyURI originatorURI);
        
        /**
         * Unsets the "originatorURI" element
         */
        void unsetOriginatorURI();
        
        /**
         * Gets the "failureReplytoURI" element
         */
        java.lang.String getFailureReplytoURI();
        
        /**
         * Gets (as xml) the "failureReplytoURI" element
         */
        org.apache.xmlbeans.XmlAnyURI xgetFailureReplytoURI();
        
        /**
         * True if has "failureReplytoURI" element
         */
        boolean isSetFailureReplytoURI();
        
        /**
         * Sets the "failureReplytoURI" element
         */
        void setFailureReplytoURI(java.lang.String failureReplytoURI);
        
        /**
         * Sets (as xml) the "failureReplytoURI" element
         */
        void xsetFailureReplytoURI(org.apache.xmlbeans.XmlAnyURI failureReplytoURI);
        
        /**
         * Unsets the "failureReplytoURI" element
         */
        void unsetFailureReplytoURI();
        
        /**
         * Gets the "activityStatus" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType getActivityStatus();
        
        /**
         * True if has "activityStatus" element
         */
        boolean isSetActivityStatus();
        
        /**
         * Sets the "activityStatus" element
         */
        void setActivityStatus(org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType activityStatus);
        
        /**
         * Appends and returns a new empty "activityStatus" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.ActivityStatusType addNewActivityStatus();
        
        /**
         * Unsets the "activityStatus" element
         */
        void unsetActivityStatus();
        
        /**
         * Gets the "correlationId" element
         */
        java.lang.String getCorrelationId();
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        org.apache.xmlbeans.XmlString xgetCorrelationId();
        
        /**
         * True if has "correlationId" element
         */
        boolean isSetCorrelationId();
        
        /**
         * Sets the "correlationId" element
         */
        void setCorrelationId(java.lang.String correlationId);
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId);
        
        /**
         * Unsets the "correlationId" element
         */
        void unsetCorrelationId();
        
        /**
         * Gets the "security" element
         */
        java.lang.String getSecurity();
        
        /**
         * Gets (as xml) the "security" element
         */
        org.apache.xmlbeans.XmlString xgetSecurity();
        
        /**
         * True if has "security" element
         */
        boolean isSetSecurity();
        
        /**
         * Sets the "security" element
         */
        void setSecurity(java.lang.String security);
        
        /**
         * Sets (as xml) the "security" element
         */
        void xsetSecurity(org.apache.xmlbeans.XmlString security);
        
        /**
         * Unsets the "security" element
         */
        void unsetSecurity();
        
        /**
         * Gets the "securityType" element
         */
        java.lang.String getSecurityType();
        
        /**
         * Gets (as xml) the "securityType" element
         */
        org.apache.xmlbeans.XmlString xgetSecurityType();
        
        /**
         * True if has "securityType" element
         */
        boolean isSetSecurityType();
        
        /**
         * Sets the "securityType" element
         */
        void setSecurityType(java.lang.String securityType);
        
        /**
         * Sets (as xml) the "securityType" element
         */
        void xsetSecurityType(org.apache.xmlbeans.XmlString securityType);
        
        /**
         * Unsets the "securityType" element
         */
        void unsetSecurityType();
        
        /**
         * Gets the "priority" element
         */
        java.lang.String getPriority();
        
        /**
         * Gets (as xml) the "priority" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority xgetPriority();
        
        /**
         * True if has "priority" element
         */
        boolean isSetPriority();
        
        /**
         * Sets the "priority" element
         */
        void setPriority(java.lang.String priority);
        
        /**
         * Sets (as xml) the "priority" element
         */
        void xsetPriority(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority priority);
        
        /**
         * Unsets the "priority" element
         */
        void unsetPriority();
        
        /**
         * Gets the "msgSpecificProperties" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties getMsgSpecificProperties();
        
        /**
         * True if has "msgSpecificProperties" element
         */
        boolean isSetMsgSpecificProperties();
        
        /**
         * Sets the "msgSpecificProperties" element
         */
        void setMsgSpecificProperties(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties msgSpecificProperties);
        
        /**
         * Appends and returns a new empty "msgSpecificProperties" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties addNewMsgSpecificProperties();
        
        /**
         * Unsets the "msgSpecificProperties" element
         */
        void unsetMsgSpecificProperties();
        
        /**
         * Gets the "communicationPattern" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType.Enum getCommunicationPattern();
        
        /**
         * Gets (as xml) the "communicationPattern" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType xgetCommunicationPattern();
        
        /**
         * True if has "communicationPattern" element
         */
        boolean isSetCommunicationPattern();
        
        /**
         * Sets the "communicationPattern" element
         */
        void setCommunicationPattern(org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType.Enum communicationPattern);
        
        /**
         * Sets (as xml) the "communicationPattern" element
         */
        void xsetCommunicationPattern(org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationPatternType communicationPattern);
        
        /**
         * Unsets the "communicationPattern" element
         */
        void unsetCommunicationPattern();
        
        /**
         * Gets the "communicationStyle" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType.Enum getCommunicationStyle();
        
        /**
         * Gets (as xml) the "communicationStyle" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType xgetCommunicationStyle();
        
        /**
         * True if has "communicationStyle" element
         */
        boolean isSetCommunicationStyle();
        
        /**
         * Sets the "communicationStyle" element
         */
        void setCommunicationStyle(org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType.Enum communicationStyle);
        
        /**
         * Sets (as xml) the "communicationStyle" element
         */
        void xsetCommunicationStyle(org.tmforum.mtop.fmw.xsd.hdr.v1.CommunicationStyleType communicationStyle);
        
        /**
         * Unsets the "communicationStyle" element
         */
        void unsetCommunicationStyle();
        
        /**
         * Gets the "requestedBatchSize" element
         */
        long getRequestedBatchSize();
        
        /**
         * Gets (as xml) the "requestedBatchSize" element
         */
        org.apache.xmlbeans.XmlUnsignedInt xgetRequestedBatchSize();
        
        /**
         * True if has "requestedBatchSize" element
         */
        boolean isSetRequestedBatchSize();
        
        /**
         * Sets the "requestedBatchSize" element
         */
        void setRequestedBatchSize(long requestedBatchSize);
        
        /**
         * Sets (as xml) the "requestedBatchSize" element
         */
        void xsetRequestedBatchSize(org.apache.xmlbeans.XmlUnsignedInt requestedBatchSize);
        
        /**
         * Unsets the "requestedBatchSize" element
         */
        void unsetRequestedBatchSize();
        
        /**
         * Gets the "batchSequenceNumber" element
         */
        long getBatchSequenceNumber();
        
        /**
         * Gets (as xml) the "batchSequenceNumber" element
         */
        org.apache.xmlbeans.XmlUnsignedInt xgetBatchSequenceNumber();
        
        /**
         * True if has "batchSequenceNumber" element
         */
        boolean isSetBatchSequenceNumber();
        
        /**
         * Sets the "batchSequenceNumber" element
         */
        void setBatchSequenceNumber(long batchSequenceNumber);
        
        /**
         * Sets (as xml) the "batchSequenceNumber" element
         */
        void xsetBatchSequenceNumber(org.apache.xmlbeans.XmlUnsignedInt batchSequenceNumber);
        
        /**
         * Unsets the "batchSequenceNumber" element
         */
        void unsetBatchSequenceNumber();
        
        /**
         * Gets the "batchSequenceEndOfReply" element
         */
        boolean getBatchSequenceEndOfReply();
        
        /**
         * Gets (as xml) the "batchSequenceEndOfReply" element
         */
        org.apache.xmlbeans.XmlBoolean xgetBatchSequenceEndOfReply();
        
        /**
         * True if has "batchSequenceEndOfReply" element
         */
        boolean isSetBatchSequenceEndOfReply();
        
        /**
         * Sets the "batchSequenceEndOfReply" element
         */
        void setBatchSequenceEndOfReply(boolean batchSequenceEndOfReply);
        
        /**
         * Sets (as xml) the "batchSequenceEndOfReply" element
         */
        void xsetBatchSequenceEndOfReply(org.apache.xmlbeans.XmlBoolean batchSequenceEndOfReply);
        
        /**
         * Unsets the "batchSequenceEndOfReply" element
         */
        void unsetBatchSequenceEndOfReply();
        
        /**
         * Gets the "iteratorReferenceURI" element
         */
        java.lang.String getIteratorReferenceURI();
        
        /**
         * Gets (as xml) the "iteratorReferenceURI" element
         */
        org.apache.xmlbeans.XmlAnyURI xgetIteratorReferenceURI();
        
        /**
         * True if has "iteratorReferenceURI" element
         */
        boolean isSetIteratorReferenceURI();
        
        /**
         * Sets the "iteratorReferenceURI" element
         */
        void setIteratorReferenceURI(java.lang.String iteratorReferenceURI);
        
        /**
         * Sets (as xml) the "iteratorReferenceURI" element
         */
        void xsetIteratorReferenceURI(org.apache.xmlbeans.XmlAnyURI iteratorReferenceURI);
        
        /**
         * Unsets the "iteratorReferenceURI" element
         */
        void unsetIteratorReferenceURI();
        
        /**
         * Gets the "fileLocationURI" element
         */
        java.lang.String getFileLocationURI();
        
        /**
         * Gets (as xml) the "fileLocationURI" element
         */
        org.apache.xmlbeans.XmlAnyURI xgetFileLocationURI();
        
        /**
         * True if has "fileLocationURI" element
         */
        boolean isSetFileLocationURI();
        
        /**
         * Sets the "fileLocationURI" element
         */
        void setFileLocationURI(java.lang.String fileLocationURI);
        
        /**
         * Sets (as xml) the "fileLocationURI" element
         */
        void xsetFileLocationURI(org.apache.xmlbeans.XmlAnyURI fileLocationURI);
        
        /**
         * Unsets the "fileLocationURI" element
         */
        void unsetFileLocationURI();
        
        /**
         * Gets the "compressionType" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType getCompressionType();
        
        /**
         * True if has "compressionType" element
         */
        boolean isSetCompressionType();
        
        /**
         * Sets the "compressionType" element
         */
        void setCompressionType(org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType compressionType);
        
        /**
         * Appends and returns a new empty "compressionType" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.CompressionTypeType addNewCompressionType();
        
        /**
         * Unsets the "compressionType" element
         */
        void unsetCompressionType();
        
        /**
         * Gets the "packingType" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType getPackingType();
        
        /**
         * True if has "packingType" element
         */
        boolean isSetPackingType();
        
        /**
         * Sets the "packingType" element
         */
        void setPackingType(org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType packingType);
        
        /**
         * Appends and returns a new empty "packingType" element
         */
        org.tmforum.mtop.fmw.xsd.hdr.v1.PackingTypeType addNewPackingType();
        
        /**
         * Unsets the "packingType" element
         */
        void unsetPackingType();
        
        /**
         * Gets the "timestamp" element
         */
        java.util.Calendar getTimestamp();
        
        /**
         * Gets (as xml) the "timestamp" element
         */
        org.apache.xmlbeans.XmlDateTime xgetTimestamp();
        
        /**
         * True if has "timestamp" element
         */
        boolean isSetTimestamp();
        
        /**
         * Sets the "timestamp" element
         */
        void setTimestamp(java.util.Calendar timestamp);
        
        /**
         * Sets (as xml) the "timestamp" element
         */
        void xsetTimestamp(org.apache.xmlbeans.XmlDateTime timestamp);
        
        /**
         * Unsets the "timestamp" element
         */
        void unsetTimestamp();
        
        /**
         * Gets the "vendorExtensions" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
        
        /**
         * True if has "vendorExtensions" element
         */
        boolean isSetVendorExtensions();
        
        /**
         * Sets the "vendorExtensions" element
         */
        void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
        
        /**
         * Unsets the "vendorExtensions" element
         */
        void unsetVendorExtensions();
        
        /**
         * An XML priority(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
         *
         * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument$Header$Priority.
         */
        public interface Priority extends org.apache.xmlbeans.XmlString
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Priority.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sDDAC7565F6271814B423C17ADF79C595").resolveHandle("priority79e9elemtype");
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority newValue(java.lang.Object obj) {
                  return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority) type.newValue( obj ); }
                
                public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority newInstance() {
                  return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.Priority) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * An XML msgSpecificProperties(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
         *
         * This is a complex type.
         */
        public interface MsgSpecificProperties extends org.apache.xmlbeans.XmlObject
        {
            public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MsgSpecificProperties.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sDDAC7565F6271814B423C17ADF79C595").resolveHandle("msgspecificproperties0597elemtype");
            
            /**
             * Gets a List of "property" elements
             */
            java.util.List<org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property> getPropertyList();
            
            /**
             * Gets array of all "property" elements
             * @deprecated
             */
            org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property[] getPropertyArray();
            
            /**
             * Gets ith "property" element
             */
            org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property getPropertyArray(int i);
            
            /**
             * Returns number of "property" element
             */
            int sizeOfPropertyArray();
            
            /**
             * Sets array of all "property" element
             */
            void setPropertyArray(org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property[] propertyArray);
            
            /**
             * Sets ith "property" element
             */
            void setPropertyArray(int i, org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property property);
            
            /**
             * Inserts and returns a new empty value (as xml) as the ith "property" element
             */
            org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property insertNewProperty(int i);
            
            /**
             * Appends and returns a new empty value (as xml) as the last "property" element
             */
            org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property addNewProperty();
            
            /**
             * Removes the ith "property" element
             */
            void removeProperty(int i);
            
            /**
             * An XML property(@http://www.tmforum.org/mtop/fmw/xsd/hdr/v1).
             *
             * This is a complex type.
             */
            public interface Property extends org.apache.xmlbeans.XmlObject
            {
                public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
                    org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Property.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sDDAC7565F6271814B423C17ADF79C595").resolveHandle("property5fc6elemtype");
                
                /**
                 * Gets the "propName" element
                 */
                java.lang.String getPropName();
                
                /**
                 * Gets (as xml) the "propName" element
                 */
                org.apache.xmlbeans.XmlString xgetPropName();
                
                /**
                 * Sets the "propName" element
                 */
                void setPropName(java.lang.String propName);
                
                /**
                 * Sets (as xml) the "propName" element
                 */
                void xsetPropName(org.apache.xmlbeans.XmlString propName);
                
                /**
                 * Gets the "propValue" element
                 */
                java.lang.String getPropValue();
                
                /**
                 * Gets (as xml) the "propValue" element
                 */
                org.apache.xmlbeans.XmlString xgetPropValue();
                
                /**
                 * Sets the "propValue" element
                 */
                void setPropValue(java.lang.String propValue);
                
                /**
                 * Sets (as xml) the "propValue" element
                 */
                void xsetPropValue(org.apache.xmlbeans.XmlString propValue);
                
                /**
                 * A factory class with static methods for creating instances
                 * of this type.
                 */
                
                public static final class Factory
                {
                    public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property newInstance() {
                      return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                    
                    public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property newInstance(org.apache.xmlbeans.XmlOptions options) {
                      return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties.Property) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                    
                    private Factory() { } // No instance of this class allowed
                }
            }
            
            /**
             * A factory class with static methods for creating instances
             * of this type.
             */
            
            public static final class Factory
            {
                public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties newInstance() {
                  return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
                
                public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties newInstance(org.apache.xmlbeans.XmlOptions options) {
                  return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header.MsgSpecificProperties) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
                
                private Factory() { } // No instance of this class allowed
            }
        }
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header newInstance() {
              return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument.Header) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument newInstance() {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.hdr.v1.HeaderDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
