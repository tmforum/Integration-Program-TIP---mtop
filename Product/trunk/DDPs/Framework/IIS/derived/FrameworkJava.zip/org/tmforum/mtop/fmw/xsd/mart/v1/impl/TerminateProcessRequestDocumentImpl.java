/*
 * An XML document type.
 * Localname: terminateProcessRequest
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/mart/v1
 * Java type: org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.mart.v1.impl;
/**
 * A document containing one terminateProcessRequest(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1) element.
 *
 * This is a complex type.
 */
public class TerminateProcessRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument
{
    
    public TerminateProcessRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TERMINATEPROCESSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "terminateProcessRequest");
    
    
    /**
     * Gets the "terminateProcessRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest getTerminateProcessRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest)get_store().find_element_user(TERMINATEPROCESSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "terminateProcessRequest" element
     */
    public void setTerminateProcessRequest(org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest terminateProcessRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest)get_store().find_element_user(TERMINATEPROCESSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest)get_store().add_element_user(TERMINATEPROCESSREQUEST$0);
            }
            target.set(terminateProcessRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "terminateProcessRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest addNewTerminateProcessRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest target = null;
            target = (org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest)get_store().add_element_user(TERMINATEPROCESSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML terminateProcessRequest(@http://www.tmforum.org/mtop/fmw/xsd/mart/v1).
     *
     * This is a complex type.
     */
    public static class TerminateProcessRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.mart.v1.TerminateProcessRequestDocument.TerminateProcessRequest
    {
        
        public TerminateProcessRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CORRELATIONID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/mart/v1", "correlationId");
        
        
        /**
         * Gets the "correlationId" element
         */
        public java.lang.String getCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "correlationId" element
         */
        public org.apache.xmlbeans.XmlString xgetCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "correlationId" element
         */
        public boolean isNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * Sets the "correlationId" element
         */
        public void setCorrelationId(java.lang.String correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setStringValue(correlationId);
            }
        }
        
        /**
         * Sets (as xml) the "correlationId" element
         */
        public void xsetCorrelationId(org.apache.xmlbeans.XmlString correlationId)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.set(correlationId);
            }
        }
        
        /**
         * Nils the "correlationId" element
         */
        public void setNilCorrelationId()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CORRELATIONID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CORRELATIONID$0);
                }
                target.setNil();
            }
        }
    }
}
