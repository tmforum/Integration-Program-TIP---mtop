/*
 * An XML document type.
 * Localname: setAliasNamesException
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.coipmsg.v1.impl;
/**
 * A document containing one setAliasNamesException(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1) element.
 *
 * This is a complex type.
 */
public class SetAliasNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument
{
    
    public SetAliasNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALIASNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1", "setAliasNamesException");
    
    
    /**
     * Gets the "setAliasNamesException" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException getSetAliasNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException)get_store().find_element_user(SETALIASNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAliasNamesException" element
     */
    public void setSetAliasNamesException(org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException setAliasNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException)get_store().find_element_user(SETALIASNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException)get_store().add_element_user(SETALIASNAMESEXCEPTION$0);
            }
            target.set(setAliasNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "setAliasNamesException" element
     */
    public org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException addNewSetAliasNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException target = null;
            target = (org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException)get_store().add_element_user(SETALIASNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setAliasNamesException(@http://www.tmforum.org/mtop/fmw/xsd/coipmsg/v1).
     *
     * This is a complex type.
     */
    public static class SetAliasNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.fmw.xsd.coipmsg.v1.SetAliasNamesExceptionDocument.SetAliasNamesException
    {
        
        public SetAliasNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
