﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_ciFileName = "componentIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function CN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function C (attributeList, attributeGroupList,
						simpleTypeList, complexTypeList,
						modelGroupList, elementList, 
						notationList) 
{
	this.attributes = attributeList;
	this.attributegroups = attributeGroupList;
	this.simpletypes = simpleTypeList;
	this.complextypes = complexTypeList;
	this.modelgroups = modelGroupList;
	this.elements = elementList;
	this.notations = notationList;
}

function component_showAllComponents() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_ciFileName;
}

function component_filterComponents () {
	parent._href = "xsd/" + xsd_ciFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function component_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href=xsd_ciFileName;	
}

function component_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in componentDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}

	parent._xsdNsFilter = nsList;
}

function component_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	component_outputList (null, components);	
}


function component_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		component_outputList (namespace, list);	
	}
}


function component_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		component_showComponentsNS (nsList, componentList)
	} else {
		component_showComponentsNoNS (nsList, componentList)
	}
}

function component_showAttributes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		attributes [i] = componentDB [nsList[i]].attributes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributes);
}

function component_showAttributeGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributegroups = new Array();
	var nss = new Array();		

	for (var i=0; i<nsList.length; i++) {
		attributegroups [i] = componentDB [nsList[i]].attributegroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributegroups);
}

function component_showSimpleTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var simpletypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		simpletypes [i] = componentDB [nsList[i]].simpletypes;	
		nss [i] = nsList[i];
	}		

	component_showComponents (nss, simpletypes);
}

function component_showComplexTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var complextypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		complextypes [i] = componentDB [nsList[i]].complextypes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, complextypes);
}

function component_showElements() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var elements = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		elements [i] = componentDB [nsList[i]].elements;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, elements);
}

function component_showModelGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var modelgroups = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		modelgroups [i] = componentDB [nsList[i]].modelgroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, modelgroups);
}

function component_showNotations() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var notations = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		notations [i] = componentDB [nsList[i]].notations;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, notations);

}


function component_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function component_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+component_getNodeText(node)+
			  '" target="'+target+'">'+component_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function component_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+component_getNodeText(node)+
			'" target="'+target+'">'+component_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		component_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function component_outputTree (node) {
	if (node.hasChild == false) {
		component_outputLeaf (node);
	} else {
		component_outputNonLeaf (node);
	}
}

function component_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = componentNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+target+'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		component_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}


var componentDB = new Array();
var componentNSMap = new Array();

componentDB ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("7/complextype/AttributeValueChangeType.html","AttributeValueChangeType",false,new Array(new CN("7/element/110.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] = "7/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("6/complextype/CommonEventInformationType.html","CommonEventInformationType",false,new Array(new CN("6/element/14.html","notificationId",false,null),new CN("6/element/15.html","sourceTime",false,null),new CN("6/element/16.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("6/element/commonEventInformation.html","commonEventInformation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "6/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("3/complextype/EventInformationType.html","EventInformationType",false,new Array(new CN("3/element/12.html","objectType",false,null),new CN("3/element/9.html","objectName",false,null),new CN("3/element/13.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "3/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/elc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("4/complextype/EventLossClearedType.html","EventLossClearedType",false,new Array(new CN("4/element/96.html","objectType",false,null),new CN("4/element/10.html","objectName",false,null),new CN("4/element/109.html","endTime",false,null)))),
					new Array(),
					new Array(new CN("4/element/eventLossCleared.html","eventLossCleared",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/elc/v1"] = "4/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/elo/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("5/complextype/EventLossOccuredType.html","EventLossOccuredType",false,new Array(new CN("5/element/97.html","objectType",false,null),new CN("5/element/11.html","objectName",false,null),new CN("5/element/103.html","startTime",false,null),new CN("5/element/94.html","firstEventLostNotificationId",false,null)))),
					new Array(),
					new Array(new CN("5/element/eventLossOccured.html","eventLossOccured",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/elo/v1"] = "5/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/fts/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("17/simpletype/FileTransferStatusEnumType.html","FileTransferStatusEnumType",false,null)),
					new Array(new CN("17/complextype/FileTransferStatusType.html","FileTransferStatusType",false,new Array(new CN("17/element/106.html","fileName",false,null),new CN("17/element/105.html","transferStatus",false,null),new CN("17/element/107.html","percentComplete",false,null),new CN("17/element/108.html","failureReason",false,null)))),
					new Array(),
					new Array(new CN("17/element/fileTransferStatus.html","fileTransferStatus",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/fts/v1"] = "17/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("2/simpletype/DiscoveredNameType.html","DiscoveredNameType",false,null),new CN("2/simpletype/LocationType.html","LocationType",false,null),new CN("2/simpletype/ManufactureDateType.html","ManufactureDateType",false,null),new CN("2/simpletype/ManufacturerType.html","ManufacturerType",false,null),new CN("2/simpletype/NamingOperationsSystemType.html","NamingOperationsSystemType",false,null),new CN("2/simpletype/NetworkAccessDomainType.html","NetworkAccessDomainType",false,null),new CN("2/simpletype/NotificationIdentifierType.html","NotificationIdentifierType",false,null),new CN("2/simpletype/ObjectEnumType.html","ObjectEnumType",false,null),new CN("2/simpletype/ObjectTypeType.html","ObjectTypeType",false,null),new CN("2/simpletype/OwnerType.html","OwnerType",false,null),new CN("2/simpletype/ProductNameType.html","ProductNameType",false,null),new CN("2/simpletype/UserLabelType.html","UserLabelType",false,null)),
					new Array(new CN("2/complextype/AliasNameListType.html","AliasNameListType",false,new Array(new CN("2/element/98.html","alias",false,null),new CN("2/element/99.html","alias/aliasName",false,null),new CN("2/element/100.html","alias/aliasValue",false,null))),new CN("2/complextype/AnyListType.html","AnyListType",false,null),new CN("2/complextype/MultiEventInventoryAttributesType.html","MultiEventInventoryAttributesType",false,new Array(new CN("2/element/101.html","neTime",false,null),new CN("2/element/102.html","eventIndication",false,null))),new CN("2/complextype/NotificationIdentifierListType.html","NotificationIdentifierListType",false,new Array(new CN("2/element/95.html","notificationId",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "2/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/hbt/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("8/complextype/HeartbeatType.html","HeartbeatType",false,null)),
					new Array(),
					new Array(new CN("8/element/heartbeat.html","heartbeat",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hbt/v1"] = "8/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("16/simpletype/ActivityStatusEnumType.html","ActivityStatusEnumType",false,null),new CN("16/simpletype/CommunicationPatternType.html","CommunicationPatternType",false,null),new CN("16/simpletype/CommunicationStyleType.html","CommunicationStyleType",false,null),new CN("16/simpletype/CompressionEnumType.html","CompressionEnumType",false,null),new CN("16/simpletype/MessageTypeType.html","MessageTypeType",false,null),new CN("16/simpletype/PackingEnumType.html","PackingEnumType",false,null)),
					new Array(new CN("16/complextype/ActivityStatusType.html","ActivityStatusType",false,null),new CN("16/complextype/CompressionTypeType.html","CompressionTypeType",false,null),new CN("16/complextype/PackingTypeType.html","PackingTypeType",false,null)),
					new Array(),
					new Array(new CN("16/element/header.html","header",false,new Array(new CN("16/element/70.html","activityName",false,null),new CN("16/element/71.html","msgName",false,null),new CN("16/element/66.html","msgType",false,null),new CN("16/element/72.html","senderURI",false,null),new CN("16/element/73.html","destinationURI",false,null),new CN("16/element/74.html","replyToURI",false,null),new CN("16/element/75.html","originatorURI",false,null),new CN("16/element/76.html","failureReplytoURI",false,null),new CN("16/element/67.html","activityStatus",false,null),new CN("16/element/77.html","correlationId",false,null),new CN("16/element/78.html","security",false,null),new CN("16/element/79.html","securityType",false,null),new CN("16/element/80.html","priority",false,null),new CN("16/element/81.html","msgSpecificProperties",false,null),new CN("16/element/82.html","msgSpecificProperties/property",false,null),new CN("16/element/83.html","msgSpecificProperties/property/propName",false,null),new CN("16/element/84.html","msgSpecificProperties/property/propValue",false,null),new CN("16/element/64.html","communicationPattern",false,null),new CN("16/element/65.html","communicationStyle",false,null),new CN("16/element/85.html","requestedBatchSize",false,null),new CN("16/element/86.html","batchSequenceNumber",false,null),new CN("16/element/87.html","batchSequenceEndOfReply",false,null),new CN("16/element/88.html","iteratorReferenceURI",false,null),new CN("16/element/89.html","fileLocationURI",false,null),new CN("16/element/68.html","compressionType",false,null),new CN("16/element/69.html","packingType",false,null),new CN("16/element/90.html","timestamp",false,null),new CN("16/element/91.html","vendorExtensions",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] = "16/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/mart/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("15/simpletype/FailPolicyType.html","FailPolicyType",false,null),new CN("15/simpletype/OperationEnumType.html","OperationEnumType",false,null),new CN("15/simpletype/OrderType.html","OrderType",false,null),new CN("15/simpletype/ResultType.html","ResultType",false,null),new CN("15/simpletype/StateType.html","StateType",false,null)),
					new Array(new CN("15/complextype/OperationResultType.html","OperationResultType",false,new Array(new CN("15/element/38.html","operationLabel",false,null),new CN("15/element/35.html","result",false,null),new CN("15/element/39.html","errorReason",false,null))),new CN("15/complextype/OperationSetType.html","OperationSetType",false,new Array(new CN("15/element/30.html","failPolicy",false,null),new CN("15/element/33.html","order",false,null),new CN("15/element/41.html","operation",false,null))),new CN("15/complextype/OperationType.html","OperationType",false,new Array(new CN("15/element/43.html","operationLabel",false,null),new CN("15/element/31.html","failPolicy",false,null),new CN("15/element/44.html","templateName",false,null))),new CN("15/complextype/TemplateListType.html","TemplateListType",false,new Array(new CN("15/element/46.html","templateName",false,null),new CN("15/element/45.html","template",false,null)))),
					new Array(),
					new Array(new CN("15/element/doProcessException.html","doProcessException",false,new Array(new CN("15/element/48.html","CorrelationId",false,null),new CN("15/element/49.html","exceptionType",false,null))),new CN("15/element/doProcessRequest.html","doProcessRequest",false,new Array(new CN("15/element/50.html","correlationId",false,null),new CN("15/element/29.html","failPolicy",false,null),new CN("15/element/32.html","order",false,null),new CN("15/element/47.html","templateList",false,null),new CN("15/element/42.html","operationSet",false,null))),new CN("15/element/doProcessResponse.html","doProcessResponse",false,new Array(new CN("15/element/51.html","correlationId",false,null),new CN("15/element/34.html","result",false,null),new CN("15/element/52.html","errorReason",false,null),new CN("15/element/40.html","operationResult",false,null))),new CN("15/element/getProcessStateException.html","getProcessStateException",false,new Array(new CN("15/element/53.html","CorrelationId",false,null),new CN("15/element/54.html","exceptionType",false,null))),new CN("15/element/getProcessStateRequest.html","getProcessStateRequest",false,new Array(new CN("15/element/55.html","correlationId",false,null))),new CN("15/element/getProcessStateResponse.html","getProcessStateResponse",false,new Array(new CN("15/element/56.html","correlationId",false,null),new CN("15/element/36.html","state",false,null),new CN("15/element/57.html","reason",false,null))),new CN("15/element/terminateProcessException.html","terminateProcessException",false,new Array(new CN("15/element/58.html","CorrelationId",false,null),new CN("15/element/59.html","exceptionType",false,null))),new CN("15/element/terminateProcessRequest.html","terminateProcessRequest",false,new Array(new CN("15/element/60.html","correlationId",false,null))),new CN("15/element/terminateProcessResponse.html","terminateProcessResponse",false,new Array(new CN("15/element/61.html","correlationId",false,null),new CN("15/element/37.html","state",false,null),new CN("15/element/62.html","reason",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/mart/v1"] = "15/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("14/complextype/AllExceptionsType.html","AllExceptionsType",false,null),new CN("14/complextype/BaseExceptionMessageType.html","BaseExceptionMessageType",false,new Array(new CN("14/element/92.html","reason",false,null),new CN("14/element/93.html","vendorExtensions",false,null))),new CN("14/complextype/GetAllDataIteratorExceptionType.html","GetAllDataIteratorExceptionType",false,null),new CN("14/complextype/GetAllDataIteratorRequestType.html","GetAllDataIteratorRequestType",false,null)),
					new Array(),
					new Array(new CN("14/element/accessDenied.html","accessDenied",false,null),new CN("14/element/capacityExceeded.html","capacityExceeded",false,null),new CN("14/element/communicationFailure.html","communicationFailure",false,null),new CN("14/element/entityNotFound.html","entityNotFound",false,null),new CN("14/element/internalError.html","internalError",false,null),new CN("14/element/invalidFilterDefinition.html","invalidFilterDefinition",false,null),new CN("14/element/invalidInput.html","invalidInput",false,null),new CN("14/element/invalidTopic.html","invalidTopic",false,null),new CN("14/element/notificationServiceProblem.html","notificationServiceProblem",false,null),new CN("14/element/notImplemented.html","notImplemented",false,null),new CN("14/element/notInValidState.html","notInValidState",false,null),new CN("14/element/objectInUse.html","objectInUse",false,null),new CN("14/element/protectionEffortNotMet.html","protectionEffortNotMet",false,null),new CN("14/element/timeslotInUse.html","timeslotInUse",false,null),new CN("14/element/tooManyOpenIterators.html","tooManyOpenIterators",false,null),new CN("14/element/tpInvalidEndPoint.html","tpInvalidEndPoint",false,null),new CN("14/element/unableToComply.html","unableToComply",false,null),new CN("14/element/unsupportedCompressionFormat.html","unsupportedCompressionFormat",false,null),new CN("14/element/unsupportedPackingFormat.html","unsupportedPackingFormat",false,null),new CN("14/element/unsupportedRoutingConstraints.html","unsupportedRoutingConstraints",false,null),new CN("14/element/userlabelInUse.html","userlabelInUse",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] = "14/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("1/complextype/NameAndAnyValueListType.html","NameAndAnyValueListType",false,new Array(new CN("1/element/0.html","nv",false,null))),new CN("1/complextype/NameAndAnyValueType.html","NameAndAnyValueType",false,new Array(new CN("1/element/1.html","name",false,null))),new CN("1/complextype/NameAndStringValueType.html","NameAndStringValueType",false,new Array(new CN("1/element/2.html","name",false,null),new CN("1/element/3.html","value",false,null))),new CN("1/complextype/NameAndValueStringListType.html","NameAndValueStringListType",false,new Array(new CN("1/element/4.html","nvs",false,null))),new CN("1/complextype/NamingAttributeListType.html","NamingAttributeListType",false,new Array(new CN("1/element/5.html","name",false,null))),new CN("1/complextype/NamingAttributeType.html","NamingAttributeType",false,new Array(new CN("1/element/6.html","object",false,null),new CN("1/element/7.html","object/type",false,null),new CN("1/element/8.html","object/name",false,null)))),
					new Array(),
					new Array(new CN("1/element/nvList.html","nvList",false,null),new CN("1/element/nvsList.html","nvsList",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "1/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("13/simpletype/EndPointReferenceType.html","EndPointReferenceType",false,null),new CN("13/simpletype/QueryDialectTypeType.html","QueryDialectTypeType",false,null),new CN("13/simpletype/SubscriptionIdentifierType.html","SubscriptionIdentifierType",false,null),new CN("13/simpletype/TopicExpressionType.html","TopicExpressionType",false,null)),
					new Array(new CN("13/complextype/QueryExpressionType.html","QueryExpressionType",false,new Array(new CN("13/element/20.html","dialect",false,null),new CN("13/element/26.html","query",false,null)))),
					new Array(),
					new Array(new CN("13/element/notify.html","notify",false,new Array(new CN("13/element/23.html","topic",false,null),new CN("13/element/28.html","message",false,null))),new CN("13/element/subscribeException.html","subscribeException",false,null),new CN("13/element/subscribeRequest.html","subscribeRequest",false,new Array(new CN("13/element/19.html","consumerEpr",false,null),new CN("13/element/24.html","topic",false,null),new CN("13/element/27.html","selector",false,null))),new CN("13/element/subscribeResponse.html","subscribeResponse",false,new Array(new CN("13/element/21.html","subscriptionID",false,null))),new CN("13/element/unsubscribeException.html","unsubscribeException",false,null),new CN("13/element/unsubscribeRequest.html","unsubscribeRequest",false,new Array(new CN("13/element/22.html","subscriptionID",false,null),new CN("13/element/25.html","topic",false,null))),new CN("13/element/unsubscribeResponse.html","unsubscribeResponse",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1"] = "13/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("9/complextype/ObjectCreationType.html","ObjectCreationType",false,new Array(new CN("9/element/63.html","object",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] = "9/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("10/complextype/ObjectDeletionType.html","ObjectDeletionType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] = "10/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("12/complextype/ObjectDiscoveryType.html","ObjectDiscoveryType",false,new Array(new CN("12/element/17.html","discoveredName",false,null),new CN("12/element/18.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] = "12/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("11/complextype/StateChangeType.html","StateChangeType",false,new Array(new CN("11/element/104.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] = "11/index.html";
								   


