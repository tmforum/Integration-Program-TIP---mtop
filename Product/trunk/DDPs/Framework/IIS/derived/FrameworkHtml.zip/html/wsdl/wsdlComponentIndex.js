﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/fmw/wsdl/mart/v1-0"] =  new WC (
					new Array(new WCN("20/service/MartHttp.html","MartHttp",false,null),new WCN("20/service/MartJms.html","MartJms",false,null)),
					new Array(new WCN("20/message/doProcessException.html","doProcessException",false,null),new WCN("20/message/doProcessRequest.html","doProcessRequest",false,null),new WCN("20/message/doProcessResponse.html","doProcessResponse",false,null),new WCN("20/message/getProcessStateException.html","getProcessStateException",false,null),new WCN("20/message/getProcessStateRequest.html","getProcessStateRequest",false,null),new WCN("20/message/getProcessStateResponse.html","getProcessStateResponse",false,null),new WCN("20/message/terminateProcessException.html","terminateProcessException",false,null),new WCN("20/message/terminateProcessRequest.html","terminateProcessRequest",false,null),new WCN("20/message/terminateProcessResponse.html","terminateProcessResponse",false,null)),
					new Array(new WCN("20/porttype/Mart.html","Mart",false,new Array(new WCN("20/operation/doProcess_5.html","doProcess",false,null),new WCN("20/operation/getProcessState_6.html","getProcessState",false,null),new WCN("20/operation/terminateProcess_7.html","terminateProcess",false,null)))),
					new Array(new WCN("20/binding/MartSoapHttpBinding.html","MartSoapHttpBinding",false,new Array(new WCN("20/operation/doProcess_5.html","doProcess",false,null),new WCN("20/operation/getProcessState_6.html","getProcessState",false,null),new WCN("20/operation/terminateProcess_7.html","terminateProcess",false,null))),new WCN("20/binding/MartSoapJmsBinding.html","MartSoapJmsBinding",false,new Array(new WCN("20/operation/doProcess_5.html","doProcess",false,null),new WCN("20/operation/getProcessState_6.html","getProcessState",false,null),new WCN("20/operation/terminateProcess_7.html","terminateProcess",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/fmw/wsdl/mart/v1-0"] = "20/index.html";
wcDB ["http://www.tmforum.org/mtop/fmw/wsdl/notb/v1-0"] =  new WC (
					new Array(new WCN("18/service/NotificationBrokerHttp.html","NotificationBrokerHttp",false,null),new WCN("18/service/NotificationBrokerJms.html","NotificationBrokerJms",false,null)),
					new Array(new WCN("18/message/notify.html","notify",true,null),new WCN("18/message/subscribeException.html","subscribeException",true,null),new WCN("18/message/subscribeRequest.html","subscribeRequest",true,null),new WCN("18/message/subscribeResponse.html","subscribeResponse",true,null),new WCN("18/message/unsubscribeException.html","unsubscribeException",true,null),new WCN("18/message/unsubscribeRequest.html","unsubscribeRequest",true,null),new WCN("18/message/unsubscribeResponse.html","unsubscribeResponse",true,null)),
					new Array(new WCN("18/porttype/NotificationBroker.html","NotificationBroker",false,new Array(new WCN("18/operation/notify_0.html","notify",false,null),new WCN("18/operation/subscribe_1.html","subscribe",false,null),new WCN("18/operation/unsubscribe_2.html","unsubscribe",false,null)))),
					new Array(new WCN("18/binding/NotificationBrokerSoapHttpBinding.html","NotificationBrokerSoapHttpBinding",false,new Array(new WCN("18/operation/notify_0.html","notify",false,null),new WCN("18/operation/subscribe_1.html","subscribe",false,null),new WCN("18/operation/unsubscribe_2.html","unsubscribe",false,null))),new WCN("18/binding/NotificationBrokerSoapJmsBinding.html","NotificationBrokerSoapJmsBinding",false,new Array(new WCN("18/operation/notify_0.html","notify",false,null),new WCN("18/operation/subscribe_1.html","subscribe",false,null),new WCN("18/operation/unsubscribe_2.html","unsubscribe",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/fmw/wsdl/notb/v1-0"] = "18/index.html";
wcDB ["http://www.tmforum.org/mtop/fmw/wsdl/notc/v1-0"] =  new WC (
					new Array(new WCN("21/service/NotificationConsumerHttp.html","NotificationConsumerHttp",false,null),new WCN("21/service/NotificationConsumerJms.html","NotificationConsumerJms",false,null)),
					new Array(new WCN("21/message/notify.html","notify",true,null)),
					new Array(new WCN("21/porttype/NotificationConsumer.html","NotificationConsumer",false,new Array(new WCN("21/operation/notify_8.html","notify",false,null)))),
					new Array(new WCN("21/binding/NotificationConsumerSoapHttpBinding.html","NotificationConsumerSoapHttpBinding",false,new Array(new WCN("21/operation/notify_8.html","notify",false,null))),new WCN("21/binding/NotificationConsumerSoapJmsBinding.html","NotificationConsumerSoapJmsBinding",false,new Array(new WCN("21/operation/notify_8.html","notify",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/fmw/wsdl/notc/v1-0"] = "21/index.html";
wcDB ["http://www.tmforum.org/mtop/fmw/wsdl/notp/v1-0"] =  new WC (
					new Array(new WCN("19/service/NotificationProducerHttp.html","NotificationProducerHttp",false,null),new WCN("19/service/NotificationProducerJms.html","NotificationProducerJms",false,null)),
					new Array(new WCN("19/message/subscribeException.html","subscribeException",true,null),new WCN("19/message/subscribeRequest.html","subscribeRequest",true,null),new WCN("19/message/subscribeResponse.html","subscribeResponse",true,null),new WCN("19/message/unsubscribeException.html","unsubscribeException",true,null),new WCN("19/message/unsubscribeRequest.html","unsubscribeRequest",true,null),new WCN("19/message/unsubscribeResponse.html","unsubscribeResponse",true,null)),
					new Array(new WCN("19/porttype/NotificationProducer.html","NotificationProducer",false,new Array(new WCN("19/operation/subscribe_3.html","subscribe",false,null),new WCN("19/operation/unsubscribe_4.html","unsubscribe",false,null)))),
					new Array(new WCN("19/binding/NotificationProducerSoapHttpBinding.html","NotificationProducerSoapHttpBinding",false,new Array(new WCN("19/operation/subscribe_3.html","subscribe",false,null),new WCN("19/operation/unsubscribe_4.html","unsubscribe",false,null))),new WCN("19/binding/NotificationProducerSoapJmsBinding.html","NotificationProducerSoapJmsBinding",false,new Array(new WCN("19/operation/subscribe_3.html","subscribe",false,null),new WCN("19/operation/unsubscribe_4.html","unsubscribe",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/fmw/wsdl/notp/v1-0"] = "19/index.html";
