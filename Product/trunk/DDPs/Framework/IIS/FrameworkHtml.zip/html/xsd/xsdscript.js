/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var isNav = (navigator.appName.indexOf("Netscape") != -1)

function loadimg () {
	if (document.readyState != "complete") {
		return;
	}

	img0 = document.createElement ("img"); 
	img0.src = "../../img/hideDetail.gif"; 
	img1 = document.createElement ("img"); 
	img1.src = "../../img/showDetail.gif"; 
	
	if (document.images) {
		var len = document.images.length;
		for (var i=0; i<len; i++) {
			var img = document.images[i];
			if (img.src.indexOf ("hideDetail.gif")>=0) {
				img.src = img0.src;
			} else if (img.src.indexOf ("showDetail.gif")>=0) {
				img.src = img1.src;
			}
		}
	}	
}

function displayAnnotations (obj, ids) {
	var flag = obj.src.indexOf ("showXIComment")>=0;

	var displayVal = null;
	var i;
	var id;
	for (i=0; i<ids.length; i++) {
		id=ids[i];
		var tag = document.getElementById (id);
		if (id.indexOf ("annID")>=0) {
			displayVal = flag ? "block" : "none";
			tag.style.display = displayVal;
		} else if (id.indexOf ("ifID")>=0) {
			displayVal = flag ? "inline" : "none";
			tag.style.display = displayVal;
			var img = document.getElementById (id+"img");			
			if (flag) {	
				img.src = "../../img/hideComment.gif";
				img.alt = "Click here to hide Comment";
			} else {
				img.src = "../../img/showComment.gif";
				img.alt = "Click here to show Comment";
			}
		}
	}

	if (obj.src.indexOf ("showXIComment")>=0) {
		obj.src = "../../img/hideXIComment.gif";
		obj.alt = "Click here to hide Comment";
	} else {
		obj.src = "../../img/showXIComment.gif";
		obj.alt = "Click here to show Comment";
	}
}

function expandCPanel (id, obj, prefix) {
	var tag = document.getElementById (id);
	var dir = "";
	if (prefix != null) {
		dir = prefix + "/";
	}
	
	if (tag.style.display == "" || tag.style.display == "block") {
		tag.style.display = "none";
		obj.src = dir+"img/expand.gif";
		obj.alt = "Expand";
	} else {
		tag.style.display = "block";
		obj.src = dir+"img/collapse.gif";
		obj.alt = "Collapse";
	}
}

function expandRefPanel (id, obj, w) {
	var tag = document.getElementById (id);
	
	if (tag.style.height == "" || tag.style.height == "100%") {
		obj.src = "../../img/expand.gif";
		obj.alt = "Expand";
		
		tag.style.height = "250px";
		tag.style.width = "650px";
		tag.style.overflow = "auto";
		if (isNav) {
			tag.parentNode.style.height = "250px";
			tag.parentNode.style.width = "650px";
		}
	} else {
		obj.src = "../../img/collapse.gif";
		obj.alt = "Collapse";
		
		tag.style.height = "100%";
		tag.style.width = w;
		tag.style.overflow = "auto";
		if (isNav) {
			tag.parentNode.style.height = "100%";
			tag.parentNode.style.width = w;
		}
	}
}

function expandAttrPanel (id, obj, w) {
	var tag = document.getElementById (id);
	
	if (tag.style.height == "" || tag.style.height == "100%") {
		obj.src = "../../img/expand.gif";
		obj.alt = "Expand";
		tag.style.height = "200px";
		tag.style.width = "650px";
		tag.style.overflow = "auto";

		if (isNav) {
			tag.parentNode.height = "200px";
			tag.parentNode.width = "650px";
			tag.style.overflow = "auto";
		}

	} else {
		obj.src = "../../img/collapse.gif";
		obj.alt = "Collapse";
		tag.style.height = "100%";
		tag.style.width = w;
		tag.style.overflow = "auto";

		if (isNav) {
			tag.parentNode.height = "100%";
			tag.parentNode.width = w;
			tag.style.overflow = "auto";
		} 

	}
}

function expandPanel (id, obj) {
	var tag = document.getElementById (id);

	if (tag.style.height == "" || tag.style.height == "100%") {
		obj.src = "../../img/expand.gif";
		obj.alt = "Expand";
		
		tag.style.height = "200px";
		tag.style.width = "650px";
		
		if (isNav) {
			tag.parentNode.height = "200px";
			tag.parentNode.width = "650px";
			tag.style.overflow = "auto";
		}
	} else {
		obj.src = "../../img/collapse.gif";
		obj.alt = "Collapse";
		
		tag.style.height = "100%";		
		tag.style.width = "100%";
		
		if (isNav) {
			tag.parentNode.height = "100%";
			tag.parentNode.width = "100%";
			tag.style.overflow = "auto";
		} 
	}
}

function setTitle (title) {
	parent.document.title = title;
}

function showHelp (helpURL) {
	helpURL = "http://www.bluetetra.com/wsdldoc/doc1.0/help.htm";
	window.open(helpURL, "_blank", "width=400,height=550,resizable=true,scrollbars=yes");	
}

function displayComment (id, obj, dstyle) {
	var tag = document.getElementById (id);
		
	if (tag != null) {
		if (tag.style.display == dstyle) {
			tag.style.display = "none";
			obj.src = "../../img/showComment.gif";
			obj.alt = "Click here to show Comment";
		} else {
			tag.style.display = dstyle;
			obj.src = "../../img/hideComment.gif";
			obj.alt = "Click here to hide Comment";
		}
	}
}

function switchView (id0, id1, obj) {
	var dstyle = 'inline';	

	var tag = document.getElementById (id0);
	if (tag != null) {
		if (tag.style.display == dstyle) {
			tag.style.display = "none";
		} else {
			tag.style.display = dstyle;
		}
	}

	tag = document.getElementById (id1);
	if (tag != null) {
		if (tag.style.display == dstyle) {
			tag.style.display = "none";
		} else {
			tag.style.display = dstyle;
		}
	}

	if (obj.src.indexOf ("showComment")>=0) {
		obj.src = "../../img/hideComment.gif";
		obj.alt = "Click here to hide Comment";
	} else {
		obj.src = "../../img/showComment.gif";
		obj.alt = "Click here to show Comment";
	}
}

function IEXmlElementClick (e) {
	e = e.parentElement.parentElement.parentElement;

	mark = e.children(0).children(0).children(0);

	if (mark.innerText == "+") {
		mark.innerText = "-";
		for (var i = 1; i < e.children.length; i++)
			e.children(i).style.display = "block";

	} else if (mark.innerText == "-") {
		mark.innerText = "+";
		for (var i = 1; i < e.children.length; i++)
			e.children(i).style.display="none";

	}

}

function NavXmlElementClick (e) {
	e = e.parentNode.parentNode.parentNode;

	mark = e.childNodes[0].childNodes[0].childNodes[0];

	if (mark.text == "+") {
		mark.childNodes[0].nodeValue = "-";
		for (var i = 1; i < e.childNodes.length; i++) {
			e.childNodes[i].style.display="block";
		}
	} else if (mark.text == "-") {
		mark.childNodes[0].nodeValue = "+";
		for (var i = 1; i < e.childNodes.length; i++) {
			e.childNodes[i].style.display="none";
		}
	}
}

function xmlElementClick(e)
{
	if (isNav) {
		NavXmlElementClick (e);
	} else {
		IEXmlElementClick(e);
	}
}



function IEIClick (e) {
	if (e.src.indexOf("plus.gif")>=0) {
		e.src = "img/minus.gif";
		while (e.tagName.toLowerCase() != "div") {
			e = e.parentElement;
		}
		e = e.parentElement;
		for (var i = 1; i < e.children.length; i++) {
			e.children(i).style.display = "block";
		}
	} else {
		e.src = "img/plus.gif";
		while (e.tagName.toLowerCase() != "div") {
			e = e.parentElement;
		}
		e = e.parentElement;
		for (var i = 1; i < e.children.length; i++) {
			e.children(i).style.display = "none";
		}

	}
}

function NavIClick (e) {
	if (e.src.indexOf("plus.gif")>=0) {
		e.src = "img/minus.gif";
		while (e.tagName.toLowerCase() != "div") {
			e = e.parentNode;
		}
		e = e.parentNode;
		for (var i = 1; i < e.childNodes.length; i++) {
			if (e.childNodes[i].style != null) {
				e.childNodes[i].style.display = "block";
			}
		}
	} else {
		e.src = "img/plus.gif";
		while (e.tagName.toLowerCase() != "div") {
			e = e.parentNode;
		}
		e = e.parentNode;
		for (var i=1; i < e.childNodes.length; i++) {
			if (e.childNodes[i].style != null) {
				e.childNodes[i].style.display = "none";
			}
		}
	}
}

function IClick (e) 
{
	if (navigator.appName.indexOf("Netscape") != -1) {
		NavIClick (e);
	} else {
		IEIClick(e);
	}
}

