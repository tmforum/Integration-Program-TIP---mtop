﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_ciFileName = "componentIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function CN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function C (attributeList, attributeGroupList,
						simpleTypeList, complexTypeList,
						modelGroupList, elementList, 
						notationList) 
{
	this.attributes = attributeList;
	this.attributegroups = attributeGroupList;
	this.simpletypes = simpleTypeList;
	this.complextypes = complexTypeList;
	this.modelgroups = modelGroupList;
	this.elements = elementList;
	this.notations = notationList;
}

function component_showAllComponents() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_ciFileName;
}

function component_filterComponents () {
	parent._href = "xsd/" + xsd_ciFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function component_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href=xsd_ciFileName;	
}

function component_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in componentDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}

	parent._xsdNsFilter = nsList;
}

function component_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	component_outputList (null, components);	
}


function component_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		component_outputList (namespace, list);	
	}
}


function component_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		component_showComponentsNS (nsList, componentList)
	} else {
		component_showComponentsNoNS (nsList, componentList)
	}
}

function component_showAttributes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		attributes [i] = componentDB [nsList[i]].attributes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributes);
}

function component_showAttributeGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributegroups = new Array();
	var nss = new Array();		

	for (var i=0; i<nsList.length; i++) {
		attributegroups [i] = componentDB [nsList[i]].attributegroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributegroups);
}

function component_showSimpleTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var simpletypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		simpletypes [i] = componentDB [nsList[i]].simpletypes;	
		nss [i] = nsList[i];
	}		

	component_showComponents (nss, simpletypes);
}

function component_showComplexTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var complextypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		complextypes [i] = componentDB [nsList[i]].complextypes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, complextypes);
}

function component_showElements() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var elements = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		elements [i] = componentDB [nsList[i]].elements;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, elements);
}

function component_showModelGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var modelgroups = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		modelgroups [i] = componentDB [nsList[i]].modelgroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, modelgroups);
}

function component_showNotations() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var notations = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		notations [i] = componentDB [nsList[i]].notations;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, notations);

}


function component_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function component_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+component_getNodeText(node)+
			  '" target="'+target+'">'+component_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function component_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+component_getNodeText(node)+
			'" target="'+target+'">'+component_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		component_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function component_outputTree (node) {
	if (node.hasChild == false) {
		component_outputLeaf (node);
	} else {
		component_outputNonLeaf (node);
	}
}

function component_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = componentNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+target+'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		component_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}


var componentDB = new Array();
var componentNSMap = new Array();

componentDB ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("21/complextype/AttributeValueChangeType.html","AttributeValueChangeType",false,new Array(new CN("21/element/133.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] = "21/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("2/complextype/CommonEventInformationType.html","CommonEventInformationType",false,new Array(new CN("2/element/13.html","notificationId",false,null),new CN("2/element/14.html","sourceTime",false,null),new CN("2/element/15.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("2/element/commonEventInformation.html","commonEventInformation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "2/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cocd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("14/complextype/CommonObjectCreateDataType.html","CommonObjectCreateDataType",false,new Array(new CN("14/element/29.html","name",false,null)))),
					new Array(),
					new Array(new CN("14/element/commonObjectCreateData.html","commonObjectCreateData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cocd/v1"] = "14/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("5/complextype/CommonObjectInfoType.html","CommonObjectInfoType",false,new Array(new CN("5/element/2.html","name",false,null),new CN("5/element/3.html","userLabel",false,null),new CN("5/element/4.html","discoveredName",false,null),new CN("5/element/5.html","namingOs",false,null),new CN("5/element/6.html","owner",false,null),new CN("5/element/7.html","aliasNameList",false,null),new CN("5/element/8.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("5/element/commonObjectInfo.html","commonObjectInfo",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "5/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/comd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("15/complextype/CommonObjectModifyDataType.html","CommonObjectModifyDataType",false,null)),
					new Array(),
					new Array(new CN("15/element/commonObjectModifyData.html","commonObjectModifyData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/comd/v1"] = "15/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cornot/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("20/complextype/CorrelatedNotificationListType.html","CorrelatedNotificationListType",false,new Array(new CN("20/element/132.html","correlatedNotifications",false,null))),new CN("20/complextype/CorrelatedNotificationsType.html","CorrelatedNotificationsType",false,new Array(new CN("20/element/30.html","name",false,null),new CN("20/element/98.html","notifIds",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cornot/v1"] = "20/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cosd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("13/complextype/CommonObjectSetDataType.html","CommonObjectSetDataType",false,new Array(new CN("13/element/19.html","userLabel",false,null),new CN("13/element/20.html","isForceUniqueness",false,null),new CN("13/element/21.html","owner",false,null),new CN("13/element/22.html","aliasNameList",false,null),new CN("13/element/23.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("13/element/commonObjectSetData.html","commonObjectSetData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cosd/v1"] = "13/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("8/complextype/EventInformationType.html","EventInformationType",false,new Array(new CN("8/element/35.html","objectType",false,null),new CN("8/element/31.html","objectName",false,null),new CN("8/element/36.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "8/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/elc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("16/complextype/EventLossClearedType.html","EventLossClearedType",false,new Array(new CN("16/element/88.html","objectType",false,null),new CN("16/element/32.html","objectName",false,null),new CN("16/element/131.html","endTime",false,null)))),
					new Array(),
					new Array(new CN("16/element/eventLossCleared.html","eventLossCleared",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/elc/v1"] = "16/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/elo/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("9/complextype/EventLossOccuredType.html","EventLossOccuredType",false,new Array(new CN("9/element/9.html","objectType",false,null),new CN("9/element/10.html","objectName",false,null),new CN("9/element/11.html","startTime",false,null),new CN("9/element/12.html","firstEventLostNotificationId",false,null)))),
					new Array(),
					new Array(new CN("9/element/eventLossOccured.html","eventLossOccured",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/elo/v1"] = "9/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/fts/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("17/simpletype/FileTransferStatusEnumType.html","FileTransferStatusEnumType",false,null)),
					new Array(new CN("17/complextype/FileTransferStatusType.html","FileTransferStatusType",false,new Array(new CN("17/element/128.html","fileName",false,null),new CN("17/element/127.html","transferStatus",false,null),new CN("17/element/129.html","percentComplete",false,null),new CN("17/element/130.html","failureReason",false,null)))),
					new Array(),
					new Array(new CN("17/element/fileTransferStatus.html","fileTransferStatus",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/fts/v1"] = "17/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("3/simpletype/DiscoveredNameType.html","DiscoveredNameType",false,null),new CN("3/simpletype/LocationType.html","LocationType",false,null),new CN("3/simpletype/ManufactureDateType.html","ManufactureDateType",false,null),new CN("3/simpletype/ManufacturerType.html","ManufacturerType",false,null),new CN("3/simpletype/NamingOperationsSystemType.html","NamingOperationsSystemType",false,null),new CN("3/simpletype/NetworkAccessDomainType.html","NetworkAccessDomainType",false,null),new CN("3/simpletype/NotificationIdentifierType.html","NotificationIdentifierType",false,null),new CN("3/simpletype/ObjectEnumType.html","ObjectEnumType",false,null),new CN("3/simpletype/ObjectTypeType.html","ObjectTypeType",false,null),new CN("3/simpletype/OwnerType.html","OwnerType",false,null),new CN("3/simpletype/ProductNameType.html","ProductNameType",false,null),new CN("3/simpletype/QueryDialectEnumType.html","QueryDialectEnumType",false,null),new CN("3/simpletype/QueryDialectTypeType.html","QueryDialectTypeType",false,null),new CN("3/simpletype/UserLabelType.html","UserLabelType",false,null)),
					new Array(new CN("3/complextype/AliasNameListType.html","AliasNameListType",false,new Array(new CN("3/element/24.html","alias",false,null),new CN("3/element/25.html","alias/aliasName",false,null),new CN("3/element/26.html","alias/aliasValue",false,null))),new CN("3/complextype/AnyListType.html","AnyListType",false,null),new CN("3/complextype/MultiEventInventoryAttributesType.html","MultiEventInventoryAttributesType",false,new Array(new CN("3/element/91.html","neTime",false,null),new CN("3/element/92.html","eventIndication",false,null))),new CN("3/complextype/NameAndAnyValueListType.html","NameAndAnyValueListType",false,new Array(new CN("3/element/93.html","nv",false,null))),new CN("3/complextype/NameAndAnyValueType.html","NameAndAnyValueType",false,new Array(new CN("3/element/94.html","name",false,null))),new CN("3/complextype/NameAndStringValueType.html","NameAndStringValueType",false,new Array(new CN("3/element/95.html","name",false,null),new CN("3/element/96.html","value",false,null))),new CN("3/complextype/NameAndValueStringListType.html","NameAndValueStringListType",false,new Array(new CN("3/element/97.html","nvs",false,null))),new CN("3/complextype/NotificationIdentifierListType.html","NotificationIdentifierListType",false,new Array(new CN("3/element/87.html","notificationId",false,null))),new CN("3/complextype/QueryExpressionType.html","QueryExpressionType",false,null)),
					new Array(),
					new Array(new CN("3/element/nvList.html","nvList",false,null),new CN("3/element/nvsList.html","nvsList",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "3/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/hbt/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("18/complextype/HeartbeatType.html","HeartbeatType",false,null)),
					new Array(),
					new Array(new CN("18/element/heartbeat.html","heartbeat",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hbt/v1"] = "18/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("25/simpletype/ActivityStatusEnumType.html","ActivityStatusEnumType",false,null),new CN("25/simpletype/CommunicationPatternType.html","CommunicationPatternType",false,null),new CN("25/simpletype/CommunicationStyleType.html","CommunicationStyleType",false,null),new CN("25/simpletype/CompressionEnumType.html","CompressionEnumType",false,null),new CN("25/simpletype/MessageTypeType.html","MessageTypeType",false,null),new CN("25/simpletype/PackingEnumType.html","PackingEnumType",false,null)),
					new Array(new CN("25/complextype/ActivityStatusType.html","ActivityStatusType",false,null),new CN("25/complextype/CompressionTypeType.html","CompressionTypeType",false,null),new CN("25/complextype/PackingTypeType.html","PackingTypeType",false,null)),
					new Array(),
					new Array(new CN("25/element/header.html","header",false,new Array(new CN("25/element/105.html","activityName",false,null),new CN("25/element/106.html","msgName",false,null),new CN("25/element/101.html","msgType",false,null),new CN("25/element/107.html","senderURI",false,null),new CN("25/element/108.html","destinationURI",false,null),new CN("25/element/109.html","replyToURI",false,null),new CN("25/element/110.html","originatorURI",false,null),new CN("25/element/111.html","failureReplytoURI",false,null),new CN("25/element/102.html","activityStatus",false,null),new CN("25/element/112.html","correlationId",false,null),new CN("25/element/113.html","security",false,null),new CN("25/element/114.html","securityType",false,null),new CN("25/element/115.html","priority",false,null),new CN("25/element/116.html","msgSpecificProperties",false,null),new CN("25/element/117.html","msgSpecificProperties/property",false,null),new CN("25/element/118.html","msgSpecificProperties/property/propName",false,null),new CN("25/element/119.html","msgSpecificProperties/property/propValue",false,null),new CN("25/element/99.html","communicationPattern",false,null),new CN("25/element/100.html","communicationStyle",false,null),new CN("25/element/120.html","requestedBatchSize",false,null),new CN("25/element/121.html","batchSequenceNumber",false,null),new CN("25/element/122.html","batchSequenceEndOfReply",false,null),new CN("25/element/123.html","iteratorReferenceURI",false,null),new CN("25/element/124.html","fileLocationURI",false,null),new CN("25/element/103.html","compressionType",false,null),new CN("25/element/104.html","packingType",false,null),new CN("25/element/125.html","timestamp",false,null),new CN("25/element/90.html","vendorExtensions",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] = "25/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/mart/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("24/simpletype/FailPolicyType.html","FailPolicyType",false,null),new CN("24/simpletype/OperationEnumType.html","OperationEnumType",false,null),new CN("24/simpletype/OrderType.html","OrderType",false,null),new CN("24/simpletype/ResultType.html","ResultType",false,null),new CN("24/simpletype/StateType.html","StateType",false,null)),
					new Array(new CN("24/complextype/OperationResultType.html","OperationResultType",false,new Array(new CN("24/element/55.html","operationLabel",false,null),new CN("24/element/50.html","result",false,null),new CN("24/element/56.html","errorReason",false,null),new CN("24/element/57.html","templateName",false,null),new CN("24/element/58.html","operationResultData",false,null))),new CN("24/complextype/OperationSetResultType.html","OperationSetResultType",false,new Array(new CN("24/element/60.html","operationSetResultLabel",false,null),new CN("24/element/51.html","result",false,null),new CN("24/element/59.html","operation",false,null))),new CN("24/complextype/OperationSetStateType.html","OperationSetStateType",false,new Array(new CN("24/element/62.html","operationSetStateLabel",false,null),new CN("24/element/52.html","state",false,null),new CN("24/element/63.html","operation",false,null))),new CN("24/complextype/OperationSetType.html","OperationSetType",false,new Array(new CN("24/element/67.html","operationSetLabel",false,null),new CN("24/element/46.html","failPolicy",false,null),new CN("24/element/49.html","order",false,null),new CN("24/element/68.html","operation",false,null))),new CN("24/complextype/OperationStateType.html","OperationStateType",false,new Array(new CN("24/element/65.html","operationLabel",false,null),new CN("24/element/53.html","state",false,null),new CN("24/element/66.html","reason",false,null))),new CN("24/complextype/OperationType.html","OperationType",false,new Array(new CN("24/element/70.html","operationLabel",false,null),new CN("24/element/47.html","failPolicy",false,null),new CN("24/element/71.html","isResultDataRequested",false,null),new CN("24/element/72.html","templateName",false,null),new CN("24/element/73.html","operationData",false,null))),new CN("24/complextype/TemplateListType.html","TemplateListType",false,new Array(new CN("24/element/75.html","template",false,null),new CN("24/element/76.html","template/name",false,null),new CN("24/element/74.html","template/definition",false,null)))),
					new Array(),
					new Array(new CN("24/element/doProcessException.html","doProcessException",false,new Array(new CN("24/element/79.html","exceptionType",false,null))),new CN("24/element/doProcessRequest.html","doProcessRequest",false,new Array(new CN("24/element/80.html","requestId",false,null),new CN("24/element/45.html","failPolicy",false,null),new CN("24/element/48.html","order",false,null),new CN("24/element/77.html","templateList",false,null),new CN("24/element/69.html","operationSet",false,null))),new CN("24/element/doProcessResponse.html","doProcessResponse",false,new Array(new CN("24/element/81.html","errorReason",false,null),new CN("24/element/78.html","templateList",false,null),new CN("24/element/61.html","operationSetResult",false,null))),new CN("24/element/getProcessStateException.html","getProcessStateException",false,new Array(new CN("24/element/82.html","exceptionType",false,null))),new CN("24/element/getProcessStateRequest.html","getProcessStateRequest",false,new Array(new CN("24/element/83.html","requestId",false,null))),new CN("24/element/getProcessStateResponse.html","getProcessStateResponse",false,new Array(new CN("24/element/64.html","operationStateSet",false,null))),new CN("24/element/terminateProcessException.html","terminateProcessException",false,new Array(new CN("24/element/84.html","exceptionType",false,null))),new CN("24/element/terminateProcessRequest.html","terminateProcessRequest",false,new Array(new CN("24/element/85.html","requestId",false,null))),new CN("24/element/terminateProcessResponse.html","terminateProcessResponse",false,new Array(new CN("24/element/54.html","state",false,null),new CN("24/element/86.html","reason",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/mart/v1"] = "24/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/md/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("4/complextype/ManagementDomainListType.html","ManagementDomainListType",false,null),new CN("4/complextype/ManagementDomainType.html","ManagementDomainType",false,null)),
					new Array(),
					new Array(new CN("4/element/md.html","md",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/md/v1"] = "4/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("23/complextype/AllExceptionsType.html","AllExceptionsType",false,null),new CN("23/complextype/BaseExceptionMessageType.html","BaseExceptionMessageType",false,new Array(new CN("23/element/126.html","reason",false,null),new CN("23/element/89.html","vendorExtensions",false,null))),new CN("23/complextype/GetAllDataIteratorExceptionType.html","GetAllDataIteratorExceptionType",false,null),new CN("23/complextype/GetAllDataIteratorRequestType.html","GetAllDataIteratorRequestType",false,null)),
					new Array(),
					new Array(new CN("23/element/accessDenied.html","accessDenied",false,null),new CN("23/element/capacityExceeded.html","capacityExceeded",false,null),new CN("23/element/commLoss.html","commLoss",false,null),new CN("23/element/entityNotFound.html","entityNotFound",false,null),new CN("23/element/internalError.html","internalError",false,null),new CN("23/element/invalidFilterDefinition.html","invalidFilterDefinition",false,null),new CN("23/element/invalidInput.html","invalidInput",false,null),new CN("23/element/invalidTopic.html","invalidTopic",false,null),new CN("23/element/notificationServiceProblem.html","notificationServiceProblem",false,null),new CN("23/element/notImplemented.html","notImplemented",false,null),new CN("23/element/notInValidState.html","notInValidState",false,null),new CN("23/element/objectInUse.html","objectInUse",false,null),new CN("23/element/protectionEffortNotMet.html","protectionEffortNotMet",false,null),new CN("23/element/timeslotInUse.html","timeslotInUse",false,null),new CN("23/element/tooManyOpenIterators.html","tooManyOpenIterators",false,null),new CN("23/element/tpInvalidEndPoint.html","tpInvalidEndPoint",false,null),new CN("23/element/unableToComply.html","unableToComply",false,null),new CN("23/element/unsupportedCompressionFormat.html","unsupportedCompressionFormat",false,null),new CN("23/element/unsupportedPackingFormat.html","unsupportedPackingFormat",false,null),new CN("23/element/unsupportedRoutingConstraints.html","unsupportedRoutingConstraints",false,null),new CN("23/element/userlabelInUse.html","userlabelInUse",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] = "23/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("6/complextype/NamingAttributeListType.html","NamingAttributeListType",false,new Array(new CN("6/element/28.html","name",false,null))),new CN("6/complextype/NamingAttributeType.html","NamingAttributeType",false,new Array(new CN("6/element/16.html","rdn",false,null))),new CN("6/complextype/RelativeDistinguishNameType.html","RelativeDistinguishNameType",false,new Array(new CN("6/element/33.html","type",false,null),new CN("6/element/34.html","value",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "6/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("19/simpletype/EndPointReferenceType.html","EndPointReferenceType",false,null),new CN("19/simpletype/SubscriptionIdentifierType.html","SubscriptionIdentifierType",false,null),new CN("19/simpletype/TopicExpressionType.html","TopicExpressionType",false,null)),
					new Array(),
					new Array(),
					new Array(new CN("19/element/notify.html","notify",false,new Array(new CN("19/element/40.html","topic",false,null),new CN("19/element/27.html","message",false,null))),new CN("19/element/subscribeException.html","subscribeException",false,null),new CN("19/element/subscribeRequest.html","subscribeRequest",false,new Array(new CN("19/element/37.html","consumerEpr",false,null),new CN("19/element/41.html","topic",false,null),new CN("19/element/43.html","selector",false,null))),new CN("19/element/subscribeResponse.html","subscribeResponse",false,new Array(new CN("19/element/38.html","subscriptionID",false,null))),new CN("19/element/unsubscribeException.html","unsubscribeException",false,null),new CN("19/element/unsubscribeRequest.html","unsubscribeRequest",false,new Array(new CN("19/element/39.html","subscriptionID",false,null),new CN("19/element/42.html","topic",false,null))),new CN("19/element/unsubscribeResponse.html","unsubscribeResponse",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1"] = "19/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("22/complextype/ObjectCreationType.html","ObjectCreationType",false,new Array(new CN("22/element/44.html","object",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] = "22/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("7/complextype/ObjectDeletionType.html","ObjectDeletionType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] = "7/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("1/complextype/ObjectDiscoveryType.html","ObjectDiscoveryType",false,new Array(new CN("1/element/0.html","discoveredName",false,null),new CN("1/element/1.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] = "1/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("10/complextype/StateChangeType.html","StateChangeType",false,new Array(new CN("10/element/17.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] = "10/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/vdn/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("11/complextype/VendorNotificationType.html","VendorNotificationType",false,new Array(new CN("11/element/18.html","type",false,null)))),
					new Array(),
					new Array(new CN("11/element/vendorNotification.html","vendorNotification",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/vdn/v1"] = "11/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/vob/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("12/complextype/VendorObjectListType.html","VendorObjectListType",false,null),new CN("12/complextype/VendorObjectType.html","VendorObjectType",false,null)),
					new Array(),
					new Array(new CN("12/element/vendorObject.html","vendorObject",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/vob/v1"] = "12/index.html";
								   


