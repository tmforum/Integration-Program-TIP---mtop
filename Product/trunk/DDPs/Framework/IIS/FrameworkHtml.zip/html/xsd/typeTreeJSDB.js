﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_tiFileName = "typeTreeIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function TN (href, prefix, ns, name, relation, simpletypeflag, children) {
	this.href = href;
	this.prefix = prefix;
	this.namespace = ns;
	this.name = name;
	this.relation = relation;
	this.simpletypeflag = simpletypeflag;
	this.children = children;

	this.hasChild = (children != null) && (children.length>0);	
}

function T (typeTree)
{
	this.typeTree = typeTree;
}

function typetree_showAllTypes() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_tiFileName;
}

function typetree_filterTypes () {
	parent._href = "xsd/" + xsd_tiFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");
}

function typetree_showTypes() {
	if (parent._xsdNsFilter == null) {
		typetree_setFilterToAll();
	}

	var nsList = parent._xsdNsFilter;
	var typetrees = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		typetrees [i] = typetreeDB [nsList[i]];	
		nss[i] = nsList[i];
	}		
	
	typetree_showTree (nss, typetrees); 
}

function typetree_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in typetreeDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}


	parent._xsdNsFilter = nsList;
}


function typetree_showTree (nsList, typetrees) {
	for (var i=0; i<nsList.length; i++) {
		var fpath = typetreeNSMap[nsList[i]];
		
		var str = '<div class="nsBox"><div class="itemNS">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+fpath+
			'" title="'+encodeURI(nsList[i])+
			'" target="'+target+'">'+encodeURI(nsList[i])+'</a></nobr></div>'+
			'<div style="margin-left: 0.5em">';		

		document.write (str);

		typetree_outputList (typetrees[i].typeTree);
		

		document.write ('</div></div>');
	}
} 

function typetree_outputList (list) {
	for (var i=0; i<list.length; i++) {
		typetree_outputTree (list[i]);
	}
}

function typetree_outputTree (node) {
	if (node.hasChild == false) {
		typetree_outputLeaf (node);
	} else {
		typetree_outputNonLeaf (node);
	}
}


function typetree_outputLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node)
	} else {
		nodeStr = anchorString (node)
	}

	str = '<span class="leaf"><nobr>' +
		  '<img src="img/leaf.gif" hspace="2" align="middle">' + 
		  nodeStr + '</nobr></span><br />';

	document.write (str);
}

function prefixedAnchorString (node) {
	return  '<a class="chref" href="'+node.href+
			'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+
			node.prefix+':'+'</a>'+
			'<a class="chref" href="'+node.href+'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);
}

function anchorString (node) {
	return 	'<a class="chref" href="'+node.href+'" target="'+target+'"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);

}

function typetree_outputNonLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node);
	} else {
		nodeStr = anchorString (node);
	}
		
	str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			nodeStr +
			'</nobr></div>'+
			'<div style="margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		typetree_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function typetree_getNodeIcon(node) {
	var rStr = null;
	if (node.relation == "none") {
		rStr = "";
	} else if (node.relation == "extension") {
		rStr = '<img alt="derived by extension" border="0" hspace="2" align="middle" src="img/extension.gif">';
	
	} else if (node.relation == "restriction") {
		rStr = '<img alt="derived by restriction" border="0" hspace="2" align="middle" src="img/restriction.gif">';
	
	} else if (node.relation == "list") {
		rStr = '<img alt="derived by list" border="0" hspace="2" align="middle" src="img/list.gif">';
	
	} else if (node.relation == "union") {
		rStr = '<img alt="derived by union" border="0" hspace="2" align="middle" src="img/union.gif">';
	
	}
	
	var typeStr = null;
	
	if (node.simpletypeflag) {
		typeStr = '<img alt="simple type" border="0" hspace="2" align="middle" src="img/simple.gif">'; 
	} else {
		typeStr = '<img alt="complex type" border="0" hspace="2" align="middle" src="img/complex.gif">';	
	} 

	return typeStr + rStr;
}

var typetreeDB = new Array();
var typetreeNSMap = new Array();

typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("8/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("21/complextype/AttributeValueChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/avc/v1","AttributeValueChangeType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] = "21/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("8/complextype/EventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","extension",false,null),new TN("16/complextype/EventLossClearedType.html","","http://www.tmforum.org/mtop/fmw/xsd/elc/v1","EventLossClearedType","extension",false,null),new TN("9/complextype/EventLossOccuredType.html","","http://www.tmforum.org/mtop/fmw/xsd/elo/v1","EventLossOccuredType","extension",false,null),new TN("17/complextype/FileTransferStatusType.html","","http://www.tmforum.org/mtop/fmw/xsd/fts/v1","FileTransferStatusType","extension",false,null),new TN("1/complextype/ObjectDiscoveryType.html","","http://www.tmforum.org/mtop/fmw/xsd/odis/v1","ObjectDiscoveryType","extension",false,null),new TN("11/complextype/VendorNotificationType.html","","http://www.tmforum.org/mtop/fmw/xsd/vdn/v1","VendorNotificationType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "2/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cocd/v1"] =  new T (new Array (new TN("13/complextype/CommonObjectSetDataType.html","cosd","http://www.tmforum.org/mtop/fmw/xsd/cosd/v1","CommonObjectSetDataType","none",false,new Array(new TN("14/complextype/CommonObjectCreateDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/cocd/v1","CommonObjectCreateDataType","restriction",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cocd/v1"] = "14/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new T (new Array (new TN("5/complextype/CommonObjectInfoType.html","","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("4/complextype/ManagementDomainType.html","","http://www.tmforum.org/mtop/fmw/xsd/md/v1","ManagementDomainType","extension",false,null),new TN("12/complextype/VendorObjectType.html","","http://www.tmforum.org/mtop/fmw/xsd/vob/v1","VendorObjectType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "5/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/comd/v1"] =  new T (new Array (new TN("13/complextype/CommonObjectSetDataType.html","cosd","http://www.tmforum.org/mtop/fmw/xsd/cosd/v1","CommonObjectSetDataType","none",false,new Array(new TN("15/complextype/CommonObjectModifyDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/comd/v1","CommonObjectModifyDataType","restriction",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/comd/v1"] = "15/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cornot/v1"] =  new T (new Array (new TN("20/complextype/CorrelatedNotificationListType.html","","http://www.tmforum.org/mtop/fmw/xsd/cornot/v1","CorrelatedNotificationListType","none",false,null),new TN("20/complextype/CorrelatedNotificationsType.html","","http://www.tmforum.org/mtop/fmw/xsd/cornot/v1","CorrelatedNotificationsType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cornot/v1"] = "20/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cosd/v1"] =  new T (new Array (new TN("13/complextype/CommonObjectSetDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/cosd/v1","CommonObjectSetDataType","none",false,new Array(new TN("14/complextype/CommonObjectCreateDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/cocd/v1","CommonObjectCreateDataType","extension",false,null),new TN("15/complextype/CommonObjectModifyDataType.html","","http://www.tmforum.org/mtop/fmw/xsd/comd/v1","CommonObjectModifyDataType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cosd/v1"] = "13/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("8/complextype/EventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("21/complextype/AttributeValueChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/avc/v1","AttributeValueChangeType","extension",false,null),new TN("18/complextype/HeartbeatType.html","","http://www.tmforum.org/mtop/fmw/xsd/hbt/v1","HeartbeatType","extension",false,null),new TN("22/complextype/ObjectCreationType.html","","http://www.tmforum.org/mtop/fmw/xsd/oc/v1","ObjectCreationType","extension",false,null),new TN("7/complextype/ObjectDeletionType.html","","http://www.tmforum.org/mtop/fmw/xsd/odel/v1","ObjectDeletionType","extension",false,null),new TN("10/complextype/StateChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/sc/v1","StateChangeType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "8/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/elc/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("16/complextype/EventLossClearedType.html","","http://www.tmforum.org/mtop/fmw/xsd/elc/v1","EventLossClearedType","restriction",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/elc/v1"] = "16/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/elo/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("9/complextype/EventLossOccuredType.html","","http://www.tmforum.org/mtop/fmw/xsd/elo/v1","EventLossOccuredType","restriction",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/elo/v1"] = "9/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/fts/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("17/complextype/FileTransferStatusType.html","","http://www.tmforum.org/mtop/fmw/xsd/fts/v1","FileTransferStatusType","restriction",false,null))),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("17/simpletype/FileTransferStatusEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/fts/v1","FileTransferStatusEnumType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/fts/v1"] = "17/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new T (new Array (new TN("3/complextype/AliasNameListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AliasNameListType","none",false,null),new TN("3/complextype/AnyListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AnyListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#anyURI","xsd","http://www.w3.org/2001/XMLSchema","anyURI","none",true,new Array(new TN("3/simpletype/QueryDialectEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryDialectEnumType","restriction",true,null),new TN("3/simpletype/QueryDialectTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryDialectTypeType","restriction",true,null))),new TN("http://www.w3.org/TR/xmlschema-2/#date","xsd","http://www.w3.org/2001/XMLSchema","date","none",true,new Array(new TN("3/simpletype/ManufactureDateType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufactureDateType","restriction",true,null))),new TN("3/complextype/MultiEventInventoryAttributesType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","MultiEventInventoryAttributesType","none",false,null),new TN("3/complextype/NameAndAnyValueListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndAnyValueListType","none",false,null),new TN("3/complextype/NameAndAnyValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndAnyValueType","none",false,null),new TN("3/complextype/NameAndStringValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndStringValueType","none",false,null),new TN("3/complextype/NameAndValueStringListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NameAndValueStringListType","none",false,null),new TN("3/complextype/NotificationIdentifierListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierListType","none",false,null),new TN("3/complextype/QueryExpressionType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","QueryExpressionType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("3/simpletype/DiscoveredNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","DiscoveredNameType","restriction",true,null),new TN("3/simpletype/LocationType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","LocationType","restriction",true,null),new TN("3/simpletype/ManufacturerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufacturerType","restriction",true,null),new TN("3/simpletype/NamingOperationsSystemType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NamingOperationsSystemType","restriction",true,null),new TN("3/simpletype/NetworkAccessDomainType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NetworkAccessDomainType","restriction",true,null),new TN("3/simpletype/NotificationIdentifierType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierType","restriction",true,null),new TN("3/simpletype/ObjectEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectEnumType","restriction",true,null),new TN("3/simpletype/ObjectTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectTypeType","restriction",true,null),new TN("3/simpletype/OwnerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","OwnerType","restriction",true,null),new TN("3/simpletype/ProductNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ProductNameType","restriction",true,null),new TN("3/simpletype/UserLabelType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","UserLabelType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "3/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/hbt/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("8/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("18/complextype/HeartbeatType.html","","http://www.tmforum.org/mtop/fmw/xsd/hbt/v1","HeartbeatType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hbt/v1"] = "18/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] =  new T (new Array (new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("25/simpletype/ActivityStatusEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","ActivityStatusEnumType","restriction",true,new Array(new TN("25/complextype/ActivityStatusType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","ActivityStatusType","restriction",false,null))),new TN("25/simpletype/CommunicationPatternType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","CommunicationPatternType","restriction",true,null),new TN("25/simpletype/CommunicationStyleType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","CommunicationStyleType","restriction",true,null),new TN("25/simpletype/CompressionEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","CompressionEnumType","restriction",true,new Array(new TN("25/complextype/CompressionTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","CompressionTypeType","restriction",false,null))),new TN("25/simpletype/MessageTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","MessageTypeType","restriction",true,null),new TN("25/simpletype/PackingEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","PackingEnumType","restriction",true,new Array(new TN("25/complextype/PackingTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/hdr/v1","PackingTypeType","restriction",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] = "25/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/mart/v1"] =  new T (new Array (new TN("24/complextype/OperationResultType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","OperationResultType","none",false,null),new TN("24/complextype/OperationSetResultType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","OperationSetResultType","none",false,null),new TN("24/complextype/OperationSetStateType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","OperationSetStateType","none",false,null),new TN("24/complextype/OperationSetType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","OperationSetType","none",false,null),new TN("24/complextype/OperationStateType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","OperationStateType","none",false,null),new TN("24/complextype/OperationType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","OperationType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("24/simpletype/FailPolicyType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","FailPolicyType","restriction",true,null),new TN("24/simpletype/OperationEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","OperationEnumType","restriction",true,null),new TN("24/simpletype/OrderType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","OrderType","restriction",true,null),new TN("24/simpletype/ResultType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","ResultType","restriction",true,null),new TN("24/simpletype/StateType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","StateType","restriction",true,null))),new TN("24/complextype/TemplateListType.html","","http://www.tmforum.org/mtop/fmw/xsd/mart/v1","TemplateListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/mart/v1"] = "24/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/md/v1"] =  new T (new Array (new TN("5/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("4/complextype/ManagementDomainType.html","","http://www.tmforum.org/mtop/fmw/xsd/md/v1","ManagementDomainType","restriction",false,null))),new TN("4/complextype/ManagementDomainListType.html","","http://www.tmforum.org/mtop/fmw/xsd/md/v1","ManagementDomainListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/md/v1"] = "4/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] =  new T (new Array (new TN("23/complextype/AllExceptionsType.html","","http://www.tmforum.org/mtop/fmw/xsd/msg/v1","AllExceptionsType","none",false,new Array(new TN("23/complextype/GetAllDataIteratorExceptionType.html","","http://www.tmforum.org/mtop/fmw/xsd/msg/v1","GetAllDataIteratorExceptionType","restriction",false,null))),new TN("23/complextype/BaseExceptionMessageType.html","","http://www.tmforum.org/mtop/fmw/xsd/msg/v1","BaseExceptionMessageType","none",false,null),new TN("23/complextype/GetAllDataIteratorRequestType.html","","http://www.tmforum.org/mtop/fmw/xsd/msg/v1","GetAllDataIteratorRequestType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] = "23/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new T (new Array (new TN("6/complextype/NamingAttributeListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeListType","none",false,null),new TN("6/complextype/NamingAttributeType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeType","none",false,null),new TN("6/complextype/RelativeDistinguishNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","RelativeDistinguishNameType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "6/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1"] =  new T (new Array (new TN("http://www.w3.org/TR/xmlschema-2/#anyURI","xsd","http://www.w3.org/2001/XMLSchema","anyURI","none",true,new Array(new TN("19/simpletype/EndPointReferenceType.html","","http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1","EndPointReferenceType","restriction",true,null))),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("19/simpletype/SubscriptionIdentifierType.html","","http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1","SubscriptionIdentifierType","restriction",true,null),new TN("19/simpletype/TopicExpressionType.html","","http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1","TopicExpressionType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/notmsg/v1"] = "19/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("8/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("22/complextype/ObjectCreationType.html","","http://www.tmforum.org/mtop/fmw/xsd/oc/v1","ObjectCreationType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] = "22/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("8/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("7/complextype/ObjectDeletionType.html","","http://www.tmforum.org/mtop/fmw/xsd/odel/v1","ObjectDeletionType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] = "7/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("1/complextype/ObjectDiscoveryType.html","","http://www.tmforum.org/mtop/fmw/xsd/odis/v1","ObjectDiscoveryType","restriction",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] = "1/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("8/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("10/complextype/StateChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/sc/v1","StateChangeType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] = "10/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/vdn/v1"] =  new T (new Array (new TN("2/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("11/complextype/VendorNotificationType.html","","http://www.tmforum.org/mtop/fmw/xsd/vdn/v1","VendorNotificationType","restriction",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/vdn/v1"] = "11/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/vob/v1"] =  new T (new Array (new TN("5/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("12/complextype/VendorObjectType.html","","http://www.tmforum.org/mtop/fmw/xsd/vob/v1","VendorObjectType","restriction",false,null))),new TN("12/complextype/VendorObjectListType.html","","http://www.tmforum.org/mtop/fmw/xsd/vob/v1","VendorObjectListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/vob/v1"] = "12/index.html";
								   


