﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_ciFileName = "componentIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function CN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function C (attributeList, attributeGroupList,
						simpleTypeList, complexTypeList,
						modelGroupList, elementList, 
						notationList) 
{
	this.attributes = attributeList;
	this.attributegroups = attributeGroupList;
	this.simpletypes = simpleTypeList;
	this.complextypes = complexTypeList;
	this.modelgroups = modelGroupList;
	this.elements = elementList;
	this.notations = notationList;
}

function component_showAllComponents() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_ciFileName;
}

function component_filterComponents () {
	parent._href = "xsd/" + xsd_ciFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function component_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href=xsd_ciFileName;	
}

function component_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in componentDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}

	parent._xsdNsFilter = nsList;
}

function component_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	component_outputList (null, components);	
}


function component_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		component_outputList (namespace, list);	
	}
}


function component_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		component_showComponentsNS (nsList, componentList)
	} else {
		component_showComponentsNoNS (nsList, componentList)
	}
}

function component_showAttributes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		attributes [i] = componentDB [nsList[i]].attributes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributes);
}

function component_showAttributeGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributegroups = new Array();
	var nss = new Array();		

	for (var i=0; i<nsList.length; i++) {
		attributegroups [i] = componentDB [nsList[i]].attributegroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributegroups);
}

function component_showSimpleTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var simpletypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		simpletypes [i] = componentDB [nsList[i]].simpletypes;	
		nss [i] = nsList[i];
	}		

	component_showComponents (nss, simpletypes);
}

function component_showComplexTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var complextypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		complextypes [i] = componentDB [nsList[i]].complextypes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, complextypes);
}

function component_showElements() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var elements = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		elements [i] = componentDB [nsList[i]].elements;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, elements);
}

function component_showModelGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var modelgroups = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		modelgroups [i] = componentDB [nsList[i]].modelgroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, modelgroups);
}

function component_showNotations() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var notations = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		notations [i] = componentDB [nsList[i]].notations;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, notations);

}


function component_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function component_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+component_getNodeText(node)+
			  '" target="'+target+'">'+component_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function component_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+component_getNodeText(node)+
			'" target="'+target+'">'+component_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		component_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function component_outputTree (node) {
	if (node.hasChild == false) {
		component_outputLeaf (node);
	} else {
		component_outputNonLeaf (node);
	}
}

function component_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = componentNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+target+'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		component_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}


var componentDB = new Array();
var componentNSMap = new Array();

componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("22/complextype/CommonEventInformationType.html","CommonEventInformationType",false,new Array(new CN("22/element/65.html","notificationId",false,null),new CN("22/element/66.html","sourceTime",false,null),new CN("22/element/67.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("22/element/commonEventInformation.html","commonEventInformation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "22/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("2/complextype/CommonObjectInfoType.html","CommonObjectInfoType",false,new Array(new CN("2/element/1.html","name",false,null),new CN("2/element/2.html","userLabel",false,null),new CN("2/element/3.html","discoveredName",false,null),new CN("2/element/4.html","namingOs",false,null),new CN("2/element/5.html","owner",false,null),new CN("2/element/6.html","aliasNameList",false,null),new CN("2/element/7.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("2/element/commonObjectInfo.html","commonObjectInfo",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "2/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cornot/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("25/complextype/CorrelatedNotificationListType.html","CorrelatedNotificationListType",false,new Array(new CN("25/element/99.html","correlatedNotifications",false,null))),new CN("25/complextype/CorrelatedNotificationsType.html","CorrelatedNotificationsType",false,new Array(new CN("25/element/203.html","name",false,null),new CN("25/element/239.html","notifIds",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cornot/v1"] = "25/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("23/complextype/EventInformationType.html","EventInformationType",false,new Array(new CN("23/element/68.html","objectType",false,null),new CN("23/element/69.html","objectName",false,null),new CN("23/element/70.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "23/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("4/simpletype/DiscoveredNameType.html","DiscoveredNameType",false,null),new CN("4/simpletype/LocationType.html","LocationType",false,null),new CN("4/simpletype/ManufactureDateType.html","ManufactureDateType",false,null),new CN("4/simpletype/ManufacturerType.html","ManufacturerType",false,null),new CN("4/simpletype/NamingOperationsSystemType.html","NamingOperationsSystemType",false,null),new CN("4/simpletype/NetworkAccessDomainType.html","NetworkAccessDomainType",false,null),new CN("4/simpletype/NotificationIdentifierType.html","NotificationIdentifierType",false,null),new CN("4/simpletype/ObjectEnumType.html","ObjectEnumType",false,null),new CN("4/simpletype/ObjectTypeType.html","ObjectTypeType",false,null),new CN("4/simpletype/OwnerType.html","OwnerType",false,null),new CN("4/simpletype/ProductNameType.html","ProductNameType",false,null),new CN("4/simpletype/UserLabelType.html","UserLabelType",false,null)),
					new Array(new CN("4/complextype/AliasNameListType.html","AliasNameListType",false,new Array(new CN("4/element/92.html","alias",false,null),new CN("4/element/93.html","alias/aliasName",false,null),new CN("4/element/94.html","alias/aliasValue",false,null))),new CN("4/complextype/AnyListType.html","AnyListType",false,null),new CN("4/complextype/MultiEventInventoryAttributesType.html","MultiEventInventoryAttributesType",false,new Array(new CN("4/element/220.html","neTime",false,null),new CN("4/element/221.html","eventIndication",false,null))),new CN("4/complextype/NotificationIdentifierListType.html","NotificationIdentifierListType",false,new Array(new CN("4/element/237.html","notificationId",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "4/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("3/complextype/NameAndAnyValueListType.html","NameAndAnyValueListType",false,new Array(new CN("3/element/102.html","nv",false,null))),new CN("3/complextype/NameAndAnyValueType.html","NameAndAnyValueType",false,new Array(new CN("3/element/197.html","name",false,null))),new CN("3/complextype/NameAndStringValueType.html","NameAndStringValueType",false,new Array(new CN("3/element/198.html","name",false,null),new CN("3/element/199.html","value",false,null))),new CN("3/complextype/NameAndValueStringListType.html","NameAndValueStringListType",false,new Array(new CN("3/element/100.html","nvs",false,null))),new CN("3/complextype/NamingAttributeListType.html","NamingAttributeListType",false,new Array(new CN("3/element/15.html","name",false,null))),new CN("3/complextype/NamingAttributeType.html","NamingAttributeType",false,new Array(new CN("3/element/23.html","object",false,null),new CN("3/element/24.html","object/type",false,null),new CN("3/element/25.html","object/name",false,null)))),
					new Array(),
					new Array(new CN("3/element/nvList.html","nvList",false,null),new CN("3/element/nvsList.html","nvsList",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "3/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/alarmid/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("16/complextype/AlarmIdType.html","AlarmIdType",false,new Array(new CN("16/element/51.html","objectName",false,null),new CN("16/element/52.html","layerRate",false,null),new CN("16/element/53.html","probableCause",false,null),new CN("16/element/54.html","probableCauseQualifier",false,null)))),
					new Array(),
					new Array(new CN("16/element/alarmId.html","alarmId",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/alarmid/v1"] = "16/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/alm/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("21/complextype/AlarmListType.html","AlarmListType",false,new Array(new CN("21/element/64.html","alarm",false,null))),new CN("21/complextype/AlarmType.html","AlarmType",false,new Array(new CN("21/element/71.html","isEdgePointRelated",false,null),new CN("21/element/72.html","isClearable",false,null),new CN("21/element/73.html","aliasNameList",false,null),new CN("21/element/74.html","layerRate",false,null),new CN("21/element/75.html","probableCause",false,null),new CN("21/element/76.html","nativeProbableCause",false,null),new CN("21/element/77.html","additionalText",false,null),new CN("21/element/78.html","perceivedSeverity",false,null),new CN("21/element/79.html","affectedTpRefList",false,null),new CN("21/element/80.html","serviceAffecting",false,null),new CN("21/element/81.html","rootCauseAlarmIndication",false,null),new CN("21/element/82.html","acknowledgement",false,null),new CN("21/element/83.html","X733_EventType",false,null),new CN("21/element/84.html","X733_SpecificProblems",false,null),new CN("21/element/85.html","X733_BackedUpStatus",false,null),new CN("21/element/86.html","X733_BackUpObjectRef",false,null),new CN("21/element/87.html","X733_TrendIndication",false,null),new CN("21/element/88.html","X733_CorrelatedNotificationList",false,null),new CN("21/element/89.html","X733_MonitoredAttributeList",false,null),new CN("21/element/90.html","X733_ProposedRepairActionList",false,null),new CN("21/element/91.html","X733_AdditionalInformation",false,null)))),
					new Array(),
					new Array(new CN("21/element/alarm.html","alarm",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/alm/v1"] = "21/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/asa/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("32/complextype/AlarmSeverityAssignmentListType.html","AlarmSeverityAssignmentListType",false,new Array(new CN("32/element/214.html","alarmSeverityAssignment",false,null))),new CN("32/complextype/AlarmSeverityAssignmentType.html","AlarmSeverityAssignmentType",false,new Array(new CN("32/element/213.html","probableCause",false,null),new CN("32/element/166.html","probableCauseQualifier",false,null),new CN("32/element/163.html","nativeProbableCause",false,null),new CN("32/element/171.html","serviceAffectingSeverity",false,null),new CN("32/element/170.html","nonServiceAffectingSeverity",false,null),new CN("32/element/172.html","serviceIndependentSeverity",false,null)))),
					new Array(),
					new Array(new CN("32/element/asa.html","asa",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/asa/v1"] = "32/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/asap/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("38/complextype/AlarmSeverityAssignmentProfileListType.html","AlarmSeverityAssignmentProfileListType",false,null),new CN("38/complextype/AlarmSeverityAssignmentProfileType.html","AlarmSeverityAssignmentProfileType",false,new Array(new CN("38/element/247.html","isFixed",false,null),new CN("38/element/215.html","alarmSeverityAssignmentList",false,null)))),
					new Array(),
					new Array(new CN("38/element/asap.html","asap",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/asap/v1"] = "38/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/atcaid/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("15/complextype/AlarmOrTcaIdListType.html","AlarmOrTcaIdListType",false,null),new CN("15/complextype/AlarmOrTcaIdType.html","AlarmOrTcaIdType",false,new Array(new CN("15/element/49.html","alarmId",false,null),new CN("15/element/50.html","tcaId",false,null)))),
					new Array(),
					new Array(new CN("15/element/alarmOrTcaId.html","alarmOrTcaId",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/atcaid/v1"] = "15/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/cmo/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("37/simpletype/MaintenanceOperationEnumType.html","MaintenanceOperationEnumType",false,null),new CN("37/simpletype/MaintenanceOperationModeEnumType.html","MaintenanceOperationModeEnumType",false,null),new CN("37/simpletype/MaintenanceOperationType.html","MaintenanceOperationType",false,null)),
					new Array(new CN("37/complextype/CurrentMaintenanceOperationListType.html","CurrentMaintenanceOperationListType",false,new Array(new CN("37/element/217.html","maintenanceOperation",false,null))),new CN("37/complextype/CurrentMaintenanceOperationType.html","CurrentMaintenanceOperationType",false,new Array(new CN("37/element/204.html","tpName",false,null),new CN("37/element/216.html","maintenanceOperation",false,null),new CN("37/element/218.html","layerRate",false,null),new CN("37/element/219.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/cmo/v1"] = "37/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/com/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("24/simpletype/AcknowledgeIndicationType.html","AcknowledgeIndicationType",true,null),new CN("24/simpletype/AssignedSeverityEnumType.html","AssignedSeverityEnumType",false,null),new CN("24/simpletype/EquipmentProtectionGroupTypeEnumType.html","EquipmentProtectionGroupTypeEnumType",false,null),new CN("24/simpletype/EquipmentSwitchReasonEnumType.html","EquipmentSwitchReasonEnumType",false,null),new CN("24/simpletype/G_774_3_APSfunctionEnumType.html","G_774_3_APSfunctionEnumType",false,null),new CN("24/simpletype/NativeProbableCauseType.html","NativeProbableCauseType",false,null),new CN("24/simpletype/PerceivedSeverityType.html","PerceivedSeverityType",false,null),new CN("24/simpletype/ProbableCauseQualifierType.html","ProbableCauseQualifierType",false,null),new CN("24/simpletype/ProposedRepairActionType.html","ProposedRepairActionType",false,null),new CN("24/simpletype/ProtectionCommandType.html","ProtectionCommandType",false,null),new CN("24/simpletype/ProtectionGroupTypeEnumType.html","ProtectionGroupTypeEnumType",false,null),new CN("24/simpletype/ProtectionTypeEnumType.html","ProtectionTypeEnumType",false,null),new CN("24/simpletype/ReversionModeType.html","ReversionModeType",false,null),new CN("24/simpletype/ServiceAffectingType.html","ServiceAffectingType",false,null),new CN("24/simpletype/SpecificProblemType.html","SpecificProblemType",false,null),new CN("24/simpletype/SwitchReasonType.html","SwitchReasonType",false,null)),
					new Array(new CN("24/complextype/AssignedSeverityType.html","AssignedSeverityType",false,null),new CN("24/complextype/EquipmentProtectionGroupTypeType.html","EquipmentProtectionGroupTypeType",false,null),new CN("24/complextype/EquipmentSwitchReasonType.html","EquipmentSwitchReasonType",false,null),new CN("24/complextype/G_774_3_APSfunctionType.html","G_774_3_APSfunctionType",false,null),new CN("24/complextype/PerceivedSeverityListType.html","PerceivedSeverityListType",false,new Array(new CN("24/element/164.html","perceivedSeverity",false,null))),new CN("24/complextype/ProposedRepairActionListType.html","ProposedRepairActionListType",false,new Array(new CN("24/element/101.html","proposedRepairAction",false,null))),new CN("24/complextype/ProtectionGroupTypeType.html","ProtectionGroupTypeType",false,null),new CN("24/complextype/ProtectionTypeType.html","ProtectionTypeType",false,null),new CN("24/complextype/SpecificProblemListType.html","SpecificProblemListType",false,new Array(new CN("24/element/98.html","specificProblem",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/com/v1"] = "24/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/epg/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("12/complextype/EquipmentProtectionGroupListType.html","EquipmentProtectionGroupListType",false,null),new CN("12/complextype/EquipmentProtectionGroupType.html","EquipmentProtectionGroupType",false,new Array(new CN("12/element/173.html","type",false,null),new CN("12/element/47.html","protectionSchemeState",false,null),new CN("12/element/167.html","reversionMode",false,null),new CN("12/element/41.html","parameterList",false,null),new CN("12/element/200.html","protectedEquipmentRefList",false,null),new CN("12/element/201.html","protectingEquipmentRefList",false,null),new CN("12/element/241.html","asapRef",false,null)))),
					new Array(),
					new Array(new CN("12/element/epgp.html","epgp",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/epg/v1"] = "12/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/eps/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("35/complextype/EquipmentProtectionSwitchListType.html","EquipmentProtectionSwitchListType",false,new Array(new CN("35/element/245.html","equipmentProtectionSwitch",false,null))),new CN("35/complextype/EquipmentProtectionSwitchType.html","EquipmentProtectionSwitchType",false,new Array(new CN("35/element/246.html","osTime",false,null),new CN("35/element/174.html","epgType",false,null),new CN("35/element/176.html","equipmentSwitchReason",false,null),new CN("35/element/205.html","epgRef",false,null),new CN("35/element/206.html","protectedEquipmentRef",false,null),new CN("35/element/207.html","switchAwayFromEquipmentRef",false,null),new CN("35/element/208.html","switchToEquipmentRef",false,null)))),
					new Array(),
					new Array(new CN("35/element/equipmentProtectionSwitch.html","equipmentProtectionSwitch",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/eps/v1"] = "35/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/esd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("36/complextype/EquipmentSwitchDataListType.html","EquipmentSwitchDataListType",false,new Array(new CN("36/element/192.html","equipmentSwitchData",false,null))),new CN("36/complextype/EquipmentSwitchDataType.html","EquipmentSwitchDataType",false,new Array(new CN("36/element/175.html","equipmentProtectionGroupType",false,null),new CN("36/element/177.html","equipmentSwitchReason",false,null),new CN("36/element/193.html","epgName",false,null),new CN("36/element/194.html","protectedEquipment",false,null),new CN("36/element/195.html","switchToEquipment",false,null),new CN("36/element/196.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/esd/v1"] = "36/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pg/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("13/complextype/ProtectionGroupListType.html","ProtectionGroupListType",false,null),new CN("13/complextype/ProtectionGroupType.html","ProtectionGroupType",false,new Array(new CN("13/element/179.html","type",false,null),new CN("13/element/48.html","protectionSchemeState",false,null),new CN("13/element/168.html","reversionMode",false,null),new CN("13/element/242.html","layerRate",false,null),new CN("13/element/42.html","parameterList",false,null),new CN("13/element/202.html","protectionRelatedTpRefList",false,null),new CN("13/element/178.html","apsProtocolType",false,null),new CN("13/element/244.html","asapRef",false,null)))),
					new Array(),
					new Array(new CN("13/element/pg.html","pg",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pg/v1"] = "13/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pgp/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("11/simpletype/AvailabilityStatusEnumType.html","AvailabilityStatusEnumType",false,null),new CN("11/simpletype/BundleSwitchingType.html","BundleSwitchingType",false,null),new CN("11/simpletype/ExerciseOnType.html","ExerciseOnType",false,null),new CN("11/simpletype/HitlessType.html","HitlessType",false,null),new CN("11/simpletype/HoldOffTimeType.html","HoldOffTimeType",false,null),new CN("11/simpletype/LodDurationType.html","LodDurationType",false,null),new CN("11/simpletype/LodNumSwitchesType.html","LodNumSwitchesType",false,null),new CN("11/simpletype/NonPreEmptibleTrafficType.html","NonPreEmptibleTrafficType",false,null),new CN("11/simpletype/PrivilegedChannelType.html","PrivilegedChannelType",false,null),new CN("11/simpletype/SpringNodeIdType.html","SpringNodeIdType",false,null),new CN("11/simpletype/SpringProtocolEnumType.html","SpringProtocolEnumType",false,null),new CN("11/simpletype/SwitchCriteriaEnableEnumType.html","SwitchCriteriaEnableEnumType",false,null),new CN("11/simpletype/SwitchModeEnumType.html","SwitchModeEnumType",false,null),new CN("11/simpletype/SwitchPositionType.html","SwitchPositionType",false,null),new CN("11/simpletype/TandemSwitchingType.html","TandemSwitchingType",false,null),new CN("11/simpletype/WtrTimeType.html","WtrTimeType",false,null)),
					new Array(new CN("11/complextype/AvailabilityStatusType.html","AvailabilityStatusType",false,null),new CN("11/complextype/ProtectionGroupParameterListType.html","ProtectionGroupParameterListType",false,new Array(new CN("11/element/40.html","pgParameter",false,null))),new CN("11/complextype/ProtectionGroupParameterType.html","ProtectionGroupParameterType",false,new Array(new CN("11/element/43.html","switchMode",false,null),new CN("11/element/44.html","springProtocol",false,null),new CN("11/element/35.html","springNodeId",false,null),new CN("11/element/36.html","switchPosition",false,null),new CN("11/element/33.html","nonPreEmptibleTraffic",false,null),new CN("11/element/38.html","wtrTime",false,null),new CN("11/element/30.html","holdOffTime",false,null),new CN("11/element/32.html","lodNumSwitches",false,null),new CN("11/element/31.html","lodDuration",false,null),new CN("11/element/37.html","tandemSwitching",false,null),new CN("11/element/27.html","bundleSwitching",false,null),new CN("11/element/29.html","hitless",false,null),new CN("11/element/28.html","exerciseOn",false,null),new CN("11/element/39.html","availabilityStatus",false,null),new CN("11/element/45.html","switchCriteriaEnable",false,null),new CN("11/element/34.html","privilegedChannel",false,null),new CN("11/element/46.html","vendorExtensions",false,null))),new CN("11/complextype/SpringProtocolType.html","SpringProtocolType",false,null),new CN("11/complextype/SwitchCriteriaEnableType.html","SwitchCriteriaEnableType",false,null),new CN("11/complextype/SwitchModeType.html","SwitchModeType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pgp/v1"] = "11/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pm/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("9/simpletype/HoldingTimeType.html","HoldingTimeType",false,null),new CN("9/simpletype/PmGranularityType.html","PmGranularityType",false,null),new CN("9/simpletype/PmIntervalStatusType.html","PmIntervalStatusType",false,null),new CN("9/simpletype/PmLocationType.html","PmLocationType",false,null),new CN("9/simpletype/PmParameterNameType.html","PmParameterNameType",false,null),new CN("9/simpletype/PmThresholdTypeType.html","PmThresholdTypeType",false,null),new CN("9/simpletype/TriggerType.html","TriggerType",false,null)),
					new Array(new CN("9/complextype/PmGranularityListType.html","PmGranularityListType",false,new Array(new CN("9/element/110.html","pmGranularity",false,null))),new CN("9/complextype/PmLocationListType.html","PmLocationListType",false,new Array(new CN("9/element/109.html","pmLocation",false,null))),new CN("9/complextype/PmParameterNameListType.html","PmParameterNameListType",false,new Array(new CN("9/element/128.html","pmParameterName",false,null)))),
					new Array(),
					new Array(new CN("9/element/pmParameterName.html","pmParameterName",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pm/v1"] = "9/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmdata/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("8/complextype/PmDataListType.html","PmDataListType",false,new Array(new CN("8/element/17.html","pmData",false,null))),new CN("8/complextype/PmDataType.html","PmDataType",false,new Array(new CN("8/element/18.html","tpName",false,null),new CN("8/element/19.html","layerRate",false,null),new CN("8/element/20.html","granularity",false,null),new CN("8/element/21.html","retrievalTime",false,null),new CN("8/element/22.html","pmMeasurementList",false,null)))),
					new Array(),
					new Array(new CN("8/element/pmData.html","pmData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmdata/v1"] = "8/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("10/complextype/PmMeasurementListType.html","PmMeasurementListType",false,new Array(new CN("10/element/26.html","pmMeasurement",false,null))),new CN("10/complextype/PmMeasurementType.html","PmMeasurementType",false,new Array(new CN("10/element/187.html","pmParameterName",false,null),new CN("10/element/188.html","pmLocation",false,null),new CN("10/element/189.html","value",false,null),new CN("10/element/190.html","measurementUnits",false,null),new CN("10/element/191.html","pmIntervalStatus",false,null)))),
					new Array(),
					new Array(new CN("10/element/pmMeasurement.html","pmMeasurement",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1"] = "10/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmp/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("28/complextype/PerformanceMonitoringPointListType.html","PerformanceMonitoringPointListType",false,new Array(new CN("28/element/120.html","pmp",false,null))),new CN("28/complextype/PerformanceMonitoringPointType.html","PerformanceMonitoringPointType",false,new Array(new CN("28/element/121.html","layerRate",false,null),new CN("28/element/122.html","pmLocation",false,null),new CN("28/element/123.html","granularity",false,null),new CN("28/element/124.html","supervisionState",false,null),new CN("28/element/125.html","monitoringState",false,null),new CN("28/element/126.html","pmParameterList",false,null),new CN("28/element/127.html","pmThresholdList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmp/v1"] = "28/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmpar/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("39/complextype/PmParameterListType.html","PmParameterListType",false,new Array(new CN("39/element/240.html","pmParameter",false,null))),new CN("39/complextype/PmParameterType.html","PmParameterType",false,new Array(new CN("39/element/225.html","pmParameter",false,null),new CN("39/element/223.html","pmLocation",false,null)))),
					new Array(),
					new Array(new CN("39/element/pmParameter.html","pmParameter",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmpar/v1"] = "39/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmparth/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("40/complextype/PmParameterWithThresholdsListType.html","PmParameterWithThresholdsListType",false,new Array(new CN("40/element/248.html","pmParameterWithThreshold",false,null))),new CN("40/complextype/PmParameterWithThresholdsType.html","PmParameterWithThresholdsType",false,new Array(new CN("40/element/226.html","pmParameterName",false,null),new CN("40/element/233.html","pmThresholdList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmparth/v1"] = "40/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("31/complextype/PerformanceMonitoringPointStateChangeType.html","PerformanceMonitoringPointStateChangeType",false,new Array(new CN("31/element/130.html","pmNameList",false,null),new CN("31/element/131.html","attributeList",false,null)))),
					new Array(),
					new Array(new CN("31/element/performanceMonitoringPointStateChange.html","performanceMonitoringPointStateChange",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1"] = "31/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("26/complextype/PmObjectSelectListType.html","PmObjectSelectListType",false,new Array(new CN("26/element/103.html","pmObjectSelect",false,null))),new CN("26/complextype/PmObjectSelectType.html","PmObjectSelectType",false,new Array(new CN("26/element/104.html","name",false,null),new CN("26/element/105.html","layerRates",false,null),new CN("26/element/106.html","pmLocationList",false,null),new CN("26/element/107.html","granularityList",false,null)))),
					new Array(),
					new Array(new CN("26/element/pmObjectSelect.html","pmObjectSelect",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1"] = "26/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmth/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("30/complextype/PmThresholdListType.html","PmThresholdListType",false,new Array(new CN("30/element/129.html","pmThreshold",false,null))),new CN("30/complextype/PmThresholdType.html","PmThresholdType",false,new Array(new CN("30/element/228.html","thresholdType",false,null),new CN("30/element/229.html","trigger",false,null),new CN("30/element/234.html","thresholdValue",false,null),new CN("30/element/235.html","thresholdUnit",false,null)))),
					new Array(),
					new Array(new CN("30/element/pmThreshold.html","pmThreshold",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmth/v1"] = "30/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/pmtv/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("20/complextype/PmThresholdValueListType.html","PmThresholdValueListType",false,new Array(new CN("20/element/63.html","pmThresholdValue",false,null))),new CN("20/complextype/PmThresholdValueType.html","PmThresholdValueType",false,new Array(new CN("20/element/181.html","pmParameterName",false,null),new CN("20/element/182.html","pmLocation",false,null),new CN("20/element/183.html","thresholdType",false,null),new CN("20/element/184.html","triggerFlag",false,null),new CN("20/element/185.html","value",false,null),new CN("20/element/186.html","units",false,null)))),
					new Array(),
					new Array(new CN("20/element/pmThresholdValue.html","pmThresholdValue",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmtv/v1"] = "20/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/prc/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("18/simpletype/ProbableCauseEnumType.html","ProbableCauseEnumType",false,null)),
					new Array(new CN("18/complextype/ProbableCauseListType.html","ProbableCauseListType",false,new Array(new CN("18/element/212.html","prc",false,null))),new CN("18/complextype/ProbableCauseType.html","ProbableCauseType",false,new Array(new CN("18/element/95.html","ru",false,null),new CN("18/element/96.html","contra",false,null),new CN("18/element/97.html","probableCause",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/prc/v1"] = "18/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/ps/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("27/complextype/ProtectionSwitchListType.html","ProtectionSwitchListType",false,new Array(new CN("27/element/111.html","protectionSwitch",false,null))),new CN("27/complextype/ProtectionSwitchType.html","ProtectionSwitchType",false,new Array(new CN("27/element/112.html","osTime",false,null),new CN("27/element/113.html","protectionType",false,null),new CN("27/element/114.html","switchReason",false,null),new CN("27/element/115.html","layerRate",false,null),new CN("27/element/116.html","groupNameRef",false,null),new CN("27/element/117.html","protectedTpRef",false,null),new CN("27/element/118.html","switchAwayFromTpRef",false,null),new CN("27/element/119.html","switchToTpRef",false,null)))),
					new Array(),
					new Array(new CN("27/element/protectionSwitch.html","protectionSwitch",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/ps/v1"] = "27/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/sd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("34/complextype/SwitchDataListType.html","SwitchDataListType",false,new Array(new CN("34/element/230.html","switchData",false,null))),new CN("34/complextype/SwitchDataType.html","SwitchDataType",false,new Array(new CN("34/element/180.html","protectionType",false,null),new CN("34/element/169.html","switchReason",false,null),new CN("34/element/231.html","layerRate",false,null),new CN("34/element/209.html","groupName",false,null),new CN("34/element/210.html","protectedTp",false,null),new CN("34/element/211.html","switchToTp",false,null),new CN("34/element/232.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/sd/v1"] = "34/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/tca/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("33/simpletype/AcknowledgeIndicationType.html","AcknowledgeIndicationType",true,null)),
					new Array(new CN("33/complextype/ThresholdCrossingAlertType.html","ThresholdCrossingAlertType",false,new Array(new CN("33/element/238.html","aliasNameList",false,null),new CN("33/element/250.html","isClearable",false,null),new CN("33/element/165.html","perceivedSeverity",false,null),new CN("33/element/243.html","layerRate",false,null),new CN("33/element/222.html","granularity",false,null),new CN("33/element/227.html","pmParameterName",false,null),new CN("33/element/224.html","parameterLocation",false,null),new CN("33/element/236.html","thresholdType",false,null),new CN("33/element/251.html","thresholdValue",false,null),new CN("33/element/252.html","thresholdUnit",false,null),new CN("33/element/249.html","acknowledgement",false,null),new CN("33/element/253.html","isEdgePointRelated",false,null)))),
					new Array(),
					new Array(new CN("33/element/thresholdCrossingAlert.html","thresholdCrossingAlert",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/tca/v1"] = "33/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/tcaid/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("17/complextype/TcaIdType.html","TcaIdType",false,new Array(new CN("17/element/55.html","objectName",false,null),new CN("17/element/56.html","layerRate",false,null),new CN("17/element/57.html","pmParameterName",false,null),new CN("17/element/58.html","pmLocation",false,null),new CN("17/element/59.html","granularity",false,null)))),
					new Array(),
					new Array(new CN("17/element/tcaId.html","tcaId",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/tcaid/v1"] = "17/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/tcapar/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("7/complextype/TcaParameterListType.html","TcaParameterListType",false,new Array(new CN("7/element/16.html","tcaParameterList",false,null))),new CN("7/complextype/TcaParameterType.html","TcaParameterType",false,new Array(new CN("7/element/132.html","pmParameterName",false,null),new CN("7/element/133.html","granularity",false,null),new CN("7/element/134.html","pmLocation",false,null),new CN("7/element/135.html","thresholdType",false,null),new CN("7/element/136.html","trigger",false,null),new CN("7/element/137.html","thresholdValue",false,null),new CN("7/element/138.html","thresholdUnit",false,null)))),
					new Array(),
					new Array(new CN("7/element/tcaParameter.html","tcaParameter",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/tcapar/v1"] = "7/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/tcapars/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("19/complextype/TcaParametersType.html","TcaParametersType",false,new Array(new CN("19/element/60.html","layerRate",false,null),new CN("19/element/61.html","granularity",false,null),new CN("19/element/62.html","tcaTypeValues",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/tcapars/v1"] = "19/index.html";
componentDB ["http://www.tmforum.org/mtop/nra/xsd/tcapp/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("1/complextype/TcaParameterProfileListType.html","TcaParameterProfileListType",false,new Array(new CN("1/element/0.html","tcaParameterProfileList",false,null))),new CN("1/complextype/TcaParameterProfileType.html","TcaParameterProfileType",false,new Array(new CN("1/element/12.html","layerRate",false,null),new CN("1/element/13.html","associatedTpRefList",false,null),new CN("1/element/14.html","tcaParameterList",false,null)))),
					new Array(),
					new Array(new CN("1/element/tcapp.html","tcapp",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nra/xsd/tcapp/v1"] = "1/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/com/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("14/simpletype/ProtectionSchemeStateEnumType.html","ProtectionSchemeStateEnumType",false,null)),
					new Array(new CN("14/complextype/ProtectionSchemeStateType.html","ProtectionSchemeStateType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/com/v1"] = "14/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/cri/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("5/simpletype/ResourceStateEnumType.html","ResourceStateEnumType",false,null),new CN("5/simpletype/SourceEnumType.html","SourceEnumType",false,null)),
					new Array(new CN("5/complextype/CommonResourceInfoType.html","CommonResourceInfoType",false,new Array(new CN("5/element/8.html","source",false,null),new CN("5/element/9.html","networkAccessDomain",false,null),new CN("5/element/10.html","meiAttributes",false,null),new CN("5/element/11.html","resourceState",false,null))),new CN("5/complextype/ResourceStateType.html","ResourceStateType",false,null),new CN("5/complextype/SourceType.html","SourceType",false,null)),
					new Array(),
					new Array(new CN("5/element/commonResourceInfo.html","commonResourceInfo",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/cri/v1"] = "5/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/itu/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("29/simpletype/M3100.AlarmStatusType.html","M3100.AlarmStatusType",false,null),new CN("29/simpletype/M3100.ArcQIStatusType.html","M3100.ArcQIStatusType",false,null),new CN("29/simpletype/M3100.ArcStateType.html","M3100.ArcStateType",false,null),new CN("29/simpletype/M3100.CircuitPackTypeType.html","M3100.CircuitPackTypeType",false,null),new CN("29/simpletype/M3100.HolderStatusType.html","M3100.HolderStatusType",false,null),new CN("29/simpletype/M3100.NALMQIIntervalType.html","M3100.NALMQIIntervalType",false,null),new CN("29/simpletype/M3100.NALMTIIntervalType.html","M3100.NALMTIIntervalType",false,null),new CN("29/simpletype/X721.AdministrativeStateType.html","X721.AdministrativeStateType",false,null),new CN("29/simpletype/X721.AvailabilityStatusType.html","X721.AvailabilityStatusType",false,null),new CN("29/simpletype/X721.ControlStatusType.html","X721.ControlStatusType",false,null),new CN("29/simpletype/X721.OperationalStateType.html","X721.OperationalStateType",false,null),new CN("29/simpletype/X721.UnkownstatusType.html","X721.UnkownstatusType",false,null),new CN("29/simpletype/X721.UsageStateType.html","X721.UsageStateType",false,null)),
					new Array(new CN("29/complextype/X721.StateType.html","X721.StateType",false,new Array(new CN("29/element/157.html","X721.OperationalState",false,null),new CN("29/element/151.html","X721.AdministrativeState",false,null),new CN("29/element/161.html","X721.UsageState",false,null),new CN("29/element/153.html","X721.AvailabilityStatus",false,null),new CN("29/element/155.html","X721.ControlStatus",false,null),new CN("29/element/147.html","M3100.HolderStatus",false,null),new CN("29/element/140.html","M3100.AlarmStatus",false,null),new CN("29/element/144.html","M3100.ArcState",false,null),new CN("29/element/142.html","M3100.ArcQIStatus",false,null),new CN("29/element/159.html","X721.Unkownstatus",false,null)))),
					new Array(),
					new Array(new CN("29/element/ituParameters.html","ituParameters",false,new Array(new CN("29/element/156.html","x721.OperationalState",false,null),new CN("29/element/150.html","x721.AdministrativeState",false,null),new CN("29/element/160.html","x721.UsageState",false,null),new CN("29/element/152.html","x721.AvailabilityStatus",false,null),new CN("29/element/154.html","x721.ControlStatus",false,null),new CN("29/element/146.html","m3100.HolderStatus",false,null),new CN("29/element/145.html","m3100.CircuitPackType",false,null),new CN("29/element/139.html","m3100.AlarmStatus",false,null),new CN("29/element/143.html","m3100.ArcState",false,null),new CN("29/element/149.html","m3100.NALMTIInterval",false,null),new CN("29/element/148.html","m3100.NALMQIInterval",false,null),new CN("29/element/141.html","m3100.ArcQIStatus",false,null),new CN("29/element/158.html","x721.Unkownstatus",false,null),new CN("29/element/162.html","x721.State",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/itu/v1"] = "29/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/lay/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("6/simpletype/LayerRateEnumType.html","LayerRateEnumType",false,null)),
					new Array(new CN("6/complextype/LayerRateListType.html","LayerRateListType",false,new Array(new CN("6/element/108.html","layerRate",false,null))),new CN("6/complextype/LayerRateType.html","LayerRateType",false,null)),
					new Array(),
					new Array(new CN("6/element/layerRateListType.html","layerRateListType",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/lay/v1"] = "6/index.html";
								   


