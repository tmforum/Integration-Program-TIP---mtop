/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */


function T (href, prefix, ns, name, relation, child) {
  	this.href = href;
  	this.prefix = prefix;
  	this.namespace = ns;
  	this.name = name;
  	this.relation = relation //"restriction", "extension", "none";
	this.child = child;
  	this.hasChild = (this.child != null);
}		

function writeTypeHierarchyString(node) {
  	if (node == null) {
		return;
  	}
			
	if (node.hasChild == false && node.relation == "none") {
		return;
	}
	
  	if (node.hasChild == false) {
		leaf (node);
  	} else {
		nonleaf (node);
  	}
}

/*
function prefixedAnchorString (node) {
  var rStr = null;
  if (node.relation == "none") {
	rStr = "";
  } else if (node.relation == "restriction") {
	rStr = "(R)";
  } else if (node.relation == "extension") {
	rStr = "(E)";
  } else {
	rStr = "";
  }

  var str = rStr + '<a href="'+node.href+ '"'+
	' title="ns=' + encodeURI(node.namespace)+'">'+
	node.prefix+':'+'</a>'+
	'<a href="'+node.href+'"'+
	' title="ns=' + encodeURI(node.namespace)+'">'+
	nodeText(node)+'</a>';
	
  return str;
}
*/

function anchorString (node) {
  	var rStr = null;
  	
  	if (node.relation == "none") {
		rStr = "";
  	} else if (node.relation == "restriction") {
		rStr = "<div style='margin-left:0.3em;font-family: sans-serif;font-size: 6pt;'>|</div>"+
				"<span style='font-family: sans-serif;font-size: 9pt;'><i>R</i></span>" +
				"<span style='font-family: sans-serif;font-size: 10pt;'>--&nbsp;</span>";
		//rStr = '<img alt="Derived by restriction" hspace="2" align="top" src="../../img/restrictionElbow.gif">';
  	} else if (node.relation == "extension") {
		rStr = "<div style='margin-left:0.3em;font-family: sans-serif;font-size: 6pt;'>|</div>"+
				"<span style='font-family: sans-serif;font-size: 9pt;'><i>E</i></span>"+
				"<span style='font-family: sans-serif;font-size: 10pt;'>--&nbsp;</span>";
		//rStr = '<img alt="Derived by extension" hspace="2" align="top" src="../../img/extensionElbow.gif">';
  	} else {
		rStr = "";
  	}

  	var str = rStr + '<a href="'+node.href+'"'+
		' title="ns=' + encodeURI(node.namespace)+'">'+
		'<span style="font-family: sans-serif;font-size: 10pt;">'+		
		nodeText(node)+'</span></a>';

  	return str;
}

function nodeText(node) {
	return node.name;
}

function leaf (node) {
	var str = null;
  	var nodeStr = null;

/*
	if (node.prefix.length>0) {
  		nodeStr = prefixedAnchorString(node);
	} else {
		nodeStr = anchorString (node);
	}
*/

	nodeStr = anchorString (node);
  	str = '<nobr>' + nodeStr + '</nobr><br />';

 	document.write (str);
}

function nonleaf (node) {
	var str = null;
  	var nodeStr = null;

	nodeStr = anchorString (node);

	str = '<div><div style="margin-left:0em;"><nobr>'+
			nodeStr +'</nobr></div>'+
			'<div style="margin-top:0em;margin-left: 1.2em;">';


  	document.write (str);

  	writeTypeHierarchyString(node.child);

  	document.write ('</div></div>');
}
