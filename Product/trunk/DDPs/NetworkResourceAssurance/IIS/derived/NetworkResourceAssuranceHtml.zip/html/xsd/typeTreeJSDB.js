﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_tiFileName = "typeTreeIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function TN (href, prefix, ns, name, relation, simpletypeflag, children) {
	this.href = href;
	this.prefix = prefix;
	this.namespace = ns;
	this.name = name;
	this.relation = relation;
	this.simpletypeflag = simpletypeflag;
	this.children = children;

	this.hasChild = (children != null) && (children.length>0);	
}

function T (typeTree)
{
	this.typeTree = typeTree;
}

function typetree_showAllTypes() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_tiFileName;
}

function typetree_filterTypes () {
	parent._href = "xsd/" + xsd_tiFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");
}

function typetree_showTypes() {
	if (parent._xsdNsFilter == null) {
		typetree_setFilterToAll();
	}

	var nsList = parent._xsdNsFilter;
	var typetrees = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		typetrees [i] = typetreeDB [nsList[i]];	
		nss[i] = nsList[i];
	}		
	
	typetree_showTree (nss, typetrees); 
}

function typetree_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in typetreeDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}


	parent._xsdNsFilter = nsList;
}


function typetree_showTree (nsList, typetrees) {
	for (var i=0; i<nsList.length; i++) {
		var fpath = typetreeNSMap[nsList[i]];
		
		var str = '<div class="nsBox"><div class="itemNS">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+fpath+
			'" title="'+encodeURI(nsList[i])+
			'" target="'+target+'">'+encodeURI(nsList[i])+'</a></nobr></div>'+
			'<div style="margin-left: 0.5em">';		

		document.write (str);

		typetree_outputList (typetrees[i].typeTree);
		

		document.write ('</div></div>');
	}
} 

function typetree_outputList (list) {
	for (var i=0; i<list.length; i++) {
		typetree_outputTree (list[i]);
	}
}

function typetree_outputTree (node) {
	if (node.hasChild == false) {
		typetree_outputLeaf (node);
	} else {
		typetree_outputNonLeaf (node);
	}
}


function typetree_outputLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node)
	} else {
		nodeStr = anchorString (node)
	}

	str = '<span class="leaf"><nobr>' +
		  '<img src="img/leaf.gif" hspace="2" align="middle">' + 
		  nodeStr + '</nobr></span><br />';

	document.write (str);
}

function prefixedAnchorString (node) {
	return  '<a class="chref" href="'+node.href+
			'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+
			node.prefix+':'+'</a>'+
			'<a class="chref" href="'+node.href+'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);
}

function anchorString (node) {
	return 	'<a class="chref" href="'+node.href+'" target="'+target+'"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);

}

function typetree_outputNonLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node);
	} else {
		nodeStr = anchorString (node);
	}
		
	str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			nodeStr +
			'</nobr></div>'+
			'<div style="margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		typetree_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function typetree_getNodeIcon(node) {
	var rStr = null;
	if (node.relation == "none") {
		rStr = "";
	} else if (node.relation == "extension") {
		rStr = '<img alt="derived by extension" border="0" hspace="2" align="middle" src="img/extension.gif">';
	
	} else if (node.relation == "restriction") {
		rStr = '<img alt="derived by restriction" border="0" hspace="2" align="middle" src="img/restriction.gif">';
	
	} else if (node.relation == "list") {
		rStr = '<img alt="derived by list" border="0" hspace="2" align="middle" src="img/list.gif">';
	
	} else if (node.relation == "union") {
		rStr = '<img alt="derived by union" border="0" hspace="2" align="middle" src="img/union.gif">';
	
	}
	
	var typeStr = null;
	
	if (node.simpletypeflag) {
		typeStr = '<img alt="simple type" border="0" hspace="2" align="middle" src="img/simple.gif">'; 
	} else {
		typeStr = '<img alt="complex type" border="0" hspace="2" align="middle" src="img/complex.gif">';	
	} 

	return typeStr + rStr;
}

var typetreeDB = new Array();
var typetreeNSMap = new Array();

typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new T (new Array (new TN("22/complextype/CommonEventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("35/complextype/EquipmentProtectionSwitchType.html","","http://www.tmforum.org/mtop/nra/xsd/eps/v1","EquipmentProtectionSwitchType","extension",false,null),new TN("23/complextype/EventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","extension",false,null),new TN("31/complextype/PerformanceMonitoringPointStateChangeType.html","","http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1","PerformanceMonitoringPointStateChangeType","extension",false,null),new TN("27/complextype/ProtectionSwitchType.html","","http://www.tmforum.org/mtop/nra/xsd/ps/v1","ProtectionSwitchType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "22/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new T (new Array (new TN("2/complextype/CommonObjectInfoType.html","","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("5/complextype/CommonResourceInfoType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "2/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cornot/v1"] =  new T (new Array (new TN("25/complextype/CorrelatedNotificationListType.html","","http://www.tmforum.org/mtop/fmw/xsd/cornot/v1","CorrelatedNotificationListType","none",false,null),new TN("25/complextype/CorrelatedNotificationsType.html","","http://www.tmforum.org/mtop/fmw/xsd/cornot/v1","CorrelatedNotificationsType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cornot/v1"] = "25/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new T (new Array (new TN("22/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("23/complextype/EventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("21/complextype/AlarmType.html","","http://www.tmforum.org/mtop/nra/xsd/alm/v1","AlarmType","extension",false,null),new TN("33/complextype/ThresholdCrossingAlertType.html","","http://www.tmforum.org/mtop/nra/xsd/tca/v1","ThresholdCrossingAlertType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "23/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new T (new Array (new TN("4/complextype/AliasNameListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AliasNameListType","none",false,null),new TN("4/complextype/AnyListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AnyListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#date","xsd","http://www.w3.org/2001/XMLSchema","date","none",true,new Array(new TN("4/simpletype/ManufactureDateType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufactureDateType","restriction",true,null))),new TN("4/complextype/MultiEventInventoryAttributesType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","MultiEventInventoryAttributesType","none",false,null),new TN("4/complextype/NotificationIdentifierListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("4/simpletype/DiscoveredNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","DiscoveredNameType","restriction",true,null),new TN("4/simpletype/LocationType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","LocationType","restriction",true,null),new TN("4/simpletype/ManufacturerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufacturerType","restriction",true,null),new TN("4/simpletype/NamingOperationsSystemType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NamingOperationsSystemType","restriction",true,null),new TN("4/simpletype/NetworkAccessDomainType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NetworkAccessDomainType","restriction",true,null),new TN("4/simpletype/NotificationIdentifierType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierType","restriction",true,null),new TN("4/simpletype/ObjectEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectEnumType","restriction",true,null),new TN("4/simpletype/ObjectTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectTypeType","restriction",true,null),new TN("4/simpletype/OwnerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","OwnerType","restriction",true,null),new TN("4/simpletype/ProductNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ProductNameType","restriction",true,null),new TN("4/simpletype/UserLabelType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","UserLabelType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "4/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new T (new Array (new TN("3/complextype/NameAndAnyValueListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NameAndAnyValueListType","none",false,null),new TN("3/complextype/NameAndAnyValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NameAndAnyValueType","none",false,null),new TN("3/complextype/NameAndStringValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NameAndStringValueType","none",false,null),new TN("3/complextype/NameAndValueStringListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NameAndValueStringListType","none",false,null),new TN("3/complextype/NamingAttributeListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeListType","none",false,null),new TN("3/complextype/NamingAttributeType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "3/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/alarmid/v1"] =  new T (new Array (new TN("16/complextype/AlarmIdType.html","","http://www.tmforum.org/mtop/nra/xsd/alarmid/v1","AlarmIdType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/alarmid/v1"] = "16/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/alm/v1"] =  new T (new Array (new TN("21/complextype/AlarmListType.html","","http://www.tmforum.org/mtop/nra/xsd/alm/v1","AlarmListType","none",false,null),new TN("22/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("23/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("21/complextype/AlarmType.html","","http://www.tmforum.org/mtop/nra/xsd/alm/v1","AlarmType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/alm/v1"] = "21/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/asa/v1"] =  new T (new Array (new TN("32/complextype/AlarmSeverityAssignmentListType.html","","http://www.tmforum.org/mtop/nra/xsd/asa/v1","AlarmSeverityAssignmentListType","none",false,null),new TN("2/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("5/complextype/CommonResourceInfoType.html","cri","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","restriction",false,new Array(new TN("32/complextype/AlarmSeverityAssignmentType.html","","http://www.tmforum.org/mtop/nra/xsd/asa/v1","AlarmSeverityAssignmentType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/asa/v1"] = "32/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/asap/v1"] =  new T (new Array (new TN("38/complextype/AlarmSeverityAssignmentProfileListType.html","","http://www.tmforum.org/mtop/nra/xsd/asap/v1","AlarmSeverityAssignmentProfileListType","none",false,null),new TN("2/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("5/complextype/CommonResourceInfoType.html","cri","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","restriction",false,new Array(new TN("38/complextype/AlarmSeverityAssignmentProfileType.html","","http://www.tmforum.org/mtop/nra/xsd/asap/v1","AlarmSeverityAssignmentProfileType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/asap/v1"] = "38/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/atcaid/v1"] =  new T (new Array (new TN("15/complextype/AlarmOrTcaIdListType.html","","http://www.tmforum.org/mtop/nra/xsd/atcaid/v1","AlarmOrTcaIdListType","none",false,null),new TN("15/complextype/AlarmOrTcaIdType.html","","http://www.tmforum.org/mtop/nra/xsd/atcaid/v1","AlarmOrTcaIdType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/atcaid/v1"] = "15/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/cmo/v1"] =  new T (new Array (new TN("37/complextype/CurrentMaintenanceOperationListType.html","","http://www.tmforum.org/mtop/nra/xsd/cmo/v1","CurrentMaintenanceOperationListType","none",false,null),new TN("37/complextype/CurrentMaintenanceOperationType.html","","http://www.tmforum.org/mtop/nra/xsd/cmo/v1","CurrentMaintenanceOperationType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("37/simpletype/MaintenanceOperationEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/cmo/v1","MaintenanceOperationEnumType","restriction",true,null),new TN("37/simpletype/MaintenanceOperationModeEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/cmo/v1","MaintenanceOperationModeEnumType","restriction",true,null),new TN("37/simpletype/MaintenanceOperationType.html","","http://www.tmforum.org/mtop/nra/xsd/cmo/v1","MaintenanceOperationType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/cmo/v1"] = "37/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/com/v1"] =  new T (new Array (new TN("24/complextype/PerceivedSeverityListType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","PerceivedSeverityListType","none",false,null),new TN("24/complextype/ProposedRepairActionListType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ProposedRepairActionListType","none",false,null),new TN("24/complextype/SpecificProblemListType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","SpecificProblemListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("24/simpletype/AcknowledgeIndicationType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","AcknowledgeIndicationType","restriction",true,null),new TN("24/simpletype/AssignedSeverityEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","AssignedSeverityEnumType","restriction",true,new Array(new TN("24/complextype/AssignedSeverityType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","AssignedSeverityType","restriction",false,null))),new TN("24/simpletype/EquipmentProtectionGroupTypeEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","EquipmentProtectionGroupTypeEnumType","restriction",true,new Array(new TN("24/complextype/EquipmentProtectionGroupTypeType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","EquipmentProtectionGroupTypeType","restriction",false,null))),new TN("24/simpletype/EquipmentSwitchReasonEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","EquipmentSwitchReasonEnumType","restriction",true,new Array(new TN("24/complextype/EquipmentSwitchReasonType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","EquipmentSwitchReasonType","restriction",false,null))),new TN("24/simpletype/G_774_3_APSfunctionEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","G_774_3_APSfunctionEnumType","restriction",true,new Array(new TN("24/complextype/G_774_3_APSfunctionType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","G_774_3_APSfunctionType","restriction",false,null))),new TN("24/simpletype/NativeProbableCauseType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","NativeProbableCauseType","restriction",true,null),new TN("24/simpletype/PerceivedSeverityType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","PerceivedSeverityType","restriction",true,null),new TN("24/simpletype/ProbableCauseQualifierType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ProbableCauseQualifierType","restriction",true,null),new TN("24/simpletype/ProposedRepairActionType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ProposedRepairActionType","restriction",true,null),new TN("24/simpletype/ProtectionCommandType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ProtectionCommandType","restriction",true,null),new TN("24/simpletype/ProtectionGroupTypeEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ProtectionGroupTypeEnumType","restriction",true,new Array(new TN("24/complextype/ProtectionGroupTypeType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ProtectionGroupTypeType","restriction",false,null))),new TN("24/simpletype/ProtectionTypeEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ProtectionTypeEnumType","restriction",true,new Array(new TN("24/complextype/ProtectionTypeType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ProtectionTypeType","restriction",false,null))),new TN("24/simpletype/ReversionModeType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ReversionModeType","restriction",true,null),new TN("24/simpletype/ServiceAffectingType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","ServiceAffectingType","restriction",true,null),new TN("24/simpletype/SpecificProblemType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","SpecificProblemType","restriction",true,null),new TN("24/simpletype/SwitchReasonType.html","","http://www.tmforum.org/mtop/nra/xsd/com/v1","SwitchReasonType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/com/v1"] = "24/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/epg/v1"] =  new T (new Array (new TN("2/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("5/complextype/CommonResourceInfoType.html","cri","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","restriction",false,new Array(new TN("12/complextype/EquipmentProtectionGroupType.html","","http://www.tmforum.org/mtop/nra/xsd/epg/v1","EquipmentProtectionGroupType","extension",false,null))))),new TN("12/complextype/EquipmentProtectionGroupListType.html","","http://www.tmforum.org/mtop/nra/xsd/epg/v1","EquipmentProtectionGroupListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/epg/v1"] = "12/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/eps/v1"] =  new T (new Array (new TN("22/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("35/complextype/EquipmentProtectionSwitchType.html","","http://www.tmforum.org/mtop/nra/xsd/eps/v1","EquipmentProtectionSwitchType","restriction",false,null))),new TN("35/complextype/EquipmentProtectionSwitchListType.html","","http://www.tmforum.org/mtop/nra/xsd/eps/v1","EquipmentProtectionSwitchListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/eps/v1"] = "35/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/esd/v1"] =  new T (new Array (new TN("36/complextype/EquipmentSwitchDataListType.html","","http://www.tmforum.org/mtop/nra/xsd/esd/v1","EquipmentSwitchDataListType","none",false,null),new TN("36/complextype/EquipmentSwitchDataType.html","","http://www.tmforum.org/mtop/nra/xsd/esd/v1","EquipmentSwitchDataType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/esd/v1"] = "36/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pg/v1"] =  new T (new Array (new TN("2/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("5/complextype/CommonResourceInfoType.html","cri","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","restriction",false,new Array(new TN("13/complextype/ProtectionGroupType.html","","http://www.tmforum.org/mtop/nra/xsd/pg/v1","ProtectionGroupType","extension",false,null))))),new TN("13/complextype/ProtectionGroupListType.html","","http://www.tmforum.org/mtop/nra/xsd/pg/v1","ProtectionGroupListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pg/v1"] = "13/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pgp/v1"] =  new T (new Array (new TN("http://www.w3.org/TR/xmlschema-2/#boolean","xsd","http://www.w3.org/2001/XMLSchema","boolean","none",true,new Array(new TN("11/simpletype/ExerciseOnType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","ExerciseOnType","restriction",true,null))),new TN("11/simpletype/HoldOffTimeType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","HoldOffTimeType","none",true,null),new TN("http://www.w3.org/TR/xmlschema-2/#integer","xsd","http://www.w3.org/2001/XMLSchema","integer","none",true,new Array(new TN("11/simpletype/WtrTimeType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","WtrTimeType","restriction",true,null))),new TN("11/complextype/ProtectionGroupParameterListType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","ProtectionGroupParameterListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("11/simpletype/AvailabilityStatusEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","AvailabilityStatusEnumType","restriction",true,new Array(new TN("11/complextype/AvailabilityStatusType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","AvailabilityStatusType","restriction",false,null))),new TN("11/simpletype/BundleSwitchingType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","BundleSwitchingType","restriction",true,null),new TN("11/simpletype/HitlessType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","HitlessType","restriction",true,null),new TN("11/simpletype/NonPreEmptibleTrafficType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","NonPreEmptibleTrafficType","restriction",true,null),new TN("11/simpletype/PrivilegedChannelType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","PrivilegedChannelType","restriction",true,null),new TN("11/simpletype/SpringNodeIdType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","SpringNodeIdType","restriction",true,null),new TN("11/simpletype/SpringProtocolEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","SpringProtocolEnumType","restriction",true,new Array(new TN("11/complextype/SpringProtocolType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","SpringProtocolType","restriction",false,null))),new TN("11/simpletype/SwitchCriteriaEnableEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","SwitchCriteriaEnableEnumType","restriction",true,new Array(new TN("11/complextype/SwitchCriteriaEnableType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","SwitchCriteriaEnableType","restriction",false,null))),new TN("11/simpletype/SwitchModeEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","SwitchModeEnumType","restriction",true,new Array(new TN("11/complextype/SwitchModeType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","SwitchModeType","restriction",false,null))),new TN("11/simpletype/SwitchPositionType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","SwitchPositionType","restriction",true,null),new TN("11/simpletype/TandemSwitchingType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","TandemSwitchingType","restriction",true,null))),new TN("http://www.w3.org/TR/xmlschema-2/#unsignedInt","xsd","http://www.w3.org/2001/XMLSchema","unsignedInt","none",true,new Array(new TN("11/simpletype/LodNumSwitchesType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","LodNumSwitchesType","restriction",true,null))),new TN("http://www.w3.org/TR/xmlschema-2/#unsignedLong","xsd","http://www.w3.org/2001/XMLSchema","unsignedLong","none",true,new Array(new TN("11/simpletype/LodDurationType.html","","http://www.tmforum.org/mtop/nra/xsd/pgp/v1","LodDurationType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pgp/v1"] = "11/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pm/v1"] =  new T (new Array (new TN("9/complextype/PmGranularityListType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","PmGranularityListType","none",false,null),new TN("9/complextype/PmLocationListType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","PmLocationListType","none",false,null),new TN("9/complextype/PmParameterNameListType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","PmParameterNameListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("9/simpletype/HoldingTimeType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","HoldingTimeType","restriction",true,null),new TN("9/simpletype/PmGranularityType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","PmGranularityType","restriction",true,null),new TN("9/simpletype/PmIntervalStatusType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","PmIntervalStatusType","restriction",true,null),new TN("9/simpletype/PmLocationType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","PmLocationType","restriction",true,null),new TN("9/simpletype/PmParameterNameType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","PmParameterNameType","restriction",true,null),new TN("9/simpletype/PmThresholdTypeType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","PmThresholdTypeType","restriction",true,null),new TN("9/simpletype/TriggerType.html","","http://www.tmforum.org/mtop/nra/xsd/pm/v1","TriggerType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pm/v1"] = "9/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmdata/v1"] =  new T (new Array (new TN("8/complextype/PmDataListType.html","","http://www.tmforum.org/mtop/nra/xsd/pmdata/v1","PmDataListType","none",false,null),new TN("8/complextype/PmDataType.html","","http://www.tmforum.org/mtop/nra/xsd/pmdata/v1","PmDataType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmdata/v1"] = "8/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1"] =  new T (new Array (new TN("10/complextype/PmMeasurementListType.html","","http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1","PmMeasurementListType","none",false,null),new TN("10/complextype/PmMeasurementType.html","","http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1","PmMeasurementType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1"] = "10/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmp/v1"] =  new T (new Array (new TN("2/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("5/complextype/CommonResourceInfoType.html","cri","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","restriction",false,new Array(new TN("28/complextype/PerformanceMonitoringPointType.html","","http://www.tmforum.org/mtop/nra/xsd/pmp/v1","PerformanceMonitoringPointType","extension",false,null))))),new TN("28/complextype/PerformanceMonitoringPointListType.html","","http://www.tmforum.org/mtop/nra/xsd/pmp/v1","PerformanceMonitoringPointListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmp/v1"] = "28/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmpar/v1"] =  new T (new Array (new TN("39/complextype/PmParameterListType.html","","http://www.tmforum.org/mtop/nra/xsd/pmpar/v1","PmParameterListType","none",false,null),new TN("39/complextype/PmParameterType.html","","http://www.tmforum.org/mtop/nra/xsd/pmpar/v1","PmParameterType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmpar/v1"] = "39/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmparth/v1"] =  new T (new Array (new TN("40/complextype/PmParameterWithThresholdsListType.html","","http://www.tmforum.org/mtop/nra/xsd/pmparth/v1","PmParameterWithThresholdsListType","none",false,null),new TN("40/complextype/PmParameterWithThresholdsType.html","","http://www.tmforum.org/mtop/nra/xsd/pmparth/v1","PmParameterWithThresholdsType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmparth/v1"] = "40/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1"] =  new T (new Array (new TN("22/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("31/complextype/PerformanceMonitoringPointStateChangeType.html","","http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1","PerformanceMonitoringPointStateChangeType","restriction",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1"] = "31/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1"] =  new T (new Array (new TN("26/complextype/PmObjectSelectListType.html","","http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1","PmObjectSelectListType","none",false,null),new TN("26/complextype/PmObjectSelectType.html","","http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1","PmObjectSelectType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1"] = "26/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmth/v1"] =  new T (new Array (new TN("30/complextype/PmThresholdListType.html","","http://www.tmforum.org/mtop/nra/xsd/pmth/v1","PmThresholdListType","none",false,null),new TN("30/complextype/PmThresholdType.html","","http://www.tmforum.org/mtop/nra/xsd/pmth/v1","PmThresholdType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmth/v1"] = "30/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/pmtv/v1"] =  new T (new Array (new TN("20/complextype/PmThresholdValueListType.html","","http://www.tmforum.org/mtop/nra/xsd/pmtv/v1","PmThresholdValueListType","none",false,null),new TN("20/complextype/PmThresholdValueType.html","","http://www.tmforum.org/mtop/nra/xsd/pmtv/v1","PmThresholdValueType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/pmtv/v1"] = "20/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/prc/v1"] =  new T (new Array (new TN("18/complextype/ProbableCauseListType.html","","http://www.tmforum.org/mtop/nra/xsd/prc/v1","ProbableCauseListType","none",false,null),new TN("18/complextype/ProbableCauseType.html","","http://www.tmforum.org/mtop/nra/xsd/prc/v1","ProbableCauseType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("18/simpletype/ProbableCauseEnumType.html","","http://www.tmforum.org/mtop/nra/xsd/prc/v1","ProbableCauseEnumType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/prc/v1"] = "18/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/ps/v1"] =  new T (new Array (new TN("22/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("27/complextype/ProtectionSwitchType.html","","http://www.tmforum.org/mtop/nra/xsd/ps/v1","ProtectionSwitchType","restriction",false,null))),new TN("27/complextype/ProtectionSwitchListType.html","","http://www.tmforum.org/mtop/nra/xsd/ps/v1","ProtectionSwitchListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/ps/v1"] = "27/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/sd/v1"] =  new T (new Array (new TN("34/complextype/SwitchDataListType.html","","http://www.tmforum.org/mtop/nra/xsd/sd/v1","SwitchDataListType","none",false,null),new TN("34/complextype/SwitchDataType.html","","http://www.tmforum.org/mtop/nra/xsd/sd/v1","SwitchDataType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/sd/v1"] = "34/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/tca/v1"] =  new T (new Array (new TN("22/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("23/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("33/complextype/ThresholdCrossingAlertType.html","","http://www.tmforum.org/mtop/nra/xsd/tca/v1","ThresholdCrossingAlertType","extension",false,null))))),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("33/simpletype/AcknowledgeIndicationType.html","","http://www.tmforum.org/mtop/nra/xsd/tca/v1","AcknowledgeIndicationType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/tca/v1"] = "33/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/tcaid/v1"] =  new T (new Array (new TN("17/complextype/TcaIdType.html","","http://www.tmforum.org/mtop/nra/xsd/tcaid/v1","TcaIdType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/tcaid/v1"] = "17/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/tcapar/v1"] =  new T (new Array (new TN("7/complextype/TcaParameterListType.html","","http://www.tmforum.org/mtop/nra/xsd/tcapar/v1","TcaParameterListType","none",false,null),new TN("7/complextype/TcaParameterType.html","","http://www.tmforum.org/mtop/nra/xsd/tcapar/v1","TcaParameterType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/tcapar/v1"] = "7/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/tcapars/v1"] =  new T (new Array (new TN("19/complextype/TcaParametersType.html","","http://www.tmforum.org/mtop/nra/xsd/tcapars/v1","TcaParametersType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/tcapars/v1"] = "19/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nra/xsd/tcapp/v1"] =  new T (new Array (new TN("2/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("5/complextype/CommonResourceInfoType.html","cri","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","restriction",false,new Array(new TN("1/complextype/TcaParameterProfileType.html","","http://www.tmforum.org/mtop/nra/xsd/tcapp/v1","TcaParameterProfileType","extension",false,null))))),new TN("1/complextype/TcaParameterProfileListType.html","","http://www.tmforum.org/mtop/nra/xsd/tcapp/v1","TcaParameterProfileListType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nra/xsd/tcapp/v1"] = "1/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/com/v1"] =  new T (new Array (new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("14/simpletype/ProtectionSchemeStateEnumType.html","","http://www.tmforum.org/mtop/nrb/xsd/com/v1","ProtectionSchemeStateEnumType","restriction",true,new Array(new TN("14/complextype/ProtectionSchemeStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/com/v1","ProtectionSchemeStateType","restriction",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/com/v1"] = "14/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/cri/v1"] =  new T (new Array (new TN("2/complextype/CommonObjectInfoType.html","coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("5/complextype/CommonResourceInfoType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","CommonResourceInfoType","restriction",false,new Array(new TN("38/complextype/AlarmSeverityAssignmentProfileType.html","","http://www.tmforum.org/mtop/nra/xsd/asap/v1","AlarmSeverityAssignmentProfileType","extension",false,null),new TN("32/complextype/AlarmSeverityAssignmentType.html","","http://www.tmforum.org/mtop/nra/xsd/asa/v1","AlarmSeverityAssignmentType","extension",false,null),new TN("12/complextype/EquipmentProtectionGroupType.html","","http://www.tmforum.org/mtop/nra/xsd/epg/v1","EquipmentProtectionGroupType","extension",false,null),new TN("28/complextype/PerformanceMonitoringPointType.html","","http://www.tmforum.org/mtop/nra/xsd/pmp/v1","PerformanceMonitoringPointType","extension",false,null),new TN("13/complextype/ProtectionGroupType.html","","http://www.tmforum.org/mtop/nra/xsd/pg/v1","ProtectionGroupType","extension",false,null),new TN("1/complextype/TcaParameterProfileType.html","","http://www.tmforum.org/mtop/nra/xsd/tcapp/v1","TcaParameterProfileType","extension",false,null))))),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("5/simpletype/ResourceStateEnumType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","ResourceStateEnumType","restriction",true,new Array(new TN("5/complextype/ResourceStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","ResourceStateType","restriction",false,null))),new TN("5/simpletype/SourceEnumType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","SourceEnumType","restriction",true,new Array(new TN("5/complextype/SourceType.html","","http://www.tmforum.org/mtop/nrb/xsd/cri/v1","SourceType","restriction",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/cri/v1"] = "5/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/itu/v1"] =  new T (new Array (new TN("http://www.w3.org/TR/xmlschema-2/#boolean","xsd","http://www.w3.org/2001/XMLSchema","boolean","none",true,new Array(new TN("29/simpletype/X721.OperationalStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.OperationalStateType","restriction",true,null),new TN("29/simpletype/X721.UnkownstatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.UnkownstatusType","restriction",true,null))),new TN("29/simpletype/M3100.NALMQIIntervalType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.NALMQIIntervalType","none",true,null),new TN("29/simpletype/M3100.NALMTIIntervalType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.NALMTIIntervalType","none",true,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("29/simpletype/M3100.AlarmStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.AlarmStatusType","restriction",true,null),new TN("29/simpletype/M3100.ArcQIStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.ArcQIStatusType","restriction",true,null),new TN("29/simpletype/M3100.ArcStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.ArcStateType","restriction",true,null),new TN("29/simpletype/M3100.CircuitPackTypeType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.CircuitPackTypeType","restriction",true,null),new TN("29/simpletype/M3100.HolderStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","M3100.HolderStatusType","restriction",true,null),new TN("29/simpletype/X721.AdministrativeStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.AdministrativeStateType","restriction",true,null),new TN("29/simpletype/X721.AvailabilityStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.AvailabilityStatusType","restriction",true,null),new TN("29/simpletype/X721.ControlStatusType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.ControlStatusType","restriction",true,null),new TN("29/simpletype/X721.UsageStateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.UsageStateType","restriction",true,null))),new TN("29/complextype/X721.StateType.html","","http://www.tmforum.org/mtop/nrb/xsd/itu/v1","X721.StateType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/itu/v1"] = "29/index.html";
typetreeDB ["http://www.tmforum.org/mtop/nrb/xsd/lay/v1"] =  new T (new Array (new TN("6/complextype/LayerRateListType.html","","http://www.tmforum.org/mtop/nrb/xsd/lay/v1","LayerRateListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("6/simpletype/LayerRateEnumType.html","","http://www.tmforum.org/mtop/nrb/xsd/lay/v1","LayerRateEnumType","restriction",true,new Array(new TN("6/complextype/LayerRateType.html","","http://www.tmforum.org/mtop/nrb/xsd/lay/v1","LayerRateType","restriction",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/nrb/xsd/lay/v1"] = "6/index.html";
								   


