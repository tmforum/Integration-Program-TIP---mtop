/*
 * XML Type:  PmMeasurementListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmmsrt.v1.impl;
/**
 * An XML PmMeasurementListType(@http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1).
 *
 * This is a complex type.
 */
public class PmMeasurementListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType
{
    
    public PmMeasurementListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMMEASUREMENT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1", "pmMeasurement");
    
    
    /**
     * Gets a List of "pmMeasurement" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType> getPmMeasurementList()
    {
        final class PmMeasurementList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType>
        {
            public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType get(int i)
                { return PmMeasurementListTypeImpl.this.getPmMeasurementArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType set(int i, org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType o)
            {
                org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType old = PmMeasurementListTypeImpl.this.getPmMeasurementArray(i);
                PmMeasurementListTypeImpl.this.setPmMeasurementArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType o)
                { PmMeasurementListTypeImpl.this.insertNewPmMeasurement(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType old = PmMeasurementListTypeImpl.this.getPmMeasurementArray(i);
                PmMeasurementListTypeImpl.this.removePmMeasurement(i);
                return old;
            }
            
            public int size()
                { return PmMeasurementListTypeImpl.this.sizeOfPmMeasurementArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmMeasurementList();
        }
    }
    
    /**
     * Gets array of all "pmMeasurement" elements
     */
    public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType[] getPmMeasurementArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMMEASUREMENT$0, targetList);
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType[] result = new org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pmMeasurement" element
     */
    public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType getPmMeasurementArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType)get_store().find_element_user(PMMEASUREMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pmMeasurement" element
     */
    public int sizeOfPmMeasurementArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMMEASUREMENT$0);
        }
    }
    
    /**
     * Sets array of all "pmMeasurement" element
     */
    public void setPmMeasurementArray(org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType[] pmMeasurementArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmMeasurementArray, PMMEASUREMENT$0);
        }
    }
    
    /**
     * Sets ith "pmMeasurement" element
     */
    public void setPmMeasurementArray(int i, org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType pmMeasurement)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType)get_store().find_element_user(PMMEASUREMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmMeasurement);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmMeasurement" element
     */
    public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType insertNewPmMeasurement(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType)get_store().insert_element_user(PMMEASUREMENT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmMeasurement" element
     */
    public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType addNewPmMeasurement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType)get_store().add_element_user(PMMEASUREMENT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmMeasurement" element
     */
    public void removePmMeasurement(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMMEASUREMENT$0, i);
        }
    }
}
