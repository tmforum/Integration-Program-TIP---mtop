/*
 * XML Type:  AssignedSeverityEnumType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1.impl;
/**
 * An XML AssignedSeverityEnumType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityEnumType.
 */
public class AssignedSeverityEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityEnumType
{
    
    public AssignedSeverityEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected AssignedSeverityEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
