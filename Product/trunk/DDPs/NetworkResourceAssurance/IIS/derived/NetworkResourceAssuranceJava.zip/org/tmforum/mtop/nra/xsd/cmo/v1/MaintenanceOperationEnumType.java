/*
 * XML Type:  MaintenanceOperationEnumType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/cmo/v1
 * Java type: org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.cmo.v1;


/**
 * An XML MaintenanceOperationEnumType(@http://www.tmforum.org/mtop/nra/xsd/cmo/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType.
 */
public interface MaintenanceOperationEnumType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(MaintenanceOperationEnumType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3302A0BB3167604C489D394E7972B422").resolveHandle("maintenanceoperationenumtype3692type");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum FACILITY_LOOPBACK = Enum.forString("FACILITY_LOOPBACK");
    static final Enum TERMINAL_LOOPBACK = Enum.forString("TERMINAL_LOOPBACK");
    static final Enum FACILITY_FORCED_AIS = Enum.forString("FACILITY_FORCED_AIS");
    static final Enum TERMINAL_FORCED_AIS = Enum.forString("TERMINAL_FORCED_AIS");
    static final Enum FORCE_RDI = Enum.forString("FORCE_RDI");
    static final Enum SET_AS_SEGMENT_END_POINT = Enum.forString("SET_AS_SEGMENT_END_POINT");
    static final Enum END_TO_END_LOOPBACK_OAM_CELL = Enum.forString("END_TO_END_LOOPBACK_OAM_CELL");
    static final Enum SEGMENT_LOOPBACK_OAM_CELL = Enum.forString("SEGMENT_LOOPBACK_OAM_CELL");
    static final Enum LOCAL_LOOP_QUALIFICATION = Enum.forString("LOCAL_LOOP_QUALIFICATION");
    static final Enum DSL_LINE_SUPERVISION = Enum.forString("DSL_LINE_SUPERVISION");
    static final Enum SINGLE_ENDED_LINE_TEST = Enum.forString("SINGLE_ENDED_LINE_TEST");
    static final Enum DUAL_ENDED_LINE_TEST = Enum.forString("DUAL_ENDED_LINE_TEST");
    static final Enum PAYLOAD_LOOPBACK = Enum.forString("PAYLOAD_LOOPBACK");
    static final Enum DUAL_LOOPBACK = Enum.forString("DUAL_LOOPBACK");
    
    static final int INT_FACILITY_LOOPBACK = Enum.INT_FACILITY_LOOPBACK;
    static final int INT_TERMINAL_LOOPBACK = Enum.INT_TERMINAL_LOOPBACK;
    static final int INT_FACILITY_FORCED_AIS = Enum.INT_FACILITY_FORCED_AIS;
    static final int INT_TERMINAL_FORCED_AIS = Enum.INT_TERMINAL_FORCED_AIS;
    static final int INT_FORCE_RDI = Enum.INT_FORCE_RDI;
    static final int INT_SET_AS_SEGMENT_END_POINT = Enum.INT_SET_AS_SEGMENT_END_POINT;
    static final int INT_END_TO_END_LOOPBACK_OAM_CELL = Enum.INT_END_TO_END_LOOPBACK_OAM_CELL;
    static final int INT_SEGMENT_LOOPBACK_OAM_CELL = Enum.INT_SEGMENT_LOOPBACK_OAM_CELL;
    static final int INT_LOCAL_LOOP_QUALIFICATION = Enum.INT_LOCAL_LOOP_QUALIFICATION;
    static final int INT_DSL_LINE_SUPERVISION = Enum.INT_DSL_LINE_SUPERVISION;
    static final int INT_SINGLE_ENDED_LINE_TEST = Enum.INT_SINGLE_ENDED_LINE_TEST;
    static final int INT_DUAL_ENDED_LINE_TEST = Enum.INT_DUAL_ENDED_LINE_TEST;
    static final int INT_PAYLOAD_LOOPBACK = Enum.INT_PAYLOAD_LOOPBACK;
    static final int INT_DUAL_LOOPBACK = Enum.INT_DUAL_LOOPBACK;
    
    /**
     * Enumeration value class for org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_FACILITY_LOOPBACK
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_FACILITY_LOOPBACK = 1;
        static final int INT_TERMINAL_LOOPBACK = 2;
        static final int INT_FACILITY_FORCED_AIS = 3;
        static final int INT_TERMINAL_FORCED_AIS = 4;
        static final int INT_FORCE_RDI = 5;
        static final int INT_SET_AS_SEGMENT_END_POINT = 6;
        static final int INT_END_TO_END_LOOPBACK_OAM_CELL = 7;
        static final int INT_SEGMENT_LOOPBACK_OAM_CELL = 8;
        static final int INT_LOCAL_LOOP_QUALIFICATION = 9;
        static final int INT_DSL_LINE_SUPERVISION = 10;
        static final int INT_SINGLE_ENDED_LINE_TEST = 11;
        static final int INT_DUAL_ENDED_LINE_TEST = 12;
        static final int INT_PAYLOAD_LOOPBACK = 13;
        static final int INT_DUAL_LOOPBACK = 14;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("FACILITY_LOOPBACK", INT_FACILITY_LOOPBACK),
                new Enum("TERMINAL_LOOPBACK", INT_TERMINAL_LOOPBACK),
                new Enum("FACILITY_FORCED_AIS", INT_FACILITY_FORCED_AIS),
                new Enum("TERMINAL_FORCED_AIS", INT_TERMINAL_FORCED_AIS),
                new Enum("FORCE_RDI", INT_FORCE_RDI),
                new Enum("SET_AS_SEGMENT_END_POINT", INT_SET_AS_SEGMENT_END_POINT),
                new Enum("END_TO_END_LOOPBACK_OAM_CELL", INT_END_TO_END_LOOPBACK_OAM_CELL),
                new Enum("SEGMENT_LOOPBACK_OAM_CELL", INT_SEGMENT_LOOPBACK_OAM_CELL),
                new Enum("LOCAL_LOOP_QUALIFICATION", INT_LOCAL_LOOP_QUALIFICATION),
                new Enum("DSL_LINE_SUPERVISION", INT_DSL_LINE_SUPERVISION),
                new Enum("SINGLE_ENDED_LINE_TEST", INT_SINGLE_ENDED_LINE_TEST),
                new Enum("DUAL_ENDED_LINE_TEST", INT_DUAL_ENDED_LINE_TEST),
                new Enum("PAYLOAD_LOOPBACK", INT_PAYLOAD_LOOPBACK),
                new Enum("DUAL_LOOPBACK", INT_DUAL_LOOPBACK),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType newValue(java.lang.Object obj) {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) type.newValue( obj ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType newInstance() {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
