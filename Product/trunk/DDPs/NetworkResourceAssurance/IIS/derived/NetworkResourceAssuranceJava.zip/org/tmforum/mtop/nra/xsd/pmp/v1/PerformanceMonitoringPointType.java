/*
 * XML Type:  PerformanceMonitoringPointType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmp.v1;


/**
 * An XML PerformanceMonitoringPointType(@http://www.tmforum.org/mtop/nra/xsd/pmp/v1).
 *
 * This is a complex type.
 */
public interface PerformanceMonitoringPointType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PerformanceMonitoringPointType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("performancemonitoringpointtype29c1type");
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * Tests for nil "layerRate" element
     */
    boolean isNilLayerRate();
    
    /**
     * True if has "layerRate" element
     */
    boolean isSetLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Nils the "layerRate" element
     */
    void setNilLayerRate();
    
    /**
     * Unsets the "layerRate" element
     */
    void unsetLayerRate();
    
    /**
     * Gets the "pmLocation" element
     */
    java.lang.String getPmLocation();
    
    /**
     * Gets (as xml) the "pmLocation" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.LocationType xgetPmLocation();
    
    /**
     * Tests for nil "pmLocation" element
     */
    boolean isNilPmLocation();
    
    /**
     * True if has "pmLocation" element
     */
    boolean isSetPmLocation();
    
    /**
     * Sets the "pmLocation" element
     */
    void setPmLocation(java.lang.String pmLocation);
    
    /**
     * Sets (as xml) the "pmLocation" element
     */
    void xsetPmLocation(org.tmforum.mtop.fmw.xsd.gen.v1.LocationType pmLocation);
    
    /**
     * Nils the "pmLocation" element
     */
    void setNilPmLocation();
    
    /**
     * Unsets the "pmLocation" element
     */
    void unsetPmLocation();
    
    /**
     * Gets the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity();
    
    /**
     * Gets (as xml) the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity();
    
    /**
     * Tests for nil "granularity" element
     */
    boolean isNilGranularity();
    
    /**
     * True if has "granularity" element
     */
    boolean isSetGranularity();
    
    /**
     * Sets the "granularity" element
     */
    void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity);
    
    /**
     * Sets (as xml) the "granularity" element
     */
    void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity);
    
    /**
     * Nils the "granularity" element
     */
    void setNilGranularity();
    
    /**
     * Unsets the "granularity" element
     */
    void unsetGranularity();
    
    /**
     * Gets the "supervisionState" element
     */
    org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum getSupervisionState();
    
    /**
     * Gets (as xml) the "supervisionState" element
     */
    org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType xgetSupervisionState();
    
    /**
     * Tests for nil "supervisionState" element
     */
    boolean isNilSupervisionState();
    
    /**
     * True if has "supervisionState" element
     */
    boolean isSetSupervisionState();
    
    /**
     * Sets the "supervisionState" element
     */
    void setSupervisionState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum supervisionState);
    
    /**
     * Sets (as xml) the "supervisionState" element
     */
    void xsetSupervisionState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType supervisionState);
    
    /**
     * Nils the "supervisionState" element
     */
    void setNilSupervisionState();
    
    /**
     * Unsets the "supervisionState" element
     */
    void unsetSupervisionState();
    
    /**
     * Gets the "monitoringState" element
     */
    org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum getMonitoringState();
    
    /**
     * Gets (as xml) the "monitoringState" element
     */
    org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType xgetMonitoringState();
    
    /**
     * Tests for nil "monitoringState" element
     */
    boolean isNilMonitoringState();
    
    /**
     * True if has "monitoringState" element
     */
    boolean isSetMonitoringState();
    
    /**
     * Sets the "monitoringState" element
     */
    void setMonitoringState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum monitoringState);
    
    /**
     * Sets (as xml) the "monitoringState" element
     */
    void xsetMonitoringState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType monitoringState);
    
    /**
     * Nils the "monitoringState" element
     */
    void setNilMonitoringState();
    
    /**
     * Unsets the "monitoringState" element
     */
    void unsetMonitoringState();
    
    /**
     * Gets the "pmParameterList" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType getPmParameterList();
    
    /**
     * Tests for nil "pmParameterList" element
     */
    boolean isNilPmParameterList();
    
    /**
     * True if has "pmParameterList" element
     */
    boolean isSetPmParameterList();
    
    /**
     * Sets the "pmParameterList" element
     */
    void setPmParameterList(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType pmParameterList);
    
    /**
     * Appends and returns a new empty "pmParameterList" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType addNewPmParameterList();
    
    /**
     * Nils the "pmParameterList" element
     */
    void setNilPmParameterList();
    
    /**
     * Unsets the "pmParameterList" element
     */
    void unsetPmParameterList();
    
    /**
     * Gets the "pmThresholdList" element
     */
    org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType getPmThresholdList();
    
    /**
     * Tests for nil "pmThresholdList" element
     */
    boolean isNilPmThresholdList();
    
    /**
     * True if has "pmThresholdList" element
     */
    boolean isSetPmThresholdList();
    
    /**
     * Sets the "pmThresholdList" element
     */
    void setPmThresholdList(org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType pmThresholdList);
    
    /**
     * Appends and returns a new empty "pmThresholdList" element
     */
    org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType addNewPmThresholdList();
    
    /**
     * Nils the "pmThresholdList" element
     */
    void setNilPmThresholdList();
    
    /**
     * Unsets the "pmThresholdList" element
     */
    void unsetPmThresholdList();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType newInstance() {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
