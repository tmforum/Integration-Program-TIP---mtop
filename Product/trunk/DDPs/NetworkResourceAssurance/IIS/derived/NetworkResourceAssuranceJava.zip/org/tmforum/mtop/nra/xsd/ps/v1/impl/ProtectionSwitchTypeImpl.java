/*
 * XML Type:  ProtectionSwitchType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/ps/v1
 * Java type: org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.ps.v1.impl;
/**
 * An XML ProtectionSwitchType(@http://www.tmforum.org/mtop/nra/xsd/ps/v1).
 *
 * This is a complex type.
 */
public class ProtectionSwitchTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationTypeImpl implements org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType
{
    
    public ProtectionSwitchTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OSTIME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "osTime");
    private static final javax.xml.namespace.QName PROTECTIONTYPE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "protectionType");
    private static final javax.xml.namespace.QName SWITCHREASON$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "switchReason");
    private static final javax.xml.namespace.QName LAYERRATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "layerRate");
    private static final javax.xml.namespace.QName GROUPNAMEREF$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "groupNameRef");
    private static final javax.xml.namespace.QName PROTECTEDTPREF$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "protectedTpRef");
    private static final javax.xml.namespace.QName SWITCHAWAYFROMTPREF$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "switchAwayFromTpRef");
    private static final javax.xml.namespace.QName SWITCHTOTPREF$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "switchToTpRef");
    
    
    /**
     * Gets the "osTime" element
     */
    public java.util.Calendar getOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSTIME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "osTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(OSTIME$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "osTime" element
     */
    public boolean isSetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OSTIME$0) != 0;
        }
    }
    
    /**
     * Sets the "osTime" element
     */
    public void setOsTime(java.util.Calendar osTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSTIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSTIME$0);
            }
            target.setCalendarValue(osTime);
        }
    }
    
    /**
     * Sets (as xml) the "osTime" element
     */
    public void xsetOsTime(org.apache.xmlbeans.XmlDateTime osTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(OSTIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(OSTIME$0);
            }
            target.set(osTime);
        }
    }
    
    /**
     * Unsets the "osTime" element
     */
    public void unsetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OSTIME$0, 0);
        }
    }
    
    /**
     * Gets the "protectionType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType getProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().find_element_user(PROTECTIONTYPE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "protectionType" element
     */
    public boolean isSetProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONTYPE$2) != 0;
        }
    }
    
    /**
     * Sets the "protectionType" element
     */
    public void setProtectionType(org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType protectionType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().find_element_user(PROTECTIONTYPE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().add_element_user(PROTECTIONTYPE$2);
            }
            target.set(protectionType);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType addNewProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().add_element_user(PROTECTIONTYPE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "protectionType" element
     */
    public void unsetProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONTYPE$2, 0);
        }
    }
    
    /**
     * Gets the "switchReason" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum getSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SWITCHREASON$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "switchReason" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType xgetSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().find_element_user(SWITCHREASON$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "switchReason" element
     */
    public boolean isSetSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHREASON$4) != 0;
        }
    }
    
    /**
     * Sets the "switchReason" element
     */
    public void setSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum switchReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SWITCHREASON$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SWITCHREASON$4);
            }
            target.setEnumValue(switchReason);
        }
    }
    
    /**
     * Sets (as xml) the "switchReason" element
     */
    public void xsetSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType switchReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().find_element_user(SWITCHREASON$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().add_element_user(SWITCHREASON$4);
            }
            target.set(switchReason);
        }
    }
    
    /**
     * Unsets the "switchReason" element
     */
    public void unsetSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHREASON$4, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            return target;
        }
    }
    
    /**
     * Gets the "groupNameRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getGroupNameRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(GROUPNAMEREF$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "groupNameRef" element
     */
    public boolean isSetGroupNameRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GROUPNAMEREF$8) != 0;
        }
    }
    
    /**
     * Sets the "groupNameRef" element
     */
    public void setGroupNameRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType groupNameRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(GROUPNAMEREF$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(GROUPNAMEREF$8);
            }
            target.set(groupNameRef);
        }
    }
    
    /**
     * Appends and returns a new empty "groupNameRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewGroupNameRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(GROUPNAMEREF$8);
            return target;
        }
    }
    
    /**
     * Unsets the "groupNameRef" element
     */
    public void unsetGroupNameRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GROUPNAMEREF$8, 0);
        }
    }
    
    /**
     * Gets the "protectedTpRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProtectedTpRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PROTECTEDTPREF$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "protectedTpRef" element
     */
    public void setProtectedTpRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType protectedTpRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PROTECTEDTPREF$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PROTECTEDTPREF$10);
            }
            target.set(protectedTpRef);
        }
    }
    
    /**
     * Appends and returns a new empty "protectedTpRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProtectedTpRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PROTECTEDTPREF$10);
            return target;
        }
    }
    
    /**
     * Gets the "switchAwayFromTpRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchAwayFromTpRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SWITCHAWAYFROMTPREF$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "switchAwayFromTpRef" element
     */
    public void setSwitchAwayFromTpRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchAwayFromTpRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SWITCHAWAYFROMTPREF$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SWITCHAWAYFROMTPREF$12);
            }
            target.set(switchAwayFromTpRef);
        }
    }
    
    /**
     * Appends and returns a new empty "switchAwayFromTpRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchAwayFromTpRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SWITCHAWAYFROMTPREF$12);
            return target;
        }
    }
    
    /**
     * Gets the "switchToTpRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchToTpRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SWITCHTOTPREF$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "switchToTpRef" element
     */
    public boolean isSetSwitchToTpRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHTOTPREF$14) != 0;
        }
    }
    
    /**
     * Sets the "switchToTpRef" element
     */
    public void setSwitchToTpRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchToTpRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SWITCHTOTPREF$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SWITCHTOTPREF$14);
            }
            target.set(switchToTpRef);
        }
    }
    
    /**
     * Appends and returns a new empty "switchToTpRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchToTpRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SWITCHTOTPREF$14);
            return target;
        }
    }
    
    /**
     * Unsets the "switchToTpRef" element
     */
    public void unsetSwitchToTpRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHTOTPREF$14, 0);
        }
    }
}
