/*
 * XML Type:  PmDataListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmdata/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmdata.v1.impl;
/**
 * An XML PmDataListType(@http://www.tmforum.org/mtop/nra/xsd/pmdata/v1).
 *
 * This is a complex type.
 */
public class PmDataListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType
{
    
    public PmDataListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmdata/v1", "pmData");
    
    
    /**
     * Gets a List of "pmData" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType> getPmDataList()
    {
        final class PmDataList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType>
        {
            public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType get(int i)
                { return PmDataListTypeImpl.this.getPmDataArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType set(int i, org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType o)
            {
                org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType old = PmDataListTypeImpl.this.getPmDataArray(i);
                PmDataListTypeImpl.this.setPmDataArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType o)
                { PmDataListTypeImpl.this.insertNewPmData(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType old = PmDataListTypeImpl.this.getPmDataArray(i);
                PmDataListTypeImpl.this.removePmData(i);
                return old;
            }
            
            public int size()
                { return PmDataListTypeImpl.this.sizeOfPmDataArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmDataList();
        }
    }
    
    /**
     * Gets array of all "pmData" elements
     */
    public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType[] getPmDataArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMDATA$0, targetList);
            org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType[] result = new org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pmData" element
     */
    public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType getPmDataArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType)get_store().find_element_user(PMDATA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pmData" element
     */
    public int sizeOfPmDataArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMDATA$0);
        }
    }
    
    /**
     * Sets array of all "pmData" element
     */
    public void setPmDataArray(org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType[] pmDataArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmDataArray, PMDATA$0);
        }
    }
    
    /**
     * Sets ith "pmData" element
     */
    public void setPmDataArray(int i, org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType pmData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType)get_store().find_element_user(PMDATA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmData);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmData" element
     */
    public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType insertNewPmData(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType)get_store().insert_element_user(PMDATA$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmData" element
     */
    public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType addNewPmData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType)get_store().add_element_user(PMDATA$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmData" element
     */
    public void removePmData(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMDATA$0, i);
        }
    }
}
