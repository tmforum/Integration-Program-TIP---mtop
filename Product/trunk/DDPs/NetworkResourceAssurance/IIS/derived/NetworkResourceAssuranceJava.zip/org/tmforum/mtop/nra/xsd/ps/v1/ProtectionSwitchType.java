/*
 * XML Type:  ProtectionSwitchType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/ps/v1
 * Java type: org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.ps.v1;


/**
 * An XML ProtectionSwitchType(@http://www.tmforum.org/mtop/nra/xsd/ps/v1).
 *
 * This is a complex type.
 */
public interface ProtectionSwitchType extends org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProtectionSwitchType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3302A0BB3167604C489D394E7972B422").resolveHandle("protectionswitchtypee512type");
    
    /**
     * Gets the "osTime" element
     */
    java.util.Calendar getOsTime();
    
    /**
     * Gets (as xml) the "osTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetOsTime();
    
    /**
     * True if has "osTime" element
     */
    boolean isSetOsTime();
    
    /**
     * Sets the "osTime" element
     */
    void setOsTime(java.util.Calendar osTime);
    
    /**
     * Sets (as xml) the "osTime" element
     */
    void xsetOsTime(org.apache.xmlbeans.XmlDateTime osTime);
    
    /**
     * Unsets the "osTime" element
     */
    void unsetOsTime();
    
    /**
     * Gets the "protectionType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType getProtectionType();
    
    /**
     * True if has "protectionType" element
     */
    boolean isSetProtectionType();
    
    /**
     * Sets the "protectionType" element
     */
    void setProtectionType(org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType protectionType);
    
    /**
     * Appends and returns a new empty "protectionType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType addNewProtectionType();
    
    /**
     * Unsets the "protectionType" element
     */
    void unsetProtectionType();
    
    /**
     * Gets the "switchReason" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum getSwitchReason();
    
    /**
     * Gets (as xml) the "switchReason" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType xgetSwitchReason();
    
    /**
     * True if has "switchReason" element
     */
    boolean isSetSwitchReason();
    
    /**
     * Sets the "switchReason" element
     */
    void setSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum switchReason);
    
    /**
     * Sets (as xml) the "switchReason" element
     */
    void xsetSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType switchReason);
    
    /**
     * Unsets the "switchReason" element
     */
    void unsetSwitchReason();
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Gets the "groupNameRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getGroupNameRef();
    
    /**
     * True if has "groupNameRef" element
     */
    boolean isSetGroupNameRef();
    
    /**
     * Sets the "groupNameRef" element
     */
    void setGroupNameRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType groupNameRef);
    
    /**
     * Appends and returns a new empty "groupNameRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewGroupNameRef();
    
    /**
     * Unsets the "groupNameRef" element
     */
    void unsetGroupNameRef();
    
    /**
     * Gets the "protectedTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProtectedTpRef();
    
    /**
     * Sets the "protectedTpRef" element
     */
    void setProtectedTpRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType protectedTpRef);
    
    /**
     * Appends and returns a new empty "protectedTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProtectedTpRef();
    
    /**
     * Gets the "switchAwayFromTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchAwayFromTpRef();
    
    /**
     * Sets the "switchAwayFromTpRef" element
     */
    void setSwitchAwayFromTpRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchAwayFromTpRef);
    
    /**
     * Appends and returns a new empty "switchAwayFromTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchAwayFromTpRef();
    
    /**
     * Gets the "switchToTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchToTpRef();
    
    /**
     * True if has "switchToTpRef" element
     */
    boolean isSetSwitchToTpRef();
    
    /**
     * Sets the "switchToTpRef" element
     */
    void setSwitchToTpRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchToTpRef);
    
    /**
     * Appends and returns a new empty "switchToTpRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchToTpRef();
    
    /**
     * Unsets the "switchToTpRef" element
     */
    void unsetSwitchToTpRef();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType newInstance() {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
