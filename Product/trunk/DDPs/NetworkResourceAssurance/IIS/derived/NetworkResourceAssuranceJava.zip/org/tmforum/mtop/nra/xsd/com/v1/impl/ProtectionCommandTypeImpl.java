/*
 * XML Type:  ProtectionCommandType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1.impl;
/**
 * An XML ProtectionCommandType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType.
 */
public class ProtectionCommandTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType
{
    
    public ProtectionCommandTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ProtectionCommandTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
