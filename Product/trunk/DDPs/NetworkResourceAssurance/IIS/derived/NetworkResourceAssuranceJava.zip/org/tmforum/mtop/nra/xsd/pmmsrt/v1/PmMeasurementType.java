/*
 * XML Type:  PmMeasurementType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmmsrt.v1;


/**
 * An XML PmMeasurementType(@http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1).
 *
 * This is a complex type.
 */
public interface PmMeasurementType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PmMeasurementType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("pmmeasurementtypea210type");
    
    /**
     * Gets the "pmParameterName" element
     */
    java.lang.String getPmParameterName();
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName();
    
    /**
     * Tests for nil "pmParameterName" element
     */
    boolean isNilPmParameterName();
    
    /**
     * True if has "pmParameterName" element
     */
    boolean isSetPmParameterName();
    
    /**
     * Sets the "pmParameterName" element
     */
    void setPmParameterName(java.lang.String pmParameterName);
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName);
    
    /**
     * Nils the "pmParameterName" element
     */
    void setNilPmParameterName();
    
    /**
     * Unsets the "pmParameterName" element
     */
    void unsetPmParameterName();
    
    /**
     * Gets the "pmLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getPmLocation();
    
    /**
     * Gets (as xml) the "pmLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetPmLocation();
    
    /**
     * Tests for nil "pmLocation" element
     */
    boolean isNilPmLocation();
    
    /**
     * True if has "pmLocation" element
     */
    boolean isSetPmLocation();
    
    /**
     * Sets the "pmLocation" element
     */
    void setPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation);
    
    /**
     * Sets (as xml) the "pmLocation" element
     */
    void xsetPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType pmLocation);
    
    /**
     * Nils the "pmLocation" element
     */
    void setNilPmLocation();
    
    /**
     * Unsets the "pmLocation" element
     */
    void unsetPmLocation();
    
    /**
     * Gets the "value" element
     */
    float getValue();
    
    /**
     * Gets (as xml) the "value" element
     */
    org.apache.xmlbeans.XmlFloat xgetValue();
    
    /**
     * Tests for nil "value" element
     */
    boolean isNilValue();
    
    /**
     * True if has "value" element
     */
    boolean isSetValue();
    
    /**
     * Sets the "value" element
     */
    void setValue(float value);
    
    /**
     * Sets (as xml) the "value" element
     */
    void xsetValue(org.apache.xmlbeans.XmlFloat value);
    
    /**
     * Nils the "value" element
     */
    void setNilValue();
    
    /**
     * Unsets the "value" element
     */
    void unsetValue();
    
    /**
     * Gets the "measurementUnits" element
     */
    java.lang.String getMeasurementUnits();
    
    /**
     * Gets (as xml) the "measurementUnits" element
     */
    org.apache.xmlbeans.XmlString xgetMeasurementUnits();
    
    /**
     * Tests for nil "measurementUnits" element
     */
    boolean isNilMeasurementUnits();
    
    /**
     * True if has "measurementUnits" element
     */
    boolean isSetMeasurementUnits();
    
    /**
     * Sets the "measurementUnits" element
     */
    void setMeasurementUnits(java.lang.String measurementUnits);
    
    /**
     * Sets (as xml) the "measurementUnits" element
     */
    void xsetMeasurementUnits(org.apache.xmlbeans.XmlString measurementUnits);
    
    /**
     * Nils the "measurementUnits" element
     */
    void setNilMeasurementUnits();
    
    /**
     * Unsets the "measurementUnits" element
     */
    void unsetMeasurementUnits();
    
    /**
     * Gets the "pmIntervalStatus" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType.Enum getPmIntervalStatus();
    
    /**
     * Gets (as xml) the "pmIntervalStatus" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType xgetPmIntervalStatus();
    
    /**
     * Tests for nil "pmIntervalStatus" element
     */
    boolean isNilPmIntervalStatus();
    
    /**
     * True if has "pmIntervalStatus" element
     */
    boolean isSetPmIntervalStatus();
    
    /**
     * Sets the "pmIntervalStatus" element
     */
    void setPmIntervalStatus(org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType.Enum pmIntervalStatus);
    
    /**
     * Sets (as xml) the "pmIntervalStatus" element
     */
    void xsetPmIntervalStatus(org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType pmIntervalStatus);
    
    /**
     * Nils the "pmIntervalStatus" element
     */
    void setNilPmIntervalStatus();
    
    /**
     * Unsets the "pmIntervalStatus" element
     */
    void unsetPmIntervalStatus();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType newInstance() {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
