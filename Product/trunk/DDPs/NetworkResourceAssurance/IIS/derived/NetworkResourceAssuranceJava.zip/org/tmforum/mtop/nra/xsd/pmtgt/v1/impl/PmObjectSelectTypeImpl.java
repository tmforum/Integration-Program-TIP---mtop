/*
 * XML Type:  PmObjectSelectType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmtgt.v1.impl;
/**
 * An XML PmObjectSelectType(@http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1).
 *
 * This is a complex type.
 */
public class PmObjectSelectTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType
{
    
    public PmObjectSelectTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1", "name");
    private static final javax.xml.namespace.QName LAYERRATES$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1", "layerRates");
    private static final javax.xml.namespace.QName PMLOCATIONLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1", "pmLocationList");
    private static final javax.xml.namespace.QName GRANULARITYLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1", "granularityList");
    
    
    /**
     * Gets the "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "name" element
     */
    public boolean isNilName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "name" element
     */
    public boolean isSetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NAME$0) != 0;
        }
    }
    
    /**
     * Sets the "name" element
     */
    public void setName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            }
            target.set(name);
        }
    }
    
    /**
     * Appends and returns a new empty "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            return target;
        }
    }
    
    /**
     * Nils the "name" element
     */
    public void setNilName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "name" element
     */
    public void unsetName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NAME$0, 0);
        }
    }
    
    /**
     * Gets the "layerRates" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getLayerRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATES$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "layerRates" element
     */
    public boolean isNilLayerRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATES$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "layerRates" element
     */
    public boolean isSetLayerRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATES$2) != 0;
        }
    }
    
    /**
     * Sets the "layerRates" element
     */
    public void setLayerRates(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType layerRates)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATES$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATES$2);
            }
            target.set(layerRates);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRates" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewLayerRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATES$2);
            return target;
        }
    }
    
    /**
     * Nils the "layerRates" element
     */
    public void setNilLayerRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATES$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATES$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "layerRates" element
     */
    public void unsetLayerRates()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATES$2, 0);
        }
    }
    
    /**
     * Gets the "pmLocationList" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType getPmLocationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType)get_store().find_element_user(PMLOCATIONLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "pmLocationList" element
     */
    public boolean isNilPmLocationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType)get_store().find_element_user(PMLOCATIONLIST$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmLocationList" element
     */
    public boolean isSetPmLocationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMLOCATIONLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "pmLocationList" element
     */
    public void setPmLocationList(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType pmLocationList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType)get_store().find_element_user(PMLOCATIONLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType)get_store().add_element_user(PMLOCATIONLIST$4);
            }
            target.set(pmLocationList);
        }
    }
    
    /**
     * Appends and returns a new empty "pmLocationList" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType addNewPmLocationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType)get_store().add_element_user(PMLOCATIONLIST$4);
            return target;
        }
    }
    
    /**
     * Nils the "pmLocationList" element
     */
    public void setNilPmLocationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType)get_store().find_element_user(PMLOCATIONLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType)get_store().add_element_user(PMLOCATIONLIST$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmLocationList" element
     */
    public void unsetPmLocationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMLOCATIONLIST$4, 0);
        }
    }
    
    /**
     * Gets the "granularityList" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType getGranularityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType)get_store().find_element_user(GRANULARITYLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "granularityList" element
     */
    public boolean isNilGranularityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType)get_store().find_element_user(GRANULARITYLIST$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "granularityList" element
     */
    public boolean isSetGranularityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GRANULARITYLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "granularityList" element
     */
    public void setGranularityList(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType granularityList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType)get_store().find_element_user(GRANULARITYLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType)get_store().add_element_user(GRANULARITYLIST$6);
            }
            target.set(granularityList);
        }
    }
    
    /**
     * Appends and returns a new empty "granularityList" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType addNewGranularityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType)get_store().add_element_user(GRANULARITYLIST$6);
            return target;
        }
    }
    
    /**
     * Nils the "granularityList" element
     */
    public void setNilGranularityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType)get_store().find_element_user(GRANULARITYLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType)get_store().add_element_user(GRANULARITYLIST$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "granularityList" element
     */
    public void unsetGranularityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GRANULARITYLIST$6, 0);
        }
    }
}
