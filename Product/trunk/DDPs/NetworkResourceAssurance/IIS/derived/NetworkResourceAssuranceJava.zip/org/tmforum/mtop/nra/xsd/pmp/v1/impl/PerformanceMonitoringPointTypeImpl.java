/*
 * XML Type:  PerformanceMonitoringPointType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmp.v1.impl;
/**
 * An XML PerformanceMonitoringPointType(@http://www.tmforum.org/mtop/nra/xsd/pmp/v1).
 *
 * This is a complex type.
 */
public class PerformanceMonitoringPointTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType
{
    
    public PerformanceMonitoringPointTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LAYERRATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmp/v1", "layerRate");
    private static final javax.xml.namespace.QName PMLOCATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmp/v1", "pmLocation");
    private static final javax.xml.namespace.QName GRANULARITY$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmp/v1", "granularity");
    private static final javax.xml.namespace.QName SUPERVISIONSTATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmp/v1", "supervisionState");
    private static final javax.xml.namespace.QName MONITORINGSTATE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmp/v1", "monitoringState");
    private static final javax.xml.namespace.QName PMPARAMETERLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmp/v1", "pmParameterList");
    private static final javax.xml.namespace.QName PMTHRESHOLDLIST$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmp/v1", "pmThresholdList");
    
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "layerRate" element
     */
    public boolean isNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$0) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            return target;
        }
    }
    
    /**
     * Nils the "layerRate" element
     */
    public void setNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$0, 0);
        }
    }
    
    /**
     * Gets the "pmLocation" element
     */
    public java.lang.String getPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmLocation" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.LocationType xgetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(PMLOCATION$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "pmLocation" element
     */
    public boolean isNilPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmLocation" element
     */
    public boolean isSetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMLOCATION$2) != 0;
        }
    }
    
    /**
     * Sets the "pmLocation" element
     */
    public void setPmLocation(java.lang.String pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMLOCATION$2);
            }
            target.setStringValue(pmLocation);
        }
    }
    
    /**
     * Sets (as xml) the "pmLocation" element
     */
    public void xsetPmLocation(org.tmforum.mtop.fmw.xsd.gen.v1.LocationType pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().add_element_user(PMLOCATION$2);
            }
            target.set(pmLocation);
        }
    }
    
    /**
     * Nils the "pmLocation" element
     */
    public void setNilPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.LocationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.LocationType)get_store().add_element_user(PMLOCATION$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmLocation" element
     */
    public void unsetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMLOCATION$2, 0);
        }
    }
    
    /**
     * Gets the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "granularity" element
     */
    public boolean isNilGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "granularity" element
     */
    public boolean isSetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GRANULARITY$4) != 0;
        }
    }
    
    /**
     * Sets the "granularity" element
     */
    public void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(GRANULARITY$4);
            }
            target.setEnumValue(granularity);
        }
    }
    
    /**
     * Sets (as xml) the "granularity" element
     */
    public void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$4);
            }
            target.set(granularity);
        }
    }
    
    /**
     * Nils the "granularity" element
     */
    public void setNilGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "granularity" element
     */
    public void unsetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GRANULARITY$4, 0);
        }
    }
    
    /**
     * Gets the "supervisionState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum getSupervisionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPERVISIONSTATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "supervisionState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType xgetSupervisionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(SUPERVISIONSTATE$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "supervisionState" element
     */
    public boolean isNilSupervisionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(SUPERVISIONSTATE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "supervisionState" element
     */
    public boolean isSetSupervisionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUPERVISIONSTATE$6) != 0;
        }
    }
    
    /**
     * Sets the "supervisionState" element
     */
    public void setSupervisionState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum supervisionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SUPERVISIONSTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SUPERVISIONSTATE$6);
            }
            target.setEnumValue(supervisionState);
        }
    }
    
    /**
     * Sets (as xml) the "supervisionState" element
     */
    public void xsetSupervisionState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType supervisionState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(SUPERVISIONSTATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().add_element_user(SUPERVISIONSTATE$6);
            }
            target.set(supervisionState);
        }
    }
    
    /**
     * Nils the "supervisionState" element
     */
    public void setNilSupervisionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(SUPERVISIONSTATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().add_element_user(SUPERVISIONSTATE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "supervisionState" element
     */
    public void unsetSupervisionState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUPERVISIONSTATE$6, 0);
        }
    }
    
    /**
     * Gets the "monitoringState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum getMonitoringState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MONITORINGSTATE$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "monitoringState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType xgetMonitoringState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(MONITORINGSTATE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "monitoringState" element
     */
    public boolean isNilMonitoringState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(MONITORINGSTATE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "monitoringState" element
     */
    public boolean isSetMonitoringState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MONITORINGSTATE$8) != 0;
        }
    }
    
    /**
     * Sets the "monitoringState" element
     */
    public void setMonitoringState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum monitoringState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MONITORINGSTATE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MONITORINGSTATE$8);
            }
            target.setEnumValue(monitoringState);
        }
    }
    
    /**
     * Sets (as xml) the "monitoringState" element
     */
    public void xsetMonitoringState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType monitoringState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(MONITORINGSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().add_element_user(MONITORINGSTATE$8);
            }
            target.set(monitoringState);
        }
    }
    
    /**
     * Nils the "monitoringState" element
     */
    public void setNilMonitoringState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(MONITORINGSTATE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().add_element_user(MONITORINGSTATE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "monitoringState" element
     */
    public void unsetMonitoringState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MONITORINGSTATE$8, 0);
        }
    }
    
    /**
     * Gets the "pmParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType getPmParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().find_element_user(PMPARAMETERLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "pmParameterList" element
     */
    public boolean isNilPmParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().find_element_user(PMPARAMETERLIST$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmParameterList" element
     */
    public boolean isSetPmParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETERLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "pmParameterList" element
     */
    public void setPmParameterList(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType pmParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().find_element_user(PMPARAMETERLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().add_element_user(PMPARAMETERLIST$10);
            }
            target.set(pmParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "pmParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType addNewPmParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().add_element_user(PMPARAMETERLIST$10);
            return target;
        }
    }
    
    /**
     * Nils the "pmParameterList" element
     */
    public void setNilPmParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().find_element_user(PMPARAMETERLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().add_element_user(PMPARAMETERLIST$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmParameterList" element
     */
    public void unsetPmParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETERLIST$10, 0);
        }
    }
    
    /**
     * Gets the "pmThresholdList" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType getPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().find_element_user(PMTHRESHOLDLIST$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "pmThresholdList" element
     */
    public boolean isNilPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().find_element_user(PMTHRESHOLDLIST$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmThresholdList" element
     */
    public boolean isSetPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMTHRESHOLDLIST$12) != 0;
        }
    }
    
    /**
     * Sets the "pmThresholdList" element
     */
    public void setPmThresholdList(org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType pmThresholdList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().find_element_user(PMTHRESHOLDLIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().add_element_user(PMTHRESHOLDLIST$12);
            }
            target.set(pmThresholdList);
        }
    }
    
    /**
     * Appends and returns a new empty "pmThresholdList" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType addNewPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().add_element_user(PMTHRESHOLDLIST$12);
            return target;
        }
    }
    
    /**
     * Nils the "pmThresholdList" element
     */
    public void setNilPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().find_element_user(PMTHRESHOLDLIST$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().add_element_user(PMTHRESHOLDLIST$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmThresholdList" element
     */
    public void unsetPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMTHRESHOLDLIST$12, 0);
        }
    }
}
