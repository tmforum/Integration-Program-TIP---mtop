/*
 * XML Type:  ObjectEnumType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1;


/**
 * An XML ObjectEnumType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType.
 */
public interface ObjectEnumType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ObjectEnumType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3302A0BB3167604C489D394E7972B422").resolveHandle("objectenumtypea809type");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum AID = Enum.forString("AID");
    static final Enum ASA = Enum.forString("ASA");
    static final Enum ASAP = Enum.forString("ASAP");
    static final Enum CTP = Enum.forString("CTP");
    static final Enum EH = Enum.forString("EH");
    static final Enum EPG = Enum.forString("EPG");
    static final Enum EQ = Enum.forString("EQ");
    static final Enum FD = Enum.forString("FD");
    static final Enum FDFR = Enum.forString("FDFR");
    static final Enum FTP = Enum.forString("FTP");
    static final Enum GTP = Enum.forString("GTP");
    static final Enum MD = Enum.forString("MD");
    static final Enum ME = Enum.forString("ME");
    static final Enum MFD = Enum.forString("MFD");
    static final Enum MLSN = Enum.forString("MLSN");
    static final Enum OS = Enum.forString("OS");
    static final Enum PG = Enum.forString("PG");
    static final Enum PMP = Enum.forString("PMP");
    static final Enum PTP = Enum.forString("PTP");
    static final Enum SNC = Enum.forString("SNC");
    static final Enum TCPROFILE = Enum.forString("TCPROFILE");
    static final Enum TCAPP = Enum.forString("TCAPP");
    static final Enum TL = Enum.forString("TL");
    static final Enum TMD = Enum.forString("TMD");
    static final Enum TPPOOL = Enum.forString("TPPOOL");
    
    static final int INT_AID = Enum.INT_AID;
    static final int INT_ASA = Enum.INT_ASA;
    static final int INT_ASAP = Enum.INT_ASAP;
    static final int INT_CTP = Enum.INT_CTP;
    static final int INT_EH = Enum.INT_EH;
    static final int INT_EPG = Enum.INT_EPG;
    static final int INT_EQ = Enum.INT_EQ;
    static final int INT_FD = Enum.INT_FD;
    static final int INT_FDFR = Enum.INT_FDFR;
    static final int INT_FTP = Enum.INT_FTP;
    static final int INT_GTP = Enum.INT_GTP;
    static final int INT_MD = Enum.INT_MD;
    static final int INT_ME = Enum.INT_ME;
    static final int INT_MFD = Enum.INT_MFD;
    static final int INT_MLSN = Enum.INT_MLSN;
    static final int INT_OS = Enum.INT_OS;
    static final int INT_PG = Enum.INT_PG;
    static final int INT_PMP = Enum.INT_PMP;
    static final int INT_PTP = Enum.INT_PTP;
    static final int INT_SNC = Enum.INT_SNC;
    static final int INT_TCPROFILE = Enum.INT_TCPROFILE;
    static final int INT_TCAPP = Enum.INT_TCAPP;
    static final int INT_TL = Enum.INT_TL;
    static final int INT_TMD = Enum.INT_TMD;
    static final int INT_TPPOOL = Enum.INT_TPPOOL;
    
    /**
     * Enumeration value class for org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_AID
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_AID = 1;
        static final int INT_ASA = 2;
        static final int INT_ASAP = 3;
        static final int INT_CTP = 4;
        static final int INT_EH = 5;
        static final int INT_EPG = 6;
        static final int INT_EQ = 7;
        static final int INT_FD = 8;
        static final int INT_FDFR = 9;
        static final int INT_FTP = 10;
        static final int INT_GTP = 11;
        static final int INT_MD = 12;
        static final int INT_ME = 13;
        static final int INT_MFD = 14;
        static final int INT_MLSN = 15;
        static final int INT_OS = 16;
        static final int INT_PG = 17;
        static final int INT_PMP = 18;
        static final int INT_PTP = 19;
        static final int INT_SNC = 20;
        static final int INT_TCPROFILE = 21;
        static final int INT_TCAPP = 22;
        static final int INT_TL = 23;
        static final int INT_TMD = 24;
        static final int INT_TPPOOL = 25;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("AID", INT_AID),
                new Enum("ASA", INT_ASA),
                new Enum("ASAP", INT_ASAP),
                new Enum("CTP", INT_CTP),
                new Enum("EH", INT_EH),
                new Enum("EPG", INT_EPG),
                new Enum("EQ", INT_EQ),
                new Enum("FD", INT_FD),
                new Enum("FDFR", INT_FDFR),
                new Enum("FTP", INT_FTP),
                new Enum("GTP", INT_GTP),
                new Enum("MD", INT_MD),
                new Enum("ME", INT_ME),
                new Enum("MFD", INT_MFD),
                new Enum("MLSN", INT_MLSN),
                new Enum("OS", INT_OS),
                new Enum("PG", INT_PG),
                new Enum("PMP", INT_PMP),
                new Enum("PTP", INT_PTP),
                new Enum("SNC", INT_SNC),
                new Enum("TCPROFILE", INT_TCPROFILE),
                new Enum("TCAPP", INT_TCAPP),
                new Enum("TL", INT_TL),
                new Enum("TMD", INT_TMD),
                new Enum("TPPOOL", INT_TPPOOL),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType newValue(java.lang.Object obj) {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) type.newValue( obj ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType newInstance() {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
