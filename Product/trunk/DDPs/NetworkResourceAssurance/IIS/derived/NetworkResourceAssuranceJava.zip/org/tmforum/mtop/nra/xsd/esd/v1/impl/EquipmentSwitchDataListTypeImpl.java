/*
 * XML Type:  EquipmentSwitchDataListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/esd/v1
 * Java type: org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.esd.v1.impl;
/**
 * An XML EquipmentSwitchDataListType(@http://www.tmforum.org/mtop/nra/xsd/esd/v1).
 *
 * This is a complex type.
 */
public class EquipmentSwitchDataListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataListType
{
    
    public EquipmentSwitchDataListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EQUIPMENTSWITCHDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/esd/v1", "equipmentSwitchData");
    
    
    /**
     * Gets a List of "equipmentSwitchData" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType> getEquipmentSwitchDataList()
    {
        final class EquipmentSwitchDataList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType>
        {
            public org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType get(int i)
                { return EquipmentSwitchDataListTypeImpl.this.getEquipmentSwitchDataArray(i); }
            
            public org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType set(int i, org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType o)
            {
                org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType old = EquipmentSwitchDataListTypeImpl.this.getEquipmentSwitchDataArray(i);
                EquipmentSwitchDataListTypeImpl.this.setEquipmentSwitchDataArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType o)
                { EquipmentSwitchDataListTypeImpl.this.insertNewEquipmentSwitchData(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType old = EquipmentSwitchDataListTypeImpl.this.getEquipmentSwitchDataArray(i);
                EquipmentSwitchDataListTypeImpl.this.removeEquipmentSwitchData(i);
                return old;
            }
            
            public int size()
                { return EquipmentSwitchDataListTypeImpl.this.sizeOfEquipmentSwitchDataArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new EquipmentSwitchDataList();
        }
    }
    
    /**
     * Gets array of all "equipmentSwitchData" elements
     */
    public org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType[] getEquipmentSwitchDataArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EQUIPMENTSWITCHDATA$0, targetList);
            org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType[] result = new org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "equipmentSwitchData" element
     */
    public org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType getEquipmentSwitchDataArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType)get_store().find_element_user(EQUIPMENTSWITCHDATA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "equipmentSwitchData" element
     */
    public int sizeOfEquipmentSwitchDataArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQUIPMENTSWITCHDATA$0);
        }
    }
    
    /**
     * Sets array of all "equipmentSwitchData" element
     */
    public void setEquipmentSwitchDataArray(org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType[] equipmentSwitchDataArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(equipmentSwitchDataArray, EQUIPMENTSWITCHDATA$0);
        }
    }
    
    /**
     * Sets ith "equipmentSwitchData" element
     */
    public void setEquipmentSwitchDataArray(int i, org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType equipmentSwitchData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType)get_store().find_element_user(EQUIPMENTSWITCHDATA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(equipmentSwitchData);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "equipmentSwitchData" element
     */
    public org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType insertNewEquipmentSwitchData(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType)get_store().insert_element_user(EQUIPMENTSWITCHDATA$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "equipmentSwitchData" element
     */
    public org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType addNewEquipmentSwitchData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType)get_store().add_element_user(EQUIPMENTSWITCHDATA$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "equipmentSwitchData" element
     */
    public void removeEquipmentSwitchData(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQUIPMENTSWITCHDATA$0, i);
        }
    }
}
