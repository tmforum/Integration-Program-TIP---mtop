/*
 * XML Type:  PmParameterType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmpar/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmpar.v1.impl;
/**
 * An XML PmParameterType(@http://www.tmforum.org/mtop/nra/xsd/pmpar/v1).
 *
 * This is a complex type.
 */
public class PmParameterTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType
{
    
    public PmParameterTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETER$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmpar/v1", "pmParameter");
    private static final javax.xml.namespace.QName PMLOCATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmpar/v1", "pmLocation");
    
    
    /**
     * Gets a List of "pmParameter" elements
     */
    public java.util.List<java.lang.String> getPmParameterList()
    {
        final class PmParameterList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return PmParameterTypeImpl.this.getPmParameterArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = PmParameterTypeImpl.this.getPmParameterArray(i);
                PmParameterTypeImpl.this.setPmParameterArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { PmParameterTypeImpl.this.insertPmParameter(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = PmParameterTypeImpl.this.getPmParameterArray(i);
                PmParameterTypeImpl.this.removePmParameter(i);
                return old;
            }
            
            public int size()
                { return PmParameterTypeImpl.this.sizeOfPmParameterArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmParameterList();
        }
    }
    
    /**
     * Gets array of all "pmParameter" elements
     */
    public java.lang.String[] getPmParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMPARAMETER$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "pmParameter" element
     */
    public java.lang.String getPmParameterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "pmParameter" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType> xgetPmParameterList()
    {
        final class PmParameterList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType get(int i)
                { return PmParameterTypeImpl.this.xgetPmParameterArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType old = PmParameterTypeImpl.this.xgetPmParameterArray(i);
                PmParameterTypeImpl.this.xsetPmParameterArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType o)
                { PmParameterTypeImpl.this.insertNewPmParameter(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType old = PmParameterTypeImpl.this.xgetPmParameterArray(i);
                PmParameterTypeImpl.this.removePmParameter(i);
                return old;
            }
            
            public int size()
                { return PmParameterTypeImpl.this.sizeOfPmParameterArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmParameterList();
        }
    }
    
    /**
     * Gets (as xml) array of all "pmParameter" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[] xgetPmParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMPARAMETER$0, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "pmParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)target;
        }
    }
    
    /**
     * Returns number of "pmParameter" element
     */
    public int sizeOfPmParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETER$0);
        }
    }
    
    /**
     * Sets array of all "pmParameter" element
     */
    public void setPmParameterArray(java.lang.String[] pmParameterArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmParameterArray, PMPARAMETER$0);
        }
    }
    
    /**
     * Sets ith "pmParameter" element
     */
    public void setPmParameterArray(int i, java.lang.String pmParameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(pmParameter);
        }
    }
    
    /**
     * Sets (as xml) array of all "pmParameter" element
     */
    public void xsetPmParameterArray(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[]pmParameterArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmParameterArray, PMPARAMETER$0);
        }
    }
    
    /**
     * Sets (as xml) ith "pmParameter" element
     */
    public void xsetPmParameterArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmParameter);
        }
    }
    
    /**
     * Inserts the value as the ith "pmParameter" element
     */
    public void insertPmParameter(int i, java.lang.String pmParameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PMPARAMETER$0, i);
            target.setStringValue(pmParameter);
        }
    }
    
    /**
     * Appends the value as the last "pmParameter" element
     */
    public void addPmParameter(java.lang.String pmParameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMPARAMETER$0);
            target.setStringValue(pmParameter);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType insertNewPmParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().insert_element_user(PMPARAMETER$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType addNewPmParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETER$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmParameter" element
     */
    public void removePmParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETER$0, i);
        }
    }
    
    /**
     * Gets a List of "pmLocation" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum> getPmLocationList()
    {
        final class PmLocationList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum get(int i)
                { return PmParameterTypeImpl.this.getPmLocationArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum old = PmParameterTypeImpl.this.getPmLocationArray(i);
                PmParameterTypeImpl.this.setPmLocationArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum o)
                { PmParameterTypeImpl.this.insertPmLocation(i, o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum old = PmParameterTypeImpl.this.getPmLocationArray(i);
                PmParameterTypeImpl.this.removePmLocation(i);
                return old;
            }
            
            public int size()
                { return PmParameterTypeImpl.this.sizeOfPmLocationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmLocationList();
        }
    }
    
    /**
     * Gets array of all "pmLocation" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] getPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMLOCATION$2, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
            return result;
        }
    }
    
    /**
     * Gets ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getPmLocationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "pmLocation" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType> xgetPmLocationList()
    {
        final class PmLocationList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType get(int i)
                { return PmParameterTypeImpl.this.xgetPmLocationArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType old = PmParameterTypeImpl.this.xgetPmLocationArray(i);
                PmParameterTypeImpl.this.xsetPmLocationArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType o)
                { PmParameterTypeImpl.this.insertNewPmLocation(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType old = PmParameterTypeImpl.this.xgetPmLocationArray(i);
                PmParameterTypeImpl.this.removePmLocation(i);
                return old;
            }
            
            public int size()
                { return PmParameterTypeImpl.this.sizeOfPmLocationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmLocationList();
        }
    }
    
    /**
     * Gets (as xml) array of all "pmLocation" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[] xgetPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMLOCATION$2, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetPmLocationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)target;
        }
    }
    
    /**
     * Returns number of "pmLocation" element
     */
    public int sizeOfPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMLOCATION$2);
        }
    }
    
    /**
     * Sets array of all "pmLocation" element
     */
    public void setPmLocationArray(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] pmLocationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmLocationArray, PMLOCATION$2);
        }
    }
    
    /**
     * Sets ith "pmLocation" element
     */
    public void setPmLocationArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Sets (as xml) array of all "pmLocation" element
     */
    public void xsetPmLocationArray(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[]pmLocationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmLocationArray, PMLOCATION$2);
        }
    }
    
    /**
     * Sets (as xml) ith "pmLocation" element
     */
    public void xsetPmLocationArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmLocation);
        }
    }
    
    /**
     * Inserts the value as the ith "pmLocation" element
     */
    public void insertPmLocation(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PMLOCATION$2, i);
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Appends the value as the last "pmLocation" element
     */
    public void addPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMLOCATION$2);
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType insertNewPmLocation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().insert_element_user(PMLOCATION$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType addNewPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().add_element_user(PMLOCATION$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmLocation" element
     */
    public void removePmLocation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMLOCATION$2, i);
        }
    }
}
