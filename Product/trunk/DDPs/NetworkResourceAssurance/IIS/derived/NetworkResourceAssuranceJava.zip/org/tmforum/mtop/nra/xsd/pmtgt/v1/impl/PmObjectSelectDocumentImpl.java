/*
 * An XML document type.
 * Localname: pmObjectSelect
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmtgt.v1.impl;
/**
 * A document containing one pmObjectSelect(@http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1) element.
 *
 * This is a complex type.
 */
public class PmObjectSelectDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectDocument
{
    
    public PmObjectSelectDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMOBJECTSELECT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1", "pmObjectSelect");
    
    
    /**
     * Gets the "pmObjectSelect" element
     */
    public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType getPmObjectSelect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType)get_store().find_element_user(PMOBJECTSELECT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pmObjectSelect" element
     */
    public void setPmObjectSelect(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType pmObjectSelect)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType)get_store().find_element_user(PMOBJECTSELECT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType)get_store().add_element_user(PMOBJECTSELECT$0);
            }
            target.set(pmObjectSelect);
        }
    }
    
    /**
     * Appends and returns a new empty "pmObjectSelect" element
     */
    public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType addNewPmObjectSelect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType)get_store().add_element_user(PMOBJECTSELECT$0);
            return target;
        }
    }
}
