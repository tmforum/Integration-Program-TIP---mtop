/*
 * XML Type:  TcaParametersType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcapars/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcapars.v1.impl;
/**
 * An XML TcaParametersType(@http://www.tmforum.org/mtop/nra/xsd/tcapars/v1).
 *
 * This is a complex type.
 */
public class TcaParametersTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType
{
    
    public TcaParametersTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LAYERRATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapars/v1", "layerRate");
    private static final javax.xml.namespace.QName GRANULARITY$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapars/v1", "granularity");
    private static final javax.xml.namespace.QName TCATYPEVALUES$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapars/v1", "tcaTypeValues");
    
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "layerRate" element
     */
    public boolean isNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$0) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            return target;
        }
    }
    
    /**
     * Nils the "layerRate" element
     */
    public void setNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$0, 0);
        }
    }
    
    /**
     * Gets the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "granularity" element
     */
    public boolean isNilGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "granularity" element
     */
    public boolean isSetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GRANULARITY$2) != 0;
        }
    }
    
    /**
     * Sets the "granularity" element
     */
    public void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(GRANULARITY$2);
            }
            target.setEnumValue(granularity);
        }
    }
    
    /**
     * Sets (as xml) the "granularity" element
     */
    public void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$2);
            }
            target.set(granularity);
        }
    }
    
    /**
     * Nils the "granularity" element
     */
    public void setNilGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "granularity" element
     */
    public void unsetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GRANULARITY$2, 0);
        }
    }
    
    /**
     * Gets the "tcaTypeValues" element
     */
    public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType getTcaTypeValues()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType)get_store().find_element_user(TCATYPEVALUES$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "tcaTypeValues" element
     */
    public boolean isNilTcaTypeValues()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType)get_store().find_element_user(TCATYPEVALUES$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tcaTypeValues" element
     */
    public boolean isSetTcaTypeValues()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TCATYPEVALUES$4) != 0;
        }
    }
    
    /**
     * Sets the "tcaTypeValues" element
     */
    public void setTcaTypeValues(org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType tcaTypeValues)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType)get_store().find_element_user(TCATYPEVALUES$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType)get_store().add_element_user(TCATYPEVALUES$4);
            }
            target.set(tcaTypeValues);
        }
    }
    
    /**
     * Appends and returns a new empty "tcaTypeValues" element
     */
    public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType addNewTcaTypeValues()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType)get_store().add_element_user(TCATYPEVALUES$4);
            return target;
        }
    }
    
    /**
     * Nils the "tcaTypeValues" element
     */
    public void setNilTcaTypeValues()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType)get_store().find_element_user(TCATYPEVALUES$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType)get_store().add_element_user(TCATYPEVALUES$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tcaTypeValues" element
     */
    public void unsetTcaTypeValues()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TCATYPEVALUES$4, 0);
        }
    }
}
