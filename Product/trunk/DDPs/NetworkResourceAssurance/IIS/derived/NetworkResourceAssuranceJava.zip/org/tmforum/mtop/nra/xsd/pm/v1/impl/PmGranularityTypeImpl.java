/*
 * XML Type:  PmGranularityType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pm/v1
 * Java type: org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pm.v1.impl;
/**
 * An XML PmGranularityType(@http://www.tmforum.org/mtop/nra/xsd/pm/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.
 */
public class PmGranularityTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType
{
    
    public PmGranularityTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected PmGranularityTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
