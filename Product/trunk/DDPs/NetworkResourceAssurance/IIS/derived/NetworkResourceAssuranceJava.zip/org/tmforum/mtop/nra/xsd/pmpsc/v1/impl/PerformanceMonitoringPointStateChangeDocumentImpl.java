/*
 * An XML document type.
 * Localname: performanceMonitoringPointStateChange
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmpsc.v1.impl;
/**
 * A document containing one performanceMonitoringPointStateChange(@http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1) element.
 *
 * This is a complex type.
 */
public class PerformanceMonitoringPointStateChangeDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeDocument
{
    
    public PerformanceMonitoringPointStateChangeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERFORMANCEMONITORINGPOINTSTATECHANGE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1", "performanceMonitoringPointStateChange");
    
    
    /**
     * Gets the "performanceMonitoringPointStateChange" element
     */
    public org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType getPerformanceMonitoringPointStateChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType)get_store().find_element_user(PERFORMANCEMONITORINGPOINTSTATECHANGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "performanceMonitoringPointStateChange" element
     */
    public void setPerformanceMonitoringPointStateChange(org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType performanceMonitoringPointStateChange)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType)get_store().find_element_user(PERFORMANCEMONITORINGPOINTSTATECHANGE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType)get_store().add_element_user(PERFORMANCEMONITORINGPOINTSTATECHANGE$0);
            }
            target.set(performanceMonitoringPointStateChange);
        }
    }
    
    /**
     * Appends and returns a new empty "performanceMonitoringPointStateChange" element
     */
    public org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType addNewPerformanceMonitoringPointStateChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType)get_store().add_element_user(PERFORMANCEMONITORINGPOINTSTATECHANGE$0);
            return target;
        }
    }
}
