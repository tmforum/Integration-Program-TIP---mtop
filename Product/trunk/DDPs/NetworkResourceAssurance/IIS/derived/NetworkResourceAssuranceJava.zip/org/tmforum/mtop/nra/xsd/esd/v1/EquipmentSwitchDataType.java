/*
 * XML Type:  EquipmentSwitchDataType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/esd/v1
 * Java type: org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.esd.v1;


/**
 * An XML EquipmentSwitchDataType(@http://www.tmforum.org/mtop/nra/xsd/esd/v1).
 *
 * This is a complex type.
 */
public interface EquipmentSwitchDataType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EquipmentSwitchDataType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("equipmentswitchdatatype1c5ctype");
    
    /**
     * Gets the "equipmentProtectionGroupType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType getEquipmentProtectionGroupType();
    
    /**
     * Tests for nil "equipmentProtectionGroupType" element
     */
    boolean isNilEquipmentProtectionGroupType();
    
    /**
     * True if has "equipmentProtectionGroupType" element
     */
    boolean isSetEquipmentProtectionGroupType();
    
    /**
     * Sets the "equipmentProtectionGroupType" element
     */
    void setEquipmentProtectionGroupType(org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType equipmentProtectionGroupType);
    
    /**
     * Appends and returns a new empty "equipmentProtectionGroupType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType addNewEquipmentProtectionGroupType();
    
    /**
     * Nils the "equipmentProtectionGroupType" element
     */
    void setNilEquipmentProtectionGroupType();
    
    /**
     * Unsets the "equipmentProtectionGroupType" element
     */
    void unsetEquipmentProtectionGroupType();
    
    /**
     * Gets the "equipmentSwitchReason" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType getEquipmentSwitchReason();
    
    /**
     * Tests for nil "equipmentSwitchReason" element
     */
    boolean isNilEquipmentSwitchReason();
    
    /**
     * True if has "equipmentSwitchReason" element
     */
    boolean isSetEquipmentSwitchReason();
    
    /**
     * Sets the "equipmentSwitchReason" element
     */
    void setEquipmentSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType equipmentSwitchReason);
    
    /**
     * Appends and returns a new empty "equipmentSwitchReason" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType addNewEquipmentSwitchReason();
    
    /**
     * Nils the "equipmentSwitchReason" element
     */
    void setNilEquipmentSwitchReason();
    
    /**
     * Unsets the "equipmentSwitchReason" element
     */
    void unsetEquipmentSwitchReason();
    
    /**
     * Gets the "epgName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEpgName();
    
    /**
     * Tests for nil "epgName" element
     */
    boolean isNilEpgName();
    
    /**
     * True if has "epgName" element
     */
    boolean isSetEpgName();
    
    /**
     * Sets the "epgName" element
     */
    void setEpgName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType epgName);
    
    /**
     * Appends and returns a new empty "epgName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEpgName();
    
    /**
     * Nils the "epgName" element
     */
    void setNilEpgName();
    
    /**
     * Unsets the "epgName" element
     */
    void unsetEpgName();
    
    /**
     * Gets the "protectedEquipment" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProtectedEquipment();
    
    /**
     * Tests for nil "protectedEquipment" element
     */
    boolean isNilProtectedEquipment();
    
    /**
     * True if has "protectedEquipment" element
     */
    boolean isSetProtectedEquipment();
    
    /**
     * Sets the "protectedEquipment" element
     */
    void setProtectedEquipment(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType protectedEquipment);
    
    /**
     * Appends and returns a new empty "protectedEquipment" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProtectedEquipment();
    
    /**
     * Nils the "protectedEquipment" element
     */
    void setNilProtectedEquipment();
    
    /**
     * Unsets the "protectedEquipment" element
     */
    void unsetProtectedEquipment();
    
    /**
     * Gets the "switchToEquipment" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchToEquipment();
    
    /**
     * Tests for nil "switchToEquipment" element
     */
    boolean isNilSwitchToEquipment();
    
    /**
     * True if has "switchToEquipment" element
     */
    boolean isSetSwitchToEquipment();
    
    /**
     * Sets the "switchToEquipment" element
     */
    void setSwitchToEquipment(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchToEquipment);
    
    /**
     * Appends and returns a new empty "switchToEquipment" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchToEquipment();
    
    /**
     * Nils the "switchToEquipment" element
     */
    void setNilSwitchToEquipment();
    
    /**
     * Unsets the "switchToEquipment" element
     */
    void unsetSwitchToEquipment();
    
    /**
     * Gets the "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
    
    /**
     * Tests for nil "vendorExtensions" element
     */
    boolean isNilVendorExtensions();
    
    /**
     * True if has "vendorExtensions" element
     */
    boolean isSetVendorExtensions();
    
    /**
     * Sets the "vendorExtensions" element
     */
    void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
    
    /**
     * Nils the "vendorExtensions" element
     */
    void setNilVendorExtensions();
    
    /**
     * Unsets the "vendorExtensions" element
     */
    void unsetVendorExtensions();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType newInstance() {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
