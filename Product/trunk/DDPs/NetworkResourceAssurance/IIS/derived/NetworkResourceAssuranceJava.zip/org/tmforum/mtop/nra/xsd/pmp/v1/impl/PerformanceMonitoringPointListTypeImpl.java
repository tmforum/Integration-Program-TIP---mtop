/*
 * XML Type:  PerformanceMonitoringPointListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmp.v1.impl;
/**
 * An XML PerformanceMonitoringPointListType(@http://www.tmforum.org/mtop/nra/xsd/pmp/v1).
 *
 * This is a complex type.
 */
public class PerformanceMonitoringPointListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType
{
    
    public PerformanceMonitoringPointListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmp/v1", "pmp");
    
    
    /**
     * Gets a List of "pmp" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType> getPmpList()
    {
        final class PmpList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType>
        {
            public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType get(int i)
                { return PerformanceMonitoringPointListTypeImpl.this.getPmpArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType set(int i, org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType o)
            {
                org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType old = PerformanceMonitoringPointListTypeImpl.this.getPmpArray(i);
                PerformanceMonitoringPointListTypeImpl.this.setPmpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType o)
                { PerformanceMonitoringPointListTypeImpl.this.insertNewPmp(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType old = PerformanceMonitoringPointListTypeImpl.this.getPmpArray(i);
                PerformanceMonitoringPointListTypeImpl.this.removePmp(i);
                return old;
            }
            
            public int size()
                { return PerformanceMonitoringPointListTypeImpl.this.sizeOfPmpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmpList();
        }
    }
    
    /**
     * Gets array of all "pmp" elements
     */
    public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType[] getPmpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMP$0, targetList);
            org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType[] result = new org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pmp" element
     */
    public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType getPmpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType)get_store().find_element_user(PMP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pmp" element
     */
    public int sizeOfPmpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMP$0);
        }
    }
    
    /**
     * Sets array of all "pmp" element
     */
    public void setPmpArray(org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType[] pmpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmpArray, PMP$0);
        }
    }
    
    /**
     * Sets ith "pmp" element
     */
    public void setPmpArray(int i, org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType pmp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType)get_store().find_element_user(PMP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmp" element
     */
    public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType insertNewPmp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType)get_store().insert_element_user(PMP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmp" element
     */
    public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType addNewPmp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointType)get_store().add_element_user(PMP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmp" element
     */
    public void removePmp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMP$0, i);
        }
    }
}
