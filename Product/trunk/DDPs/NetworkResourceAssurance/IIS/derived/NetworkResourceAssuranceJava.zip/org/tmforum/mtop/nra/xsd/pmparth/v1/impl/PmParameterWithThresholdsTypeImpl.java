/*
 * XML Type:  PmParameterWithThresholdsType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmparth/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmparth.v1.impl;
/**
 * An XML PmParameterWithThresholdsType(@http://www.tmforum.org/mtop/nra/xsd/pmparth/v1).
 *
 * This is a complex type.
 */
public class PmParameterWithThresholdsTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType
{
    
    public PmParameterWithThresholdsTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETERNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmparth/v1", "pmParameterName");
    private static final javax.xml.namespace.QName PMTHRESHOLDLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmparth/v1", "pmThresholdList");
    
    
    /**
     * Gets the "pmParameterName" element
     */
    public java.lang.String getPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "pmParameterName" element
     */
    public boolean isNilPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmParameterName" element
     */
    public boolean isSetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETERNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "pmParameterName" element
     */
    public void setPmParameterName(java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    public void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.set(pmParameterName);
        }
    }
    
    /**
     * Nils the "pmParameterName" element
     */
    public void setNilPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmParameterName" element
     */
    public void unsetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETERNAME$0, 0);
        }
    }
    
    /**
     * Gets the "pmThresholdList" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType getPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().find_element_user(PMTHRESHOLDLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "pmThresholdList" element
     */
    public boolean isNilPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().find_element_user(PMTHRESHOLDLIST$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmThresholdList" element
     */
    public boolean isSetPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMTHRESHOLDLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "pmThresholdList" element
     */
    public void setPmThresholdList(org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType pmThresholdList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().find_element_user(PMTHRESHOLDLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().add_element_user(PMTHRESHOLDLIST$2);
            }
            target.set(pmThresholdList);
        }
    }
    
    /**
     * Appends and returns a new empty "pmThresholdList" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType addNewPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().add_element_user(PMTHRESHOLDLIST$2);
            return target;
        }
    }
    
    /**
     * Nils the "pmThresholdList" element
     */
    public void setNilPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().find_element_user(PMTHRESHOLDLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType)get_store().add_element_user(PMTHRESHOLDLIST$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmThresholdList" element
     */
    public void unsetPmThresholdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMTHRESHOLDLIST$2, 0);
        }
    }
}
