/*
 * XML Type:  ProbableCauseEnumType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/prc/v1
 * Java type: org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.prc.v1;


/**
 * An XML ProbableCauseEnumType(@http://www.tmforum.org/mtop/nra/xsd/prc/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType.
 */
public interface ProbableCauseEnumType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProbableCauseEnumType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3302A0BB3167604C489D394E7972B422").resolveHandle("probablecauseenumtype1742type");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum VENDOR_EXT = Enum.forString("VENDOR_EXT");
    static final Enum MINOR_EXT = Enum.forString("MINOR_EXT");
    static final Enum UNIDENTIFIED = Enum.forString("UNIDENTIFIED");
    static final Enum AIS = Enum.forString("AIS");
    static final Enum AMS = Enum.forString("AMS");
    static final Enum ATPC_FAIL = Enum.forString("ATPC_FAIL");
    static final Enum AU_AIS = Enum.forString("AU-AIS");
    static final Enum BER_SD = Enum.forString("BER_SD");
    static final Enum BER_SF = Enum.forString("BER_SF");
    static final Enum BLOCKED_FE = Enum.forString("BLOCKED_FE");
    static final Enum CFG_ABORT = Enum.forString("CFG_ABORT");
    static final Enum CFG_ABORT_FE = Enum.forString("CFG_ABORT_FE");
    static final Enum DCC_FAILURE = Enum.forString("DCC_FAILURE");
    static final Enum DEMODULATION_FAIL = Enum.forString("DEMODULATION_FAIL");
    static final Enum EMS = Enum.forString("EMS");
    static final Enum EMS_ALM_LOSS = Enum.forString("EMS_ALM_LOSS");
    static final Enum EMS_LIFECYCLE_LOSS = Enum.forString("EMS_LIFECYCLE_LOSS");
    static final Enum EMS_ALM_AND_LIFECYCLE_LOSS = Enum.forString("EMS_ALM_AND_LIFECYCLE_LOSS");
    static final Enum EQPT = Enum.forString("EQPT");
    static final Enum ENV = Enum.forString("ENV");
    static final Enum FF = Enum.forString("FF");
    static final Enum FOP_APS = Enum.forString("FOP_APS");
    static final Enum INSUFF_LINKS = Enum.forString("INSUFF_LINKS");
    static final Enum INSUFF_LINKS_FE = Enum.forString("INSUFF_LINKS_FE");
    static final Enum LCD = Enum.forString("LCD");
    static final Enum LIF = Enum.forString("LIF");
    static final Enum LOA = Enum.forString("LOA");
    static final Enum LOC = Enum.forString("LOC");
    static final Enum LODS = Enum.forString("LODS");
    static final Enum LOF = Enum.forString("LOF");
    static final Enum LOM = Enum.forString("LOM");
    static final Enum LOP = Enum.forString("LOP");
    static final Enum LOPC = Enum.forString("LOPC");
    static final Enum LOS = Enum.forString("LOS");
    static final Enum LOTC = Enum.forString("LOTC");
    static final Enum MODULATION_FAIL = Enum.forString("MODULATION_FAIL");
    static final Enum MS_AIS = Enum.forString("MS-AIS");
    static final Enum OS = Enum.forString("OS");
    static final Enum OS_ALM_LOSS = Enum.forString("OS_ALM_LOSS");
    static final Enum OS_LIFECYCLE_LOSS = Enum.forString("OS_LIFECYCLE_LOSS");
    static final Enum OS_ALM_AND_LIFECYCLE_LOSS = Enum.forString("OS_ALM_AND_LIFECYCLE_LOSS");
    static final Enum OSC_AIS = Enum.forString("OSC-AIS");
    static final Enum OSC_BER_SF = Enum.forString("OSC_BER_SF");
    static final Enum OSC_FERF = Enum.forString("OSC_FERF");
    static final Enum OSC_LOF = Enum.forString("OSC_LOF");
    static final Enum OSC_LOS = Enum.forString("OSC_LOS");
    static final Enum OSC_SD = Enum.forString("OSC_SD");
    static final Enum PLM = Enum.forString("PLM");
    static final Enum RAI = Enum.forString("RAI");
    static final Enum RX_FAIL = Enum.forString("RX_FAIL");
    static final Enum RX_MIS_CONNECT = Enum.forString("RX_MIS_CONNECT");
    static final Enum RX_UNUSABLE_FE = Enum.forString("RX_UNUSABLE_FE");
    static final Enum SECURITY_VIOLATION = Enum.forString("SECURITY_VIOLATION");
    static final Enum SQL = Enum.forString("SQL");
    static final Enum SSF = Enum.forString("SSF");
    static final Enum STARTUP_FE = Enum.forString("STARTUP_FE");
    static final Enum TCF = Enum.forString("TCF");
    static final Enum TCFE = Enum.forString("TCFE");
    static final Enum TCFI = Enum.forString("TCFI");
    static final Enum TIM = Enum.forString("TIM");
    static final Enum TIMING_SYNCH = Enum.forString("TIMING_SYNCH");
    static final Enum TSD = Enum.forString("TSD");
    static final Enum TSF = Enum.forString("TSF");
    static final Enum TU_AIS = Enum.forString("TU-AIS");
    static final Enum TX_DEGRADE = Enum.forString("TX_DEGRADE");
    static final Enum TX_FAIL = Enum.forString("TX_FAIL");
    static final Enum TX_MIS_CONNECT = Enum.forString("TX_MIS_CONNECT");
    static final Enum TX_UNUSABLE_FE = Enum.forString("TX_UNUSABLE_FE");
    static final Enum UAT = Enum.forString("UAT");
    static final Enum UNEQ = Enum.forString("UNEQ");
    static final Enum VC_AIS = Enum.forString("VC-AIS");
    static final Enum VC_RDI = Enum.forString("VC-RDI");
    static final Enum VP_AIS = Enum.forString("VP-AIS");
    static final Enum VP_RDI = Enum.forString("VP-RDI");
    static final Enum XPIC_FAIL = Enum.forString("XPIC_FAIL");
    
    static final int INT_VENDOR_EXT = Enum.INT_VENDOR_EXT;
    static final int INT_MINOR_EXT = Enum.INT_MINOR_EXT;
    static final int INT_UNIDENTIFIED = Enum.INT_UNIDENTIFIED;
    static final int INT_AIS = Enum.INT_AIS;
    static final int INT_AMS = Enum.INT_AMS;
    static final int INT_ATPC_FAIL = Enum.INT_ATPC_FAIL;
    static final int INT_AU_AIS = Enum.INT_AU_AIS;
    static final int INT_BER_SD = Enum.INT_BER_SD;
    static final int INT_BER_SF = Enum.INT_BER_SF;
    static final int INT_BLOCKED_FE = Enum.INT_BLOCKED_FE;
    static final int INT_CFG_ABORT = Enum.INT_CFG_ABORT;
    static final int INT_CFG_ABORT_FE = Enum.INT_CFG_ABORT_FE;
    static final int INT_DCC_FAILURE = Enum.INT_DCC_FAILURE;
    static final int INT_DEMODULATION_FAIL = Enum.INT_DEMODULATION_FAIL;
    static final int INT_EMS = Enum.INT_EMS;
    static final int INT_EMS_ALM_LOSS = Enum.INT_EMS_ALM_LOSS;
    static final int INT_EMS_LIFECYCLE_LOSS = Enum.INT_EMS_LIFECYCLE_LOSS;
    static final int INT_EMS_ALM_AND_LIFECYCLE_LOSS = Enum.INT_EMS_ALM_AND_LIFECYCLE_LOSS;
    static final int INT_EQPT = Enum.INT_EQPT;
    static final int INT_ENV = Enum.INT_ENV;
    static final int INT_FF = Enum.INT_FF;
    static final int INT_FOP_APS = Enum.INT_FOP_APS;
    static final int INT_INSUFF_LINKS = Enum.INT_INSUFF_LINKS;
    static final int INT_INSUFF_LINKS_FE = Enum.INT_INSUFF_LINKS_FE;
    static final int INT_LCD = Enum.INT_LCD;
    static final int INT_LIF = Enum.INT_LIF;
    static final int INT_LOA = Enum.INT_LOA;
    static final int INT_LOC = Enum.INT_LOC;
    static final int INT_LODS = Enum.INT_LODS;
    static final int INT_LOF = Enum.INT_LOF;
    static final int INT_LOM = Enum.INT_LOM;
    static final int INT_LOP = Enum.INT_LOP;
    static final int INT_LOPC = Enum.INT_LOPC;
    static final int INT_LOS = Enum.INT_LOS;
    static final int INT_LOTC = Enum.INT_LOTC;
    static final int INT_MODULATION_FAIL = Enum.INT_MODULATION_FAIL;
    static final int INT_MS_AIS = Enum.INT_MS_AIS;
    static final int INT_OS = Enum.INT_OS;
    static final int INT_OS_ALM_LOSS = Enum.INT_OS_ALM_LOSS;
    static final int INT_OS_LIFECYCLE_LOSS = Enum.INT_OS_LIFECYCLE_LOSS;
    static final int INT_OS_ALM_AND_LIFECYCLE_LOSS = Enum.INT_OS_ALM_AND_LIFECYCLE_LOSS;
    static final int INT_OSC_AIS = Enum.INT_OSC_AIS;
    static final int INT_OSC_BER_SF = Enum.INT_OSC_BER_SF;
    static final int INT_OSC_FERF = Enum.INT_OSC_FERF;
    static final int INT_OSC_LOF = Enum.INT_OSC_LOF;
    static final int INT_OSC_LOS = Enum.INT_OSC_LOS;
    static final int INT_OSC_SD = Enum.INT_OSC_SD;
    static final int INT_PLM = Enum.INT_PLM;
    static final int INT_RAI = Enum.INT_RAI;
    static final int INT_RX_FAIL = Enum.INT_RX_FAIL;
    static final int INT_RX_MIS_CONNECT = Enum.INT_RX_MIS_CONNECT;
    static final int INT_RX_UNUSABLE_FE = Enum.INT_RX_UNUSABLE_FE;
    static final int INT_SECURITY_VIOLATION = Enum.INT_SECURITY_VIOLATION;
    static final int INT_SQL = Enum.INT_SQL;
    static final int INT_SSF = Enum.INT_SSF;
    static final int INT_STARTUP_FE = Enum.INT_STARTUP_FE;
    static final int INT_TCF = Enum.INT_TCF;
    static final int INT_TCFE = Enum.INT_TCFE;
    static final int INT_TCFI = Enum.INT_TCFI;
    static final int INT_TIM = Enum.INT_TIM;
    static final int INT_TIMING_SYNCH = Enum.INT_TIMING_SYNCH;
    static final int INT_TSD = Enum.INT_TSD;
    static final int INT_TSF = Enum.INT_TSF;
    static final int INT_TU_AIS = Enum.INT_TU_AIS;
    static final int INT_TX_DEGRADE = Enum.INT_TX_DEGRADE;
    static final int INT_TX_FAIL = Enum.INT_TX_FAIL;
    static final int INT_TX_MIS_CONNECT = Enum.INT_TX_MIS_CONNECT;
    static final int INT_TX_UNUSABLE_FE = Enum.INT_TX_UNUSABLE_FE;
    static final int INT_UAT = Enum.INT_UAT;
    static final int INT_UNEQ = Enum.INT_UNEQ;
    static final int INT_VC_AIS = Enum.INT_VC_AIS;
    static final int INT_VC_RDI = Enum.INT_VC_RDI;
    static final int INT_VP_AIS = Enum.INT_VP_AIS;
    static final int INT_VP_RDI = Enum.INT_VP_RDI;
    static final int INT_XPIC_FAIL = Enum.INT_XPIC_FAIL;
    
    /**
     * Enumeration value class for org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_VENDOR_EXT
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_VENDOR_EXT = 1;
        static final int INT_MINOR_EXT = 2;
        static final int INT_UNIDENTIFIED = 3;
        static final int INT_AIS = 4;
        static final int INT_AMS = 5;
        static final int INT_ATPC_FAIL = 6;
        static final int INT_AU_AIS = 7;
        static final int INT_BER_SD = 8;
        static final int INT_BER_SF = 9;
        static final int INT_BLOCKED_FE = 10;
        static final int INT_CFG_ABORT = 11;
        static final int INT_CFG_ABORT_FE = 12;
        static final int INT_DCC_FAILURE = 13;
        static final int INT_DEMODULATION_FAIL = 14;
        static final int INT_EMS = 15;
        static final int INT_EMS_ALM_LOSS = 16;
        static final int INT_EMS_LIFECYCLE_LOSS = 17;
        static final int INT_EMS_ALM_AND_LIFECYCLE_LOSS = 18;
        static final int INT_EQPT = 19;
        static final int INT_ENV = 20;
        static final int INT_FF = 21;
        static final int INT_FOP_APS = 22;
        static final int INT_INSUFF_LINKS = 23;
        static final int INT_INSUFF_LINKS_FE = 24;
        static final int INT_LCD = 25;
        static final int INT_LIF = 26;
        static final int INT_LOA = 27;
        static final int INT_LOC = 28;
        static final int INT_LODS = 29;
        static final int INT_LOF = 30;
        static final int INT_LOM = 31;
        static final int INT_LOP = 32;
        static final int INT_LOPC = 33;
        static final int INT_LOS = 34;
        static final int INT_LOTC = 35;
        static final int INT_MODULATION_FAIL = 36;
        static final int INT_MS_AIS = 37;
        static final int INT_OS = 38;
        static final int INT_OS_ALM_LOSS = 39;
        static final int INT_OS_LIFECYCLE_LOSS = 40;
        static final int INT_OS_ALM_AND_LIFECYCLE_LOSS = 41;
        static final int INT_OSC_AIS = 42;
        static final int INT_OSC_BER_SF = 43;
        static final int INT_OSC_FERF = 44;
        static final int INT_OSC_LOF = 45;
        static final int INT_OSC_LOS = 46;
        static final int INT_OSC_SD = 47;
        static final int INT_PLM = 48;
        static final int INT_RAI = 49;
        static final int INT_RX_FAIL = 50;
        static final int INT_RX_MIS_CONNECT = 51;
        static final int INT_RX_UNUSABLE_FE = 52;
        static final int INT_SECURITY_VIOLATION = 53;
        static final int INT_SQL = 54;
        static final int INT_SSF = 55;
        static final int INT_STARTUP_FE = 56;
        static final int INT_TCF = 57;
        static final int INT_TCFE = 58;
        static final int INT_TCFI = 59;
        static final int INT_TIM = 60;
        static final int INT_TIMING_SYNCH = 61;
        static final int INT_TSD = 62;
        static final int INT_TSF = 63;
        static final int INT_TU_AIS = 64;
        static final int INT_TX_DEGRADE = 65;
        static final int INT_TX_FAIL = 66;
        static final int INT_TX_MIS_CONNECT = 67;
        static final int INT_TX_UNUSABLE_FE = 68;
        static final int INT_UAT = 69;
        static final int INT_UNEQ = 70;
        static final int INT_VC_AIS = 71;
        static final int INT_VC_RDI = 72;
        static final int INT_VP_AIS = 73;
        static final int INT_VP_RDI = 74;
        static final int INT_XPIC_FAIL = 75;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("VENDOR_EXT", INT_VENDOR_EXT),
                new Enum("MINOR_EXT", INT_MINOR_EXT),
                new Enum("UNIDENTIFIED", INT_UNIDENTIFIED),
                new Enum("AIS", INT_AIS),
                new Enum("AMS", INT_AMS),
                new Enum("ATPC_FAIL", INT_ATPC_FAIL),
                new Enum("AU-AIS", INT_AU_AIS),
                new Enum("BER_SD", INT_BER_SD),
                new Enum("BER_SF", INT_BER_SF),
                new Enum("BLOCKED_FE", INT_BLOCKED_FE),
                new Enum("CFG_ABORT", INT_CFG_ABORT),
                new Enum("CFG_ABORT_FE", INT_CFG_ABORT_FE),
                new Enum("DCC_FAILURE", INT_DCC_FAILURE),
                new Enum("DEMODULATION_FAIL", INT_DEMODULATION_FAIL),
                new Enum("EMS", INT_EMS),
                new Enum("EMS_ALM_LOSS", INT_EMS_ALM_LOSS),
                new Enum("EMS_LIFECYCLE_LOSS", INT_EMS_LIFECYCLE_LOSS),
                new Enum("EMS_ALM_AND_LIFECYCLE_LOSS", INT_EMS_ALM_AND_LIFECYCLE_LOSS),
                new Enum("EQPT", INT_EQPT),
                new Enum("ENV", INT_ENV),
                new Enum("FF", INT_FF),
                new Enum("FOP_APS", INT_FOP_APS),
                new Enum("INSUFF_LINKS", INT_INSUFF_LINKS),
                new Enum("INSUFF_LINKS_FE", INT_INSUFF_LINKS_FE),
                new Enum("LCD", INT_LCD),
                new Enum("LIF", INT_LIF),
                new Enum("LOA", INT_LOA),
                new Enum("LOC", INT_LOC),
                new Enum("LODS", INT_LODS),
                new Enum("LOF", INT_LOF),
                new Enum("LOM", INT_LOM),
                new Enum("LOP", INT_LOP),
                new Enum("LOPC", INT_LOPC),
                new Enum("LOS", INT_LOS),
                new Enum("LOTC", INT_LOTC),
                new Enum("MODULATION_FAIL", INT_MODULATION_FAIL),
                new Enum("MS-AIS", INT_MS_AIS),
                new Enum("OS", INT_OS),
                new Enum("OS_ALM_LOSS", INT_OS_ALM_LOSS),
                new Enum("OS_LIFECYCLE_LOSS", INT_OS_LIFECYCLE_LOSS),
                new Enum("OS_ALM_AND_LIFECYCLE_LOSS", INT_OS_ALM_AND_LIFECYCLE_LOSS),
                new Enum("OSC-AIS", INT_OSC_AIS),
                new Enum("OSC_BER_SF", INT_OSC_BER_SF),
                new Enum("OSC_FERF", INT_OSC_FERF),
                new Enum("OSC_LOF", INT_OSC_LOF),
                new Enum("OSC_LOS", INT_OSC_LOS),
                new Enum("OSC_SD", INT_OSC_SD),
                new Enum("PLM", INT_PLM),
                new Enum("RAI", INT_RAI),
                new Enum("RX_FAIL", INT_RX_FAIL),
                new Enum("RX_MIS_CONNECT", INT_RX_MIS_CONNECT),
                new Enum("RX_UNUSABLE_FE", INT_RX_UNUSABLE_FE),
                new Enum("SECURITY_VIOLATION", INT_SECURITY_VIOLATION),
                new Enum("SQL", INT_SQL),
                new Enum("SSF", INT_SSF),
                new Enum("STARTUP_FE", INT_STARTUP_FE),
                new Enum("TCF", INT_TCF),
                new Enum("TCFE", INT_TCFE),
                new Enum("TCFI", INT_TCFI),
                new Enum("TIM", INT_TIM),
                new Enum("TIMING_SYNCH", INT_TIMING_SYNCH),
                new Enum("TSD", INT_TSD),
                new Enum("TSF", INT_TSF),
                new Enum("TU-AIS", INT_TU_AIS),
                new Enum("TX_DEGRADE", INT_TX_DEGRADE),
                new Enum("TX_FAIL", INT_TX_FAIL),
                new Enum("TX_MIS_CONNECT", INT_TX_MIS_CONNECT),
                new Enum("TX_UNUSABLE_FE", INT_TX_UNUSABLE_FE),
                new Enum("UAT", INT_UAT),
                new Enum("UNEQ", INT_UNEQ),
                new Enum("VC-AIS", INT_VC_AIS),
                new Enum("VC-RDI", INT_VC_RDI),
                new Enum("VP-AIS", INT_VP_AIS),
                new Enum("VP-RDI", INT_VP_RDI),
                new Enum("XPIC_FAIL", INT_XPIC_FAIL),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType newValue(java.lang.Object obj) {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) type.newValue( obj ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType newInstance() {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
