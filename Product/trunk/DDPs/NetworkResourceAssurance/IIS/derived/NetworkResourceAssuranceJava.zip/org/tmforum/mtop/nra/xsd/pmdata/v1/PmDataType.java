/*
 * XML Type:  PmDataType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmdata/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmdata.v1;


/**
 * An XML PmDataType(@http://www.tmforum.org/mtop/nra/xsd/pmdata/v1).
 *
 * This is a complex type.
 */
public interface PmDataType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PmDataType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("pmdatatypedc88type");
    
    /**
     * Gets the "tpName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getTpName();
    
    /**
     * Tests for nil "tpName" element
     */
    boolean isNilTpName();
    
    /**
     * True if has "tpName" element
     */
    boolean isSetTpName();
    
    /**
     * Sets the "tpName" element
     */
    void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType tpName);
    
    /**
     * Appends and returns a new empty "tpName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewTpName();
    
    /**
     * Nils the "tpName" element
     */
    void setNilTpName();
    
    /**
     * Unsets the "tpName" element
     */
    void unsetTpName();
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * Tests for nil "layerRate" element
     */
    boolean isNilLayerRate();
    
    /**
     * True if has "layerRate" element
     */
    boolean isSetLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Nils the "layerRate" element
     */
    void setNilLayerRate();
    
    /**
     * Unsets the "layerRate" element
     */
    void unsetLayerRate();
    
    /**
     * Gets the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity();
    
    /**
     * Gets (as xml) the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity();
    
    /**
     * Tests for nil "granularity" element
     */
    boolean isNilGranularity();
    
    /**
     * True if has "granularity" element
     */
    boolean isSetGranularity();
    
    /**
     * Sets the "granularity" element
     */
    void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity);
    
    /**
     * Sets (as xml) the "granularity" element
     */
    void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity);
    
    /**
     * Nils the "granularity" element
     */
    void setNilGranularity();
    
    /**
     * Unsets the "granularity" element
     */
    void unsetGranularity();
    
    /**
     * Gets the "retrievalTime" element
     */
    java.util.Calendar getRetrievalTime();
    
    /**
     * Gets (as xml) the "retrievalTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetRetrievalTime();
    
    /**
     * True if has "retrievalTime" element
     */
    boolean isSetRetrievalTime();
    
    /**
     * Sets the "retrievalTime" element
     */
    void setRetrievalTime(java.util.Calendar retrievalTime);
    
    /**
     * Sets (as xml) the "retrievalTime" element
     */
    void xsetRetrievalTime(org.apache.xmlbeans.XmlDateTime retrievalTime);
    
    /**
     * Unsets the "retrievalTime" element
     */
    void unsetRetrievalTime();
    
    /**
     * Gets the "pmMeasurementList" element
     */
    org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType getPmMeasurementList();
    
    /**
     * Tests for nil "pmMeasurementList" element
     */
    boolean isNilPmMeasurementList();
    
    /**
     * True if has "pmMeasurementList" element
     */
    boolean isSetPmMeasurementList();
    
    /**
     * Sets the "pmMeasurementList" element
     */
    void setPmMeasurementList(org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType pmMeasurementList);
    
    /**
     * Appends and returns a new empty "pmMeasurementList" element
     */
    org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType addNewPmMeasurementList();
    
    /**
     * Nils the "pmMeasurementList" element
     */
    void setNilPmMeasurementList();
    
    /**
     * Unsets the "pmMeasurementList" element
     */
    void unsetPmMeasurementList();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType newInstance() {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
