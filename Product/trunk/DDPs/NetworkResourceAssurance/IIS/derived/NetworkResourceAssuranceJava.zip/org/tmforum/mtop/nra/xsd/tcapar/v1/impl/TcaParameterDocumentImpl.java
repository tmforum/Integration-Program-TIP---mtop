/*
 * An XML document type.
 * Localname: tcaParameter
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcapar/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcapar.v1.impl;
/**
 * A document containing one tcaParameter(@http://www.tmforum.org/mtop/nra/xsd/tcapar/v1) element.
 *
 * This is a complex type.
 */
public class TcaParameterDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterDocument
{
    
    public TcaParameterDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TCAPARAMETER$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapar/v1", "tcaParameter");
    
    
    /**
     * Gets the "tcaParameter" element
     */
    public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType getTcaParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType)get_store().find_element_user(TCAPARAMETER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tcaParameter" element
     */
    public void setTcaParameter(org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType tcaParameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType)get_store().find_element_user(TCAPARAMETER$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType)get_store().add_element_user(TCAPARAMETER$0);
            }
            target.set(tcaParameter);
        }
    }
    
    /**
     * Appends and returns a new empty "tcaParameter" element
     */
    public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType addNewTcaParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType)get_store().add_element_user(TCAPARAMETER$0);
            return target;
        }
    }
}
