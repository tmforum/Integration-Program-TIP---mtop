/*
 * XML Type:  EquipmentProtectionSwitchListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/eps/v1
 * Java type: org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.eps.v1.impl;
/**
 * An XML EquipmentProtectionSwitchListType(@http://www.tmforum.org/mtop/nra/xsd/eps/v1).
 *
 * This is a complex type.
 */
public class EquipmentProtectionSwitchListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchListType
{
    
    public EquipmentProtectionSwitchListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EQUIPMENTPROTECTIONSWITCH$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/eps/v1", "equipmentProtectionSwitch");
    
    
    /**
     * Gets a List of "equipmentProtectionSwitch" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType> getEquipmentProtectionSwitchList()
    {
        final class EquipmentProtectionSwitchList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType>
        {
            public org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType get(int i)
                { return EquipmentProtectionSwitchListTypeImpl.this.getEquipmentProtectionSwitchArray(i); }
            
            public org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType set(int i, org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType o)
            {
                org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType old = EquipmentProtectionSwitchListTypeImpl.this.getEquipmentProtectionSwitchArray(i);
                EquipmentProtectionSwitchListTypeImpl.this.setEquipmentProtectionSwitchArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType o)
                { EquipmentProtectionSwitchListTypeImpl.this.insertNewEquipmentProtectionSwitch(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType old = EquipmentProtectionSwitchListTypeImpl.this.getEquipmentProtectionSwitchArray(i);
                EquipmentProtectionSwitchListTypeImpl.this.removeEquipmentProtectionSwitch(i);
                return old;
            }
            
            public int size()
                { return EquipmentProtectionSwitchListTypeImpl.this.sizeOfEquipmentProtectionSwitchArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new EquipmentProtectionSwitchList();
        }
    }
    
    /**
     * Gets array of all "equipmentProtectionSwitch" elements
     */
    public org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType[] getEquipmentProtectionSwitchArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EQUIPMENTPROTECTIONSWITCH$0, targetList);
            org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType[] result = new org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "equipmentProtectionSwitch" element
     */
    public org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType getEquipmentProtectionSwitchArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType)get_store().find_element_user(EQUIPMENTPROTECTIONSWITCH$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "equipmentProtectionSwitch" element
     */
    public int sizeOfEquipmentProtectionSwitchArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQUIPMENTPROTECTIONSWITCH$0);
        }
    }
    
    /**
     * Sets array of all "equipmentProtectionSwitch" element
     */
    public void setEquipmentProtectionSwitchArray(org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType[] equipmentProtectionSwitchArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(equipmentProtectionSwitchArray, EQUIPMENTPROTECTIONSWITCH$0);
        }
    }
    
    /**
     * Sets ith "equipmentProtectionSwitch" element
     */
    public void setEquipmentProtectionSwitchArray(int i, org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType equipmentProtectionSwitch)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType)get_store().find_element_user(EQUIPMENTPROTECTIONSWITCH$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(equipmentProtectionSwitch);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "equipmentProtectionSwitch" element
     */
    public org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType insertNewEquipmentProtectionSwitch(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType)get_store().insert_element_user(EQUIPMENTPROTECTIONSWITCH$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "equipmentProtectionSwitch" element
     */
    public org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType addNewEquipmentProtectionSwitch()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType)get_store().add_element_user(EQUIPMENTPROTECTIONSWITCH$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "equipmentProtectionSwitch" element
     */
    public void removeEquipmentProtectionSwitch(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQUIPMENTPROTECTIONSWITCH$0, i);
        }
    }
}
