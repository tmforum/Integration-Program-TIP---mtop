/*
 * XML Type:  SpecificProblemListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1.impl;
/**
 * An XML SpecificProblemListType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is a complex type.
 */
public class SpecificProblemListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType
{
    
    public SpecificProblemListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SPECIFICPROBLEM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/com/v1", "specificProblem");
    
    
    /**
     * Gets a List of "specificProblem" elements
     */
    public java.util.List<java.lang.String> getSpecificProblemList()
    {
        final class SpecificProblemList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return SpecificProblemListTypeImpl.this.getSpecificProblemArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = SpecificProblemListTypeImpl.this.getSpecificProblemArray(i);
                SpecificProblemListTypeImpl.this.setSpecificProblemArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { SpecificProblemListTypeImpl.this.insertSpecificProblem(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = SpecificProblemListTypeImpl.this.getSpecificProblemArray(i);
                SpecificProblemListTypeImpl.this.removeSpecificProblem(i);
                return old;
            }
            
            public int size()
                { return SpecificProblemListTypeImpl.this.sizeOfSpecificProblemArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new SpecificProblemList();
        }
    }
    
    /**
     * Gets array of all "specificProblem" elements
     */
    public java.lang.String[] getSpecificProblemArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SPECIFICPROBLEM$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "specificProblem" element
     */
    public java.lang.String getSpecificProblemArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SPECIFICPROBLEM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "specificProblem" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType> xgetSpecificProblemList()
    {
        final class SpecificProblemList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType>
        {
            public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType get(int i)
                { return SpecificProblemListTypeImpl.this.xgetSpecificProblemArray(i); }
            
            public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType set(int i, org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType o)
            {
                org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType old = SpecificProblemListTypeImpl.this.xgetSpecificProblemArray(i);
                SpecificProblemListTypeImpl.this.xsetSpecificProblemArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType o)
                { SpecificProblemListTypeImpl.this.insertNewSpecificProblem(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType old = SpecificProblemListTypeImpl.this.xgetSpecificProblemArray(i);
                SpecificProblemListTypeImpl.this.removeSpecificProblem(i);
                return old;
            }
            
            public int size()
                { return SpecificProblemListTypeImpl.this.sizeOfSpecificProblemArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new SpecificProblemList();
        }
    }
    
    /**
     * Gets (as xml) array of all "specificProblem" elements
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType[] xgetSpecificProblemArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SPECIFICPROBLEM$0, targetList);
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType[] result = new org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "specificProblem" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType xgetSpecificProblemArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType)get_store().find_element_user(SPECIFICPROBLEM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType)target;
        }
    }
    
    /**
     * Returns number of "specificProblem" element
     */
    public int sizeOfSpecificProblemArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SPECIFICPROBLEM$0);
        }
    }
    
    /**
     * Sets array of all "specificProblem" element
     */
    public void setSpecificProblemArray(java.lang.String[] specificProblemArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(specificProblemArray, SPECIFICPROBLEM$0);
        }
    }
    
    /**
     * Sets ith "specificProblem" element
     */
    public void setSpecificProblemArray(int i, java.lang.String specificProblem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SPECIFICPROBLEM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(specificProblem);
        }
    }
    
    /**
     * Sets (as xml) array of all "specificProblem" element
     */
    public void xsetSpecificProblemArray(org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType[]specificProblemArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(specificProblemArray, SPECIFICPROBLEM$0);
        }
    }
    
    /**
     * Sets (as xml) ith "specificProblem" element
     */
    public void xsetSpecificProblemArray(int i, org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType specificProblem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType)get_store().find_element_user(SPECIFICPROBLEM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(specificProblem);
        }
    }
    
    /**
     * Inserts the value as the ith "specificProblem" element
     */
    public void insertSpecificProblem(int i, java.lang.String specificProblem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(SPECIFICPROBLEM$0, i);
            target.setStringValue(specificProblem);
        }
    }
    
    /**
     * Appends the value as the last "specificProblem" element
     */
    public void addSpecificProblem(java.lang.String specificProblem)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SPECIFICPROBLEM$0);
            target.setStringValue(specificProblem);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "specificProblem" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType insertNewSpecificProblem(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType)get_store().insert_element_user(SPECIFICPROBLEM$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "specificProblem" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType addNewSpecificProblem()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType)get_store().add_element_user(SPECIFICPROBLEM$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "specificProblem" element
     */
    public void removeSpecificProblem(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SPECIFICPROBLEM$0, i);
        }
    }
}
