/*
 * XML Type:  ProtectionGroupParameterListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pgp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pgp.v1;


/**
 * An XML ProtectionGroupParameterListType(@http://www.tmforum.org/mtop/nra/xsd/pgp/v1).
 *
 * This is a complex type.
 */
public interface ProtectionGroupParameterListType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProtectionGroupParameterListType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("protectiongroupparameterlisttype5552type");
    
    /**
     * Gets the "switchMode" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType getSwitchMode();
    
    /**
     * True if has "switchMode" element
     */
    boolean isSetSwitchMode();
    
    /**
     * Sets the "switchMode" element
     */
    void setSwitchMode(org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType switchMode);
    
    /**
     * Appends and returns a new empty "switchMode" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType addNewSwitchMode();
    
    /**
     * Unsets the "switchMode" element
     */
    void unsetSwitchMode();
    
    /**
     * Gets the "springProtocol" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType getSpringProtocol();
    
    /**
     * True if has "springProtocol" element
     */
    boolean isSetSpringProtocol();
    
    /**
     * Sets the "springProtocol" element
     */
    void setSpringProtocol(org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType springProtocol);
    
    /**
     * Appends and returns a new empty "springProtocol" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType addNewSpringProtocol();
    
    /**
     * Unsets the "springProtocol" element
     */
    void unsetSpringProtocol();
    
    /**
     * Gets the "springNodeId" element
     */
    java.lang.String getSpringNodeId();
    
    /**
     * Gets (as xml) the "springNodeId" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType xgetSpringNodeId();
    
    /**
     * True if has "springNodeId" element
     */
    boolean isSetSpringNodeId();
    
    /**
     * Sets the "springNodeId" element
     */
    void setSpringNodeId(java.lang.String springNodeId);
    
    /**
     * Sets (as xml) the "springNodeId" element
     */
    void xsetSpringNodeId(org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType springNodeId);
    
    /**
     * Unsets the "springNodeId" element
     */
    void unsetSpringNodeId();
    
    /**
     * Gets the "switchPosition" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType.Enum getSwitchPosition();
    
    /**
     * Gets (as xml) the "switchPosition" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType xgetSwitchPosition();
    
    /**
     * True if has "switchPosition" element
     */
    boolean isSetSwitchPosition();
    
    /**
     * Sets the "switchPosition" element
     */
    void setSwitchPosition(org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType.Enum switchPosition);
    
    /**
     * Sets (as xml) the "switchPosition" element
     */
    void xsetSwitchPosition(org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType switchPosition);
    
    /**
     * Unsets the "switchPosition" element
     */
    void unsetSwitchPosition();
    
    /**
     * Gets the "nonPreEmptibleTraffic" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType.Enum getNonPreEmptibleTraffic();
    
    /**
     * Gets (as xml) the "nonPreEmptibleTraffic" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType xgetNonPreEmptibleTraffic();
    
    /**
     * True if has "nonPreEmptibleTraffic" element
     */
    boolean isSetNonPreEmptibleTraffic();
    
    /**
     * Sets the "nonPreEmptibleTraffic" element
     */
    void setNonPreEmptibleTraffic(org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType.Enum nonPreEmptibleTraffic);
    
    /**
     * Sets (as xml) the "nonPreEmptibleTraffic" element
     */
    void xsetNonPreEmptibleTraffic(org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType nonPreEmptibleTraffic);
    
    /**
     * Unsets the "nonPreEmptibleTraffic" element
     */
    void unsetNonPreEmptibleTraffic();
    
    /**
     * Gets the "wtrTime" element
     */
    java.math.BigInteger getWtrTime();
    
    /**
     * Gets (as xml) the "wtrTime" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType xgetWtrTime();
    
    /**
     * True if has "wtrTime" element
     */
    boolean isSetWtrTime();
    
    /**
     * Sets the "wtrTime" element
     */
    void setWtrTime(java.math.BigInteger wtrTime);
    
    /**
     * Sets (as xml) the "wtrTime" element
     */
    void xsetWtrTime(org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType wtrTime);
    
    /**
     * Unsets the "wtrTime" element
     */
    void unsetWtrTime();
    
    /**
     * Gets the "holdOffTime" element
     */
    java.lang.Object getHoldOffTime();
    
    /**
     * Gets (as xml) the "holdOffTime" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType xgetHoldOffTime();
    
    /**
     * True if has "holdOffTime" element
     */
    boolean isSetHoldOffTime();
    
    /**
     * Sets the "holdOffTime" element
     */
    void setHoldOffTime(java.lang.Object holdOffTime);
    
    /**
     * Sets (as xml) the "holdOffTime" element
     */
    void xsetHoldOffTime(org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType holdOffTime);
    
    /**
     * Unsets the "holdOffTime" element
     */
    void unsetHoldOffTime();
    
    /**
     * Gets the "lodNumSwitches" element
     */
    long getLodNumSwitches();
    
    /**
     * Gets (as xml) the "lodNumSwitches" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType xgetLodNumSwitches();
    
    /**
     * True if has "lodNumSwitches" element
     */
    boolean isSetLodNumSwitches();
    
    /**
     * Sets the "lodNumSwitches" element
     */
    void setLodNumSwitches(long lodNumSwitches);
    
    /**
     * Sets (as xml) the "lodNumSwitches" element
     */
    void xsetLodNumSwitches(org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType lodNumSwitches);
    
    /**
     * Unsets the "lodNumSwitches" element
     */
    void unsetLodNumSwitches();
    
    /**
     * Gets the "lodDuration" element
     */
    java.math.BigInteger getLodDuration();
    
    /**
     * Gets (as xml) the "lodDuration" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType xgetLodDuration();
    
    /**
     * True if has "lodDuration" element
     */
    boolean isSetLodDuration();
    
    /**
     * Sets the "lodDuration" element
     */
    void setLodDuration(java.math.BigInteger lodDuration);
    
    /**
     * Sets (as xml) the "lodDuration" element
     */
    void xsetLodDuration(org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType lodDuration);
    
    /**
     * Unsets the "lodDuration" element
     */
    void unsetLodDuration();
    
    /**
     * Gets the "tandemSwitching" element
     */
    java.lang.String getTandemSwitching();
    
    /**
     * Gets (as xml) the "tandemSwitching" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType xgetTandemSwitching();
    
    /**
     * True if has "tandemSwitching" element
     */
    boolean isSetTandemSwitching();
    
    /**
     * Sets the "tandemSwitching" element
     */
    void setTandemSwitching(java.lang.String tandemSwitching);
    
    /**
     * Sets (as xml) the "tandemSwitching" element
     */
    void xsetTandemSwitching(org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType tandemSwitching);
    
    /**
     * Unsets the "tandemSwitching" element
     */
    void unsetTandemSwitching();
    
    /**
     * Gets the "bundleSwitching" element
     */
    java.lang.String getBundleSwitching();
    
    /**
     * Gets (as xml) the "bundleSwitching" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType xgetBundleSwitching();
    
    /**
     * True if has "bundleSwitching" element
     */
    boolean isSetBundleSwitching();
    
    /**
     * Sets the "bundleSwitching" element
     */
    void setBundleSwitching(java.lang.String bundleSwitching);
    
    /**
     * Sets (as xml) the "bundleSwitching" element
     */
    void xsetBundleSwitching(org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType bundleSwitching);
    
    /**
     * Unsets the "bundleSwitching" element
     */
    void unsetBundleSwitching();
    
    /**
     * Gets the "hitless" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType.Enum getHitless();
    
    /**
     * Gets (as xml) the "hitless" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType xgetHitless();
    
    /**
     * True if has "hitless" element
     */
    boolean isSetHitless();
    
    /**
     * Sets the "hitless" element
     */
    void setHitless(org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType.Enum hitless);
    
    /**
     * Sets (as xml) the "hitless" element
     */
    void xsetHitless(org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType hitless);
    
    /**
     * Unsets the "hitless" element
     */
    void unsetHitless();
    
    /**
     * Gets the "exerciseOn" element
     */
    boolean getExerciseOn();
    
    /**
     * Gets (as xml) the "exerciseOn" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType xgetExerciseOn();
    
    /**
     * True if has "exerciseOn" element
     */
    boolean isSetExerciseOn();
    
    /**
     * Sets the "exerciseOn" element
     */
    void setExerciseOn(boolean exerciseOn);
    
    /**
     * Sets (as xml) the "exerciseOn" element
     */
    void xsetExerciseOn(org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType exerciseOn);
    
    /**
     * Unsets the "exerciseOn" element
     */
    void unsetExerciseOn();
    
    /**
     * Gets the "availabilityStatus" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType getAvailabilityStatus();
    
    /**
     * True if has "availabilityStatus" element
     */
    boolean isSetAvailabilityStatus();
    
    /**
     * Sets the "availabilityStatus" element
     */
    void setAvailabilityStatus(org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType availabilityStatus);
    
    /**
     * Appends and returns a new empty "availabilityStatus" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType addNewAvailabilityStatus();
    
    /**
     * Unsets the "availabilityStatus" element
     */
    void unsetAvailabilityStatus();
    
    /**
     * Gets the "switchCriteriaEnable" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType getSwitchCriteriaEnable();
    
    /**
     * True if has "switchCriteriaEnable" element
     */
    boolean isSetSwitchCriteriaEnable();
    
    /**
     * Sets the "switchCriteriaEnable" element
     */
    void setSwitchCriteriaEnable(org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType switchCriteriaEnable);
    
    /**
     * Appends and returns a new empty "switchCriteriaEnable" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType addNewSwitchCriteriaEnable();
    
    /**
     * Unsets the "switchCriteriaEnable" element
     */
    void unsetSwitchCriteriaEnable();
    
    /**
     * Gets the "privilegedChannel" element
     */
    java.lang.String getPrivilegedChannel();
    
    /**
     * Gets (as xml) the "privilegedChannel" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType xgetPrivilegedChannel();
    
    /**
     * True if has "privilegedChannel" element
     */
    boolean isSetPrivilegedChannel();
    
    /**
     * Sets the "privilegedChannel" element
     */
    void setPrivilegedChannel(java.lang.String privilegedChannel);
    
    /**
     * Sets (as xml) the "privilegedChannel" element
     */
    void xsetPrivilegedChannel(org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType privilegedChannel);
    
    /**
     * Unsets the "privilegedChannel" element
     */
    void unsetPrivilegedChannel();
    
    /**
     * Gets the "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
    
    /**
     * True if has "vendorExtensions" element
     */
    boolean isSetVendorExtensions();
    
    /**
     * Sets the "vendorExtensions" element
     */
    void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
    
    /**
     * Unsets the "vendorExtensions" element
     */
    void unsetVendorExtensions();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType newInstance() {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pgp.v1.ProtectionGroupParameterListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
