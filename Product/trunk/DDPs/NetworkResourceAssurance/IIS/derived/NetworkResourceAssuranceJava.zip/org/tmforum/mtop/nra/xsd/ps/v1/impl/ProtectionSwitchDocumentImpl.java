/*
 * An XML document type.
 * Localname: protectionSwitch
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/ps/v1
 * Java type: org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.ps.v1.impl;
/**
 * A document containing one protectionSwitch(@http://www.tmforum.org/mtop/nra/xsd/ps/v1) element.
 *
 * This is a complex type.
 */
public class ProtectionSwitchDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchDocument
{
    
    public ProtectionSwitchDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROTECTIONSWITCH$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "protectionSwitch");
    
    
    /**
     * Gets the "protectionSwitch" element
     */
    public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType getProtectionSwitch()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType)get_store().find_element_user(PROTECTIONSWITCH$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "protectionSwitch" element
     */
    public void setProtectionSwitch(org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType protectionSwitch)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType)get_store().find_element_user(PROTECTIONSWITCH$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType)get_store().add_element_user(PROTECTIONSWITCH$0);
            }
            target.set(protectionSwitch);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionSwitch" element
     */
    public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType addNewProtectionSwitch()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType)get_store().add_element_user(PROTECTIONSWITCH$0);
            return target;
        }
    }
}
