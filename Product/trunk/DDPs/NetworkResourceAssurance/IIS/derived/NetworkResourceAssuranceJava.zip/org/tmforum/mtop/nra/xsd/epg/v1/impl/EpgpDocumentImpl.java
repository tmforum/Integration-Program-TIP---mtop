/*
 * An XML document type.
 * Localname: epgp
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/epg/v1
 * Java type: org.tmforum.mtop.nra.xsd.epg.v1.EpgpDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.epg.v1.impl;
/**
 * A document containing one epgp(@http://www.tmforum.org/mtop/nra/xsd/epg/v1) element.
 *
 * This is a complex type.
 */
public class EpgpDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.epg.v1.EpgpDocument
{
    
    public EpgpDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EPGP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "epgp");
    
    
    /**
     * Gets the "epgp" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType getEpgp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().find_element_user(EPGP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "epgp" element
     */
    public void setEpgp(org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType epgp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().find_element_user(EPGP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().add_element_user(EPGP$0);
            }
            target.set(epgp);
        }
    }
    
    /**
     * Appends and returns a new empty "epgp" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType addNewEpgp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType)get_store().add_element_user(EPGP$0);
            return target;
        }
    }
}
