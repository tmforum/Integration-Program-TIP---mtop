/*
 * XML Type:  PmParameterType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmpar/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmpar.v1;


/**
 * An XML PmParameterType(@http://www.tmforum.org/mtop/nra/xsd/pmpar/v1).
 *
 * This is a complex type.
 */
public interface PmParameterType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PmParameterType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3302A0BB3167604C489D394E7972B422").resolveHandle("pmparametertype038etype");
    
    /**
     * Gets a List of "pmParameter" elements
     */
    java.util.List<java.lang.String> getPmParameterList();
    
    /**
     * Gets array of all "pmParameter" elements
     * @deprecated
     */
    java.lang.String[] getPmParameterArray();
    
    /**
     * Gets ith "pmParameter" element
     */
    java.lang.String getPmParameterArray(int i);
    
    /**
     * Gets (as xml) a List of "pmParameter" elements
     */
    java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType> xgetPmParameterList();
    
    /**
     * Gets (as xml) array of all "pmParameter" elements
     * @deprecated
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[] xgetPmParameterArray();
    
    /**
     * Gets (as xml) ith "pmParameter" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterArray(int i);
    
    /**
     * Returns number of "pmParameter" element
     */
    int sizeOfPmParameterArray();
    
    /**
     * Sets array of all "pmParameter" element
     */
    void setPmParameterArray(java.lang.String[] pmParameterArray);
    
    /**
     * Sets ith "pmParameter" element
     */
    void setPmParameterArray(int i, java.lang.String pmParameter);
    
    /**
     * Sets (as xml) array of all "pmParameter" element
     */
    void xsetPmParameterArray(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[] pmParameterArray);
    
    /**
     * Sets (as xml) ith "pmParameter" element
     */
    void xsetPmParameterArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameter);
    
    /**
     * Inserts the value as the ith "pmParameter" element
     */
    void insertPmParameter(int i, java.lang.String pmParameter);
    
    /**
     * Appends the value as the last "pmParameter" element
     */
    void addPmParameter(java.lang.String pmParameter);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmParameter" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType insertNewPmParameter(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmParameter" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType addNewPmParameter();
    
    /**
     * Removes the ith "pmParameter" element
     */
    void removePmParameter(int i);
    
    /**
     * Gets a List of "pmLocation" elements
     */
    java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum> getPmLocationList();
    
    /**
     * Gets array of all "pmLocation" elements
     * @deprecated
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] getPmLocationArray();
    
    /**
     * Gets ith "pmLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getPmLocationArray(int i);
    
    /**
     * Gets (as xml) a List of "pmLocation" elements
     */
    java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType> xgetPmLocationList();
    
    /**
     * Gets (as xml) array of all "pmLocation" elements
     * @deprecated
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[] xgetPmLocationArray();
    
    /**
     * Gets (as xml) ith "pmLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetPmLocationArray(int i);
    
    /**
     * Returns number of "pmLocation" element
     */
    int sizeOfPmLocationArray();
    
    /**
     * Sets array of all "pmLocation" element
     */
    void setPmLocationArray(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] pmLocationArray);
    
    /**
     * Sets ith "pmLocation" element
     */
    void setPmLocationArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation);
    
    /**
     * Sets (as xml) array of all "pmLocation" element
     */
    void xsetPmLocationArray(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[] pmLocationArray);
    
    /**
     * Sets (as xml) ith "pmLocation" element
     */
    void xsetPmLocationArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType pmLocation);
    
    /**
     * Inserts the value as the ith "pmLocation" element
     */
    void insertPmLocation(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation);
    
    /**
     * Appends the value as the last "pmLocation" element
     */
    void addPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType insertNewPmLocation(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType addNewPmLocation();
    
    /**
     * Removes the ith "pmLocation" element
     */
    void removePmLocation(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType newInstance() {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
