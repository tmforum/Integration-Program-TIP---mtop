/*
 * XML Type:  ProposedRepairActionListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1.impl;
/**
 * An XML ProposedRepairActionListType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is a complex type.
 */
public class ProposedRepairActionListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType
{
    
    public ProposedRepairActionListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROPOSEDREPAIRACTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/com/v1", "proposedRepairAction");
    
    
    /**
     * Gets a List of "proposedRepairAction" elements
     */
    public java.util.List<java.lang.String> getProposedRepairActionList()
    {
        final class ProposedRepairActionList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return ProposedRepairActionListTypeImpl.this.getProposedRepairActionArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = ProposedRepairActionListTypeImpl.this.getProposedRepairActionArray(i);
                ProposedRepairActionListTypeImpl.this.setProposedRepairActionArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { ProposedRepairActionListTypeImpl.this.insertProposedRepairAction(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = ProposedRepairActionListTypeImpl.this.getProposedRepairActionArray(i);
                ProposedRepairActionListTypeImpl.this.removeProposedRepairAction(i);
                return old;
            }
            
            public int size()
                { return ProposedRepairActionListTypeImpl.this.sizeOfProposedRepairActionArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ProposedRepairActionList();
        }
    }
    
    /**
     * Gets array of all "proposedRepairAction" elements
     */
    public java.lang.String[] getProposedRepairActionArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PROPOSEDREPAIRACTION$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "proposedRepairAction" element
     */
    public java.lang.String getProposedRepairActionArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROPOSEDREPAIRACTION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "proposedRepairAction" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType> xgetProposedRepairActionList()
    {
        final class ProposedRepairActionList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType>
        {
            public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType get(int i)
                { return ProposedRepairActionListTypeImpl.this.xgetProposedRepairActionArray(i); }
            
            public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType set(int i, org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType o)
            {
                org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType old = ProposedRepairActionListTypeImpl.this.xgetProposedRepairActionArray(i);
                ProposedRepairActionListTypeImpl.this.xsetProposedRepairActionArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType o)
                { ProposedRepairActionListTypeImpl.this.insertNewProposedRepairAction(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType old = ProposedRepairActionListTypeImpl.this.xgetProposedRepairActionArray(i);
                ProposedRepairActionListTypeImpl.this.removeProposedRepairAction(i);
                return old;
            }
            
            public int size()
                { return ProposedRepairActionListTypeImpl.this.sizeOfProposedRepairActionArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ProposedRepairActionList();
        }
    }
    
    /**
     * Gets (as xml) array of all "proposedRepairAction" elements
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType[] xgetProposedRepairActionArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PROPOSEDREPAIRACTION$0, targetList);
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType[] result = new org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "proposedRepairAction" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType xgetProposedRepairActionArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType)get_store().find_element_user(PROPOSEDREPAIRACTION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType)target;
        }
    }
    
    /**
     * Returns number of "proposedRepairAction" element
     */
    public int sizeOfProposedRepairActionArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROPOSEDREPAIRACTION$0);
        }
    }
    
    /**
     * Sets array of all "proposedRepairAction" element
     */
    public void setProposedRepairActionArray(java.lang.String[] proposedRepairActionArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(proposedRepairActionArray, PROPOSEDREPAIRACTION$0);
        }
    }
    
    /**
     * Sets ith "proposedRepairAction" element
     */
    public void setProposedRepairActionArray(int i, java.lang.String proposedRepairAction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROPOSEDREPAIRACTION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(proposedRepairAction);
        }
    }
    
    /**
     * Sets (as xml) array of all "proposedRepairAction" element
     */
    public void xsetProposedRepairActionArray(org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType[]proposedRepairActionArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(proposedRepairActionArray, PROPOSEDREPAIRACTION$0);
        }
    }
    
    /**
     * Sets (as xml) ith "proposedRepairAction" element
     */
    public void xsetProposedRepairActionArray(int i, org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType proposedRepairAction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType)get_store().find_element_user(PROPOSEDREPAIRACTION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(proposedRepairAction);
        }
    }
    
    /**
     * Inserts the value as the ith "proposedRepairAction" element
     */
    public void insertProposedRepairAction(int i, java.lang.String proposedRepairAction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PROPOSEDREPAIRACTION$0, i);
            target.setStringValue(proposedRepairAction);
        }
    }
    
    /**
     * Appends the value as the last "proposedRepairAction" element
     */
    public void addProposedRepairAction(java.lang.String proposedRepairAction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROPOSEDREPAIRACTION$0);
            target.setStringValue(proposedRepairAction);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "proposedRepairAction" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType insertNewProposedRepairAction(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType)get_store().insert_element_user(PROPOSEDREPAIRACTION$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "proposedRepairAction" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType addNewProposedRepairAction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionType)get_store().add_element_user(PROPOSEDREPAIRACTION$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "proposedRepairAction" element
     */
    public void removeProposedRepairAction(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROPOSEDREPAIRACTION$0, i);
        }
    }
}
