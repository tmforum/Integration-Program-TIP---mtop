/*
 * XML Type:  ThresholdCrossingAlertType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tca/v1
 * Java type: org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tca.v1.impl;
/**
 * An XML ThresholdCrossingAlertType(@http://www.tmforum.org/mtop/nra/xsd/tca/v1).
 *
 * This is a complex type.
 */
public class ThresholdCrossingAlertTypeImpl extends org.tmforum.mtop.fmw.xsd.ei.v1.impl.EventInformationTypeImpl implements org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType
{
    
    public ThresholdCrossingAlertTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALIASNAMELIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "aliasNameList");
    private static final javax.xml.namespace.QName ISCLEARABLE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "isClearable");
    private static final javax.xml.namespace.QName PERCEIVEDSEVERITY$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "perceivedSeverity");
    private static final javax.xml.namespace.QName LAYERRATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "layerRate");
    private static final javax.xml.namespace.QName GRANULARITY$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "granularity");
    private static final javax.xml.namespace.QName PMPARAMETERNAME$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "pmParameterName");
    private static final javax.xml.namespace.QName PARAMETERLOCATION$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "parameterLocation");
    private static final javax.xml.namespace.QName THRESHOLDTYPE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "thresholdType");
    private static final javax.xml.namespace.QName THRESHOLDVALUE$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "thresholdValue");
    private static final javax.xml.namespace.QName THRESHOLDUNIT$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "thresholdUnit");
    private static final javax.xml.namespace.QName ACKNOWLEDGEMENT$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "acknowledgement");
    private static final javax.xml.namespace.QName ISEDGEPOINTRELATED$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "isEdgePointRelated");
    
    
    /**
     * Gets the "aliasNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "aliasNameList" element
     */
    public void setAliasNameList(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNameList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$0);
            }
            target.set(aliasNameList);
        }
    }
    
    /**
     * Appends and returns a new empty "aliasNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$0);
            return target;
        }
    }
    
    /**
     * Gets the "isClearable" element
     */
    public boolean getIsClearable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISCLEARABLE$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isClearable" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsClearable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISCLEARABLE$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "isClearable" element
     */
    public void setIsClearable(boolean isClearable)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISCLEARABLE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISCLEARABLE$2);
            }
            target.setBooleanValue(isClearable);
        }
    }
    
    /**
     * Sets (as xml) the "isClearable" element
     */
    public void xsetIsClearable(org.apache.xmlbeans.XmlBoolean isClearable)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISCLEARABLE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISCLEARABLE$2);
            }
            target.set(isClearable);
        }
    }
    
    /**
     * Gets the "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum getPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCEIVEDSEVERITY$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType xgetPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().find_element_user(PERCEIVEDSEVERITY$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "perceivedSeverity" element
     */
    public void setPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCEIVEDSEVERITY$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PERCEIVEDSEVERITY$4);
            }
            target.setEnumValue(perceivedSeverity);
        }
    }
    
    /**
     * Sets (as xml) the "perceivedSeverity" element
     */
    public void xsetPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().find_element_user(PERCEIVEDSEVERITY$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().add_element_user(PERCEIVEDSEVERITY$4);
            }
            target.set(perceivedSeverity);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            return target;
        }
    }
    
    /**
     * Gets the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "granularity" element
     */
    public void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(GRANULARITY$8);
            }
            target.setEnumValue(granularity);
        }
    }
    
    /**
     * Sets (as xml) the "granularity" element
     */
    public void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$8);
            }
            target.set(granularity);
        }
    }
    
    /**
     * Gets the "pmParameterName" element
     */
    public java.lang.String getPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$10, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pmParameterName" element
     */
    public void setPmParameterName(java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMPARAMETERNAME$10);
            }
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    public void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$10);
            }
            target.set(pmParameterName);
        }
    }
    
    /**
     * Gets the "parameterLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getParameterLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PARAMETERLOCATION$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "parameterLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetParameterLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PARAMETERLOCATION$12, 0);
            return target;
        }
    }
    
    /**
     * Sets the "parameterLocation" element
     */
    public void setParameterLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum parameterLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PARAMETERLOCATION$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PARAMETERLOCATION$12);
            }
            target.setEnumValue(parameterLocation);
        }
    }
    
    /**
     * Sets (as xml) the "parameterLocation" element
     */
    public void xsetParameterLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType parameterLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PARAMETERLOCATION$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().add_element_user(PARAMETERLOCATION$12);
            }
            target.set(parameterLocation);
        }
    }
    
    /**
     * Gets the "thresholdType" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType getThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().find_element_user(THRESHOLDTYPE$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "thresholdType" element
     */
    public void setThresholdType(org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType thresholdType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().find_element_user(THRESHOLDTYPE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().add_element_user(THRESHOLDTYPE$14);
            }
            target.set(thresholdType);
        }
    }
    
    /**
     * Appends and returns a new empty "thresholdType" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType addNewThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().add_element_user(THRESHOLDTYPE$14);
            return target;
        }
    }
    
    /**
     * Gets the "thresholdValue" element
     */
    public float getThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDVALUE$16, 0);
            if (target == null)
            {
                return 0.0f;
            }
            return target.getFloatValue();
        }
    }
    
    /**
     * Gets (as xml) the "thresholdValue" element
     */
    public org.apache.xmlbeans.XmlFloat xgetThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(THRESHOLDVALUE$16, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "thresholdValue" element
     */
    public boolean isNilThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(THRESHOLDVALUE$16, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "thresholdValue" element
     */
    public boolean isSetThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(THRESHOLDVALUE$16) != 0;
        }
    }
    
    /**
     * Sets the "thresholdValue" element
     */
    public void setThresholdValue(float thresholdValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDVALUE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(THRESHOLDVALUE$16);
            }
            target.setFloatValue(thresholdValue);
        }
    }
    
    /**
     * Sets (as xml) the "thresholdValue" element
     */
    public void xsetThresholdValue(org.apache.xmlbeans.XmlFloat thresholdValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(THRESHOLDVALUE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlFloat)get_store().add_element_user(THRESHOLDVALUE$16);
            }
            target.set(thresholdValue);
        }
    }
    
    /**
     * Nils the "thresholdValue" element
     */
    public void setNilThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(THRESHOLDVALUE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlFloat)get_store().add_element_user(THRESHOLDVALUE$16);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "thresholdValue" element
     */
    public void unsetThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(THRESHOLDVALUE$16, 0);
        }
    }
    
    /**
     * Gets the "thresholdUnit" element
     */
    public java.lang.String getThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDUNIT$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "thresholdUnit" element
     */
    public org.apache.xmlbeans.XmlString xgetThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(THRESHOLDUNIT$18, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "thresholdUnit" element
     */
    public boolean isNilThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(THRESHOLDUNIT$18, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "thresholdUnit" element
     */
    public boolean isSetThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(THRESHOLDUNIT$18) != 0;
        }
    }
    
    /**
     * Sets the "thresholdUnit" element
     */
    public void setThresholdUnit(java.lang.String thresholdUnit)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDUNIT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(THRESHOLDUNIT$18);
            }
            target.setStringValue(thresholdUnit);
        }
    }
    
    /**
     * Sets (as xml) the "thresholdUnit" element
     */
    public void xsetThresholdUnit(org.apache.xmlbeans.XmlString thresholdUnit)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(THRESHOLDUNIT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(THRESHOLDUNIT$18);
            }
            target.set(thresholdUnit);
        }
    }
    
    /**
     * Nils the "thresholdUnit" element
     */
    public void setNilThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(THRESHOLDUNIT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(THRESHOLDUNIT$18);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "thresholdUnit" element
     */
    public void unsetThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(THRESHOLDUNIT$18, 0);
        }
    }
    
    /**
     * Gets the "acknowledgement" element
     */
    public org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType.Enum getAcknowledgement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACKNOWLEDGEMENT$20, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "acknowledgement" element
     */
    public org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType xgetAcknowledgement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType target = null;
            target = (org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType)get_store().find_element_user(ACKNOWLEDGEMENT$20, 0);
            return target;
        }
    }
    
    /**
     * Sets the "acknowledgement" element
     */
    public void setAcknowledgement(org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType.Enum acknowledgement)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACKNOWLEDGEMENT$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACKNOWLEDGEMENT$20);
            }
            target.setEnumValue(acknowledgement);
        }
    }
    
    /**
     * Sets (as xml) the "acknowledgement" element
     */
    public void xsetAcknowledgement(org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType acknowledgement)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType target = null;
            target = (org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType)get_store().find_element_user(ACKNOWLEDGEMENT$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType)get_store().add_element_user(ACKNOWLEDGEMENT$20);
            }
            target.set(acknowledgement);
        }
    }
    
    /**
     * Gets the "isEdgePointRelated" element
     */
    public boolean getIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEDGEPOINTRELATED$22, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isEdgePointRelated" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINTRELATED$22, 0);
            return target;
        }
    }
    
    /**
     * True if has "isEdgePointRelated" element
     */
    public boolean isSetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISEDGEPOINTRELATED$22) != 0;
        }
    }
    
    /**
     * Sets the "isEdgePointRelated" element
     */
    public void setIsEdgePointRelated(boolean isEdgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEDGEPOINTRELATED$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISEDGEPOINTRELATED$22);
            }
            target.setBooleanValue(isEdgePointRelated);
        }
    }
    
    /**
     * Sets (as xml) the "isEdgePointRelated" element
     */
    public void xsetIsEdgePointRelated(org.apache.xmlbeans.XmlBoolean isEdgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINTRELATED$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISEDGEPOINTRELATED$22);
            }
            target.set(isEdgePointRelated);
        }
    }
    
    /**
     * Unsets the "isEdgePointRelated" element
     */
    public void unsetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISEDGEPOINTRELATED$22, 0);
        }
    }
}
