/*
 * XML Type:  HoldingTimeType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pm/v1
 * Java type: org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pm.v1.impl;
/**
 * An XML HoldingTimeType(@http://www.tmforum.org/mtop/nra/xsd/pm/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType.
 */
public class HoldingTimeTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType
{
    
    public HoldingTimeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected HoldingTimeTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
