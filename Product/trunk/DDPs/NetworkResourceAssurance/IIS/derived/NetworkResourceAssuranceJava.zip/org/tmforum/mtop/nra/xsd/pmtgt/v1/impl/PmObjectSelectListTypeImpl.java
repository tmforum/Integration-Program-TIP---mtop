/*
 * XML Type:  PmObjectSelectListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmtgt.v1.impl;
/**
 * An XML PmObjectSelectListType(@http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1).
 *
 * This is a complex type.
 */
public class PmObjectSelectListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType
{
    
    public PmObjectSelectListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMOBJECTSELECT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1", "pmObjectSelect");
    
    
    /**
     * Gets a List of "pmObjectSelect" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType> getPmObjectSelectList()
    {
        final class PmObjectSelectList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType>
        {
            public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType get(int i)
                { return PmObjectSelectListTypeImpl.this.getPmObjectSelectArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType set(int i, org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType o)
            {
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType old = PmObjectSelectListTypeImpl.this.getPmObjectSelectArray(i);
                PmObjectSelectListTypeImpl.this.setPmObjectSelectArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType o)
                { PmObjectSelectListTypeImpl.this.insertNewPmObjectSelect(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType old = PmObjectSelectListTypeImpl.this.getPmObjectSelectArray(i);
                PmObjectSelectListTypeImpl.this.removePmObjectSelect(i);
                return old;
            }
            
            public int size()
                { return PmObjectSelectListTypeImpl.this.sizeOfPmObjectSelectArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmObjectSelectList();
        }
    }
    
    /**
     * Gets array of all "pmObjectSelect" elements
     */
    public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType[] getPmObjectSelectArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMOBJECTSELECT$0, targetList);
            org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType[] result = new org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pmObjectSelect" element
     */
    public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType getPmObjectSelectArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType)get_store().find_element_user(PMOBJECTSELECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pmObjectSelect" element
     */
    public int sizeOfPmObjectSelectArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMOBJECTSELECT$0);
        }
    }
    
    /**
     * Sets array of all "pmObjectSelect" element
     */
    public void setPmObjectSelectArray(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType[] pmObjectSelectArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmObjectSelectArray, PMOBJECTSELECT$0);
        }
    }
    
    /**
     * Sets ith "pmObjectSelect" element
     */
    public void setPmObjectSelectArray(int i, org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType pmObjectSelect)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType)get_store().find_element_user(PMOBJECTSELECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmObjectSelect);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmObjectSelect" element
     */
    public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType insertNewPmObjectSelect(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType)get_store().insert_element_user(PMOBJECTSELECT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmObjectSelect" element
     */
    public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType addNewPmObjectSelect()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType)get_store().add_element_user(PMOBJECTSELECT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmObjectSelect" element
     */
    public void removePmObjectSelect(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMOBJECTSELECT$0, i);
        }
    }
}
