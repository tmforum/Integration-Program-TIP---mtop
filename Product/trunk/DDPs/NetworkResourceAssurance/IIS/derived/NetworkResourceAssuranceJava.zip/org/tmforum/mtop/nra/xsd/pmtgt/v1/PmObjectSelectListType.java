/*
 * XML Type:  PmObjectSelectListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmtgt.v1;


/**
 * An XML PmObjectSelectListType(@http://www.tmforum.org/mtop/nra/xsd/pmtgt/v1).
 *
 * This is a complex type.
 */
public interface PmObjectSelectListType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PmObjectSelectListType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("pmobjectselectlisttype3092type");
    
    /**
     * Gets a List of "pmObjectSelect" elements
     */
    java.util.List<org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType> getPmObjectSelectList();
    
    /**
     * Gets array of all "pmObjectSelect" elements
     * @deprecated
     */
    org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType[] getPmObjectSelectArray();
    
    /**
     * Gets ith "pmObjectSelect" element
     */
    org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType getPmObjectSelectArray(int i);
    
    /**
     * Returns number of "pmObjectSelect" element
     */
    int sizeOfPmObjectSelectArray();
    
    /**
     * Sets array of all "pmObjectSelect" element
     */
    void setPmObjectSelectArray(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType[] pmObjectSelectArray);
    
    /**
     * Sets ith "pmObjectSelect" element
     */
    void setPmObjectSelectArray(int i, org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType pmObjectSelect);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmObjectSelect" element
     */
    org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType insertNewPmObjectSelect(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmObjectSelect" element
     */
    org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectType addNewPmObjectSelect();
    
    /**
     * Removes the ith "pmObjectSelect" element
     */
    void removePmObjectSelect(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType newInstance() {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
