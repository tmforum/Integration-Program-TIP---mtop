/*
 * XML Type:  EquipmentProtectionSwitchType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/eps/v1
 * Java type: org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.eps.v1;


/**
 * An XML EquipmentProtectionSwitchType(@http://www.tmforum.org/mtop/nra/xsd/eps/v1).
 *
 * This is a complex type.
 */
public interface EquipmentProtectionSwitchType extends org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EquipmentProtectionSwitchType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("equipmentprotectionswitchtype90dbtype");
    
    /**
     * Gets the "osTime" element
     */
    java.util.Calendar getOsTime();
    
    /**
     * Gets (as xml) the "osTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetOsTime();
    
    /**
     * True if has "osTime" element
     */
    boolean isSetOsTime();
    
    /**
     * Sets the "osTime" element
     */
    void setOsTime(java.util.Calendar osTime);
    
    /**
     * Sets (as xml) the "osTime" element
     */
    void xsetOsTime(org.apache.xmlbeans.XmlDateTime osTime);
    
    /**
     * Unsets the "osTime" element
     */
    void unsetOsTime();
    
    /**
     * Gets the "epgType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType getEpgType();
    
    /**
     * True if has "epgType" element
     */
    boolean isSetEpgType();
    
    /**
     * Sets the "epgType" element
     */
    void setEpgType(org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType epgType);
    
    /**
     * Appends and returns a new empty "epgType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType addNewEpgType();
    
    /**
     * Unsets the "epgType" element
     */
    void unsetEpgType();
    
    /**
     * Gets the "equipmentSwitchReason" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType getEquipmentSwitchReason();
    
    /**
     * True if has "equipmentSwitchReason" element
     */
    boolean isSetEquipmentSwitchReason();
    
    /**
     * Sets the "equipmentSwitchReason" element
     */
    void setEquipmentSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType equipmentSwitchReason);
    
    /**
     * Appends and returns a new empty "equipmentSwitchReason" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType addNewEquipmentSwitchReason();
    
    /**
     * Unsets the "equipmentSwitchReason" element
     */
    void unsetEquipmentSwitchReason();
    
    /**
     * Gets the "epgRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEpgRef();
    
    /**
     * True if has "epgRef" element
     */
    boolean isSetEpgRef();
    
    /**
     * Sets the "epgRef" element
     */
    void setEpgRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType epgRef);
    
    /**
     * Appends and returns a new empty "epgRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEpgRef();
    
    /**
     * Unsets the "epgRef" element
     */
    void unsetEpgRef();
    
    /**
     * Gets the "protectedEquipmentRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProtectedEquipmentRef();
    
    /**
     * True if has "protectedEquipmentRef" element
     */
    boolean isSetProtectedEquipmentRef();
    
    /**
     * Sets the "protectedEquipmentRef" element
     */
    void setProtectedEquipmentRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType protectedEquipmentRef);
    
    /**
     * Appends and returns a new empty "protectedEquipmentRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProtectedEquipmentRef();
    
    /**
     * Unsets the "protectedEquipmentRef" element
     */
    void unsetProtectedEquipmentRef();
    
    /**
     * Gets the "switchAwayFromEquipmentRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchAwayFromEquipmentRef();
    
    /**
     * True if has "switchAwayFromEquipmentRef" element
     */
    boolean isSetSwitchAwayFromEquipmentRef();
    
    /**
     * Sets the "switchAwayFromEquipmentRef" element
     */
    void setSwitchAwayFromEquipmentRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchAwayFromEquipmentRef);
    
    /**
     * Appends and returns a new empty "switchAwayFromEquipmentRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchAwayFromEquipmentRef();
    
    /**
     * Unsets the "switchAwayFromEquipmentRef" element
     */
    void unsetSwitchAwayFromEquipmentRef();
    
    /**
     * Gets the "switchToEquipmentRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchToEquipmentRef();
    
    /**
     * True if has "switchToEquipmentRef" element
     */
    boolean isSetSwitchToEquipmentRef();
    
    /**
     * Sets the "switchToEquipmentRef" element
     */
    void setSwitchToEquipmentRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchToEquipmentRef);
    
    /**
     * Appends and returns a new empty "switchToEquipmentRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchToEquipmentRef();
    
    /**
     * Unsets the "switchToEquipmentRef" element
     */
    void unsetSwitchToEquipmentRef();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType newInstance() {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
