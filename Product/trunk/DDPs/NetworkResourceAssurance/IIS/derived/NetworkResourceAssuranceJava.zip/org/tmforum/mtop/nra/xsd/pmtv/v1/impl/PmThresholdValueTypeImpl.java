/*
 * XML Type:  PmThresholdValueType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmtv/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmtv.v1.impl;
/**
 * An XML PmThresholdValueType(@http://www.tmforum.org/mtop/nra/xsd/pmtv/v1).
 *
 * This is a complex type.
 */
public class PmThresholdValueTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType
{
    
    public PmThresholdValueTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETERNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtv/v1", "pmParameterName");
    private static final javax.xml.namespace.QName PMLOCATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtv/v1", "pmLocation");
    private static final javax.xml.namespace.QName THRESHOLDTYPE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtv/v1", "thresholdType");
    private static final javax.xml.namespace.QName TRIGGERFLAG$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtv/v1", "triggerFlag");
    private static final javax.xml.namespace.QName VALUE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtv/v1", "value");
    private static final javax.xml.namespace.QName UNITS$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtv/v1", "units");
    
    
    /**
     * Gets the "pmParameterName" element
     */
    public java.lang.String getPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "pmParameterName" element
     */
    public boolean isNilPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmParameterName" element
     */
    public boolean isSetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETERNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "pmParameterName" element
     */
    public void setPmParameterName(java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    public void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.set(pmParameterName);
        }
    }
    
    /**
     * Nils the "pmParameterName" element
     */
    public void setNilPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmParameterName" element
     */
    public void unsetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETERNAME$0, 0);
        }
    }
    
    /**
     * Gets a List of "pmLocation" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum> getPmLocationList()
    {
        final class PmLocationList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum get(int i)
                { return PmThresholdValueTypeImpl.this.getPmLocationArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum old = PmThresholdValueTypeImpl.this.getPmLocationArray(i);
                PmThresholdValueTypeImpl.this.setPmLocationArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum o)
                { PmThresholdValueTypeImpl.this.insertPmLocation(i, o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum old = PmThresholdValueTypeImpl.this.getPmLocationArray(i);
                PmThresholdValueTypeImpl.this.removePmLocation(i);
                return old;
            }
            
            public int size()
                { return PmThresholdValueTypeImpl.this.sizeOfPmLocationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmLocationList();
        }
    }
    
    /**
     * Gets array of all "pmLocation" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] getPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMLOCATION$2, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
            return result;
        }
    }
    
    /**
     * Gets ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getPmLocationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "pmLocation" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType> xgetPmLocationList()
    {
        final class PmLocationList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType get(int i)
                { return PmThresholdValueTypeImpl.this.xgetPmLocationArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType old = PmThresholdValueTypeImpl.this.xgetPmLocationArray(i);
                PmThresholdValueTypeImpl.this.xsetPmLocationArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType o)
                { PmThresholdValueTypeImpl.this.insertNewPmLocation(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType old = PmThresholdValueTypeImpl.this.xgetPmLocationArray(i);
                PmThresholdValueTypeImpl.this.removePmLocation(i);
                return old;
            }
            
            public int size()
                { return PmThresholdValueTypeImpl.this.sizeOfPmLocationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmLocationList();
        }
    }
    
    /**
     * Gets (as xml) array of all "pmLocation" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[] xgetPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMLOCATION$2, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetPmLocationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)target;
        }
    }
    
    /**
     * Returns number of "pmLocation" element
     */
    public int sizeOfPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMLOCATION$2);
        }
    }
    
    /**
     * Sets array of all "pmLocation" element
     */
    public void setPmLocationArray(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] pmLocationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmLocationArray, PMLOCATION$2);
        }
    }
    
    /**
     * Sets ith "pmLocation" element
     */
    public void setPmLocationArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Sets (as xml) array of all "pmLocation" element
     */
    public void xsetPmLocationArray(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[]pmLocationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmLocationArray, PMLOCATION$2);
        }
    }
    
    /**
     * Sets (as xml) ith "pmLocation" element
     */
    public void xsetPmLocationArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmLocation);
        }
    }
    
    /**
     * Inserts the value as the ith "pmLocation" element
     */
    public void insertPmLocation(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PMLOCATION$2, i);
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Appends the value as the last "pmLocation" element
     */
    public void addPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMLOCATION$2);
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType insertNewPmLocation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().insert_element_user(PMLOCATION$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType addNewPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().add_element_user(PMLOCATION$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmLocation" element
     */
    public void removePmLocation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMLOCATION$2, i);
        }
    }
    
    /**
     * Gets the "thresholdType" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType.Enum getThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDTYPE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "thresholdType" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType xgetThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().find_element_user(THRESHOLDTYPE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "thresholdType" element
     */
    public boolean isNilThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().find_element_user(THRESHOLDTYPE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "thresholdType" element
     */
    public boolean isSetThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(THRESHOLDTYPE$4) != 0;
        }
    }
    
    /**
     * Sets the "thresholdType" element
     */
    public void setThresholdType(org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType.Enum thresholdType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDTYPE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(THRESHOLDTYPE$4);
            }
            target.setEnumValue(thresholdType);
        }
    }
    
    /**
     * Sets (as xml) the "thresholdType" element
     */
    public void xsetThresholdType(org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType thresholdType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().find_element_user(THRESHOLDTYPE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().add_element_user(THRESHOLDTYPE$4);
            }
            target.set(thresholdType);
        }
    }
    
    /**
     * Nils the "thresholdType" element
     */
    public void setNilThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().find_element_user(THRESHOLDTYPE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().add_element_user(THRESHOLDTYPE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "thresholdType" element
     */
    public void unsetThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(THRESHOLDTYPE$4, 0);
        }
    }
    
    /**
     * Gets the "triggerFlag" element
     */
    public boolean getTriggerFlag()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRIGGERFLAG$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "triggerFlag" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetTriggerFlag()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(TRIGGERFLAG$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "triggerFlag" element
     */
    public boolean isNilTriggerFlag()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(TRIGGERFLAG$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "triggerFlag" element
     */
    public boolean isSetTriggerFlag()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRIGGERFLAG$6) != 0;
        }
    }
    
    /**
     * Sets the "triggerFlag" element
     */
    public void setTriggerFlag(boolean triggerFlag)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRIGGERFLAG$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TRIGGERFLAG$6);
            }
            target.setBooleanValue(triggerFlag);
        }
    }
    
    /**
     * Sets (as xml) the "triggerFlag" element
     */
    public void xsetTriggerFlag(org.apache.xmlbeans.XmlBoolean triggerFlag)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(TRIGGERFLAG$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(TRIGGERFLAG$6);
            }
            target.set(triggerFlag);
        }
    }
    
    /**
     * Nils the "triggerFlag" element
     */
    public void setNilTriggerFlag()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(TRIGGERFLAG$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(TRIGGERFLAG$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "triggerFlag" element
     */
    public void unsetTriggerFlag()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRIGGERFLAG$6, 0);
        }
    }
    
    /**
     * Gets the "value" element
     */
    public float getValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUE$8, 0);
            if (target == null)
            {
                return 0.0f;
            }
            return target.getFloatValue();
        }
    }
    
    /**
     * Gets (as xml) the "value" element
     */
    public org.apache.xmlbeans.XmlFloat xgetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(VALUE$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "value" element
     */
    public boolean isNilValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(VALUE$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "value" element
     */
    public boolean isSetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALUE$8) != 0;
        }
    }
    
    /**
     * Sets the "value" element
     */
    public void setValue(float value)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALUE$8);
            }
            target.setFloatValue(value);
        }
    }
    
    /**
     * Sets (as xml) the "value" element
     */
    public void xsetValue(org.apache.xmlbeans.XmlFloat value)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(VALUE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlFloat)get_store().add_element_user(VALUE$8);
            }
            target.set(value);
        }
    }
    
    /**
     * Nils the "value" element
     */
    public void setNilValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(VALUE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlFloat)get_store().add_element_user(VALUE$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "value" element
     */
    public void unsetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALUE$8, 0);
        }
    }
    
    /**
     * Gets the "units" element
     */
    public java.lang.String getUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UNITS$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "units" element
     */
    public org.apache.xmlbeans.XmlString xgetUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UNITS$10, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "units" element
     */
    public boolean isNilUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UNITS$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "units" element
     */
    public boolean isSetUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UNITS$10) != 0;
        }
    }
    
    /**
     * Sets the "units" element
     */
    public void setUnits(java.lang.String units)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UNITS$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UNITS$10);
            }
            target.setStringValue(units);
        }
    }
    
    /**
     * Sets (as xml) the "units" element
     */
    public void xsetUnits(org.apache.xmlbeans.XmlString units)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UNITS$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(UNITS$10);
            }
            target.set(units);
        }
    }
    
    /**
     * Nils the "units" element
     */
    public void setNilUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UNITS$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(UNITS$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "units" element
     */
    public void unsetUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UNITS$10, 0);
        }
    }
}
