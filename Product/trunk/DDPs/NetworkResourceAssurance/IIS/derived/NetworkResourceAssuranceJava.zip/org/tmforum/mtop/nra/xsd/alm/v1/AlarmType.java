/*
 * XML Type:  AlarmType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alm/v1
 * Java type: org.tmforum.mtop.nra.xsd.alm.v1.AlarmType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alm.v1;


/**
 * An XML AlarmType(@http://www.tmforum.org/mtop/nra/xsd/alm/v1).
 *
 * This is a complex type.
 */
public interface AlarmType extends org.tmforum.mtop.fmw.xsd.ei.v1.EventInformationType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AlarmType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3302A0BB3167604C489D394E7972B422").resolveHandle("alarmtype44abtype");
    
    /**
     * Gets the "isEdgePointRelated" element
     */
    boolean getIsEdgePointRelated();
    
    /**
     * Gets (as xml) the "isEdgePointRelated" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsEdgePointRelated();
    
    /**
     * True if has "isEdgePointRelated" element
     */
    boolean isSetIsEdgePointRelated();
    
    /**
     * Sets the "isEdgePointRelated" element
     */
    void setIsEdgePointRelated(boolean isEdgePointRelated);
    
    /**
     * Sets (as xml) the "isEdgePointRelated" element
     */
    void xsetIsEdgePointRelated(org.apache.xmlbeans.XmlBoolean isEdgePointRelated);
    
    /**
     * Unsets the "isEdgePointRelated" element
     */
    void unsetIsEdgePointRelated();
    
    /**
     * Gets the "isClearable" element
     */
    boolean getIsClearable();
    
    /**
     * Gets (as xml) the "isClearable" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsClearable();
    
    /**
     * True if has "isClearable" element
     */
    boolean isSetIsClearable();
    
    /**
     * Sets the "isClearable" element
     */
    void setIsClearable(boolean isClearable);
    
    /**
     * Sets (as xml) the "isClearable" element
     */
    void xsetIsClearable(org.apache.xmlbeans.XmlBoolean isClearable);
    
    /**
     * Unsets the "isClearable" element
     */
    void unsetIsClearable();
    
    /**
     * Gets the "aliasNameList" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNameList();
    
    /**
     * True if has "aliasNameList" element
     */
    boolean isSetAliasNameList();
    
    /**
     * Sets the "aliasNameList" element
     */
    void setAliasNameList(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNameList);
    
    /**
     * Appends and returns a new empty "aliasNameList" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNameList();
    
    /**
     * Unsets the "aliasNameList" element
     */
    void unsetAliasNameList();
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * True if has "layerRate" element
     */
    boolean isSetLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Unsets the "layerRate" element
     */
    void unsetLayerRate();
    
    /**
     * Gets the "probableCause" element
     */
    org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType getProbableCause();
    
    /**
     * True if has "probableCause" element
     */
    boolean isSetProbableCause();
    
    /**
     * Sets the "probableCause" element
     */
    void setProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType probableCause);
    
    /**
     * Appends and returns a new empty "probableCause" element
     */
    org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType addNewProbableCause();
    
    /**
     * Unsets the "probableCause" element
     */
    void unsetProbableCause();
    
    /**
     * Gets the "nativeProbableCause" element
     */
    java.lang.String getNativeProbableCause();
    
    /**
     * Gets (as xml) the "nativeProbableCause" element
     */
    org.apache.xmlbeans.XmlString xgetNativeProbableCause();
    
    /**
     * True if has "nativeProbableCause" element
     */
    boolean isSetNativeProbableCause();
    
    /**
     * Sets the "nativeProbableCause" element
     */
    void setNativeProbableCause(java.lang.String nativeProbableCause);
    
    /**
     * Sets (as xml) the "nativeProbableCause" element
     */
    void xsetNativeProbableCause(org.apache.xmlbeans.XmlString nativeProbableCause);
    
    /**
     * Unsets the "nativeProbableCause" element
     */
    void unsetNativeProbableCause();
    
    /**
     * Gets the "additionalText" element
     */
    java.lang.String getAdditionalText();
    
    /**
     * Gets (as xml) the "additionalText" element
     */
    org.apache.xmlbeans.XmlString xgetAdditionalText();
    
    /**
     * True if has "additionalText" element
     */
    boolean isSetAdditionalText();
    
    /**
     * Sets the "additionalText" element
     */
    void setAdditionalText(java.lang.String additionalText);
    
    /**
     * Sets (as xml) the "additionalText" element
     */
    void xsetAdditionalText(org.apache.xmlbeans.XmlString additionalText);
    
    /**
     * Unsets the "additionalText" element
     */
    void unsetAdditionalText();
    
    /**
     * Gets the "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum getPerceivedSeverity();
    
    /**
     * Gets (as xml) the "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType xgetPerceivedSeverity();
    
    /**
     * True if has "perceivedSeverity" element
     */
    boolean isSetPerceivedSeverity();
    
    /**
     * Sets the "perceivedSeverity" element
     */
    void setPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity);
    
    /**
     * Sets (as xml) the "perceivedSeverity" element
     */
    void xsetPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType perceivedSeverity);
    
    /**
     * Unsets the "perceivedSeverity" element
     */
    void unsetPerceivedSeverity();
    
    /**
     * Gets the "affectedTpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAffectedTpRefList();
    
    /**
     * True if has "affectedTpRefList" element
     */
    boolean isSetAffectedTpRefList();
    
    /**
     * Sets the "affectedTpRefList" element
     */
    void setAffectedTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType affectedTpRefList);
    
    /**
     * Appends and returns a new empty "affectedTpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAffectedTpRefList();
    
    /**
     * Unsets the "affectedTpRefList" element
     */
    void unsetAffectedTpRefList();
    
    /**
     * Gets the "serviceAffecting" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum getServiceAffecting();
    
    /**
     * Gets (as xml) the "serviceAffecting" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType xgetServiceAffecting();
    
    /**
     * True if has "serviceAffecting" element
     */
    boolean isSetServiceAffecting();
    
    /**
     * Sets the "serviceAffecting" element
     */
    void setServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum serviceAffecting);
    
    /**
     * Sets (as xml) the "serviceAffecting" element
     */
    void xsetServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType serviceAffecting);
    
    /**
     * Unsets the "serviceAffecting" element
     */
    void unsetServiceAffecting();
    
    /**
     * Gets the "rootCauseAlarmIndication" element
     */
    boolean getRootCauseAlarmIndication();
    
    /**
     * Gets (as xml) the "rootCauseAlarmIndication" element
     */
    org.apache.xmlbeans.XmlBoolean xgetRootCauseAlarmIndication();
    
    /**
     * True if has "rootCauseAlarmIndication" element
     */
    boolean isSetRootCauseAlarmIndication();
    
    /**
     * Sets the "rootCauseAlarmIndication" element
     */
    void setRootCauseAlarmIndication(boolean rootCauseAlarmIndication);
    
    /**
     * Sets (as xml) the "rootCauseAlarmIndication" element
     */
    void xsetRootCauseAlarmIndication(org.apache.xmlbeans.XmlBoolean rootCauseAlarmIndication);
    
    /**
     * Unsets the "rootCauseAlarmIndication" element
     */
    void unsetRootCauseAlarmIndication();
    
    /**
     * Gets the "acknowledgement" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum getAcknowledgement();
    
    /**
     * Gets (as xml) the "acknowledgement" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType xgetAcknowledgement();
    
    /**
     * True if has "acknowledgement" element
     */
    boolean isSetAcknowledgement();
    
    /**
     * Sets the "acknowledgement" element
     */
    void setAcknowledgement(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum acknowledgement);
    
    /**
     * Sets (as xml) the "acknowledgement" element
     */
    void xsetAcknowledgement(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType acknowledgement);
    
    /**
     * Unsets the "acknowledgement" element
     */
    void unsetAcknowledgement();
    
    /**
     * Gets the "X733_EventType" element
     */
    java.lang.String getX733EventType();
    
    /**
     * Gets (as xml) the "X733_EventType" element
     */
    org.apache.xmlbeans.XmlString xgetX733EventType();
    
    /**
     * True if has "X733_EventType" element
     */
    boolean isSetX733EventType();
    
    /**
     * Sets the "X733_EventType" element
     */
    void setX733EventType(java.lang.String x733EventType);
    
    /**
     * Sets (as xml) the "X733_EventType" element
     */
    void xsetX733EventType(org.apache.xmlbeans.XmlString x733EventType);
    
    /**
     * Unsets the "X733_EventType" element
     */
    void unsetX733EventType();
    
    /**
     * Gets the "X733_SpecificProblems" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType getX733SpecificProblems();
    
    /**
     * True if has "X733_SpecificProblems" element
     */
    boolean isSetX733SpecificProblems();
    
    /**
     * Sets the "X733_SpecificProblems" element
     */
    void setX733SpecificProblems(org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType x733SpecificProblems);
    
    /**
     * Appends and returns a new empty "X733_SpecificProblems" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType addNewX733SpecificProblems();
    
    /**
     * Unsets the "X733_SpecificProblems" element
     */
    void unsetX733SpecificProblems();
    
    /**
     * Gets the "X733_BackedUpStatus" element
     */
    java.lang.String getX733BackedUpStatus();
    
    /**
     * Gets (as xml) the "X733_BackedUpStatus" element
     */
    org.apache.xmlbeans.XmlString xgetX733BackedUpStatus();
    
    /**
     * True if has "X733_BackedUpStatus" element
     */
    boolean isSetX733BackedUpStatus();
    
    /**
     * Sets the "X733_BackedUpStatus" element
     */
    void setX733BackedUpStatus(java.lang.String x733BackedUpStatus);
    
    /**
     * Sets (as xml) the "X733_BackedUpStatus" element
     */
    void xsetX733BackedUpStatus(org.apache.xmlbeans.XmlString x733BackedUpStatus);
    
    /**
     * Unsets the "X733_BackedUpStatus" element
     */
    void unsetX733BackedUpStatus();
    
    /**
     * Gets the "X733_BackUpObjectRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getX733BackUpObjectRef();
    
    /**
     * True if has "X733_BackUpObjectRef" element
     */
    boolean isSetX733BackUpObjectRef();
    
    /**
     * Sets the "X733_BackUpObjectRef" element
     */
    void setX733BackUpObjectRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType x733BackUpObjectRef);
    
    /**
     * Appends and returns a new empty "X733_BackUpObjectRef" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewX733BackUpObjectRef();
    
    /**
     * Unsets the "X733_BackUpObjectRef" element
     */
    void unsetX733BackUpObjectRef();
    
    /**
     * Gets the "X733_TrendIndication" element
     */
    java.lang.String getX733TrendIndication();
    
    /**
     * Gets (as xml) the "X733_TrendIndication" element
     */
    org.apache.xmlbeans.XmlString xgetX733TrendIndication();
    
    /**
     * True if has "X733_TrendIndication" element
     */
    boolean isSetX733TrendIndication();
    
    /**
     * Sets the "X733_TrendIndication" element
     */
    void setX733TrendIndication(java.lang.String x733TrendIndication);
    
    /**
     * Sets (as xml) the "X733_TrendIndication" element
     */
    void xsetX733TrendIndication(org.apache.xmlbeans.XmlString x733TrendIndication);
    
    /**
     * Unsets the "X733_TrendIndication" element
     */
    void unsetX733TrendIndication();
    
    /**
     * Gets the "X733_CorrelatedNotificationList" element
     */
    org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType getX733CorrelatedNotificationList();
    
    /**
     * True if has "X733_CorrelatedNotificationList" element
     */
    boolean isSetX733CorrelatedNotificationList();
    
    /**
     * Sets the "X733_CorrelatedNotificationList" element
     */
    void setX733CorrelatedNotificationList(org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType x733CorrelatedNotificationList);
    
    /**
     * Appends and returns a new empty "X733_CorrelatedNotificationList" element
     */
    org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType addNewX733CorrelatedNotificationList();
    
    /**
     * Unsets the "X733_CorrelatedNotificationList" element
     */
    void unsetX733CorrelatedNotificationList();
    
    /**
     * Gets the "X733_MonitoredAttributeList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType getX733MonitoredAttributeList();
    
    /**
     * True if has "X733_MonitoredAttributeList" element
     */
    boolean isSetX733MonitoredAttributeList();
    
    /**
     * Sets the "X733_MonitoredAttributeList" element
     */
    void setX733MonitoredAttributeList(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType x733MonitoredAttributeList);
    
    /**
     * Appends and returns a new empty "X733_MonitoredAttributeList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType addNewX733MonitoredAttributeList();
    
    /**
     * Unsets the "X733_MonitoredAttributeList" element
     */
    void unsetX733MonitoredAttributeList();
    
    /**
     * Gets the "X733_ProposedRepairActionList" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType getX733ProposedRepairActionList();
    
    /**
     * True if has "X733_ProposedRepairActionList" element
     */
    boolean isSetX733ProposedRepairActionList();
    
    /**
     * Sets the "X733_ProposedRepairActionList" element
     */
    void setX733ProposedRepairActionList(org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType x733ProposedRepairActionList);
    
    /**
     * Appends and returns a new empty "X733_ProposedRepairActionList" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType addNewX733ProposedRepairActionList();
    
    /**
     * Unsets the "X733_ProposedRepairActionList" element
     */
    void unsetX733ProposedRepairActionList();
    
    /**
     * Gets the "X733_AdditionalInformation" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType getX733AdditionalInformation();
    
    /**
     * True if has "X733_AdditionalInformation" element
     */
    boolean isSetX733AdditionalInformation();
    
    /**
     * Sets the "X733_AdditionalInformation" element
     */
    void setX733AdditionalInformation(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType x733AdditionalInformation);
    
    /**
     * Appends and returns a new empty "X733_AdditionalInformation" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType addNewX733AdditionalInformation();
    
    /**
     * Unsets the "X733_AdditionalInformation" element
     */
    void unsetX733AdditionalInformation();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType newInstance() {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
