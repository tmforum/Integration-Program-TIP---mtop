/*
 * XML Type:  PmParameterListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmpar/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmpar.v1.impl;
/**
 * An XML PmParameterListType(@http://www.tmforum.org/mtop/nra/xsd/pmpar/v1).
 *
 * This is a complex type.
 */
public class PmParameterListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType
{
    
    public PmParameterListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETER$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmpar/v1", "pmParameter");
    
    
    /**
     * Gets a List of "pmParameter" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType> getPmParameterList()
    {
        final class PmParameterList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType>
        {
            public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType get(int i)
                { return PmParameterListTypeImpl.this.getPmParameterArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType set(int i, org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType o)
            {
                org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType old = PmParameterListTypeImpl.this.getPmParameterArray(i);
                PmParameterListTypeImpl.this.setPmParameterArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType o)
                { PmParameterListTypeImpl.this.insertNewPmParameter(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType old = PmParameterListTypeImpl.this.getPmParameterArray(i);
                PmParameterListTypeImpl.this.removePmParameter(i);
                return old;
            }
            
            public int size()
                { return PmParameterListTypeImpl.this.sizeOfPmParameterArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmParameterList();
        }
    }
    
    /**
     * Gets array of all "pmParameter" elements
     */
    public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType[] getPmParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMPARAMETER$0, targetList);
            org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType[] result = new org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pmParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType getPmParameterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType)get_store().find_element_user(PMPARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pmParameter" element
     */
    public int sizeOfPmParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETER$0);
        }
    }
    
    /**
     * Sets array of all "pmParameter" element
     */
    public void setPmParameterArray(org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType[] pmParameterArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmParameterArray, PMPARAMETER$0);
        }
    }
    
    /**
     * Sets ith "pmParameter" element
     */
    public void setPmParameterArray(int i, org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType pmParameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType)get_store().find_element_user(PMPARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmParameter);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType insertNewPmParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType)get_store().insert_element_user(PMPARAMETER$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType addNewPmParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType)get_store().add_element_user(PMPARAMETER$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmParameter" element
     */
    public void removePmParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETER$0, i);
        }
    }
}
