/*
 * XML Type:  ProtectionSwitchListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/ps/v1
 * Java type: org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.ps.v1.impl;
/**
 * An XML ProtectionSwitchListType(@http://www.tmforum.org/mtop/nra/xsd/ps/v1).
 *
 * This is a complex type.
 */
public class ProtectionSwitchListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchListType
{
    
    public ProtectionSwitchListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROTECTIONSWITCH$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/ps/v1", "protectionSwitch");
    
    
    /**
     * Gets a List of "protectionSwitch" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType> getProtectionSwitchList()
    {
        final class ProtectionSwitchList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType>
        {
            public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType get(int i)
                { return ProtectionSwitchListTypeImpl.this.getProtectionSwitchArray(i); }
            
            public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType set(int i, org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType o)
            {
                org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType old = ProtectionSwitchListTypeImpl.this.getProtectionSwitchArray(i);
                ProtectionSwitchListTypeImpl.this.setProtectionSwitchArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType o)
                { ProtectionSwitchListTypeImpl.this.insertNewProtectionSwitch(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType old = ProtectionSwitchListTypeImpl.this.getProtectionSwitchArray(i);
                ProtectionSwitchListTypeImpl.this.removeProtectionSwitch(i);
                return old;
            }
            
            public int size()
                { return ProtectionSwitchListTypeImpl.this.sizeOfProtectionSwitchArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ProtectionSwitchList();
        }
    }
    
    /**
     * Gets array of all "protectionSwitch" elements
     */
    public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType[] getProtectionSwitchArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PROTECTIONSWITCH$0, targetList);
            org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType[] result = new org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "protectionSwitch" element
     */
    public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType getProtectionSwitchArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType)get_store().find_element_user(PROTECTIONSWITCH$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "protectionSwitch" element
     */
    public int sizeOfProtectionSwitchArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONSWITCH$0);
        }
    }
    
    /**
     * Sets array of all "protectionSwitch" element
     */
    public void setProtectionSwitchArray(org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType[] protectionSwitchArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(protectionSwitchArray, PROTECTIONSWITCH$0);
        }
    }
    
    /**
     * Sets ith "protectionSwitch" element
     */
    public void setProtectionSwitchArray(int i, org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType protectionSwitch)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType)get_store().find_element_user(PROTECTIONSWITCH$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(protectionSwitch);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "protectionSwitch" element
     */
    public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType insertNewProtectionSwitch(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType)get_store().insert_element_user(PROTECTIONSWITCH$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "protectionSwitch" element
     */
    public org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType addNewProtectionSwitch()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType target = null;
            target = (org.tmforum.mtop.nra.xsd.ps.v1.ProtectionSwitchType)get_store().add_element_user(PROTECTIONSWITCH$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "protectionSwitch" element
     */
    public void removeProtectionSwitch(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONSWITCH$0, i);
        }
    }
}
