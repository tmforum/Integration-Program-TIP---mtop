/*
 * XML Type:  AlarmListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alm/v1
 * Java type: org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alm.v1.impl;
/**
 * An XML AlarmListType(@http://www.tmforum.org/mtop/nra/xsd/alm/v1).
 *
 * This is a complex type.
 */
public class AlarmListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType
{
    
    public AlarmListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "alarm");
    
    
    /**
     * Gets a List of "alarm" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.alm.v1.AlarmType> getAlarmList()
    {
        final class AlarmList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.alm.v1.AlarmType>
        {
            public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType get(int i)
                { return AlarmListTypeImpl.this.getAlarmArray(i); }
            
            public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType set(int i, org.tmforum.mtop.nra.xsd.alm.v1.AlarmType o)
            {
                org.tmforum.mtop.nra.xsd.alm.v1.AlarmType old = AlarmListTypeImpl.this.getAlarmArray(i);
                AlarmListTypeImpl.this.setAlarmArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.alm.v1.AlarmType o)
                { AlarmListTypeImpl.this.insertNewAlarm(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.alm.v1.AlarmType old = AlarmListTypeImpl.this.getAlarmArray(i);
                AlarmListTypeImpl.this.removeAlarm(i);
                return old;
            }
            
            public int size()
                { return AlarmListTypeImpl.this.sizeOfAlarmArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new AlarmList();
        }
    }
    
    /**
     * Gets array of all "alarm" elements
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType[] getAlarmArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ALARM$0, targetList);
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmType[] result = new org.tmforum.mtop.nra.xsd.alm.v1.AlarmType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "alarm" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType getAlarmArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType)get_store().find_element_user(ALARM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "alarm" element
     */
    public int sizeOfAlarmArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARM$0);
        }
    }
    
    /**
     * Sets array of all "alarm" element
     */
    public void setAlarmArray(org.tmforum.mtop.nra.xsd.alm.v1.AlarmType[] alarmArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(alarmArray, ALARM$0);
        }
    }
    
    /**
     * Sets ith "alarm" element
     */
    public void setAlarmArray(int i, org.tmforum.mtop.nra.xsd.alm.v1.AlarmType alarm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType)get_store().find_element_user(ALARM$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(alarm);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "alarm" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType insertNewAlarm(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType)get_store().insert_element_user(ALARM$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "alarm" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType addNewAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType)get_store().add_element_user(ALARM$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "alarm" element
     */
    public void removeAlarm(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARM$0, i);
        }
    }
}
