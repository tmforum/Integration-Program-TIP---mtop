/*
 * XML Type:  M3100.ArcQIStatusType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1.impl;
/**
 * An XML M3100.ArcQIStatusType(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType.
 */
public class M3100ArcQIStatusTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType
{
    
    public M3100ArcQIStatusTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected M3100ArcQIStatusTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
