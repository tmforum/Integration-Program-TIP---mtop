/*
 * An XML document type.
 * Localname: pmThresholdValue
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmtv/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmtv.v1.impl;
/**
 * A document containing one pmThresholdValue(@http://www.tmforum.org/mtop/nra/xsd/pmtv/v1) element.
 *
 * This is a complex type.
 */
public class PmThresholdValueDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueDocument
{
    
    public PmThresholdValueDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMTHRESHOLDVALUE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtv/v1", "pmThresholdValue");
    
    
    /**
     * Gets the "pmThresholdValue" element
     */
    public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType getPmThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType)get_store().find_element_user(PMTHRESHOLDVALUE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pmThresholdValue" element
     */
    public void setPmThresholdValue(org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType pmThresholdValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType)get_store().find_element_user(PMTHRESHOLDVALUE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType)get_store().add_element_user(PMTHRESHOLDVALUE$0);
            }
            target.set(pmThresholdValue);
        }
    }
    
    /**
     * Appends and returns a new empty "pmThresholdValue" element
     */
    public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType addNewPmThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType)get_store().add_element_user(PMTHRESHOLDVALUE$0);
            return target;
        }
    }
}
