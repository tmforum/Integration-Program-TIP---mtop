/*
 * An XML document type.
 * Localname: thresholdCrossingAlert
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tca/v1
 * Java type: org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tca.v1.impl;
/**
 * A document containing one thresholdCrossingAlert(@http://www.tmforum.org/mtop/nra/xsd/tca/v1) element.
 *
 * This is a complex type.
 */
public class ThresholdCrossingAlertDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument
{
    
    public ThresholdCrossingAlertDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName THRESHOLDCROSSINGALERT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tca/v1", "thresholdCrossingAlert");
    
    
    /**
     * Gets the "thresholdCrossingAlert" element
     */
    public org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType getThresholdCrossingAlert()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType target = null;
            target = (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType)get_store().find_element_user(THRESHOLDCROSSINGALERT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "thresholdCrossingAlert" element
     */
    public void setThresholdCrossingAlert(org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType thresholdCrossingAlert)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType target = null;
            target = (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType)get_store().find_element_user(THRESHOLDCROSSINGALERT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType)get_store().add_element_user(THRESHOLDCROSSINGALERT$0);
            }
            target.set(thresholdCrossingAlert);
        }
    }
    
    /**
     * Appends and returns a new empty "thresholdCrossingAlert" element
     */
    public org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType addNewThresholdCrossingAlert()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType target = null;
            target = (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType)get_store().add_element_user(THRESHOLDCROSSINGALERT$0);
            return target;
        }
    }
}
