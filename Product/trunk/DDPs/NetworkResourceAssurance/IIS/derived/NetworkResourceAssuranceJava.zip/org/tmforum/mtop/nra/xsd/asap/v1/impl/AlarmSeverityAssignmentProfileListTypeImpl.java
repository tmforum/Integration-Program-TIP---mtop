/*
 * XML Type:  AlarmSeverityAssignmentProfileListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/asap/v1
 * Java type: org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.asap.v1.impl;
/**
 * An XML AlarmSeverityAssignmentProfileListType(@http://www.tmforum.org/mtop/nra/xsd/asap/v1).
 *
 * This is a complex type.
 */
public class AlarmSeverityAssignmentProfileListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType
{
    
    public AlarmSeverityAssignmentProfileListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASAP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asap/v1", "asap");
    
    
    /**
     * Gets a List of "asap" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType> getAsapList()
    {
        final class AsapList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType>
        {
            public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType get(int i)
                { return AlarmSeverityAssignmentProfileListTypeImpl.this.getAsapArray(i); }
            
            public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType set(int i, org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType o)
            {
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType old = AlarmSeverityAssignmentProfileListTypeImpl.this.getAsapArray(i);
                AlarmSeverityAssignmentProfileListTypeImpl.this.setAsapArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType o)
                { AlarmSeverityAssignmentProfileListTypeImpl.this.insertNewAsap(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType old = AlarmSeverityAssignmentProfileListTypeImpl.this.getAsapArray(i);
                AlarmSeverityAssignmentProfileListTypeImpl.this.removeAsap(i);
                return old;
            }
            
            public int size()
                { return AlarmSeverityAssignmentProfileListTypeImpl.this.sizeOfAsapArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new AsapList();
        }
    }
    
    /**
     * Gets array of all "asap" elements
     */
    public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType[] getAsapArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ASAP$0, targetList);
            org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType[] result = new org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "asap" element
     */
    public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType getAsapArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "asap" element
     */
    public int sizeOfAsapArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAP$0);
        }
    }
    
    /**
     * Sets array of all "asap" element
     */
    public void setAsapArray(org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType[] asapArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(asapArray, ASAP$0);
        }
    }
    
    /**
     * Sets ith "asap" element
     */
    public void setAsapArray(int i, org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType asap)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(asap);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "asap" element
     */
    public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType insertNewAsap(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().insert_element_user(ASAP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "asap" element
     */
    public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType addNewAsap()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(ASAP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "asap" element
     */
    public void removeAsap(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAP$0, i);
        }
    }
}
