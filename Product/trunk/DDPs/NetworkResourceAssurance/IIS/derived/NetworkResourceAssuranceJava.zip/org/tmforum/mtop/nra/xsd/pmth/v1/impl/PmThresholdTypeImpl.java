/*
 * XML Type:  PmThresholdType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmth/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmth.v1.impl;
/**
 * An XML PmThresholdType(@http://www.tmforum.org/mtop/nra/xsd/pmth/v1).
 *
 * This is a complex type.
 */
public class PmThresholdTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType
{
    
    public PmThresholdTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName THRESHOLDTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmth/v1", "thresholdType");
    private static final javax.xml.namespace.QName TRIGGER$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmth/v1", "trigger");
    private static final javax.xml.namespace.QName THRESHOLDVALUE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmth/v1", "thresholdValue");
    private static final javax.xml.namespace.QName THRESHOLDUNIT$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmth/v1", "thresholdUnit");
    
    
    /**
     * Gets the "thresholdType" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType.Enum getThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "thresholdType" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType xgetThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().find_element_user(THRESHOLDTYPE$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "thresholdType" element
     */
    public boolean isNilThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().find_element_user(THRESHOLDTYPE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "thresholdType" element
     */
    public boolean isSetThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(THRESHOLDTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "thresholdType" element
     */
    public void setThresholdType(org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType.Enum thresholdType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDTYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(THRESHOLDTYPE$0);
            }
            target.setEnumValue(thresholdType);
        }
    }
    
    /**
     * Sets (as xml) the "thresholdType" element
     */
    public void xsetThresholdType(org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType thresholdType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().find_element_user(THRESHOLDTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().add_element_user(THRESHOLDTYPE$0);
            }
            target.set(thresholdType);
        }
    }
    
    /**
     * Nils the "thresholdType" element
     */
    public void setNilThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().find_element_user(THRESHOLDTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType)get_store().add_element_user(THRESHOLDTYPE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "thresholdType" element
     */
    public void unsetThresholdType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(THRESHOLDTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "trigger" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.TriggerType.Enum getTrigger()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRIGGER$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.TriggerType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "trigger" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.TriggerType xgetTrigger()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.TriggerType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.TriggerType)get_store().find_element_user(TRIGGER$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "trigger" element
     */
    public boolean isNilTrigger()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.TriggerType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.TriggerType)get_store().find_element_user(TRIGGER$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "trigger" element
     */
    public boolean isSetTrigger()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TRIGGER$2) != 0;
        }
    }
    
    /**
     * Sets the "trigger" element
     */
    public void setTrigger(org.tmforum.mtop.nra.xsd.pm.v1.TriggerType.Enum trigger)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TRIGGER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TRIGGER$2);
            }
            target.setEnumValue(trigger);
        }
    }
    
    /**
     * Sets (as xml) the "trigger" element
     */
    public void xsetTrigger(org.tmforum.mtop.nra.xsd.pm.v1.TriggerType trigger)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.TriggerType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.TriggerType)get_store().find_element_user(TRIGGER$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.TriggerType)get_store().add_element_user(TRIGGER$2);
            }
            target.set(trigger);
        }
    }
    
    /**
     * Nils the "trigger" element
     */
    public void setNilTrigger()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.TriggerType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.TriggerType)get_store().find_element_user(TRIGGER$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.TriggerType)get_store().add_element_user(TRIGGER$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "trigger" element
     */
    public void unsetTrigger()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TRIGGER$2, 0);
        }
    }
    
    /**
     * Gets the "thresholdValue" element
     */
    public float getThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDVALUE$4, 0);
            if (target == null)
            {
                return 0.0f;
            }
            return target.getFloatValue();
        }
    }
    
    /**
     * Gets (as xml) the "thresholdValue" element
     */
    public org.apache.xmlbeans.XmlFloat xgetThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(THRESHOLDVALUE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "thresholdValue" element
     */
    public boolean isNilThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(THRESHOLDVALUE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "thresholdValue" element
     */
    public boolean isSetThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(THRESHOLDVALUE$4) != 0;
        }
    }
    
    /**
     * Sets the "thresholdValue" element
     */
    public void setThresholdValue(float thresholdValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDVALUE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(THRESHOLDVALUE$4);
            }
            target.setFloatValue(thresholdValue);
        }
    }
    
    /**
     * Sets (as xml) the "thresholdValue" element
     */
    public void xsetThresholdValue(org.apache.xmlbeans.XmlFloat thresholdValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(THRESHOLDVALUE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlFloat)get_store().add_element_user(THRESHOLDVALUE$4);
            }
            target.set(thresholdValue);
        }
    }
    
    /**
     * Nils the "thresholdValue" element
     */
    public void setNilThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(THRESHOLDVALUE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlFloat)get_store().add_element_user(THRESHOLDVALUE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "thresholdValue" element
     */
    public void unsetThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(THRESHOLDVALUE$4, 0);
        }
    }
    
    /**
     * Gets the "thresholdUnit" element
     */
    public java.lang.String getThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDUNIT$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "thresholdUnit" element
     */
    public org.apache.xmlbeans.XmlString xgetThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(THRESHOLDUNIT$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "thresholdUnit" element
     */
    public boolean isNilThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(THRESHOLDUNIT$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "thresholdUnit" element
     */
    public boolean isSetThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(THRESHOLDUNIT$6) != 0;
        }
    }
    
    /**
     * Sets the "thresholdUnit" element
     */
    public void setThresholdUnit(java.lang.String thresholdUnit)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(THRESHOLDUNIT$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(THRESHOLDUNIT$6);
            }
            target.setStringValue(thresholdUnit);
        }
    }
    
    /**
     * Sets (as xml) the "thresholdUnit" element
     */
    public void xsetThresholdUnit(org.apache.xmlbeans.XmlString thresholdUnit)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(THRESHOLDUNIT$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(THRESHOLDUNIT$6);
            }
            target.set(thresholdUnit);
        }
    }
    
    /**
     * Nils the "thresholdUnit" element
     */
    public void setNilThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(THRESHOLDUNIT$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(THRESHOLDUNIT$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "thresholdUnit" element
     */
    public void unsetThresholdUnit()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(THRESHOLDUNIT$6, 0);
        }
    }
}
