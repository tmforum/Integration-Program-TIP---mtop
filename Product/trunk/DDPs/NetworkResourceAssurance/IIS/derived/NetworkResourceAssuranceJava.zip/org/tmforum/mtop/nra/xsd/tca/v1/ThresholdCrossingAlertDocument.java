/*
 * An XML document type.
 * Localname: thresholdCrossingAlert
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tca/v1
 * Java type: org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tca.v1;


/**
 * A document containing one thresholdCrossingAlert(@http://www.tmforum.org/mtop/nra/xsd/tca/v1) element.
 *
 * This is a complex type.
 */
public interface ThresholdCrossingAlertDocument extends org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationDocument
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ThresholdCrossingAlertDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("thresholdcrossingalert7d95doctype");
    
    /**
     * Gets the "thresholdCrossingAlert" element
     */
    org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType getThresholdCrossingAlert();
    
    /**
     * Sets the "thresholdCrossingAlert" element
     */
    void setThresholdCrossingAlert(org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType thresholdCrossingAlert);
    
    /**
     * Appends and returns a new empty "thresholdCrossingAlert" element
     */
    org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType addNewThresholdCrossingAlert();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument newInstance() {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
