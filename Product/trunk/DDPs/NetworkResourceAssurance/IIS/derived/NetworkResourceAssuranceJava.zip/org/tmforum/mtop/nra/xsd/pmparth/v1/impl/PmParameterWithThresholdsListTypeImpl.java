/*
 * XML Type:  PmParameterWithThresholdsListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmparth/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmparth.v1.impl;
/**
 * An XML PmParameterWithThresholdsListType(@http://www.tmforum.org/mtop/nra/xsd/pmparth/v1).
 *
 * This is a complex type.
 */
public class PmParameterWithThresholdsListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsListType
{
    
    public PmParameterWithThresholdsListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETERWITHTHRESHOLD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmparth/v1", "pmParameterWithThreshold");
    
    
    /**
     * Gets a List of "pmParameterWithThreshold" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType> getPmParameterWithThresholdList()
    {
        final class PmParameterWithThresholdList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType>
        {
            public org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType get(int i)
                { return PmParameterWithThresholdsListTypeImpl.this.getPmParameterWithThresholdArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType set(int i, org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType o)
            {
                org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType old = PmParameterWithThresholdsListTypeImpl.this.getPmParameterWithThresholdArray(i);
                PmParameterWithThresholdsListTypeImpl.this.setPmParameterWithThresholdArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType o)
                { PmParameterWithThresholdsListTypeImpl.this.insertNewPmParameterWithThreshold(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType old = PmParameterWithThresholdsListTypeImpl.this.getPmParameterWithThresholdArray(i);
                PmParameterWithThresholdsListTypeImpl.this.removePmParameterWithThreshold(i);
                return old;
            }
            
            public int size()
                { return PmParameterWithThresholdsListTypeImpl.this.sizeOfPmParameterWithThresholdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmParameterWithThresholdList();
        }
    }
    
    /**
     * Gets array of all "pmParameterWithThreshold" elements
     */
    public org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType[] getPmParameterWithThresholdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMPARAMETERWITHTHRESHOLD$0, targetList);
            org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType[] result = new org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pmParameterWithThreshold" element
     */
    public org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType getPmParameterWithThresholdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType)get_store().find_element_user(PMPARAMETERWITHTHRESHOLD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pmParameterWithThreshold" element
     */
    public int sizeOfPmParameterWithThresholdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETERWITHTHRESHOLD$0);
        }
    }
    
    /**
     * Sets array of all "pmParameterWithThreshold" element
     */
    public void setPmParameterWithThresholdArray(org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType[] pmParameterWithThresholdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmParameterWithThresholdArray, PMPARAMETERWITHTHRESHOLD$0);
        }
    }
    
    /**
     * Sets ith "pmParameterWithThreshold" element
     */
    public void setPmParameterWithThresholdArray(int i, org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType pmParameterWithThreshold)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType)get_store().find_element_user(PMPARAMETERWITHTHRESHOLD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmParameterWithThreshold);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmParameterWithThreshold" element
     */
    public org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType insertNewPmParameterWithThreshold(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType)get_store().insert_element_user(PMPARAMETERWITHTHRESHOLD$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmParameterWithThreshold" element
     */
    public org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType addNewPmParameterWithThreshold()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmparth.v1.PmParameterWithThresholdsType)get_store().add_element_user(PMPARAMETERWITHTHRESHOLD$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmParameterWithThreshold" element
     */
    public void removePmParameterWithThreshold(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETERWITHTHRESHOLD$0, i);
        }
    }
}
