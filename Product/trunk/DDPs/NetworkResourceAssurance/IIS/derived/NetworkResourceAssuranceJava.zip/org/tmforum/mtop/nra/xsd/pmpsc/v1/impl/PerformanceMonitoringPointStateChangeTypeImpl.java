/*
 * XML Type:  PerformanceMonitoringPointStateChangeType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmpsc.v1.impl;
/**
 * An XML PerformanceMonitoringPointStateChangeType(@http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1).
 *
 * This is a complex type.
 */
public class PerformanceMonitoringPointStateChangeTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationTypeImpl implements org.tmforum.mtop.nra.xsd.pmpsc.v1.PerformanceMonitoringPointStateChangeType
{
    
    public PerformanceMonitoringPointStateChangeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMNAMELIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1", "pmNameList");
    private static final javax.xml.namespace.QName ATTRIBUTELIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmpsc/v1", "attributeList");
    
    
    /**
     * Gets the "pmNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getPmNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PMNAMELIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pmNameList" element
     */
    public void setPmNameList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType pmNameList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PMNAMELIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PMNAMELIST$0);
            }
            target.set(pmNameList);
        }
    }
    
    /**
     * Appends and returns a new empty "pmNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewPmNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PMNAMELIST$0);
            return target;
        }
    }
    
    /**
     * Gets the "attributeList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(ATTRIBUTELIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "attributeList" element
     */
    public boolean isSetAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ATTRIBUTELIST$2) != 0;
        }
    }
    
    /**
     * Sets the "attributeList" element
     */
    public void setAttributeList(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType attributeList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(ATTRIBUTELIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(ATTRIBUTELIST$2);
            }
            target.set(attributeList);
        }
    }
    
    /**
     * Appends and returns a new empty "attributeList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(ATTRIBUTELIST$2);
            return target;
        }
    }
    
    /**
     * Unsets the "attributeList" element
     */
    public void unsetAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ATTRIBUTELIST$2, 0);
        }
    }
}
