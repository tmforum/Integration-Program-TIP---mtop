/*
 * XML Type:  EquipmentProtectionSwitchType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/eps/v1
 * Java type: org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.eps.v1.impl;
/**
 * An XML EquipmentProtectionSwitchType(@http://www.tmforum.org/mtop/nra/xsd/eps/v1).
 *
 * This is a complex type.
 */
public class EquipmentProtectionSwitchTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationTypeImpl implements org.tmforum.mtop.nra.xsd.eps.v1.EquipmentProtectionSwitchType
{
    
    public EquipmentProtectionSwitchTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OSTIME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/eps/v1", "osTime");
    private static final javax.xml.namespace.QName EPGTYPE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/eps/v1", "epgType");
    private static final javax.xml.namespace.QName EQUIPMENTSWITCHREASON$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/eps/v1", "equipmentSwitchReason");
    private static final javax.xml.namespace.QName EPGREF$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/eps/v1", "epgRef");
    private static final javax.xml.namespace.QName PROTECTEDEQUIPMENTREF$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/eps/v1", "protectedEquipmentRef");
    private static final javax.xml.namespace.QName SWITCHAWAYFROMEQUIPMENTREF$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/eps/v1", "switchAwayFromEquipmentRef");
    private static final javax.xml.namespace.QName SWITCHTOEQUIPMENTREF$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/eps/v1", "switchToEquipmentRef");
    
    
    /**
     * Gets the "osTime" element
     */
    public java.util.Calendar getOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSTIME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "osTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(OSTIME$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "osTime" element
     */
    public boolean isSetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OSTIME$0) != 0;
        }
    }
    
    /**
     * Sets the "osTime" element
     */
    public void setOsTime(java.util.Calendar osTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OSTIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OSTIME$0);
            }
            target.setCalendarValue(osTime);
        }
    }
    
    /**
     * Sets (as xml) the "osTime" element
     */
    public void xsetOsTime(org.apache.xmlbeans.XmlDateTime osTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(OSTIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(OSTIME$0);
            }
            target.set(osTime);
        }
    }
    
    /**
     * Unsets the "osTime" element
     */
    public void unsetOsTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OSTIME$0, 0);
        }
    }
    
    /**
     * Gets the "epgType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType getEpgType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EPGTYPE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "epgType" element
     */
    public boolean isSetEpgType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGTYPE$2) != 0;
        }
    }
    
    /**
     * Sets the "epgType" element
     */
    public void setEpgType(org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType epgType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EPGTYPE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EPGTYPE$2);
            }
            target.set(epgType);
        }
    }
    
    /**
     * Appends and returns a new empty "epgType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType addNewEpgType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EPGTYPE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "epgType" element
     */
    public void unsetEpgType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGTYPE$2, 0);
        }
    }
    
    /**
     * Gets the "equipmentSwitchReason" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType getEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().find_element_user(EQUIPMENTSWITCHREASON$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "equipmentSwitchReason" element
     */
    public boolean isSetEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQUIPMENTSWITCHREASON$4) != 0;
        }
    }
    
    /**
     * Sets the "equipmentSwitchReason" element
     */
    public void setEquipmentSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType equipmentSwitchReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().find_element_user(EQUIPMENTSWITCHREASON$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().add_element_user(EQUIPMENTSWITCHREASON$4);
            }
            target.set(equipmentSwitchReason);
        }
    }
    
    /**
     * Appends and returns a new empty "equipmentSwitchReason" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType addNewEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().add_element_user(EQUIPMENTSWITCHREASON$4);
            return target;
        }
    }
    
    /**
     * Unsets the "equipmentSwitchReason" element
     */
    public void unsetEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQUIPMENTSWITCHREASON$4, 0);
        }
    }
    
    /**
     * Gets the "epgRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEpgRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EPGREF$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "epgRef" element
     */
    public boolean isSetEpgRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGREF$6) != 0;
        }
    }
    
    /**
     * Sets the "epgRef" element
     */
    public void setEpgRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType epgRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EPGREF$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EPGREF$6);
            }
            target.set(epgRef);
        }
    }
    
    /**
     * Appends and returns a new empty "epgRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEpgRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EPGREF$6);
            return target;
        }
    }
    
    /**
     * Unsets the "epgRef" element
     */
    public void unsetEpgRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGREF$6, 0);
        }
    }
    
    /**
     * Gets the "protectedEquipmentRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProtectedEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PROTECTEDEQUIPMENTREF$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "protectedEquipmentRef" element
     */
    public boolean isSetProtectedEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTEDEQUIPMENTREF$8) != 0;
        }
    }
    
    /**
     * Sets the "protectedEquipmentRef" element
     */
    public void setProtectedEquipmentRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType protectedEquipmentRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PROTECTEDEQUIPMENTREF$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PROTECTEDEQUIPMENTREF$8);
            }
            target.set(protectedEquipmentRef);
        }
    }
    
    /**
     * Appends and returns a new empty "protectedEquipmentRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProtectedEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PROTECTEDEQUIPMENTREF$8);
            return target;
        }
    }
    
    /**
     * Unsets the "protectedEquipmentRef" element
     */
    public void unsetProtectedEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTEDEQUIPMENTREF$8, 0);
        }
    }
    
    /**
     * Gets the "switchAwayFromEquipmentRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchAwayFromEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SWITCHAWAYFROMEQUIPMENTREF$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "switchAwayFromEquipmentRef" element
     */
    public boolean isSetSwitchAwayFromEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHAWAYFROMEQUIPMENTREF$10) != 0;
        }
    }
    
    /**
     * Sets the "switchAwayFromEquipmentRef" element
     */
    public void setSwitchAwayFromEquipmentRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchAwayFromEquipmentRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SWITCHAWAYFROMEQUIPMENTREF$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SWITCHAWAYFROMEQUIPMENTREF$10);
            }
            target.set(switchAwayFromEquipmentRef);
        }
    }
    
    /**
     * Appends and returns a new empty "switchAwayFromEquipmentRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchAwayFromEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SWITCHAWAYFROMEQUIPMENTREF$10);
            return target;
        }
    }
    
    /**
     * Unsets the "switchAwayFromEquipmentRef" element
     */
    public void unsetSwitchAwayFromEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHAWAYFROMEQUIPMENTREF$10, 0);
        }
    }
    
    /**
     * Gets the "switchToEquipmentRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchToEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SWITCHTOEQUIPMENTREF$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "switchToEquipmentRef" element
     */
    public boolean isSetSwitchToEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHTOEQUIPMENTREF$12) != 0;
        }
    }
    
    /**
     * Sets the "switchToEquipmentRef" element
     */
    public void setSwitchToEquipmentRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchToEquipmentRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SWITCHTOEQUIPMENTREF$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SWITCHTOEQUIPMENTREF$12);
            }
            target.set(switchToEquipmentRef);
        }
    }
    
    /**
     * Appends and returns a new empty "switchToEquipmentRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchToEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SWITCHTOEQUIPMENTREF$12);
            return target;
        }
    }
    
    /**
     * Unsets the "switchToEquipmentRef" element
     */
    public void unsetSwitchToEquipmentRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHTOEQUIPMENTREF$12, 0);
        }
    }
}
