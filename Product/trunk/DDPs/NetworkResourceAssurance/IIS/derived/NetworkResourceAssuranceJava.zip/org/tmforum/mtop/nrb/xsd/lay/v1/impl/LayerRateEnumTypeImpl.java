/*
 * XML Type:  LayerRateEnumType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/lay/v1
 * Java type: org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.lay.v1.impl;
/**
 * An XML LayerRateEnumType(@http://www.tmforum.org/mtop/nrb/xsd/lay/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType.
 */
public class LayerRateEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType
{
    
    public LayerRateEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected LayerRateEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
