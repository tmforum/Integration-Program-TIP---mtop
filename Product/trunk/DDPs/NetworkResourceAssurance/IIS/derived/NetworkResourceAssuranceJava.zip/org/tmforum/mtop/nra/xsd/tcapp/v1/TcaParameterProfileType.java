/*
 * XML Type:  TcaParameterProfileType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcapp/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcapp.v1;


/**
 * An XML TcaParameterProfileType(@http://www.tmforum.org/mtop/nra/xsd/tcapp/v1).
 *
 * This is a complex type.
 */
public interface TcaParameterProfileType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcaParameterProfileType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s6982FB52D4AE2F5B24D47B961EDD96DC").resolveHandle("tcaparameterprofiletypecd3atype");
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * Tests for nil "layerRate" element
     */
    boolean isNilLayerRate();
    
    /**
     * True if has "layerRate" element
     */
    boolean isSetLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Nils the "layerRate" element
     */
    void setNilLayerRate();
    
    /**
     * Unsets the "layerRate" element
     */
    void unsetLayerRate();
    
    /**
     * Gets the "associatedTpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAssociatedTpRefList();
    
    /**
     * Tests for nil "associatedTpRefList" element
     */
    boolean isNilAssociatedTpRefList();
    
    /**
     * True if has "associatedTpRefList" element
     */
    boolean isSetAssociatedTpRefList();
    
    /**
     * Sets the "associatedTpRefList" element
     */
    void setAssociatedTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType associatedTpRefList);
    
    /**
     * Appends and returns a new empty "associatedTpRefList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAssociatedTpRefList();
    
    /**
     * Nils the "associatedTpRefList" element
     */
    void setNilAssociatedTpRefList();
    
    /**
     * Unsets the "associatedTpRefList" element
     */
    void unsetAssociatedTpRefList();
    
    /**
     * Gets the "tcaParameterList" element
     */
    org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType getTcaParameterList();
    
    /**
     * Tests for nil "tcaParameterList" element
     */
    boolean isNilTcaParameterList();
    
    /**
     * True if has "tcaParameterList" element
     */
    boolean isSetTcaParameterList();
    
    /**
     * Sets the "tcaParameterList" element
     */
    void setTcaParameterList(org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType tcaParameterList);
    
    /**
     * Appends and returns a new empty "tcaParameterList" element
     */
    org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType addNewTcaParameterList();
    
    /**
     * Nils the "tcaParameterList" element
     */
    void setNilTcaParameterList();
    
    /**
     * Unsets the "tcaParameterList" element
     */
    void unsetTcaParameterList();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType newInstance() {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
