/*
 * XML Type:  ThresholdCrossingAlertType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tca/v1
 * Java type: org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tca.v1;


/**
 * An XML ThresholdCrossingAlertType(@http://www.tmforum.org/mtop/nra/xsd/tca/v1).
 *
 * This is a complex type.
 */
public interface ThresholdCrossingAlertType extends org.tmforum.mtop.fmw.xsd.ei.v1.EventInformationType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ThresholdCrossingAlertType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s3302A0BB3167604C489D394E7972B422").resolveHandle("thresholdcrossingalerttype9debtype");
    
    /**
     * Gets the "aliasNameList" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNameList();
    
    /**
     * Sets the "aliasNameList" element
     */
    void setAliasNameList(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNameList);
    
    /**
     * Appends and returns a new empty "aliasNameList" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNameList();
    
    /**
     * Gets the "isClearable" element
     */
    boolean getIsClearable();
    
    /**
     * Gets (as xml) the "isClearable" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsClearable();
    
    /**
     * Sets the "isClearable" element
     */
    void setIsClearable(boolean isClearable);
    
    /**
     * Sets (as xml) the "isClearable" element
     */
    void xsetIsClearable(org.apache.xmlbeans.XmlBoolean isClearable);
    
    /**
     * Gets the "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum getPerceivedSeverity();
    
    /**
     * Gets (as xml) the "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType xgetPerceivedSeverity();
    
    /**
     * Sets the "perceivedSeverity" element
     */
    void setPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity);
    
    /**
     * Sets (as xml) the "perceivedSeverity" element
     */
    void xsetPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType perceivedSeverity);
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Gets the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity();
    
    /**
     * Gets (as xml) the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity();
    
    /**
     * Sets the "granularity" element
     */
    void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity);
    
    /**
     * Sets (as xml) the "granularity" element
     */
    void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity);
    
    /**
     * Gets the "pmParameterName" element
     */
    java.lang.String getPmParameterName();
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName();
    
    /**
     * Sets the "pmParameterName" element
     */
    void setPmParameterName(java.lang.String pmParameterName);
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName);
    
    /**
     * Gets the "parameterLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getParameterLocation();
    
    /**
     * Gets (as xml) the "parameterLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetParameterLocation();
    
    /**
     * Sets the "parameterLocation" element
     */
    void setParameterLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum parameterLocation);
    
    /**
     * Sets (as xml) the "parameterLocation" element
     */
    void xsetParameterLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType parameterLocation);
    
    /**
     * Gets the "thresholdType" element
     */
    org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType getThresholdType();
    
    /**
     * Sets the "thresholdType" element
     */
    void setThresholdType(org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType thresholdType);
    
    /**
     * Appends and returns a new empty "thresholdType" element
     */
    org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType addNewThresholdType();
    
    /**
     * Gets the "thresholdValue" element
     */
    float getThresholdValue();
    
    /**
     * Gets (as xml) the "thresholdValue" element
     */
    org.apache.xmlbeans.XmlFloat xgetThresholdValue();
    
    /**
     * Tests for nil "thresholdValue" element
     */
    boolean isNilThresholdValue();
    
    /**
     * True if has "thresholdValue" element
     */
    boolean isSetThresholdValue();
    
    /**
     * Sets the "thresholdValue" element
     */
    void setThresholdValue(float thresholdValue);
    
    /**
     * Sets (as xml) the "thresholdValue" element
     */
    void xsetThresholdValue(org.apache.xmlbeans.XmlFloat thresholdValue);
    
    /**
     * Nils the "thresholdValue" element
     */
    void setNilThresholdValue();
    
    /**
     * Unsets the "thresholdValue" element
     */
    void unsetThresholdValue();
    
    /**
     * Gets the "thresholdUnit" element
     */
    java.lang.String getThresholdUnit();
    
    /**
     * Gets (as xml) the "thresholdUnit" element
     */
    org.apache.xmlbeans.XmlString xgetThresholdUnit();
    
    /**
     * Tests for nil "thresholdUnit" element
     */
    boolean isNilThresholdUnit();
    
    /**
     * True if has "thresholdUnit" element
     */
    boolean isSetThresholdUnit();
    
    /**
     * Sets the "thresholdUnit" element
     */
    void setThresholdUnit(java.lang.String thresholdUnit);
    
    /**
     * Sets (as xml) the "thresholdUnit" element
     */
    void xsetThresholdUnit(org.apache.xmlbeans.XmlString thresholdUnit);
    
    /**
     * Nils the "thresholdUnit" element
     */
    void setNilThresholdUnit();
    
    /**
     * Unsets the "thresholdUnit" element
     */
    void unsetThresholdUnit();
    
    /**
     * Gets the "acknowledgement" element
     */
    org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType.Enum getAcknowledgement();
    
    /**
     * Gets (as xml) the "acknowledgement" element
     */
    org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType xgetAcknowledgement();
    
    /**
     * Sets the "acknowledgement" element
     */
    void setAcknowledgement(org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType.Enum acknowledgement);
    
    /**
     * Sets (as xml) the "acknowledgement" element
     */
    void xsetAcknowledgement(org.tmforum.mtop.nra.xsd.tca.v1.AcknowledgeIndicationType acknowledgement);
    
    /**
     * Gets the "isEdgePointRelated" element
     */
    boolean getIsEdgePointRelated();
    
    /**
     * Gets (as xml) the "isEdgePointRelated" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsEdgePointRelated();
    
    /**
     * True if has "isEdgePointRelated" element
     */
    boolean isSetIsEdgePointRelated();
    
    /**
     * Sets the "isEdgePointRelated" element
     */
    void setIsEdgePointRelated(boolean isEdgePointRelated);
    
    /**
     * Sets (as xml) the "isEdgePointRelated" element
     */
    void xsetIsEdgePointRelated(org.apache.xmlbeans.XmlBoolean isEdgePointRelated);
    
    /**
     * Unsets the "isEdgePointRelated" element
     */
    void unsetIsEdgePointRelated();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType newInstance() {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tca.v1.ThresholdCrossingAlertType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
