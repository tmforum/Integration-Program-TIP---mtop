/*
 * An XML document type.
 * Localname: enablePmDataException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmc/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmc.v1.impl;
/**
 * A document containing one enablePmDataException(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1) element.
 *
 * This is a complex type.
 */
public class EnablePmDataExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument
{
    
    public EnablePmDataExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENABLEPMDATAEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "enablePmDataException");
    
    
    /**
     * Gets the "enablePmDataException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException getEnablePmDataException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException)get_store().find_element_user(ENABLEPMDATAEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "enablePmDataException" element
     */
    public void setEnablePmDataException(org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException enablePmDataException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException)get_store().find_element_user(ENABLEPMDATAEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException)get_store().add_element_user(ENABLEPMDATAEXCEPTION$0);
            }
            target.set(enablePmDataException);
        }
    }
    
    /**
     * Appends and returns a new empty "enablePmDataException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException addNewEnablePmDataException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException)get_store().add_element_user(ENABLEPMDATAEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML enablePmDataException(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1).
     *
     * This is a complex type.
     */
    public static class EnablePmDataExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataExceptionDocument.EnablePmDataException
    {
        
        public EnablePmDataExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
