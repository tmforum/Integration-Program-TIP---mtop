/*
 * XML Type:  GetAllDataIteratorExceptionType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * An XML GetAllDataIteratorExceptionType(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1).
 *
 * This is a complex type.
 */
public class GetAllDataIteratorExceptionTypeImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType
{
    
    public GetAllDataIteratorExceptionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
