/*
 * XML Type:  PmDataType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmdata/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmdata.v1.impl;
/**
 * An XML PmDataType(@http://www.tmforum.org/mtop/nra/xsd/pmdata/v1).
 *
 * This is a complex type.
 */
public class PmDataTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataType
{
    
    public PmDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmdata/v1", "tpName");
    private static final javax.xml.namespace.QName LAYERRATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmdata/v1", "layerRate");
    private static final javax.xml.namespace.QName GRANULARITY$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmdata/v1", "granularity");
    private static final javax.xml.namespace.QName RETRIEVALTIME$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmdata/v1", "retrievalTime");
    private static final javax.xml.namespace.QName PMMEASUREMENTLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmdata/v1", "pmMeasurementList");
    
    
    /**
     * Gets the "tpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "tpName" element
     */
    public boolean isNilTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tpName" element
     */
    public boolean isSetTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "tpName" element
     */
    public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
            }
            target.set(tpName);
        }
    }
    
    /**
     * Appends and returns a new empty "tpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
            return target;
        }
    }
    
    /**
     * Nils the "tpName" element
     */
    public void setNilTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tpName" element
     */
    public void unsetTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPNAME$0, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "layerRate" element
     */
    public boolean isNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$2) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$2);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$2);
            return target;
        }
    }
    
    /**
     * Nils the "layerRate" element
     */
    public void setNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$2, 0);
        }
    }
    
    /**
     * Gets the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "granularity" element
     */
    public boolean isNilGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "granularity" element
     */
    public boolean isSetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GRANULARITY$4) != 0;
        }
    }
    
    /**
     * Sets the "granularity" element
     */
    public void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(GRANULARITY$4);
            }
            target.setEnumValue(granularity);
        }
    }
    
    /**
     * Sets (as xml) the "granularity" element
     */
    public void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$4);
            }
            target.set(granularity);
        }
    }
    
    /**
     * Nils the "granularity" element
     */
    public void setNilGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "granularity" element
     */
    public void unsetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GRANULARITY$4, 0);
        }
    }
    
    /**
     * Gets the "retrievalTime" element
     */
    public java.util.Calendar getRetrievalTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RETRIEVALTIME$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "retrievalTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetRetrievalTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(RETRIEVALTIME$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "retrievalTime" element
     */
    public boolean isSetRetrievalTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RETRIEVALTIME$6) != 0;
        }
    }
    
    /**
     * Sets the "retrievalTime" element
     */
    public void setRetrievalTime(java.util.Calendar retrievalTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RETRIEVALTIME$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RETRIEVALTIME$6);
            }
            target.setCalendarValue(retrievalTime);
        }
    }
    
    /**
     * Sets (as xml) the "retrievalTime" element
     */
    public void xsetRetrievalTime(org.apache.xmlbeans.XmlDateTime retrievalTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(RETRIEVALTIME$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(RETRIEVALTIME$6);
            }
            target.set(retrievalTime);
        }
    }
    
    /**
     * Unsets the "retrievalTime" element
     */
    public void unsetRetrievalTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RETRIEVALTIME$6, 0);
        }
    }
    
    /**
     * Gets the "pmMeasurementList" element
     */
    public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType getPmMeasurementList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType)get_store().find_element_user(PMMEASUREMENTLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "pmMeasurementList" element
     */
    public boolean isNilPmMeasurementList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType)get_store().find_element_user(PMMEASUREMENTLIST$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmMeasurementList" element
     */
    public boolean isSetPmMeasurementList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMMEASUREMENTLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "pmMeasurementList" element
     */
    public void setPmMeasurementList(org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType pmMeasurementList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType)get_store().find_element_user(PMMEASUREMENTLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType)get_store().add_element_user(PMMEASUREMENTLIST$8);
            }
            target.set(pmMeasurementList);
        }
    }
    
    /**
     * Appends and returns a new empty "pmMeasurementList" element
     */
    public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType addNewPmMeasurementList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType)get_store().add_element_user(PMMEASUREMENTLIST$8);
            return target;
        }
    }
    
    /**
     * Nils the "pmMeasurementList" element
     */
    public void setNilPmMeasurementList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType)get_store().find_element_user(PMMEASUREMENTLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementListType)get_store().add_element_user(PMMEASUREMENTLIST$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmMeasurementList" element
     */
    public void unsetPmMeasurementList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMMEASUREMENTLIST$8, 0);
        }
    }
}
