/*
 * An XML document type.
 * Localname: disableTcaRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one disableTcaRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class DisableTcaRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument
{
    
    public DisableTcaRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DISABLETCAREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "disableTcaRequest");
    
    
    /**
     * Gets the "disableTcaRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest getDisableTcaRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest)get_store().find_element_user(DISABLETCAREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "disableTcaRequest" element
     */
    public void setDisableTcaRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest disableTcaRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest)get_store().find_element_user(DISABLETCAREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest)get_store().add_element_user(DISABLETCAREQUEST$0);
            }
            target.set(disableTcaRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "disableTcaRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest addNewDisableTcaRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest)get_store().add_element_user(DISABLETCAREQUEST$0);
            return target;
        }
    }
    /**
     * An XML disableTcaRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class DisableTcaRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaRequestDocument.DisableTcaRequest
    {
        
        public DisableTcaRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PMTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "pmTpSelectList");
        
        
        /**
         * Gets the "pmTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmTpSelectList" element
         */
        public boolean isSetPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "pmTpSelectList" element
         */
        public void setPmTpSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType pmTpSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMTPSELECTLIST$0);
                }
                target.set(pmTpSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "pmTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "pmTpSelectList" element
         */
        public void unsetPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMTPSELECTLIST$0, 0);
            }
        }
    }
}
