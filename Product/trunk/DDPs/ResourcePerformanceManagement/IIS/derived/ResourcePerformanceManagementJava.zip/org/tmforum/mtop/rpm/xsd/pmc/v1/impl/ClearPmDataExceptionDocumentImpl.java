/*
 * An XML document type.
 * Localname: clearPmDataException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmc/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmc.v1.impl;
/**
 * A document containing one clearPmDataException(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1) element.
 *
 * This is a complex type.
 */
public class ClearPmDataExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument
{
    
    public ClearPmDataExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLEARPMDATAEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "clearPmDataException");
    
    
    /**
     * Gets the "clearPmDataException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException getClearPmDataException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException)get_store().find_element_user(CLEARPMDATAEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "clearPmDataException" element
     */
    public void setClearPmDataException(org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException clearPmDataException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException)get_store().find_element_user(CLEARPMDATAEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException)get_store().add_element_user(CLEARPMDATAEXCEPTION$0);
            }
            target.set(clearPmDataException);
        }
    }
    
    /**
     * Appends and returns a new empty "clearPmDataException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException addNewClearPmDataException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException)get_store().add_element_user(CLEARPMDATAEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML clearPmDataException(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1).
     *
     * This is a complex type.
     */
    public static class ClearPmDataExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataExceptionDocument.ClearPmDataException
    {
        
        public ClearPmDataExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
