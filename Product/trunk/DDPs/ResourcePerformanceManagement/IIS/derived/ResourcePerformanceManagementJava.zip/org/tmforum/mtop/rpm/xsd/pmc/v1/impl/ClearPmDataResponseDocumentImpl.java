/*
 * An XML document type.
 * Localname: clearPmDataResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmc/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmc.v1.impl;
/**
 * A document containing one clearPmDataResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1) element.
 *
 * This is a complex type.
 */
public class ClearPmDataResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument
{
    
    public ClearPmDataResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLEARPMDATARESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "clearPmDataResponse");
    
    
    /**
     * Gets the "clearPmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse getClearPmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse)get_store().find_element_user(CLEARPMDATARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "clearPmDataResponse" element
     */
    public void setClearPmDataResponse(org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse clearPmDataResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse)get_store().find_element_user(CLEARPMDATARESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse)get_store().add_element_user(CLEARPMDATARESPONSE$0);
            }
            target.set(clearPmDataResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "clearPmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse addNewClearPmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse)get_store().add_element_user(CLEARPMDATARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML clearPmDataResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1).
     *
     * This is a complex type.
     */
    public static class ClearPmDataResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataResponseDocument.ClearPmDataResponse
    {
        
        public ClearPmDataResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FAILEDTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "failedTPSelectList");
        
        
        /**
         * Gets the "failedTPSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "failedTPSelectList" element
         */
        public boolean isSetFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILEDTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "failedTPSelectList" element
         */
        public void setFailedTPSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType failedTPSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                }
                target.set(failedTPSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "failedTPSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "failedTPSelectList" element
         */
        public void unsetFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILEDTPSELECTLIST$0, 0);
            }
        }
    }
}
