/*
 * An XML document type.
 * Localname: getAllPmpNamesResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getAllPmpNamesResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllPmpNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesResponseDocument
{
    
    public GetAllPmpNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLPMPNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getAllPmpNamesResponse");
    
    
    /**
     * Gets the "getAllPmpNamesResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType getGetAllPmpNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType)get_store().find_element_user(GETALLPMPNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllPmpNamesResponse" element
     */
    public void setGetAllPmpNamesResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType getAllPmpNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType)get_store().find_element_user(GETALLPMPNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType)get_store().add_element_user(GETALLPMPNAMESRESPONSE$0);
            }
            target.set(getAllPmpNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllPmpNamesResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType addNewGetAllPmpNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType)get_store().add_element_user(GETALLPMPNAMESRESPONSE$0);
            return target;
        }
    }
}
