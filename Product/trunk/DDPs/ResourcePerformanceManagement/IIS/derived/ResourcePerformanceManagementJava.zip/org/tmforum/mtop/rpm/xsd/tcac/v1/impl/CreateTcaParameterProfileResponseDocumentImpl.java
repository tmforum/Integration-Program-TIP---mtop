/*
 * An XML document type.
 * Localname: createTcaParameterProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one createTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class CreateTcaParameterProfileResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument
{
    
    public CreateTcaParameterProfileResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATETCAPARAMETERPROFILERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "createTcaParameterProfileResponse");
    
    
    /**
     * Gets the "createTcaParameterProfileResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse getCreateTcaParameterProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse)get_store().find_element_user(CREATETCAPARAMETERPROFILERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createTcaParameterProfileResponse" element
     */
    public void setCreateTcaParameterProfileResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse createTcaParameterProfileResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse)get_store().find_element_user(CREATETCAPARAMETERPROFILERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse)get_store().add_element_user(CREATETCAPARAMETERPROFILERESPONSE$0);
            }
            target.set(createTcaParameterProfileResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "createTcaParameterProfileResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse addNewCreateTcaParameterProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse)get_store().add_element_user(CREATETCAPARAMETERPROFILERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML createTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class CreateTcaParameterProfileResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse
    {
        
        public CreateTcaParameterProfileResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TCAPARAMETERPROFILE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tcaParameterProfile");
        
        
        /**
         * Gets the "tcaParameterProfile" element
         */
        public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType getTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().find_element_user(TCAPARAMETERPROFILE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tcaParameterProfile" element
         */
        public boolean isSetTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TCAPARAMETERPROFILE$0) != 0;
            }
        }
        
        /**
         * Sets the "tcaParameterProfile" element
         */
        public void setTcaParameterProfile(org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType tcaParameterProfile)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().find_element_user(TCAPARAMETERPROFILE$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().add_element_user(TCAPARAMETERPROFILE$0);
                }
                target.set(tcaParameterProfile);
            }
        }
        
        /**
         * Appends and returns a new empty "tcaParameterProfile" element
         */
        public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType addNewTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().add_element_user(TCAPARAMETERPROFILE$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tcaParameterProfile" element
         */
        public void unsetTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TCAPARAMETERPROFILE$0, 0);
            }
        }
    }
}
