/*
 * An XML document type.
 * Localname: getMePmCapabilitiesRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getMePmCapabilitiesRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetMePmCapabilitiesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument
{
    
    public GetMePmCapabilitiesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMEPMCAPABILITIESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getMePmCapabilitiesRequest");
    
    
    /**
     * Gets the "getMePmCapabilitiesRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest getGetMePmCapabilitiesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest)get_store().find_element_user(GETMEPMCAPABILITIESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getMePmCapabilitiesRequest" element
     */
    public void setGetMePmCapabilitiesRequest(org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest getMePmCapabilitiesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest)get_store().find_element_user(GETMEPMCAPABILITIESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest)get_store().add_element_user(GETMEPMCAPABILITIESREQUEST$0);
            }
            target.set(getMePmCapabilitiesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getMePmCapabilitiesRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest addNewGetMePmCapabilitiesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest)get_store().add_element_user(GETMEPMCAPABILITIESREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getMePmCapabilitiesRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetMePmCapabilitiesRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesRequestDocument.GetMePmCapabilitiesRequest
    {
        
        public GetMePmCapabilitiesRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "meName");
        private static final javax.xml.namespace.QName LAYER$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "layer");
        
        
        /**
         * Gets the "meName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "meName" element
         */
        public boolean isSetMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "meName" element
         */
        public void setMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType meName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$0);
                }
                target.set(meName);
            }
        }
        
        /**
         * Appends and returns a new empty "meName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "meName" element
         */
        public void unsetMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MENAME$0, 0);
            }
        }
        
        /**
         * Gets the "layer" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYER$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "layer" element
         */
        public boolean isSetLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LAYER$2) != 0;
            }
        }
        
        /**
         * Sets the "layer" element
         */
        public void setLayer(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layer)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYER$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYER$2);
                }
                target.set(layer);
            }
        }
        
        /**
         * Appends and returns a new empty "layer" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYER$2);
                return target;
            }
        }
        
        /**
         * Unsets the "layer" element
         */
        public void unsetLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LAYER$2, 0);
            }
        }
    }
}
