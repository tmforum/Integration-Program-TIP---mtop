/*
 * An XML document type.
 * Localname: getProfileAssociatedTpsResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getProfileAssociatedTpsResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetProfileAssociatedTpsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsResponseDocument
{
    
    public GetProfileAssociatedTpsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROFILEASSOCIATEDTPSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getProfileAssociatedTpsResponse");
    
    
    /**
     * Gets the "getProfileAssociatedTpsResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType getGetProfileAssociatedTpsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType)get_store().find_element_user(GETPROFILEASSOCIATEDTPSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getProfileAssociatedTpsResponse" element
     */
    public void setGetProfileAssociatedTpsResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType getProfileAssociatedTpsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType)get_store().find_element_user(GETPROFILEASSOCIATEDTPSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType)get_store().add_element_user(GETPROFILEASSOCIATEDTPSRESPONSE$0);
            }
            target.set(getProfileAssociatedTpsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getProfileAssociatedTpsResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType addNewGetProfileAssociatedTpsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultipleProfileAssociatedTpObjectNamesResponseType)get_store().add_element_user(GETPROFILEASSOCIATEDTPSRESPONSE$0);
            return target;
        }
    }
}
