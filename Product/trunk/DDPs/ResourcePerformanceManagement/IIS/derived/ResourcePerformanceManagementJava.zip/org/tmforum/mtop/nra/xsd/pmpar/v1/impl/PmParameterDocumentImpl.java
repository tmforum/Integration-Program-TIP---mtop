/*
 * An XML document type.
 * Localname: pmParameter
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmpar/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmpar.v1.impl;
/**
 * A document containing one pmParameter(@http://www.tmforum.org/mtop/nra/xsd/pmpar/v1) element.
 *
 * This is a complex type.
 */
public class PmParameterDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterDocument
{
    
    public PmParameterDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETER$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmpar/v1", "pmParameter");
    
    
    /**
     * Gets the "pmParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType getPmParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType)get_store().find_element_user(PMPARAMETER$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pmParameter" element
     */
    public void setPmParameter(org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType pmParameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType)get_store().find_element_user(PMPARAMETER$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType)get_store().add_element_user(PMPARAMETER$0);
            }
            target.set(pmParameter);
        }
    }
    
    /**
     * Appends and returns a new empty "pmParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType addNewPmParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterType)get_store().add_element_user(PMPARAMETER$0);
            return target;
        }
    }
}
