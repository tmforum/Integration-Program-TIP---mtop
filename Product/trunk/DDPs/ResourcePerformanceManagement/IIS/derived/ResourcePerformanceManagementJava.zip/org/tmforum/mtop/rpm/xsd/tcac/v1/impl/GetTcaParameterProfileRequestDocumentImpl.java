/*
 * An XML document type.
 * Localname: getTcaParameterProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetTcaParameterProfileRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument
{
    
    public GetTcaParameterProfileRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTCAPARAMETERPROFILEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getTcaParameterProfileRequest");
    
    
    /**
     * Gets the "getTcaParameterProfileRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest getGetTcaParameterProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest)get_store().find_element_user(GETTCAPARAMETERPROFILEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getTcaParameterProfileRequest" element
     */
    public void setGetTcaParameterProfileRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest getTcaParameterProfileRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest)get_store().find_element_user(GETTCAPARAMETERPROFILEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest)get_store().add_element_user(GETTCAPARAMETERPROFILEREQUEST$0);
            }
            target.set(getTcaParameterProfileRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getTcaParameterProfileRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest addNewGetTcaParameterProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest)get_store().add_element_user(GETTCAPARAMETERPROFILEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetTcaParameterProfileRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileRequestDocument.GetTcaParameterProfileRequest
    {
        
        public GetTcaParameterProfileRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TCAPARAMETERPROFILENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tcaParameterProfileName");
        
        
        /**
         * Gets the "tcaParameterProfileName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TCAPARAMETERPROFILENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tcaParameterProfileName" element
         */
        public boolean isSetTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TCAPARAMETERPROFILENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tcaParameterProfileName" element
         */
        public void setTcaParameterProfileName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tcaParameterProfileName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TCAPARAMETERPROFILENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TCAPARAMETERPROFILENAME$0);
                }
                target.set(tcaParameterProfileName);
            }
        }
        
        /**
         * Appends and returns a new empty "tcaParameterProfileName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TCAPARAMETERPROFILENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tcaParameterProfileName" element
         */
        public void unsetTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TCAPARAMETERPROFILENAME$0, 0);
            }
        }
    }
}
