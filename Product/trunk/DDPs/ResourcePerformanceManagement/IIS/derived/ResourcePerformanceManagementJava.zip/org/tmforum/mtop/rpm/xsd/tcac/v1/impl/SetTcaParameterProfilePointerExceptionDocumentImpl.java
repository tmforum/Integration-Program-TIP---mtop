/*
 * An XML document type.
 * Localname: setTcaParameterProfilePointerException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one setTcaParameterProfilePointerException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class SetTcaParameterProfilePointerExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument
{
    
    public SetTcaParameterProfilePointerExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETTCAPARAMETERPROFILEPOINTEREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "setTcaParameterProfilePointerException");
    
    
    /**
     * Gets the "setTcaParameterProfilePointerException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException getSetTcaParameterProfilePointerException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException)get_store().find_element_user(SETTCAPARAMETERPROFILEPOINTEREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setTcaParameterProfilePointerException" element
     */
    public void setSetTcaParameterProfilePointerException(org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException setTcaParameterProfilePointerException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException)get_store().find_element_user(SETTCAPARAMETERPROFILEPOINTEREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException)get_store().add_element_user(SETTCAPARAMETERPROFILEPOINTEREXCEPTION$0);
            }
            target.set(setTcaParameterProfilePointerException);
        }
    }
    
    /**
     * Appends and returns a new empty "setTcaParameterProfilePointerException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException addNewSetTcaParameterProfilePointerException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException)get_store().add_element_user(SETTCAPARAMETERPROFILEPOINTEREXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setTcaParameterProfilePointerException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class SetTcaParameterProfilePointerExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerExceptionDocument.SetTcaParameterProfilePointerException
    {
        
        public SetTcaParameterProfilePointerExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
