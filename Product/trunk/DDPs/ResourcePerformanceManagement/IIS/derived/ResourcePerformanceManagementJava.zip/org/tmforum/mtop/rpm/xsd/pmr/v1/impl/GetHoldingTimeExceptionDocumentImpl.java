/*
 * An XML document type.
 * Localname: getHoldingTimeException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getHoldingTimeException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetHoldingTimeExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument
{
    
    public GetHoldingTimeExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETHOLDINGTIMEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getHoldingTimeException");
    
    
    /**
     * Gets the "getHoldingTimeException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException getGetHoldingTimeException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException)get_store().find_element_user(GETHOLDINGTIMEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getHoldingTimeException" element
     */
    public void setGetHoldingTimeException(org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException getHoldingTimeException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException)get_store().find_element_user(GETHOLDINGTIMEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException)get_store().add_element_user(GETHOLDINGTIMEEXCEPTION$0);
            }
            target.set(getHoldingTimeException);
        }
    }
    
    /**
     * Appends and returns a new empty "getHoldingTimeException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException addNewGetHoldingTimeException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException)get_store().add_element_user(GETHOLDINGTIMEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getHoldingTimeException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetHoldingTimeExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeExceptionDocument.GetHoldingTimeException
    {
        
        public GetHoldingTimeExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
