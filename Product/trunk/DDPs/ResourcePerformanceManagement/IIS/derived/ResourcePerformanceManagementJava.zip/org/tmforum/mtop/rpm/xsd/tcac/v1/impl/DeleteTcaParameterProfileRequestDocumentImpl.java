/*
 * An XML document type.
 * Localname: deleteTcaParameterProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one deleteTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class DeleteTcaParameterProfileRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument
{
    
    public DeleteTcaParameterProfileRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETETCAPARAMETERPROFILEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "deleteTcaParameterProfileRequest");
    
    
    /**
     * Gets the "deleteTcaParameterProfileRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest getDeleteTcaParameterProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest)get_store().find_element_user(DELETETCAPARAMETERPROFILEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteTcaParameterProfileRequest" element
     */
    public void setDeleteTcaParameterProfileRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest deleteTcaParameterProfileRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest)get_store().find_element_user(DELETETCAPARAMETERPROFILEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest)get_store().add_element_user(DELETETCAPARAMETERPROFILEREQUEST$0);
            }
            target.set(deleteTcaParameterProfileRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteTcaParameterProfileRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest addNewDeleteTcaParameterProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest)get_store().add_element_user(DELETETCAPARAMETERPROFILEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML deleteTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class DeleteTcaParameterProfileRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileRequestDocument.DeleteTcaParameterProfileRequest
    {
        
        public DeleteTcaParameterProfileRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TCAPARAMETERPROFILENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tcaParameterProfileName");
        
        
        /**
         * Gets the "tcaParameterProfileName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TCAPARAMETERPROFILENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tcaParameterProfileName" element
         */
        public boolean isSetTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TCAPARAMETERPROFILENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tcaParameterProfileName" element
         */
        public void setTcaParameterProfileName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tcaParameterProfileName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TCAPARAMETERPROFILENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TCAPARAMETERPROFILENAME$0);
                }
                target.set(tcaParameterProfileName);
            }
        }
        
        /**
         * Appends and returns a new empty "tcaParameterProfileName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TCAPARAMETERPROFILENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tcaParameterProfileName" element
         */
        public void unsetTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TCAPARAMETERPROFILENAME$0, 0);
            }
        }
    }
}
