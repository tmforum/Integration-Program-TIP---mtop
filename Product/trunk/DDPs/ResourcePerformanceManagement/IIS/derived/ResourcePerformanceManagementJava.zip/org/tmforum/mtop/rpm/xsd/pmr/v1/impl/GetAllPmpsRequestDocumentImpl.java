/*
 * An XML document type.
 * Localname: getAllPmpsRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getAllPmpsRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllPmpsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument
{
    
    public GetAllPmpsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLPMPSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getAllPmpsRequest");
    
    
    /**
     * Gets the "getAllPmpsRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest getGetAllPmpsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest)get_store().find_element_user(GETALLPMPSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllPmpsRequest" element
     */
    public void setGetAllPmpsRequest(org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest getAllPmpsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest)get_store().find_element_user(GETALLPMPSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest)get_store().add_element_user(GETALLPMPSREQUEST$0);
            }
            target.set(getAllPmpsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllPmpsRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest addNewGetAllPmpsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest)get_store().add_element_user(GETALLPMPSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllPmpsRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllPmpsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsRequestDocument.GetAllPmpsRequest
    {
        
        public GetAllPmpsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPORMENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "tpOrMeName");
        
        
        /**
         * Gets the "tpOrMeName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPORMENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpOrMeName" element
         */
        public boolean isSetTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPORMENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tpOrMeName" element
         */
        public void setTpOrMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpOrMeName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPORMENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPORMENAME$0);
                }
                target.set(tpOrMeName);
            }
        }
        
        /**
         * Appends and returns a new empty "tpOrMeName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPORMENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tpOrMeName" element
         */
        public void unsetTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPORMENAME$0, 0);
            }
        }
    }
}
