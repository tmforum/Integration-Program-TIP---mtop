/*
 * An XML document type.
 * Localname: getProfileAssociatedTpsRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getProfileAssociatedTpsRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetProfileAssociatedTpsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument
{
    
    public GetProfileAssociatedTpsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPROFILEASSOCIATEDTPSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getProfileAssociatedTpsRequest");
    
    
    /**
     * Gets the "getProfileAssociatedTpsRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest getGetProfileAssociatedTpsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest)get_store().find_element_user(GETPROFILEASSOCIATEDTPSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getProfileAssociatedTpsRequest" element
     */
    public void setGetProfileAssociatedTpsRequest(org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest getProfileAssociatedTpsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest)get_store().find_element_user(GETPROFILEASSOCIATEDTPSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest)get_store().add_element_user(GETPROFILEASSOCIATEDTPSREQUEST$0);
            }
            target.set(getProfileAssociatedTpsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getProfileAssociatedTpsRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest addNewGetProfileAssociatedTpsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest)get_store().add_element_user(GETPROFILEASSOCIATEDTPSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getProfileAssociatedTpsRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetProfileAssociatedTpsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetProfileAssociatedTpsRequestDocument.GetProfileAssociatedTpsRequest
    {
        
        public GetProfileAssociatedTpsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PROFILENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "profileName");
        
        
        /**
         * Gets the "profileName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROFILENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "profileName" element
         */
        public boolean isSetProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PROFILENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "profileName" element
         */
        public void setProfileName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType profileName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROFILENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PROFILENAME$0);
                }
                target.set(profileName);
            }
        }
        
        /**
         * Appends and returns a new empty "profileName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PROFILENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "profileName" element
         */
        public void unsetProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PROFILENAME$0, 0);
            }
        }
    }
}
