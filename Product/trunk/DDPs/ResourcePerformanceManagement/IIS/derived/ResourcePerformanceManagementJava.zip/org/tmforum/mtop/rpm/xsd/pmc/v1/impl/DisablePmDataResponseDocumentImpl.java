/*
 * An XML document type.
 * Localname: disablePmDataResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmc/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmc.v1.impl;
/**
 * A document containing one disablePmDataResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1) element.
 *
 * This is a complex type.
 */
public class DisablePmDataResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument
{
    
    public DisablePmDataResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DISABLEPMDATARESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "disablePmDataResponse");
    
    
    /**
     * Gets the "disablePmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse getDisablePmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse)get_store().find_element_user(DISABLEPMDATARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "disablePmDataResponse" element
     */
    public void setDisablePmDataResponse(org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse disablePmDataResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse)get_store().find_element_user(DISABLEPMDATARESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse)get_store().add_element_user(DISABLEPMDATARESPONSE$0);
            }
            target.set(disablePmDataResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "disablePmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse addNewDisablePmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse)get_store().add_element_user(DISABLEPMDATARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML disablePmDataResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1).
     *
     * This is a complex type.
     */
    public static class DisablePmDataResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataResponseDocument.DisablePmDataResponse
    {
        
        public DisablePmDataResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FAILEDTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "failedTpSelectList");
        
        
        /**
         * Gets the "failedTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "failedTpSelectList" element
         */
        public boolean isSetFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILEDTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "failedTpSelectList" element
         */
        public void setFailedTpSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType failedTpSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                }
                target.set(failedTpSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "failedTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "failedTpSelectList" element
         */
        public void unsetFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILEDTPSELECTLIST$0, 0);
            }
        }
    }
}
