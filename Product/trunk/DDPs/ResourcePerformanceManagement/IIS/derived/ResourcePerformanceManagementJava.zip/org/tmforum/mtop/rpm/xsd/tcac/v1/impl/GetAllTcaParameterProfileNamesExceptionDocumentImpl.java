/*
 * An XML document type.
 * Localname: getAllTcaParameterProfileNamesException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getAllTcaParameterProfileNamesException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetAllTcaParameterProfileNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument
{
    
    public GetAllTcaParameterProfileNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLTCAPARAMETERPROFILENAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getAllTcaParameterProfileNamesException");
    
    
    /**
     * Gets the "getAllTcaParameterProfileNamesException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException getGetAllTcaParameterProfileNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException)get_store().find_element_user(GETALLTCAPARAMETERPROFILENAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllTcaParameterProfileNamesException" element
     */
    public void setGetAllTcaParameterProfileNamesException(org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException getAllTcaParameterProfileNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException)get_store().find_element_user(GETALLTCAPARAMETERPROFILENAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException)get_store().add_element_user(GETALLTCAPARAMETERPROFILENAMESEXCEPTION$0);
            }
            target.set(getAllTcaParameterProfileNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllTcaParameterProfileNamesException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException addNewGetAllTcaParameterProfileNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException)get_store().add_element_user(GETALLTCAPARAMETERPROFILENAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllTcaParameterProfileNamesException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetAllTcaParameterProfileNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesExceptionDocument.GetAllTcaParameterProfileNamesException
    {
        
        public GetAllTcaParameterProfileNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
