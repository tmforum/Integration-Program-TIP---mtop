/*
 * XML Type:  MultiplePmpObjectsResponseType
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * An XML MultiplePmpObjectsResponseType(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
 *
 * This is a complex type.
 */
public class MultiplePmpObjectsResponseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType
{
    
    public MultiplePmpObjectsResponseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "pmpList");
    
    
    /**
     * Gets the "pmpList" element
     */
    public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType getPmpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType)get_store().find_element_user(PMPLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "pmpList" element
     */
    public boolean isSetPmpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "pmpList" element
     */
    public void setPmpList(org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType pmpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType)get_store().find_element_user(PMPLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType)get_store().add_element_user(PMPLIST$0);
            }
            target.set(pmpList);
        }
    }
    
    /**
     * Appends and returns a new empty "pmpList" element
     */
    public org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType addNewPmpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmp.v1.PerformanceMonitoringPointListType)get_store().add_element_user(PMPLIST$0);
            return target;
        }
    }
    
    /**
     * Unsets the "pmpList" element
     */
    public void unsetPmpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPLIST$0, 0);
        }
    }
}
