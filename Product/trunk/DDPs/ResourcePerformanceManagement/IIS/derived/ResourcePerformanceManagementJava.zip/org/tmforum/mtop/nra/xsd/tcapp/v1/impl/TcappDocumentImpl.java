/*
 * An XML document type.
 * Localname: tcapp
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcapp/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcapp.v1.TcappDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcapp.v1.impl;
/**
 * A document containing one tcapp(@http://www.tmforum.org/mtop/nra/xsd/tcapp/v1) element.
 *
 * This is a complex type.
 */
public class TcappDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.tcapp.v1.TcappDocument
{
    
    public TcappDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TCAPP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapp/v1", "tcapp");
    
    
    /**
     * Gets the "tcapp" element
     */
    public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType getTcapp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().find_element_user(TCAPP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tcapp" element
     */
    public void setTcapp(org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType tcapp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().find_element_user(TCAPP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().add_element_user(TCAPP$0);
            }
            target.set(tcapp);
        }
    }
    
    /**
     * Appends and returns a new empty "tcapp" element
     */
    public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType addNewTcapp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().add_element_user(TCAPP$0);
            return target;
        }
    }
}
