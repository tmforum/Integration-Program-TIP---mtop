/*
 * An XML document type.
 * Localname: setTcaParameterProfilePointerRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one setTcaParameterProfilePointerRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class SetTcaParameterProfilePointerRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument
{
    
    public SetTcaParameterProfilePointerRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETTCAPARAMETERPROFILEPOINTERREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "setTcaParameterProfilePointerRequest");
    
    
    /**
     * Gets the "setTcaParameterProfilePointerRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest getSetTcaParameterProfilePointerRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest)get_store().find_element_user(SETTCAPARAMETERPROFILEPOINTERREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setTcaParameterProfilePointerRequest" element
     */
    public void setSetTcaParameterProfilePointerRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest setTcaParameterProfilePointerRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest)get_store().find_element_user(SETTCAPARAMETERPROFILEPOINTERREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest)get_store().add_element_user(SETTCAPARAMETERPROFILEPOINTERREQUEST$0);
            }
            target.set(setTcaParameterProfilePointerRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setTcaParameterProfilePointerRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest addNewSetTcaParameterProfilePointerRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest)get_store().add_element_user(SETTCAPARAMETERPROFILEPOINTERREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setTcaParameterProfilePointerRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class SetTcaParameterProfilePointerRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfilePointerRequestDocument.SetTcaParameterProfilePointerRequest
    {
        
        public SetTcaParameterProfilePointerRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tpName");
        private static final javax.xml.namespace.QName ADDTCAPARAMETERPROFILE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "addTcaParameterProfile");
        private static final javax.xml.namespace.QName REMOVETCAPARAMETERPROFILE$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "removeTcaParameterProfile");
        
        
        /**
         * Gets the "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpName" element
         */
        public boolean isSetTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tpName" element
         */
        public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
                }
                target.set(tpName);
            }
        }
        
        /**
         * Appends and returns a new empty "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tpName" element
         */
        public void unsetTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPNAME$0, 0);
            }
        }
        
        /**
         * Gets the "addTcaParameterProfile" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getAddTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ADDTCAPARAMETERPROFILE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "addTcaParameterProfile" element
         */
        public boolean isSetAddTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ADDTCAPARAMETERPROFILE$2) != 0;
            }
        }
        
        /**
         * Sets the "addTcaParameterProfile" element
         */
        public void setAddTcaParameterProfile(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addTcaParameterProfile)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ADDTCAPARAMETERPROFILE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ADDTCAPARAMETERPROFILE$2);
                }
                target.set(addTcaParameterProfile);
            }
        }
        
        /**
         * Appends and returns a new empty "addTcaParameterProfile" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewAddTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ADDTCAPARAMETERPROFILE$2);
                return target;
            }
        }
        
        /**
         * Unsets the "addTcaParameterProfile" element
         */
        public void unsetAddTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ADDTCAPARAMETERPROFILE$2, 0);
            }
        }
        
        /**
         * Gets the "removeTcaParameterProfile" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getRemoveTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(REMOVETCAPARAMETERPROFILE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "removeTcaParameterProfile" element
         */
        public boolean isSetRemoveTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(REMOVETCAPARAMETERPROFILE$4) != 0;
            }
        }
        
        /**
         * Sets the "removeTcaParameterProfile" element
         */
        public void setRemoveTcaParameterProfile(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType removeTcaParameterProfile)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(REMOVETCAPARAMETERPROFILE$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(REMOVETCAPARAMETERPROFILE$4);
                }
                target.set(removeTcaParameterProfile);
            }
        }
        
        /**
         * Appends and returns a new empty "removeTcaParameterProfile" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewRemoveTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(REMOVETCAPARAMETERPROFILE$4);
                return target;
            }
        }
        
        /**
         * Unsets the "removeTcaParameterProfile" element
         */
        public void unsetRemoveTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(REMOVETCAPARAMETERPROFILE$4, 0);
            }
        }
    }
}
