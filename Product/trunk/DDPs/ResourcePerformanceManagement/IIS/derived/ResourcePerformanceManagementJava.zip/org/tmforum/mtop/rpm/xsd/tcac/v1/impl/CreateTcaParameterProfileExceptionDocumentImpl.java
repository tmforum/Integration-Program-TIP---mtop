/*
 * An XML document type.
 * Localname: createTcaParameterProfileException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one createTcaParameterProfileException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class CreateTcaParameterProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument
{
    
    public CreateTcaParameterProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATETCAPARAMETERPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "createTcaParameterProfileException");
    
    
    /**
     * Gets the "createTcaParameterProfileException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException getCreateTcaParameterProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException)get_store().find_element_user(CREATETCAPARAMETERPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createTcaParameterProfileException" element
     */
    public void setCreateTcaParameterProfileException(org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException createTcaParameterProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException)get_store().find_element_user(CREATETCAPARAMETERPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException)get_store().add_element_user(CREATETCAPARAMETERPROFILEEXCEPTION$0);
            }
            target.set(createTcaParameterProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "createTcaParameterProfileException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException addNewCreateTcaParameterProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException)get_store().add_element_user(CREATETCAPARAMETERPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML createTcaParameterProfileException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class CreateTcaParameterProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileExceptionDocument.CreateTcaParameterProfileException
    {
        
        public CreateTcaParameterProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
