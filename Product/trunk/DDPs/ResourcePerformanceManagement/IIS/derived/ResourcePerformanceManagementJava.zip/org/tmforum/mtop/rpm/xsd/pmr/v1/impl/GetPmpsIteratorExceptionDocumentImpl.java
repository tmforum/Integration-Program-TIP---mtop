/*
 * An XML document type.
 * Localname: getPmpsIteratorException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetPmpsIteratorExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getPmpsIteratorException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetPmpsIteratorExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetPmpsIteratorExceptionDocument
{
    
    public GetPmpsIteratorExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPMPSITERATOREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getPmpsIteratorException");
    
    
    /**
     * Gets the "getPmpsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getGetPmpsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETPMPSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPmpsIteratorException" element
     */
    public void setGetPmpsIteratorException(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getPmpsIteratorException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETPMPSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETPMPSITERATOREXCEPTION$0);
            }
            target.set(getPmpsIteratorException);
        }
    }
    
    /**
     * Appends and returns a new empty "getPmpsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType addNewGetPmpsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETPMPSITERATOREXCEPTION$0);
            return target;
        }
    }
}
