/*
 * An XML document type.
 * Localname: getPmDataIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetPmDataIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getPmDataIteratorRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetPmDataIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetPmDataIteratorRequestDocument
{
    
    public GetPmDataIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPMDATAITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getPmDataIteratorRequest");
    
    
    /**
     * Gets the "getPmDataIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getGetPmDataIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETPMDATAITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPmDataIteratorRequest" element
     */
    public void setGetPmDataIteratorRequest(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType getPmDataIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().find_element_user(GETPMDATAITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETPMDATAITERATORREQUEST$0);
            }
            target.set(getPmDataIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getPmDataIteratorRequest" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType addNewGetPmDataIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorRequestType)get_store().add_element_user(GETPMDATAITERATORREQUEST$0);
            return target;
        }
    }
}
