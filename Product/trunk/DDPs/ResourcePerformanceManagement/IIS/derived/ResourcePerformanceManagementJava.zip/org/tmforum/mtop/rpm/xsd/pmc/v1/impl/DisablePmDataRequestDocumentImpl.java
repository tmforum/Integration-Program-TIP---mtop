/*
 * An XML document type.
 * Localname: disablePmDataRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmc/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmc.v1.impl;
/**
 * A document containing one disablePmDataRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1) element.
 *
 * This is a complex type.
 */
public class DisablePmDataRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument
{
    
    public DisablePmDataRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DISABLEPMDATAREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "disablePmDataRequest");
    
    
    /**
     * Gets the "disablePmDataRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest getDisablePmDataRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest)get_store().find_element_user(DISABLEPMDATAREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "disablePmDataRequest" element
     */
    public void setDisablePmDataRequest(org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest disablePmDataRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest)get_store().find_element_user(DISABLEPMDATAREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest)get_store().add_element_user(DISABLEPMDATAREQUEST$0);
            }
            target.set(disablePmDataRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "disablePmDataRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest addNewDisablePmDataRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest)get_store().add_element_user(DISABLEPMDATAREQUEST$0);
            return target;
        }
    }
    /**
     * An XML disablePmDataRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1).
     *
     * This is a complex type.
     */
    public static class DisablePmDataRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataRequestDocument.DisablePmDataRequest
    {
        
        public DisablePmDataRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PMTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "pmTpSelectList");
        
        
        /**
         * Gets the "pmTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmTpSelectList" element
         */
        public boolean isSetPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "pmTpSelectList" element
         */
        public void setPmTpSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType pmTpSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMTPSELECTLIST$0);
                }
                target.set(pmTpSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "pmTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "pmTpSelectList" element
         */
        public void unsetPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMTPSELECTLIST$0, 0);
            }
        }
    }
}
