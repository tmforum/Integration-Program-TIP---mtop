/*
 * An XML document type.
 * Localname: getAllCurrentPmDataResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getAllCurrentPmDataResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllCurrentPmDataResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataResponseDocument
{
    
    public GetAllCurrentPmDataResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLCURRENTPMDATARESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getAllCurrentPmDataResponse");
    
    
    /**
     * Gets the "getAllCurrentPmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType getGetAllCurrentPmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType)get_store().find_element_user(GETALLCURRENTPMDATARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllCurrentPmDataResponse" element
     */
    public void setGetAllCurrentPmDataResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType getAllCurrentPmDataResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType)get_store().find_element_user(GETALLCURRENTPMDATARESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType)get_store().add_element_user(GETALLCURRENTPMDATARESPONSE$0);
            }
            target.set(getAllCurrentPmDataResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllCurrentPmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType addNewGetAllCurrentPmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType)get_store().add_element_user(GETALLCURRENTPMDATARESPONSE$0);
            return target;
        }
    }
}
