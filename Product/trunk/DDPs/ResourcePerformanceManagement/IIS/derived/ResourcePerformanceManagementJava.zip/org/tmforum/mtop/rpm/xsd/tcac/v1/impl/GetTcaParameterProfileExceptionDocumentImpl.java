/*
 * An XML document type.
 * Localname: getTcaParameterProfileException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getTcaParameterProfileException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetTcaParameterProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument
{
    
    public GetTcaParameterProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTCAPARAMETERPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getTcaParameterProfileException");
    
    
    /**
     * Gets the "getTcaParameterProfileException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException getGetTcaParameterProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException)get_store().find_element_user(GETTCAPARAMETERPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getTcaParameterProfileException" element
     */
    public void setGetTcaParameterProfileException(org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException getTcaParameterProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException)get_store().find_element_user(GETTCAPARAMETERPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException)get_store().add_element_user(GETTCAPARAMETERPROFILEEXCEPTION$0);
            }
            target.set(getTcaParameterProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "getTcaParameterProfileException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException addNewGetTcaParameterProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException)get_store().add_element_user(GETTCAPARAMETERPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getTcaParameterProfileException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetTcaParameterProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileExceptionDocument.GetTcaParameterProfileException
    {
        
        public GetTcaParameterProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
