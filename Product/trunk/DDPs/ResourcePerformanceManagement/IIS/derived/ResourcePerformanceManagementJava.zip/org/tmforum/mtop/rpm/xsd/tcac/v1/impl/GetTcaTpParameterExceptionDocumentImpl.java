/*
 * An XML document type.
 * Localname: getTcaTpParameterException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getTcaTpParameterException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetTcaTpParameterExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument
{
    
    public GetTcaTpParameterExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTCATPPARAMETEREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getTcaTpParameterException");
    
    
    /**
     * Gets the "getTcaTpParameterException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException getGetTcaTpParameterException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException)get_store().find_element_user(GETTCATPPARAMETEREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getTcaTpParameterException" element
     */
    public void setGetTcaTpParameterException(org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException getTcaTpParameterException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException)get_store().find_element_user(GETTCATPPARAMETEREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException)get_store().add_element_user(GETTCATPPARAMETEREXCEPTION$0);
            }
            target.set(getTcaTpParameterException);
        }
    }
    
    /**
     * Appends and returns a new empty "getTcaTpParameterException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException addNewGetTcaTpParameterException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException)get_store().add_element_user(GETTCATPPARAMETEREXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getTcaTpParameterException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetTcaTpParameterExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterExceptionDocument.GetTcaTpParameterException
    {
        
        public GetTcaTpParameterExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
