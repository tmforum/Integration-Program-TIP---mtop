/*
 * XML Type:  X721.StateType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.X721StateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1.impl;
/**
 * An XML X721.StateType(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
 *
 * This is a complex type.
 */
public class X721StateTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.itu.v1.X721StateType
{
    
    public X721StateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName X721OPERATIONALSTATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "X721.OperationalState");
    private static final javax.xml.namespace.QName X721ADMINISTRATIVESTATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "X721.AdministrativeState");
    private static final javax.xml.namespace.QName X721USAGESTATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "X721.UsageState");
    private static final javax.xml.namespace.QName X721AVAILABILITYSTATUS$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "X721.AvailabilityStatus");
    private static final javax.xml.namespace.QName X721CONTROLSTATUS$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "X721.ControlStatus");
    private static final javax.xml.namespace.QName M3100HOLDERSTATUS$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "M3100.HolderStatus");
    private static final javax.xml.namespace.QName M3100ALARMSTATUS$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "M3100.AlarmStatus");
    private static final javax.xml.namespace.QName M3100ARCSTATE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "M3100.ArcState");
    private static final javax.xml.namespace.QName M3100ARCQISTATUS$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "M3100.ArcQIStatus");
    private static final javax.xml.namespace.QName X721UNKOWNSTATUS$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/itu/v1", "X721.Unkownstatus");
    
    
    /**
     * Gets the "X721.OperationalState" element
     */
    public boolean getX721OperationalState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721OPERATIONALSTATE$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "X721.OperationalState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType xgetX721OperationalState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType)get_store().find_element_user(X721OPERATIONALSTATE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "X721.OperationalState" element
     */
    public boolean isSetX721OperationalState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X721OPERATIONALSTATE$0) != 0;
        }
    }
    
    /**
     * Sets the "X721.OperationalState" element
     */
    public void setX721OperationalState(boolean x721OperationalState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721OPERATIONALSTATE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X721OPERATIONALSTATE$0);
            }
            target.setBooleanValue(x721OperationalState);
        }
    }
    
    /**
     * Sets (as xml) the "X721.OperationalState" element
     */
    public void xsetX721OperationalState(org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType x721OperationalState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType)get_store().find_element_user(X721OPERATIONALSTATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType)get_store().add_element_user(X721OPERATIONALSTATE$0);
            }
            target.set(x721OperationalState);
        }
    }
    
    /**
     * Unsets the "X721.OperationalState" element
     */
    public void unsetX721OperationalState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X721OPERATIONALSTATE$0, 0);
        }
    }
    
    /**
     * Gets the "X721.AdministrativeState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum getX721AdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721ADMINISTRATIVESTATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "X721.AdministrativeState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType xgetX721AdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(X721ADMINISTRATIVESTATE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "X721.AdministrativeState" element
     */
    public boolean isSetX721AdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X721ADMINISTRATIVESTATE$2) != 0;
        }
    }
    
    /**
     * Sets the "X721.AdministrativeState" element
     */
    public void setX721AdministrativeState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType.Enum x721AdministrativeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721ADMINISTRATIVESTATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X721ADMINISTRATIVESTATE$2);
            }
            target.setEnumValue(x721AdministrativeState);
        }
    }
    
    /**
     * Sets (as xml) the "X721.AdministrativeState" element
     */
    public void xsetX721AdministrativeState(org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType x721AdministrativeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().find_element_user(X721ADMINISTRATIVESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AdministrativeStateType)get_store().add_element_user(X721ADMINISTRATIVESTATE$2);
            }
            target.set(x721AdministrativeState);
        }
    }
    
    /**
     * Unsets the "X721.AdministrativeState" element
     */
    public void unsetX721AdministrativeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X721ADMINISTRATIVESTATE$2, 0);
        }
    }
    
    /**
     * Gets the "X721.UsageState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType.Enum getX721UsageState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721USAGESTATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "X721.UsageState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType xgetX721UsageState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType)get_store().find_element_user(X721USAGESTATE$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "X721.UsageState" element
     */
    public boolean isSetX721UsageState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X721USAGESTATE$4) != 0;
        }
    }
    
    /**
     * Sets the "X721.UsageState" element
     */
    public void setX721UsageState(org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType.Enum x721UsageState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721USAGESTATE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X721USAGESTATE$4);
            }
            target.setEnumValue(x721UsageState);
        }
    }
    
    /**
     * Sets (as xml) the "X721.UsageState" element
     */
    public void xsetX721UsageState(org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType x721UsageState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType)get_store().find_element_user(X721USAGESTATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721UsageStateType)get_store().add_element_user(X721USAGESTATE$4);
            }
            target.set(x721UsageState);
        }
    }
    
    /**
     * Unsets the "X721.UsageState" element
     */
    public void unsetX721UsageState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X721USAGESTATE$4, 0);
        }
    }
    
    /**
     * Gets the "X721.AvailabilityStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType.Enum getX721AvailabilityStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721AVAILABILITYSTATUS$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "X721.AvailabilityStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType xgetX721AvailabilityStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType)get_store().find_element_user(X721AVAILABILITYSTATUS$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "X721.AvailabilityStatus" element
     */
    public boolean isSetX721AvailabilityStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X721AVAILABILITYSTATUS$6) != 0;
        }
    }
    
    /**
     * Sets the "X721.AvailabilityStatus" element
     */
    public void setX721AvailabilityStatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType.Enum x721AvailabilityStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721AVAILABILITYSTATUS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X721AVAILABILITYSTATUS$6);
            }
            target.setEnumValue(x721AvailabilityStatus);
        }
    }
    
    /**
     * Sets (as xml) the "X721.AvailabilityStatus" element
     */
    public void xsetX721AvailabilityStatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType x721AvailabilityStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType)get_store().find_element_user(X721AVAILABILITYSTATUS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType)get_store().add_element_user(X721AVAILABILITYSTATUS$6);
            }
            target.set(x721AvailabilityStatus);
        }
    }
    
    /**
     * Unsets the "X721.AvailabilityStatus" element
     */
    public void unsetX721AvailabilityStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X721AVAILABILITYSTATUS$6, 0);
        }
    }
    
    /**
     * Gets the "X721.ControlStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType.Enum getX721ControlStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721CONTROLSTATUS$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "X721.ControlStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType xgetX721ControlStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType)get_store().find_element_user(X721CONTROLSTATUS$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "X721.ControlStatus" element
     */
    public boolean isSetX721ControlStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X721CONTROLSTATUS$8) != 0;
        }
    }
    
    /**
     * Sets the "X721.ControlStatus" element
     */
    public void setX721ControlStatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType.Enum x721ControlStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721CONTROLSTATUS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X721CONTROLSTATUS$8);
            }
            target.setEnumValue(x721ControlStatus);
        }
    }
    
    /**
     * Sets (as xml) the "X721.ControlStatus" element
     */
    public void xsetX721ControlStatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType x721ControlStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType)get_store().find_element_user(X721CONTROLSTATUS$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721ControlStatusType)get_store().add_element_user(X721CONTROLSTATUS$8);
            }
            target.set(x721ControlStatus);
        }
    }
    
    /**
     * Unsets the "X721.ControlStatus" element
     */
    public void unsetX721ControlStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X721CONTROLSTATUS$8, 0);
        }
    }
    
    /**
     * Gets the "M3100.HolderStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType.Enum getM3100HolderStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(M3100HOLDERSTATUS$10, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "M3100.HolderStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType xgetM3100HolderStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType)get_store().find_element_user(M3100HOLDERSTATUS$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "M3100.HolderStatus" element
     */
    public boolean isSetM3100HolderStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(M3100HOLDERSTATUS$10) != 0;
        }
    }
    
    /**
     * Sets the "M3100.HolderStatus" element
     */
    public void setM3100HolderStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType.Enum m3100HolderStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(M3100HOLDERSTATUS$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(M3100HOLDERSTATUS$10);
            }
            target.setEnumValue(m3100HolderStatus);
        }
    }
    
    /**
     * Sets (as xml) the "M3100.HolderStatus" element
     */
    public void xsetM3100HolderStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType m3100HolderStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType)get_store().find_element_user(M3100HOLDERSTATUS$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100HolderStatusType)get_store().add_element_user(M3100HOLDERSTATUS$10);
            }
            target.set(m3100HolderStatus);
        }
    }
    
    /**
     * Unsets the "M3100.HolderStatus" element
     */
    public void unsetM3100HolderStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(M3100HOLDERSTATUS$10, 0);
        }
    }
    
    /**
     * Gets the "M3100.AlarmStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType.Enum getM3100AlarmStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(M3100ALARMSTATUS$12, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "M3100.AlarmStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType xgetM3100AlarmStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType)get_store().find_element_user(M3100ALARMSTATUS$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "M3100.AlarmStatus" element
     */
    public boolean isSetM3100AlarmStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(M3100ALARMSTATUS$12) != 0;
        }
    }
    
    /**
     * Sets the "M3100.AlarmStatus" element
     */
    public void setM3100AlarmStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType.Enum m3100AlarmStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(M3100ALARMSTATUS$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(M3100ALARMSTATUS$12);
            }
            target.setEnumValue(m3100AlarmStatus);
        }
    }
    
    /**
     * Sets (as xml) the "M3100.AlarmStatus" element
     */
    public void xsetM3100AlarmStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType m3100AlarmStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType)get_store().find_element_user(M3100ALARMSTATUS$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100AlarmStatusType)get_store().add_element_user(M3100ALARMSTATUS$12);
            }
            target.set(m3100AlarmStatus);
        }
    }
    
    /**
     * Unsets the "M3100.AlarmStatus" element
     */
    public void unsetM3100AlarmStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(M3100ALARMSTATUS$12, 0);
        }
    }
    
    /**
     * Gets the "M3100.ArcState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType.Enum getM3100ArcState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(M3100ARCSTATE$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "M3100.ArcState" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType xgetM3100ArcState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType)get_store().find_element_user(M3100ARCSTATE$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "M3100.ArcState" element
     */
    public boolean isSetM3100ArcState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(M3100ARCSTATE$14) != 0;
        }
    }
    
    /**
     * Sets the "M3100.ArcState" element
     */
    public void setM3100ArcState(org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType.Enum m3100ArcState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(M3100ARCSTATE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(M3100ARCSTATE$14);
            }
            target.setEnumValue(m3100ArcState);
        }
    }
    
    /**
     * Sets (as xml) the "M3100.ArcState" element
     */
    public void xsetM3100ArcState(org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType m3100ArcState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType)get_store().find_element_user(M3100ARCSTATE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcStateType)get_store().add_element_user(M3100ARCSTATE$14);
            }
            target.set(m3100ArcState);
        }
    }
    
    /**
     * Unsets the "M3100.ArcState" element
     */
    public void unsetM3100ArcState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(M3100ARCSTATE$14, 0);
        }
    }
    
    /**
     * Gets the "M3100.ArcQIStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType.Enum getM3100ArcQIStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(M3100ARCQISTATUS$16, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "M3100.ArcQIStatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType xgetM3100ArcQIStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType)get_store().find_element_user(M3100ARCQISTATUS$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "M3100.ArcQIStatus" element
     */
    public boolean isSetM3100ArcQIStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(M3100ARCQISTATUS$16) != 0;
        }
    }
    
    /**
     * Sets the "M3100.ArcQIStatus" element
     */
    public void setM3100ArcQIStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType.Enum m3100ArcQIStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(M3100ARCQISTATUS$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(M3100ARCQISTATUS$16);
            }
            target.setEnumValue(m3100ArcQIStatus);
        }
    }
    
    /**
     * Sets (as xml) the "M3100.ArcQIStatus" element
     */
    public void xsetM3100ArcQIStatus(org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType m3100ArcQIStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType)get_store().find_element_user(M3100ARCQISTATUS$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.M3100ArcQIStatusType)get_store().add_element_user(M3100ARCQISTATUS$16);
            }
            target.set(m3100ArcQIStatus);
        }
    }
    
    /**
     * Unsets the "M3100.ArcQIStatus" element
     */
    public void unsetM3100ArcQIStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(M3100ARCQISTATUS$16, 0);
        }
    }
    
    /**
     * Gets the "X721.Unkownstatus" element
     */
    public boolean getX721Unkownstatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721UNKOWNSTATUS$18, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "X721.Unkownstatus" element
     */
    public org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType xgetX721Unkownstatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType)get_store().find_element_user(X721UNKOWNSTATUS$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "X721.Unkownstatus" element
     */
    public boolean isSetX721Unkownstatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X721UNKOWNSTATUS$18) != 0;
        }
    }
    
    /**
     * Sets the "X721.Unkownstatus" element
     */
    public void setX721Unkownstatus(boolean x721Unkownstatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X721UNKOWNSTATUS$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X721UNKOWNSTATUS$18);
            }
            target.setBooleanValue(x721Unkownstatus);
        }
    }
    
    /**
     * Sets (as xml) the "X721.Unkownstatus" element
     */
    public void xsetX721Unkownstatus(org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType x721Unkownstatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType target = null;
            target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType)get_store().find_element_user(X721UNKOWNSTATUS$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType)get_store().add_element_user(X721UNKOWNSTATUS$18);
            }
            target.set(x721Unkownstatus);
        }
    }
    
    /**
     * Unsets the "X721.Unkownstatus" element
     */
    public void unsetX721Unkownstatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X721UNKOWNSTATUS$18, 0);
        }
    }
}
