/*
 * XML Type:  PmThresholdValueListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmtv/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmtv.v1.impl;
/**
 * An XML PmThresholdValueListType(@http://www.tmforum.org/mtop/nra/xsd/pmtv/v1).
 *
 * This is a complex type.
 */
public class PmThresholdValueListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType
{
    
    public PmThresholdValueListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMTHRESHOLDVALUE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmtv/v1", "pmThresholdValue");
    
    
    /**
     * Gets a List of "pmThresholdValue" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType> getPmThresholdValueList()
    {
        final class PmThresholdValueList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType>
        {
            public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType get(int i)
                { return PmThresholdValueListTypeImpl.this.getPmThresholdValueArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType set(int i, org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType o)
            {
                org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType old = PmThresholdValueListTypeImpl.this.getPmThresholdValueArray(i);
                PmThresholdValueListTypeImpl.this.setPmThresholdValueArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType o)
                { PmThresholdValueListTypeImpl.this.insertNewPmThresholdValue(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType old = PmThresholdValueListTypeImpl.this.getPmThresholdValueArray(i);
                PmThresholdValueListTypeImpl.this.removePmThresholdValue(i);
                return old;
            }
            
            public int size()
                { return PmThresholdValueListTypeImpl.this.sizeOfPmThresholdValueArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmThresholdValueList();
        }
    }
    
    /**
     * Gets array of all "pmThresholdValue" elements
     */
    public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType[] getPmThresholdValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMTHRESHOLDVALUE$0, targetList);
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType[] result = new org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pmThresholdValue" element
     */
    public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType getPmThresholdValueArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType)get_store().find_element_user(PMTHRESHOLDVALUE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pmThresholdValue" element
     */
    public int sizeOfPmThresholdValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMTHRESHOLDVALUE$0);
        }
    }
    
    /**
     * Sets array of all "pmThresholdValue" element
     */
    public void setPmThresholdValueArray(org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType[] pmThresholdValueArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmThresholdValueArray, PMTHRESHOLDVALUE$0);
        }
    }
    
    /**
     * Sets ith "pmThresholdValue" element
     */
    public void setPmThresholdValueArray(int i, org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType pmThresholdValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType)get_store().find_element_user(PMTHRESHOLDVALUE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmThresholdValue);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmThresholdValue" element
     */
    public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType insertNewPmThresholdValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType)get_store().insert_element_user(PMTHRESHOLDVALUE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmThresholdValue" element
     */
    public org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType addNewPmThresholdValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueType)get_store().add_element_user(PMTHRESHOLDVALUE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmThresholdValue" element
     */
    public void removePmThresholdValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMTHRESHOLDVALUE$0, i);
        }
    }
}
