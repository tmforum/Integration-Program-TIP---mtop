/*
 * XML Type:  X721.OperationalStateType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1.impl;
/**
 * An XML X721.OperationalStateType(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType.
 */
public class X721OperationalStateTypeImpl extends org.apache.xmlbeans.impl.values.JavaBooleanHolderEx implements org.tmforum.mtop.nrb.xsd.itu.v1.X721OperationalStateType
{
    
    public X721OperationalStateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected X721OperationalStateTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
