/*
 * An XML document type.
 * Localname: pmMeasurement
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmmsrt.v1.impl;
/**
 * A document containing one pmMeasurement(@http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1) element.
 *
 * This is a complex type.
 */
public class PmMeasurementDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementDocument
{
    
    public PmMeasurementDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMMEASUREMENT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1", "pmMeasurement");
    
    
    /**
     * Gets the "pmMeasurement" element
     */
    public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType getPmMeasurement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType)get_store().find_element_user(PMMEASUREMENT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pmMeasurement" element
     */
    public void setPmMeasurement(org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType pmMeasurement)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType)get_store().find_element_user(PMMEASUREMENT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType)get_store().add_element_user(PMMEASUREMENT$0);
            }
            target.set(pmMeasurement);
        }
    }
    
    /**
     * Appends and returns a new empty "pmMeasurement" element
     */
    public org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType addNewPmMeasurement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType)get_store().add_element_user(PMMEASUREMENT$0);
            return target;
        }
    }
}
