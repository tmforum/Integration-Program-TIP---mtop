/*
 * An XML document type.
 * Localname: getTcaTpParameterResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getTcaTpParameterResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetTcaTpParameterResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument
{
    
    public GetTcaTpParameterResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTCATPPARAMETERRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getTcaTpParameterResponse");
    
    
    /**
     * Gets the "getTcaTpParameterResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse getGetTcaTpParameterResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse)get_store().find_element_user(GETTCATPPARAMETERRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getTcaTpParameterResponse" element
     */
    public void setGetTcaTpParameterResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse getTcaTpParameterResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse)get_store().find_element_user(GETTCATPPARAMETERRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse)get_store().add_element_user(GETTCATPPARAMETERRESPONSE$0);
            }
            target.set(getTcaTpParameterResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getTcaTpParameterResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse addNewGetTcaTpParameterResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse)get_store().add_element_user(GETTCATPPARAMETERRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getTcaTpParameterResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetTcaTpParameterResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterResponseDocument.GetTcaTpParameterResponse
    {
        
        public GetTcaTpParameterResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TCAPARAMETER$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tcaParameter");
        
        
        /**
         * Gets the "tcaParameter" element
         */
        public org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType getTcaParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().find_element_user(TCAPARAMETER$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tcaParameter" element
         */
        public boolean isSetTcaParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TCAPARAMETER$0) != 0;
            }
        }
        
        /**
         * Sets the "tcaParameter" element
         */
        public void setTcaParameter(org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType tcaParameter)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().find_element_user(TCAPARAMETER$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().add_element_user(TCAPARAMETER$0);
                }
                target.set(tcaParameter);
            }
        }
        
        /**
         * Appends and returns a new empty "tcaParameter" element
         */
        public org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType addNewTcaParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().add_element_user(TCAPARAMETER$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tcaParameter" element
         */
        public void unsetTcaParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TCAPARAMETER$0, 0);
            }
        }
    }
}
