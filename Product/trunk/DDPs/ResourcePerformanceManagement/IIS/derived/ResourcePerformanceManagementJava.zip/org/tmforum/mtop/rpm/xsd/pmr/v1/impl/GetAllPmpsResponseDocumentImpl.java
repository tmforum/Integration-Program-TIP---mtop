/*
 * An XML document type.
 * Localname: getAllPmpsResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getAllPmpsResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllPmpsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsResponseDocument
{
    
    public GetAllPmpsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLPMPSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getAllPmpsResponse");
    
    
    /**
     * Gets the "getAllPmpsResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType getGetAllPmpsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType)get_store().find_element_user(GETALLPMPSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllPmpsResponse" element
     */
    public void setGetAllPmpsResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType getAllPmpsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType)get_store().find_element_user(GETALLPMPSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType)get_store().add_element_user(GETALLPMPSRESPONSE$0);
            }
            target.set(getAllPmpsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllPmpsResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType addNewGetAllPmpsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType)get_store().add_element_user(GETALLPMPSRESPONSE$0);
            return target;
        }
    }
}
