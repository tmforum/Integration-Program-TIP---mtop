/*
 * An XML document type.
 * Localname: getAllTcaParameterProfilesResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getAllTcaParameterProfilesResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetAllTcaParameterProfilesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesResponseDocument
{
    
    public GetAllTcaParameterProfilesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLTCAPARAMETERPROFILESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getAllTcaParameterProfilesResponse");
    
    
    /**
     * Gets the "getAllTcaParameterProfilesResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType getGetAllTcaParameterProfilesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType)get_store().find_element_user(GETALLTCAPARAMETERPROFILESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllTcaParameterProfilesResponse" element
     */
    public void setGetAllTcaParameterProfilesResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType getAllTcaParameterProfilesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType)get_store().find_element_user(GETALLTCAPARAMETERPROFILESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType)get_store().add_element_user(GETALLTCAPARAMETERPROFILESRESPONSE$0);
            }
            target.set(getAllTcaParameterProfilesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllTcaParameterProfilesResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType addNewGetAllTcaParameterProfilesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectsResponseType)get_store().add_element_user(GETALLTCAPARAMETERPROFILESRESPONSE$0);
            return target;
        }
    }
}
