/*
 * An XML document type.
 * Localname: disableTcaResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one disableTcaResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class DisableTcaResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument
{
    
    public DisableTcaResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DISABLETCARESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "disableTcaResponse");
    
    
    /**
     * Gets the "disableTcaResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse getDisableTcaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse)get_store().find_element_user(DISABLETCARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "disableTcaResponse" element
     */
    public void setDisableTcaResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse disableTcaResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse)get_store().find_element_user(DISABLETCARESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse)get_store().add_element_user(DISABLETCARESPONSE$0);
            }
            target.set(disableTcaResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "disableTcaResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse addNewDisableTcaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse)get_store().add_element_user(DISABLETCARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML disableTcaResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class DisableTcaResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaResponseDocument.DisableTcaResponse
    {
        
        public DisableTcaResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FAILEDTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "failedTPSelectList");
        
        
        /**
         * Gets the "failedTPSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "failedTPSelectList" element
         */
        public boolean isSetFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILEDTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "failedTPSelectList" element
         */
        public void setFailedTPSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType failedTPSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                }
                target.set(failedTPSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "failedTPSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "failedTPSelectList" element
         */
        public void unsetFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILEDTPSELECTLIST$0, 0);
            }
        }
    }
}
