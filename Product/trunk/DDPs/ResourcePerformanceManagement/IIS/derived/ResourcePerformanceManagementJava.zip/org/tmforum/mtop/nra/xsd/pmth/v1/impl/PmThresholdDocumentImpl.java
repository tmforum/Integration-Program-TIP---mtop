/*
 * An XML document type.
 * Localname: pmThreshold
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmth/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmth.v1.impl;
/**
 * A document containing one pmThreshold(@http://www.tmforum.org/mtop/nra/xsd/pmth/v1) element.
 *
 * This is a complex type.
 */
public class PmThresholdDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdDocument
{
    
    public PmThresholdDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMTHRESHOLD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmth/v1", "pmThreshold");
    
    
    /**
     * Gets the "pmThreshold" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType getPmThreshold()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().find_element_user(PMTHRESHOLD$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pmThreshold" element
     */
    public void setPmThreshold(org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType pmThreshold)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().find_element_user(PMTHRESHOLD$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().add_element_user(PMTHRESHOLD$0);
            }
            target.set(pmThreshold);
        }
    }
    
    /**
     * Appends and returns a new empty "pmThreshold" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType addNewPmThreshold()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().add_element_user(PMTHRESHOLD$0);
            return target;
        }
    }
}
