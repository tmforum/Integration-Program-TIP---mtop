/*
 * An XML document type.
 * Localname: getAllPmpNamesException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getAllPmpNamesException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllPmpNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument
{
    
    public GetAllPmpNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLPMPNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getAllPmpNamesException");
    
    
    /**
     * Gets the "getAllPmpNamesException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException getGetAllPmpNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException)get_store().find_element_user(GETALLPMPNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllPmpNamesException" element
     */
    public void setGetAllPmpNamesException(org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException getAllPmpNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException)get_store().find_element_user(GETALLPMPNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException)get_store().add_element_user(GETALLPMPNAMESEXCEPTION$0);
            }
            target.set(getAllPmpNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllPmpNamesException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException addNewGetAllPmpNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException)get_store().add_element_user(GETALLPMPNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllPmpNamesException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllPmpNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesExceptionDocument.GetAllPmpNamesException
    {
        
        public GetAllPmpNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
