/*
 * An XML document type.
 * Localname: deleteTcaParameterProfileException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one deleteTcaParameterProfileException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class DeleteTcaParameterProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument
{
    
    public DeleteTcaParameterProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETETCAPARAMETERPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "deleteTcaParameterProfileException");
    
    
    /**
     * Gets the "deleteTcaParameterProfileException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException getDeleteTcaParameterProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException)get_store().find_element_user(DELETETCAPARAMETERPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteTcaParameterProfileException" element
     */
    public void setDeleteTcaParameterProfileException(org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException deleteTcaParameterProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException)get_store().find_element_user(DELETETCAPARAMETERPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException)get_store().add_element_user(DELETETCAPARAMETERPROFILEEXCEPTION$0);
            }
            target.set(deleteTcaParameterProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteTcaParameterProfileException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException addNewDeleteTcaParameterProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException)get_store().add_element_user(DELETETCAPARAMETERPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deleteTcaParameterProfileException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class DeleteTcaParameterProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileExceptionDocument.DeleteTcaParameterProfileException
    {
        
        public DeleteTcaParameterProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
