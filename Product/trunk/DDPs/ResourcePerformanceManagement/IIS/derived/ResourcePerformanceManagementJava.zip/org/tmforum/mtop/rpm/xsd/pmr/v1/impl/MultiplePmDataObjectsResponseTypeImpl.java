/*
 * XML Type:  MultiplePmDataObjectsResponseType
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * An XML MultiplePmDataObjectsResponseType(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
 *
 * This is a complex type.
 */
public class MultiplePmDataObjectsResponseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType
{
    
    public MultiplePmDataObjectsResponseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMDATALIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "pmDataList");
    
    
    /**
     * Gets the "pmDataList" element
     */
    public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType getPmDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType)get_store().find_element_user(PMDATALIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "pmDataList" element
     */
    public boolean isSetPmDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMDATALIST$0) != 0;
        }
    }
    
    /**
     * Sets the "pmDataList" element
     */
    public void setPmDataList(org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType pmDataList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType)get_store().find_element_user(PMDATALIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType)get_store().add_element_user(PMDATALIST$0);
            }
            target.set(pmDataList);
        }
    }
    
    /**
     * Appends and returns a new empty "pmDataList" element
     */
    public org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType addNewPmDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmdata.v1.PmDataListType)get_store().add_element_user(PMDATALIST$0);
            return target;
        }
    }
    
    /**
     * Unsets the "pmDataList" element
     */
    public void unsetPmDataList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMDATALIST$0, 0);
        }
    }
}
