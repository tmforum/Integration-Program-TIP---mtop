/*
 * An XML document type.
 * Localname: createTcaParameterProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1;


/**
 * A document containing one createTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public interface CreateTcaParameterProfileRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateTcaParameterProfileRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s7C5F0157FFA8BEFD0B6FA87BDFBDB36E").resolveHandle("createtcaparameterprofilerequest1258doctype");
    
    /**
     * Gets the "createTcaParameterProfileRequest" element
     */
    org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest getCreateTcaParameterProfileRequest();
    
    /**
     * Sets the "createTcaParameterProfileRequest" element
     */
    void setCreateTcaParameterProfileRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest createTcaParameterProfileRequest);
    
    /**
     * Appends and returns a new empty "createTcaParameterProfileRequest" element
     */
    org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest addNewCreateTcaParameterProfileRequest();
    
    /**
     * An XML createTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public interface CreateTcaParameterProfileRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateTcaParameterProfileRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s7C5F0157FFA8BEFD0B6FA87BDFBDB36E").resolveHandle("createtcaparameterprofilerequest1683elemtype");
        
        /**
         * Gets the "meName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMeName();
        
        /**
         * True if has "meName" element
         */
        boolean isSetMeName();
        
        /**
         * Sets the "meName" element
         */
        void setMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType meName);
        
        /**
         * Appends and returns a new empty "meName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMeName();
        
        /**
         * Unsets the "meName" element
         */
        void unsetMeName();
        
        /**
         * Gets the "layer" element
         */
        org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayer();
        
        /**
         * True if has "layer" element
         */
        boolean isSetLayer();
        
        /**
         * Sets the "layer" element
         */
        void setLayer(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layer);
        
        /**
         * Appends and returns a new empty "layer" element
         */
        org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayer();
        
        /**
         * Unsets the "layer" element
         */
        void unsetLayer();
        
        /**
         * Gets the "userLabel" element
         */
        java.lang.String getUserLabel();
        
        /**
         * Gets (as xml) the "userLabel" element
         */
        org.apache.xmlbeans.XmlString xgetUserLabel();
        
        /**
         * True if has "userLabel" element
         */
        boolean isSetUserLabel();
        
        /**
         * Sets the "userLabel" element
         */
        void setUserLabel(java.lang.String userLabel);
        
        /**
         * Sets (as xml) the "userLabel" element
         */
        void xsetUserLabel(org.apache.xmlbeans.XmlString userLabel);
        
        /**
         * Unsets the "userLabel" element
         */
        void unsetUserLabel();
        
        /**
         * Gets the "forceUniqueness" element
         */
        java.lang.String getForceUniqueness();
        
        /**
         * Gets (as xml) the "forceUniqueness" element
         */
        org.apache.xmlbeans.XmlString xgetForceUniqueness();
        
        /**
         * True if has "forceUniqueness" element
         */
        boolean isSetForceUniqueness();
        
        /**
         * Sets the "forceUniqueness" element
         */
        void setForceUniqueness(java.lang.String forceUniqueness);
        
        /**
         * Sets (as xml) the "forceUniqueness" element
         */
        void xsetForceUniqueness(org.apache.xmlbeans.XmlString forceUniqueness);
        
        /**
         * Unsets the "forceUniqueness" element
         */
        void unsetForceUniqueness();
        
        /**
         * Gets the "owner" element
         */
        java.lang.String getOwner();
        
        /**
         * Gets (as xml) the "owner" element
         */
        org.apache.xmlbeans.XmlString xgetOwner();
        
        /**
         * True if has "owner" element
         */
        boolean isSetOwner();
        
        /**
         * Sets the "owner" element
         */
        void setOwner(java.lang.String owner);
        
        /**
         * Sets (as xml) the "owner" element
         */
        void xsetOwner(org.apache.xmlbeans.XmlString owner);
        
        /**
         * Unsets the "owner" element
         */
        void unsetOwner();
        
        /**
         * Gets the "vendorExtensions" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        boolean isNilVendorExtensions();
        
        /**
         * True if has "vendorExtensions" element
         */
        boolean isSetVendorExtensions();
        
        /**
         * Sets the "vendorExtensions" element
         */
        void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
        
        /**
         * Nils the "vendorExtensions" element
         */
        void setNilVendorExtensions();
        
        /**
         * Unsets the "vendorExtensions" element
         */
        void unsetVendorExtensions();
        
        /**
         * Gets the "listOfTCAParameter" element
         */
        org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType getListOfTCAParameter();
        
        /**
         * True if has "listOfTCAParameter" element
         */
        boolean isSetListOfTCAParameter();
        
        /**
         * Sets the "listOfTCAParameter" element
         */
        void setListOfTCAParameter(org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType listOfTCAParameter);
        
        /**
         * Appends and returns a new empty "listOfTCAParameter" element
         */
        org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType addNewListOfTCAParameter();
        
        /**
         * Unsets the "listOfTCAParameter" element
         */
        void unsetListOfTCAParameter();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest newInstance() {
              return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument newInstance() {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
