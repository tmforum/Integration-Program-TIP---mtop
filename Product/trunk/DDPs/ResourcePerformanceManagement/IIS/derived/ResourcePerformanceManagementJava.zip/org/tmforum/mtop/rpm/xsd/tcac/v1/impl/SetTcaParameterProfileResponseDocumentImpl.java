/*
 * An XML document type.
 * Localname: setTcaParameterProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one setTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class SetTcaParameterProfileResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument
{
    
    public SetTcaParameterProfileResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETTCAPARAMETERPROFILERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "setTcaParameterProfileResponse");
    
    
    /**
     * Gets the "setTcaParameterProfileResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse getSetTcaParameterProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse)get_store().find_element_user(SETTCAPARAMETERPROFILERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setTcaParameterProfileResponse" element
     */
    public void setSetTcaParameterProfileResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse setTcaParameterProfileResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse)get_store().find_element_user(SETTCAPARAMETERPROFILERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse)get_store().add_element_user(SETTCAPARAMETERPROFILERESPONSE$0);
            }
            target.set(setTcaParameterProfileResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setTcaParameterProfileResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse addNewSetTcaParameterProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse)get_store().add_element_user(SETTCAPARAMETERPROFILERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class SetTcaParameterProfileResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileResponseDocument.SetTcaParameterProfileResponse
    {
        
        public SetTcaParameterProfileResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FAILEDTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "failedTpSelectList");
        
        
        /**
         * Gets the "failedTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "failedTpSelectList" element
         */
        public boolean isSetFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILEDTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "failedTpSelectList" element
         */
        public void setFailedTpSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType failedTpSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                }
                target.set(failedTpSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "failedTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "failedTpSelectList" element
         */
        public void unsetFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILEDTPSELECTLIST$0, 0);
            }
        }
    }
}
