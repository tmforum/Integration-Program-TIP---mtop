/*
 * An XML document type.
 * Localname: getTcaParameterProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetTcaParameterProfileResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument
{
    
    public GetTcaParameterProfileResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTCAPARAMETERPROFILERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getTcaParameterProfileResponse");
    
    
    /**
     * Gets the "getTcaParameterProfileResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse getGetTcaParameterProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse)get_store().find_element_user(GETTCAPARAMETERPROFILERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getTcaParameterProfileResponse" element
     */
    public void setGetTcaParameterProfileResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse getTcaParameterProfileResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse)get_store().find_element_user(GETTCAPARAMETERPROFILERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse)get_store().add_element_user(GETTCAPARAMETERPROFILERESPONSE$0);
            }
            target.set(getTcaParameterProfileResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getTcaParameterProfileResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse addNewGetTcaParameterProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse)get_store().add_element_user(GETTCAPARAMETERPROFILERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetTcaParameterProfileResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaParameterProfileResponseDocument.GetTcaParameterProfileResponse
    {
        
        public GetTcaParameterProfileResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TCAPARAMETERPROFILE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tcaParameterProfile");
        
        
        /**
         * Gets the "tcaParameterProfile" element
         */
        public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType getTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().find_element_user(TCAPARAMETERPROFILE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tcaParameterProfile" element
         */
        public boolean isSetTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TCAPARAMETERPROFILE$0) != 0;
            }
        }
        
        /**
         * Sets the "tcaParameterProfile" element
         */
        public void setTcaParameterProfile(org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType tcaParameterProfile)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().find_element_user(TCAPARAMETERPROFILE$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().add_element_user(TCAPARAMETERPROFILE$0);
                }
                target.set(tcaParameterProfile);
            }
        }
        
        /**
         * Appends and returns a new empty "tcaParameterProfile" element
         */
        public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType addNewTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().add_element_user(TCAPARAMETERPROFILE$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tcaParameterProfile" element
         */
        public void unsetTcaParameterProfile()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TCAPARAMETERPROFILE$0, 0);
            }
        }
    }
}
