/*
 * An XML document type.
 * Localname: getAllTcaParameterProfileNamesResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getAllTcaParameterProfileNamesResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetAllTcaParameterProfileNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesResponseDocument
{
    
    public GetAllTcaParameterProfileNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLTCAPARAMETERPROFILENAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getAllTcaParameterProfileNamesResponse");
    
    
    /**
     * Gets the "getAllTcaParameterProfileNamesResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType getGetAllTcaParameterProfileNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType)get_store().find_element_user(GETALLTCAPARAMETERPROFILENAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllTcaParameterProfileNamesResponse" element
     */
    public void setGetAllTcaParameterProfileNamesResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType getAllTcaParameterProfileNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType)get_store().find_element_user(GETALLTCAPARAMETERPROFILENAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType)get_store().add_element_user(GETALLTCAPARAMETERPROFILENAMESRESPONSE$0);
            }
            target.set(getAllTcaParameterProfileNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllTcaParameterProfileNamesResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType addNewGetAllTcaParameterProfileNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.MultipleTcaParameterProfileObjectNamesResponseType)get_store().add_element_user(GETALLTCAPARAMETERPROFILENAMESRESPONSE$0);
            return target;
        }
    }
}
