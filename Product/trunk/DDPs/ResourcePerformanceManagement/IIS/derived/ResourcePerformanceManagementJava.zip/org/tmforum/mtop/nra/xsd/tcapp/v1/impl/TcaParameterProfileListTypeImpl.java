/*
 * XML Type:  TcaParameterProfileListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcapp/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcapp.v1.impl;
/**
 * An XML TcaParameterProfileListType(@http://www.tmforum.org/mtop/nra/xsd/tcapp/v1).
 *
 * This is a complex type.
 */
public class TcaParameterProfileListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileListType
{
    
    public TcaParameterProfileListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TCAPARAMETERPROFILELIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapp/v1", "tcaParameterProfileList");
    
    
    /**
     * Gets a List of "tcaParameterProfileList" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType> getTcaParameterProfileListList()
    {
        final class TcaParameterProfileListList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType>
        {
            public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType get(int i)
                { return TcaParameterProfileListTypeImpl.this.getTcaParameterProfileListArray(i); }
            
            public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType set(int i, org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType o)
            {
                org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType old = TcaParameterProfileListTypeImpl.this.getTcaParameterProfileListArray(i);
                TcaParameterProfileListTypeImpl.this.setTcaParameterProfileListArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType o)
                { TcaParameterProfileListTypeImpl.this.insertNewTcaParameterProfileList(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType old = TcaParameterProfileListTypeImpl.this.getTcaParameterProfileListArray(i);
                TcaParameterProfileListTypeImpl.this.removeTcaParameterProfileList(i);
                return old;
            }
            
            public int size()
                { return TcaParameterProfileListTypeImpl.this.sizeOfTcaParameterProfileListArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TcaParameterProfileListList();
        }
    }
    
    /**
     * Gets array of all "tcaParameterProfileList" elements
     */
    public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType[] getTcaParameterProfileListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TCAPARAMETERPROFILELIST$0, targetList);
            org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType[] result = new org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "tcaParameterProfileList" element
     */
    public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType getTcaParameterProfileListArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().find_element_user(TCAPARAMETERPROFILELIST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "tcaParameterProfileList" element
     */
    public int sizeOfTcaParameterProfileListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TCAPARAMETERPROFILELIST$0);
        }
    }
    
    /**
     * Sets array of all "tcaParameterProfileList" element
     */
    public void setTcaParameterProfileListArray(org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType[] tcaParameterProfileListArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(tcaParameterProfileListArray, TCAPARAMETERPROFILELIST$0);
        }
    }
    
    /**
     * Sets ith "tcaParameterProfileList" element
     */
    public void setTcaParameterProfileListArray(int i, org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType tcaParameterProfileList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().find_element_user(TCAPARAMETERPROFILELIST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(tcaParameterProfileList);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tcaParameterProfileList" element
     */
    public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType insertNewTcaParameterProfileList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().insert_element_user(TCAPARAMETERPROFILELIST$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tcaParameterProfileList" element
     */
    public org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType addNewTcaParameterProfileList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType)get_store().add_element_user(TCAPARAMETERPROFILELIST$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "tcaParameterProfileList" element
     */
    public void removeTcaParameterProfileList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TCAPARAMETERPROFILELIST$0, i);
        }
    }
}
