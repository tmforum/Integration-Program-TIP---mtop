/*
 * XML Type:  PmParameterNameListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pm/v1
 * Java type: org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pm.v1.impl;
/**
 * An XML PmParameterNameListType(@http://www.tmforum.org/mtop/nra/xsd/pm/v1).
 *
 * This is a complex type.
 */
public class PmParameterNameListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType
{
    
    public PmParameterNameListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETERNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pm/v1", "pmParameterName");
    
    
    /**
     * Gets a List of "pmParameterName" elements
     */
    public java.util.List<java.lang.String> getPmParameterNameList()
    {
        final class PmParameterNameList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return PmParameterNameListTypeImpl.this.getPmParameterNameArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = PmParameterNameListTypeImpl.this.getPmParameterNameArray(i);
                PmParameterNameListTypeImpl.this.setPmParameterNameArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { PmParameterNameListTypeImpl.this.insertPmParameterName(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = PmParameterNameListTypeImpl.this.getPmParameterNameArray(i);
                PmParameterNameListTypeImpl.this.removePmParameterName(i);
                return old;
            }
            
            public int size()
                { return PmParameterNameListTypeImpl.this.sizeOfPmParameterNameArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmParameterNameList();
        }
    }
    
    /**
     * Gets array of all "pmParameterName" elements
     */
    public java.lang.String[] getPmParameterNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMPARAMETERNAME$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "pmParameterName" element
     */
    public java.lang.String getPmParameterNameArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "pmParameterName" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType> xgetPmParameterNameList()
    {
        final class PmParameterNameList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType get(int i)
                { return PmParameterNameListTypeImpl.this.xgetPmParameterNameArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType old = PmParameterNameListTypeImpl.this.xgetPmParameterNameArray(i);
                PmParameterNameListTypeImpl.this.xsetPmParameterNameArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType o)
                { PmParameterNameListTypeImpl.this.insertNewPmParameterName(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType old = PmParameterNameListTypeImpl.this.xgetPmParameterNameArray(i);
                PmParameterNameListTypeImpl.this.removePmParameterName(i);
                return old;
            }
            
            public int size()
                { return PmParameterNameListTypeImpl.this.sizeOfPmParameterNameArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmParameterNameList();
        }
    }
    
    /**
     * Gets (as xml) array of all "pmParameterName" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[] xgetPmParameterNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMPARAMETERNAME$0, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterNameArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)target;
        }
    }
    
    /**
     * Returns number of "pmParameterName" element
     */
    public int sizeOfPmParameterNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETERNAME$0);
        }
    }
    
    /**
     * Sets array of all "pmParameterName" element
     */
    public void setPmParameterNameArray(java.lang.String[] pmParameterNameArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmParameterNameArray, PMPARAMETERNAME$0);
        }
    }
    
    /**
     * Sets ith "pmParameterName" element
     */
    public void setPmParameterNameArray(int i, java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Sets (as xml) array of all "pmParameterName" element
     */
    public void xsetPmParameterNameArray(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType[]pmParameterNameArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmParameterNameArray, PMPARAMETERNAME$0);
        }
    }
    
    /**
     * Sets (as xml) ith "pmParameterName" element
     */
    public void xsetPmParameterNameArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmParameterName);
        }
    }
    
    /**
     * Inserts the value as the ith "pmParameterName" element
     */
    public void insertPmParameterName(int i, java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PMPARAMETERNAME$0, i);
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Appends the value as the last "pmParameterName" element
     */
    public void addPmParameterName(java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMPARAMETERNAME$0);
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType insertNewPmParameterName(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().insert_element_user(PMPARAMETERNAME$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType addNewPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmParameterName" element
     */
    public void removePmParameterName(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETERNAME$0, i);
        }
    }
}
