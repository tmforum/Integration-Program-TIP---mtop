/*
 * An XML document type.
 * Localname: getAllPmpNamesRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getAllPmpNamesRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllPmpNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument
{
    
    public GetAllPmpNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLPMPNAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getAllPmpNamesRequest");
    
    
    /**
     * Gets the "getAllPmpNamesRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest getGetAllPmpNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest)get_store().find_element_user(GETALLPMPNAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllPmpNamesRequest" element
     */
    public void setGetAllPmpNamesRequest(org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest getAllPmpNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest)get_store().find_element_user(GETALLPMPNAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest)get_store().add_element_user(GETALLPMPNAMESREQUEST$0);
            }
            target.set(getAllPmpNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllPmpNamesRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest addNewGetAllPmpNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest)get_store().add_element_user(GETALLPMPNAMESREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllPmpNamesRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllPmpNamesRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpNamesRequestDocument.GetAllPmpNamesRequest
    {
        
        public GetAllPmpNamesRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "tpName");
        
        
        /**
         * Gets the "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpName" element
         */
        public boolean isSetTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tpName" element
         */
        public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
                }
                target.set(tpName);
            }
        }
        
        /**
         * Appends and returns a new empty "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tpName" element
         */
        public void unsetTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPNAME$0, 0);
            }
        }
    }
}
