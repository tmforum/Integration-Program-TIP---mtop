/*
 * An XML document type.
 * Localname: enableTcaRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one enableTcaRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class EnableTcaRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument
{
    
    public EnableTcaRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENABLETCAREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "enableTcaRequest");
    
    
    /**
     * Gets the "enableTcaRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest getEnableTcaRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest)get_store().find_element_user(ENABLETCAREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "enableTcaRequest" element
     */
    public void setEnableTcaRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest enableTcaRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest)get_store().find_element_user(ENABLETCAREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest)get_store().add_element_user(ENABLETCAREQUEST$0);
            }
            target.set(enableTcaRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "enableTcaRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest addNewEnableTcaRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest)get_store().add_element_user(ENABLETCAREQUEST$0);
            return target;
        }
    }
    /**
     * An XML enableTcaRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class EnableTcaRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaRequestDocument.EnableTcaRequest
    {
        
        public EnableTcaRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PMTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "pmTpSelectList");
        
        
        /**
         * Gets the "pmTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmTpSelectList" element
         */
        public boolean isSetPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "pmTpSelectList" element
         */
        public void setPmTpSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType pmTpSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMTPSELECTLIST$0);
                }
                target.set(pmTpSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "pmTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "pmTpSelectList" element
         */
        public void unsetPmTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMTPSELECTLIST$0, 0);
            }
        }
    }
}
