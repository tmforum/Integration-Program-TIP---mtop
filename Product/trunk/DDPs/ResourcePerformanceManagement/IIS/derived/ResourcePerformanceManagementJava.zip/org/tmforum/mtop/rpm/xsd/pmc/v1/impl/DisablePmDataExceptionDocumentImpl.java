/*
 * An XML document type.
 * Localname: disablePmDataException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmc/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmc.v1.impl;
/**
 * A document containing one disablePmDataException(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1) element.
 *
 * This is a complex type.
 */
public class DisablePmDataExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument
{
    
    public DisablePmDataExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DISABLEPMDATAEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "disablePmDataException");
    
    
    /**
     * Gets the "disablePmDataException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException getDisablePmDataException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException)get_store().find_element_user(DISABLEPMDATAEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "disablePmDataException" element
     */
    public void setDisablePmDataException(org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException disablePmDataException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException)get_store().find_element_user(DISABLEPMDATAEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException)get_store().add_element_user(DISABLEPMDATAEXCEPTION$0);
            }
            target.set(disablePmDataException);
        }
    }
    
    /**
     * Appends and returns a new empty "disablePmDataException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException addNewDisablePmDataException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException)get_store().add_element_user(DISABLEPMDATAEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML disablePmDataException(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1).
     *
     * This is a complex type.
     */
    public static class DisablePmDataExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.DisablePmDataExceptionDocument.DisablePmDataException
    {
        
        public DisablePmDataExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
