/*
 * An XML document type.
 * Localname: enablePmDataResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmc/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmc.v1.impl;
/**
 * A document containing one enablePmDataResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1) element.
 *
 * This is a complex type.
 */
public class EnablePmDataResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument
{
    
    public EnablePmDataResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENABLEPMDATARESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "enablePmDataResponse");
    
    
    /**
     * Gets the "enablePmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse getEnablePmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse)get_store().find_element_user(ENABLEPMDATARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "enablePmDataResponse" element
     */
    public void setEnablePmDataResponse(org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse enablePmDataResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse)get_store().find_element_user(ENABLEPMDATARESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse)get_store().add_element_user(ENABLEPMDATARESPONSE$0);
            }
            target.set(enablePmDataResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "enablePmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse addNewEnablePmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse)get_store().add_element_user(ENABLEPMDATARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML enablePmDataResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1).
     *
     * This is a complex type.
     */
    public static class EnablePmDataResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.EnablePmDataResponseDocument.EnablePmDataResponse
    {
        
        public EnablePmDataResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FAILEDTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "failedTpSelectList");
        
        
        /**
         * Gets the "failedTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "failedTpSelectList" element
         */
        public boolean isSetFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILEDTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "failedTpSelectList" element
         */
        public void setFailedTpSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType failedTpSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                }
                target.set(failedTpSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "failedTpSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "failedTpSelectList" element
         */
        public void unsetFailedTpSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILEDTPSELECTLIST$0, 0);
            }
        }
    }
}
