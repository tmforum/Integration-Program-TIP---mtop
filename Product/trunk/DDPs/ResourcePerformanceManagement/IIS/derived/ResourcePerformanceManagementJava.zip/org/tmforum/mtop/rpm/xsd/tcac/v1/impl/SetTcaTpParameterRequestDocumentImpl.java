/*
 * An XML document type.
 * Localname: setTcaTpParameterRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one setTcaTpParameterRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class SetTcaTpParameterRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument
{
    
    public SetTcaTpParameterRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETTCATPPARAMETERREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "setTcaTpParameterRequest");
    
    
    /**
     * Gets the "setTcaTpParameterRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest getSetTcaTpParameterRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest)get_store().find_element_user(SETTCATPPARAMETERREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setTcaTpParameterRequest" element
     */
    public void setSetTcaTpParameterRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest setTcaTpParameterRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest)get_store().find_element_user(SETTCATPPARAMETERREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest)get_store().add_element_user(SETTCATPPARAMETERREQUEST$0);
            }
            target.set(setTcaTpParameterRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setTcaTpParameterRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest addNewSetTcaTpParameterRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest)get_store().add_element_user(SETTCATPPARAMETERREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setTcaTpParameterRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class SetTcaTpParameterRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterRequestDocument.SetTcaTpParameterRequest
    {
        
        public SetTcaTpParameterRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tpName");
        private static final javax.xml.namespace.QName TCAPARAMETERS$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tcaParameters");
        
        
        /**
         * Gets the "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpName" element
         */
        public boolean isSetTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tpName" element
         */
        public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
                }
                target.set(tpName);
            }
        }
        
        /**
         * Appends and returns a new empty "tpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tpName" element
         */
        public void unsetTpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPNAME$0, 0);
            }
        }
        
        /**
         * Gets the "tcaParameters" element
         */
        public org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType getTcaParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().find_element_user(TCAPARAMETERS$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tcaParameters" element
         */
        public boolean isSetTcaParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TCAPARAMETERS$2) != 0;
            }
        }
        
        /**
         * Sets the "tcaParameters" element
         */
        public void setTcaParameters(org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType tcaParameters)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().find_element_user(TCAPARAMETERS$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().add_element_user(TCAPARAMETERS$2);
                }
                target.set(tcaParameters);
            }
        }
        
        /**
         * Appends and returns a new empty "tcaParameters" element
         */
        public org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType addNewTcaParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().add_element_user(TCAPARAMETERS$2);
                return target;
            }
        }
        
        /**
         * Unsets the "tcaParameters" element
         */
        public void unsetTcaParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TCAPARAMETERS$2, 0);
            }
        }
    }
}
