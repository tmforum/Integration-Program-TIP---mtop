/*
 * An XML document type.
 * Localname: getAllPmpsException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getAllPmpsException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllPmpsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument
{
    
    public GetAllPmpsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLPMPSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getAllPmpsException");
    
    
    /**
     * Gets the "getAllPmpsException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException getGetAllPmpsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException)get_store().find_element_user(GETALLPMPSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllPmpsException" element
     */
    public void setGetAllPmpsException(org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException getAllPmpsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException)get_store().find_element_user(GETALLPMPSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException)get_store().add_element_user(GETALLPMPSEXCEPTION$0);
            }
            target.set(getAllPmpsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllPmpsException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException addNewGetAllPmpsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException)get_store().add_element_user(GETALLPMPSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllPmpsException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllPmpsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllPmpsExceptionDocument.GetAllPmpsException
    {
        
        public GetAllPmpsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
