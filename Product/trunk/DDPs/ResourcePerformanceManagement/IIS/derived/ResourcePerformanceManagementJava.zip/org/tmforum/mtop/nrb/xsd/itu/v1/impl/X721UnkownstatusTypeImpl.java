/*
 * XML Type:  X721.UnkownstatusType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1.impl;
/**
 * An XML X721.UnkownstatusType(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType.
 */
public class X721UnkownstatusTypeImpl extends org.apache.xmlbeans.impl.values.JavaBooleanHolderEx implements org.tmforum.mtop.nrb.xsd.itu.v1.X721UnkownstatusType
{
    
    public X721UnkownstatusTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected X721UnkownstatusTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
