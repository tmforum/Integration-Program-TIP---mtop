/*
 * XML Type:  TcaParameterProfileType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcapp/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcapp.v1.impl;
/**
 * An XML TcaParameterProfileType(@http://www.tmforum.org/mtop/nra/xsd/tcapp/v1).
 *
 * This is a complex type.
 */
public class TcaParameterProfileTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType
{
    
    public TcaParameterProfileTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LAYERRATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapp/v1", "layerRate");
    private static final javax.xml.namespace.QName ASSOCIATEDTPREFLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapp/v1", "associatedTpRefList");
    private static final javax.xml.namespace.QName TCAPARAMETERLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapp/v1", "tcaParameterList");
    
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "layerRate" element
     */
    public boolean isNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$0) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            return target;
        }
    }
    
    /**
     * Nils the "layerRate" element
     */
    public void setNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$0, 0);
        }
    }
    
    /**
     * Gets the "associatedTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getAssociatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ASSOCIATEDTPREFLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "associatedTpRefList" element
     */
    public boolean isNilAssociatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ASSOCIATEDTPREFLIST$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "associatedTpRefList" element
     */
    public boolean isSetAssociatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASSOCIATEDTPREFLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "associatedTpRefList" element
     */
    public void setAssociatedTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType associatedTpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ASSOCIATEDTPREFLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(ASSOCIATEDTPREFLIST$2);
            }
            target.set(associatedTpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "associatedTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewAssociatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(ASSOCIATEDTPREFLIST$2);
            return target;
        }
    }
    
    /**
     * Nils the "associatedTpRefList" element
     */
    public void setNilAssociatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(ASSOCIATEDTPREFLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(ASSOCIATEDTPREFLIST$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "associatedTpRefList" element
     */
    public void unsetAssociatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASSOCIATEDTPREFLIST$2, 0);
        }
    }
    
    /**
     * Gets the "tcaParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType getTcaParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().find_element_user(TCAPARAMETERLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "tcaParameterList" element
     */
    public boolean isNilTcaParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().find_element_user(TCAPARAMETERLIST$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "tcaParameterList" element
     */
    public boolean isSetTcaParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TCAPARAMETERLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "tcaParameterList" element
     */
    public void setTcaParameterList(org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType tcaParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().find_element_user(TCAPARAMETERLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().add_element_user(TCAPARAMETERLIST$4);
            }
            target.set(tcaParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "tcaParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType addNewTcaParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().add_element_user(TCAPARAMETERLIST$4);
            return target;
        }
    }
    
    /**
     * Nils the "tcaParameterList" element
     */
    public void setNilTcaParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().find_element_user(TCAPARAMETERLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().add_element_user(TCAPARAMETERLIST$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "tcaParameterList" element
     */
    public void unsetTcaParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TCAPARAMETERLIST$4, 0);
        }
    }
}
