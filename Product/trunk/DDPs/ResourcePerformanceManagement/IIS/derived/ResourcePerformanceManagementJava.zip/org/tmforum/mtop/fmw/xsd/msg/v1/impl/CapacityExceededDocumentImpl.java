/*
 * An XML document type.
 * Localname: capacityExceeded
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.CapacityExceededDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * A document containing one capacityExceeded(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1) element.
 *
 * This is a complex type.
 */
public class CapacityExceededDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.CapacityExceededDocument
{
    
    public CapacityExceededDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CAPACITYEXCEEDED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "capacityExceeded");
    
    
    /**
     * Gets the "capacityExceeded" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getCapacityExceeded()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(CAPACITYEXCEEDED$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "capacityExceeded" element
     */
    public void setCapacityExceeded(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType capacityExceeded)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(CAPACITYEXCEEDED$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(CAPACITYEXCEEDED$0);
            }
            target.set(capacityExceeded);
        }
    }
    
    /**
     * Appends and returns a new empty "capacityExceeded" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewCapacityExceeded()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(CAPACITYEXCEEDED$0);
            return target;
        }
    }
}
