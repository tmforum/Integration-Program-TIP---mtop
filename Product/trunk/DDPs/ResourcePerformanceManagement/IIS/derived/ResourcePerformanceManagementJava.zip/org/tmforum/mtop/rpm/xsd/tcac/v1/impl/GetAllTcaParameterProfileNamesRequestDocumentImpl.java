/*
 * An XML document type.
 * Localname: getAllTcaParameterProfileNamesRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getAllTcaParameterProfileNamesRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetAllTcaParameterProfileNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument
{
    
    public GetAllTcaParameterProfileNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLTCAPARAMETERPROFILENAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getAllTcaParameterProfileNamesRequest");
    
    
    /**
     * Gets the "getAllTcaParameterProfileNamesRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest getGetAllTcaParameterProfileNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest)get_store().find_element_user(GETALLTCAPARAMETERPROFILENAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllTcaParameterProfileNamesRequest" element
     */
    public void setGetAllTcaParameterProfileNamesRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest getAllTcaParameterProfileNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest)get_store().find_element_user(GETALLTCAPARAMETERPROFILENAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest)get_store().add_element_user(GETALLTCAPARAMETERPROFILENAMESREQUEST$0);
            }
            target.set(getAllTcaParameterProfileNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllTcaParameterProfileNamesRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest addNewGetAllTcaParameterProfileNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest)get_store().add_element_user(GETALLTCAPARAMETERPROFILENAMESREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllTcaParameterProfileNamesRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetAllTcaParameterProfileNamesRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfileNamesRequestDocument.GetAllTcaParameterProfileNamesRequest
    {
        
        public GetAllTcaParameterProfileNamesRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "meName");
        
        
        /**
         * Gets the "meName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "meName" element
         */
        public boolean isSetMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "meName" element
         */
        public void setMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType meName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$0);
                }
                target.set(meName);
            }
        }
        
        /**
         * Appends and returns a new empty "meName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "meName" element
         */
        public void unsetMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MENAME$0, 0);
            }
        }
    }
}
