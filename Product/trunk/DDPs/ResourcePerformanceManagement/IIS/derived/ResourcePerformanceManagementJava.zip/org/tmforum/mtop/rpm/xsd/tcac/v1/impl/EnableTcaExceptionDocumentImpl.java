/*
 * An XML document type.
 * Localname: enableTcaException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one enableTcaException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class EnableTcaExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument
{
    
    public EnableTcaExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENABLETCAEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "enableTcaException");
    
    
    /**
     * Gets the "enableTcaException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException getEnableTcaException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException)get_store().find_element_user(ENABLETCAEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "enableTcaException" element
     */
    public void setEnableTcaException(org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException enableTcaException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException)get_store().find_element_user(ENABLETCAEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException)get_store().add_element_user(ENABLETCAEXCEPTION$0);
            }
            target.set(enableTcaException);
        }
    }
    
    /**
     * Appends and returns a new empty "enableTcaException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException addNewEnableTcaException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException)get_store().add_element_user(ENABLETCAEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML enableTcaException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class EnableTcaExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaExceptionDocument.EnableTcaException
    {
        
        public EnableTcaExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
