/*
 * XML Type:  X721.AvailabilityStatusType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/itu/v1
 * Java type: org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.itu.v1.impl;
/**
 * An XML X721.AvailabilityStatusType(@http://www.tmforum.org/mtop/nrb/xsd/itu/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType.
 */
public class X721AvailabilityStatusTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nrb.xsd.itu.v1.X721AvailabilityStatusType
{
    
    public X721AvailabilityStatusTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected X721AvailabilityStatusTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
