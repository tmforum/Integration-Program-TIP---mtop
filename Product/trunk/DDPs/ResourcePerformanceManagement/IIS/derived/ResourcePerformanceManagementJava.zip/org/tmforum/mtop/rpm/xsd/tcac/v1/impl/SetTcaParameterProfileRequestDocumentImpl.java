/*
 * An XML document type.
 * Localname: setTcaParameterProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one setTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class SetTcaParameterProfileRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument
{
    
    public SetTcaParameterProfileRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETTCAPARAMETERPROFILEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "setTcaParameterProfileRequest");
    
    
    /**
     * Gets the "setTcaParameterProfileRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest getSetTcaParameterProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest)get_store().find_element_user(SETTCAPARAMETERPROFILEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setTcaParameterProfileRequest" element
     */
    public void setSetTcaParameterProfileRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest setTcaParameterProfileRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest)get_store().find_element_user(SETTCAPARAMETERPROFILEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest)get_store().add_element_user(SETTCAPARAMETERPROFILEREQUEST$0);
            }
            target.set(setTcaParameterProfileRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setTcaParameterProfileRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest addNewSetTcaParameterProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest)get_store().add_element_user(SETTCAPARAMETERPROFILEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class SetTcaParameterProfileRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileRequestDocument.SetTcaParameterProfileRequest
    {
        
        public SetTcaParameterProfileRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TCAPARAMETERPROFILENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tcaParameterProfileName");
        private static final javax.xml.namespace.QName LISTOFTCAPARAMETER$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "listOfTcaParameter");
        
        
        /**
         * Gets the "tcaParameterProfileName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TCAPARAMETERPROFILENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tcaParameterProfileName" element
         */
        public boolean isSetTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TCAPARAMETERPROFILENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tcaParameterProfileName" element
         */
        public void setTcaParameterProfileName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tcaParameterProfileName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TCAPARAMETERPROFILENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TCAPARAMETERPROFILENAME$0);
                }
                target.set(tcaParameterProfileName);
            }
        }
        
        /**
         * Appends and returns a new empty "tcaParameterProfileName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TCAPARAMETERPROFILENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tcaParameterProfileName" element
         */
        public void unsetTcaParameterProfileName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TCAPARAMETERPROFILENAME$0, 0);
            }
        }
        
        /**
         * Gets the "listOfTcaParameter" element
         */
        public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType getListOfTcaParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().find_element_user(LISTOFTCAPARAMETER$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "listOfTcaParameter" element
         */
        public boolean isSetListOfTcaParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTOFTCAPARAMETER$2) != 0;
            }
        }
        
        /**
         * Sets the "listOfTcaParameter" element
         */
        public void setListOfTcaParameter(org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType listOfTcaParameter)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().find_element_user(LISTOFTCAPARAMETER$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().add_element_user(LISTOFTCAPARAMETER$2);
                }
                target.set(listOfTcaParameter);
            }
        }
        
        /**
         * Appends and returns a new empty "listOfTcaParameter" element
         */
        public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType addNewListOfTcaParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().add_element_user(LISTOFTCAPARAMETER$2);
                return target;
            }
        }
        
        /**
         * Unsets the "listOfTcaParameter" element
         */
        public void unsetListOfTcaParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTOFTCAPARAMETER$2, 0);
            }
        }
    }
}
