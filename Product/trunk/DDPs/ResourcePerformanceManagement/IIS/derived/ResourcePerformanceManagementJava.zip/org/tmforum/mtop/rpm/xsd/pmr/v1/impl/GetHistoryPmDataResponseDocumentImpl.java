/*
 * An XML document type.
 * Localname: getHistoryPmDataResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getHistoryPmDataResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetHistoryPmDataResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataResponseDocument
{
    
    public GetHistoryPmDataResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETHISTORYPMDATARESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getHistoryPmDataResponse");
    
    
    /**
     * Gets the "getHistoryPmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType getGetHistoryPmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType)get_store().find_element_user(GETHISTORYPMDATARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getHistoryPmDataResponse" element
     */
    public void setGetHistoryPmDataResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType getHistoryPmDataResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType)get_store().find_element_user(GETHISTORYPMDATARESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType)get_store().add_element_user(GETHISTORYPMDATARESPONSE$0);
            }
            target.set(getHistoryPmDataResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getHistoryPmDataResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType addNewGetHistoryPmDataResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmDataObjectsResponseType)get_store().add_element_user(GETHISTORYPMDATARESPONSE$0);
            return target;
        }
    }
}
