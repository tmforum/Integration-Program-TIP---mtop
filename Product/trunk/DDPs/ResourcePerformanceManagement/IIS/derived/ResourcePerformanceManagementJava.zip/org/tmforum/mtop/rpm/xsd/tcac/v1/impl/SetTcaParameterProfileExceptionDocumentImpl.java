/*
 * An XML document type.
 * Localname: setTcaParameterProfileException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one setTcaParameterProfileException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class SetTcaParameterProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument
{
    
    public SetTcaParameterProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETTCAPARAMETERPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "setTcaParameterProfileException");
    
    
    /**
     * Gets the "setTcaParameterProfileException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException getSetTcaParameterProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException)get_store().find_element_user(SETTCAPARAMETERPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setTcaParameterProfileException" element
     */
    public void setSetTcaParameterProfileException(org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException setTcaParameterProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException)get_store().find_element_user(SETTCAPARAMETERPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException)get_store().add_element_user(SETTCAPARAMETERPROFILEEXCEPTION$0);
            }
            target.set(setTcaParameterProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "setTcaParameterProfileException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException addNewSetTcaParameterProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException)get_store().add_element_user(SETTCAPARAMETERPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setTcaParameterProfileException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class SetTcaParameterProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaParameterProfileExceptionDocument.SetTcaParameterProfileException
    {
        
        public SetTcaParameterProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
