/*
 * An XML document type.
 * Localname: getHistoryPmDataRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getHistoryPmDataRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetHistoryPmDataRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument
{
    
    public GetHistoryPmDataRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETHISTORYPMDATAREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getHistoryPmDataRequest");
    
    
    /**
     * Gets the "getHistoryPmDataRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest getGetHistoryPmDataRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest)get_store().find_element_user(GETHISTORYPMDATAREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getHistoryPmDataRequest" element
     */
    public void setGetHistoryPmDataRequest(org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest getHistoryPmDataRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest)get_store().find_element_user(GETHISTORYPMDATAREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest)get_store().add_element_user(GETHISTORYPMDATAREQUEST$0);
            }
            target.set(getHistoryPmDataRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getHistoryPmDataRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest addNewGetHistoryPmDataRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest)get_store().add_element_user(GETHISTORYPMDATAREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getHistoryPmDataRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetHistoryPmDataRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataRequestDocument.GetHistoryPmDataRequest
    {
        
        public GetHistoryPmDataRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PMOBJECTSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "pmObjectSelectList");
        private static final javax.xml.namespace.QName PMPARAMETERS$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "pmParameters");
        private static final javax.xml.namespace.QName STARTTIME$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "startTime");
        private static final javax.xml.namespace.QName ENDTIME$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "endTime");
        private static final javax.xml.namespace.QName FORCEUPLOAD$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "forceUpload");
        
        
        /**
         * Gets the "pmObjectSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMOBJECTSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmObjectSelectList" element
         */
        public boolean isSetPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMOBJECTSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "pmObjectSelectList" element
         */
        public void setPmObjectSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType pmObjectSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMOBJECTSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMOBJECTSELECTLIST$0);
                }
                target.set(pmObjectSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "pmObjectSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMOBJECTSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "pmObjectSelectList" element
         */
        public void unsetPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMOBJECTSELECTLIST$0, 0);
            }
        }
        
        /**
         * Gets the "pmParameters" element
         */
        public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType getPmParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().find_element_user(PMPARAMETERS$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmParameters" element
         */
        public boolean isSetPmParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMPARAMETERS$2) != 0;
            }
        }
        
        /**
         * Sets the "pmParameters" element
         */
        public void setPmParameters(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType pmParameters)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().find_element_user(PMPARAMETERS$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().add_element_user(PMPARAMETERS$2);
                }
                target.set(pmParameters);
            }
        }
        
        /**
         * Appends and returns a new empty "pmParameters" element
         */
        public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType addNewPmParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().add_element_user(PMPARAMETERS$2);
                return target;
            }
        }
        
        /**
         * Unsets the "pmParameters" element
         */
        public void unsetPmParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMPARAMETERS$2, 0);
            }
        }
        
        /**
         * Gets the "startTime" element
         */
        public java.util.Calendar getStartTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STARTTIME$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getCalendarValue();
            }
        }
        
        /**
         * Gets (as xml) the "startTime" element
         */
        public org.apache.xmlbeans.XmlDateTime xgetStartTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(STARTTIME$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "startTime" element
         */
        public boolean isSetStartTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(STARTTIME$4) != 0;
            }
        }
        
        /**
         * Sets the "startTime" element
         */
        public void setStartTime(java.util.Calendar startTime)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STARTTIME$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STARTTIME$4);
                }
                target.setCalendarValue(startTime);
            }
        }
        
        /**
         * Sets (as xml) the "startTime" element
         */
        public void xsetStartTime(org.apache.xmlbeans.XmlDateTime startTime)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(STARTTIME$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(STARTTIME$4);
                }
                target.set(startTime);
            }
        }
        
        /**
         * Unsets the "startTime" element
         */
        public void unsetStartTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(STARTTIME$4, 0);
            }
        }
        
        /**
         * Gets the "endTime" element
         */
        public java.util.Calendar getEndTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ENDTIME$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getCalendarValue();
            }
        }
        
        /**
         * Gets (as xml) the "endTime" element
         */
        public org.apache.xmlbeans.XmlDateTime xgetEndTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(ENDTIME$6, 0);
                return target;
            }
        }
        
        /**
         * True if has "endTime" element
         */
        public boolean isSetEndTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ENDTIME$6) != 0;
            }
        }
        
        /**
         * Sets the "endTime" element
         */
        public void setEndTime(java.util.Calendar endTime)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ENDTIME$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ENDTIME$6);
                }
                target.setCalendarValue(endTime);
            }
        }
        
        /**
         * Sets (as xml) the "endTime" element
         */
        public void xsetEndTime(org.apache.xmlbeans.XmlDateTime endTime)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(ENDTIME$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(ENDTIME$6);
                }
                target.set(endTime);
            }
        }
        
        /**
         * Unsets the "endTime" element
         */
        public void unsetEndTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ENDTIME$6, 0);
            }
        }
        
        /**
         * Gets the "forceUpload" element
         */
        public boolean getForceUpload()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FORCEUPLOAD$8, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "forceUpload" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetForceUpload()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FORCEUPLOAD$8, 0);
                return target;
            }
        }
        
        /**
         * True if has "forceUpload" element
         */
        public boolean isSetForceUpload()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FORCEUPLOAD$8) != 0;
            }
        }
        
        /**
         * Sets the "forceUpload" element
         */
        public void setForceUpload(boolean forceUpload)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FORCEUPLOAD$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FORCEUPLOAD$8);
                }
                target.setBooleanValue(forceUpload);
            }
        }
        
        /**
         * Sets (as xml) the "forceUpload" element
         */
        public void xsetForceUpload(org.apache.xmlbeans.XmlBoolean forceUpload)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FORCEUPLOAD$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FORCEUPLOAD$8);
                }
                target.set(forceUpload);
            }
        }
        
        /**
         * Unsets the "forceUpload" element
         */
        public void unsetForceUpload()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FORCEUPLOAD$8, 0);
            }
        }
    }
}
