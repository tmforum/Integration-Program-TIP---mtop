/*
 * XML Type:  TcaParameterListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcapar/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcapar.v1.impl;
/**
 * An XML TcaParameterListType(@http://www.tmforum.org/mtop/nra/xsd/tcapar/v1).
 *
 * This is a complex type.
 */
public class TcaParameterListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType
{
    
    public TcaParameterListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TCAPARAMETERLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcapar/v1", "tcaParameterList");
    
    
    /**
     * Gets a List of "tcaParameterList" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType> getTcaParameterListList()
    {
        final class TcaParameterListList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType>
        {
            public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType get(int i)
                { return TcaParameterListTypeImpl.this.getTcaParameterListArray(i); }
            
            public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType set(int i, org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType o)
            {
                org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType old = TcaParameterListTypeImpl.this.getTcaParameterListArray(i);
                TcaParameterListTypeImpl.this.setTcaParameterListArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType o)
                { TcaParameterListTypeImpl.this.insertNewTcaParameterList(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType old = TcaParameterListTypeImpl.this.getTcaParameterListArray(i);
                TcaParameterListTypeImpl.this.removeTcaParameterList(i);
                return old;
            }
            
            public int size()
                { return TcaParameterListTypeImpl.this.sizeOfTcaParameterListArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new TcaParameterListList();
        }
    }
    
    /**
     * Gets array of all "tcaParameterList" elements
     */
    public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType[] getTcaParameterListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(TCAPARAMETERLIST$0, targetList);
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType[] result = new org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "tcaParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType getTcaParameterListArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType)get_store().find_element_user(TCAPARAMETERLIST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "tcaParameterList" element
     */
    public int sizeOfTcaParameterListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TCAPARAMETERLIST$0);
        }
    }
    
    /**
     * Sets array of all "tcaParameterList" element
     */
    public void setTcaParameterListArray(org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType[] tcaParameterListArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(tcaParameterListArray, TCAPARAMETERLIST$0);
        }
    }
    
    /**
     * Sets ith "tcaParameterList" element
     */
    public void setTcaParameterListArray(int i, org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType tcaParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType)get_store().find_element_user(TCAPARAMETERLIST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(tcaParameterList);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "tcaParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType insertNewTcaParameterList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType)get_store().insert_element_user(TCAPARAMETERLIST$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "tcaParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType addNewTcaParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterType)get_store().add_element_user(TCAPARAMETERLIST$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "tcaParameterList" element
     */
    public void removeTcaParameterList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TCAPARAMETERLIST$0, i);
        }
    }
}
