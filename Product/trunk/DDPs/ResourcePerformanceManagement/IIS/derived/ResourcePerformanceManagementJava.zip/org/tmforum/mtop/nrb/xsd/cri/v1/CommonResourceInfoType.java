/*
 * XML Type:  CommonResourceInfoType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/cri/v1
 * Java type: org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.cri.v1;


/**
 * An XML CommonResourceInfoType(@http://www.tmforum.org/mtop/nrb/xsd/cri/v1).
 *
 * This is a complex type.
 */
public interface CommonResourceInfoType extends org.tmforum.mtop.fmw.xsd.coi.v1.CommonObjectInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CommonResourceInfoType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s7C5F0157FFA8BEFD0B6FA87BDFBDB36E").resolveHandle("commonresourceinfotype3d8atype");
    
    /**
     * Gets the "source" element
     */
    org.tmforum.mtop.nrb.xsd.cri.v1.SourceType getSource();
    
    /**
     * Tests for nil "source" element
     */
    boolean isNilSource();
    
    /**
     * True if has "source" element
     */
    boolean isSetSource();
    
    /**
     * Sets the "source" element
     */
    void setSource(org.tmforum.mtop.nrb.xsd.cri.v1.SourceType source);
    
    /**
     * Appends and returns a new empty "source" element
     */
    org.tmforum.mtop.nrb.xsd.cri.v1.SourceType addNewSource();
    
    /**
     * Nils the "source" element
     */
    void setNilSource();
    
    /**
     * Unsets the "source" element
     */
    void unsetSource();
    
    /**
     * Gets the "networkAccessDomain" element
     */
    java.lang.String getNetworkAccessDomain();
    
    /**
     * Gets (as xml) the "networkAccessDomain" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType xgetNetworkAccessDomain();
    
    /**
     * Tests for nil "networkAccessDomain" element
     */
    boolean isNilNetworkAccessDomain();
    
    /**
     * True if has "networkAccessDomain" element
     */
    boolean isSetNetworkAccessDomain();
    
    /**
     * Sets the "networkAccessDomain" element
     */
    void setNetworkAccessDomain(java.lang.String networkAccessDomain);
    
    /**
     * Sets (as xml) the "networkAccessDomain" element
     */
    void xsetNetworkAccessDomain(org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType networkAccessDomain);
    
    /**
     * Nils the "networkAccessDomain" element
     */
    void setNilNetworkAccessDomain();
    
    /**
     * Unsets the "networkAccessDomain" element
     */
    void unsetNetworkAccessDomain();
    
    /**
     * Gets the "meiAttributes" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.MeiAttributesType getMeiAttributes();
    
    /**
     * Tests for nil "meiAttributes" element
     */
    boolean isNilMeiAttributes();
    
    /**
     * True if has "meiAttributes" element
     */
    boolean isSetMeiAttributes();
    
    /**
     * Sets the "meiAttributes" element
     */
    void setMeiAttributes(org.tmforum.mtop.fmw.xsd.gen.v1.MeiAttributesType meiAttributes);
    
    /**
     * Appends and returns a new empty "meiAttributes" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.MeiAttributesType addNewMeiAttributes();
    
    /**
     * Nils the "meiAttributes" element
     */
    void setNilMeiAttributes();
    
    /**
     * Unsets the "meiAttributes" element
     */
    void unsetMeiAttributes();
    
    /**
     * Gets the "resourceState" element
     */
    org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType getResourceState();
    
    /**
     * Tests for nil "resourceState" element
     */
    boolean isNilResourceState();
    
    /**
     * True if has "resourceState" element
     */
    boolean isSetResourceState();
    
    /**
     * Sets the "resourceState" element
     */
    void setResourceState(org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType resourceState);
    
    /**
     * Appends and returns a new empty "resourceState" element
     */
    org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType addNewResourceState();
    
    /**
     * Nils the "resourceState" element
     */
    void setNilResourceState();
    
    /**
     * Unsets the "resourceState" element
     */
    void unsetResourceState();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        /** @deprecated No need to be able to create instances of abstract types */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType newInstance() {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        /** @deprecated No need to be able to create instances of abstract types */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
