/*
 * An XML document type.
 * Localname: createTcaParameterProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one createTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class CreateTcaParameterProfileRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument
{
    
    public CreateTcaParameterProfileRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATETCAPARAMETERPROFILEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "createTcaParameterProfileRequest");
    
    
    /**
     * Gets the "createTcaParameterProfileRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest getCreateTcaParameterProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest)get_store().find_element_user(CREATETCAPARAMETERPROFILEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createTcaParameterProfileRequest" element
     */
    public void setCreateTcaParameterProfileRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest createTcaParameterProfileRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest)get_store().find_element_user(CREATETCAPARAMETERPROFILEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest)get_store().add_element_user(CREATETCAPARAMETERPROFILEREQUEST$0);
            }
            target.set(createTcaParameterProfileRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "createTcaParameterProfileRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest addNewCreateTcaParameterProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest)get_store().add_element_user(CREATETCAPARAMETERPROFILEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML createTcaParameterProfileRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class CreateTcaParameterProfileRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileRequestDocument.CreateTcaParameterProfileRequest
    {
        
        public CreateTcaParameterProfileRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "meName");
        private static final javax.xml.namespace.QName LAYER$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "layer");
        private static final javax.xml.namespace.QName USERLABEL$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "userLabel");
        private static final javax.xml.namespace.QName FORCEUNIQUENESS$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "forceUniqueness");
        private static final javax.xml.namespace.QName OWNER$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "owner");
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$10 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "vendorExtensions");
        private static final javax.xml.namespace.QName LISTOFTCAPARAMETER$12 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "listOfTCAParameter");
        
        
        /**
         * Gets the "meName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "meName" element
         */
        public boolean isSetMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "meName" element
         */
        public void setMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType meName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$0);
                }
                target.set(meName);
            }
        }
        
        /**
         * Appends and returns a new empty "meName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "meName" element
         */
        public void unsetMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MENAME$0, 0);
            }
        }
        
        /**
         * Gets the "layer" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYER$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "layer" element
         */
        public boolean isSetLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LAYER$2) != 0;
            }
        }
        
        /**
         * Sets the "layer" element
         */
        public void setLayer(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layer)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYER$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYER$2);
                }
                target.set(layer);
            }
        }
        
        /**
         * Appends and returns a new empty "layer" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYER$2);
                return target;
            }
        }
        
        /**
         * Unsets the "layer" element
         */
        public void unsetLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LAYER$2, 0);
            }
        }
        
        /**
         * Gets the "userLabel" element
         */
        public java.lang.String getUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "userLabel" element
         */
        public org.apache.xmlbeans.XmlString xgetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERLABEL$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "userLabel" element
         */
        public boolean isSetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(USERLABEL$4) != 0;
            }
        }
        
        /**
         * Sets the "userLabel" element
         */
        public void setUserLabel(java.lang.String userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERLABEL$4);
                }
                target.setStringValue(userLabel);
            }
        }
        
        /**
         * Sets (as xml) the "userLabel" element
         */
        public void xsetUserLabel(org.apache.xmlbeans.XmlString userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERLABEL$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERLABEL$4);
                }
                target.set(userLabel);
            }
        }
        
        /**
         * Unsets the "userLabel" element
         */
        public void unsetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(USERLABEL$4, 0);
            }
        }
        
        /**
         * Gets the "forceUniqueness" element
         */
        public java.lang.String getForceUniqueness()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FORCEUNIQUENESS$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "forceUniqueness" element
         */
        public org.apache.xmlbeans.XmlString xgetForceUniqueness()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FORCEUNIQUENESS$6, 0);
                return target;
            }
        }
        
        /**
         * True if has "forceUniqueness" element
         */
        public boolean isSetForceUniqueness()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FORCEUNIQUENESS$6) != 0;
            }
        }
        
        /**
         * Sets the "forceUniqueness" element
         */
        public void setForceUniqueness(java.lang.String forceUniqueness)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FORCEUNIQUENESS$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FORCEUNIQUENESS$6);
                }
                target.setStringValue(forceUniqueness);
            }
        }
        
        /**
         * Sets (as xml) the "forceUniqueness" element
         */
        public void xsetForceUniqueness(org.apache.xmlbeans.XmlString forceUniqueness)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FORCEUNIQUENESS$6, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FORCEUNIQUENESS$6);
                }
                target.set(forceUniqueness);
            }
        }
        
        /**
         * Unsets the "forceUniqueness" element
         */
        public void unsetForceUniqueness()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FORCEUNIQUENESS$6, 0);
            }
        }
        
        /**
         * Gets the "owner" element
         */
        public java.lang.String getOwner()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OWNER$8, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "owner" element
         */
        public org.apache.xmlbeans.XmlString xgetOwner()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OWNER$8, 0);
                return target;
            }
        }
        
        /**
         * True if has "owner" element
         */
        public boolean isSetOwner()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OWNER$8) != 0;
            }
        }
        
        /**
         * Sets the "owner" element
         */
        public void setOwner(java.lang.String owner)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OWNER$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OWNER$8);
                }
                target.setStringValue(owner);
            }
        }
        
        /**
         * Sets (as xml) the "owner" element
         */
        public void xsetOwner(org.apache.xmlbeans.XmlString owner)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(OWNER$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(OWNER$8);
                }
                target.set(owner);
            }
        }
        
        /**
         * Unsets the "owner" element
         */
        public void unsetOwner()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OWNER$8, 0);
            }
        }
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$10, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        public boolean isNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$10, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$10) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$10, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$10);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$10);
                return target;
            }
        }
        
        /**
         * Nils the "vendorExtensions" element
         */
        public void setNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$10, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$10);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$10, 0);
            }
        }
        
        /**
         * Gets the "listOfTCAParameter" element
         */
        public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType getListOfTCAParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().find_element_user(LISTOFTCAPARAMETER$12, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "listOfTCAParameter" element
         */
        public boolean isSetListOfTCAParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LISTOFTCAPARAMETER$12) != 0;
            }
        }
        
        /**
         * Sets the "listOfTCAParameter" element
         */
        public void setListOfTCAParameter(org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType listOfTCAParameter)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().find_element_user(LISTOFTCAPARAMETER$12, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().add_element_user(LISTOFTCAPARAMETER$12);
                }
                target.set(listOfTCAParameter);
            }
        }
        
        /**
         * Appends and returns a new empty "listOfTCAParameter" element
         */
        public org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType addNewListOfTCAParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapar.v1.TcaParameterListType)get_store().add_element_user(LISTOFTCAPARAMETER$12);
                return target;
            }
        }
        
        /**
         * Unsets the "listOfTCAParameter" element
         */
        public void unsetListOfTCAParameter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LISTOFTCAPARAMETER$12, 0);
            }
        }
    }
}
