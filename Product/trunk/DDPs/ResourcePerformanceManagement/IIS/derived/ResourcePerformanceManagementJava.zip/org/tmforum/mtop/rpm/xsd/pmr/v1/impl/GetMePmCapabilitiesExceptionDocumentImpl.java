/*
 * An XML document type.
 * Localname: getMePmCapabilitiesException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getMePmCapabilitiesException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetMePmCapabilitiesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument
{
    
    public GetMePmCapabilitiesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMEPMCAPABILITIESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getMePmCapabilitiesException");
    
    
    /**
     * Gets the "getMePmCapabilitiesException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException getGetMePmCapabilitiesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException)get_store().find_element_user(GETMEPMCAPABILITIESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getMePmCapabilitiesException" element
     */
    public void setGetMePmCapabilitiesException(org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException getMePmCapabilitiesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException)get_store().find_element_user(GETMEPMCAPABILITIESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException)get_store().add_element_user(GETMEPMCAPABILITIESEXCEPTION$0);
            }
            target.set(getMePmCapabilitiesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getMePmCapabilitiesException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException addNewGetMePmCapabilitiesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException)get_store().add_element_user(GETMEPMCAPABILITIESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getMePmCapabilitiesException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetMePmCapabilitiesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesExceptionDocument.GetMePmCapabilitiesException
    {
        
        public GetMePmCapabilitiesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
