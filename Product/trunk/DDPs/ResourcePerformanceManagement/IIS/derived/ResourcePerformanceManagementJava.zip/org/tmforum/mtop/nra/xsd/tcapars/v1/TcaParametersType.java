/*
 * XML Type:  TcaParametersType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcapars/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcapars.v1;


/**
 * An XML TcaParametersType(@http://www.tmforum.org/mtop/nra/xsd/tcapars/v1).
 *
 * This is a complex type.
 */
public interface TcaParametersType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcaParametersType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s7C5F0157FFA8BEFD0B6FA87BDFBDB36E").resolveHandle("tcaparameterstypec2detype");
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * Tests for nil "layerRate" element
     */
    boolean isNilLayerRate();
    
    /**
     * True if has "layerRate" element
     */
    boolean isSetLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Nils the "layerRate" element
     */
    void setNilLayerRate();
    
    /**
     * Unsets the "layerRate" element
     */
    void unsetLayerRate();
    
    /**
     * Gets the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity();
    
    /**
     * Gets (as xml) the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity();
    
    /**
     * Tests for nil "granularity" element
     */
    boolean isNilGranularity();
    
    /**
     * True if has "granularity" element
     */
    boolean isSetGranularity();
    
    /**
     * Sets the "granularity" element
     */
    void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity);
    
    /**
     * Sets (as xml) the "granularity" element
     */
    void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity);
    
    /**
     * Nils the "granularity" element
     */
    void setNilGranularity();
    
    /**
     * Unsets the "granularity" element
     */
    void unsetGranularity();
    
    /**
     * Gets the "tcaTypeValues" element
     */
    org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType getTcaTypeValues();
    
    /**
     * Tests for nil "tcaTypeValues" element
     */
    boolean isNilTcaTypeValues();
    
    /**
     * True if has "tcaTypeValues" element
     */
    boolean isSetTcaTypeValues();
    
    /**
     * Sets the "tcaTypeValues" element
     */
    void setTcaTypeValues(org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType tcaTypeValues);
    
    /**
     * Appends and returns a new empty "tcaTypeValues" element
     */
    org.tmforum.mtop.nra.xsd.pmtv.v1.PmThresholdValueListType addNewTcaTypeValues();
    
    /**
     * Nils the "tcaTypeValues" element
     */
    void setNilTcaTypeValues();
    
    /**
     * Unsets the "tcaTypeValues" element
     */
    void unsetTcaTypeValues();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType newInstance() {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
