/*
 * An XML document type.
 * Localname: deleteTcaParameterProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one deleteTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class DeleteTcaParameterProfileResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DeleteTcaParameterProfileResponseDocument
{
    
    public DeleteTcaParameterProfileResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETETCAPARAMETERPROFILERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "deleteTcaParameterProfileResponse");
    
    
    /**
     * Gets the "deleteTcaParameterProfileResponse" element
     */
    public org.apache.xmlbeans.XmlObject getDeleteTcaParameterProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(DELETETCAPARAMETERPROFILERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteTcaParameterProfileResponse" element
     */
    public void setDeleteTcaParameterProfileResponse(org.apache.xmlbeans.XmlObject deleteTcaParameterProfileResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(DELETETCAPARAMETERPROFILERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(DELETETCAPARAMETERPROFILERESPONSE$0);
            }
            target.set(deleteTcaParameterProfileResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteTcaParameterProfileResponse" element
     */
    public org.apache.xmlbeans.XmlObject addNewDeleteTcaParameterProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(DELETETCAPARAMETERPROFILERESPONSE$0);
            return target;
        }
    }
}
