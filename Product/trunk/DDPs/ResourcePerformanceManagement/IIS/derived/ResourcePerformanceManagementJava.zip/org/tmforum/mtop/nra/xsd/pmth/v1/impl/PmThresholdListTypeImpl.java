/*
 * XML Type:  PmThresholdListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmth/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmth.v1.impl;
/**
 * An XML PmThresholdListType(@http://www.tmforum.org/mtop/nra/xsd/pmth/v1).
 *
 * This is a complex type.
 */
public class PmThresholdListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdListType
{
    
    public PmThresholdListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMTHRESHOLD$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmth/v1", "pmThreshold");
    
    
    /**
     * Gets a List of "pmThreshold" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType> getPmThresholdList()
    {
        final class PmThresholdList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType>
        {
            public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType get(int i)
                { return PmThresholdListTypeImpl.this.getPmThresholdArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType set(int i, org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType o)
            {
                org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType old = PmThresholdListTypeImpl.this.getPmThresholdArray(i);
                PmThresholdListTypeImpl.this.setPmThresholdArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType o)
                { PmThresholdListTypeImpl.this.insertNewPmThreshold(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType old = PmThresholdListTypeImpl.this.getPmThresholdArray(i);
                PmThresholdListTypeImpl.this.removePmThreshold(i);
                return old;
            }
            
            public int size()
                { return PmThresholdListTypeImpl.this.sizeOfPmThresholdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmThresholdList();
        }
    }
    
    /**
     * Gets array of all "pmThreshold" elements
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType[] getPmThresholdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMTHRESHOLD$0, targetList);
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType[] result = new org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pmThreshold" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType getPmThresholdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().find_element_user(PMTHRESHOLD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pmThreshold" element
     */
    public int sizeOfPmThresholdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMTHRESHOLD$0);
        }
    }
    
    /**
     * Sets array of all "pmThreshold" element
     */
    public void setPmThresholdArray(org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType[] pmThresholdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmThresholdArray, PMTHRESHOLD$0);
        }
    }
    
    /**
     * Sets ith "pmThreshold" element
     */
    public void setPmThresholdArray(int i, org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType pmThreshold)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().find_element_user(PMTHRESHOLD$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmThreshold);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmThreshold" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType insertNewPmThreshold(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().insert_element_user(PMTHRESHOLD$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmThreshold" element
     */
    public org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType addNewPmThreshold()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pmth.v1.PmThresholdType)get_store().add_element_user(PMTHRESHOLD$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmThreshold" element
     */
    public void removePmThreshold(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMTHRESHOLD$0, i);
        }
    }
}
