/*
 * An XML document type.
 * Localname: getMePmCapabilitiesResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getMePmCapabilitiesResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetMePmCapabilitiesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument
{
    
    public GetMePmCapabilitiesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETMEPMCAPABILITIESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getMePmCapabilitiesResponse");
    
    
    /**
     * Gets the "getMePmCapabilitiesResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse getGetMePmCapabilitiesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse)get_store().find_element_user(GETMEPMCAPABILITIESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getMePmCapabilitiesResponse" element
     */
    public void setGetMePmCapabilitiesResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse getMePmCapabilitiesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse)get_store().find_element_user(GETMEPMCAPABILITIESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse)get_store().add_element_user(GETMEPMCAPABILITIESRESPONSE$0);
            }
            target.set(getMePmCapabilitiesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getMePmCapabilitiesResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse addNewGetMePmCapabilitiesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse)get_store().add_element_user(GETMEPMCAPABILITIESRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getMePmCapabilitiesResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetMePmCapabilitiesResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetMePmCapabilitiesResponseDocument.GetMePmCapabilitiesResponse
    {
        
        public GetMePmCapabilitiesResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PMPARAMETERLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "pmParameterList");
        
        
        /**
         * Gets the "pmParameterList" element
         */
        public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType getPmParameterList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType)get_store().find_element_user(PMPARAMETERLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmParameterList" element
         */
        public boolean isSetPmParameterList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMPARAMETERLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "pmParameterList" element
         */
        public void setPmParameterList(org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType pmParameterList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType)get_store().find_element_user(PMPARAMETERLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType)get_store().add_element_user(PMPARAMETERLIST$0);
                }
                target.set(pmParameterList);
            }
        }
        
        /**
         * Appends and returns a new empty "pmParameterList" element
         */
        public org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType addNewPmParameterList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmpar.v1.PmParameterListType)get_store().add_element_user(PMPARAMETERLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "pmParameterList" element
         */
        public void unsetPmParameterList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMPARAMETERLIST$0, 0);
            }
        }
    }
}
