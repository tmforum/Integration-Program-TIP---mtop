/*
 * An XML document type.
 * Localname: getPmpsIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetPmpsIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getPmpsIteratorResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetPmpsIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetPmpsIteratorResponseDocument
{
    
    public GetPmpsIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPMPSITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getPmpsIteratorResponse");
    
    
    /**
     * Gets the "getPmpsIteratorResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType getGetPmpsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType)get_store().find_element_user(GETPMPSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPmpsIteratorResponse" element
     */
    public void setGetPmpsIteratorResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType getPmpsIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType)get_store().find_element_user(GETPMPSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType)get_store().add_element_user(GETPMPSITERATORRESPONSE$0);
            }
            target.set(getPmpsIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getPmpsIteratorResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType addNewGetPmpsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectsResponseType)get_store().add_element_user(GETPMPSITERATORRESPONSE$0);
            return target;
        }
    }
}
