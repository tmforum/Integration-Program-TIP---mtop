/*
 * An XML document type.
 * Localname: enableTcaResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one enableTcaResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class EnableTcaResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument
{
    
    public EnableTcaResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ENABLETCARESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "enableTcaResponse");
    
    
    /**
     * Gets the "enableTcaResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse getEnableTcaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse)get_store().find_element_user(ENABLETCARESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "enableTcaResponse" element
     */
    public void setEnableTcaResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse enableTcaResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse)get_store().find_element_user(ENABLETCARESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse)get_store().add_element_user(ENABLETCARESPONSE$0);
            }
            target.set(enableTcaResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "enableTcaResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse addNewEnableTcaResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse)get_store().add_element_user(ENABLETCARESPONSE$0);
            return target;
        }
    }
    /**
     * An XML enableTcaResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class EnableTcaResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.EnableTcaResponseDocument.EnableTcaResponse
    {
        
        public EnableTcaResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FAILEDTPSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "failedTPSelectList");
        
        
        /**
         * Gets the "failedTPSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "failedTPSelectList" element
         */
        public boolean isSetFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILEDTPSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "failedTPSelectList" element
         */
        public void setFailedTPSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType failedTPSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(FAILEDTPSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                }
                target.set(failedTPSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "failedTPSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(FAILEDTPSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "failedTPSelectList" element
         */
        public void unsetFailedTPSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILEDTPSELECTLIST$0, 0);
            }
        }
    }
}
