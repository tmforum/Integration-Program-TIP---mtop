/*
 * An XML document type.
 * Localname: getHistoryPmDataException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getHistoryPmDataException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetHistoryPmDataExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument
{
    
    public GetHistoryPmDataExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETHISTORYPMDATAEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getHistoryPmDataException");
    
    
    /**
     * Gets the "getHistoryPmDataException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException getGetHistoryPmDataException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException)get_store().find_element_user(GETHISTORYPMDATAEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getHistoryPmDataException" element
     */
    public void setGetHistoryPmDataException(org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException getHistoryPmDataException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException)get_store().find_element_user(GETHISTORYPMDATAEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException)get_store().add_element_user(GETHISTORYPMDATAEXCEPTION$0);
            }
            target.set(getHistoryPmDataException);
        }
    }
    
    /**
     * Appends and returns a new empty "getHistoryPmDataException" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException addNewGetHistoryPmDataException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException)get_store().add_element_user(GETHISTORYPMDATAEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getHistoryPmDataException(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetHistoryPmDataExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHistoryPmDataExceptionDocument.GetHistoryPmDataException
    {
        
        public GetHistoryPmDataExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
