/*
 * An XML document type.
 * Localname: clearPmDataRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmc/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmc.v1.impl;
/**
 * A document containing one clearPmDataRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1) element.
 *
 * This is a complex type.
 */
public class ClearPmDataRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument
{
    
    public ClearPmDataRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CLEARPMDATAREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "clearPmDataRequest");
    
    
    /**
     * Gets the "clearPmDataRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest getClearPmDataRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest)get_store().find_element_user(CLEARPMDATAREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "clearPmDataRequest" element
     */
    public void setClearPmDataRequest(org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest clearPmDataRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest)get_store().find_element_user(CLEARPMDATAREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest)get_store().add_element_user(CLEARPMDATAREQUEST$0);
            }
            target.set(clearPmDataRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "clearPmDataRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest addNewClearPmDataRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest)get_store().add_element_user(CLEARPMDATAREQUEST$0);
            return target;
        }
    }
    /**
     * An XML clearPmDataRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmc/v1).
     *
     * This is a complex type.
     */
    public static class ClearPmDataRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmc.v1.ClearPmDataRequestDocument.ClearPmDataRequest
    {
        
        public ClearPmDataRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PMOBJECTSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmc/v1", "pmObjectSelectList");
        
        
        /**
         * Gets the "pmObjectSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMOBJECTSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmObjectSelectList" element
         */
        public boolean isSetPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMOBJECTSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "pmObjectSelectList" element
         */
        public void setPmObjectSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType pmObjectSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMOBJECTSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMOBJECTSELECTLIST$0);
                }
                target.set(pmObjectSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "pmObjectSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMOBJECTSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "pmObjectSelectList" element
         */
        public void unsetPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMOBJECTSELECTLIST$0, 0);
            }
        }
    }
}
