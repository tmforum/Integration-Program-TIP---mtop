/*
 * An XML document type.
 * Localname: disableTcaException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one disableTcaException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class DisableTcaExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument
{
    
    public DisableTcaExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DISABLETCAEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "disableTcaException");
    
    
    /**
     * Gets the "disableTcaException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException getDisableTcaException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException)get_store().find_element_user(DISABLETCAEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "disableTcaException" element
     */
    public void setDisableTcaException(org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException disableTcaException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException)get_store().find_element_user(DISABLETCAEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException)get_store().add_element_user(DISABLETCAEXCEPTION$0);
            }
            target.set(disableTcaException);
        }
    }
    
    /**
     * Appends and returns a new empty "disableTcaException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException addNewDisableTcaException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException)get_store().add_element_user(DISABLETCAEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML disableTcaException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class DisableTcaExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.DisableTcaExceptionDocument.DisableTcaException
    {
        
        public DisableTcaExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
