/*
 * An XML document type.
 * Localname: getAllCurrentPmDataRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getAllCurrentPmDataRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllCurrentPmDataRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument
{
    
    public GetAllCurrentPmDataRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLCURRENTPMDATAREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getAllCurrentPmDataRequest");
    
    
    /**
     * Gets the "getAllCurrentPmDataRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest getGetAllCurrentPmDataRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest)get_store().find_element_user(GETALLCURRENTPMDATAREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllCurrentPmDataRequest" element
     */
    public void setGetAllCurrentPmDataRequest(org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest getAllCurrentPmDataRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest)get_store().find_element_user(GETALLCURRENTPMDATAREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest)get_store().add_element_user(GETALLCURRENTPMDATAREQUEST$0);
            }
            target.set(getAllCurrentPmDataRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllCurrentPmDataRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest addNewGetAllCurrentPmDataRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest)get_store().add_element_user(GETALLCURRENTPMDATAREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllCurrentPmDataRequest(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllCurrentPmDataRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetAllCurrentPmDataRequestDocument.GetAllCurrentPmDataRequest
    {
        
        public GetAllCurrentPmDataRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PMOBJECTSELECTLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "pmObjectSelectList");
        private static final javax.xml.namespace.QName PMPARAMETERS$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "pmParameters");
        
        
        /**
         * Gets the "pmObjectSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType getPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMOBJECTSELECTLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmObjectSelectList" element
         */
        public boolean isSetPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMOBJECTSELECTLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "pmObjectSelectList" element
         */
        public void setPmObjectSelectList(org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType pmObjectSelectList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().find_element_user(PMOBJECTSELECTLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMOBJECTSELECTLIST$0);
                }
                target.set(pmObjectSelectList);
            }
        }
        
        /**
         * Appends and returns a new empty "pmObjectSelectList" element
         */
        public org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType addNewPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pmtgt.v1.PmObjectSelectListType)get_store().add_element_user(PMOBJECTSELECTLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "pmObjectSelectList" element
         */
        public void unsetPmObjectSelectList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMOBJECTSELECTLIST$0, 0);
            }
        }
        
        /**
         * Gets the "pmParameters" element
         */
        public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType getPmParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().find_element_user(PMPARAMETERS$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "pmParameters" element
         */
        public boolean isSetPmParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PMPARAMETERS$2) != 0;
            }
        }
        
        /**
         * Sets the "pmParameters" element
         */
        public void setPmParameters(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType pmParameters)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().find_element_user(PMPARAMETERS$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().add_element_user(PMPARAMETERS$2);
                }
                target.set(pmParameters);
            }
        }
        
        /**
         * Appends and returns a new empty "pmParameters" element
         */
        public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType addNewPmParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameListType)get_store().add_element_user(PMPARAMETERS$2);
                return target;
            }
        }
        
        /**
         * Unsets the "pmParameters" element
         */
        public void unsetPmParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PMPARAMETERS$2, 0);
            }
        }
    }
}
