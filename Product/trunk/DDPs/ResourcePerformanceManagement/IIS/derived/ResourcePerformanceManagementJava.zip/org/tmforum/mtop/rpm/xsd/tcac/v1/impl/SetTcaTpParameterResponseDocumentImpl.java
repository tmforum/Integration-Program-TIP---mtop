/*
 * An XML document type.
 * Localname: setTcaTpParameterResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one setTcaTpParameterResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class SetTcaTpParameterResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument
{
    
    public SetTcaTpParameterResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETTCATPPARAMETERRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "setTcaTpParameterResponse");
    
    
    /**
     * Gets the "setTcaTpParameterResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse getSetTcaTpParameterResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse)get_store().find_element_user(SETTCATPPARAMETERRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setTcaTpParameterResponse" element
     */
    public void setSetTcaTpParameterResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse setTcaTpParameterResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse)get_store().find_element_user(SETTCATPPARAMETERRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse)get_store().add_element_user(SETTCATPPARAMETERRESPONSE$0);
            }
            target.set(setTcaTpParameterResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setTcaTpParameterResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse addNewSetTcaTpParameterResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse)get_store().add_element_user(SETTCATPPARAMETERRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setTcaTpParameterResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class SetTcaTpParameterResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.SetTcaTpParameterResponseDocument.SetTcaTpParameterResponse
    {
        
        public SetTcaTpParameterResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TCAPARAMETERS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tcaParameters");
        
        
        /**
         * Gets the "tcaParameters" element
         */
        public org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType getTcaParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().find_element_user(TCAPARAMETERS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tcaParameters" element
         */
        public boolean isSetTcaParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TCAPARAMETERS$0) != 0;
            }
        }
        
        /**
         * Sets the "tcaParameters" element
         */
        public void setTcaParameters(org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType tcaParameters)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().find_element_user(TCAPARAMETERS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().add_element_user(TCAPARAMETERS$0);
                }
                target.set(tcaParameters);
            }
        }
        
        /**
         * Appends and returns a new empty "tcaParameters" element
         */
        public org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType addNewTcaParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType target = null;
                target = (org.tmforum.mtop.nra.xsd.tcapars.v1.TcaParametersType)get_store().add_element_user(TCAPARAMETERS$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tcaParameters" element
         */
        public void unsetTcaParameters()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TCAPARAMETERS$0, 0);
            }
        }
    }
}
