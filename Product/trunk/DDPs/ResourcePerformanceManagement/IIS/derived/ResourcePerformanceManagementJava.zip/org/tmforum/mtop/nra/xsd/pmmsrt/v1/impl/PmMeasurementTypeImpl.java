/*
 * XML Type:  PmMeasurementType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1
 * Java type: org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pmmsrt.v1.impl;
/**
 * An XML PmMeasurementType(@http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1).
 *
 * This is a complex type.
 */
public class PmMeasurementTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pmmsrt.v1.PmMeasurementType
{
    
    public PmMeasurementTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETERNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1", "pmParameterName");
    private static final javax.xml.namespace.QName PMLOCATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1", "pmLocation");
    private static final javax.xml.namespace.QName VALUE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1", "value");
    private static final javax.xml.namespace.QName MEASUREMENTUNITS$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1", "measurementUnits");
    private static final javax.xml.namespace.QName PMINTERVALSTATUS$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pmmsrt/v1", "pmIntervalStatus");
    
    
    /**
     * Gets the "pmParameterName" element
     */
    public java.lang.String getPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "pmParameterName" element
     */
    public boolean isNilPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmParameterName" element
     */
    public boolean isSetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETERNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "pmParameterName" element
     */
    public void setPmParameterName(java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    public void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.set(pmParameterName);
        }
    }
    
    /**
     * Nils the "pmParameterName" element
     */
    public void setNilPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmParameterName" element
     */
    public void unsetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETERNAME$0, 0);
        }
    }
    
    /**
     * Gets the "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "pmLocation" element
     */
    public boolean isNilPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmLocation" element
     */
    public boolean isSetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMLOCATION$2) != 0;
        }
    }
    
    /**
     * Sets the "pmLocation" element
     */
    public void setPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMLOCATION$2);
            }
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Sets (as xml) the "pmLocation" element
     */
    public void xsetPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().add_element_user(PMLOCATION$2);
            }
            target.set(pmLocation);
        }
    }
    
    /**
     * Nils the "pmLocation" element
     */
    public void setNilPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().add_element_user(PMLOCATION$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmLocation" element
     */
    public void unsetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMLOCATION$2, 0);
        }
    }
    
    /**
     * Gets the "value" element
     */
    public float getValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUE$4, 0);
            if (target == null)
            {
                return 0.0f;
            }
            return target.getFloatValue();
        }
    }
    
    /**
     * Gets (as xml) the "value" element
     */
    public org.apache.xmlbeans.XmlFloat xgetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(VALUE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "value" element
     */
    public boolean isNilValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(VALUE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "value" element
     */
    public boolean isSetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALUE$4) != 0;
        }
    }
    
    /**
     * Sets the "value" element
     */
    public void setValue(float value)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALUE$4);
            }
            target.setFloatValue(value);
        }
    }
    
    /**
     * Sets (as xml) the "value" element
     */
    public void xsetValue(org.apache.xmlbeans.XmlFloat value)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(VALUE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlFloat)get_store().add_element_user(VALUE$4);
            }
            target.set(value);
        }
    }
    
    /**
     * Nils the "value" element
     */
    public void setNilValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlFloat target = null;
            target = (org.apache.xmlbeans.XmlFloat)get_store().find_element_user(VALUE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlFloat)get_store().add_element_user(VALUE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "value" element
     */
    public void unsetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALUE$4, 0);
        }
    }
    
    /**
     * Gets the "measurementUnits" element
     */
    public java.lang.String getMeasurementUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MEASUREMENTUNITS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "measurementUnits" element
     */
    public org.apache.xmlbeans.XmlString xgetMeasurementUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEASUREMENTUNITS$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "measurementUnits" element
     */
    public boolean isNilMeasurementUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEASUREMENTUNITS$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "measurementUnits" element
     */
    public boolean isSetMeasurementUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MEASUREMENTUNITS$6) != 0;
        }
    }
    
    /**
     * Sets the "measurementUnits" element
     */
    public void setMeasurementUnits(java.lang.String measurementUnits)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MEASUREMENTUNITS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MEASUREMENTUNITS$6);
            }
            target.setStringValue(measurementUnits);
        }
    }
    
    /**
     * Sets (as xml) the "measurementUnits" element
     */
    public void xsetMeasurementUnits(org.apache.xmlbeans.XmlString measurementUnits)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEASUREMENTUNITS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MEASUREMENTUNITS$6);
            }
            target.set(measurementUnits);
        }
    }
    
    /**
     * Nils the "measurementUnits" element
     */
    public void setNilMeasurementUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(MEASUREMENTUNITS$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(MEASUREMENTUNITS$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "measurementUnits" element
     */
    public void unsetMeasurementUnits()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MEASUREMENTUNITS$6, 0);
        }
    }
    
    /**
     * Gets the "pmIntervalStatus" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType.Enum getPmIntervalStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMINTERVALSTATUS$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmIntervalStatus" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType xgetPmIntervalStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType)get_store().find_element_user(PMINTERVALSTATUS$8, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "pmIntervalStatus" element
     */
    public boolean isNilPmIntervalStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType)get_store().find_element_user(PMINTERVALSTATUS$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pmIntervalStatus" element
     */
    public boolean isSetPmIntervalStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMINTERVALSTATUS$8) != 0;
        }
    }
    
    /**
     * Sets the "pmIntervalStatus" element
     */
    public void setPmIntervalStatus(org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType.Enum pmIntervalStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMINTERVALSTATUS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMINTERVALSTATUS$8);
            }
            target.setEnumValue(pmIntervalStatus);
        }
    }
    
    /**
     * Sets (as xml) the "pmIntervalStatus" element
     */
    public void xsetPmIntervalStatus(org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType pmIntervalStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType)get_store().find_element_user(PMINTERVALSTATUS$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType)get_store().add_element_user(PMINTERVALSTATUS$8);
            }
            target.set(pmIntervalStatus);
        }
    }
    
    /**
     * Nils the "pmIntervalStatus" element
     */
    public void setNilPmIntervalStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType)get_store().find_element_user(PMINTERVALSTATUS$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType)get_store().add_element_user(PMINTERVALSTATUS$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pmIntervalStatus" element
     */
    public void unsetPmIntervalStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMINTERVALSTATUS$8, 0);
        }
    }
}
