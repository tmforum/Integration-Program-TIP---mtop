/*
 * An XML document type.
 * Localname: getAllTcaParameterProfilesException
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getAllTcaParameterProfilesException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetAllTcaParameterProfilesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument
{
    
    public GetAllTcaParameterProfilesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLTCAPARAMETERPROFILESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getAllTcaParameterProfilesException");
    
    
    /**
     * Gets the "getAllTcaParameterProfilesException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException getGetAllTcaParameterProfilesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException)get_store().find_element_user(GETALLTCAPARAMETERPROFILESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllTcaParameterProfilesException" element
     */
    public void setGetAllTcaParameterProfilesException(org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException getAllTcaParameterProfilesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException)get_store().find_element_user(GETALLTCAPARAMETERPROFILESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException)get_store().add_element_user(GETALLTCAPARAMETERPROFILESEXCEPTION$0);
            }
            target.set(getAllTcaParameterProfilesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllTcaParameterProfilesException" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException addNewGetAllTcaParameterProfilesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException)get_store().add_element_user(GETALLTCAPARAMETERPROFILESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllTcaParameterProfilesException(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetAllTcaParameterProfilesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetAllTcaParameterProfilesExceptionDocument.GetAllTcaParameterProfilesException
    {
        
        public GetAllTcaParameterProfilesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
