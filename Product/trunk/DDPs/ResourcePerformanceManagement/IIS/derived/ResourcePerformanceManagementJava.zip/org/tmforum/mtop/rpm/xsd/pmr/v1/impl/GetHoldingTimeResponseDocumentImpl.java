/*
 * An XML document type.
 * Localname: getHoldingTimeResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getHoldingTimeResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetHoldingTimeResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument
{
    
    public GetHoldingTimeResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETHOLDINGTIMERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getHoldingTimeResponse");
    
    
    /**
     * Gets the "getHoldingTimeResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse getGetHoldingTimeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse)get_store().find_element_user(GETHOLDINGTIMERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getHoldingTimeResponse" element
     */
    public void setGetHoldingTimeResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse getHoldingTimeResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse)get_store().find_element_user(GETHOLDINGTIMERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse)get_store().add_element_user(GETHOLDINGTIMERESPONSE$0);
            }
            target.set(getHoldingTimeResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getHoldingTimeResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse addNewGetHoldingTimeResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse)get_store().add_element_user(GETHOLDINGTIMERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getHoldingTimeResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1).
     *
     * This is a complex type.
     */
    public static class GetHoldingTimeResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetHoldingTimeResponseDocument.GetHoldingTimeResponse
    {
        
        public GetHoldingTimeResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName HOLDINGTIME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "holdingTime");
        
        
        /**
         * Gets the "holdingTime" element
         */
        public org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType.Enum getHoldingTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HOLDINGTIME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "holdingTime" element
         */
        public org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType xgetHoldingTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType)get_store().find_element_user(HOLDINGTIME$0, 0);
                return target;
            }
        }
        
        /**
         * True if has "holdingTime" element
         */
        public boolean isSetHoldingTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(HOLDINGTIME$0) != 0;
            }
        }
        
        /**
         * Sets the "holdingTime" element
         */
        public void setHoldingTime(org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType.Enum holdingTime)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HOLDINGTIME$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(HOLDINGTIME$0);
                }
                target.setEnumValue(holdingTime);
            }
        }
        
        /**
         * Sets (as xml) the "holdingTime" element
         */
        public void xsetHoldingTime(org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType holdingTime)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType)get_store().find_element_user(HOLDINGTIME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pm.v1.HoldingTimeType)get_store().add_element_user(HOLDINGTIME$0);
                }
                target.set(holdingTime);
            }
        }
        
        /**
         * Unsets the "holdingTime" element
         */
        public void unsetHoldingTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(HOLDINGTIME$0, 0);
            }
        }
    }
}
