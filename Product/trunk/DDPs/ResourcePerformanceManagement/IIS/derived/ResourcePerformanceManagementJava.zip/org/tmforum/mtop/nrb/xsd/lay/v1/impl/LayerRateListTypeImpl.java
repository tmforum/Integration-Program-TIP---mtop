/*
 * XML Type:  LayerRateListType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/lay/v1
 * Java type: org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.lay.v1.impl;
/**
 * An XML LayerRateListType(@http://www.tmforum.org/mtop/nrb/xsd/lay/v1).
 *
 * This is a complex type.
 */
public class LayerRateListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType
{
    
    public LayerRateListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LAYERRATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/lay/v1", "layerRate");
    
    
    /**
     * Gets a List of "layerRate" elements
     */
    public java.util.List<org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType> getLayerRateList()
    {
        final class LayerRateList extends java.util.AbstractList<org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType>
        {
            public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType get(int i)
                { return LayerRateListTypeImpl.this.getLayerRateArray(i); }
            
            public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType set(int i, org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType o)
            {
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType old = LayerRateListTypeImpl.this.getLayerRateArray(i);
                LayerRateListTypeImpl.this.setLayerRateArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType o)
                { LayerRateListTypeImpl.this.insertNewLayerRate(i).set(o); }
            
            public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType remove(int i)
            {
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType old = LayerRateListTypeImpl.this.getLayerRateArray(i);
                LayerRateListTypeImpl.this.removeLayerRate(i);
                return old;
            }
            
            public int size()
                { return LayerRateListTypeImpl.this.sizeOfLayerRateArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new LayerRateList();
        }
    }
    
    /**
     * Gets array of all "layerRate" elements
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType[] getLayerRateArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(LAYERRATE$0, targetList);
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType[] result = new org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRateArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "layerRate" element
     */
    public int sizeOfLayerRateArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$0);
        }
    }
    
    /**
     * Sets array of all "layerRate" element
     */
    public void setLayerRateArray(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType[] layerRateArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(layerRateArray, LAYERRATE$0);
        }
    }
    
    /**
     * Sets ith "layerRate" element
     */
    public void setLayerRateArray(int i, org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType insertNewLayerRate(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().insert_element_user(LAYERRATE$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "layerRate" element
     */
    public void removeLayerRate(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$0, i);
        }
    }
}
