/*
 * An XML document type.
 * Localname: getTcaTpParameterRequest
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1.impl;
/**
 * A document containing one getTcaTpParameterRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public class GetTcaTpParameterRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument
{
    
    public GetTcaTpParameterRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETTCATPPARAMETERREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "getTcaTpParameterRequest");
    
    
    /**
     * Gets the "getTcaTpParameterRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest getGetTcaTpParameterRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest)get_store().find_element_user(GETTCATPPARAMETERREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getTcaTpParameterRequest" element
     */
    public void setGetTcaTpParameterRequest(org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest getTcaTpParameterRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest)get_store().find_element_user(GETTCATPPARAMETERREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest)get_store().add_element_user(GETTCATPPARAMETERREQUEST$0);
            }
            target.set(getTcaTpParameterRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getTcaTpParameterRequest" element
     */
    public org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest addNewGetTcaTpParameterRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest target = null;
            target = (org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest)get_store().add_element_user(GETTCATPPARAMETERREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getTcaTpParameterRequest(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public static class GetTcaTpParameterRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.tcac.v1.GetTcaTpParameterRequestDocument.GetTcaTpParameterRequest
    {
        
        public GetTcaTpParameterRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPELEMENTNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "tpElementName");
        private static final javax.xml.namespace.QName LAYER$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "layer");
        private static final javax.xml.namespace.QName GRANULARITY$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/tcac/v1", "granularity");
        
        
        /**
         * Gets the "tpElementName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpElementName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPELEMENTNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "tpElementName" element
         */
        public boolean isSetTpElementName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPELEMENTNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tpElementName" element
         */
        public void setTpElementName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpElementName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPELEMENTNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPELEMENTNAME$0);
                }
                target.set(tpElementName);
            }
        }
        
        /**
         * Appends and returns a new empty "tpElementName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpElementName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPELEMENTNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "tpElementName" element
         */
        public void unsetTpElementName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPELEMENTNAME$0, 0);
            }
        }
        
        /**
         * Gets the "layer" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYER$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "layer" element
         */
        public boolean isSetLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LAYER$2) != 0;
            }
        }
        
        /**
         * Sets the "layer" element
         */
        public void setLayer(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layer)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYER$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYER$2);
                }
                target.set(layer);
            }
        }
        
        /**
         * Appends and returns a new empty "layer" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYER$2);
                return target;
            }
        }
        
        /**
         * Unsets the "layer" element
         */
        public void unsetLayer()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LAYER$2, 0);
            }
        }
        
        /**
         * Gets the "granularity" element
         */
        public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$4, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "granularity" element
         */
        public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
                return target;
            }
        }
        
        /**
         * True if has "granularity" element
         */
        public boolean isSetGranularity()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(GRANULARITY$4) != 0;
            }
        }
        
        /**
         * Sets the "granularity" element
         */
        public void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(GRANULARITY$4);
                }
                target.setEnumValue(granularity);
            }
        }
        
        /**
         * Sets (as xml) the "granularity" element
         */
        public void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$4);
                }
                target.set(granularity);
            }
        }
        
        /**
         * Unsets the "granularity" element
         */
        public void unsetGranularity()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(GRANULARITY$4, 0);
            }
        }
    }
}
