/*
 * An XML document type.
 * Localname: getPmpNamesIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/pmr/v1
 * Java type: org.tmforum.mtop.rpm.xsd.pmr.v1.GetPmpNamesIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.pmr.v1.impl;
/**
 * A document containing one getPmpNamesIteratorResponse(@http://www.tmforum.org/mtop/rpm/xsd/pmr/v1) element.
 *
 * This is a complex type.
 */
public class GetPmpNamesIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rpm.xsd.pmr.v1.GetPmpNamesIteratorResponseDocument
{
    
    public GetPmpNamesIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPMPNAMESITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rpm/xsd/pmr/v1", "getPmpNamesIteratorResponse");
    
    
    /**
     * Gets the "getPmpNamesIteratorResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType getGetPmpNamesIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType)get_store().find_element_user(GETPMPNAMESITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPmpNamesIteratorResponse" element
     */
    public void setGetPmpNamesIteratorResponse(org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType getPmpNamesIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType)get_store().find_element_user(GETPMPNAMESITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType)get_store().add_element_user(GETPMPNAMESITERATORRESPONSE$0);
            }
            target.set(getPmpNamesIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getPmpNamesIteratorResponse" element
     */
    public org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType addNewGetPmpNamesIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.rpm.xsd.pmr.v1.MultiplePmpObjectNamesResponseType)get_store().add_element_user(GETPMPNAMESITERATORRESPONSE$0);
            return target;
        }
    }
}
