/*
 * An XML document type.
 * Localname: createTcaParameterProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rpm/xsd/tcac/v1
 * Java type: org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rpm.xsd.tcac.v1;


/**
 * A document containing one createTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1) element.
 *
 * This is a complex type.
 */
public interface CreateTcaParameterProfileResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateTcaParameterProfileResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s7C5F0157FFA8BEFD0B6FA87BDFBDB36E").resolveHandle("createtcaparameterprofileresponse6964doctype");
    
    /**
     * Gets the "createTcaParameterProfileResponse" element
     */
    org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse getCreateTcaParameterProfileResponse();
    
    /**
     * Sets the "createTcaParameterProfileResponse" element
     */
    void setCreateTcaParameterProfileResponse(org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse createTcaParameterProfileResponse);
    
    /**
     * Appends and returns a new empty "createTcaParameterProfileResponse" element
     */
    org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse addNewCreateTcaParameterProfileResponse();
    
    /**
     * An XML createTcaParameterProfileResponse(@http://www.tmforum.org/mtop/rpm/xsd/tcac/v1).
     *
     * This is a complex type.
     */
    public interface CreateTcaParameterProfileResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CreateTcaParameterProfileResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s7C5F0157FFA8BEFD0B6FA87BDFBDB36E").resolveHandle("createtcaparameterprofileresponse1347elemtype");
        
        /**
         * Gets the "tcaParameterProfile" element
         */
        org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType getTcaParameterProfile();
        
        /**
         * True if has "tcaParameterProfile" element
         */
        boolean isSetTcaParameterProfile();
        
        /**
         * Sets the "tcaParameterProfile" element
         */
        void setTcaParameterProfile(org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType tcaParameterProfile);
        
        /**
         * Appends and returns a new empty "tcaParameterProfile" element
         */
        org.tmforum.mtop.nra.xsd.tcapp.v1.TcaParameterProfileType addNewTcaParameterProfile();
        
        /**
         * Unsets the "tcaParameterProfile" element
         */
        void unsetTcaParameterProfile();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse newInstance() {
              return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument.CreateTcaParameterProfileResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument newInstance() {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rpm.xsd.tcac.v1.CreateTcaParameterProfileResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
