﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/rpm/wsdl/pmc/v1-0"] =  new WC (
					new Array(new WCN("23/service/PerformanceManagementControlHttp.html","PerformanceManagementControlHttp",false,null),new WCN("23/service/PerformanceManagementControlJms.html","PerformanceManagementControlJms",false,null)),
					new Array(new WCN("23/message/clearPmDataException.html","clearPmDataException",false,null),new WCN("23/message/clearPmDataRequest.html","clearPmDataRequest",false,null),new WCN("23/message/clearPmDataResponse.html","clearPmDataResponse",false,null),new WCN("23/message/disablePmDataException.html","disablePmDataException",false,null),new WCN("23/message/disablePmDataRequest.html","disablePmDataRequest",false,null),new WCN("23/message/disablePmDataResponse.html","disablePmDataResponse",false,null),new WCN("23/message/enablePmDataException.html","enablePmDataException",false,null),new WCN("23/message/enablePmDataRequest.html","enablePmDataRequest",false,null),new WCN("23/message/enablePmDataResponse.html","enablePmDataResponse",false,null)),
					new Array(new WCN("23/porttype/PerformanceManagementControl.html","PerformanceManagementControl",false,new Array(new WCN("23/operation/clearPmData_0.html","clearPmData",false,null),new WCN("23/operation/disablePmData_1.html","disablePmData",false,null),new WCN("23/operation/enablePmData_2.html","enablePmData",false,null)))),
					new Array(new WCN("23/binding/PerformanceManagementControlSoapHttpBinding.html","PerformanceManagementControlSoapHttpBinding",false,new Array(new WCN("23/operation/clearPmData_0.html","clearPmData",false,null),new WCN("23/operation/disablePmData_1.html","disablePmData",false,null),new WCN("23/operation/enablePmData_2.html","enablePmData",false,null))),new WCN("23/binding/PerformanceManagementControlSoapJmsBinding.html","PerformanceManagementControlSoapJmsBinding",false,new Array(new WCN("23/operation/clearPmData_0.html","clearPmData",false,null),new WCN("23/operation/disablePmData_1.html","disablePmData",false,null),new WCN("23/operation/enablePmData_2.html","enablePmData",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rpm/wsdl/pmc/v1-0"] = "23/index.html";
wcDB ["http://www.tmforum.org/mtop/rpm/wsdl/pmr/v1-0"] =  new WC (
					new Array(new WCN("25/service/PerformanceManagementRetrievalHttp.html","PerformanceManagementRetrievalHttp",false,null),new WCN("25/service/PerformanceManagementRetrievalJms.html","PerformanceManagementRetrievalJms",false,null)),
					new Array(new WCN("25/message/getAllCurrentPmDataException.html","getAllCurrentPmDataException",false,null),new WCN("25/message/getAllCurrentPmDataRequest.html","getAllCurrentPmDataRequest",false,null),new WCN("25/message/getAllCurrentPmDataResponse.html","getAllCurrentPmDataResponse",false,null),new WCN("25/message/getAllPmpNamesException.html","getAllPmpNamesException",false,null),new WCN("25/message/getAllPmpNamesRequest.html","getAllPmpNamesRequest",false,null),new WCN("25/message/getAllPmpNamesResponse.html","getAllPmpNamesResponse",false,null),new WCN("25/message/getAllPmpsException.html","getAllPmpsException",false,null),new WCN("25/message/getAllPmpsRequest.html","getAllPmpsRequest",false,null),new WCN("25/message/getAllPmpsResponse.html","getAllPmpsResponse",false,null),new WCN("25/message/getHistoryPmDataException.html","getHistoryPmDataException",false,null),new WCN("25/message/getHistoryPmDataRequest.html","getHistoryPmDataRequest",false,null),new WCN("25/message/getHistoryPmDataResponse.html","getHistoryPmDataResponse",false,null),new WCN("25/message/getHoldingTimeException.html","getHoldingTimeException",false,null),new WCN("25/message/getHoldingTimeRequest.html","getHoldingTimeRequest",false,null),new WCN("25/message/getHoldingTimeResponse.html","getHoldingTimeResponse",false,null),new WCN("25/message/getMePmCapabilitiesException.html","getMePmCapabilitiesException",false,null),new WCN("25/message/getMePmCapabilitiesRequest.html","getMePmCapabilitiesRequest",false,null),new WCN("25/message/getMePmCapabilitiesResponse.html","getMePmCapabilitiesResponse",false,null),new WCN("25/message/getPmDataIteratorException.html","getPmDataIteratorException",false,null),new WCN("25/message/getPmDataIteratorRequest.html","getPmDataIteratorRequest",false,null),new WCN("25/message/getPmDataIteratorResponse.html","getPmDataIteratorResponse",false,null),new WCN("25/message/getPmpNamesIteratorException.html","getPmpNamesIteratorException",false,null),new WCN("25/message/getPmpNamesIteratorRequest.html","getPmpNamesIteratorRequest",false,null),new WCN("25/message/getPmpNamesIteratorResponse.html","getPmpNamesIteratorResponse",false,null),new WCN("25/message/getPmpsIteratorException.html","getPmpsIteratorException",false,null),new WCN("25/message/getPmpsIteratorRequest.html","getPmpsIteratorRequest",false,null),new WCN("25/message/getPmpsIteratorResponse.html","getPmpsIteratorResponse",false,null),new WCN("25/message/getProfileAssociatedTpsException.html","getProfileAssociatedTpsException",false,null),new WCN("25/message/getProfileAssociatedTpsRequest.html","getProfileAssociatedTpsRequest",false,null),new WCN("25/message/getProfileAssociatedTpsResponse.html","getProfileAssociatedTpsResponse",false,null)),
					new Array(new WCN("25/porttype/PerformanceManagementRetrieval.html","PerformanceManagementRetrieval",false,new Array(new WCN("25/operation/getAllCurrentPmData_16.html","getAllCurrentPmData",false,null),new WCN("25/operation/getAllPmpNames_17.html","getAllPmpNames",false,null),new WCN("25/operation/getAllPmps_18.html","getAllPmps",false,null),new WCN("25/operation/getHistoryPmData_19.html","getHistoryPmData",false,null),new WCN("25/operation/getHoldingTime_20.html","getHoldingTime",false,null),new WCN("25/operation/getMePmCapabilities_21.html","getMePmCapabilities",false,null),new WCN("25/operation/getPmDataIterator_23.html","getPmDataIterator",false,null),new WCN("25/operation/getPmpNamesIterator_24.html","getPmpNamesIterator",false,null),new WCN("25/operation/getPmpsIterator_25.html","getPmpsIterator",false,null),new WCN("25/operation/getProfileAssociatedTps_22.html","getProfileAssociatedTps",false,null)))),
					new Array(new WCN("25/binding/PerformanceManagementRetrievalSoapHttpBinding.html","PerformanceManagementRetrievalSoapHttpBinding",false,new Array(new WCN("25/operation/getAllCurrentPmData_16.html","getAllCurrentPmData",false,null),new WCN("25/operation/getAllPmpNames_17.html","getAllPmpNames",false,null),new WCN("25/operation/getAllPmps_18.html","getAllPmps",false,null),new WCN("25/operation/getHistoryPmData_19.html","getHistoryPmData",false,null),new WCN("25/operation/getHoldingTime_20.html","getHoldingTime",false,null),new WCN("25/operation/getMePmCapabilities_21.html","getMePmCapabilities",false,null),new WCN("25/operation/getPmDataIterator_23.html","getPmDataIterator",false,null),new WCN("25/operation/getPmpNamesIterator_24.html","getPmpNamesIterator",false,null),new WCN("25/operation/getPmpsIterator_25.html","getPmpsIterator",false,null),new WCN("25/operation/getProfileAssociatedTps_22.html","getProfileAssociatedTps",false,null))),new WCN("25/binding/PerformanceManagementRetrievalSoapJmsBinding.html","PerformanceManagementRetrievalSoapJmsBinding",false,new Array(new WCN("25/operation/getAllCurrentPmData_16.html","getAllCurrentPmData",false,null),new WCN("25/operation/getAllPmpNames_17.html","getAllPmpNames",false,null),new WCN("25/operation/getAllPmps_18.html","getAllPmps",false,null),new WCN("25/operation/getHistoryPmData_19.html","getHistoryPmData",false,null),new WCN("25/operation/getHoldingTime_20.html","getHoldingTime",false,null),new WCN("25/operation/getMePmCapabilities_21.html","getMePmCapabilities",false,null),new WCN("25/operation/getPmDataIterator_23.html","getPmDataIterator",false,null),new WCN("25/operation/getPmpNamesIterator_24.html","getPmpNamesIterator",false,null),new WCN("25/operation/getPmpsIterator_25.html","getPmpsIterator",false,null),new WCN("25/operation/getProfileAssociatedTps_22.html","getProfileAssociatedTps",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rpm/wsdl/pmr/v1-0"] = "25/index.html";
wcDB ["http://www.tmforum.org/mtop/rpm/wsdl/tcac/v1-0"] =  new WC (
					new Array(new WCN("24/service/ThresholdCrossingAlertControlHttp.html","ThresholdCrossingAlertControlHttp",false,null),new WCN("24/service/ThresholdCrossingAlertControlJms.html","ThresholdCrossingAlertControlJms",false,null)),
					new Array(new WCN("24/message/createTcaParameterProfileException.html","createTcaParameterProfileException",false,null),new WCN("24/message/createTcaParameterProfileRequest.html","createTcaParameterProfileRequest",false,null),new WCN("24/message/createTcaParameterProfileResponse.html","createTcaParameterProfileResponse",false,null),new WCN("24/message/deleteTcaParameterProfileException.html","deleteTcaParameterProfileException",false,null),new WCN("24/message/deleteTcaParameterProfileRequest.html","deleteTcaParameterProfileRequest",false,null),new WCN("24/message/deleteTcaParameterProfileResponse.html","deleteTcaParameterProfileResponse",false,null),new WCN("24/message/disableTcaException.html","disableTcaException",false,null),new WCN("24/message/disableTcaRequest.html","disableTcaRequest",false,null),new WCN("24/message/disableTcaResponse.html","disableTcaResponse",false,null),new WCN("24/message/enableTcaException.html","enableTcaException",false,null),new WCN("24/message/enableTcaRequest.html","enableTcaRequest",false,null),new WCN("24/message/enableTcaResponse.html","enableTcaResponse",false,null),new WCN("24/message/getAllTcaParameterProfileNamesException.html","getAllTcaParameterProfileNamesException",false,null),new WCN("24/message/getAllTcaParameterProfileNamesRequest.html","getAllTcaParameterProfileNamesRequest",false,null),new WCN("24/message/getAllTcaParameterProfileNamesResponse.html","getAllTcaParameterProfileNamesResponse",false,null),new WCN("24/message/getAllTcaParameterProfilesException.html","getAllTcaParameterProfilesException",false,null),new WCN("24/message/getAllTcaParameterProfilesRequest.html","getAllTcaParameterProfilesRequest",false,null),new WCN("24/message/getAllTcaParameterProfilesResponse.html","getAllTcaParameterProfilesResponse",false,null),new WCN("24/message/getTcaParameterProfileException.html","getTcaParameterProfileException",false,null),new WCN("24/message/getTcaParameterProfileNamesIteratorException.html","getTcaParameterProfileNamesIteratorException",false,null),new WCN("24/message/getTcaParameterProfileNamesIteratorRequest.html","getTcaParameterProfileNamesIteratorRequest",false,null),new WCN("24/message/getTcaParameterProfileNamesIteratorResponse.html","getTcaParameterProfileNamesIteratorResponse",false,null),new WCN("24/message/getTcaParameterProfileRequest.html","getTcaParameterProfileRequest",false,null),new WCN("24/message/getTcaParameterProfileResponse.html","getTcaParameterProfileResponse",false,null),new WCN("24/message/getTcaParameterProfilesIteratorException.html","getTcaParameterProfilesIteratorException",false,null),new WCN("24/message/getTcaParameterProfilesIteratorRequest.html","getTcaParameterProfilesIteratorRequest",false,null),new WCN("24/message/getTcaParameterProfilesIteratorResponse.html","getTcaParameterProfilesIteratorResponse",false,null),new WCN("24/message/getTcaTpParameterException.html","getTcaTpParameterException",false,null),new WCN("24/message/getTcaTpParameterRequest.html","getTcaTpParameterRequest",false,null),new WCN("24/message/getTcaTpParameterResponse.html","getTcaTpParameterResponse",false,null),new WCN("24/message/setTcaParameterProfileException.html","setTcaParameterProfileException",false,null),new WCN("24/message/setTcaParameterProfilePointerException.html","setTcaParameterProfilePointerException",false,null),new WCN("24/message/setTcaParameterProfilePointerRequest.html","setTcaParameterProfilePointerRequest",false,null),new WCN("24/message/setTcaParameterProfilePointerResponse.html","setTcaParameterProfilePointerResponse",false,null),new WCN("24/message/setTcaParameterProfileRequest.html","setTcaParameterProfileRequest",false,null),new WCN("24/message/setTcaParameterProfileResponse.html","setTcaParameterProfileResponse",false,null),new WCN("24/message/setTcaTpParameterException.html","setTcaTpParameterException",false,null),new WCN("24/message/setTcaTpParameterRequest.html","setTcaTpParameterRequest",false,null),new WCN("24/message/setTcaTpParameterResponse.html","setTcaTpParameterResponse",false,null)),
					new Array(new WCN("24/porttype/ThresholdCrossingAlertControl.html","ThresholdCrossingAlertControl",false,new Array(new WCN("24/operation/createTcaParameterProfile_3.html","createTcaParameterProfile",false,null),new WCN("24/operation/deleteTcaParameterProfile_4.html","deleteTcaParameterProfile",false,null),new WCN("24/operation/disableTca_5.html","disableTca",false,null),new WCN("24/operation/enableTca_6.html","enableTca",false,null),new WCN("24/operation/getAllTcaParameterProfileNames_7.html","getAllTcaParameterProfileNames",false,null),new WCN("24/operation/getAllTcaParameterProfiles_8.html","getAllTcaParameterProfiles",false,null),new WCN("24/operation/getTcaParameterProfile_9.html","getTcaParameterProfile",false,null),new WCN("24/operation/getTcaParameterProfileNamesIterator_14.html","getTcaParameterProfileNamesIterator",false,null),new WCN("24/operation/getTcaParameterProfilesIterator_15.html","getTcaParameterProfilesIterator",false,null),new WCN("24/operation/getTcaTpParameter_10.html","getTcaTpParameter",false,null),new WCN("24/operation/setTcaParameterProfile_11.html","setTcaParameterProfile",false,null),new WCN("24/operation/setTcaParameterProfilePointer_12.html","setTcaParameterProfilePointer",false,null),new WCN("24/operation/setTcaTpParameter_13.html","setTcaTpParameter",false,null)))),
					new Array(new WCN("24/binding/ThresholdCrossingAlertControlSoapHttpBinding.html","ThresholdCrossingAlertControlSoapHttpBinding",false,new Array(new WCN("24/operation/createTcaParameterProfile_3.html","createTcaParameterProfile",false,null),new WCN("24/operation/deleteTcaParameterProfile_4.html","deleteTcaParameterProfile",false,null),new WCN("24/operation/disableTca_5.html","disableTca",false,null),new WCN("24/operation/enableTca_6.html","enableTca",false,null),new WCN("24/operation/getAllTcaParameterProfileNames_7.html","getAllTcaParameterProfileNames",false,null),new WCN("24/operation/getAllTcaParameterProfiles_8.html","getAllTcaParameterProfiles",false,null),new WCN("24/operation/getTcaParameterProfile_9.html","getTcaParameterProfile",false,null),new WCN("24/operation/getTcaParameterProfileNamesIterator_14.html","getTcaParameterProfileNamesIterator",false,null),new WCN("24/operation/getTcaParameterProfilesIterator_15.html","getTcaParameterProfilesIterator",false,null),new WCN("24/operation/getTcaTpParameter_10.html","getTcaTpParameter",false,null),new WCN("24/operation/setTcaParameterProfile_11.html","setTcaParameterProfile",false,null),new WCN("24/operation/setTcaParameterProfilePointer_12.html","setTcaParameterProfilePointer",false,null),new WCN("24/operation/setTcaTpParameter_13.html","setTcaTpParameter",false,null))),new WCN("24/binding/ThresholdCrossingAlertControlSoapJmsBinding.html","ThresholdCrossingAlertControlSoapJmsBinding",false,new Array(new WCN("24/operation/createTcaParameterProfile_3.html","createTcaParameterProfile",false,null),new WCN("24/operation/deleteTcaParameterProfile_4.html","deleteTcaParameterProfile",false,null),new WCN("24/operation/disableTca_5.html","disableTca",false,null),new WCN("24/operation/enableTca_6.html","enableTca",false,null),new WCN("24/operation/getAllTcaParameterProfileNames_7.html","getAllTcaParameterProfileNames",false,null),new WCN("24/operation/getAllTcaParameterProfiles_8.html","getAllTcaParameterProfiles",false,null),new WCN("24/operation/getTcaParameterProfile_9.html","getTcaParameterProfile",false,null),new WCN("24/operation/getTcaParameterProfileNamesIterator_14.html","getTcaParameterProfileNamesIterator",false,null),new WCN("24/operation/getTcaParameterProfilesIterator_15.html","getTcaParameterProfilesIterator",false,null),new WCN("24/operation/getTcaTpParameter_10.html","getTcaTpParameter",false,null),new WCN("24/operation/setTcaParameterProfile_11.html","setTcaParameterProfile",false,null),new WCN("24/operation/setTcaParameterProfilePointer_12.html","setTcaParameterProfilePointer",false,null),new WCN("24/operation/setTcaTpParameter_13.html","setTcaTpParameter",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rpm/wsdl/tcac/v1-0"] = "24/index.html";
