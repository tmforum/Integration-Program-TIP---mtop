﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_ciFileName = "componentIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function CN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function C (attributeList, attributeGroupList,
						simpleTypeList, complexTypeList,
						modelGroupList, elementList, 
						notationList) 
{
	this.attributes = attributeList;
	this.attributegroups = attributeGroupList;
	this.simpletypes = simpleTypeList;
	this.complextypes = complexTypeList;
	this.modelgroups = modelGroupList;
	this.elements = elementList;
	this.notations = notationList;
}

function component_showAllComponents() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_ciFileName;
}

function component_filterComponents () {
	parent._href = "xsd/" + xsd_ciFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function component_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href=xsd_ciFileName;	
}

function component_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in componentDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}

	parent._xsdNsFilter = nsList;
}

function component_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	component_outputList (null, components);	
}


function component_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		component_outputList (namespace, list);	
	}
}


function component_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		component_showComponentsNS (nsList, componentList)
	} else {
		component_showComponentsNoNS (nsList, componentList)
	}
}

function component_showAttributes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		attributes [i] = componentDB [nsList[i]].attributes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributes);
}

function component_showAttributeGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributegroups = new Array();
	var nss = new Array();		

	for (var i=0; i<nsList.length; i++) {
		attributegroups [i] = componentDB [nsList[i]].attributegroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributegroups);
}

function component_showSimpleTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var simpletypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		simpletypes [i] = componentDB [nsList[i]].simpletypes;	
		nss [i] = nsList[i];
	}		

	component_showComponents (nss, simpletypes);
}

function component_showComplexTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var complextypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		complextypes [i] = componentDB [nsList[i]].complextypes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, complextypes);
}

function component_showElements() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var elements = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		elements [i] = componentDB [nsList[i]].elements;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, elements);
}

function component_showModelGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var modelgroups = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		modelgroups [i] = componentDB [nsList[i]].modelgroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, modelgroups);
}

function component_showNotations() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var notations = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		notations [i] = componentDB [nsList[i]].notations;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, notations);

}


function component_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function component_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+component_getNodeText(node)+
			  '" target="'+target+'">'+component_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function component_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+component_getNodeText(node)+
			'" target="'+target+'">'+component_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		component_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function component_outputTree (node) {
	if (node.hasChild == false) {
		component_outputLeaf (node);
	} else {
		component_outputNonLeaf (node);
	}
}

function component_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = componentNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+target+'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		component_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}


var componentDB = new Array();
var componentNSMap = new Array();

componentDB ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("7/complextype/AttributeValueChangeType.html","AttributeValueChangeType",false,new Array(new CN("7/element/111.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] = "7/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("6/complextype/CommonEventInformationType.html","CommonEventInformationType",false,new Array(new CN("6/element/34.html","notificationId",false,null),new CN("6/element/35.html","sourceTime",false,null),new CN("6/element/36.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("6/element/commonEventInformation.html","commonEventInformation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "6/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("3/complextype/CommonObjectInfoType.html","CommonObjectInfoType",false,new Array(new CN("3/element/17.html","name",false,null),new CN("3/element/49.html","userLabel",false,null),new CN("3/element/50.html","discoveredName",false,null),new CN("3/element/51.html","namingOs",false,null),new CN("3/element/52.html","owner",false,null),new CN("3/element/53.html","aliasNameList",false,null),new CN("3/element/54.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("3/element/commonObjectInfo.html","commonObjectInfo",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "3/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("4/complextype/EventInformationType.html","EventInformationType",false,new Array(new CN("4/element/32.html","objectType",false,null),new CN("4/element/19.html","objectName",false,null),new CN("4/element/33.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "4/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("5/simpletype/DiscoveredNameType.html","DiscoveredNameType",false,null),new CN("5/simpletype/LocationType.html","LocationType",false,null),new CN("5/simpletype/ManufactureDateType.html","ManufactureDateType",false,null),new CN("5/simpletype/ManufacturerType.html","ManufacturerType",false,null),new CN("5/simpletype/NamingOperationsSystemType.html","NamingOperationsSystemType",false,null),new CN("5/simpletype/NetworkAccessDomainType.html","NetworkAccessDomainType",false,null),new CN("5/simpletype/NotificationIdentifierType.html","NotificationIdentifierType",false,null),new CN("5/simpletype/ObjectEnumType.html","ObjectEnumType",false,null),new CN("5/simpletype/ObjectTypeType.html","ObjectTypeType",false,null),new CN("5/simpletype/OwnerType.html","OwnerType",false,null),new CN("5/simpletype/ProductNameType.html","ProductNameType",false,null),new CN("5/simpletype/QueryDialectEnumType.html","QueryDialectEnumType",false,null),new CN("5/simpletype/QueryDialectTypeType.html","QueryDialectTypeType",false,null),new CN("5/simpletype/UserLabelType.html","UserLabelType",false,null)),
					new Array(new CN("5/complextype/AliasNameListType.html","AliasNameListType",false,new Array(new CN("5/element/101.html","alias",false,null),new CN("5/element/102.html","alias/aliasName",false,null),new CN("5/element/103.html","alias/aliasValue",false,null))),new CN("5/complextype/AnyListType.html","AnyListType",false,null),new CN("5/complextype/MultiEventInventoryAttributesType.html","MultiEventInventoryAttributesType",false,new Array(new CN("5/element/104.html","neTime",false,null),new CN("5/element/105.html","eventIndication",false,null))),new CN("5/complextype/NameAndAnyValueListType.html","NameAndAnyValueListType",false,new Array(new CN("5/element/106.html","nv",false,null))),new CN("5/complextype/NameAndAnyValueType.html","NameAndAnyValueType",false,new Array(new CN("5/element/107.html","name",false,null))),new CN("5/complextype/NameAndStringValueType.html","NameAndStringValueType",false,new Array(new CN("5/element/108.html","name",false,null),new CN("5/element/109.html","value",false,null))),new CN("5/complextype/NameAndValueStringListType.html","NameAndValueStringListType",false,new Array(new CN("5/element/110.html","nvs",false,null))),new CN("5/complextype/NotificationIdentifierListType.html","NotificationIdentifierListType",false,new Array(new CN("5/element/100.html","notificationId",false,null))),new CN("5/complextype/QueryExpressionType.html","QueryExpressionType",false,null)),
					new Array(),
					new Array(new CN("5/element/nvList.html","nvList",false,null),new CN("5/element/nvsList.html","nvsList",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "5/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("1/complextype/NamingAttributeListType.html","NamingAttributeListType",false,new Array(new CN("1/element/0.html","name",false,null))),new CN("1/complextype/NamingAttributeType.html","NamingAttributeType",false,new Array(new CN("1/element/16.html","rdn",false,null))),new CN("1/complextype/RelativeDistinguishNameType.html","RelativeDistinguishNameType",false,new Array(new CN("1/element/30.html","type",false,null),new CN("1/element/31.html","value",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "1/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("8/complextype/ObjectCreationType.html","ObjectCreationType",false,new Array(new CN("8/element/37.html","object",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] = "8/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("9/complextype/ObjectDeletionType.html","ObjectDeletionType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] = "9/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("10/complextype/StateChangeType.html","StateChangeType",false,new Array(new CN("10/element/38.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] = "10/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("13/complextype/CommonServiceInfoType.html","CommonServiceInfoType",false,new Array(new CN("13/element/39.html","description",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] = "13/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/savc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("15/complextype/ServiceAttributeValueChangeType.html","ServiceAttributeValueChangeType",false,null)),
					new Array(),
					new Array(new CN("15/element/serviceAttributeValueChange.html","serviceAttributeValueChange",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/savc/v1"] = "15/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/soc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("11/complextype/ServiceObjectCreationType.html","ServiceObjectCreationType",false,null)),
					new Array(),
					new Array(new CN("11/element/serviceObjectCreation.html","serviceObjectCreation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/soc/v1"] = "11/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/sodel/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("14/complextype/ServiceObjectDeletionType.html","ServiceObjectDeletionType",false,null)),
					new Array(),
					new Array(new CN("14/element/serviceObjectDeletion.html","serviceObjectDeletion",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/sodel/v1"] = "14/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/ssc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("12/complextype/ServiceStateChangeType.html","ServiceStateChangeType",false,null)),
					new Array(),
					new Array(new CN("12/element/ServiceStateChange.html","ServiceStateChange",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/ssc/v1"] = "12/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/svc/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("2/simpletype/AdminStateType.html","AdminStateType",false,null),new CN("2/simpletype/OperationalStateType.html","OperationalStateType",false,null),new CN("2/simpletype/ServiceDefinitionStatusType.html","ServiceDefinitionStatusType",false,null),new CN("2/simpletype/ServiceStateType.html","ServiceStateType",false,null),new CN("2/simpletype/ServiceTemplateStatusType.html","ServiceTemplateStatusType",false,null),new CN("2/simpletype/StartModeType.html","StartModeType",false,null)),
					new Array(new CN("2/complextype/CustomerFacingServiceType.html","CustomerFacingServiceType",false,new Array(new CN("2/element/18.html","productRef",false,null))),new CN("2/complextype/PartyRoleType.html","PartyRoleType",false,new Array(new CN("2/element/59.html","partyRoleId",false,null),new CN("2/element/60.html","status",false,null),new CN("2/element/61.html","validFor",false,null))),new CN("2/complextype/ResourceFacingServiceType.html","ResourceFacingServiceType",false,new Array(new CN("2/element/20.html","cfsRef",false,null))),new CN("2/complextype/SapSpecificationType.html","SapSpecificationType",false,new Array(new CN("2/element/64.html","type",false,null),new CN("2/element/65.html","applicableServiceList",false,null),new CN("2/element/66.html","applicableStateValueList",false,null),new CN("2/element/1.html","supportedSdRefList",false,null))),new CN("2/complextype/ServiceAccessPointType.html","ServiceAccessPointType",false,new Array(new CN("2/element/40.html","adminState",false,null),new CN("2/element/45.html","serviceState",false,null),new CN("2/element/42.html","operationalState",false,null),new CN("2/element/23.html","subscriberRef",false,null),new CN("2/element/2.html","userRefList",false,null),new CN("2/element/21.html","resourceRef",false,null),new CN("2/element/22.html","sapSpecRef",false,null))),new CN("2/complextype/ServiceCatalogType.html","ServiceCatalogType",false,new Array(new CN("2/element/3.html","sscRefList",false,null),new CN("2/element/4.html","ssDefinitionRefList",false,null),new CN("2/element/5.html","ssTemplateRefList",false,null))),new CN("2/complextype/ServiceCharacteristicValueType.html","ServiceCharacteristicValueType",false,new Array(new CN("2/element/70.html","value",false,null),new CN("2/element/71.html","validFor",false,null),new CN("2/element/24.html","sscRef",false,null))),new CN("2/complextype/ServiceDefinitionType.html","ServiceDefinitionType",false,new Array(new CN("2/element/72.html","activationMode",false,null),new CN("2/element/44.html","sdStatus",false,null),new CN("2/element/7.html","sapSpecificationRefList",false,null),new CN("2/element/6.html","dependencyRefList",false,null),new CN("2/element/8.html","validatesRefList",false,null))),new CN("2/complextype/ServiceSpecCharacteristicType.html","ServiceSpecCharacteristicType",false,new Array(new CN("2/element/76.html","valueType",false,null),new CN("2/element/77.html","minCardinality",false,null),new CN("2/element/78.html","maxCardinality",false,null),new CN("2/element/79.html","derivationFormula",false,null),new CN("2/element/80.html","validFor",false,null),new CN("2/element/9.html","containedBySscRefList",false,null),new CN("2/element/10.html","containsSscRefList",false,null),new CN("2/element/25.html","productScRef",false,null),new CN("2/element/11.html","serviceCatalogRefList",false,null),new CN("2/element/81.html","valueList",false,null))),new CN("2/complextype/ServiceSpecCharacteristicUseType.html","ServiceSpecCharacteristicUseType",false,new Array(new CN("2/element/90.html","globallySet",false,null),new CN("2/element/91.html","canBeOveridden",false,null),new CN("2/element/92.html","minCardinality",false,null),new CN("2/element/93.html","maxCardinality",false,null),new CN("2/element/94.html","extensible",false,null),new CN("2/element/95.html","validFor",false,null))),new CN("2/complextype/ServiceSpecCharacteristicValueType.html","ServiceSpecCharacteristicValueType",false,new Array(new CN("2/element/82.html","valueType",false,null),new CN("2/element/83.html","default",false,null),new CN("2/element/84.html","value",false,null),new CN("2/element/85.html","unitOfMeasure",false,null),new CN("2/element/86.html","valueFrom",false,null),new CN("2/element/87.html","valueTo",false,null),new CN("2/element/88.html","rangeInterval",false,null),new CN("2/element/89.html","validFor",false,null))),new CN("2/complextype/ServiceSpecCharInUseType.html","ServiceSpecCharInUseType",false,new Array(new CN("2/element/26.html","sscRef",false,null),new CN("2/element/96.html","sscUse",false,null),new CN("2/element/97.html","valueList",false,null))),new CN("2/complextype/ServiceSpecificationType.html","ServiceSpecificationType",false,new Array(new CN("2/element/73.html","serviceSpecType",false,null),new CN("2/element/74.html","version",false,null),new CN("2/element/12.html","productSpecRefList",false,null),new CN("2/element/13.html","serviceCatalogRefList",false,null),new CN("2/element/75.html","describedByList",false,null))),new CN("2/complextype/ServiceSpecificationTypeType.html","ServiceSpecificationTypeType",false,new Array(new CN("2/element/67.html","name",false,null),new CN("2/element/68.html","description",false,null),new CN("2/element/69.html","version",false,null))),new CN("2/complextype/ServiceTemplateType.html","ServiceTemplateType",false,new Array(new CN("2/element/98.html","source",false,null),new CN("2/element/99.html","serviceLocation",false,null),new CN("2/element/47.html","stStatus",false,null),new CN("2/element/27.html","validatedByRef",false,null))),new CN("2/complextype/ServiceType.html","ServiceType",false,new Array(new CN("2/element/55.html","hasStarted",false,null),new CN("2/element/56.html","isMandatory",false,null),new CN("2/element/48.html","startMode",false,null),new CN("2/element/57.html","isStateful",false,null),new CN("2/element/41.html","adminState",false,null),new CN("2/element/46.html","serviceState",false,null),new CN("2/element/43.html","operationalState",false,null),new CN("2/element/28.html","serviceTemplateRef",false,null),new CN("2/element/29.html","subscriberRef",false,null),new CN("2/element/15.html","userRefList",false,null),new CN("2/element/14.html","sapRefList",false,null),new CN("2/element/58.html","describedByList",false,null))),new CN("2/complextype/SubscriberType.html","SubscriberType",false,null),new CN("2/complextype/TimePeriodType.html","TimePeriodType",false,new Array(new CN("2/element/62.html","startDateTime",false,null),new CN("2/element/63.html","endDateTime",false,null))),new CN("2/complextype/UserType.html","UserType",false,null)),
					new Array(),
					new Array(new CN("2/element/serviceCatalog.html","serviceCatalog",false,null),new CN("2/element/serviceDefinition.html","serviceDefinition",false,null),new CN("2/element/serviceSpecCharacteristicUseType.html","serviceSpecCharacteristicUseType",false,null),new CN("2/element/serviceSpecCharInUseType.html","serviceSpecCharInUseType",false,null),new CN("2/element/serviceSpecification.html","serviceSpecification",false,null),new CN("2/element/serviceTemplate.html","serviceTemplate",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/svc/v1"] = "2/index.html";
								   


