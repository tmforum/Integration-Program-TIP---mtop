﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_tiFileName = "typeTreeIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function TN (href, prefix, ns, name, relation, simpletypeflag, children) {
	this.href = href;
	this.prefix = prefix;
	this.namespace = ns;
	this.name = name;
	this.relation = relation;
	this.simpletypeflag = simpletypeflag;
	this.children = children;

	this.hasChild = (children != null) && (children.length>0);	
}

function T (typeTree)
{
	this.typeTree = typeTree;
}

function typetree_showAllTypes() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_tiFileName;
}

function typetree_filterTypes () {
	parent._href = "xsd/" + xsd_tiFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");
}

function typetree_showTypes() {
	if (parent._xsdNsFilter == null) {
		typetree_setFilterToAll();
	}

	var nsList = parent._xsdNsFilter;
	var typetrees = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		typetrees [i] = typetreeDB [nsList[i]];	
		nss[i] = nsList[i];
	}		
	
	typetree_showTree (nss, typetrees); 
}

function typetree_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in typetreeDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}


	parent._xsdNsFilter = nsList;
}


function typetree_showTree (nsList, typetrees) {
	for (var i=0; i<nsList.length; i++) {
		var fpath = typetreeNSMap[nsList[i]];
		
		var str = '<div class="nsBox"><div class="itemNS">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+fpath+
			'" title="'+encodeURI(nsList[i])+
			'" target="'+target+'">'+encodeURI(nsList[i])+'</a></nobr></div>'+
			'<div style="margin-left: 0.5em">';		

		document.write (str);

		typetree_outputList (typetrees[i].typeTree);
		

		document.write ('</div></div>');
	}
} 

function typetree_outputList (list) {
	for (var i=0; i<list.length; i++) {
		typetree_outputTree (list[i]);
	}
}

function typetree_outputTree (node) {
	if (node.hasChild == false) {
		typetree_outputLeaf (node);
	} else {
		typetree_outputNonLeaf (node);
	}
}


function typetree_outputLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node)
	} else {
		nodeStr = anchorString (node)
	}

	str = '<span class="leaf"><nobr>' +
		  '<img src="img/leaf.gif" hspace="2" align="middle">' + 
		  nodeStr + '</nobr></span><br />';

	document.write (str);
}

function prefixedAnchorString (node) {
	return  '<a class="chref" href="'+node.href+
			'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+
			node.prefix+':'+'</a>'+
			'<a class="chref" href="'+node.href+'" target="'+target+ '"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);
}

function anchorString (node) {
	return 	'<a class="chref" href="'+node.href+'" target="'+target+'"'+
			' title="ns=' + encodeURI(node.namespace)+'">'+ node.name +
			'</a>'+typetree_getNodeIcon(node);

}

function typetree_outputNonLeaf (node) {
	var str = null;
	var nodeStr = null;

	if (node.prefix.length>0) {
		nodeStr = prefixedAnchorString(node);
	} else {
		nodeStr = anchorString (node);
	}
		
	str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			nodeStr +
			'</nobr></div>'+
			'<div style="margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		typetree_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function typetree_getNodeIcon(node) {
	var rStr = null;
	if (node.relation == "none") {
		rStr = "";
	} else if (node.relation == "extension") {
		rStr = '<img alt="derived by extension" border="0" hspace="2" align="middle" src="img/extension.gif">';
	
	} else if (node.relation == "restriction") {
		rStr = '<img alt="derived by restriction" border="0" hspace="2" align="middle" src="img/restriction.gif">';
	
	} else if (node.relation == "list") {
		rStr = '<img alt="derived by list" border="0" hspace="2" align="middle" src="img/list.gif">';
	
	} else if (node.relation == "union") {
		rStr = '<img alt="derived by union" border="0" hspace="2" align="middle" src="img/union.gif">';
	
	}
	
	var typeStr = null;
	
	if (node.simpletypeflag) {
		typeStr = '<img alt="simple type" border="0" hspace="2" align="middle" src="img/simple.gif">'; 
	} else {
		typeStr = '<img alt="complex type" border="0" hspace="2" align="middle" src="img/complex.gif">';	
	} 

	return typeStr + rStr;
}

var typetreeDB = new Array();
var typetreeNSMap = new Array();

typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("7/complextype/AttributeValueChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/avc/v1","AttributeValueChangeType","extension",false,new Array(new TN("15/complextype/ServiceAttributeValueChangeType.html","","http://www.tmforum.org/mtop/sb/xsd/savc/v1","ServiceAttributeValueChangeType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] = "7/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "6/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new T (new Array (new TN("4/complextype/CommonObjectInfoType.html","","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("13/complextype/CommonServiceInfoType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","CommonServiceInfoType","extension",false,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "4/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("7/complextype/AttributeValueChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/avc/v1","AttributeValueChangeType","extension",false,null),new TN("8/complextype/ObjectCreationType.html","","http://www.tmforum.org/mtop/fmw/xsd/oc/v1","ObjectCreationType","extension",false,null),new TN("9/complextype/ObjectDeletionType.html","","http://www.tmforum.org/mtop/fmw/xsd/odel/v1","ObjectDeletionType","extension",false,null),new TN("10/complextype/StateChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/sc/v1","StateChangeType","extension",false,null)))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "5/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new T (new Array (new TN("3/complextype/AliasNameListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AliasNameListType","none",false,null),new TN("3/complextype/AnyListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","AnyListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#date","xsd","http://www.w3.org/2001/XMLSchema","date","none",true,new Array(new TN("3/simpletype/ManufactureDateType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufactureDateType","restriction",true,null))),new TN("3/complextype/MultiEventInventoryAttributesType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","MultiEventInventoryAttributesType","none",false,null),new TN("3/complextype/NotificationIdentifierListType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierListType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("3/simpletype/DiscoveredNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","DiscoveredNameType","restriction",true,null),new TN("3/simpletype/LocationType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","LocationType","restriction",true,null),new TN("3/simpletype/ManufacturerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ManufacturerType","restriction",true,null),new TN("3/simpletype/NamingOperationsSystemType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NamingOperationsSystemType","restriction",true,null),new TN("3/simpletype/NetworkAccessDomainType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NetworkAccessDomainType","restriction",true,null),new TN("3/simpletype/NotificationIdentifierType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","NotificationIdentifierType","restriction",true,null),new TN("3/simpletype/ObjectEnumType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectEnumType","restriction",true,null),new TN("3/simpletype/ObjectTypeType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ObjectTypeType","restriction",true,null),new TN("3/simpletype/OwnerType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","OwnerType","restriction",true,null),new TN("3/simpletype/ProductNameType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","ProductNameType","restriction",true,null),new TN("3/simpletype/UserLabelType.html","","http://www.tmforum.org/mtop/fmw/xsd/gen/v1","UserLabelType","restriction",true,null)))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "3/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new T (new Array (new TN("1/complextype/NameAndAnyValueListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NameAndAnyValueListType","none",false,null),new TN("1/complextype/NameAndAnyValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NameAndAnyValueType","none",false,null),new TN("1/complextype/NameAndStringValueType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NameAndStringValueType","none",false,null),new TN("1/complextype/NameAndValueStringListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NameAndValueStringListType","none",false,null),new TN("1/complextype/NamingAttributeListType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeListType","none",false,null),new TN("1/complextype/NamingAttributeType.html","","http://www.tmforum.org/mtop/fmw/xsd/nam/v1","NamingAttributeType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "1/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("8/complextype/ObjectCreationType.html","","http://www.tmforum.org/mtop/fmw/xsd/oc/v1","ObjectCreationType","extension",false,new Array(new TN("11/complextype/ServiceObjectCreationType.html","","http://www.tmforum.org/mtop/sb/xsd/soc/v1","ServiceObjectCreationType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] = "8/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("9/complextype/ObjectDeletionType.html","","http://www.tmforum.org/mtop/fmw/xsd/odel/v1","ObjectDeletionType","extension",false,new Array(new TN("14/complextype/ServiceObjectDeletionType.html","","http://www.tmforum.org/mtop/sb/xsd/sodel/v1","ServiceObjectDeletionType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] = "9/index.html";
typetreeDB ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("10/complextype/StateChangeType.html","","http://www.tmforum.org/mtop/fmw/xsd/sc/v1","StateChangeType","extension",false,new Array(new TN("12/complextype/ServiceStateChangeType.html","","http://www.tmforum.org/mtop/sb/xsd/ssc/v1","ServiceStateChangeType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] = "10/index.html";
typetreeDB ["http://www.tmforum.org/mtop/sb/svc/v1"] =  new T (new Array (new TN("4/complextype/CommonObjectInfoType.html","fmw.coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("13/complextype/CommonServiceInfoType.html","csi","http://www.tmforum.org/mtop/sb/xsd/csi/v1","CommonServiceInfoType","restriction",false,new Array(new TN("2/complextype/service.html","tns","http://www.tmforum.org/mtop/sb/svc/v1","service","extension",false,new Array(new TN("2/complextype/customerFacingService.html","","http://www.tmforum.org/mtop/sb/svc/v1","customerFacingService","extension",false,null),new TN("2/complextype/resourceFacingService.html","","http://www.tmforum.org/mtop/sb/svc/v1","resourceFacingService","extension",false,null))),new TN("2/complextype/ServiceSpecificationType.html","tns","http://www.tmforum.org/mtop/sb/svc/v1","ServiceSpecificationType","extension",false,new Array(new TN("2/complextype/ServiceDefinitionType.html","","http://www.tmforum.org/mtop/sb/svc/v1","ServiceDefinitionType","extension",false,null),new TN("2/complextype/ServiceTemplateType.html","","http://www.tmforum.org/mtop/sb/svc/v1","ServiceTemplateType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/sb/svc/v1"] = "2/index.html";
typetreeDB ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] =  new T (new Array (new TN("4/complextype/CommonObjectInfoType.html","fmw.coi","http://www.tmforum.org/mtop/fmw/xsd/coi/v1","CommonObjectInfoType","none",false,new Array(new TN("13/complextype/CommonServiceInfoType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","CommonServiceInfoType","restriction",false,new Array(new TN("2/complextype/service.html","","http://www.tmforum.org/mtop/sb/svc/v1","service","extension",false,null),new TN("13/complextype/ServiceSpecCharType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","ServiceSpecCharType","extension",false,null),new TN("2/complextype/ServiceSpecificationType.html","","http://www.tmforum.org/mtop/sb/svc/v1","ServiceSpecificationType","extension",false,null))))),new TN("13/complextype/PartyRoleType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","PartyRoleType","none",false,new Array(new TN("13/complextype/SubscriberType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","SubscriberType","restriction",false,null),new TN("13/complextype/UserType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","UserType","restriction",false,null))),new TN("13/complextype/ServiceAccessPointType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","ServiceAccessPointType","none",false,null),new TN("13/complextype/ServiceCharValueType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","ServiceCharValueType","none",false,null),new TN("13/complextype/ServiceSpecCharValueType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","ServiceSpecCharValueType","none",false,null),new TN("13/complextype/ServiceSpecVersionType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","ServiceSpecVersionType","none",false,null),new TN("http://www.w3.org/TR/xmlschema-2/#string","xsd","http://www.w3.org/2001/XMLSchema","string","none",true,new Array(new TN("13/simpletype/OperStateType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","OperStateType","restriction",true,null),new TN("13/simpletype/ServiceStateType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","ServiceStateType","restriction",true,null))),new TN("13/complextype/TimePeriodType.html","","http://www.tmforum.org/mtop/sb/xsd/csi/v1","TimePeriodType","none",false,null)));
typetreeNSMap ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] = "13/index.html";
typetreeDB ["http://www.tmforum.org/mtop/sb/xsd/savc/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("7/complextype/AttributeValueChangeType.html","avc","http://www.tmforum.org/mtop/fmw/xsd/avc/v1","AttributeValueChangeType","extension",false,new Array(new TN("15/complextype/ServiceAttributeValueChangeType.html","","http://www.tmforum.org/mtop/sb/xsd/savc/v1","ServiceAttributeValueChangeType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/sb/xsd/savc/v1"] = "15/index.html";
typetreeDB ["http://www.tmforum.org/mtop/sb/xsd/soc/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("8/complextype/ObjectCreationType.html","oc","http://www.tmforum.org/mtop/fmw/xsd/oc/v1","ObjectCreationType","extension",false,new Array(new TN("11/complextype/ServiceObjectCreationType.html","","http://www.tmforum.org/mtop/sb/xsd/soc/v1","ServiceObjectCreationType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/sb/xsd/soc/v1"] = "11/index.html";
typetreeDB ["http://www.tmforum.org/mtop/sb/xsd/sodel/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("9/complextype/ObjectDeletionType.html","odel","http://www.tmforum.org/mtop/fmw/xsd/odel/v1","ObjectDeletionType","extension",false,new Array(new TN("14/complextype/ServiceObjectDeletionType.html","","http://www.tmforum.org/mtop/sb/xsd/sodel/v1","ServiceObjectDeletionType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/sb/xsd/sodel/v1"] = "14/index.html";
typetreeDB ["http://www.tmforum.org/mtop/sb/xsd/ssc/v1"] =  new T (new Array (new TN("6/complextype/CommonEventInformationType.html","cei","http://www.tmforum.org/mtop/fmw/xsd/cei/v1","CommonEventInformationType","none",false,new Array(new TN("5/complextype/EventInformationType.html","ei","http://www.tmforum.org/mtop/fmw/xsd/ei/v1","EventInformationType","restriction",false,new Array(new TN("10/complextype/StateChangeType.html","sc","http://www.tmforum.org/mtop/fmw/xsd/sc/v1","StateChangeType","extension",false,new Array(new TN("12/complextype/ServiceStateChangeType.html","","http://www.tmforum.org/mtop/sb/xsd/ssc/v1","ServiceStateChangeType","extension",false,null)))))))));
typetreeNSMap ["http://www.tmforum.org/mtop/sb/xsd/ssc/v1"] = "12/index.html";
								   


