/*
 * XML Type:  ServiceObjectDeletionType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/sodel/v1
 * Java type: org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.sodel.v1.impl;
/**
 * An XML ServiceObjectDeletionType(@http://www.tmforum.org/mtop/sb/xsd/sodel/v1).
 *
 * This is a complex type.
 */
public class ServiceObjectDeletionTypeImpl extends org.tmforum.mtop.fmw.xsd.odel.v1.impl.ObjectDeletionTypeImpl implements org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType
{
    
    public ServiceObjectDeletionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
