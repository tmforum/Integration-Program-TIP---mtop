/*
 * XML Type:  ServiceStateType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1;


/**
 * An XML ServiceStateType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType.
 */
public interface ServiceStateType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ServiceStateType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sB137642067B43A8768970C32DE897552").resolveHandle("servicestatetype5409type");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum PLANNING_FEASIBILITY_CHECK = Enum.forString("PLANNING_FEASIBILITY_CHECK");
    static final Enum PLANNING_DESIGNED = Enum.forString("PLANNING_DESIGNED");
    static final Enum RESERVED = Enum.forString("RESERVED");
    static final Enum PROVISIONED_INACTIVE = Enum.forString("PROVISIONED_INACTIVE");
    static final Enum PROVISIONED_ACTIVE = Enum.forString("PROVISIONED_ACTIVE");
    static final Enum TERMINATED = Enum.forString("TERMINATED");
    
    static final int INT_PLANNING_FEASIBILITY_CHECK = Enum.INT_PLANNING_FEASIBILITY_CHECK;
    static final int INT_PLANNING_DESIGNED = Enum.INT_PLANNING_DESIGNED;
    static final int INT_RESERVED = Enum.INT_RESERVED;
    static final int INT_PROVISIONED_INACTIVE = Enum.INT_PROVISIONED_INACTIVE;
    static final int INT_PROVISIONED_ACTIVE = Enum.INT_PROVISIONED_ACTIVE;
    static final int INT_TERMINATED = Enum.INT_TERMINATED;
    
    /**
     * Enumeration value class for org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_PLANNING_FEASIBILITY_CHECK
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_PLANNING_FEASIBILITY_CHECK = 1;
        static final int INT_PLANNING_DESIGNED = 2;
        static final int INT_RESERVED = 3;
        static final int INT_PROVISIONED_INACTIVE = 4;
        static final int INT_PROVISIONED_ACTIVE = 5;
        static final int INT_TERMINATED = 6;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("PLANNING_FEASIBILITY_CHECK", INT_PLANNING_FEASIBILITY_CHECK),
                new Enum("PLANNING_DESIGNED", INT_PLANNING_DESIGNED),
                new Enum("RESERVED", INT_RESERVED),
                new Enum("PROVISIONED_INACTIVE", INT_PROVISIONED_INACTIVE),
                new Enum("PROVISIONED_ACTIVE", INT_PROVISIONED_ACTIVE),
                new Enum("TERMINATED", INT_TERMINATED),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType newValue(java.lang.Object obj) {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) type.newValue( obj ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType newInstance() {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
