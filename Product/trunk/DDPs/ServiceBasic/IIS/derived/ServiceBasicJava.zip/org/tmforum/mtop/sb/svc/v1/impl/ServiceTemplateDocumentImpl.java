/*
 * An XML document type.
 * Localname: serviceTemplate
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ServiceTemplateDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * A document containing one serviceTemplate(@http://www.tmforum.org/mtop/sb/svc/v1) element.
 *
 * This is a complex type.
 */
public class ServiceTemplateDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sb.svc.v1.ServiceTemplateDocument
{
    
    public ServiceTemplateDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICETEMPLATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceTemplate");
    
    
    /**
     * Gets the "serviceTemplate" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceTemplateType getServiceTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceTemplateType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceTemplateType)get_store().find_element_user(SERVICETEMPLATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "serviceTemplate" element
     */
    public void setServiceTemplate(org.tmforum.mtop.sb.svc.v1.ServiceTemplateType serviceTemplate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceTemplateType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceTemplateType)get_store().find_element_user(SERVICETEMPLATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.svc.v1.ServiceTemplateType)get_store().add_element_user(SERVICETEMPLATE$0);
            }
            target.set(serviceTemplate);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceTemplate" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceTemplateType addNewServiceTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceTemplateType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceTemplateType)get_store().add_element_user(SERVICETEMPLATE$0);
            return target;
        }
    }
}
