/*
 * XML Type:  ServiceDefinitionType
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * An XML ServiceDefinitionType(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public class ServiceDefinitionTypeImpl extends org.tmforum.mtop.sb.svc.v1.impl.ServiceSpecificationTypeImpl implements org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType
{
    
    public ServiceDefinitionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACTIVATIONMODE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "activationMode");
    private static final javax.xml.namespace.QName TYPEOFDEFINITION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "typeOfDefinition");
    private static final javax.xml.namespace.QName SDSTATUS$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "sdStatus");
    
    
    /**
     * Gets the "activationMode" element
     */
    public java.lang.String getActivationMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVATIONMODE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "activationMode" element
     */
    public org.apache.xmlbeans.XmlString xgetActivationMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ACTIVATIONMODE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "activationMode" element
     */
    public boolean isSetActivationMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACTIVATIONMODE$0) != 0;
        }
    }
    
    /**
     * Sets the "activationMode" element
     */
    public void setActivationMode(java.lang.String activationMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVATIONMODE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACTIVATIONMODE$0);
            }
            target.setStringValue(activationMode);
        }
    }
    
    /**
     * Sets (as xml) the "activationMode" element
     */
    public void xsetActivationMode(org.apache.xmlbeans.XmlString activationMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ACTIVATIONMODE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ACTIVATIONMODE$0);
            }
            target.set(activationMode);
        }
    }
    
    /**
     * Unsets the "activationMode" element
     */
    public void unsetActivationMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACTIVATIONMODE$0, 0);
        }
    }
    
    /**
     * Gets the "typeOfDefinition" element
     */
    public java.lang.String getTypeOfDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPEOFDEFINITION$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "typeOfDefinition" element
     */
    public org.apache.xmlbeans.XmlString xgetTypeOfDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPEOFDEFINITION$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "typeOfDefinition" element
     */
    public boolean isSetTypeOfDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TYPEOFDEFINITION$2) != 0;
        }
    }
    
    /**
     * Sets the "typeOfDefinition" element
     */
    public void setTypeOfDefinition(java.lang.String typeOfDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPEOFDEFINITION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TYPEOFDEFINITION$2);
            }
            target.setStringValue(typeOfDefinition);
        }
    }
    
    /**
     * Sets (as xml) the "typeOfDefinition" element
     */
    public void xsetTypeOfDefinition(org.apache.xmlbeans.XmlString typeOfDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TYPEOFDEFINITION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TYPEOFDEFINITION$2);
            }
            target.set(typeOfDefinition);
        }
    }
    
    /**
     * Unsets the "typeOfDefinition" element
     */
    public void unsetTypeOfDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TYPEOFDEFINITION$2, 0);
        }
    }
    
    /**
     * Gets the "sdStatus" element
     */
    public java.lang.String getSdStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SDSTATUS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "sdStatus" element
     */
    public org.apache.xmlbeans.XmlString xgetSdStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SDSTATUS$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "sdStatus" element
     */
    public boolean isSetSdStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SDSTATUS$4) != 0;
        }
    }
    
    /**
     * Sets the "sdStatus" element
     */
    public void setSdStatus(java.lang.String sdStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SDSTATUS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SDSTATUS$4);
            }
            target.setStringValue(sdStatus);
        }
    }
    
    /**
     * Sets (as xml) the "sdStatus" element
     */
    public void xsetSdStatus(org.apache.xmlbeans.XmlString sdStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SDSTATUS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SDSTATUS$4);
            }
            target.set(sdStatus);
        }
    }
    
    /**
     * Unsets the "sdStatus" element
     */
    public void unsetSdStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SDSTATUS$4, 0);
        }
    }
}
