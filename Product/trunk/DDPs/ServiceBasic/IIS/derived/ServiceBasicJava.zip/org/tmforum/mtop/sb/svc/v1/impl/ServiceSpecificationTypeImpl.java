/*
 * XML Type:  ServiceSpecificationType
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * An XML ServiceSpecificationType(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public class ServiceSpecificationTypeImpl extends org.tmforum.mtop.sb.xsd.csi.v1.impl.CommonServiceInfoTypeImpl implements org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType
{
    
    public ServiceSpecificationTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICESPECIFICATIONHAS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceSpecificationHas");
    private static final javax.xml.namespace.QName SERVICESPECVERSION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceSpecVersion");
    private static final javax.xml.namespace.QName SERVICESPECCHARACTERISTIC$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceSpecCharacteristic");
    private static final javax.xml.namespace.QName SERVICESPECCHARACTERISTICVALUE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceSpecCharacteristicValue");
    
    
    /**
     * Gets a List of "serviceSpecificationHas" elements
     */
    public java.util.List<org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType> getServiceSpecificationHasList()
    {
        final class ServiceSpecificationHasList extends java.util.AbstractList<org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType>
        {
            public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType get(int i)
                { return ServiceSpecificationTypeImpl.this.getServiceSpecificationHasArray(i); }
            
            public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType set(int i, org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType o)
            {
                org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType old = ServiceSpecificationTypeImpl.this.getServiceSpecificationHasArray(i);
                ServiceSpecificationTypeImpl.this.setServiceSpecificationHasArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType o)
                { ServiceSpecificationTypeImpl.this.insertNewServiceSpecificationHas(i).set(o); }
            
            public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType remove(int i)
            {
                org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType old = ServiceSpecificationTypeImpl.this.getServiceSpecificationHasArray(i);
                ServiceSpecificationTypeImpl.this.removeServiceSpecificationHas(i);
                return old;
            }
            
            public int size()
                { return ServiceSpecificationTypeImpl.this.sizeOfServiceSpecificationHasArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceSpecificationHasList();
        }
    }
    
    /**
     * Gets array of all "serviceSpecificationHas" elements
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType[] getServiceSpecificationHasArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICESPECIFICATIONHAS$0, targetList);
            org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType[] result = new org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceSpecificationHas" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType getServiceSpecificationHasArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType)get_store().find_element_user(SERVICESPECIFICATIONHAS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceSpecificationHas" element
     */
    public int sizeOfServiceSpecificationHasArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESPECIFICATIONHAS$0);
        }
    }
    
    /**
     * Sets array of all "serviceSpecificationHas" element
     */
    public void setServiceSpecificationHasArray(org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType[] serviceSpecificationHasArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceSpecificationHasArray, SERVICESPECIFICATIONHAS$0);
        }
    }
    
    /**
     * Sets ith "serviceSpecificationHas" element
     */
    public void setServiceSpecificationHasArray(int i, org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType serviceSpecificationHas)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType)get_store().find_element_user(SERVICESPECIFICATIONHAS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceSpecificationHas);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecificationHas" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType insertNewServiceSpecificationHas(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType)get_store().insert_element_user(SERVICESPECIFICATIONHAS$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecificationHas" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType addNewServiceSpecificationHas()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType)get_store().add_element_user(SERVICESPECIFICATIONHAS$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceSpecificationHas" element
     */
    public void removeServiceSpecificationHas(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESPECIFICATIONHAS$0, i);
        }
    }
    
    /**
     * Gets a List of "serviceSpecVersion" elements
     */
    public java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType> getServiceSpecVersionList()
    {
        final class ServiceSpecVersionList extends java.util.AbstractList<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType>
        {
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType get(int i)
                { return ServiceSpecificationTypeImpl.this.getServiceSpecVersionArray(i); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType set(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType o)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType old = ServiceSpecificationTypeImpl.this.getServiceSpecVersionArray(i);
                ServiceSpecificationTypeImpl.this.setServiceSpecVersionArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType o)
                { ServiceSpecificationTypeImpl.this.insertNewServiceSpecVersion(i).set(o); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType remove(int i)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType old = ServiceSpecificationTypeImpl.this.getServiceSpecVersionArray(i);
                ServiceSpecificationTypeImpl.this.removeServiceSpecVersion(i);
                return old;
            }
            
            public int size()
                { return ServiceSpecificationTypeImpl.this.sizeOfServiceSpecVersionArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceSpecVersionList();
        }
    }
    
    /**
     * Gets array of all "serviceSpecVersion" elements
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType[] getServiceSpecVersionArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICESPECVERSION$2, targetList);
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType[] result = new org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceSpecVersion" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType getServiceSpecVersionArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType)get_store().find_element_user(SERVICESPECVERSION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceSpecVersion" element
     */
    public int sizeOfServiceSpecVersionArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESPECVERSION$2);
        }
    }
    
    /**
     * Sets array of all "serviceSpecVersion" element
     */
    public void setServiceSpecVersionArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType[] serviceSpecVersionArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceSpecVersionArray, SERVICESPECVERSION$2);
        }
    }
    
    /**
     * Sets ith "serviceSpecVersion" element
     */
    public void setServiceSpecVersionArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType serviceSpecVersion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType)get_store().find_element_user(SERVICESPECVERSION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceSpecVersion);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecVersion" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType insertNewServiceSpecVersion(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType)get_store().insert_element_user(SERVICESPECVERSION$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecVersion" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType addNewServiceSpecVersion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType)get_store().add_element_user(SERVICESPECVERSION$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceSpecVersion" element
     */
    public void removeServiceSpecVersion(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESPECVERSION$2, i);
        }
    }
    
    /**
     * Gets a List of "serviceSpecCharacteristic" elements
     */
    public java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType> getServiceSpecCharacteristicList()
    {
        final class ServiceSpecCharacteristicList extends java.util.AbstractList<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType>
        {
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType get(int i)
                { return ServiceSpecificationTypeImpl.this.getServiceSpecCharacteristicArray(i); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType set(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType o)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType old = ServiceSpecificationTypeImpl.this.getServiceSpecCharacteristicArray(i);
                ServiceSpecificationTypeImpl.this.setServiceSpecCharacteristicArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType o)
                { ServiceSpecificationTypeImpl.this.insertNewServiceSpecCharacteristic(i).set(o); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType remove(int i)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType old = ServiceSpecificationTypeImpl.this.getServiceSpecCharacteristicArray(i);
                ServiceSpecificationTypeImpl.this.removeServiceSpecCharacteristic(i);
                return old;
            }
            
            public int size()
                { return ServiceSpecificationTypeImpl.this.sizeOfServiceSpecCharacteristicArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceSpecCharacteristicList();
        }
    }
    
    /**
     * Gets array of all "serviceSpecCharacteristic" elements
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType[] getServiceSpecCharacteristicArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICESPECCHARACTERISTIC$4, targetList);
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType[] result = new org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceSpecCharacteristic" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType getServiceSpecCharacteristicArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType)get_store().find_element_user(SERVICESPECCHARACTERISTIC$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceSpecCharacteristic" element
     */
    public int sizeOfServiceSpecCharacteristicArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESPECCHARACTERISTIC$4);
        }
    }
    
    /**
     * Sets array of all "serviceSpecCharacteristic" element
     */
    public void setServiceSpecCharacteristicArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType[] serviceSpecCharacteristicArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceSpecCharacteristicArray, SERVICESPECCHARACTERISTIC$4);
        }
    }
    
    /**
     * Sets ith "serviceSpecCharacteristic" element
     */
    public void setServiceSpecCharacteristicArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType serviceSpecCharacteristic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType)get_store().find_element_user(SERVICESPECCHARACTERISTIC$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceSpecCharacteristic);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecCharacteristic" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType insertNewServiceSpecCharacteristic(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType)get_store().insert_element_user(SERVICESPECCHARACTERISTIC$4, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecCharacteristic" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType addNewServiceSpecCharacteristic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType)get_store().add_element_user(SERVICESPECCHARACTERISTIC$4);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceSpecCharacteristic" element
     */
    public void removeServiceSpecCharacteristic(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESPECCHARACTERISTIC$4, i);
        }
    }
    
    /**
     * Gets a List of "serviceSpecCharacteristicValue" elements
     */
    public java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType> getServiceSpecCharacteristicValueList()
    {
        final class ServiceSpecCharacteristicValueList extends java.util.AbstractList<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType>
        {
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType get(int i)
                { return ServiceSpecificationTypeImpl.this.getServiceSpecCharacteristicValueArray(i); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType set(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType o)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType old = ServiceSpecificationTypeImpl.this.getServiceSpecCharacteristicValueArray(i);
                ServiceSpecificationTypeImpl.this.setServiceSpecCharacteristicValueArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType o)
                { ServiceSpecificationTypeImpl.this.insertNewServiceSpecCharacteristicValue(i).set(o); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType remove(int i)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType old = ServiceSpecificationTypeImpl.this.getServiceSpecCharacteristicValueArray(i);
                ServiceSpecificationTypeImpl.this.removeServiceSpecCharacteristicValue(i);
                return old;
            }
            
            public int size()
                { return ServiceSpecificationTypeImpl.this.sizeOfServiceSpecCharacteristicValueArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceSpecCharacteristicValueList();
        }
    }
    
    /**
     * Gets array of all "serviceSpecCharacteristicValue" elements
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] getServiceSpecCharacteristicValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICESPECCHARACTERISTICVALUE$6, targetList);
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] result = new org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceSpecCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType getServiceSpecCharacteristicValueArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType)get_store().find_element_user(SERVICESPECCHARACTERISTICVALUE$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceSpecCharacteristicValue" element
     */
    public int sizeOfServiceSpecCharacteristicValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESPECCHARACTERISTICVALUE$6);
        }
    }
    
    /**
     * Sets array of all "serviceSpecCharacteristicValue" element
     */
    public void setServiceSpecCharacteristicValueArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] serviceSpecCharacteristicValueArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceSpecCharacteristicValueArray, SERVICESPECCHARACTERISTICVALUE$6);
        }
    }
    
    /**
     * Sets ith "serviceSpecCharacteristicValue" element
     */
    public void setServiceSpecCharacteristicValueArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType serviceSpecCharacteristicValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType)get_store().find_element_user(SERVICESPECCHARACTERISTICVALUE$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceSpecCharacteristicValue);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType insertNewServiceSpecCharacteristicValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType)get_store().insert_element_user(SERVICESPECCHARACTERISTICVALUE$6, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType addNewServiceSpecCharacteristicValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType)get_store().add_element_user(SERVICESPECCHARACTERISTICVALUE$6);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceSpecCharacteristicValue" element
     */
    public void removeServiceSpecCharacteristicValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESPECCHARACTERISTICVALUE$6, i);
        }
    }
}
