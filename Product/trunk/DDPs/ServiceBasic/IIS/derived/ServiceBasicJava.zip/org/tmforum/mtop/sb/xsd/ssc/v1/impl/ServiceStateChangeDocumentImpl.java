/*
 * An XML document type.
 * Localname: ServiceStateChange
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/ssc/v1
 * Java type: org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.ssc.v1.impl;
/**
 * A document containing one ServiceStateChange(@http://www.tmforum.org/mtop/sb/xsd/ssc/v1) element.
 *
 * This is a complex type.
 */
public class ServiceStateChangeDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeDocument
{
    
    public ServiceStateChangeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICESTATECHANGE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/ssc/v1", "ServiceStateChange");
    
    
    /**
     * Gets the "ServiceStateChange" element
     */
    public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType getServiceStateChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType)get_store().find_element_user(SERVICESTATECHANGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "ServiceStateChange" element
     */
    public void setServiceStateChange(org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType serviceStateChange)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType)get_store().find_element_user(SERVICESTATECHANGE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType)get_store().add_element_user(SERVICESTATECHANGE$0);
            }
            target.set(serviceStateChange);
        }
    }
    
    /**
     * Appends and returns a new empty "ServiceStateChange" element
     */
    public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType addNewServiceStateChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType)get_store().add_element_user(SERVICESTATECHANGE$0);
            return target;
        }
    }
}
