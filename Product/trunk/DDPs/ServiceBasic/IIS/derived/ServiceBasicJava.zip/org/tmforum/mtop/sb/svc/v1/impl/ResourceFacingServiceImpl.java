/*
 * XML Type:  resourceFacingService
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ResourceFacingService
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * An XML resourceFacingService(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public class ResourceFacingServiceImpl extends org.tmforum.mtop.sb.svc.v1.impl.ServiceImpl implements org.tmforum.mtop.sb.svc.v1.ResourceFacingService
{
    
    public ResourceFacingServiceImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RFSSTATUS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "rfsStatus");
    
    
    /**
     * Gets the "rfsStatus" element
     */
    public int getRfsStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RFSSTATUS$0, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "rfsStatus" element
     */
    public org.apache.xmlbeans.XmlInt xgetRfsStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(RFSSTATUS$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "rfsStatus" element
     */
    public boolean isSetRfsStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RFSSTATUS$0) != 0;
        }
    }
    
    /**
     * Sets the "rfsStatus" element
     */
    public void setRfsStatus(int rfsStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RFSSTATUS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RFSSTATUS$0);
            }
            target.setIntValue(rfsStatus);
        }
    }
    
    /**
     * Sets (as xml) the "rfsStatus" element
     */
    public void xsetRfsStatus(org.apache.xmlbeans.XmlInt rfsStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(RFSSTATUS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(RFSSTATUS$0);
            }
            target.set(rfsStatus);
        }
    }
    
    /**
     * Unsets the "rfsStatus" element
     */
    public void unsetRfsStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RFSSTATUS$0, 0);
        }
    }
}
