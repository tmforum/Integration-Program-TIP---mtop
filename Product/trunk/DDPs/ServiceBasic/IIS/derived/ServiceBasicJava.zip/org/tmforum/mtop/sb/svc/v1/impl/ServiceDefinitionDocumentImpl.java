/*
 * An XML document type.
 * Localname: serviceDefinition
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ServiceDefinitionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * A document containing one serviceDefinition(@http://www.tmforum.org/mtop/sb/svc/v1) element.
 *
 * This is a complex type.
 */
public class ServiceDefinitionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sb.svc.v1.ServiceDefinitionDocument
{
    
    public ServiceDefinitionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEDEFINITION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceDefinition");
    
    
    /**
     * Gets the "serviceDefinition" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType getServiceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType)get_store().find_element_user(SERVICEDEFINITION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "serviceDefinition" element
     */
    public void setServiceDefinition(org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType serviceDefinition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType)get_store().find_element_user(SERVICEDEFINITION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType)get_store().add_element_user(SERVICEDEFINITION$0);
            }
            target.set(serviceDefinition);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceDefinition" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType addNewServiceDefinition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType)get_store().add_element_user(SERVICEDEFINITION$0);
            return target;
        }
    }
}
