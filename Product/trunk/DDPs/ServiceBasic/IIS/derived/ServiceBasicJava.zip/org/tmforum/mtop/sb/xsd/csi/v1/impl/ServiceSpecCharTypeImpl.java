/*
 * XML Type:  ServiceSpecCharType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML ServiceSpecCharType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public class ServiceSpecCharTypeImpl extends org.tmforum.mtop.sb.xsd.csi.v1.impl.CommonServiceInfoTypeImpl implements org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType
{
    
    public ServiceSpecCharTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VALUETYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "valueType");
    private static final javax.xml.namespace.QName MINCARDINALITY$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "minCardinality");
    private static final javax.xml.namespace.QName MAXCARDINALITY$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "maxCardinality");
    private static final javax.xml.namespace.QName DERIVATIONFORMULA$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "derivationFormula");
    private static final javax.xml.namespace.QName VALIDFOR$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "validFor");
    private static final javax.xml.namespace.QName SERVICESPECCHARACTERISTICVALUE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "serviceSpecCharacteristicValue");
    
    
    /**
     * Gets the "valueType" element
     */
    public java.lang.String getValueType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUETYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "valueType" element
     */
    public org.apache.xmlbeans.XmlString xgetValueType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUETYPE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "valueType" element
     */
    public boolean isSetValueType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALUETYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "valueType" element
     */
    public void setValueType(java.lang.String valueType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUETYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALUETYPE$0);
            }
            target.setStringValue(valueType);
        }
    }
    
    /**
     * Sets (as xml) the "valueType" element
     */
    public void xsetValueType(org.apache.xmlbeans.XmlString valueType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUETYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALUETYPE$0);
            }
            target.set(valueType);
        }
    }
    
    /**
     * Unsets the "valueType" element
     */
    public void unsetValueType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALUETYPE$0, 0);
        }
    }
    
    /**
     * Gets the "minCardinality" element
     */
    public int getMinCardinality()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MINCARDINALITY$2, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "minCardinality" element
     */
    public org.apache.xmlbeans.XmlInt xgetMinCardinality()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(MINCARDINALITY$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "minCardinality" element
     */
    public boolean isSetMinCardinality()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MINCARDINALITY$2) != 0;
        }
    }
    
    /**
     * Sets the "minCardinality" element
     */
    public void setMinCardinality(int minCardinality)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MINCARDINALITY$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MINCARDINALITY$2);
            }
            target.setIntValue(minCardinality);
        }
    }
    
    /**
     * Sets (as xml) the "minCardinality" element
     */
    public void xsetMinCardinality(org.apache.xmlbeans.XmlInt minCardinality)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(MINCARDINALITY$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(MINCARDINALITY$2);
            }
            target.set(minCardinality);
        }
    }
    
    /**
     * Unsets the "minCardinality" element
     */
    public void unsetMinCardinality()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MINCARDINALITY$2, 0);
        }
    }
    
    /**
     * Gets the "maxCardinality" element
     */
    public int getMaxCardinality()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAXCARDINALITY$4, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "maxCardinality" element
     */
    public org.apache.xmlbeans.XmlInt xgetMaxCardinality()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(MAXCARDINALITY$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "maxCardinality" element
     */
    public boolean isSetMaxCardinality()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MAXCARDINALITY$4) != 0;
        }
    }
    
    /**
     * Sets the "maxCardinality" element
     */
    public void setMaxCardinality(int maxCardinality)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAXCARDINALITY$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MAXCARDINALITY$4);
            }
            target.setIntValue(maxCardinality);
        }
    }
    
    /**
     * Sets (as xml) the "maxCardinality" element
     */
    public void xsetMaxCardinality(org.apache.xmlbeans.XmlInt maxCardinality)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(MAXCARDINALITY$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(MAXCARDINALITY$4);
            }
            target.set(maxCardinality);
        }
    }
    
    /**
     * Unsets the "maxCardinality" element
     */
    public void unsetMaxCardinality()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MAXCARDINALITY$4, 0);
        }
    }
    
    /**
     * Gets the "derivationFormula" element
     */
    public java.lang.String getDerivationFormula()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DERIVATIONFORMULA$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "derivationFormula" element
     */
    public org.apache.xmlbeans.XmlString xgetDerivationFormula()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DERIVATIONFORMULA$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "derivationFormula" element
     */
    public boolean isSetDerivationFormula()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DERIVATIONFORMULA$6) != 0;
        }
    }
    
    /**
     * Sets the "derivationFormula" element
     */
    public void setDerivationFormula(java.lang.String derivationFormula)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DERIVATIONFORMULA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DERIVATIONFORMULA$6);
            }
            target.setStringValue(derivationFormula);
        }
    }
    
    /**
     * Sets (as xml) the "derivationFormula" element
     */
    public void xsetDerivationFormula(org.apache.xmlbeans.XmlString derivationFormula)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DERIVATIONFORMULA$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DERIVATIONFORMULA$6);
            }
            target.set(derivationFormula);
        }
    }
    
    /**
     * Unsets the "derivationFormula" element
     */
    public void unsetDerivationFormula()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DERIVATIONFORMULA$6, 0);
        }
    }
    
    /**
     * Gets the "validFor" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType getValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(VALIDFOR$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "validFor" element
     */
    public boolean isSetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALIDFOR$8) != 0;
        }
    }
    
    /**
     * Sets the "validFor" element
     */
    public void setValidFor(org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType validFor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(VALIDFOR$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(VALIDFOR$8);
            }
            target.set(validFor);
        }
    }
    
    /**
     * Appends and returns a new empty "validFor" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType addNewValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(VALIDFOR$8);
            return target;
        }
    }
    
    /**
     * Unsets the "validFor" element
     */
    public void unsetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALIDFOR$8, 0);
        }
    }
    
    /**
     * Gets a List of "serviceSpecCharacteristicValue" elements
     */
    public java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType> getServiceSpecCharacteristicValueList()
    {
        final class ServiceSpecCharacteristicValueList extends java.util.AbstractList<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType>
        {
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType get(int i)
                { return ServiceSpecCharTypeImpl.this.getServiceSpecCharacteristicValueArray(i); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType set(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType o)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType old = ServiceSpecCharTypeImpl.this.getServiceSpecCharacteristicValueArray(i);
                ServiceSpecCharTypeImpl.this.setServiceSpecCharacteristicValueArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType o)
                { ServiceSpecCharTypeImpl.this.insertNewServiceSpecCharacteristicValue(i).set(o); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType remove(int i)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType old = ServiceSpecCharTypeImpl.this.getServiceSpecCharacteristicValueArray(i);
                ServiceSpecCharTypeImpl.this.removeServiceSpecCharacteristicValue(i);
                return old;
            }
            
            public int size()
                { return ServiceSpecCharTypeImpl.this.sizeOfServiceSpecCharacteristicValueArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceSpecCharacteristicValueList();
        }
    }
    
    /**
     * Gets array of all "serviceSpecCharacteristicValue" elements
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] getServiceSpecCharacteristicValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICESPECCHARACTERISTICVALUE$10, targetList);
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] result = new org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceSpecCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType getServiceSpecCharacteristicValueArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType)get_store().find_element_user(SERVICESPECCHARACTERISTICVALUE$10, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceSpecCharacteristicValue" element
     */
    public int sizeOfServiceSpecCharacteristicValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESPECCHARACTERISTICVALUE$10);
        }
    }
    
    /**
     * Sets array of all "serviceSpecCharacteristicValue" element
     */
    public void setServiceSpecCharacteristicValueArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] serviceSpecCharacteristicValueArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceSpecCharacteristicValueArray, SERVICESPECCHARACTERISTICVALUE$10);
        }
    }
    
    /**
     * Sets ith "serviceSpecCharacteristicValue" element
     */
    public void setServiceSpecCharacteristicValueArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType serviceSpecCharacteristicValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType)get_store().find_element_user(SERVICESPECCHARACTERISTICVALUE$10, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceSpecCharacteristicValue);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType insertNewServiceSpecCharacteristicValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType)get_store().insert_element_user(SERVICESPECCHARACTERISTICVALUE$10, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType addNewServiceSpecCharacteristicValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType)get_store().add_element_user(SERVICESPECCHARACTERISTICVALUE$10);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceSpecCharacteristicValue" element
     */
    public void removeServiceSpecCharacteristicValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESPECCHARACTERISTICVALUE$10, i);
        }
    }
}
