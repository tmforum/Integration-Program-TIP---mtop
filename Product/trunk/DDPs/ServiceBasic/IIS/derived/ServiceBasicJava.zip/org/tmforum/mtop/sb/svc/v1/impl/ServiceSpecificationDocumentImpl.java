/*
 * An XML document type.
 * Localname: serviceSpecification
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ServiceSpecificationDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * A document containing one serviceSpecification(@http://www.tmforum.org/mtop/sb/svc/v1) element.
 *
 * This is a complex type.
 */
public class ServiceSpecificationDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sb.svc.v1.ServiceSpecificationDocument
{
    
    public ServiceSpecificationDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICESPECIFICATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceSpecification");
    
    
    /**
     * Gets the "serviceSpecification" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType getServiceSpecification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType)get_store().find_element_user(SERVICESPECIFICATION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "serviceSpecification" element
     */
    public void setServiceSpecification(org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType serviceSpecification)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType)get_store().find_element_user(SERVICESPECIFICATION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType)get_store().add_element_user(SERVICESPECIFICATION$0);
            }
            target.set(serviceSpecification);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceSpecification" element
     */
    public org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType addNewServiceSpecification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType target = null;
            target = (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType)get_store().add_element_user(SERVICESPECIFICATION$0);
            return target;
        }
    }
}
