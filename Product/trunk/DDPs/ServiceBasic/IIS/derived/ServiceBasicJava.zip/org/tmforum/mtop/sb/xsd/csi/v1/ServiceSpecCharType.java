/*
 * XML Type:  ServiceSpecCharType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1;


/**
 * An XML ServiceSpecCharType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public interface ServiceSpecCharType extends org.tmforum.mtop.sb.xsd.csi.v1.CommonServiceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ServiceSpecCharType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sB137642067B43A8768970C32DE897552").resolveHandle("servicespecchartype6001type");
    
    /**
     * Gets the "valueType" element
     */
    java.lang.String getValueType();
    
    /**
     * Gets (as xml) the "valueType" element
     */
    org.apache.xmlbeans.XmlString xgetValueType();
    
    /**
     * True if has "valueType" element
     */
    boolean isSetValueType();
    
    /**
     * Sets the "valueType" element
     */
    void setValueType(java.lang.String valueType);
    
    /**
     * Sets (as xml) the "valueType" element
     */
    void xsetValueType(org.apache.xmlbeans.XmlString valueType);
    
    /**
     * Unsets the "valueType" element
     */
    void unsetValueType();
    
    /**
     * Gets the "minCardinality" element
     */
    int getMinCardinality();
    
    /**
     * Gets (as xml) the "minCardinality" element
     */
    org.apache.xmlbeans.XmlInt xgetMinCardinality();
    
    /**
     * True if has "minCardinality" element
     */
    boolean isSetMinCardinality();
    
    /**
     * Sets the "minCardinality" element
     */
    void setMinCardinality(int minCardinality);
    
    /**
     * Sets (as xml) the "minCardinality" element
     */
    void xsetMinCardinality(org.apache.xmlbeans.XmlInt minCardinality);
    
    /**
     * Unsets the "minCardinality" element
     */
    void unsetMinCardinality();
    
    /**
     * Gets the "maxCardinality" element
     */
    int getMaxCardinality();
    
    /**
     * Gets (as xml) the "maxCardinality" element
     */
    org.apache.xmlbeans.XmlInt xgetMaxCardinality();
    
    /**
     * True if has "maxCardinality" element
     */
    boolean isSetMaxCardinality();
    
    /**
     * Sets the "maxCardinality" element
     */
    void setMaxCardinality(int maxCardinality);
    
    /**
     * Sets (as xml) the "maxCardinality" element
     */
    void xsetMaxCardinality(org.apache.xmlbeans.XmlInt maxCardinality);
    
    /**
     * Unsets the "maxCardinality" element
     */
    void unsetMaxCardinality();
    
    /**
     * Gets the "derivationFormula" element
     */
    java.lang.String getDerivationFormula();
    
    /**
     * Gets (as xml) the "derivationFormula" element
     */
    org.apache.xmlbeans.XmlString xgetDerivationFormula();
    
    /**
     * True if has "derivationFormula" element
     */
    boolean isSetDerivationFormula();
    
    /**
     * Sets the "derivationFormula" element
     */
    void setDerivationFormula(java.lang.String derivationFormula);
    
    /**
     * Sets (as xml) the "derivationFormula" element
     */
    void xsetDerivationFormula(org.apache.xmlbeans.XmlString derivationFormula);
    
    /**
     * Unsets the "derivationFormula" element
     */
    void unsetDerivationFormula();
    
    /**
     * Gets the "validFor" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType getValidFor();
    
    /**
     * True if has "validFor" element
     */
    boolean isSetValidFor();
    
    /**
     * Sets the "validFor" element
     */
    void setValidFor(org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType validFor);
    
    /**
     * Appends and returns a new empty "validFor" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType addNewValidFor();
    
    /**
     * Unsets the "validFor" element
     */
    void unsetValidFor();
    
    /**
     * Gets a List of "serviceSpecCharacteristicValue" elements
     */
    java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType> getServiceSpecCharacteristicValueList();
    
    /**
     * Gets array of all "serviceSpecCharacteristicValue" elements
     * @deprecated
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] getServiceSpecCharacteristicValueArray();
    
    /**
     * Gets ith "serviceSpecCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType getServiceSpecCharacteristicValueArray(int i);
    
    /**
     * Returns number of "serviceSpecCharacteristicValue" element
     */
    int sizeOfServiceSpecCharacteristicValueArray();
    
    /**
     * Sets array of all "serviceSpecCharacteristicValue" element
     */
    void setServiceSpecCharacteristicValueArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] serviceSpecCharacteristicValueArray);
    
    /**
     * Sets ith "serviceSpecCharacteristicValue" element
     */
    void setServiceSpecCharacteristicValueArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType serviceSpecCharacteristicValue);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType insertNewServiceSpecCharacteristicValue(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType addNewServiceSpecCharacteristicValue();
    
    /**
     * Removes the ith "serviceSpecCharacteristicValue" element
     */
    void removeServiceSpecCharacteristicValue(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType newInstance() {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
