/*
 * XML Type:  customerFacingService
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.CustomerFacingService
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * An XML customerFacingService(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public class CustomerFacingServiceImpl extends org.tmforum.mtop.sb.svc.v1.impl.ServiceImpl implements org.tmforum.mtop.sb.svc.v1.CustomerFacingService
{
    
    public CustomerFacingServiceImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CFSSTATUS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "cfsStatus");
    
    
    /**
     * Gets the "cfsStatus" element
     */
    public int getCfsStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CFSSTATUS$0, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "cfsStatus" element
     */
    public org.apache.xmlbeans.XmlInt xgetCfsStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(CFSSTATUS$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "cfsStatus" element
     */
    public boolean isSetCfsStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CFSSTATUS$0) != 0;
        }
    }
    
    /**
     * Sets the "cfsStatus" element
     */
    public void setCfsStatus(int cfsStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CFSSTATUS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CFSSTATUS$0);
            }
            target.setIntValue(cfsStatus);
        }
    }
    
    /**
     * Sets (as xml) the "cfsStatus" element
     */
    public void xsetCfsStatus(org.apache.xmlbeans.XmlInt cfsStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(CFSSTATUS$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(CFSSTATUS$0);
            }
            target.set(cfsStatus);
        }
    }
    
    /**
     * Unsets the "cfsStatus" element
     */
    public void unsetCfsStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CFSSTATUS$0, 0);
        }
    }
}
