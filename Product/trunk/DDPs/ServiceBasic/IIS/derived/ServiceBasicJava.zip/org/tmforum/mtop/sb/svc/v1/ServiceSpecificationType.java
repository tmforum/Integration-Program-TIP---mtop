/*
 * XML Type:  ServiceSpecificationType
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1;


/**
 * An XML ServiceSpecificationType(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public interface ServiceSpecificationType extends org.tmforum.mtop.sb.xsd.csi.v1.CommonServiceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ServiceSpecificationType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sB137642067B43A8768970C32DE897552").resolveHandle("servicespecificationtype012etype");
    
    /**
     * Gets a List of "serviceSpecificationHas" elements
     */
    java.util.List<org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType> getServiceSpecificationHasList();
    
    /**
     * Gets array of all "serviceSpecificationHas" elements
     * @deprecated
     */
    org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType[] getServiceSpecificationHasArray();
    
    /**
     * Gets ith "serviceSpecificationHas" element
     */
    org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType getServiceSpecificationHasArray(int i);
    
    /**
     * Returns number of "serviceSpecificationHas" element
     */
    int sizeOfServiceSpecificationHasArray();
    
    /**
     * Sets array of all "serviceSpecificationHas" element
     */
    void setServiceSpecificationHasArray(org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType[] serviceSpecificationHasArray);
    
    /**
     * Sets ith "serviceSpecificationHas" element
     */
    void setServiceSpecificationHasArray(int i, org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType serviceSpecificationHas);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecificationHas" element
     */
    org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType insertNewServiceSpecificationHas(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecificationHas" element
     */
    org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType addNewServiceSpecificationHas();
    
    /**
     * Removes the ith "serviceSpecificationHas" element
     */
    void removeServiceSpecificationHas(int i);
    
    /**
     * Gets a List of "serviceSpecVersion" elements
     */
    java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType> getServiceSpecVersionList();
    
    /**
     * Gets array of all "serviceSpecVersion" elements
     * @deprecated
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType[] getServiceSpecVersionArray();
    
    /**
     * Gets ith "serviceSpecVersion" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType getServiceSpecVersionArray(int i);
    
    /**
     * Returns number of "serviceSpecVersion" element
     */
    int sizeOfServiceSpecVersionArray();
    
    /**
     * Sets array of all "serviceSpecVersion" element
     */
    void setServiceSpecVersionArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType[] serviceSpecVersionArray);
    
    /**
     * Sets ith "serviceSpecVersion" element
     */
    void setServiceSpecVersionArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType serviceSpecVersion);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecVersion" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType insertNewServiceSpecVersion(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecVersion" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType addNewServiceSpecVersion();
    
    /**
     * Removes the ith "serviceSpecVersion" element
     */
    void removeServiceSpecVersion(int i);
    
    /**
     * Gets a List of "serviceSpecCharacteristic" elements
     */
    java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType> getServiceSpecCharacteristicList();
    
    /**
     * Gets array of all "serviceSpecCharacteristic" elements
     * @deprecated
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType[] getServiceSpecCharacteristicArray();
    
    /**
     * Gets ith "serviceSpecCharacteristic" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType getServiceSpecCharacteristicArray(int i);
    
    /**
     * Returns number of "serviceSpecCharacteristic" element
     */
    int sizeOfServiceSpecCharacteristicArray();
    
    /**
     * Sets array of all "serviceSpecCharacteristic" element
     */
    void setServiceSpecCharacteristicArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType[] serviceSpecCharacteristicArray);
    
    /**
     * Sets ith "serviceSpecCharacteristic" element
     */
    void setServiceSpecCharacteristicArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType serviceSpecCharacteristic);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecCharacteristic" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType insertNewServiceSpecCharacteristic(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecCharacteristic" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType addNewServiceSpecCharacteristic();
    
    /**
     * Removes the ith "serviceSpecCharacteristic" element
     */
    void removeServiceSpecCharacteristic(int i);
    
    /**
     * Gets a List of "serviceSpecCharacteristicValue" elements
     */
    java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType> getServiceSpecCharacteristicValueList();
    
    /**
     * Gets array of all "serviceSpecCharacteristicValue" elements
     * @deprecated
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] getServiceSpecCharacteristicValueArray();
    
    /**
     * Gets ith "serviceSpecCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType getServiceSpecCharacteristicValueArray(int i);
    
    /**
     * Returns number of "serviceSpecCharacteristicValue" element
     */
    int sizeOfServiceSpecCharacteristicValueArray();
    
    /**
     * Sets array of all "serviceSpecCharacteristicValue" element
     */
    void setServiceSpecCharacteristicValueArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType[] serviceSpecCharacteristicValueArray);
    
    /**
     * Sets ith "serviceSpecCharacteristicValue" element
     */
    void setServiceSpecCharacteristicValueArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType serviceSpecCharacteristicValue);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType insertNewServiceSpecCharacteristicValue(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType addNewServiceSpecCharacteristicValue();
    
    /**
     * Removes the ith "serviceSpecCharacteristicValue" element
     */
    void removeServiceSpecCharacteristicValue(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType newInstance() {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
