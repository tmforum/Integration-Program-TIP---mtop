/*
 * XML Type:  ServiceDefinitionType
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1;


/**
 * An XML ServiceDefinitionType(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public interface ServiceDefinitionType extends org.tmforum.mtop.sb.svc.v1.ServiceSpecificationType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ServiceDefinitionType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sB137642067B43A8768970C32DE897552").resolveHandle("servicedefinitiontyped556type");
    
    /**
     * Gets the "activationMode" element
     */
    java.lang.String getActivationMode();
    
    /**
     * Gets (as xml) the "activationMode" element
     */
    org.apache.xmlbeans.XmlString xgetActivationMode();
    
    /**
     * True if has "activationMode" element
     */
    boolean isSetActivationMode();
    
    /**
     * Sets the "activationMode" element
     */
    void setActivationMode(java.lang.String activationMode);
    
    /**
     * Sets (as xml) the "activationMode" element
     */
    void xsetActivationMode(org.apache.xmlbeans.XmlString activationMode);
    
    /**
     * Unsets the "activationMode" element
     */
    void unsetActivationMode();
    
    /**
     * Gets the "typeOfDefinition" element
     */
    java.lang.String getTypeOfDefinition();
    
    /**
     * Gets (as xml) the "typeOfDefinition" element
     */
    org.apache.xmlbeans.XmlString xgetTypeOfDefinition();
    
    /**
     * True if has "typeOfDefinition" element
     */
    boolean isSetTypeOfDefinition();
    
    /**
     * Sets the "typeOfDefinition" element
     */
    void setTypeOfDefinition(java.lang.String typeOfDefinition);
    
    /**
     * Sets (as xml) the "typeOfDefinition" element
     */
    void xsetTypeOfDefinition(org.apache.xmlbeans.XmlString typeOfDefinition);
    
    /**
     * Unsets the "typeOfDefinition" element
     */
    void unsetTypeOfDefinition();
    
    /**
     * Gets the "sdStatus" element
     */
    java.lang.String getSdStatus();
    
    /**
     * Gets (as xml) the "sdStatus" element
     */
    org.apache.xmlbeans.XmlString xgetSdStatus();
    
    /**
     * True if has "sdStatus" element
     */
    boolean isSetSdStatus();
    
    /**
     * Sets the "sdStatus" element
     */
    void setSdStatus(java.lang.String sdStatus);
    
    /**
     * Sets (as xml) the "sdStatus" element
     */
    void xsetSdStatus(org.apache.xmlbeans.XmlString sdStatus);
    
    /**
     * Unsets the "sdStatus" element
     */
    void unsetSdStatus();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType newInstance() {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.svc.v1.ServiceDefinitionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
