/*
 * XML Type:  service
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.Service
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1;


/**
 * An XML service(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public interface Service extends org.tmforum.mtop.sb.xsd.csi.v1.CommonServiceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(Service.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sB137642067B43A8768970C32DE897552").resolveHandle("service28e9type");
    
    /**
     * Gets the "isServiceEnabled" element
     */
    boolean getIsServiceEnabled();
    
    /**
     * Gets (as xml) the "isServiceEnabled" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsServiceEnabled();
    
    /**
     * True if has "isServiceEnabled" element
     */
    boolean isSetIsServiceEnabled();
    
    /**
     * Sets the "isServiceEnabled" element
     */
    void setIsServiceEnabled(boolean isServiceEnabled);
    
    /**
     * Sets (as xml) the "isServiceEnabled" element
     */
    void xsetIsServiceEnabled(org.apache.xmlbeans.XmlBoolean isServiceEnabled);
    
    /**
     * Unsets the "isServiceEnabled" element
     */
    void unsetIsServiceEnabled();
    
    /**
     * Gets the "hasStarted" element
     */
    boolean getHasStarted();
    
    /**
     * Gets (as xml) the "hasStarted" element
     */
    org.apache.xmlbeans.XmlBoolean xgetHasStarted();
    
    /**
     * True if has "hasStarted" element
     */
    boolean isSetHasStarted();
    
    /**
     * Sets the "hasStarted" element
     */
    void setHasStarted(boolean hasStarted);
    
    /**
     * Sets (as xml) the "hasStarted" element
     */
    void xsetHasStarted(org.apache.xmlbeans.XmlBoolean hasStarted);
    
    /**
     * Unsets the "hasStarted" element
     */
    void unsetHasStarted();
    
    /**
     * Gets the "isMandatory" element
     */
    boolean getIsMandatory();
    
    /**
     * Gets (as xml) the "isMandatory" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsMandatory();
    
    /**
     * True if has "isMandatory" element
     */
    boolean isSetIsMandatory();
    
    /**
     * Sets the "isMandatory" element
     */
    void setIsMandatory(boolean isMandatory);
    
    /**
     * Sets (as xml) the "isMandatory" element
     */
    void xsetIsMandatory(org.apache.xmlbeans.XmlBoolean isMandatory);
    
    /**
     * Unsets the "isMandatory" element
     */
    void unsetIsMandatory();
    
    /**
     * Gets the "startMode" element
     */
    int getStartMode();
    
    /**
     * Gets (as xml) the "startMode" element
     */
    org.apache.xmlbeans.XmlInt xgetStartMode();
    
    /**
     * True if has "startMode" element
     */
    boolean isSetStartMode();
    
    /**
     * Sets the "startMode" element
     */
    void setStartMode(int startMode);
    
    /**
     * Sets (as xml) the "startMode" element
     */
    void xsetStartMode(org.apache.xmlbeans.XmlInt startMode);
    
    /**
     * Unsets the "startMode" element
     */
    void unsetStartMode();
    
    /**
     * Gets the "isStateful" element
     */
    boolean getIsStateful();
    
    /**
     * Gets (as xml) the "isStateful" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsStateful();
    
    /**
     * True if has "isStateful" element
     */
    boolean isSetIsStateful();
    
    /**
     * Sets the "isStateful" element
     */
    void setIsStateful(boolean isStateful);
    
    /**
     * Sets (as xml) the "isStateful" element
     */
    void xsetIsStateful(org.apache.xmlbeans.XmlBoolean isStateful);
    
    /**
     * Unsets the "isStateful" element
     */
    void unsetIsStateful();
    
    /**
     * Gets a List of "subscriber" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType> getSubscriberList();
    
    /**
     * Gets array of all "subscriber" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] getSubscriberArray();
    
    /**
     * Gets ith "subscriber" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSubscriberArray(int i);
    
    /**
     * Returns number of "subscriber" element
     */
    int sizeOfSubscriberArray();
    
    /**
     * Sets array of all "subscriber" element
     */
    void setSubscriberArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] subscriberArray);
    
    /**
     * Sets ith "subscriber" element
     */
    void setSubscriberArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType subscriber);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "subscriber" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType insertNewSubscriber(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "subscriber" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSubscriber();
    
    /**
     * Removes the ith "subscriber" element
     */
    void removeSubscriber(int i);
    
    /**
     * Gets a List of "user" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType> getUserList();
    
    /**
     * Gets array of all "user" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] getUserArray();
    
    /**
     * Gets ith "user" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getUserArray(int i);
    
    /**
     * Returns number of "user" element
     */
    int sizeOfUserArray();
    
    /**
     * Sets array of all "user" element
     */
    void setUserArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] userArray);
    
    /**
     * Sets ith "user" element
     */
    void setUserArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType user);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "user" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType insertNewUser(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "user" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewUser();
    
    /**
     * Removes the ith "user" element
     */
    void removeUser(int i);
    
    /**
     * Gets the "serviceState" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType.Enum getServiceState();
    
    /**
     * Gets (as xml) the "serviceState" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType xgetServiceState();
    
    /**
     * True if has "serviceState" element
     */
    boolean isSetServiceState();
    
    /**
     * Sets the "serviceState" element
     */
    void setServiceState(org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType.Enum serviceState);
    
    /**
     * Sets (as xml) the "serviceState" element
     */
    void xsetServiceState(org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType serviceState);
    
    /**
     * Unsets the "serviceState" element
     */
    void unsetServiceState();
    
    /**
     * Gets the "operationalState" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.OperStateType.Enum getOperationalState();
    
    /**
     * Gets (as xml) the "operationalState" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.OperStateType xgetOperationalState();
    
    /**
     * True if has "operationalState" element
     */
    boolean isSetOperationalState();
    
    /**
     * Sets the "operationalState" element
     */
    void setOperationalState(org.tmforum.mtop.sb.xsd.csi.v1.OperStateType.Enum operationalState);
    
    /**
     * Sets (as xml) the "operationalState" element
     */
    void xsetOperationalState(org.tmforum.mtop.sb.xsd.csi.v1.OperStateType operationalState);
    
    /**
     * Unsets the "operationalState" element
     */
    void unsetOperationalState();
    
    /**
     * Gets a List of "serviceAccessPoint" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType> getServiceAccessPointList();
    
    /**
     * Gets array of all "serviceAccessPoint" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] getServiceAccessPointArray();
    
    /**
     * Gets ith "serviceAccessPoint" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getServiceAccessPointArray(int i);
    
    /**
     * Returns number of "serviceAccessPoint" element
     */
    int sizeOfServiceAccessPointArray();
    
    /**
     * Sets array of all "serviceAccessPoint" element
     */
    void setServiceAccessPointArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] serviceAccessPointArray);
    
    /**
     * Sets ith "serviceAccessPoint" element
     */
    void setServiceAccessPointArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType serviceAccessPoint);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceAccessPoint" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType insertNewServiceAccessPoint(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceAccessPoint" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewServiceAccessPoint();
    
    /**
     * Removes the ith "serviceAccessPoint" element
     */
    void removeServiceAccessPoint(int i);
    
    /**
     * Gets a List of "serviceCharacteristicValue" elements
     */
    java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType> getServiceCharacteristicValueList();
    
    /**
     * Gets array of all "serviceCharacteristicValue" elements
     * @deprecated
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType[] getServiceCharacteristicValueArray();
    
    /**
     * Gets ith "serviceCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType getServiceCharacteristicValueArray(int i);
    
    /**
     * Returns number of "serviceCharacteristicValue" element
     */
    int sizeOfServiceCharacteristicValueArray();
    
    /**
     * Sets array of all "serviceCharacteristicValue" element
     */
    void setServiceCharacteristicValueArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType[] serviceCharacteristicValueArray);
    
    /**
     * Sets ith "serviceCharacteristicValue" element
     */
    void setServiceCharacteristicValueArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType serviceCharacteristicValue);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType insertNewServiceCharacteristicValue(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceCharacteristicValue" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType addNewServiceCharacteristicValue();
    
    /**
     * Removes the ith "serviceCharacteristicValue" element
     */
    void removeServiceCharacteristicValue(int i);
    
    /**
     * Gets the "serviceTemplate" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getServiceTemplate();
    
    /**
     * True if has "serviceTemplate" element
     */
    boolean isSetServiceTemplate();
    
    /**
     * Sets the "serviceTemplate" element
     */
    void setServiceTemplate(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType serviceTemplate);
    
    /**
     * Appends and returns a new empty "serviceTemplate" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewServiceTemplate();
    
    /**
     * Unsets the "serviceTemplate" element
     */
    void unsetServiceTemplate();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        /** @deprecated No need to be able to create instances of abstract types */
        public static org.tmforum.mtop.sb.svc.v1.Service newInstance() {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        /** @deprecated No need to be able to create instances of abstract types */
        public static org.tmforum.mtop.sb.svc.v1.Service newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sb.svc.v1.Service parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.svc.v1.Service parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.svc.v1.Service parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.svc.v1.Service) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
