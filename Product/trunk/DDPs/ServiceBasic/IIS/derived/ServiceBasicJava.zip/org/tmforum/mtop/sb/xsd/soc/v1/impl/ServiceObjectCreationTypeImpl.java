/*
 * XML Type:  ServiceObjectCreationType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/soc/v1
 * Java type: org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.soc.v1.impl;
/**
 * An XML ServiceObjectCreationType(@http://www.tmforum.org/mtop/sb/xsd/soc/v1).
 *
 * This is a complex type.
 */
public class ServiceObjectCreationTypeImpl extends org.tmforum.mtop.fmw.xsd.oc.v1.impl.ObjectCreationTypeImpl implements org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType
{
    
    public ServiceObjectCreationTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
