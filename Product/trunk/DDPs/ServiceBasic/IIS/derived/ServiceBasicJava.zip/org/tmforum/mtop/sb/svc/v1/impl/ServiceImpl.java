/*
 * XML Type:  service
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.Service
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * An XML service(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public class ServiceImpl extends org.tmforum.mtop.sb.xsd.csi.v1.impl.CommonServiceInfoTypeImpl implements org.tmforum.mtop.sb.svc.v1.Service
{
    
    public ServiceImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ISSERVICEENABLED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "isServiceEnabled");
    private static final javax.xml.namespace.QName HASSTARTED$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "hasStarted");
    private static final javax.xml.namespace.QName ISMANDATORY$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "isMandatory");
    private static final javax.xml.namespace.QName STARTMODE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "startMode");
    private static final javax.xml.namespace.QName ISSTATEFUL$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "isStateful");
    private static final javax.xml.namespace.QName SUBSCRIBER$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "subscriber");
    private static final javax.xml.namespace.QName USER$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "user");
    private static final javax.xml.namespace.QName SERVICESTATE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceState");
    private static final javax.xml.namespace.QName OPERATIONALSTATE$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "operationalState");
    private static final javax.xml.namespace.QName SERVICEACCESSPOINT$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceAccessPoint");
    private static final javax.xml.namespace.QName SERVICECHARACTERISTICVALUE$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceCharacteristicValue");
    private static final javax.xml.namespace.QName SERVICETEMPLATE$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceTemplate");
    
    
    /**
     * Gets the "isServiceEnabled" element
     */
    public boolean getIsServiceEnabled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSERVICEENABLED$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isServiceEnabled" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsServiceEnabled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSERVICEENABLED$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "isServiceEnabled" element
     */
    public boolean isSetIsServiceEnabled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISSERVICEENABLED$0) != 0;
        }
    }
    
    /**
     * Sets the "isServiceEnabled" element
     */
    public void setIsServiceEnabled(boolean isServiceEnabled)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSERVICEENABLED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISSERVICEENABLED$0);
            }
            target.setBooleanValue(isServiceEnabled);
        }
    }
    
    /**
     * Sets (as xml) the "isServiceEnabled" element
     */
    public void xsetIsServiceEnabled(org.apache.xmlbeans.XmlBoolean isServiceEnabled)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSERVICEENABLED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISSERVICEENABLED$0);
            }
            target.set(isServiceEnabled);
        }
    }
    
    /**
     * Unsets the "isServiceEnabled" element
     */
    public void unsetIsServiceEnabled()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISSERVICEENABLED$0, 0);
        }
    }
    
    /**
     * Gets the "hasStarted" element
     */
    public boolean getHasStarted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HASSTARTED$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "hasStarted" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetHasStarted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(HASSTARTED$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "hasStarted" element
     */
    public boolean isSetHasStarted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(HASSTARTED$2) != 0;
        }
    }
    
    /**
     * Sets the "hasStarted" element
     */
    public void setHasStarted(boolean hasStarted)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HASSTARTED$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(HASSTARTED$2);
            }
            target.setBooleanValue(hasStarted);
        }
    }
    
    /**
     * Sets (as xml) the "hasStarted" element
     */
    public void xsetHasStarted(org.apache.xmlbeans.XmlBoolean hasStarted)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(HASSTARTED$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(HASSTARTED$2);
            }
            target.set(hasStarted);
        }
    }
    
    /**
     * Unsets the "hasStarted" element
     */
    public void unsetHasStarted()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(HASSTARTED$2, 0);
        }
    }
    
    /**
     * Gets the "isMandatory" element
     */
    public boolean getIsMandatory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISMANDATORY$4, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isMandatory" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsMandatory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISMANDATORY$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "isMandatory" element
     */
    public boolean isSetIsMandatory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISMANDATORY$4) != 0;
        }
    }
    
    /**
     * Sets the "isMandatory" element
     */
    public void setIsMandatory(boolean isMandatory)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISMANDATORY$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISMANDATORY$4);
            }
            target.setBooleanValue(isMandatory);
        }
    }
    
    /**
     * Sets (as xml) the "isMandatory" element
     */
    public void xsetIsMandatory(org.apache.xmlbeans.XmlBoolean isMandatory)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISMANDATORY$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISMANDATORY$4);
            }
            target.set(isMandatory);
        }
    }
    
    /**
     * Unsets the "isMandatory" element
     */
    public void unsetIsMandatory()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISMANDATORY$4, 0);
        }
    }
    
    /**
     * Gets the "startMode" element
     */
    public int getStartMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STARTMODE$6, 0);
            if (target == null)
            {
                return 0;
            }
            return target.getIntValue();
        }
    }
    
    /**
     * Gets (as xml) the "startMode" element
     */
    public org.apache.xmlbeans.XmlInt xgetStartMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(STARTMODE$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "startMode" element
     */
    public boolean isSetStartMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STARTMODE$6) != 0;
        }
    }
    
    /**
     * Sets the "startMode" element
     */
    public void setStartMode(int startMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STARTMODE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STARTMODE$6);
            }
            target.setIntValue(startMode);
        }
    }
    
    /**
     * Sets (as xml) the "startMode" element
     */
    public void xsetStartMode(org.apache.xmlbeans.XmlInt startMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInt target = null;
            target = (org.apache.xmlbeans.XmlInt)get_store().find_element_user(STARTMODE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInt)get_store().add_element_user(STARTMODE$6);
            }
            target.set(startMode);
        }
    }
    
    /**
     * Unsets the "startMode" element
     */
    public void unsetStartMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STARTMODE$6, 0);
        }
    }
    
    /**
     * Gets the "isStateful" element
     */
    public boolean getIsStateful()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSTATEFUL$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isStateful" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsStateful()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSTATEFUL$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "isStateful" element
     */
    public boolean isSetIsStateful()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISSTATEFUL$8) != 0;
        }
    }
    
    /**
     * Sets the "isStateful" element
     */
    public void setIsStateful(boolean isStateful)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISSTATEFUL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISSTATEFUL$8);
            }
            target.setBooleanValue(isStateful);
        }
    }
    
    /**
     * Sets (as xml) the "isStateful" element
     */
    public void xsetIsStateful(org.apache.xmlbeans.XmlBoolean isStateful)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISSTATEFUL$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISSTATEFUL$8);
            }
            target.set(isStateful);
        }
    }
    
    /**
     * Unsets the "isStateful" element
     */
    public void unsetIsStateful()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISSTATEFUL$8, 0);
        }
    }
    
    /**
     * Gets a List of "subscriber" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType> getSubscriberList()
    {
        final class SubscriberList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType get(int i)
                { return ServiceImpl.this.getSubscriberArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType old = ServiceImpl.this.getSubscriberArray(i);
                ServiceImpl.this.setSubscriberArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType o)
                { ServiceImpl.this.insertNewSubscriber(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType old = ServiceImpl.this.getSubscriberArray(i);
                ServiceImpl.this.removeSubscriber(i);
                return old;
            }
            
            public int size()
                { return ServiceImpl.this.sizeOfSubscriberArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new SubscriberList();
        }
    }
    
    /**
     * Gets array of all "subscriber" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] getSubscriberArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SUBSCRIBER$10, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "subscriber" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getSubscriberArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUBSCRIBER$10, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "subscriber" element
     */
    public int sizeOfSubscriberArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUBSCRIBER$10);
        }
    }
    
    /**
     * Sets array of all "subscriber" element
     */
    public void setSubscriberArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] subscriberArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(subscriberArray, SUBSCRIBER$10);
        }
    }
    
    /**
     * Sets ith "subscriber" element
     */
    public void setSubscriberArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType subscriber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SUBSCRIBER$10, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(subscriber);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "subscriber" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType insertNewSubscriber(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().insert_element_user(SUBSCRIBER$10, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "subscriber" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewSubscriber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SUBSCRIBER$10);
            return target;
        }
    }
    
    /**
     * Removes the ith "subscriber" element
     */
    public void removeSubscriber(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUBSCRIBER$10, i);
        }
    }
    
    /**
     * Gets a List of "user" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType> getUserList()
    {
        final class UserList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType get(int i)
                { return ServiceImpl.this.getUserArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType old = ServiceImpl.this.getUserArray(i);
                ServiceImpl.this.setUserArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType o)
                { ServiceImpl.this.insertNewUser(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType old = ServiceImpl.this.getUserArray(i);
                ServiceImpl.this.removeUser(i);
                return old;
            }
            
            public int size()
                { return ServiceImpl.this.sizeOfUserArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new UserList();
        }
    }
    
    /**
     * Gets array of all "user" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] getUserArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(USER$12, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "user" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getUserArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(USER$12, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "user" element
     */
    public int sizeOfUserArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(USER$12);
        }
    }
    
    /**
     * Sets array of all "user" element
     */
    public void setUserArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] userArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(userArray, USER$12);
        }
    }
    
    /**
     * Sets ith "user" element
     */
    public void setUserArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType user)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(USER$12, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(user);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "user" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType insertNewUser(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().insert_element_user(USER$12, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "user" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewUser()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(USER$12);
            return target;
        }
    }
    
    /**
     * Removes the ith "user" element
     */
    public void removeUser(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(USER$12, i);
        }
    }
    
    /**
     * Gets the "serviceState" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType.Enum getServiceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICESTATE$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceState" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType xgetServiceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType)get_store().find_element_user(SERVICESTATE$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "serviceState" element
     */
    public boolean isSetServiceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESTATE$14) != 0;
        }
    }
    
    /**
     * Sets the "serviceState" element
     */
    public void setServiceState(org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType.Enum serviceState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICESTATE$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICESTATE$14);
            }
            target.setEnumValue(serviceState);
        }
    }
    
    /**
     * Sets (as xml) the "serviceState" element
     */
    public void xsetServiceState(org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType serviceState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType)get_store().find_element_user(SERVICESTATE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType)get_store().add_element_user(SERVICESTATE$14);
            }
            target.set(serviceState);
        }
    }
    
    /**
     * Unsets the "serviceState" element
     */
    public void unsetServiceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESTATE$14, 0);
        }
    }
    
    /**
     * Gets the "operationalState" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.OperStateType.Enum getOperationalState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERATIONALSTATE$16, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.sb.xsd.csi.v1.OperStateType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "operationalState" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.OperStateType xgetOperationalState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.OperStateType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.OperStateType)get_store().find_element_user(OPERATIONALSTATE$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "operationalState" element
     */
    public boolean isSetOperationalState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OPERATIONALSTATE$16) != 0;
        }
    }
    
    /**
     * Sets the "operationalState" element
     */
    public void setOperationalState(org.tmforum.mtop.sb.xsd.csi.v1.OperStateType.Enum operationalState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OPERATIONALSTATE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OPERATIONALSTATE$16);
            }
            target.setEnumValue(operationalState);
        }
    }
    
    /**
     * Sets (as xml) the "operationalState" element
     */
    public void xsetOperationalState(org.tmforum.mtop.sb.xsd.csi.v1.OperStateType operationalState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.OperStateType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.OperStateType)get_store().find_element_user(OPERATIONALSTATE$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.csi.v1.OperStateType)get_store().add_element_user(OPERATIONALSTATE$16);
            }
            target.set(operationalState);
        }
    }
    
    /**
     * Unsets the "operationalState" element
     */
    public void unsetOperationalState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OPERATIONALSTATE$16, 0);
        }
    }
    
    /**
     * Gets a List of "serviceAccessPoint" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType> getServiceAccessPointList()
    {
        final class ServiceAccessPointList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType get(int i)
                { return ServiceImpl.this.getServiceAccessPointArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType old = ServiceImpl.this.getServiceAccessPointArray(i);
                ServiceImpl.this.setServiceAccessPointArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType o)
                { ServiceImpl.this.insertNewServiceAccessPoint(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType old = ServiceImpl.this.getServiceAccessPointArray(i);
                ServiceImpl.this.removeServiceAccessPoint(i);
                return old;
            }
            
            public int size()
                { return ServiceImpl.this.sizeOfServiceAccessPointArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceAccessPointList();
        }
    }
    
    /**
     * Gets array of all "serviceAccessPoint" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] getServiceAccessPointArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICEACCESSPOINT$18, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceAccessPoint" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getServiceAccessPointArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SERVICEACCESSPOINT$18, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceAccessPoint" element
     */
    public int sizeOfServiceAccessPointArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICEACCESSPOINT$18);
        }
    }
    
    /**
     * Sets array of all "serviceAccessPoint" element
     */
    public void setServiceAccessPointArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType[] serviceAccessPointArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceAccessPointArray, SERVICEACCESSPOINT$18);
        }
    }
    
    /**
     * Sets ith "serviceAccessPoint" element
     */
    public void setServiceAccessPointArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType serviceAccessPoint)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SERVICEACCESSPOINT$18, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceAccessPoint);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceAccessPoint" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType insertNewServiceAccessPoint(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().insert_element_user(SERVICEACCESSPOINT$18, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceAccessPoint" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewServiceAccessPoint()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SERVICEACCESSPOINT$18);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceAccessPoint" element
     */
    public void removeServiceAccessPoint(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICEACCESSPOINT$18, i);
        }
    }
    
    /**
     * Gets a List of "serviceCharacteristicValue" elements
     */
    public java.util.List<org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType> getServiceCharacteristicValueList()
    {
        final class ServiceCharacteristicValueList extends java.util.AbstractList<org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType>
        {
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType get(int i)
                { return ServiceImpl.this.getServiceCharacteristicValueArray(i); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType set(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType o)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType old = ServiceImpl.this.getServiceCharacteristicValueArray(i);
                ServiceImpl.this.setServiceCharacteristicValueArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType o)
                { ServiceImpl.this.insertNewServiceCharacteristicValue(i).set(o); }
            
            public org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType remove(int i)
            {
                org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType old = ServiceImpl.this.getServiceCharacteristicValueArray(i);
                ServiceImpl.this.removeServiceCharacteristicValue(i);
                return old;
            }
            
            public int size()
                { return ServiceImpl.this.sizeOfServiceCharacteristicValueArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceCharacteristicValueList();
        }
    }
    
    /**
     * Gets array of all "serviceCharacteristicValue" elements
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType[] getServiceCharacteristicValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICECHARACTERISTICVALUE$20, targetList);
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType[] result = new org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType getServiceCharacteristicValueArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType)get_store().find_element_user(SERVICECHARACTERISTICVALUE$20, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceCharacteristicValue" element
     */
    public int sizeOfServiceCharacteristicValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICECHARACTERISTICVALUE$20);
        }
    }
    
    /**
     * Sets array of all "serviceCharacteristicValue" element
     */
    public void setServiceCharacteristicValueArray(org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType[] serviceCharacteristicValueArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceCharacteristicValueArray, SERVICECHARACTERISTICVALUE$20);
        }
    }
    
    /**
     * Sets ith "serviceCharacteristicValue" element
     */
    public void setServiceCharacteristicValueArray(int i, org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType serviceCharacteristicValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType)get_store().find_element_user(SERVICECHARACTERISTICVALUE$20, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceCharacteristicValue);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType insertNewServiceCharacteristicValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType)get_store().insert_element_user(SERVICECHARACTERISTICVALUE$20, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceCharacteristicValue" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType addNewServiceCharacteristicValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType)get_store().add_element_user(SERVICECHARACTERISTICVALUE$20);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceCharacteristicValue" element
     */
    public void removeServiceCharacteristicValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICECHARACTERISTICVALUE$20, i);
        }
    }
    
    /**
     * Gets the "serviceTemplate" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getServiceTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SERVICETEMPLATE$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "serviceTemplate" element
     */
    public boolean isSetServiceTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICETEMPLATE$22) != 0;
        }
    }
    
    /**
     * Sets the "serviceTemplate" element
     */
    public void setServiceTemplate(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType serviceTemplate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SERVICETEMPLATE$22, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SERVICETEMPLATE$22);
            }
            target.set(serviceTemplate);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceTemplate" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewServiceTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SERVICETEMPLATE$22);
            return target;
        }
    }
    
    /**
     * Unsets the "serviceTemplate" element
     */
    public void unsetServiceTemplate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICETEMPLATE$22, 0);
        }
    }
}
