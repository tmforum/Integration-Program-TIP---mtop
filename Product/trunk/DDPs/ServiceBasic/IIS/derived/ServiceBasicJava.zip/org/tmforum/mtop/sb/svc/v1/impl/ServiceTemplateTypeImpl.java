/*
 * XML Type:  ServiceTemplateType
 * Namespace: http://www.tmforum.org/mtop/sb/svc/v1
 * Java type: org.tmforum.mtop.sb.svc.v1.ServiceTemplateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.svc.v1.impl;
/**
 * An XML ServiceTemplateType(@http://www.tmforum.org/mtop/sb/svc/v1).
 *
 * This is a complex type.
 */
public class ServiceTemplateTypeImpl extends org.tmforum.mtop.sb.svc.v1.impl.ServiceSpecificationTypeImpl implements org.tmforum.mtop.sb.svc.v1.ServiceTemplateType
{
    
    public ServiceTemplateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SOURCE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "source");
    private static final javax.xml.namespace.QName SERVICELOCATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "serviceLocation");
    private static final javax.xml.namespace.QName STSTATUS$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/svc/v1", "stStatus");
    
    
    /**
     * Gets the "source" element
     */
    public java.lang.String getSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "source" element
     */
    public org.apache.xmlbeans.XmlString xgetSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SOURCE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "source" element
     */
    public boolean isSetSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SOURCE$0) != 0;
        }
    }
    
    /**
     * Sets the "source" element
     */
    public void setSource(java.lang.String source)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SOURCE$0);
            }
            target.setStringValue(source);
        }
    }
    
    /**
     * Sets (as xml) the "source" element
     */
    public void xsetSource(org.apache.xmlbeans.XmlString source)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SOURCE$0);
            }
            target.set(source);
        }
    }
    
    /**
     * Unsets the "source" element
     */
    public void unsetSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SOURCE$0, 0);
        }
    }
    
    /**
     * Gets the "serviceLocation" element
     */
    public java.lang.String getServiceLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICELOCATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceLocation" element
     */
    public org.apache.xmlbeans.XmlString xgetServiceLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICELOCATION$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "serviceLocation" element
     */
    public boolean isSetServiceLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICELOCATION$2) != 0;
        }
    }
    
    /**
     * Sets the "serviceLocation" element
     */
    public void setServiceLocation(java.lang.String serviceLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICELOCATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICELOCATION$2);
            }
            target.setStringValue(serviceLocation);
        }
    }
    
    /**
     * Sets (as xml) the "serviceLocation" element
     */
    public void xsetServiceLocation(org.apache.xmlbeans.XmlString serviceLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICELOCATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICELOCATION$2);
            }
            target.set(serviceLocation);
        }
    }
    
    /**
     * Unsets the "serviceLocation" element
     */
    public void unsetServiceLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICELOCATION$2, 0);
        }
    }
    
    /**
     * Gets the "stStatus" element
     */
    public java.lang.String getStStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STSTATUS$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "stStatus" element
     */
    public org.apache.xmlbeans.XmlString xgetStStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STSTATUS$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "stStatus" element
     */
    public boolean isSetStStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STSTATUS$4) != 0;
        }
    }
    
    /**
     * Sets the "stStatus" element
     */
    public void setStStatus(java.lang.String stStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(STSTATUS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(STSTATUS$4);
            }
            target.setStringValue(stStatus);
        }
    }
    
    /**
     * Sets (as xml) the "stStatus" element
     */
    public void xsetStStatus(org.apache.xmlbeans.XmlString stStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(STSTATUS$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(STSTATUS$4);
            }
            target.set(stStatus);
        }
    }
    
    /**
     * Unsets the "stStatus" element
     */
    public void unsetStStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STSTATUS$4, 0);
        }
    }
}
