/*
 * XML Type:  ServiceSpecCharValueType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML ServiceSpecCharValueType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public class ServiceSpecCharValueTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType
{
    
    public ServiceSpecCharValueTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VALUETYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "valueType");
    private static final javax.xml.namespace.QName DEFAULT$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "default");
    private static final javax.xml.namespace.QName VALUE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "value");
    private static final javax.xml.namespace.QName UNITOFMEASURE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "unitOfMeasure");
    private static final javax.xml.namespace.QName VALUEFROM$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "valueFrom");
    private static final javax.xml.namespace.QName VALUETO$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "valueTo");
    private static final javax.xml.namespace.QName VALIDFOR$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "validFor");
    
    
    /**
     * Gets the "valueType" element
     */
    public java.lang.String getValueType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUETYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "valueType" element
     */
    public org.apache.xmlbeans.XmlString xgetValueType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUETYPE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "valueType" element
     */
    public boolean isSetValueType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALUETYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "valueType" element
     */
    public void setValueType(java.lang.String valueType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUETYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALUETYPE$0);
            }
            target.setStringValue(valueType);
        }
    }
    
    /**
     * Sets (as xml) the "valueType" element
     */
    public void xsetValueType(org.apache.xmlbeans.XmlString valueType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUETYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALUETYPE$0);
            }
            target.set(valueType);
        }
    }
    
    /**
     * Unsets the "valueType" element
     */
    public void unsetValueType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALUETYPE$0, 0);
        }
    }
    
    /**
     * Gets the "default" element
     */
    public java.lang.String getDefault()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DEFAULT$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "default" element
     */
    public org.apache.xmlbeans.XmlString xgetDefault()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DEFAULT$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "default" element
     */
    public boolean isSetDefault()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(DEFAULT$2) != 0;
        }
    }
    
    /**
     * Sets the "default" element
     */
    public void setDefault(java.lang.String xdefault)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DEFAULT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DEFAULT$2);
            }
            target.setStringValue(xdefault);
        }
    }
    
    /**
     * Sets (as xml) the "default" element
     */
    public void xsetDefault(org.apache.xmlbeans.XmlString xdefault)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DEFAULT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DEFAULT$2);
            }
            target.set(xdefault);
        }
    }
    
    /**
     * Unsets the "default" element
     */
    public void unsetDefault()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(DEFAULT$2, 0);
        }
    }
    
    /**
     * Gets the "value" element
     */
    public java.lang.String getValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "value" element
     */
    public org.apache.xmlbeans.XmlString xgetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUE$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "value" element
     */
    public boolean isSetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALUE$4) != 0;
        }
    }
    
    /**
     * Sets the "value" element
     */
    public void setValue(java.lang.String value)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALUE$4);
            }
            target.setStringValue(value);
        }
    }
    
    /**
     * Sets (as xml) the "value" element
     */
    public void xsetValue(org.apache.xmlbeans.XmlString value)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALUE$4);
            }
            target.set(value);
        }
    }
    
    /**
     * Unsets the "value" element
     */
    public void unsetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALUE$4, 0);
        }
    }
    
    /**
     * Gets the "unitOfMeasure" element
     */
    public java.lang.String getUnitOfMeasure()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UNITOFMEASURE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "unitOfMeasure" element
     */
    public org.apache.xmlbeans.XmlString xgetUnitOfMeasure()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UNITOFMEASURE$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "unitOfMeasure" element
     */
    public boolean isSetUnitOfMeasure()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(UNITOFMEASURE$6) != 0;
        }
    }
    
    /**
     * Sets the "unitOfMeasure" element
     */
    public void setUnitOfMeasure(java.lang.String unitOfMeasure)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UNITOFMEASURE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UNITOFMEASURE$6);
            }
            target.setStringValue(unitOfMeasure);
        }
    }
    
    /**
     * Sets (as xml) the "unitOfMeasure" element
     */
    public void xsetUnitOfMeasure(org.apache.xmlbeans.XmlString unitOfMeasure)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(UNITOFMEASURE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(UNITOFMEASURE$6);
            }
            target.set(unitOfMeasure);
        }
    }
    
    /**
     * Unsets the "unitOfMeasure" element
     */
    public void unsetUnitOfMeasure()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(UNITOFMEASURE$6, 0);
        }
    }
    
    /**
     * Gets the "valueFrom" element
     */
    public java.lang.String getValueFrom()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUEFROM$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "valueFrom" element
     */
    public org.apache.xmlbeans.XmlString xgetValueFrom()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUEFROM$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "valueFrom" element
     */
    public boolean isSetValueFrom()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALUEFROM$8) != 0;
        }
    }
    
    /**
     * Sets the "valueFrom" element
     */
    public void setValueFrom(java.lang.String valueFrom)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUEFROM$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALUEFROM$8);
            }
            target.setStringValue(valueFrom);
        }
    }
    
    /**
     * Sets (as xml) the "valueFrom" element
     */
    public void xsetValueFrom(org.apache.xmlbeans.XmlString valueFrom)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUEFROM$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALUEFROM$8);
            }
            target.set(valueFrom);
        }
    }
    
    /**
     * Unsets the "valueFrom" element
     */
    public void unsetValueFrom()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALUEFROM$8, 0);
        }
    }
    
    /**
     * Gets the "valueTo" element
     */
    public java.lang.String getValueTo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUETO$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "valueTo" element
     */
    public org.apache.xmlbeans.XmlString xgetValueTo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUETO$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "valueTo" element
     */
    public boolean isSetValueTo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALUETO$10) != 0;
        }
    }
    
    /**
     * Sets the "valueTo" element
     */
    public void setValueTo(java.lang.String valueTo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUETO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALUETO$10);
            }
            target.setStringValue(valueTo);
        }
    }
    
    /**
     * Sets (as xml) the "valueTo" element
     */
    public void xsetValueTo(org.apache.xmlbeans.XmlString valueTo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUETO$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALUETO$10);
            }
            target.set(valueTo);
        }
    }
    
    /**
     * Unsets the "valueTo" element
     */
    public void unsetValueTo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALUETO$10, 0);
        }
    }
    
    /**
     * Gets the "validFor" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType getValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(VALIDFOR$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "validFor" element
     */
    public boolean isSetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALIDFOR$12) != 0;
        }
    }
    
    /**
     * Sets the "validFor" element
     */
    public void setValidFor(org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType validFor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(VALIDFOR$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(VALIDFOR$12);
            }
            target.set(validFor);
        }
    }
    
    /**
     * Appends and returns a new empty "validFor" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType addNewValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(VALIDFOR$12);
            return target;
        }
    }
    
    /**
     * Unsets the "validFor" element
     */
    public void unsetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALIDFOR$12, 0);
        }
    }
}
