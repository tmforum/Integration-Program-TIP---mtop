/*
 * XML Type:  ServiceSpecCharValueType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1;


/**
 * An XML ServiceSpecCharValueType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public interface ServiceSpecCharValueType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ServiceSpecCharValueType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sB137642067B43A8768970C32DE897552").resolveHandle("servicespeccharvaluetypebf78type");
    
    /**
     * Gets the "valueType" element
     */
    java.lang.String getValueType();
    
    /**
     * Gets (as xml) the "valueType" element
     */
    org.apache.xmlbeans.XmlString xgetValueType();
    
    /**
     * True if has "valueType" element
     */
    boolean isSetValueType();
    
    /**
     * Sets the "valueType" element
     */
    void setValueType(java.lang.String valueType);
    
    /**
     * Sets (as xml) the "valueType" element
     */
    void xsetValueType(org.apache.xmlbeans.XmlString valueType);
    
    /**
     * Unsets the "valueType" element
     */
    void unsetValueType();
    
    /**
     * Gets the "default" element
     */
    java.lang.String getDefault();
    
    /**
     * Gets (as xml) the "default" element
     */
    org.apache.xmlbeans.XmlString xgetDefault();
    
    /**
     * True if has "default" element
     */
    boolean isSetDefault();
    
    /**
     * Sets the "default" element
     */
    void setDefault(java.lang.String xdefault);
    
    /**
     * Sets (as xml) the "default" element
     */
    void xsetDefault(org.apache.xmlbeans.XmlString xdefault);
    
    /**
     * Unsets the "default" element
     */
    void unsetDefault();
    
    /**
     * Gets the "value" element
     */
    java.lang.String getValue();
    
    /**
     * Gets (as xml) the "value" element
     */
    org.apache.xmlbeans.XmlString xgetValue();
    
    /**
     * True if has "value" element
     */
    boolean isSetValue();
    
    /**
     * Sets the "value" element
     */
    void setValue(java.lang.String value);
    
    /**
     * Sets (as xml) the "value" element
     */
    void xsetValue(org.apache.xmlbeans.XmlString value);
    
    /**
     * Unsets the "value" element
     */
    void unsetValue();
    
    /**
     * Gets the "unitOfMeasure" element
     */
    java.lang.String getUnitOfMeasure();
    
    /**
     * Gets (as xml) the "unitOfMeasure" element
     */
    org.apache.xmlbeans.XmlString xgetUnitOfMeasure();
    
    /**
     * True if has "unitOfMeasure" element
     */
    boolean isSetUnitOfMeasure();
    
    /**
     * Sets the "unitOfMeasure" element
     */
    void setUnitOfMeasure(java.lang.String unitOfMeasure);
    
    /**
     * Sets (as xml) the "unitOfMeasure" element
     */
    void xsetUnitOfMeasure(org.apache.xmlbeans.XmlString unitOfMeasure);
    
    /**
     * Unsets the "unitOfMeasure" element
     */
    void unsetUnitOfMeasure();
    
    /**
     * Gets the "valueFrom" element
     */
    java.lang.String getValueFrom();
    
    /**
     * Gets (as xml) the "valueFrom" element
     */
    org.apache.xmlbeans.XmlString xgetValueFrom();
    
    /**
     * True if has "valueFrom" element
     */
    boolean isSetValueFrom();
    
    /**
     * Sets the "valueFrom" element
     */
    void setValueFrom(java.lang.String valueFrom);
    
    /**
     * Sets (as xml) the "valueFrom" element
     */
    void xsetValueFrom(org.apache.xmlbeans.XmlString valueFrom);
    
    /**
     * Unsets the "valueFrom" element
     */
    void unsetValueFrom();
    
    /**
     * Gets the "valueTo" element
     */
    java.lang.String getValueTo();
    
    /**
     * Gets (as xml) the "valueTo" element
     */
    org.apache.xmlbeans.XmlString xgetValueTo();
    
    /**
     * True if has "valueTo" element
     */
    boolean isSetValueTo();
    
    /**
     * Sets the "valueTo" element
     */
    void setValueTo(java.lang.String valueTo);
    
    /**
     * Sets (as xml) the "valueTo" element
     */
    void xsetValueTo(org.apache.xmlbeans.XmlString valueTo);
    
    /**
     * Unsets the "valueTo" element
     */
    void unsetValueTo();
    
    /**
     * Gets the "validFor" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType getValidFor();
    
    /**
     * True if has "validFor" element
     */
    boolean isSetValidFor();
    
    /**
     * Sets the "validFor" element
     */
    void setValidFor(org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType validFor);
    
    /**
     * Appends and returns a new empty "validFor" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType addNewValidFor();
    
    /**
     * Unsets the "validFor" element
     */
    void unsetValidFor();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType newInstance() {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharValueType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
