﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/ac/v1-0"] =  new WC (
					new Array(new WCN("46/service/AlarmControlHttp.html","AlarmControlHttp",false,null),new WCN("46/service/AlarmControlJms.html","AlarmControlJms",false,null)),
					new Array(new WCN("46/message/setAlarmReportingOffException.html","setAlarmReportingOffException",false,null),new WCN("46/message/setAlarmReportingOffRequest.html","setAlarmReportingOffRequest",false,null),new WCN("46/message/setAlarmReportingOffResponse.html","setAlarmReportingOffResponse",false,null),new WCN("46/message/setAlarmReportingOnException.html","setAlarmReportingOnException",false,null),new WCN("46/message/setAlarmReportingOnRequest.html","setAlarmReportingOnRequest",false,null),new WCN("46/message/setAlarmReportingOnResponse.html","setAlarmReportingOnResponse",false,null),new WCN("46/message/setGtpAlarmReportingOffException.html","setGtpAlarmReportingOffException",false,null),new WCN("46/message/setGtpAlarmReportingOffRequest.html","setGtpAlarmReportingOffRequest",false,null),new WCN("46/message/setGtpAlarmReportingOffResponse.html","setGtpAlarmReportingOffResponse",false,null),new WCN("46/message/setGtpAlarmReportingOnException.html","setGtpAlarmReportingOnException",false,null),new WCN("46/message/setGtpAlarmReportingOnRequest.html","setGtpAlarmReportingOnRequest",false,null),new WCN("46/message/setGtpAlarmReportingOnResponse.html","setGtpAlarmReportingOnResponse",false,null)),
					new Array(new WCN("46/porttype/AlarmControl.html","AlarmControl",false,new Array(new WCN("46/operation/setAlarmReportingOff_30.html","setAlarmReportingOff",false,null),new WCN("46/operation/setAlarmReportingOn_31.html","setAlarmReportingOn",false,null),new WCN("46/operation/setGtpAlarmReportingOff_32.html","setGtpAlarmReportingOff",false,null),new WCN("46/operation/setGtpAlarmReportingOn_33.html","setGtpAlarmReportingOn",false,null)))),
					new Array(new WCN("46/binding/AlarmControlSoapHttpBinding.html","AlarmControlSoapHttpBinding",false,new Array(new WCN("46/operation/setAlarmReportingOff_30.html","setAlarmReportingOff",false,null),new WCN("46/operation/setAlarmReportingOn_31.html","setAlarmReportingOn",false,null),new WCN("46/operation/setGtpAlarmReportingOff_32.html","setGtpAlarmReportingOff",false,null),new WCN("46/operation/setGtpAlarmReportingOn_33.html","setGtpAlarmReportingOn",false,null))),new WCN("46/binding/AlarmControlSoapJmsBinding.html","AlarmControlSoapJmsBinding",false,new Array(new WCN("46/operation/setAlarmReportingOff_30.html","setAlarmReportingOff",false,null),new WCN("46/operation/setAlarmReportingOn_31.html","setAlarmReportingOn",false,null),new WCN("46/operation/setGtpAlarmReportingOff_32.html","setGtpAlarmReportingOff",false,null),new WCN("46/operation/setGtpAlarmReportingOn_33.html","setGtpAlarmReportingOn",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/ac/v1-0"] = "46/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/ah/v1-0"] =  new WC (
					new Array(new WCN("44/service/AlarmHandlingHttp.html","AlarmHandlingHttp",false,null),new WCN("44/service/AlarmHandlingJms.html","AlarmHandlingJms",false,null)),
					new Array(new WCN("44/message/acknowledgeAlarmsException.html","acknowledgeAlarmsException",false,null),new WCN("44/message/acknowledgeAlarmsRequest.html","acknowledgeAlarmsRequest",false,null),new WCN("44/message/acknowledgeAlarmsResponse.html","acknowledgeAlarmsResponse",false,null),new WCN("44/message/unacknowledgeAlarmsException.html","unacknowledgeAlarmsException",false,null),new WCN("44/message/unacknowledgeAlarmsRequest.html","unacknowledgeAlarmsRequest",false,null),new WCN("44/message/unacknowledgeAlarmsResponse.html","unacknowledgeAlarmsResponse",false,null)),
					new Array(new WCN("44/porttype/AlarmHandling.html","AlarmHandling",false,new Array(new WCN("44/operation/acknowledgeAlarms_22.html","acknowledgeAlarms",false,null),new WCN("44/operation/unacknowledgeAlarms_23.html","unacknowledgeAlarms",false,null)))),
					new Array(new WCN("44/binding/AlarmHandlingSoapHttpBinding.html","AlarmHandlingSoapHttpBinding",false,new Array(new WCN("44/operation/acknowledgeAlarms_22.html","acknowledgeAlarms",false,null),new WCN("44/operation/unacknowledgeAlarms_23.html","unacknowledgeAlarms",false,null))),new WCN("44/binding/AlarmHandlingSoapJmsBinding.html","AlarmHandlingSoapJmsBinding",false,new Array(new WCN("44/operation/acknowledgeAlarms_22.html","acknowledgeAlarms",false,null),new WCN("44/operation/unacknowledgeAlarms_23.html","unacknowledgeAlarms",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/ah/v1-0"] = "44/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/ar/v1-0"] =  new WC (
					new Array(new WCN("40/service/AlarmRetrievalHttp.html","AlarmRetrievalHttp",false,null),new WCN("40/service/AlarmRetrievalJms.html","AlarmRetrievalJms",false,null)),
					new Array(new WCN("40/message/getActiveAlarmsCountException.html","getActiveAlarmsCountException",false,null),new WCN("40/message/getActiveAlarmsCountRequest.html","getActiveAlarmsCountRequest",false,null),new WCN("40/message/getActiveAlarmsCountResponse.html","getActiveAlarmsCountResponse",false,null),new WCN("40/message/getActiveAlarmsException.html","getActiveAlarmsException",false,null),new WCN("40/message/getActiveAlarmsRequest.html","getActiveAlarmsRequest",false,null),new WCN("40/message/getActiveAlarmsResponse.html","getActiveAlarmsResponse",false,null)),
					new Array(new WCN("40/porttype/AlarmRetrieval.html","AlarmRetrieval",false,new Array(new WCN("40/operation/getActiveAlarms_5.html","getActiveAlarms",false,null),new WCN("40/operation/getActiveAlarmsCount_6.html","getActiveAlarmsCount",false,null)))),
					new Array(new WCN("40/binding/AlarmRetrievalSoapHttpBinding.html","AlarmRetrievalSoapHttpBinding",false,new Array(new WCN("40/operation/getActiveAlarms_5.html","getActiveAlarms",false,null),new WCN("40/operation/getActiveAlarmsCount_6.html","getActiveAlarmsCount",false,null))),new WCN("40/binding/AlarmRetrievalSoapJmsBinding.html","AlarmRetrievalSoapJmsBinding",false,new Array(new WCN("40/operation/getActiveAlarms_5.html","getActiveAlarms",false,null),new WCN("40/operation/getActiveAlarmsCount_6.html","getActiveAlarmsCount",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/ar/v1-0"] = "40/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/asapc/v1-0"] =  new WC (
					new Array(new WCN("39/service/AsapControlHttp.html","AsapControlHttp",false,null),new WCN("39/service/AsapControlJms.html","AsapControlJms",false,null)),
					new Array(new WCN("39/message/assignAsapException.html","assignAsapException",false,null),new WCN("39/message/assignAsapRequest.html","assignAsapRequest",false,null),new WCN("39/message/assignAsapResponse.html","assignAsapResponse",false,null),new WCN("39/message/createAsapException.html","createAsapException",false,null),new WCN("39/message/createAsapRequest.html","createAsapRequest",false,null),new WCN("39/message/createAsapResponse.html","createAsapResponse",false,null),new WCN("39/message/deassignAsapException.html","deassignAsapException",false,null),new WCN("39/message/deassignAsapRequest.html","deassignAsapRequest",false,null),new WCN("39/message/deassignAsapResponse.html","deassignAsapResponse",false,null),new WCN("39/message/deleteAsapException.html","deleteAsapException",false,null),new WCN("39/message/deleteAsapRequest.html","deleteAsapRequest",false,null),new WCN("39/message/deleteAsapResponse.html","deleteAsapResponse",false,null),new WCN("39/message/modifyAsapException.html","modifyAsapException",false,null),new WCN("39/message/modifyAsapRequest.html","modifyAsapRequest",false,null),new WCN("39/message/modifyAsapResponse.html","modifyAsapResponse",false,null)),
					new Array(new WCN("39/porttype/AsapControl.html","AsapControl",false,new Array(new WCN("39/operation/assignAsap_0.html","assignAsap",false,null),new WCN("39/operation/createAsap_1.html","createAsap",false,null),new WCN("39/operation/deassignAsap_2.html","deassignAsap",false,null),new WCN("39/operation/deleteAsap_3.html","deleteAsap",false,null),new WCN("39/operation/modifyAsap_4.html","modifyAsap",false,null)))),
					new Array(new WCN("39/binding/AsapControlSoapHttpBinding.html","AsapControlSoapHttpBinding",false,new Array(new WCN("39/operation/assignAsap_0.html","assignAsap",false,null),new WCN("39/operation/createAsap_1.html","createAsap",false,null),new WCN("39/operation/deassignAsap_2.html","deassignAsap",false,null),new WCN("39/operation/deleteAsap_3.html","deleteAsap",false,null),new WCN("39/operation/modifyAsap_4.html","modifyAsap",false,null))),new WCN("39/binding/AsapControlSoapJmsBinding.html","AsapControlSoapJmsBinding",false,new Array(new WCN("39/operation/assignAsap_0.html","assignAsap",false,null),new WCN("39/operation/createAsap_1.html","createAsap",false,null),new WCN("39/operation/deassignAsap_2.html","deassignAsap",false,null),new WCN("39/operation/deleteAsap_3.html","deleteAsap",false,null),new WCN("39/operation/modifyAsap_4.html","modifyAsap",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/asapc/v1-0"] = "39/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/asapr/v1-0"] =  new WC (
					new Array(new WCN("45/service/AsapRetrievalHttp.html","AsapRetrievalHttp",false,null),new WCN("45/service/AsapRetrievalJms.html","AsapRetrievalJms",false,null)),
					new Array(new WCN("45/message/getAllAsapNamesWrtOsException.html","getAllAsapNamesWrtOsException",false,null),new WCN("45/message/getAllAsapNamesWrtOsRequest.html","getAllAsapNamesWrtOsRequest",false,null),new WCN("45/message/getAllAsapNamesWrtOsResponse.html","getAllAsapNamesWrtOsResponse",false,null),new WCN("45/message/getAllAsapsWrtOsException.html","getAllAsapsWrtOsException",false,null),new WCN("45/message/getAllAsapsWrtOsRequest.html","getAllAsapsWrtOsRequest",false,null),new WCN("45/message/getAllAsapsWrtOsResponse.html","getAllAsapsWrtOsResponse",false,null),new WCN("45/message/getAsapAssociatedResourceNamesException.html","getAsapAssociatedResourceNamesException",false,null),new WCN("45/message/getAsapAssociatedResourceNamesRequest.html","getAsapAssociatedResourceNamesRequest",false,null),new WCN("45/message/getAsapAssociatedResourceNamesResponse.html","getAsapAssociatedResourceNamesResponse",false,null),new WCN("45/message/getAsapByResourceException.html","getAsapByResourceException",false,null),new WCN("45/message/getAsapByResourceRequest.html","getAsapByResourceRequest",false,null),new WCN("45/message/getAsapByResourceResponse.html","getAsapByResourceResponse",false,null),new WCN("45/message/getAsapException.html","getAsapException",false,null),new WCN("45/message/getAsapIteratorException.html","getAsapIteratorException",false,null),new WCN("45/message/getAsapIteratorRequest.html","getAsapIteratorRequest",false,null),new WCN("45/message/getAsapIteratorResponse.html","getAsapIteratorResponse",false,null),new WCN("45/message/getAsapRequest.html","getAsapRequest",false,null),new WCN("45/message/getAsapResponse.html","getAsapResponse",false,null)),
					new Array(new WCN("45/porttype/AsapRetrieval.html","AsapRetrieval",false,new Array(new WCN("45/operation/getAllAsapNamesWrtOs_24.html","getAllAsapNamesWrtOs",false,null),new WCN("45/operation/getAllAsapsWrtOs_25.html","getAllAsapsWrtOs",false,null),new WCN("45/operation/getAsap_26.html","getAsap",false,null),new WCN("45/operation/getAsapAssociatedResourceNames_28.html","getAsapAssociatedResourceNames",false,null),new WCN("45/operation/getAsapByResource_29.html","getAsapByResource",false,null),new WCN("45/operation/getAsapIterator_27.html","getAsapIterator",false,null)))),
					new Array(new WCN("45/binding/AsapRetrievalSoapHttpBinding.html","AsapRetrievalSoapHttpBinding",false,new Array(new WCN("45/operation/getAllAsapNamesWrtOs_24.html","getAllAsapNamesWrtOs",false,null),new WCN("45/operation/getAllAsapsWrtOs_25.html","getAllAsapsWrtOs",false,null),new WCN("45/operation/getAsap_26.html","getAsap",false,null),new WCN("45/operation/getAsapAssociatedResourceNames_28.html","getAsapAssociatedResourceNames",false,null),new WCN("45/operation/getAsapByResource_29.html","getAsapByResource",false,null),new WCN("45/operation/getAsapIterator_27.html","getAsapIterator",false,null))),new WCN("45/binding/AsapRetrievalSoapJmsBinding.html","AsapRetrievalSoapJmsBinding",false,new Array(new WCN("45/operation/getAllAsapNamesWrtOs_24.html","getAllAsapNamesWrtOs",false,null),new WCN("45/operation/getAllAsapsWrtOs_25.html","getAllAsapsWrtOs",false,null),new WCN("45/operation/getAsap_26.html","getAsap",false,null),new WCN("45/operation/getAsapAssociatedResourceNames_28.html","getAsapAssociatedResourceNames",false,null),new WCN("45/operation/getAsapByResource_29.html","getAsapByResource",false,null),new WCN("45/operation/getAsapIterator_27.html","getAsapIterator",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/asapr/v1-0"] = "45/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/mc/v1-0"] =  new WC (
					new Array(new WCN("41/service/MaintenanceControlHttp.html","MaintenanceControlHttp",false,null),new WCN("41/service/MaintenanceControlJms.html","MaintenanceControlJms",false,null)),
					new Array(new WCN("41/message/getActiveMaintenanceOperationsException.html","getActiveMaintenanceOperationsException",false,null),new WCN("41/message/getActiveMaintenanceOperationsRequest.html","getActiveMaintenanceOperationsRequest",false,null),new WCN("41/message/getActiveMaintenanceOperationsResponse.html","getActiveMaintenanceOperationsResponse",false,null),new WCN("41/message/performMaintenanceOperationException.html","performMaintenanceOperationException",false,null),new WCN("41/message/performMaintenanceOperationRequest.html","performMaintenanceOperationRequest",false,null),new WCN("41/message/performMaintenanceOperationResponse.html","performMaintenanceOperationResponse",false,null)),
					new Array(new WCN("41/porttype/MaintenanceControl.html","MaintenanceControl",false,new Array(new WCN("41/operation/getActiveMaintenanceOperations_7.html","getActiveMaintenanceOperations",false,null),new WCN("41/operation/performMaintenanceOperation_8.html","performMaintenanceOperation",false,null)))),
					new Array(new WCN("41/binding/MaintenanceControlSoapHttpBinding.html","MaintenanceControlSoapHttpBinding",false,new Array(new WCN("41/operation/getActiveMaintenanceOperations_7.html","getActiveMaintenanceOperations",false,null),new WCN("41/operation/performMaintenanceOperation_8.html","performMaintenanceOperation",false,null))),new WCN("41/binding/MaintenanceControlSoapJmsBinding.html","MaintenanceControlSoapJmsBinding",false,new Array(new WCN("41/operation/getActiveMaintenanceOperations_7.html","getActiveMaintenanceOperations",false,null),new WCN("41/operation/performMaintenanceOperation_8.html","performMaintenanceOperation",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/mc/v1-0"] = "41/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/pc/v1-0"] =  new WC (
					new Array(new WCN("43/service/ProtectionControlHttp.html","ProtectionControlHttp",false,null),new WCN("43/service/ProtectionControlJms.html","ProtectionControlJms",false,null)),
					new Array(new WCN("43/message/performProtectionCommandException.html","performProtectionCommandException",false,null),new WCN("43/message/performProtectionCommandRequest.html","performProtectionCommandRequest",false,null),new WCN("43/message/performProtectionCommandResponse.html","performProtectionCommandResponse",false,null)),
					new Array(new WCN("43/porttype/ProtectionControl.html","ProtectionControl",false,new Array(new WCN("43/operation/performProtectionCommand_21.html","performProtectionCommand",false,null)))),
					new Array(new WCN("43/binding/ProtectionControlSoapHttpBinding.html","ProtectionControlSoapHttpBinding",false,new Array(new WCN("43/operation/performProtectionCommand_21.html","performProtectionCommand",false,null))),new WCN("43/binding/ProtectionControlSoapJmsBinding.html","ProtectionControlSoapJmsBinding",false,new Array(new WCN("43/operation/performProtectionCommand_21.html","performProtectionCommand",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/pc/v1-0"] = "43/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/pr/v1-0"] =  new WC (
					new Array(new WCN("42/service/ProtectionRetrievalHttp.html","ProtectionRetrievalHttp",false,null),new WCN("42/service/ProtectionRetrievalJms.html","ProtectionRetrievalJms",false,null)),
					new Array(new WCN("42/message/getAllEquipmentProtectionGroupsException.html","getAllEquipmentProtectionGroupsException",false,null),new WCN("42/message/getAllEquipmentProtectionGroupsRequest.html","getAllEquipmentProtectionGroupsRequest",false,null),new WCN("42/message/getAllEquipmentProtectionGroupsResponse.html","getAllEquipmentProtectionGroupsResponse",false,null),new WCN("42/message/getAllNonPreemptibleUnprotectedTpNamesException.html","getAllNonPreemptibleUnprotectedTpNamesException",false,null),new WCN("42/message/getAllNonPreemptibleUnprotectedTpNamesRequest.html","getAllNonPreemptibleUnprotectedTpNamesRequest",false,null),new WCN("42/message/getAllNonPreemptibleUnprotectedTpNamesResponse.html","getAllNonPreemptibleUnprotectedTpNamesResponse",false,null),new WCN("42/message/getAllPreemptibleTpNamesException.html","getAllPreemptibleTpNamesException",false,null),new WCN("42/message/getAllPreemptibleTpNamesRequest.html","getAllPreemptibleTpNamesRequest",false,null),new WCN("42/message/getAllPreemptibleTpNamesResponse.html","getAllPreemptibleTpNamesResponse",false,null),new WCN("42/message/getAllProtectedTpNamesException.html","getAllProtectedTpNamesException",false,null),new WCN("42/message/getAllProtectedTpNamesRequest.html","getAllProtectedTpNamesRequest",false,null),new WCN("42/message/getAllProtectedTpNamesResponse.html","getAllProtectedTpNamesResponse",false,null),new WCN("42/message/getAllProtectionGroupsException.html","getAllProtectionGroupsException",false,null),new WCN("42/message/getAllProtectionGroupsRequest.html","getAllProtectionGroupsRequest",false,null),new WCN("42/message/getAllProtectionGroupsResponse.html","getAllProtectionGroupsResponse",false,null),new WCN("42/message/getContainingProtectionGroupNamesException.html","getContainingProtectionGroupNamesException",false,null),new WCN("42/message/getContainingProtectionGroupNamesRequest.html","getContainingProtectionGroupNamesRequest",false,null),new WCN("42/message/getContainingProtectionGroupNamesResponse.html","getContainingProtectionGroupNamesResponse",false,null),new WCN("42/message/getEquipmentProtectionGroupException.html","getEquipmentProtectionGroupException",false,null),new WCN("42/message/getEquipmentProtectionGroupIteratorException.html","getEquipmentProtectionGroupIteratorException",false,null),new WCN("42/message/getEquipmentProtectionGroupIteratorRequest.html","getEquipmentProtectionGroupIteratorRequest",false,null),new WCN("42/message/getEquipmentProtectionGroupIteratorResponse.html","getEquipmentProtectionGroupIteratorResponse",false,null),new WCN("42/message/getEquipmentProtectionGroupRequest.html","getEquipmentProtectionGroupRequest",false,null),new WCN("42/message/getEquipmentProtectionGroupResponse.html","getEquipmentProtectionGroupResponse",false,null),new WCN("42/message/getProtectionGroupException.html","getProtectionGroupException",false,null),new WCN("42/message/getProtectionGroupIteratorException.html","getProtectionGroupIteratorException",false,null),new WCN("42/message/getProtectionGroupIteratorRequest.html","getProtectionGroupIteratorRequest",false,null),new WCN("42/message/getProtectionGroupIteratorResponse.html","getProtectionGroupIteratorResponse",false,null),new WCN("42/message/getProtectionGroupRequest.html","getProtectionGroupRequest",false,null),new WCN("42/message/getProtectionGroupResponse.html","getProtectionGroupResponse",false,null),new WCN("42/message/retrieveEquipmentSwitchDataException.html","retrieveEquipmentSwitchDataException",false,null),new WCN("42/message/retrieveEquipmentSwitchDataRequest.html","retrieveEquipmentSwitchDataRequest",false,null),new WCN("42/message/retrieveEquipmentSwitchDataResponse.html","retrieveEquipmentSwitchDataResponse",false,null),new WCN("42/message/retrieveSwitchDataException.html","retrieveSwitchDataException",false,null),new WCN("42/message/retrieveSwitchDataRequest.html","retrieveSwitchDataRequest",false,null),new WCN("42/message/retrieveSwitchDataResponse.html","retrieveSwitchDataResponse",false,null)),
					new Array(new WCN("42/porttype/ProtectionRetrieval.html","ProtectionRetrieval",false,new Array(new WCN("42/operation/getAllEquipmentProtectionGroups_9.html","getAllEquipmentProtectionGroups",false,null),new WCN("42/operation/getAllNonPreemptibleUnprotectedTpNames_10.html","getAllNonPreemptibleUnprotectedTpNames",false,null),new WCN("42/operation/getAllPreemptibleTpNames_11.html","getAllPreemptibleTpNames",false,null),new WCN("42/operation/getAllProtectedTpNames_12.html","getAllProtectedTpNames",false,null),new WCN("42/operation/getAllProtectionGroups_13.html","getAllProtectionGroups",false,null),new WCN("42/operation/getContainingProtectionGroupNames_14.html","getContainingProtectionGroupNames",false,null),new WCN("42/operation/getEquipmentProtectionGroup_15.html","getEquipmentProtectionGroup",false,null),new WCN("42/operation/getEquipmentProtectionGroupIterator_19.html","getEquipmentProtectionGroupIterator",false,null),new WCN("42/operation/getProtectionGroup_16.html","getProtectionGroup",false,null),new WCN("42/operation/getProtectionGroupIterator_20.html","getProtectionGroupIterator",false,null),new WCN("42/operation/retrieveEquipmentSwitchData_17.html","retrieveEquipmentSwitchData",false,null),new WCN("42/operation/retrieveSwitchData_18.html","retrieveSwitchData",false,null)))),
					new Array(new WCN("42/binding/ProtectionRetrievalSoapHttpBinding.html","ProtectionRetrievalSoapHttpBinding",false,new Array(new WCN("42/operation/getAllEquipmentProtectionGroups_9.html","getAllEquipmentProtectionGroups",false,null),new WCN("42/operation/getAllNonPreemptibleUnprotectedTpNames_10.html","getAllNonPreemptibleUnprotectedTpNames",false,null),new WCN("42/operation/getAllPreemptibleTpNames_11.html","getAllPreemptibleTpNames",false,null),new WCN("42/operation/getAllProtectedTpNames_12.html","getAllProtectedTpNames",false,null),new WCN("42/operation/getAllProtectionGroups_13.html","getAllProtectionGroups",false,null),new WCN("42/operation/getContainingProtectionGroupNames_14.html","getContainingProtectionGroupNames",false,null),new WCN("42/operation/getEquipmentProtectionGroup_15.html","getEquipmentProtectionGroup",false,null),new WCN("42/operation/getEquipmentProtectionGroupIterator_19.html","getEquipmentProtectionGroupIterator",false,null),new WCN("42/operation/getProtectionGroup_16.html","getProtectionGroup",false,null),new WCN("42/operation/getProtectionGroupIterator_20.html","getProtectionGroupIterator",false,null),new WCN("42/operation/retrieveEquipmentSwitchData_17.html","retrieveEquipmentSwitchData",false,null),new WCN("42/operation/retrieveSwitchData_18.html","retrieveSwitchData",false,null))),new WCN("42/binding/ProtectionRetrievalSoapJmsBinding.html","ProtectionRetrievalSoapJmsBinding",false,new Array(new WCN("42/operation/getAllEquipmentProtectionGroups_9.html","getAllEquipmentProtectionGroups",false,null),new WCN("42/operation/getAllNonPreemptibleUnprotectedTpNames_10.html","getAllNonPreemptibleUnprotectedTpNames",false,null),new WCN("42/operation/getAllPreemptibleTpNames_11.html","getAllPreemptibleTpNames",false,null),new WCN("42/operation/getAllProtectedTpNames_12.html","getAllProtectedTpNames",false,null),new WCN("42/operation/getAllProtectionGroups_13.html","getAllProtectionGroups",false,null),new WCN("42/operation/getContainingProtectionGroupNames_14.html","getContainingProtectionGroupNames",false,null),new WCN("42/operation/getEquipmentProtectionGroup_15.html","getEquipmentProtectionGroup",false,null),new WCN("42/operation/getEquipmentProtectionGroupIterator_19.html","getEquipmentProtectionGroupIterator",false,null),new WCN("42/operation/getProtectionGroup_16.html","getProtectionGroup",false,null),new WCN("42/operation/getProtectionGroupIterator_20.html","getProtectionGroupIterator",false,null),new WCN("42/operation/retrieveEquipmentSwitchData_17.html","retrieveEquipmentSwitchData",false,null),new WCN("42/operation/retrieveSwitchData_18.html","retrieveSwitchData",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/pr/v1-0"] = "42/index.html";
