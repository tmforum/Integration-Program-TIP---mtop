﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/ac/v1-0"] =  new WC (
					new Array(new WCN("47/service/AlarmControlHttp.html","AlarmControlHttp",false,null),new WCN("47/service/AlarmControlJms.html","AlarmControlJms",false,null)),
					new Array(new WCN("47/message/setAlarmReportingOffException.html","setAlarmReportingOffException",false,null),new WCN("47/message/setAlarmReportingOffRequest.html","setAlarmReportingOffRequest",false,null),new WCN("47/message/setAlarmReportingOffResponse.html","setAlarmReportingOffResponse",false,null),new WCN("47/message/setAlarmReportingOnException.html","setAlarmReportingOnException",false,null),new WCN("47/message/setAlarmReportingOnRequest.html","setAlarmReportingOnRequest",false,null),new WCN("47/message/setAlarmReportingOnResponse.html","setAlarmReportingOnResponse",false,null),new WCN("47/message/setGtpAlarmReportingOffException.html","setGtpAlarmReportingOffException",false,null),new WCN("47/message/setGtpAlarmReportingOffRequest.html","setGtpAlarmReportingOffRequest",false,null),new WCN("47/message/setGtpAlarmReportingOffResponse.html","setGtpAlarmReportingOffResponse",false,null),new WCN("47/message/setGtpAlarmReportingOnException.html","setGtpAlarmReportingOnException",false,null),new WCN("47/message/setGtpAlarmReportingOnRequest.html","setGtpAlarmReportingOnRequest",false,null),new WCN("47/message/setGtpAlarmReportingOnResponse.html","setGtpAlarmReportingOnResponse",false,null)),
					new Array(new WCN("47/porttype/AlarmControl.html","AlarmControl",false,new Array(new WCN("47/operation/setAlarmReportingOff_30.html","setAlarmReportingOff",false,null),new WCN("47/operation/setAlarmReportingOn_31.html","setAlarmReportingOn",false,null),new WCN("47/operation/setGtpAlarmReportingOff_32.html","setGtpAlarmReportingOff",false,null),new WCN("47/operation/setGtpAlarmReportingOn_33.html","setGtpAlarmReportingOn",false,null)))),
					new Array(new WCN("47/binding/AlarmControlSoapHttpBinding.html","AlarmControlSoapHttpBinding",false,new Array(new WCN("47/operation/setAlarmReportingOff_30.html","setAlarmReportingOff",false,null),new WCN("47/operation/setAlarmReportingOn_31.html","setAlarmReportingOn",false,null),new WCN("47/operation/setGtpAlarmReportingOff_32.html","setGtpAlarmReportingOff",false,null),new WCN("47/operation/setGtpAlarmReportingOn_33.html","setGtpAlarmReportingOn",false,null))),new WCN("47/binding/AlarmControlSoapJmsBinding.html","AlarmControlSoapJmsBinding",false,new Array(new WCN("47/operation/setAlarmReportingOff_30.html","setAlarmReportingOff",false,null),new WCN("47/operation/setAlarmReportingOn_31.html","setAlarmReportingOn",false,null),new WCN("47/operation/setGtpAlarmReportingOff_32.html","setGtpAlarmReportingOff",false,null),new WCN("47/operation/setGtpAlarmReportingOn_33.html","setGtpAlarmReportingOn",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/ac/v1-0"] = "47/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/ah/v1-0"] =  new WC (
					new Array(new WCN("45/service/AlarmHandlingHttp.html","AlarmHandlingHttp",false,null),new WCN("45/service/AlarmHandlingJms.html","AlarmHandlingJms",false,null)),
					new Array(new WCN("45/message/acknowledgeAlarmsException.html","acknowledgeAlarmsException",false,null),new WCN("45/message/acknowledgeAlarmsRequest.html","acknowledgeAlarmsRequest",false,null),new WCN("45/message/acknowledgeAlarmsResponse.html","acknowledgeAlarmsResponse",false,null),new WCN("45/message/unacknowledgeAlarmsException.html","unacknowledgeAlarmsException",false,null),new WCN("45/message/unacknowledgeAlarmsRequest.html","unacknowledgeAlarmsRequest",false,null),new WCN("45/message/unacknowledgeAlarmsResponse.html","unacknowledgeAlarmsResponse",false,null)),
					new Array(new WCN("45/porttype/AlarmHandling.html","AlarmHandling",false,new Array(new WCN("45/operation/acknowledgeAlarms_22.html","acknowledgeAlarms",false,null),new WCN("45/operation/unacknowledgeAlarms_23.html","unacknowledgeAlarms",false,null)))),
					new Array(new WCN("45/binding/AlarmHandlingSoapHttpBinding.html","AlarmHandlingSoapHttpBinding",false,new Array(new WCN("45/operation/acknowledgeAlarms_22.html","acknowledgeAlarms",false,null),new WCN("45/operation/unacknowledgeAlarms_23.html","unacknowledgeAlarms",false,null))),new WCN("45/binding/AlarmHandlingSoapJmsBinding.html","AlarmHandlingSoapJmsBinding",false,new Array(new WCN("45/operation/acknowledgeAlarms_22.html","acknowledgeAlarms",false,null),new WCN("45/operation/unacknowledgeAlarms_23.html","unacknowledgeAlarms",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/ah/v1-0"] = "45/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/ar/v1-0"] =  new WC (
					new Array(new WCN("41/service/AlarmRetrievalHttp.html","AlarmRetrievalHttp",false,null),new WCN("41/service/AlarmRetrievalJms.html","AlarmRetrievalJms",false,null)),
					new Array(new WCN("41/message/getActiveAlarmsCountException.html","getActiveAlarmsCountException",false,null),new WCN("41/message/getActiveAlarmsCountRequest.html","getActiveAlarmsCountRequest",false,null),new WCN("41/message/getActiveAlarmsCountResponse.html","getActiveAlarmsCountResponse",false,null),new WCN("41/message/getActiveAlarmsException.html","getActiveAlarmsException",false,null),new WCN("41/message/getActiveAlarmsRequest.html","getActiveAlarmsRequest",false,null),new WCN("41/message/getActiveAlarmsResponse.html","getActiveAlarmsResponse",false,null)),
					new Array(new WCN("41/porttype/AlarmRetrieval.html","AlarmRetrieval",false,new Array(new WCN("41/operation/getActiveAlarms_5.html","getActiveAlarms",false,null),new WCN("41/operation/getActiveAlarmsCount_6.html","getActiveAlarmsCount",false,null)))),
					new Array(new WCN("41/binding/AlarmRetrievalSoapHttpBinding.html","AlarmRetrievalSoapHttpBinding",false,new Array(new WCN("41/operation/getActiveAlarms_5.html","getActiveAlarms",false,null),new WCN("41/operation/getActiveAlarmsCount_6.html","getActiveAlarmsCount",false,null))),new WCN("41/binding/AlarmRetrievalSoapJmsBinding.html","AlarmRetrievalSoapJmsBinding",false,new Array(new WCN("41/operation/getActiveAlarms_5.html","getActiveAlarms",false,null),new WCN("41/operation/getActiveAlarmsCount_6.html","getActiveAlarmsCount",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/ar/v1-0"] = "41/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/asapc/v1-0"] =  new WC (
					new Array(new WCN("40/service/AlarmSeverityAssignmentProfileControlHttp.html","AlarmSeverityAssignmentProfileControlHttp",false,null),new WCN("40/service/AlarmSeverityAssignmentProfileControlJms.html","AlarmSeverityAssignmentProfileControlJms",false,null)),
					new Array(new WCN("40/message/assignAlarmSeverityAssignmentProfileException.html","assignAlarmSeverityAssignmentProfileException",false,null),new WCN("40/message/assignAlarmSeverityAssignmentProfileRequest.html","assignAlarmSeverityAssignmentProfileRequest",false,null),new WCN("40/message/assignAlarmSeverityAssignmentProfileResponse.html","assignAlarmSeverityAssignmentProfileResponse",false,null),new WCN("40/message/createAlarmSeverityAssignmentProfileException.html","createAlarmSeverityAssignmentProfileException",false,null),new WCN("40/message/createAlarmSeverityAssignmentProfileRequest.html","createAlarmSeverityAssignmentProfileRequest",false,null),new WCN("40/message/createAlarmSeverityAssignmentProfileResponse.html","createAlarmSeverityAssignmentProfileResponse",false,null),new WCN("40/message/deassignAlarmSeverityAssignmentProfileException.html","deassignAlarmSeverityAssignmentProfileException",false,null),new WCN("40/message/deassignAlarmSeverityAssignmentProfileRequest.html","deassignAlarmSeverityAssignmentProfileRequest",false,null),new WCN("40/message/deassignAlarmSeverityAssignmentProfileResponse.html","deassignAlarmSeverityAssignmentProfileResponse",false,null),new WCN("40/message/deleteAlarmSeverityAssignmentProfileException.html","deleteAlarmSeverityAssignmentProfileException",false,null),new WCN("40/message/deleteAlarmSeverityAssignmentProfileRequest.html","deleteAlarmSeverityAssignmentProfileRequest",false,null),new WCN("40/message/deleteAlarmSeverityAssignmentProfileResponse.html","deleteAlarmSeverityAssignmentProfileResponse",false,null),new WCN("40/message/modifyAlarmSeverityAssignmentProfileException.html","modifyAlarmSeverityAssignmentProfileException",false,null),new WCN("40/message/modifyAlarmSeverityAssignmentProfileRequest.html","modifyAlarmSeverityAssignmentProfileRequest",false,null),new WCN("40/message/modifyAlarmSeverityAssignmentProfileResponse.html","modifyAlarmSeverityAssignmentProfileResponse",false,null)),
					new Array(new WCN("40/porttype/AlarmSeverityAssignmentProfileControl.html","AlarmSeverityAssignmentProfileControl",false,new Array(new WCN("40/operation/assignAlarmSeverityAssignmentProfile_0.html","assignAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/createAlarmSeverityAssignmentProfile_1.html","createAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/deassignAlarmSeverityAssignmentProfile_2.html","deassignAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/deleteAlarmSeverityAssignmentProfile_3.html","deleteAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/modifyAlarmSeverityAssignmentProfile_4.html","modifyAlarmSeverityAssignmentProfile",false,null)))),
					new Array(new WCN("40/binding/AlarmSeverityAssignmentProfileControlSoapHttpBinding.html","AlarmSeverityAssignmentProfileControlSoapHttpBinding",false,new Array(new WCN("40/operation/assignAlarmSeverityAssignmentProfile_0.html","assignAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/createAlarmSeverityAssignmentProfile_1.html","createAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/deassignAlarmSeverityAssignmentProfile_2.html","deassignAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/deleteAlarmSeverityAssignmentProfile_3.html","deleteAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/modifyAlarmSeverityAssignmentProfile_4.html","modifyAlarmSeverityAssignmentProfile",false,null))),new WCN("40/binding/AlarmSeverityAssignmentProfileControlSoapJmsBinding.html","AlarmSeverityAssignmentProfileControlSoapJmsBinding",false,new Array(new WCN("40/operation/assignAlarmSeverityAssignmentProfile_0.html","assignAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/createAlarmSeverityAssignmentProfile_1.html","createAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/deassignAlarmSeverityAssignmentProfile_2.html","deassignAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/deleteAlarmSeverityAssignmentProfile_3.html","deleteAlarmSeverityAssignmentProfile",false,null),new WCN("40/operation/modifyAlarmSeverityAssignmentProfile_4.html","modifyAlarmSeverityAssignmentProfile",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/asapc/v1-0"] = "40/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/asapr/v1-0"] =  new WC (
					new Array(new WCN("46/service/AlarmSeverityAssignmentProfileRetrievalHttp.html","AlarmSeverityAssignmentProfileRetrievalHttp",false,null),new WCN("46/service/AlarmSeverityAssignmentProfileRetrievalJms.html","AlarmSeverityAssignmentProfileRetrievalJms",false,null)),
					new Array(new WCN("46/message/getAlarmSeverityAssignmentProfileByResourceException.html","getAlarmSeverityAssignmentProfileByResourceException",false,null),new WCN("46/message/getAlarmSeverityAssignmentProfileByResourceRequest.html","getAlarmSeverityAssignmentProfileByResourceRequest",false,null),new WCN("46/message/getAlarmSeverityAssignmentProfileByResourceResponse.html","getAlarmSeverityAssignmentProfileByResourceResponse",false,null),new WCN("46/message/getAlarmSeverityAssignmentProfileException.html","getAlarmSeverityAssignmentProfileException",false,null),new WCN("46/message/getAlarmSeverityAssignmentProfileIteratorException.html","getAlarmSeverityAssignmentProfileIteratorException",false,null),new WCN("46/message/getAlarmSeverityAssignmentProfileIteratorRequest.html","getAlarmSeverityAssignmentProfileIteratorRequest",false,null),new WCN("46/message/getAlarmSeverityAssignmentProfileIteratorResponse.html","getAlarmSeverityAssignmentProfileIteratorResponse",false,null),new WCN("46/message/getAlarmSeverityAssignmentProfileRequest.html","getAlarmSeverityAssignmentProfileRequest",false,null),new WCN("46/message/getAlarmSeverityAssignmentProfileResponse.html","getAlarmSeverityAssignmentProfileResponse",false,null),new WCN("46/message/getAllAlarmSeverityAssignmentProfileNamesWrtOsException.html","getAllAlarmSeverityAssignmentProfileNamesWrtOsException",false,null),new WCN("46/message/getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest.html","getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest",false,null),new WCN("46/message/getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse.html","getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse",false,null),new WCN("46/message/getAllAlarmSeverityAssignmentProfilesWrtOsException.html","getAllAlarmSeverityAssignmentProfilesWrtOsException",false,null),new WCN("46/message/getAllAlarmSeverityAssignmentProfilesWrtOsRequest.html","getAllAlarmSeverityAssignmentProfilesWrtOsRequest",false,null),new WCN("46/message/getAllAlarmSeverityAssignmentProfilesWrtOsResponse.html","getAllAlarmSeverityAssignmentProfilesWrtOsResponse",false,null),new WCN("46/message/getAsapAssociatedResourceNamesException.html","getAsapAssociatedResourceNamesException",false,null),new WCN("46/message/getAsapAssociatedResourceNamesRequest.html","getAsapAssociatedResourceNamesRequest",false,null),new WCN("46/message/getAsapAssociatedResourceNamesResponse.html","getAsapAssociatedResourceNamesResponse",false,null)),
					new Array(new WCN("46/porttype/AlarmSeverityAssignmentProfileRetrieval.html","AlarmSeverityAssignmentProfileRetrieval",false,new Array(new WCN("46/operation/getAlarmSeverityAssignmentProfile_24.html","getAlarmSeverityAssignmentProfile",false,null),new WCN("46/operation/getAlarmSeverityAssignmentProfileByResource_25.html","getAlarmSeverityAssignmentProfileByResource",false,null),new WCN("46/operation/getAlarmSeverityAssignmentProfileIterator_26.html","getAlarmSeverityAssignmentProfileIterator",false,null),new WCN("46/operation/getAllAlarmSeverityAssignmentProfileNamesWrtOs_27.html","getAllAlarmSeverityAssignmentProfileNamesWrtOs",false,null),new WCN("46/operation/getAllAlarmSeverityAssignmentProfilesWrtOs_28.html","getAllAlarmSeverityAssignmentProfilesWrtOs",false,null),new WCN("46/operation/getAsapAssociatedResourceNames_29.html","getAsapAssociatedResourceNames",false,null)))),
					new Array(new WCN("46/binding/AlarmSeverityAssignmentProfileRetrievalSoapHttpBinding.html","AlarmSeverityAssignmentProfileRetrievalSoapHttpBinding",false,new Array(new WCN("46/operation/getAlarmSeverityAssignmentProfile_24.html","getAlarmSeverityAssignmentProfile",false,null),new WCN("46/operation/getAlarmSeverityAssignmentProfileByResource_25.html","getAlarmSeverityAssignmentProfileByResource",false,null),new WCN("46/operation/getAlarmSeverityAssignmentProfileIterator_26.html","getAlarmSeverityAssignmentProfileIterator",false,null),new WCN("46/operation/getAllAlarmSeverityAssignmentProfileNamesWrtOs_27.html","getAllAlarmSeverityAssignmentProfileNamesWrtOs",false,null),new WCN("46/operation/getAllAlarmSeverityAssignmentProfilesWrtOs_28.html","getAllAlarmSeverityAssignmentProfilesWrtOs",false,null),new WCN("46/operation/getAsapAssociatedResourceNames_29.html","getAsapAssociatedResourceNames",false,null))),new WCN("46/binding/AlarmSeverityAssignmentProfileRetrievalSoapJmsBinding.html","AlarmSeverityAssignmentProfileRetrievalSoapJmsBinding",false,new Array(new WCN("46/operation/getAlarmSeverityAssignmentProfile_24.html","getAlarmSeverityAssignmentProfile",false,null),new WCN("46/operation/getAlarmSeverityAssignmentProfileByResource_25.html","getAlarmSeverityAssignmentProfileByResource",false,null),new WCN("46/operation/getAlarmSeverityAssignmentProfileIterator_26.html","getAlarmSeverityAssignmentProfileIterator",false,null),new WCN("46/operation/getAllAlarmSeverityAssignmentProfileNamesWrtOs_27.html","getAllAlarmSeverityAssignmentProfileNamesWrtOs",false,null),new WCN("46/operation/getAllAlarmSeverityAssignmentProfilesWrtOs_28.html","getAllAlarmSeverityAssignmentProfilesWrtOs",false,null),new WCN("46/operation/getAsapAssociatedResourceNames_29.html","getAsapAssociatedResourceNames",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/asapr/v1-0"] = "46/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/mc/v1-0"] =  new WC (
					new Array(new WCN("42/service/MaintenanceControlHttp.html","MaintenanceControlHttp",false,null),new WCN("42/service/MaintenanceControlJms.html","MaintenanceControlJms",false,null)),
					new Array(new WCN("42/message/getActiveMaintenanceOperationsException.html","getActiveMaintenanceOperationsException",false,null),new WCN("42/message/getActiveMaintenanceOperationsRequest.html","getActiveMaintenanceOperationsRequest",false,null),new WCN("42/message/getActiveMaintenanceOperationsResponse.html","getActiveMaintenanceOperationsResponse",false,null),new WCN("42/message/performMaintenanceOperationException.html","performMaintenanceOperationException",false,null),new WCN("42/message/performMaintenanceOperationRequest.html","performMaintenanceOperationRequest",false,null),new WCN("42/message/performMaintenanceOperationResponse.html","performMaintenanceOperationResponse",false,null)),
					new Array(new WCN("42/porttype/MaintenanceControl.html","MaintenanceControl",false,new Array(new WCN("42/operation/getActiveMaintenanceOperations_7.html","getActiveMaintenanceOperations",false,null),new WCN("42/operation/performMaintenanceOperation_8.html","performMaintenanceOperation",false,null)))),
					new Array(new WCN("42/binding/MaintenanceControlSoapHttpBinding.html","MaintenanceControlSoapHttpBinding",false,new Array(new WCN("42/operation/getActiveMaintenanceOperations_7.html","getActiveMaintenanceOperations",false,null),new WCN("42/operation/performMaintenanceOperation_8.html","performMaintenanceOperation",false,null))),new WCN("42/binding/MaintenanceControlSoapJmsBinding.html","MaintenanceControlSoapJmsBinding",false,new Array(new WCN("42/operation/getActiveMaintenanceOperations_7.html","getActiveMaintenanceOperations",false,null),new WCN("42/operation/performMaintenanceOperation_8.html","performMaintenanceOperation",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/mc/v1-0"] = "42/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/pc/v1-0"] =  new WC (
					new Array(new WCN("44/service/ProtectionControlHttp.html","ProtectionControlHttp",false,null),new WCN("44/service/ProtectionControlJms.html","ProtectionControlJms",false,null)),
					new Array(new WCN("44/message/performProtectionCommandException.html","performProtectionCommandException",false,null),new WCN("44/message/performProtectionCommandRequest.html","performProtectionCommandRequest",false,null),new WCN("44/message/performProtectionCommandResponse.html","performProtectionCommandResponse",false,null)),
					new Array(new WCN("44/porttype/ProtectionControl.html","ProtectionControl",false,new Array(new WCN("44/operation/performProtectionCommand_21.html","performProtectionCommand",false,null)))),
					new Array(new WCN("44/binding/ProtectionControlSoapHttpBinding.html","ProtectionControlSoapHttpBinding",false,new Array(new WCN("44/operation/performProtectionCommand_21.html","performProtectionCommand",false,null))),new WCN("44/binding/ProtectionControlSoapJmsBinding.html","ProtectionControlSoapJmsBinding",false,new Array(new WCN("44/operation/performProtectionCommand_21.html","performProtectionCommand",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/pc/v1-0"] = "44/index.html";
wcDB ["http://www.tmforum.org/mtop/rtm/wsdl/pr/v1-0"] =  new WC (
					new Array(new WCN("43/service/ProtectionRetrievalHttp.html","ProtectionRetrievalHttp",false,null),new WCN("43/service/ProtectionRetrievalJms.html","ProtectionRetrievalJms",false,null)),
					new Array(new WCN("43/message/getAllEquipmentProtectionGroupsException.html","getAllEquipmentProtectionGroupsException",false,null),new WCN("43/message/getAllEquipmentProtectionGroupsRequest.html","getAllEquipmentProtectionGroupsRequest",false,null),new WCN("43/message/getAllEquipmentProtectionGroupsResponse.html","getAllEquipmentProtectionGroupsResponse",false,null),new WCN("43/message/getAllNonPreemptibleUnprotectedTpNamesException.html","getAllNonPreemptibleUnprotectedTpNamesException",false,null),new WCN("43/message/getAllNonPreemptibleUnprotectedTpNamesRequest.html","getAllNonPreemptibleUnprotectedTpNamesRequest",false,null),new WCN("43/message/getAllNonPreemptibleUnprotectedTpNamesResponse.html","getAllNonPreemptibleUnprotectedTpNamesResponse",false,null),new WCN("43/message/getAllPreemptibleTerminationPointNamesException.html","getAllPreemptibleTerminationPointNamesException",false,null),new WCN("43/message/getAllPreemptibleTerminationPointNamesRequest.html","getAllPreemptibleTerminationPointNamesRequest",false,null),new WCN("43/message/getAllPreemptibleTerminationPointNamesResponse.html","getAllPreemptibleTerminationPointNamesResponse",false,null),new WCN("43/message/getAllProtectedTerminationPointNamesException.html","getAllProtectedTerminationPointNamesException",false,null),new WCN("43/message/getAllProtectedTerminationPointNamesRequest.html","getAllProtectedTerminationPointNamesRequest",false,null),new WCN("43/message/getAllProtectedTerminationPointNamesResponse.html","getAllProtectedTerminationPointNamesResponse",false,null),new WCN("43/message/getAllProtectionGroupsException.html","getAllProtectionGroupsException",false,null),new WCN("43/message/getAllProtectionGroupsRequest.html","getAllProtectionGroupsRequest",false,null),new WCN("43/message/getAllProtectionGroupsResponse.html","getAllProtectionGroupsResponse",false,null),new WCN("43/message/getContainingProtectionGroupNamesException.html","getContainingProtectionGroupNamesException",false,null),new WCN("43/message/getContainingProtectionGroupNamesRequest.html","getContainingProtectionGroupNamesRequest",false,null),new WCN("43/message/getContainingProtectionGroupNamesResponse.html","getContainingProtectionGroupNamesResponse",false,null),new WCN("43/message/getEquipmentProtectionGroupException.html","getEquipmentProtectionGroupException",false,null),new WCN("43/message/getEquipmentProtectionGroupIteratorException.html","getEquipmentProtectionGroupIteratorException",false,null),new WCN("43/message/getEquipmentProtectionGroupIteratorRequest.html","getEquipmentProtectionGroupIteratorRequest",false,null),new WCN("43/message/getEquipmentProtectionGroupIteratorResponse.html","getEquipmentProtectionGroupIteratorResponse",false,null),new WCN("43/message/getEquipmentProtectionGroupRequest.html","getEquipmentProtectionGroupRequest",false,null),new WCN("43/message/getEquipmentProtectionGroupResponse.html","getEquipmentProtectionGroupResponse",false,null),new WCN("43/message/getProtectionGroupException.html","getProtectionGroupException",false,null),new WCN("43/message/getProtectionGroupIteratorException.html","getProtectionGroupIteratorException",false,null),new WCN("43/message/getProtectionGroupIteratorRequest.html","getProtectionGroupIteratorRequest",false,null),new WCN("43/message/getProtectionGroupIteratorResponse.html","getProtectionGroupIteratorResponse",false,null),new WCN("43/message/getProtectionGroupRequest.html","getProtectionGroupRequest",false,null),new WCN("43/message/getProtectionGroupResponse.html","getProtectionGroupResponse",false,null),new WCN("43/message/retrieveEquipmentSwitchDataException.html","retrieveEquipmentSwitchDataException",false,null),new WCN("43/message/retrieveEquipmentSwitchDataRequest.html","retrieveEquipmentSwitchDataRequest",false,null),new WCN("43/message/retrieveEquipmentSwitchDataResponse.html","retrieveEquipmentSwitchDataResponse",false,null),new WCN("43/message/retrieveSwitchDataException.html","retrieveSwitchDataException",false,null),new WCN("43/message/retrieveSwitchDataRequest.html","retrieveSwitchDataRequest",false,null),new WCN("43/message/retrieveSwitchDataResponse.html","retrieveSwitchDataResponse",false,null)),
					new Array(new WCN("43/porttype/ProtectionRetrieval.html","ProtectionRetrieval",false,new Array(new WCN("43/operation/getAllEquipmentProtectionGroups_9.html","getAllEquipmentProtectionGroups",false,null),new WCN("43/operation/getAllNonPreemptibleUnprotectedTpNames_10.html","getAllNonPreemptibleUnprotectedTpNames",false,null),new WCN("43/operation/getAllPreemptibleTerminationPointNames_11.html","getAllPreemptibleTerminationPointNames",false,null),new WCN("43/operation/getAllProtectedTerminationPointNames_12.html","getAllProtectedTerminationPointNames",false,null),new WCN("43/operation/getAllProtectionGroups_13.html","getAllProtectionGroups",false,null),new WCN("43/operation/getContainingProtectionGroupNames_14.html","getContainingProtectionGroupNames",false,null),new WCN("43/operation/getEquipmentProtectionGroup_15.html","getEquipmentProtectionGroup",false,null),new WCN("43/operation/getEquipmentProtectionGroupIterator_19.html","getEquipmentProtectionGroupIterator",false,null),new WCN("43/operation/getProtectionGroup_16.html","getProtectionGroup",false,null),new WCN("43/operation/getProtectionGroupIterator_20.html","getProtectionGroupIterator",false,null),new WCN("43/operation/retrieveEquipmentSwitchData_17.html","retrieveEquipmentSwitchData",false,null),new WCN("43/operation/retrieveSwitchData_18.html","retrieveSwitchData",false,null)))),
					new Array(new WCN("43/binding/ProtectionRetrievalSoapHttpBinding.html","ProtectionRetrievalSoapHttpBinding",false,new Array(new WCN("43/operation/getAllEquipmentProtectionGroups_9.html","getAllEquipmentProtectionGroups",false,null),new WCN("43/operation/getAllNonPreemptibleUnprotectedTpNames_10.html","getAllNonPreemptibleUnprotectedTpNames",false,null),new WCN("43/operation/getAllPreemptibleTerminationPointNames_11.html","getAllPreemptibleTerminationPointNames",false,null),new WCN("43/operation/getAllProtectedTerminationPointNames_12.html","getAllProtectedTerminationPointNames",false,null),new WCN("43/operation/getAllProtectionGroups_13.html","getAllProtectionGroups",false,null),new WCN("43/operation/getContainingProtectionGroupNames_14.html","getContainingProtectionGroupNames",false,null),new WCN("43/operation/getEquipmentProtectionGroup_15.html","getEquipmentProtectionGroup",false,null),new WCN("43/operation/getEquipmentProtectionGroupIterator_19.html","getEquipmentProtectionGroupIterator",false,null),new WCN("43/operation/getProtectionGroup_16.html","getProtectionGroup",false,null),new WCN("43/operation/getProtectionGroupIterator_20.html","getProtectionGroupIterator",false,null),new WCN("43/operation/retrieveEquipmentSwitchData_17.html","retrieveEquipmentSwitchData",false,null),new WCN("43/operation/retrieveSwitchData_18.html","retrieveSwitchData",false,null))),new WCN("43/binding/ProtectionRetrievalSoapJmsBinding.html","ProtectionRetrievalSoapJmsBinding",false,new Array(new WCN("43/operation/getAllEquipmentProtectionGroups_9.html","getAllEquipmentProtectionGroups",false,null),new WCN("43/operation/getAllNonPreemptibleUnprotectedTpNames_10.html","getAllNonPreemptibleUnprotectedTpNames",false,null),new WCN("43/operation/getAllPreemptibleTerminationPointNames_11.html","getAllPreemptibleTerminationPointNames",false,null),new WCN("43/operation/getAllProtectedTerminationPointNames_12.html","getAllProtectedTerminationPointNames",false,null),new WCN("43/operation/getAllProtectionGroups_13.html","getAllProtectionGroups",false,null),new WCN("43/operation/getContainingProtectionGroupNames_14.html","getContainingProtectionGroupNames",false,null),new WCN("43/operation/getEquipmentProtectionGroup_15.html","getEquipmentProtectionGroup",false,null),new WCN("43/operation/getEquipmentProtectionGroupIterator_19.html","getEquipmentProtectionGroupIterator",false,null),new WCN("43/operation/getProtectionGroup_16.html","getProtectionGroup",false,null),new WCN("43/operation/getProtectionGroupIterator_20.html","getProtectionGroupIterator",false,null),new WCN("43/operation/retrieveEquipmentSwitchData_17.html","retrieveEquipmentSwitchData",false,null),new WCN("43/operation/retrieveSwitchData_18.html","retrieveSwitchData",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rtm/wsdl/pr/v1-0"] = "43/index.html";
