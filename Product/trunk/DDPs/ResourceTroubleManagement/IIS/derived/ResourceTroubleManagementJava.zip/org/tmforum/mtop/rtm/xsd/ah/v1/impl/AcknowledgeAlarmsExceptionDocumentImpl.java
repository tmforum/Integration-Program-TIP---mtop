/*
 * An XML document type.
 * Localname: acknowledgeAlarmsException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ah/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ah.v1.impl;
/**
 * A document containing one acknowledgeAlarmsException(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1) element.
 *
 * This is a complex type.
 */
public class AcknowledgeAlarmsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument
{
    
    public AcknowledgeAlarmsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACKNOWLEDGEALARMSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "acknowledgeAlarmsException");
    
    
    /**
     * Gets the "acknowledgeAlarmsException" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException getAcknowledgeAlarmsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException)get_store().find_element_user(ACKNOWLEDGEALARMSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "acknowledgeAlarmsException" element
     */
    public void setAcknowledgeAlarmsException(org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException acknowledgeAlarmsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException)get_store().find_element_user(ACKNOWLEDGEALARMSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException)get_store().add_element_user(ACKNOWLEDGEALARMSEXCEPTION$0);
            }
            target.set(acknowledgeAlarmsException);
        }
    }
    
    /**
     * Appends and returns a new empty "acknowledgeAlarmsException" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException addNewAcknowledgeAlarmsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException)get_store().add_element_user(ACKNOWLEDGEALARMSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML acknowledgeAlarmsException(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1).
     *
     * This is a complex type.
     */
    public static class AcknowledgeAlarmsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsExceptionDocument.AcknowledgeAlarmsException
    {
        
        public AcknowledgeAlarmsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
