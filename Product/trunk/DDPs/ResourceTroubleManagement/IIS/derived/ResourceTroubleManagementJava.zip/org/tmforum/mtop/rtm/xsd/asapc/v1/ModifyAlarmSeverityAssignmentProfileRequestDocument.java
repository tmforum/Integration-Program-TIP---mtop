/*
 * An XML document type.
 * Localname: modifyAlarmSeverityAssignmentProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1;


/**
 * A document containing one modifyAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public interface ModifyAlarmSeverityAssignmentProfileRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ModifyAlarmSeverityAssignmentProfileRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD7F14712642FA7BC89FBCB45763AB9FB").resolveHandle("modifyalarmseverityassignmentprofilerequest13f1doctype");
    
    /**
     * Gets the "modifyAlarmSeverityAssignmentProfileRequest" element
     */
    org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest getModifyAlarmSeverityAssignmentProfileRequest();
    
    /**
     * Sets the "modifyAlarmSeverityAssignmentProfileRequest" element
     */
    void setModifyAlarmSeverityAssignmentProfileRequest(org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest modifyAlarmSeverityAssignmentProfileRequest);
    
    /**
     * Appends and returns a new empty "modifyAlarmSeverityAssignmentProfileRequest" element
     */
    org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest addNewModifyAlarmSeverityAssignmentProfileRequest();
    
    /**
     * An XML modifyAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public interface ModifyAlarmSeverityAssignmentProfileRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ModifyAlarmSeverityAssignmentProfileRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD7F14712642FA7BC89FBCB45763AB9FB").resolveHandle("modifyalarmseverityassignmentprofilerequest24deelemtype");
        
        /**
         * Gets the "asapName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getAsapName();
        
        /**
         * Tests for nil "asapName" element
         */
        boolean isNilAsapName();
        
        /**
         * True if has "asapName" element
         */
        boolean isSetAsapName();
        
        /**
         * Sets the "asapName" element
         */
        void setAsapName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType asapName);
        
        /**
         * Appends and returns a new empty "asapName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewAsapName();
        
        /**
         * Nils the "asapName" element
         */
        void setNilAsapName();
        
        /**
         * Unsets the "asapName" element
         */
        void unsetAsapName();
        
        /**
         * Gets the "asapModifyData" element
         */
        org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType getAsapModifyData();
        
        /**
         * Tests for nil "asapModifyData" element
         */
        boolean isNilAsapModifyData();
        
        /**
         * True if has "asapModifyData" element
         */
        boolean isSetAsapModifyData();
        
        /**
         * Sets the "asapModifyData" element
         */
        void setAsapModifyData(org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType asapModifyData);
        
        /**
         * Appends and returns a new empty "asapModifyData" element
         */
        org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType addNewAsapModifyData();
        
        /**
         * Nils the "asapModifyData" element
         */
        void setNilAsapModifyData();
        
        /**
         * Unsets the "asapModifyData" element
         */
        void unsetAsapModifyData();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest newInstance() {
              return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument newInstance() {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
