/*
 * An XML document type.
 * Localname: getAlarmSeverityAssignmentProfileByResourceRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAlarmSeverityAssignmentProfileByResourceRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAlarmSeverityAssignmentProfileByResourceRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument
{
    
    public GetAlarmSeverityAssignmentProfileByResourceRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAlarmSeverityAssignmentProfileByResourceRequest");
    
    
    /**
     * Gets the "getAlarmSeverityAssignmentProfileByResourceRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest getGetAlarmSeverityAssignmentProfileByResourceRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAlarmSeverityAssignmentProfileByResourceRequest" element
     */
    public void setGetAlarmSeverityAssignmentProfileByResourceRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest getAlarmSeverityAssignmentProfileByResourceRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEREQUEST$0);
            }
            target.set(getAlarmSeverityAssignmentProfileByResourceRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAlarmSeverityAssignmentProfileByResourceRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest addNewGetAlarmSeverityAssignmentProfileByResourceRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAlarmSeverityAssignmentProfileByResourceRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAlarmSeverityAssignmentProfileByResourceRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceRequestDocument.GetAlarmSeverityAssignmentProfileByResourceRequest
    {
        
        public GetAlarmSeverityAssignmentProfileByResourceRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName RESOURCENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "resourceName");
        private static final javax.xml.namespace.QName LAYERRATELIST$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "layerRateList");
        
        
        /**
         * Gets the "resourceName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(RESOURCENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "resourceName" element
         */
        public boolean isSetResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(RESOURCENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "resourceName" element
         */
        public void setResourceName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType resourceName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(RESOURCENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(RESOURCENAME$0);
                }
                target.set(resourceName);
            }
        }
        
        /**
         * Appends and returns a new empty "resourceName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(RESOURCENAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "resourceName" element
         */
        public void unsetResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(RESOURCENAME$0, 0);
            }
        }
        
        /**
         * Gets the "layerRateList" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATELIST$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "layerRateList" element
         */
        public boolean isSetLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LAYERRATELIST$2) != 0;
            }
        }
        
        /**
         * Sets the "layerRateList" element
         */
        public void setLayerRateList(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType layerRateList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATELIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATELIST$2);
                }
                target.set(layerRateList);
            }
        }
        
        /**
         * Appends and returns a new empty "layerRateList" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATELIST$2);
                return target;
            }
        }
        
        /**
         * Unsets the "layerRateList" element
         */
        public void unsetLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LAYERRATELIST$2, 0);
            }
        }
    }
}
