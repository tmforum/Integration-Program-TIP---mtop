/*
 * An XML document type.
 * Localname: commonObjectCreateData
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cocd/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cocd.v1.impl;
/**
 * A document containing one commonObjectCreateData(@http://www.tmforum.org/mtop/fmw/xsd/cocd/v1) element.
 *
 * This is a complex type.
 */
public class CommonObjectCreateDataDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataDocument
{
    
    public CommonObjectCreateDataDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONOBJECTCREATEDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cocd/v1", "commonObjectCreateData");
    
    
    /**
     * Gets the "commonObjectCreateData" element
     */
    public org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType getCommonObjectCreateData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType)get_store().find_element_user(COMMONOBJECTCREATEDATA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonObjectCreateData" element
     */
    public void setCommonObjectCreateData(org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType commonObjectCreateData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType)get_store().find_element_user(COMMONOBJECTCREATEDATA$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType)get_store().add_element_user(COMMONOBJECTCREATEDATA$0);
            }
            target.set(commonObjectCreateData);
        }
    }
    
    /**
     * Appends and returns a new empty "commonObjectCreateData" element
     */
    public org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType addNewCommonObjectCreateData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cocd.v1.CommonObjectCreateDataType)get_store().add_element_user(COMMONOBJECTCREATEDATA$0);
            return target;
        }
    }
}
