/*
 * An XML document type.
 * Localname: getAsapAssociatedResourceNamesResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAsapAssociatedResourceNamesResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAsapAssociatedResourceNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument
{
    
    public GetAsapAssociatedResourceNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASAPASSOCIATEDRESOURCENAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAsapAssociatedResourceNamesResponse");
    
    
    /**
     * Gets the "getAsapAssociatedResourceNamesResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse getGetAsapAssociatedResourceNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse)get_store().find_element_user(GETASAPASSOCIATEDRESOURCENAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAsapAssociatedResourceNamesResponse" element
     */
    public void setGetAsapAssociatedResourceNamesResponse(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse getAsapAssociatedResourceNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse)get_store().find_element_user(GETASAPASSOCIATEDRESOURCENAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse)get_store().add_element_user(GETASAPASSOCIATEDRESOURCENAMESRESPONSE$0);
            }
            target.set(getAsapAssociatedResourceNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAsapAssociatedResourceNamesResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse addNewGetAsapAssociatedResourceNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse)get_store().add_element_user(GETASAPASSOCIATEDRESOURCENAMESRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAsapAssociatedResourceNamesResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAsapAssociatedResourceNamesResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesResponseDocument.GetAsapAssociatedResourceNamesResponse
    {
        
        public GetAsapAssociatedResourceNamesResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NAMELIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "nameList");
        
        
        /**
         * Gets the "nameList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(NAMELIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "nameList" element
         */
        public boolean isSetNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NAMELIST$0) != 0;
            }
        }
        
        /**
         * Sets the "nameList" element
         */
        public void setNameList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType nameList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(NAMELIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(NAMELIST$0);
                }
                target.set(nameList);
            }
        }
        
        /**
         * Appends and returns a new empty "nameList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(NAMELIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "nameList" element
         */
        public void unsetNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NAMELIST$0, 0);
            }
        }
    }
}
