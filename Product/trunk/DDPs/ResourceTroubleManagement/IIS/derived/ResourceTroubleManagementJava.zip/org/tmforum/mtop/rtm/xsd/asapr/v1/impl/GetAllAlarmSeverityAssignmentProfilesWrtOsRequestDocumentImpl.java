/*
 * An XML document type.
 * Localname: getAllAlarmSeverityAssignmentProfilesWrtOsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAlarmSeverityAssignmentProfilesWrtOsRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument
{
    
    public GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAlarmSeverityAssignmentProfilesWrtOsRequest");
    
    
    /**
     * Gets the "getAllAlarmSeverityAssignmentProfilesWrtOsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest getGetAllAlarmSeverityAssignmentProfilesWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAlarmSeverityAssignmentProfilesWrtOsRequest" element
     */
    public void setGetAllAlarmSeverityAssignmentProfilesWrtOsRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest getAllAlarmSeverityAssignmentProfilesWrtOsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSREQUEST$0);
            }
            target.set(getAllAlarmSeverityAssignmentProfilesWrtOsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAlarmSeverityAssignmentProfilesWrtOsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest addNewGetAllAlarmSeverityAssignmentProfilesWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllAlarmSeverityAssignmentProfilesWrtOsRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAlarmSeverityAssignmentProfilesWrtOsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsRequest
    {
        
        public GetAllAlarmSeverityAssignmentProfilesWrtOsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OSNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "osName");
        
        
        /**
         * Gets the "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "osName" element
         */
        public boolean isSetOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OSNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "osName" element
         */
        public void setOsName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType osName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OSNAME$0);
                }
                target.set(osName);
            }
        }
        
        /**
         * Appends and returns a new empty "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OSNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "osName" element
         */
        public void unsetOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OSNAME$0, 0);
            }
        }
    }
}
