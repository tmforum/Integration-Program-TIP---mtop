/*
 * XML Type:  MaintenanceOperationModeEnumType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/cmo/v1
 * Java type: org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.cmo.v1.impl;
/**
 * An XML MaintenanceOperationModeEnumType(@http://www.tmforum.org/mtop/nra/xsd/cmo/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType.
 */
public class MaintenanceOperationModeEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType
{
    
    public MaintenanceOperationModeEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected MaintenanceOperationModeEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
