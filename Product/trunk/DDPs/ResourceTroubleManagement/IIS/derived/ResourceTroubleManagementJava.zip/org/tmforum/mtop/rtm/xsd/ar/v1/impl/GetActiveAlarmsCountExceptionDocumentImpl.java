/*
 * An XML document type.
 * Localname: getActiveAlarmsCountException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1.impl;
/**
 * A document containing one getActiveAlarmsCountException(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveAlarmsCountExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument
{
    
    public GetActiveAlarmsCountExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEALARMSCOUNTEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "getActiveAlarmsCountException");
    
    
    /**
     * Gets the "getActiveAlarmsCountException" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException getGetActiveAlarmsCountException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException)get_store().find_element_user(GETACTIVEALARMSCOUNTEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveAlarmsCountException" element
     */
    public void setGetActiveAlarmsCountException(org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException getActiveAlarmsCountException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException)get_store().find_element_user(GETACTIVEALARMSCOUNTEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException)get_store().add_element_user(GETACTIVEALARMSCOUNTEXCEPTION$0);
            }
            target.set(getActiveAlarmsCountException);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveAlarmsCountException" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException addNewGetActiveAlarmsCountException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException)get_store().add_element_user(GETACTIVEALARMSCOUNTEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getActiveAlarmsCountException(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1).
     *
     * This is a complex type.
     */
    public static class GetActiveAlarmsCountExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountExceptionDocument.GetActiveAlarmsCountException
    {
        
        public GetActiveAlarmsCountExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
