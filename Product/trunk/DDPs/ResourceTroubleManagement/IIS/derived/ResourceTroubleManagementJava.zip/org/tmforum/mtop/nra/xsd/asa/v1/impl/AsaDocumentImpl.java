/*
 * An XML document type.
 * Localname: asa
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/asa/v1
 * Java type: org.tmforum.mtop.nra.xsd.asa.v1.AsaDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.asa.v1.impl;
/**
 * A document containing one asa(@http://www.tmforum.org/mtop/nra/xsd/asa/v1) element.
 *
 * This is a complex type.
 */
public class AsaDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.asa.v1.AsaDocument
{
    
    public AsaDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asa/v1", "asa");
    
    
    /**
     * Gets the "asa" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType getAsa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType)get_store().find_element_user(ASA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "asa" element
     */
    public void setAsa(org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType asa)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType)get_store().find_element_user(ASA$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType)get_store().add_element_user(ASA$0);
            }
            target.set(asa);
        }
    }
    
    /**
     * Appends and returns a new empty "asa" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType addNewAsa()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType)get_store().add_element_user(ASA$0);
            return target;
        }
    }
}
