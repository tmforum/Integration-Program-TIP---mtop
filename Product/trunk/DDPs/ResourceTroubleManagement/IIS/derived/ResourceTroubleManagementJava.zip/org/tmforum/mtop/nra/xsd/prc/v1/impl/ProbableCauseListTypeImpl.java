/*
 * XML Type:  ProbableCauseListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/prc/v1
 * Java type: org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.prc.v1.impl;
/**
 * An XML ProbableCauseListType(@http://www.tmforum.org/mtop/nra/xsd/prc/v1).
 *
 * This is a complex type.
 */
public class ProbableCauseListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType
{
    
    public ProbableCauseListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PRC$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/prc/v1", "prc");
    
    
    /**
     * Gets a List of "prc" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType> getPrcList()
    {
        final class PrcList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType>
        {
            public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType get(int i)
                { return ProbableCauseListTypeImpl.this.getPrcArray(i); }
            
            public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType set(int i, org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType o)
            {
                org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType old = ProbableCauseListTypeImpl.this.getPrcArray(i);
                ProbableCauseListTypeImpl.this.setPrcArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType o)
                { ProbableCauseListTypeImpl.this.insertNewPrc(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType old = ProbableCauseListTypeImpl.this.getPrcArray(i);
                ProbableCauseListTypeImpl.this.removePrc(i);
                return old;
            }
            
            public int size()
                { return ProbableCauseListTypeImpl.this.sizeOfPrcArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PrcList();
        }
    }
    
    /**
     * Gets array of all "prc" elements
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType[] getPrcArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PRC$0, targetList);
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType[] result = new org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "prc" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType getPrcArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PRC$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "prc" element
     */
    public int sizeOfPrcArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRC$0);
        }
    }
    
    /**
     * Sets array of all "prc" element
     */
    public void setPrcArray(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType[] prcArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(prcArray, PRC$0);
        }
    }
    
    /**
     * Sets ith "prc" element
     */
    public void setPrcArray(int i, org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType prc)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PRC$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(prc);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "prc" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType insertNewPrc(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().insert_element_user(PRC$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "prc" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType addNewPrc()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PRC$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "prc" element
     */
    public void removePrc(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRC$0, i);
        }
    }
}
