/*
 * An XML document type.
 * Localname: getAlarmSeverityAssignmentProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAlarmSeverityAssignmentProfileResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAlarmSeverityAssignmentProfileResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument
{
    
    public GetAlarmSeverityAssignmentProfileResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALARMSEVERITYASSIGNMENTPROFILERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAlarmSeverityAssignmentProfileResponse");
    
    
    /**
     * Gets the "getAlarmSeverityAssignmentProfileResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse getGetAlarmSeverityAssignmentProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAlarmSeverityAssignmentProfileResponse" element
     */
    public void setGetAlarmSeverityAssignmentProfileResponse(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse getAlarmSeverityAssignmentProfileResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILERESPONSE$0);
            }
            target.set(getAlarmSeverityAssignmentProfileResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAlarmSeverityAssignmentProfileResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse addNewGetAlarmSeverityAssignmentProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAlarmSeverityAssignmentProfileResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAlarmSeverityAssignmentProfileResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileResponseDocument.GetAlarmSeverityAssignmentProfileResponse
    {
        
        public GetAlarmSeverityAssignmentProfileResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "asap");
        
        
        /**
         * Gets the "asap" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType getAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "asap" element
         */
        public boolean isSetAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAP$0) != 0;
            }
        }
        
        /**
         * Sets the "asap" element
         */
        public void setAsap(org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType asap)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(ASAP$0);
                }
                target.set(asap);
            }
        }
        
        /**
         * Appends and returns a new empty "asap" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType addNewAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(ASAP$0);
                return target;
            }
        }
        
        /**
         * Unsets the "asap" element
         */
        public void unsetAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAP$0, 0);
            }
        }
    }
}
