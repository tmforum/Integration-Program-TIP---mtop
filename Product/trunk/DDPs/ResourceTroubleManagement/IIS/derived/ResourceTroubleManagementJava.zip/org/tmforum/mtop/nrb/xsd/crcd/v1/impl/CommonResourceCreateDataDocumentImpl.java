/*
 * An XML document type.
 * Localname: commonResourceCreateData
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/crcd/v1
 * Java type: org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.crcd.v1.impl;
/**
 * A document containing one commonResourceCreateData(@http://www.tmforum.org/mtop/nrb/xsd/crcd/v1) element.
 *
 * This is a complex type.
 */
public class CommonResourceCreateDataDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataDocument
{
    
    public CommonResourceCreateDataDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONRESOURCECREATEDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/crcd/v1", "commonResourceCreateData");
    
    
    /**
     * Gets the "commonResourceCreateData" element
     */
    public org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType getCommonResourceCreateData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType target = null;
            target = (org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType)get_store().find_element_user(COMMONRESOURCECREATEDATA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonResourceCreateData" element
     */
    public void setCommonResourceCreateData(org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType commonResourceCreateData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType target = null;
            target = (org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType)get_store().find_element_user(COMMONRESOURCECREATEDATA$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType)get_store().add_element_user(COMMONRESOURCECREATEDATA$0);
            }
            target.set(commonResourceCreateData);
        }
    }
    
    /**
     * Appends and returns a new empty "commonResourceCreateData" element
     */
    public org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType addNewCommonResourceCreateData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType target = null;
            target = (org.tmforum.mtop.nrb.xsd.crcd.v1.CommonResourceCreateDataType)get_store().add_element_user(COMMONRESOURCECREATEDATA$0);
            return target;
        }
    }
}
