/*
 * An XML document type.
 * Localname: assignAlarmSeverityAssignmentProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one assignAlarmSeverityAssignmentProfileResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class AssignAlarmSeverityAssignmentProfileResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument
{
    
    public AssignAlarmSeverityAssignmentProfileResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "assignAlarmSeverityAssignmentProfileResponse");
    
    
    /**
     * Gets the "assignAlarmSeverityAssignmentProfileResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse getAssignAlarmSeverityAssignmentProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse)get_store().find_element_user(ASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "assignAlarmSeverityAssignmentProfileResponse" element
     */
    public void setAssignAlarmSeverityAssignmentProfileResponse(org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse assignAlarmSeverityAssignmentProfileResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse)get_store().find_element_user(ASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse)get_store().add_element_user(ASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0);
            }
            target.set(assignAlarmSeverityAssignmentProfileResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "assignAlarmSeverityAssignmentProfileResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse addNewAssignAlarmSeverityAssignmentProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse)get_store().add_element_user(ASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML assignAlarmSeverityAssignmentProfileResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class AssignAlarmSeverityAssignmentProfileResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileResponseDocument.AssignAlarmSeverityAssignmentProfileResponse
    {
        
        public AssignAlarmSeverityAssignmentProfileResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "vendorExtensions");
        
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        public boolean isNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$0) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                return target;
            }
        }
        
        /**
         * Nils the "vendorExtensions" element
         */
        public void setNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$0, 0);
            }
        }
    }
}
