/*
 * An XML document type.
 * Localname: getAllAlarmSeverityAssignmentProfilesWrtOsException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAlarmSeverityAssignmentProfilesWrtOsException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument
{
    
    public GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAlarmSeverityAssignmentProfilesWrtOsException");
    
    
    /**
     * Gets the "getAllAlarmSeverityAssignmentProfilesWrtOsException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException getGetAllAlarmSeverityAssignmentProfilesWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAlarmSeverityAssignmentProfilesWrtOsException" element
     */
    public void setGetAllAlarmSeverityAssignmentProfilesWrtOsException(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException getAllAlarmSeverityAssignmentProfilesWrtOsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSEXCEPTION$0);
            }
            target.set(getAllAlarmSeverityAssignmentProfilesWrtOsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAlarmSeverityAssignmentProfilesWrtOsException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException addNewGetAllAlarmSeverityAssignmentProfilesWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILESWRTOSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllAlarmSeverityAssignmentProfilesWrtOsException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfilesWrtOsException
    {
        
        public GetAllAlarmSeverityAssignmentProfilesWrtOsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
