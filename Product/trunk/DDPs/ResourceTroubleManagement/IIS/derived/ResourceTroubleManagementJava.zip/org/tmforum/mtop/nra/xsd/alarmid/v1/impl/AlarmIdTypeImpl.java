/*
 * XML Type:  AlarmIdType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alarmid/v1
 * Java type: org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alarmid.v1.impl;
/**
 * An XML AlarmIdType(@http://www.tmforum.org/mtop/nra/xsd/alarmid/v1).
 *
 * This is a complex type.
 */
public class AlarmIdTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType
{
    
    public AlarmIdTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alarmid/v1", "objectName");
    private static final javax.xml.namespace.QName LAYERRATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alarmid/v1", "layerRate");
    private static final javax.xml.namespace.QName PROBABLECAUSE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alarmid/v1", "probableCause");
    private static final javax.xml.namespace.QName PROBABLECAUSEQUALIFIER$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alarmid/v1", "probableCauseQualifier");
    
    
    /**
     * Gets the "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "objectName" element
     */
    public boolean isSetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "objectName" element
     */
    public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
            }
            target.set(objectName);
        }
    }
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$0);
            return target;
        }
    }
    
    /**
     * Unsets the "objectName" element
     */
    public void unsetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTNAME$0, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$2) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$2);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$2, 0);
        }
    }
    
    /**
     * Gets the "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType getProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "probableCause" element
     */
    public boolean isSetProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROBABLECAUSE$4) != 0;
        }
    }
    
    /**
     * Sets the "probableCause" element
     */
    public void setProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType probableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$4);
            }
            target.set(probableCause);
        }
    }
    
    /**
     * Appends and returns a new empty "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType addNewProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$4);
            return target;
        }
    }
    
    /**
     * Unsets the "probableCause" element
     */
    public void unsetProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROBABLECAUSE$4, 0);
        }
    }
    
    /**
     * Gets the "probableCauseQualifier" element
     */
    public java.lang.String getProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROBABLECAUSEQUALIFIER$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "probableCauseQualifier" element
     */
    public org.apache.xmlbeans.XmlString xgetProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROBABLECAUSEQUALIFIER$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "probableCauseQualifier" element
     */
    public boolean isSetProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROBABLECAUSEQUALIFIER$6) != 0;
        }
    }
    
    /**
     * Sets the "probableCauseQualifier" element
     */
    public void setProbableCauseQualifier(java.lang.String probableCauseQualifier)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROBABLECAUSEQUALIFIER$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROBABLECAUSEQUALIFIER$6);
            }
            target.setStringValue(probableCauseQualifier);
        }
    }
    
    /**
     * Sets (as xml) the "probableCauseQualifier" element
     */
    public void xsetProbableCauseQualifier(org.apache.xmlbeans.XmlString probableCauseQualifier)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PROBABLECAUSEQUALIFIER$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PROBABLECAUSEQUALIFIER$6);
            }
            target.set(probableCauseQualifier);
        }
    }
    
    /**
     * Unsets the "probableCauseQualifier" element
     */
    public void unsetProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROBABLECAUSEQUALIFIER$6, 0);
        }
    }
}
