/*
 * An XML document type.
 * Localname: performProtectionCommandException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/pc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.pc.v1.impl;
/**
 * A document containing one performProtectionCommandException(@http://www.tmforum.org/mtop/rtm/xsd/pc/v1) element.
 *
 * This is a complex type.
 */
public class PerformProtectionCommandExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument
{
    
    public PerformProtectionCommandExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERFORMPROTECTIONCOMMANDEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/pc/v1", "performProtectionCommandException");
    
    
    /**
     * Gets the "performProtectionCommandException" element
     */
    public org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException getPerformProtectionCommandException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException)get_store().find_element_user(PERFORMPROTECTIONCOMMANDEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "performProtectionCommandException" element
     */
    public void setPerformProtectionCommandException(org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException performProtectionCommandException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException)get_store().find_element_user(PERFORMPROTECTIONCOMMANDEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException)get_store().add_element_user(PERFORMPROTECTIONCOMMANDEXCEPTION$0);
            }
            target.set(performProtectionCommandException);
        }
    }
    
    /**
     * Appends and returns a new empty "performProtectionCommandException" element
     */
    public org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException addNewPerformProtectionCommandException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException)get_store().add_element_user(PERFORMPROTECTIONCOMMANDEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML performProtectionCommandException(@http://www.tmforum.org/mtop/rtm/xsd/pc/v1).
     *
     * This is a complex type.
     */
    public static class PerformProtectionCommandExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandExceptionDocument.PerformProtectionCommandException
    {
        
        public PerformProtectionCommandExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
