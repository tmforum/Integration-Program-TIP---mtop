/*
 * An XML document type.
 * Localname: modifyAlarmSeverityAssignmentProfileException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one modifyAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class ModifyAlarmSeverityAssignmentProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument
{
    
    public ModifyAlarmSeverityAssignmentProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MODIFYALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "modifyAlarmSeverityAssignmentProfileException");
    
    
    /**
     * Gets the "modifyAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException getModifyAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException)get_store().find_element_user(MODIFYALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "modifyAlarmSeverityAssignmentProfileException" element
     */
    public void setModifyAlarmSeverityAssignmentProfileException(org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException modifyAlarmSeverityAssignmentProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException)get_store().find_element_user(MODIFYALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException)get_store().add_element_user(MODIFYALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            }
            target.set(modifyAlarmSeverityAssignmentProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "modifyAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException addNewModifyAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException)get_store().add_element_user(MODIFYALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML modifyAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class ModifyAlarmSeverityAssignmentProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileExceptionDocument.ModifyAlarmSeverityAssignmentProfileException
    {
        
        public ModifyAlarmSeverityAssignmentProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
