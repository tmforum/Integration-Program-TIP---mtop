/*
 * An XML document type.
 * Localname: unacknowledgeAlarmsException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ah/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ah.v1.impl;
/**
 * A document containing one unacknowledgeAlarmsException(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1) element.
 *
 * This is a complex type.
 */
public class UnacknowledgeAlarmsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument
{
    
    public UnacknowledgeAlarmsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UNACKNOWLEDGEALARMSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "unacknowledgeAlarmsException");
    
    
    /**
     * Gets the "unacknowledgeAlarmsException" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException getUnacknowledgeAlarmsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException)get_store().find_element_user(UNACKNOWLEDGEALARMSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "unacknowledgeAlarmsException" element
     */
    public void setUnacknowledgeAlarmsException(org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException unacknowledgeAlarmsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException)get_store().find_element_user(UNACKNOWLEDGEALARMSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException)get_store().add_element_user(UNACKNOWLEDGEALARMSEXCEPTION$0);
            }
            target.set(unacknowledgeAlarmsException);
        }
    }
    
    /**
     * Appends and returns a new empty "unacknowledgeAlarmsException" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException addNewUnacknowledgeAlarmsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException)get_store().add_element_user(UNACKNOWLEDGEALARMSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML unacknowledgeAlarmsException(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1).
     *
     * This is a complex type.
     */
    public static class UnacknowledgeAlarmsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsExceptionDocument.UnacknowledgeAlarmsException
    {
        
        public UnacknowledgeAlarmsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
