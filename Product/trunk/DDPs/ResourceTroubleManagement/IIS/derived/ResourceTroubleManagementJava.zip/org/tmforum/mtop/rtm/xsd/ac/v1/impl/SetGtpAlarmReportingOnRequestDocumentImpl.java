/*
 * An XML document type.
 * Localname: setGtpAlarmReportingOnRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setGtpAlarmReportingOnRequest(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetGtpAlarmReportingOnRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument
{
    
    public SetGtpAlarmReportingOnRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETGTPALARMREPORTINGONREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setGtpAlarmReportingOnRequest");
    
    
    /**
     * Gets the "setGtpAlarmReportingOnRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest getSetGtpAlarmReportingOnRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest)get_store().find_element_user(SETGTPALARMREPORTINGONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setGtpAlarmReportingOnRequest" element
     */
    public void setSetGtpAlarmReportingOnRequest(org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest setGtpAlarmReportingOnRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest)get_store().find_element_user(SETGTPALARMREPORTINGONREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest)get_store().add_element_user(SETGTPALARMREPORTINGONREQUEST$0);
            }
            target.set(setGtpAlarmReportingOnRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setGtpAlarmReportingOnRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest addNewSetGtpAlarmReportingOnRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest)get_store().add_element_user(SETGTPALARMREPORTINGONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setGtpAlarmReportingOnRequest(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetGtpAlarmReportingOnRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnRequestDocument.SetGtpAlarmReportingOnRequest
    {
        
        public SetGtpAlarmReportingOnRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName GTPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "gtpName");
        
        
        /**
         * Gets the "gtpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getGtpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(GTPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "gtpName" element
         */
        public boolean isNilGtpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(GTPNAME$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "gtpName" element
         */
        public boolean isSetGtpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(GTPNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "gtpName" element
         */
        public void setGtpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType gtpName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(GTPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(GTPNAME$0);
                }
                target.set(gtpName);
            }
        }
        
        /**
         * Appends and returns a new empty "gtpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewGtpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(GTPNAME$0);
                return target;
            }
        }
        
        /**
         * Nils the "gtpName" element
         */
        public void setNilGtpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(GTPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(GTPNAME$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "gtpName" element
         */
        public void unsetGtpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(GTPNAME$0, 0);
            }
        }
    }
}
