/*
 * An XML document type.
 * Localname: getAllAlarmSeverityAssignmentProfileNamesWrtOsException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAlarmSeverityAssignmentProfileNamesWrtOsException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument
{
    
    public GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAlarmSeverityAssignmentProfileNamesWrtOsException");
    
    
    /**
     * Gets the "getAllAlarmSeverityAssignmentProfileNamesWrtOsException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException getGetAllAlarmSeverityAssignmentProfileNamesWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAlarmSeverityAssignmentProfileNamesWrtOsException" element
     */
    public void setGetAllAlarmSeverityAssignmentProfileNamesWrtOsException(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException getAllAlarmSeverityAssignmentProfileNamesWrtOsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSEXCEPTION$0);
            }
            target.set(getAllAlarmSeverityAssignmentProfileNamesWrtOsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAlarmSeverityAssignmentProfileNamesWrtOsException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException addNewGetAllAlarmSeverityAssignmentProfileNamesWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllAlarmSeverityAssignmentProfileNamesWrtOsException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsException
    {
        
        public GetAllAlarmSeverityAssignmentProfileNamesWrtOsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
