/*
 * An XML document type.
 * Localname: getAlarmSeverityAssignmentProfileIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAlarmSeverityAssignmentProfileIteratorRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAlarmSeverityAssignmentProfileIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument
{
    
    public GetAlarmSeverityAssignmentProfileIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALARMSEVERITYASSIGNMENTPROFILEITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAlarmSeverityAssignmentProfileIteratorRequest");
    
    
    /**
     * Gets the "getAlarmSeverityAssignmentProfileIteratorRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest getGetAlarmSeverityAssignmentProfileIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAlarmSeverityAssignmentProfileIteratorRequest" element
     */
    public void setGetAlarmSeverityAssignmentProfileIteratorRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest getAlarmSeverityAssignmentProfileIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEITERATORREQUEST$0);
            }
            target.set(getAlarmSeverityAssignmentProfileIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAlarmSeverityAssignmentProfileIteratorRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest addNewGetAlarmSeverityAssignmentProfileIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEITERATORREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAlarmSeverityAssignmentProfileIteratorRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAlarmSeverityAssignmentProfileIteratorRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorRequestDocument.GetAlarmSeverityAssignmentProfileIteratorRequest
    {
        
        public GetAlarmSeverityAssignmentProfileIteratorRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
