/*
 * XML Type:  MaintenanceOperationEnumType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/cmo/v1
 * Java type: org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.cmo.v1.impl;
/**
 * An XML MaintenanceOperationEnumType(@http://www.tmforum.org/mtop/nra/xsd/cmo/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType.
 */
public class MaintenanceOperationEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationEnumType
{
    
    public MaintenanceOperationEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected MaintenanceOperationEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
