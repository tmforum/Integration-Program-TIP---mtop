/*
 * XML Type:  SwitchDataType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/sd/v1
 * Java type: org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.sd.v1.impl;
/**
 * An XML SwitchDataType(@http://www.tmforum.org/mtop/nra/xsd/sd/v1).
 *
 * This is a complex type.
 */
public class SwitchDataTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType
{
    
    public SwitchDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROTECTIONTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/sd/v1", "protectionType");
    private static final javax.xml.namespace.QName SWITCHREASON$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/sd/v1", "switchReason");
    private static final javax.xml.namespace.QName LAYERRATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/sd/v1", "layerRate");
    private static final javax.xml.namespace.QName GROUPNAME$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/sd/v1", "groupName");
    private static final javax.xml.namespace.QName PROTECTEDTP$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/sd/v1", "protectedTp");
    private static final javax.xml.namespace.QName SWITCHTOTP$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/sd/v1", "switchToTp");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/sd/v1", "vendorExtensions");
    
    
    /**
     * Gets the "protectionType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType getProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().find_element_user(PROTECTIONTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionType" element
     */
    public boolean isNilProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().find_element_user(PROTECTIONTYPE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionType" element
     */
    public boolean isSetProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "protectionType" element
     */
    public void setProtectionType(org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType protectionType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().find_element_user(PROTECTIONTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().add_element_user(PROTECTIONTYPE$0);
            }
            target.set(protectionType);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType addNewProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().add_element_user(PROTECTIONTYPE$0);
            return target;
        }
    }
    
    /**
     * Nils the "protectionType" element
     */
    public void setNilProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().find_element_user(PROTECTIONTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType)get_store().add_element_user(PROTECTIONTYPE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionType" element
     */
    public void unsetProtectionType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "switchReason" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum getSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SWITCHREASON$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "switchReason" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType xgetSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().find_element_user(SWITCHREASON$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "switchReason" element
     */
    public boolean isNilSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().find_element_user(SWITCHREASON$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "switchReason" element
     */
    public boolean isSetSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHREASON$2) != 0;
        }
    }
    
    /**
     * Sets the "switchReason" element
     */
    public void setSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum switchReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SWITCHREASON$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SWITCHREASON$2);
            }
            target.setEnumValue(switchReason);
        }
    }
    
    /**
     * Sets (as xml) the "switchReason" element
     */
    public void xsetSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType switchReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().find_element_user(SWITCHREASON$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().add_element_user(SWITCHREASON$2);
            }
            target.set(switchReason);
        }
    }
    
    /**
     * Nils the "switchReason" element
     */
    public void setNilSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().find_element_user(SWITCHREASON$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType)get_store().add_element_user(SWITCHREASON$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "switchReason" element
     */
    public void unsetSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHREASON$2, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "layerRate" element
     */
    public boolean isNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$4) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$4);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$4);
            return target;
        }
    }
    
    /**
     * Nils the "layerRate" element
     */
    public void setNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$4, 0);
        }
    }
    
    /**
     * Gets the "groupName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getGroupName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(GROUPNAME$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "groupName" element
     */
    public boolean isNilGroupName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(GROUPNAME$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "groupName" element
     */
    public boolean isSetGroupName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GROUPNAME$6) != 0;
        }
    }
    
    /**
     * Sets the "groupName" element
     */
    public void setGroupName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType groupName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(GROUPNAME$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(GROUPNAME$6);
            }
            target.set(groupName);
        }
    }
    
    /**
     * Appends and returns a new empty "groupName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewGroupName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(GROUPNAME$6);
            return target;
        }
    }
    
    /**
     * Nils the "groupName" element
     */
    public void setNilGroupName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(GROUPNAME$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(GROUPNAME$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "groupName" element
     */
    public void unsetGroupName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GROUPNAME$6, 0);
        }
    }
    
    /**
     * Gets the "protectedTp" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getProtectedTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROTECTEDTP$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectedTp" element
     */
    public boolean isNilProtectedTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROTECTEDTP$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectedTp" element
     */
    public boolean isSetProtectedTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTEDTP$8) != 0;
        }
    }
    
    /**
     * Sets the "protectedTp" element
     */
    public void setProtectedTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType protectedTp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROTECTEDTP$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PROTECTEDTP$8);
            }
            target.set(protectedTp);
        }
    }
    
    /**
     * Appends and returns a new empty "protectedTp" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewProtectedTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PROTECTEDTP$8);
            return target;
        }
    }
    
    /**
     * Nils the "protectedTp" element
     */
    public void setNilProtectedTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROTECTEDTP$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PROTECTEDTP$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectedTp" element
     */
    public void unsetProtectedTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTEDTP$8, 0);
        }
    }
    
    /**
     * Gets the "switchToTp" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getSwitchToTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SWITCHTOTP$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "switchToTp" element
     */
    public boolean isNilSwitchToTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SWITCHTOTP$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "switchToTp" element
     */
    public boolean isSetSwitchToTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHTOTP$10) != 0;
        }
    }
    
    /**
     * Sets the "switchToTp" element
     */
    public void setSwitchToTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType switchToTp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SWITCHTOTP$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SWITCHTOTP$10);
            }
            target.set(switchToTp);
        }
    }
    
    /**
     * Appends and returns a new empty "switchToTp" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewSwitchToTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SWITCHTOTP$10);
            return target;
        }
    }
    
    /**
     * Nils the "switchToTp" element
     */
    public void setNilSwitchToTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SWITCHTOTP$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SWITCHTOTP$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "switchToTp" element
     */
    public void unsetSwitchToTp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHTOTP$10, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "vendorExtensions" element
     */
    public boolean isNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$12) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$12);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$12);
            return target;
        }
    }
    
    /**
     * Nils the "vendorExtensions" element
     */
    public void setNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$12, 0);
        }
    }
}
