/*
 * An XML document type.
 * Localname: performProtectionCommandResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/pc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.pc.v1.impl;
/**
 * A document containing one performProtectionCommandResponse(@http://www.tmforum.org/mtop/rtm/xsd/pc/v1) element.
 *
 * This is a complex type.
 */
public class PerformProtectionCommandResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument
{
    
    public PerformProtectionCommandResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERFORMPROTECTIONCOMMANDRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/pc/v1", "performProtectionCommandResponse");
    
    
    /**
     * Gets the "performProtectionCommandResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse getPerformProtectionCommandResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse)get_store().find_element_user(PERFORMPROTECTIONCOMMANDRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "performProtectionCommandResponse" element
     */
    public void setPerformProtectionCommandResponse(org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse performProtectionCommandResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse)get_store().find_element_user(PERFORMPROTECTIONCOMMANDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse)get_store().add_element_user(PERFORMPROTECTIONCOMMANDRESPONSE$0);
            }
            target.set(performProtectionCommandResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "performProtectionCommandResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse addNewPerformProtectionCommandResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse)get_store().add_element_user(PERFORMPROTECTIONCOMMANDRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML performProtectionCommandResponse(@http://www.tmforum.org/mtop/rtm/xsd/pc/v1).
     *
     * This is a complex type.
     */
    public static class PerformProtectionCommandResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandResponseDocument.PerformProtectionCommandResponse
    {
        
        public PerformProtectionCommandResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SWITCHDATA$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/pc/v1", "switchData");
        
        
        /**
         * Gets the "switchData" element
         */
        public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType getSwitchData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType target = null;
                target = (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType)get_store().find_element_user(SWITCHDATA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "switchData" element
         */
        public boolean isSetSwitchData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SWITCHDATA$0) != 0;
            }
        }
        
        /**
         * Sets the "switchData" element
         */
        public void setSwitchData(org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType switchData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType target = null;
                target = (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType)get_store().find_element_user(SWITCHDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType)get_store().add_element_user(SWITCHDATA$0);
                }
                target.set(switchData);
            }
        }
        
        /**
         * Appends and returns a new empty "switchData" element
         */
        public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType addNewSwitchData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType target = null;
                target = (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType)get_store().add_element_user(SWITCHDATA$0);
                return target;
            }
        }
        
        /**
         * Unsets the "switchData" element
         */
        public void unsetSwitchData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SWITCHDATA$0, 0);
            }
        }
    }
}
