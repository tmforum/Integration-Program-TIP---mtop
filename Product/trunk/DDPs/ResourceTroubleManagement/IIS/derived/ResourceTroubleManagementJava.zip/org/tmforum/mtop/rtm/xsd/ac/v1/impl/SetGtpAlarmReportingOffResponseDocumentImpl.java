/*
 * An XML document type.
 * Localname: setGtpAlarmReportingOffResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setGtpAlarmReportingOffResponse(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetGtpAlarmReportingOffResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument
{
    
    public SetGtpAlarmReportingOffResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETGTPALARMREPORTINGOFFRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setGtpAlarmReportingOffResponse");
    
    
    /**
     * Gets the "setGtpAlarmReportingOffResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse getSetGtpAlarmReportingOffResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse)get_store().find_element_user(SETGTPALARMREPORTINGOFFRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setGtpAlarmReportingOffResponse" element
     */
    public void setSetGtpAlarmReportingOffResponse(org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse setGtpAlarmReportingOffResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse)get_store().find_element_user(SETGTPALARMREPORTINGOFFRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse)get_store().add_element_user(SETGTPALARMREPORTINGOFFRESPONSE$0);
            }
            target.set(setGtpAlarmReportingOffResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setGtpAlarmReportingOffResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse addNewSetGtpAlarmReportingOffResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse)get_store().add_element_user(SETGTPALARMREPORTINGOFFRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setGtpAlarmReportingOffResponse(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetGtpAlarmReportingOffResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffResponseDocument.SetGtpAlarmReportingOffResponse
    {
        
        public SetGtpAlarmReportingOffResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
