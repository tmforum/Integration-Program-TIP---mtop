/*
 * An XML document type.
 * Localname: alarmOrTcaId
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/atcaid/v1
 * Java type: org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.atcaid.v1.impl;
/**
 * A document containing one alarmOrTcaId(@http://www.tmforum.org/mtop/nra/xsd/atcaid/v1) element.
 *
 * This is a complex type.
 */
public class AlarmOrTcaIdDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdDocument
{
    
    public AlarmOrTcaIdDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARMORTCAID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/atcaid/v1", "alarmOrTcaId");
    
    
    /**
     * Gets the "alarmOrTcaId" element
     */
    public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType getAlarmOrTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType)get_store().find_element_user(ALARMORTCAID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "alarmOrTcaId" element
     */
    public void setAlarmOrTcaId(org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType alarmOrTcaId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType)get_store().find_element_user(ALARMORTCAID$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType)get_store().add_element_user(ALARMORTCAID$0);
            }
            target.set(alarmOrTcaId);
        }
    }
    
    /**
     * Appends and returns a new empty "alarmOrTcaId" element
     */
    public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType addNewAlarmOrTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType)get_store().add_element_user(ALARMORTCAID$0);
            return target;
        }
    }
}
