/*
 * XML Type:  AlarmSeverityAssignmentListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/asa/v1
 * Java type: org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.asa.v1.impl;
/**
 * An XML AlarmSeverityAssignmentListType(@http://www.tmforum.org/mtop/nra/xsd/asa/v1).
 *
 * This is a complex type.
 */
public class AlarmSeverityAssignmentListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType
{
    
    public AlarmSeverityAssignmentListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARMSEVERITYASSIGNMENT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asa/v1", "alarmSeverityAssignment");
    
    
    /**
     * Gets a List of "alarmSeverityAssignment" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType> getAlarmSeverityAssignmentList()
    {
        final class AlarmSeverityAssignmentList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType>
        {
            public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType get(int i)
                { return AlarmSeverityAssignmentListTypeImpl.this.getAlarmSeverityAssignmentArray(i); }
            
            public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType set(int i, org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType o)
            {
                org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType old = AlarmSeverityAssignmentListTypeImpl.this.getAlarmSeverityAssignmentArray(i);
                AlarmSeverityAssignmentListTypeImpl.this.setAlarmSeverityAssignmentArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType o)
                { AlarmSeverityAssignmentListTypeImpl.this.insertNewAlarmSeverityAssignment(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType old = AlarmSeverityAssignmentListTypeImpl.this.getAlarmSeverityAssignmentArray(i);
                AlarmSeverityAssignmentListTypeImpl.this.removeAlarmSeverityAssignment(i);
                return old;
            }
            
            public int size()
                { return AlarmSeverityAssignmentListTypeImpl.this.sizeOfAlarmSeverityAssignmentArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new AlarmSeverityAssignmentList();
        }
    }
    
    /**
     * Gets array of all "alarmSeverityAssignment" elements
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType[] getAlarmSeverityAssignmentArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ALARMSEVERITYASSIGNMENT$0, targetList);
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType[] result = new org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "alarmSeverityAssignment" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType getAlarmSeverityAssignmentArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType)get_store().find_element_user(ALARMSEVERITYASSIGNMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "alarmSeverityAssignment" element
     */
    public int sizeOfAlarmSeverityAssignmentArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMSEVERITYASSIGNMENT$0);
        }
    }
    
    /**
     * Sets array of all "alarmSeverityAssignment" element
     */
    public void setAlarmSeverityAssignmentArray(org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType[] alarmSeverityAssignmentArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(alarmSeverityAssignmentArray, ALARMSEVERITYASSIGNMENT$0);
        }
    }
    
    /**
     * Sets ith "alarmSeverityAssignment" element
     */
    public void setAlarmSeverityAssignmentArray(int i, org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType alarmSeverityAssignment)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType)get_store().find_element_user(ALARMSEVERITYASSIGNMENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(alarmSeverityAssignment);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "alarmSeverityAssignment" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType insertNewAlarmSeverityAssignment(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType)get_store().insert_element_user(ALARMSEVERITYASSIGNMENT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "alarmSeverityAssignment" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType addNewAlarmSeverityAssignment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType)get_store().add_element_user(ALARMSEVERITYASSIGNMENT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "alarmSeverityAssignment" element
     */
    public void removeAlarmSeverityAssignment(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMSEVERITYASSIGNMENT$0, i);
        }
    }
}
