/*
 * An XML document type.
 * Localname: performMaintenanceOperationRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/mc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.mc.v1.impl;
/**
 * A document containing one performMaintenanceOperationRequest(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1) element.
 *
 * This is a complex type.
 */
public class PerformMaintenanceOperationRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument
{
    
    public PerformMaintenanceOperationRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERFORMMAINTENANCEOPERATIONREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "performMaintenanceOperationRequest");
    
    
    /**
     * Gets the "performMaintenanceOperationRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest getPerformMaintenanceOperationRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest)get_store().find_element_user(PERFORMMAINTENANCEOPERATIONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "performMaintenanceOperationRequest" element
     */
    public void setPerformMaintenanceOperationRequest(org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest performMaintenanceOperationRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest)get_store().find_element_user(PERFORMMAINTENANCEOPERATIONREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest)get_store().add_element_user(PERFORMMAINTENANCEOPERATIONREQUEST$0);
            }
            target.set(performMaintenanceOperationRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "performMaintenanceOperationRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest addNewPerformMaintenanceOperationRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest)get_store().add_element_user(PERFORMMAINTENANCEOPERATIONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML performMaintenanceOperationRequest(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1).
     *
     * This is a complex type.
     */
    public static class PerformMaintenanceOperationRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationRequestDocument.PerformMaintenanceOperationRequest
    {
        
        public PerformMaintenanceOperationRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MAINTENANCEOPERATION$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "maintenanceOperation");
        private static final javax.xml.namespace.QName MAINTENANCEOPERATIONMODE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "maintenanceOperationMode");
        
        
        /**
         * Gets the "maintenanceOperation" element
         */
        public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType getMaintenanceOperation()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().find_element_user(MAINTENANCEOPERATION$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "maintenanceOperation" element
         */
        public boolean isNilMaintenanceOperation()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().find_element_user(MAINTENANCEOPERATION$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "maintenanceOperation" element
         */
        public boolean isSetMaintenanceOperation()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MAINTENANCEOPERATION$0) != 0;
            }
        }
        
        /**
         * Sets the "maintenanceOperation" element
         */
        public void setMaintenanceOperation(org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType maintenanceOperation)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().find_element_user(MAINTENANCEOPERATION$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().add_element_user(MAINTENANCEOPERATION$0);
                }
                target.set(maintenanceOperation);
            }
        }
        
        /**
         * Appends and returns a new empty "maintenanceOperation" element
         */
        public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType addNewMaintenanceOperation()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().add_element_user(MAINTENANCEOPERATION$0);
                return target;
            }
        }
        
        /**
         * Nils the "maintenanceOperation" element
         */
        public void setNilMaintenanceOperation()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().find_element_user(MAINTENANCEOPERATION$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().add_element_user(MAINTENANCEOPERATION$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "maintenanceOperation" element
         */
        public void unsetMaintenanceOperation()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MAINTENANCEOPERATION$0, 0);
            }
        }
        
        /**
         * Gets the "maintenanceOperationMode" element
         */
        public org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType.Enum getMaintenanceOperationMode()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAINTENANCEOPERATIONMODE$2, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "maintenanceOperationMode" element
         */
        public org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType xgetMaintenanceOperationMode()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType)get_store().find_element_user(MAINTENANCEOPERATIONMODE$2, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "maintenanceOperationMode" element
         */
        public boolean isNilMaintenanceOperationMode()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType)get_store().find_element_user(MAINTENANCEOPERATIONMODE$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "maintenanceOperationMode" element
         */
        public boolean isSetMaintenanceOperationMode()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MAINTENANCEOPERATIONMODE$2) != 0;
            }
        }
        
        /**
         * Sets the "maintenanceOperationMode" element
         */
        public void setMaintenanceOperationMode(org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType.Enum maintenanceOperationMode)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAINTENANCEOPERATIONMODE$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MAINTENANCEOPERATIONMODE$2);
                }
                target.setEnumValue(maintenanceOperationMode);
            }
        }
        
        /**
         * Sets (as xml) the "maintenanceOperationMode" element
         */
        public void xsetMaintenanceOperationMode(org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType maintenanceOperationMode)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType)get_store().find_element_user(MAINTENANCEOPERATIONMODE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType)get_store().add_element_user(MAINTENANCEOPERATIONMODE$2);
                }
                target.set(maintenanceOperationMode);
            }
        }
        
        /**
         * Nils the "maintenanceOperationMode" element
         */
        public void setNilMaintenanceOperationMode()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType)get_store().find_element_user(MAINTENANCEOPERATIONMODE$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationModeEnumType)get_store().add_element_user(MAINTENANCEOPERATIONMODE$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "maintenanceOperationMode" element
         */
        public void unsetMaintenanceOperationMode()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MAINTENANCEOPERATIONMODE$2, 0);
            }
        }
    }
}
