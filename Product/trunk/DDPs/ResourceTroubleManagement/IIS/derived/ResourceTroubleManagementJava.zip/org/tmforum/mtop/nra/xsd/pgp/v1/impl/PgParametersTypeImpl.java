/*
 * XML Type:  PgParametersType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pgp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pgp.v1.impl;
/**
 * An XML PgParametersType(@http://www.tmforum.org/mtop/nra/xsd/pgp/v1).
 *
 * This is a complex type.
 */
public class PgParametersTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType
{
    
    public PgParametersTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SWITCHMODE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "switchMode");
    private static final javax.xml.namespace.QName SPRINGPROTOCOL$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "springProtocol");
    private static final javax.xml.namespace.QName SPRINGNODEID$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "springNodeId");
    private static final javax.xml.namespace.QName SWITCHPOSITION$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "switchPosition");
    private static final javax.xml.namespace.QName NONPREEMPTIBLETRAFFIC$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "nonPreEmptibleTraffic");
    private static final javax.xml.namespace.QName WTRTIME$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "wtrTime");
    private static final javax.xml.namespace.QName HOLDOFFTIME$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "holdOffTime");
    private static final javax.xml.namespace.QName LODNUMSWITCHES$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "lodNumSwitches");
    private static final javax.xml.namespace.QName LODDURATION$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "lodDuration");
    private static final javax.xml.namespace.QName TANDEMSWITCHING$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "tandemSwitching");
    private static final javax.xml.namespace.QName BUNDLESWITCHING$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "bundleSwitching");
    private static final javax.xml.namespace.QName HITLESS$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "hitless");
    private static final javax.xml.namespace.QName EXERCISEON$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "exerciseOn");
    private static final javax.xml.namespace.QName AVAILABILITYSTATUS$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "availabilityStatus");
    private static final javax.xml.namespace.QName SWITCHCRITERIAENABLE$28 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "switchCriteriaEnable");
    private static final javax.xml.namespace.QName PRIVILEGEDCHANNEL$30 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "privilegedChannel");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$32 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "vendorExtensions");
    
    
    /**
     * Gets the "switchMode" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType getSwitchMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType)get_store().find_element_user(SWITCHMODE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "switchMode" element
     */
    public boolean isSetSwitchMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHMODE$0) != 0;
        }
    }
    
    /**
     * Sets the "switchMode" element
     */
    public void setSwitchMode(org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType switchMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType)get_store().find_element_user(SWITCHMODE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType)get_store().add_element_user(SWITCHMODE$0);
            }
            target.set(switchMode);
        }
    }
    
    /**
     * Appends and returns a new empty "switchMode" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType addNewSwitchMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchModeType)get_store().add_element_user(SWITCHMODE$0);
            return target;
        }
    }
    
    /**
     * Unsets the "switchMode" element
     */
    public void unsetSwitchMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHMODE$0, 0);
        }
    }
    
    /**
     * Gets the "springProtocol" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType getSpringProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType)get_store().find_element_user(SPRINGPROTOCOL$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "springProtocol" element
     */
    public boolean isSetSpringProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SPRINGPROTOCOL$2) != 0;
        }
    }
    
    /**
     * Sets the "springProtocol" element
     */
    public void setSpringProtocol(org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType springProtocol)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType)get_store().find_element_user(SPRINGPROTOCOL$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType)get_store().add_element_user(SPRINGPROTOCOL$2);
            }
            target.set(springProtocol);
        }
    }
    
    /**
     * Appends and returns a new empty "springProtocol" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType addNewSpringProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SpringProtocolType)get_store().add_element_user(SPRINGPROTOCOL$2);
            return target;
        }
    }
    
    /**
     * Unsets the "springProtocol" element
     */
    public void unsetSpringProtocol()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SPRINGPROTOCOL$2, 0);
        }
    }
    
    /**
     * Gets the "springNodeId" element
     */
    public java.lang.String getSpringNodeId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SPRINGNODEID$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "springNodeId" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType xgetSpringNodeId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType)get_store().find_element_user(SPRINGNODEID$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "springNodeId" element
     */
    public boolean isSetSpringNodeId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SPRINGNODEID$4) != 0;
        }
    }
    
    /**
     * Sets the "springNodeId" element
     */
    public void setSpringNodeId(java.lang.String springNodeId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SPRINGNODEID$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SPRINGNODEID$4);
            }
            target.setStringValue(springNodeId);
        }
    }
    
    /**
     * Sets (as xml) the "springNodeId" element
     */
    public void xsetSpringNodeId(org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType springNodeId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType)get_store().find_element_user(SPRINGNODEID$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.SpringNodeIdType)get_store().add_element_user(SPRINGNODEID$4);
            }
            target.set(springNodeId);
        }
    }
    
    /**
     * Unsets the "springNodeId" element
     */
    public void unsetSpringNodeId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SPRINGNODEID$4, 0);
        }
    }
    
    /**
     * Gets the "switchPosition" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType.Enum getSwitchPosition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SWITCHPOSITION$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "switchPosition" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType xgetSwitchPosition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType)get_store().find_element_user(SWITCHPOSITION$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "switchPosition" element
     */
    public boolean isSetSwitchPosition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHPOSITION$6) != 0;
        }
    }
    
    /**
     * Sets the "switchPosition" element
     */
    public void setSwitchPosition(org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType.Enum switchPosition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SWITCHPOSITION$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SWITCHPOSITION$6);
            }
            target.setEnumValue(switchPosition);
        }
    }
    
    /**
     * Sets (as xml) the "switchPosition" element
     */
    public void xsetSwitchPosition(org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType switchPosition)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType)get_store().find_element_user(SWITCHPOSITION$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchPositionType)get_store().add_element_user(SWITCHPOSITION$6);
            }
            target.set(switchPosition);
        }
    }
    
    /**
     * Unsets the "switchPosition" element
     */
    public void unsetSwitchPosition()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHPOSITION$6, 0);
        }
    }
    
    /**
     * Gets the "nonPreEmptibleTraffic" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType.Enum getNonPreEmptibleTraffic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NONPREEMPTIBLETRAFFIC$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "nonPreEmptibleTraffic" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType xgetNonPreEmptibleTraffic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType)get_store().find_element_user(NONPREEMPTIBLETRAFFIC$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "nonPreEmptibleTraffic" element
     */
    public boolean isSetNonPreEmptibleTraffic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NONPREEMPTIBLETRAFFIC$8) != 0;
        }
    }
    
    /**
     * Sets the "nonPreEmptibleTraffic" element
     */
    public void setNonPreEmptibleTraffic(org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType.Enum nonPreEmptibleTraffic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NONPREEMPTIBLETRAFFIC$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NONPREEMPTIBLETRAFFIC$8);
            }
            target.setEnumValue(nonPreEmptibleTraffic);
        }
    }
    
    /**
     * Sets (as xml) the "nonPreEmptibleTraffic" element
     */
    public void xsetNonPreEmptibleTraffic(org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType nonPreEmptibleTraffic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType)get_store().find_element_user(NONPREEMPTIBLETRAFFIC$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.NonPreEmptibleTrafficType)get_store().add_element_user(NONPREEMPTIBLETRAFFIC$8);
            }
            target.set(nonPreEmptibleTraffic);
        }
    }
    
    /**
     * Unsets the "nonPreEmptibleTraffic" element
     */
    public void unsetNonPreEmptibleTraffic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NONPREEMPTIBLETRAFFIC$8, 0);
        }
    }
    
    /**
     * Gets the "wtrTime" element
     */
    public java.math.BigInteger getWtrTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(WTRTIME$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigIntegerValue();
        }
    }
    
    /**
     * Gets (as xml) the "wtrTime" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType xgetWtrTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType)get_store().find_element_user(WTRTIME$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "wtrTime" element
     */
    public boolean isSetWtrTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(WTRTIME$10) != 0;
        }
    }
    
    /**
     * Sets the "wtrTime" element
     */
    public void setWtrTime(java.math.BigInteger wtrTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(WTRTIME$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(WTRTIME$10);
            }
            target.setBigIntegerValue(wtrTime);
        }
    }
    
    /**
     * Sets (as xml) the "wtrTime" element
     */
    public void xsetWtrTime(org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType wtrTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType)get_store().find_element_user(WTRTIME$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType)get_store().add_element_user(WTRTIME$10);
            }
            target.set(wtrTime);
        }
    }
    
    /**
     * Unsets the "wtrTime" element
     */
    public void unsetWtrTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(WTRTIME$10, 0);
        }
    }
    
    /**
     * Gets the "holdOffTime" element
     */
    public java.lang.Object getHoldOffTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HOLDOFFTIME$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getObjectValue();
        }
    }
    
    /**
     * Gets (as xml) the "holdOffTime" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType xgetHoldOffTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType)get_store().find_element_user(HOLDOFFTIME$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "holdOffTime" element
     */
    public boolean isSetHoldOffTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(HOLDOFFTIME$12) != 0;
        }
    }
    
    /**
     * Sets the "holdOffTime" element
     */
    public void setHoldOffTime(java.lang.Object holdOffTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HOLDOFFTIME$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(HOLDOFFTIME$12);
            }
            target.setObjectValue(holdOffTime);
        }
    }
    
    /**
     * Sets (as xml) the "holdOffTime" element
     */
    public void xsetHoldOffTime(org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType holdOffTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType)get_store().find_element_user(HOLDOFFTIME$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.HoldOffTimeType)get_store().add_element_user(HOLDOFFTIME$12);
            }
            target.set(holdOffTime);
        }
    }
    
    /**
     * Unsets the "holdOffTime" element
     */
    public void unsetHoldOffTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(HOLDOFFTIME$12, 0);
        }
    }
    
    /**
     * Gets the "lodNumSwitches" element
     */
    public long getLodNumSwitches()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LODNUMSWITCHES$14, 0);
            if (target == null)
            {
                return 0L;
            }
            return target.getLongValue();
        }
    }
    
    /**
     * Gets (as xml) the "lodNumSwitches" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType xgetLodNumSwitches()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType)get_store().find_element_user(LODNUMSWITCHES$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "lodNumSwitches" element
     */
    public boolean isSetLodNumSwitches()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LODNUMSWITCHES$14) != 0;
        }
    }
    
    /**
     * Sets the "lodNumSwitches" element
     */
    public void setLodNumSwitches(long lodNumSwitches)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LODNUMSWITCHES$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LODNUMSWITCHES$14);
            }
            target.setLongValue(lodNumSwitches);
        }
    }
    
    /**
     * Sets (as xml) the "lodNumSwitches" element
     */
    public void xsetLodNumSwitches(org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType lodNumSwitches)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType)get_store().find_element_user(LODNUMSWITCHES$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType)get_store().add_element_user(LODNUMSWITCHES$14);
            }
            target.set(lodNumSwitches);
        }
    }
    
    /**
     * Unsets the "lodNumSwitches" element
     */
    public void unsetLodNumSwitches()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LODNUMSWITCHES$14, 0);
        }
    }
    
    /**
     * Gets the "lodDuration" element
     */
    public java.math.BigInteger getLodDuration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LODDURATION$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigIntegerValue();
        }
    }
    
    /**
     * Gets (as xml) the "lodDuration" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType xgetLodDuration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType)get_store().find_element_user(LODDURATION$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "lodDuration" element
     */
    public boolean isSetLodDuration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LODDURATION$16) != 0;
        }
    }
    
    /**
     * Sets the "lodDuration" element
     */
    public void setLodDuration(java.math.BigInteger lodDuration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LODDURATION$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LODDURATION$16);
            }
            target.setBigIntegerValue(lodDuration);
        }
    }
    
    /**
     * Sets (as xml) the "lodDuration" element
     */
    public void xsetLodDuration(org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType lodDuration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType)get_store().find_element_user(LODDURATION$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.LodDurationType)get_store().add_element_user(LODDURATION$16);
            }
            target.set(lodDuration);
        }
    }
    
    /**
     * Unsets the "lodDuration" element
     */
    public void unsetLodDuration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LODDURATION$16, 0);
        }
    }
    
    /**
     * Gets the "tandemSwitching" element
     */
    public java.lang.String getTandemSwitching()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TANDEMSWITCHING$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "tandemSwitching" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType xgetTandemSwitching()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType)get_store().find_element_user(TANDEMSWITCHING$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "tandemSwitching" element
     */
    public boolean isSetTandemSwitching()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TANDEMSWITCHING$18) != 0;
        }
    }
    
    /**
     * Sets the "tandemSwitching" element
     */
    public void setTandemSwitching(java.lang.String tandemSwitching)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TANDEMSWITCHING$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TANDEMSWITCHING$18);
            }
            target.setStringValue(tandemSwitching);
        }
    }
    
    /**
     * Sets (as xml) the "tandemSwitching" element
     */
    public void xsetTandemSwitching(org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType tandemSwitching)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType)get_store().find_element_user(TANDEMSWITCHING$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.TandemSwitchingType)get_store().add_element_user(TANDEMSWITCHING$18);
            }
            target.set(tandemSwitching);
        }
    }
    
    /**
     * Unsets the "tandemSwitching" element
     */
    public void unsetTandemSwitching()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TANDEMSWITCHING$18, 0);
        }
    }
    
    /**
     * Gets the "bundleSwitching" element
     */
    public java.lang.String getBundleSwitching()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BUNDLESWITCHING$20, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "bundleSwitching" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType xgetBundleSwitching()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType)get_store().find_element_user(BUNDLESWITCHING$20, 0);
            return target;
        }
    }
    
    /**
     * True if has "bundleSwitching" element
     */
    public boolean isSetBundleSwitching()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(BUNDLESWITCHING$20) != 0;
        }
    }
    
    /**
     * Sets the "bundleSwitching" element
     */
    public void setBundleSwitching(java.lang.String bundleSwitching)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(BUNDLESWITCHING$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(BUNDLESWITCHING$20);
            }
            target.setStringValue(bundleSwitching);
        }
    }
    
    /**
     * Sets (as xml) the "bundleSwitching" element
     */
    public void xsetBundleSwitching(org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType bundleSwitching)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType)get_store().find_element_user(BUNDLESWITCHING$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.BundleSwitchingType)get_store().add_element_user(BUNDLESWITCHING$20);
            }
            target.set(bundleSwitching);
        }
    }
    
    /**
     * Unsets the "bundleSwitching" element
     */
    public void unsetBundleSwitching()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(BUNDLESWITCHING$20, 0);
        }
    }
    
    /**
     * Gets the "hitless" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType.Enum getHitless()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HITLESS$22, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "hitless" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType xgetHitless()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType)get_store().find_element_user(HITLESS$22, 0);
            return target;
        }
    }
    
    /**
     * True if has "hitless" element
     */
    public boolean isSetHitless()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(HITLESS$22) != 0;
        }
    }
    
    /**
     * Sets the "hitless" element
     */
    public void setHitless(org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType.Enum hitless)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(HITLESS$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(HITLESS$22);
            }
            target.setEnumValue(hitless);
        }
    }
    
    /**
     * Sets (as xml) the "hitless" element
     */
    public void xsetHitless(org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType hitless)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType)get_store().find_element_user(HITLESS$22, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.HitlessType)get_store().add_element_user(HITLESS$22);
            }
            target.set(hitless);
        }
    }
    
    /**
     * Unsets the "hitless" element
     */
    public void unsetHitless()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(HITLESS$22, 0);
        }
    }
    
    /**
     * Gets the "exerciseOn" element
     */
    public boolean getExerciseOn()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXERCISEON$24, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "exerciseOn" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType xgetExerciseOn()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType)get_store().find_element_user(EXERCISEON$24, 0);
            return target;
        }
    }
    
    /**
     * True if has "exerciseOn" element
     */
    public boolean isSetExerciseOn()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXERCISEON$24) != 0;
        }
    }
    
    /**
     * Sets the "exerciseOn" element
     */
    public void setExerciseOn(boolean exerciseOn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXERCISEON$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXERCISEON$24);
            }
            target.setBooleanValue(exerciseOn);
        }
    }
    
    /**
     * Sets (as xml) the "exerciseOn" element
     */
    public void xsetExerciseOn(org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType exerciseOn)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType)get_store().find_element_user(EXERCISEON$24, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.ExerciseOnType)get_store().add_element_user(EXERCISEON$24);
            }
            target.set(exerciseOn);
        }
    }
    
    /**
     * Unsets the "exerciseOn" element
     */
    public void unsetExerciseOn()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXERCISEON$24, 0);
        }
    }
    
    /**
     * Gets the "availabilityStatus" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType getAvailabilityStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType)get_store().find_element_user(AVAILABILITYSTATUS$26, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "availabilityStatus" element
     */
    public boolean isSetAvailabilityStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AVAILABILITYSTATUS$26) != 0;
        }
    }
    
    /**
     * Sets the "availabilityStatus" element
     */
    public void setAvailabilityStatus(org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType availabilityStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType)get_store().find_element_user(AVAILABILITYSTATUS$26, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType)get_store().add_element_user(AVAILABILITYSTATUS$26);
            }
            target.set(availabilityStatus);
        }
    }
    
    /**
     * Appends and returns a new empty "availabilityStatus" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType addNewAvailabilityStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.AvailabilityStatusType)get_store().add_element_user(AVAILABILITYSTATUS$26);
            return target;
        }
    }
    
    /**
     * Unsets the "availabilityStatus" element
     */
    public void unsetAvailabilityStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AVAILABILITYSTATUS$26, 0);
        }
    }
    
    /**
     * Gets the "switchCriteriaEnable" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType getSwitchCriteriaEnable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType)get_store().find_element_user(SWITCHCRITERIAENABLE$28, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "switchCriteriaEnable" element
     */
    public boolean isSetSwitchCriteriaEnable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHCRITERIAENABLE$28) != 0;
        }
    }
    
    /**
     * Sets the "switchCriteriaEnable" element
     */
    public void setSwitchCriteriaEnable(org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType switchCriteriaEnable)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType)get_store().find_element_user(SWITCHCRITERIAENABLE$28, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType)get_store().add_element_user(SWITCHCRITERIAENABLE$28);
            }
            target.set(switchCriteriaEnable);
        }
    }
    
    /**
     * Appends and returns a new empty "switchCriteriaEnable" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType addNewSwitchCriteriaEnable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.SwitchCriteriaEnableType)get_store().add_element_user(SWITCHCRITERIAENABLE$28);
            return target;
        }
    }
    
    /**
     * Unsets the "switchCriteriaEnable" element
     */
    public void unsetSwitchCriteriaEnable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHCRITERIAENABLE$28, 0);
        }
    }
    
    /**
     * Gets the "privilegedChannel" element
     */
    public java.lang.String getPrivilegedChannel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIVILEGEDCHANNEL$30, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "privilegedChannel" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType xgetPrivilegedChannel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType)get_store().find_element_user(PRIVILEGEDCHANNEL$30, 0);
            return target;
        }
    }
    
    /**
     * True if has "privilegedChannel" element
     */
    public boolean isSetPrivilegedChannel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRIVILEGEDCHANNEL$30) != 0;
        }
    }
    
    /**
     * Sets the "privilegedChannel" element
     */
    public void setPrivilegedChannel(java.lang.String privilegedChannel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIVILEGEDCHANNEL$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRIVILEGEDCHANNEL$30);
            }
            target.setStringValue(privilegedChannel);
        }
    }
    
    /**
     * Sets (as xml) the "privilegedChannel" element
     */
    public void xsetPrivilegedChannel(org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType privilegedChannel)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType)get_store().find_element_user(PRIVILEGEDCHANNEL$30, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType)get_store().add_element_user(PRIVILEGEDCHANNEL$30);
            }
            target.set(privilegedChannel);
        }
    }
    
    /**
     * Unsets the "privilegedChannel" element
     */
    public void unsetPrivilegedChannel()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRIVILEGEDCHANNEL$30, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$32) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$32, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$32);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$32);
            return target;
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$32, 0);
        }
    }
}
