/*
 * An XML document type.
 * Localname: acknowledgeAlarmsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ah/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ah.v1;


/**
 * A document containing one acknowledgeAlarmsRequest(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1) element.
 *
 * This is a complex type.
 */
public interface AcknowledgeAlarmsRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AcknowledgeAlarmsRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD7F14712642FA7BC89FBCB45763AB9FB").resolveHandle("acknowledgealarmsrequest1196doctype");
    
    /**
     * Gets the "acknowledgeAlarmsRequest" element
     */
    org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest getAcknowledgeAlarmsRequest();
    
    /**
     * Sets the "acknowledgeAlarmsRequest" element
     */
    void setAcknowledgeAlarmsRequest(org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest acknowledgeAlarmsRequest);
    
    /**
     * Appends and returns a new empty "acknowledgeAlarmsRequest" element
     */
    org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest addNewAcknowledgeAlarmsRequest();
    
    /**
     * An XML acknowledgeAlarmsRequest(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1).
     *
     * This is a complex type.
     */
    public interface AcknowledgeAlarmsRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AcknowledgeAlarmsRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD7F14712642FA7BC89FBCB45763AB9FB").resolveHandle("acknowledgealarmsrequest0a69elemtype");
        
        /**
         * Gets the "acknowledgeIdList" element
         */
        org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType getAcknowledgeIdList();
        
        /**
         * Tests for nil "acknowledgeIdList" element
         */
        boolean isNilAcknowledgeIdList();
        
        /**
         * True if has "acknowledgeIdList" element
         */
        boolean isSetAcknowledgeIdList();
        
        /**
         * Sets the "acknowledgeIdList" element
         */
        void setAcknowledgeIdList(org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType acknowledgeIdList);
        
        /**
         * Appends and returns a new empty "acknowledgeIdList" element
         */
        org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType addNewAcknowledgeIdList();
        
        /**
         * Nils the "acknowledgeIdList" element
         */
        void setNilAcknowledgeIdList();
        
        /**
         * Unsets the "acknowledgeIdList" element
         */
        void unsetAcknowledgeIdList();
        
        /**
         * Gets the "username" element
         */
        java.lang.String getUsername();
        
        /**
         * Gets (as xml) the "username" element
         */
        org.apache.xmlbeans.XmlString xgetUsername();
        
        /**
         * Tests for nil "username" element
         */
        boolean isNilUsername();
        
        /**
         * True if has "username" element
         */
        boolean isSetUsername();
        
        /**
         * Sets the "username" element
         */
        void setUsername(java.lang.String username);
        
        /**
         * Sets (as xml) the "username" element
         */
        void xsetUsername(org.apache.xmlbeans.XmlString username);
        
        /**
         * Nils the "username" element
         */
        void setNilUsername();
        
        /**
         * Unsets the "username" element
         */
        void unsetUsername();
        
        /**
         * Gets the "notepad" element
         */
        java.lang.String getNotepad();
        
        /**
         * Gets (as xml) the "notepad" element
         */
        org.apache.xmlbeans.XmlString xgetNotepad();
        
        /**
         * Tests for nil "notepad" element
         */
        boolean isNilNotepad();
        
        /**
         * True if has "notepad" element
         */
        boolean isSetNotepad();
        
        /**
         * Sets the "notepad" element
         */
        void setNotepad(java.lang.String notepad);
        
        /**
         * Sets (as xml) the "notepad" element
         */
        void xsetNotepad(org.apache.xmlbeans.XmlString notepad);
        
        /**
         * Nils the "notepad" element
         */
        void setNilNotepad();
        
        /**
         * Unsets the "notepad" element
         */
        void unsetNotepad();
        
        /**
         * Gets the "vendorExtensions" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        boolean isNilVendorExtensions();
        
        /**
         * True if has "vendorExtensions" element
         */
        boolean isSetVendorExtensions();
        
        /**
         * Sets the "vendorExtensions" element
         */
        void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
        
        /**
         * Nils the "vendorExtensions" element
         */
        void setNilVendorExtensions();
        
        /**
         * Unsets the "vendorExtensions" element
         */
        void unsetVendorExtensions();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest newInstance() {
              return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument newInstance() {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
