/*
 * An XML document type.
 * Localname: commonObjectModifyData
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/comd/v1
 * Java type: org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.comd.v1.impl;
/**
 * A document containing one commonObjectModifyData(@http://www.tmforum.org/mtop/fmw/xsd/comd/v1) element.
 *
 * This is a complex type.
 */
public class CommonObjectModifyDataDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataDocument
{
    
    public CommonObjectModifyDataDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONOBJECTMODIFYDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/comd/v1", "commonObjectModifyData");
    
    
    /**
     * Gets the "commonObjectModifyData" element
     */
    public org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType getCommonObjectModifyData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType)get_store().find_element_user(COMMONOBJECTMODIFYDATA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonObjectModifyData" element
     */
    public void setCommonObjectModifyData(org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType commonObjectModifyData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType)get_store().find_element_user(COMMONOBJECTMODIFYDATA$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType)get_store().add_element_user(COMMONOBJECTMODIFYDATA$0);
            }
            target.set(commonObjectModifyData);
        }
    }
    
    /**
     * Appends and returns a new empty "commonObjectModifyData" element
     */
    public org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType addNewCommonObjectModifyData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType target = null;
            target = (org.tmforum.mtop.fmw.xsd.comd.v1.CommonObjectModifyDataType)get_store().add_element_user(COMMONOBJECTMODIFYDATA$0);
            return target;
        }
    }
}
