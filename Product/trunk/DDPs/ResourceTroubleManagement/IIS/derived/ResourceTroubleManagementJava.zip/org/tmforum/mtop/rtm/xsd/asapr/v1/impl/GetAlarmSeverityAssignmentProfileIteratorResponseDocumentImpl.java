/*
 * An XML document type.
 * Localname: getAlarmSeverityAssignmentProfileIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAlarmSeverityAssignmentProfileIteratorResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAlarmSeverityAssignmentProfileIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument
{
    
    public GetAlarmSeverityAssignmentProfileIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALARMSEVERITYASSIGNMENTPROFILEITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAlarmSeverityAssignmentProfileIteratorResponse");
    
    
    /**
     * Gets the "getAlarmSeverityAssignmentProfileIteratorResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse getGetAlarmSeverityAssignmentProfileIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAlarmSeverityAssignmentProfileIteratorResponse" element
     */
    public void setGetAlarmSeverityAssignmentProfileIteratorResponse(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse getAlarmSeverityAssignmentProfileIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEITERATORRESPONSE$0);
            }
            target.set(getAlarmSeverityAssignmentProfileIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAlarmSeverityAssignmentProfileIteratorResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse addNewGetAlarmSeverityAssignmentProfileIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEITERATORRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAlarmSeverityAssignmentProfileIteratorResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAlarmSeverityAssignmentProfileIteratorResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileIteratorResponseDocument.GetAlarmSeverityAssignmentProfileIteratorResponse
    {
        
        public GetAlarmSeverityAssignmentProfileIteratorResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "asapList");
        
        
        /**
         * Gets the "asapList" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType getAsapList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType)get_store().find_element_user(ASAPLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "asapList" element
         */
        public boolean isSetAsapList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "asapList" element
         */
        public void setAsapList(org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType asapList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType)get_store().find_element_user(ASAPLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType)get_store().add_element_user(ASAPLIST$0);
                }
                target.set(asapList);
            }
        }
        
        /**
         * Appends and returns a new empty "asapList" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType addNewAsapList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType)get_store().add_element_user(ASAPLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "asapList" element
         */
        public void unsetAsapList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPLIST$0, 0);
            }
        }
    }
}
