/*
 * An XML document type.
 * Localname: getAllAsapNamesWrtOsResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAsapNamesWrtOsResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAsapNamesWrtOsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument
{
    
    public GetAllAsapNamesWrtOsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLASAPNAMESWRTOSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAsapNamesWrtOsResponse");
    
    
    /**
     * Gets the "getAllAsapNamesWrtOsResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse getGetAllAsapNamesWrtOsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse)get_store().find_element_user(GETALLASAPNAMESWRTOSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAsapNamesWrtOsResponse" element
     */
    public void setGetAllAsapNamesWrtOsResponse(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse getAllAsapNamesWrtOsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse)get_store().find_element_user(GETALLASAPNAMESWRTOSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse)get_store().add_element_user(GETALLASAPNAMESWRTOSRESPONSE$0);
            }
            target.set(getAllAsapNamesWrtOsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAsapNamesWrtOsResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse addNewGetAllAsapNamesWrtOsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse)get_store().add_element_user(GETALLASAPNAMESWRTOSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAllAsapNamesWrtOsResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAsapNamesWrtOsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsResponseDocument.GetAllAsapNamesWrtOsResponse
    {
        
        public GetAllAsapNamesWrtOsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NAMELIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "nameList");
        
        
        /**
         * Gets a List of "nameList" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType> getNameListList()
        {
            final class NameListList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType>
            {
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType get(int i)
                    { return GetAllAsapNamesWrtOsResponseImpl.this.getNameListArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType o)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType old = GetAllAsapNamesWrtOsResponseImpl.this.getNameListArray(i);
                    GetAllAsapNamesWrtOsResponseImpl.this.setNameListArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType o)
                    { GetAllAsapNamesWrtOsResponseImpl.this.insertNewNameList(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType old = GetAllAsapNamesWrtOsResponseImpl.this.getNameListArray(i);
                    GetAllAsapNamesWrtOsResponseImpl.this.removeNameList(i);
                    return old;
                }
                
                public int size()
                    { return GetAllAsapNamesWrtOsResponseImpl.this.sizeOfNameListArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new NameListList();
            }
        }
        
        /**
         * Gets array of all "nameList" elements
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType[] getNameListArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(NAMELIST$0, targetList);
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "nameList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getNameListArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NAMELIST$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "nameList" element
         */
        public int sizeOfNameListArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NAMELIST$0);
            }
        }
        
        /**
         * Sets array of all "nameList" element
         */
        public void setNameListArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType[] nameListArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(nameListArray, NAMELIST$0);
            }
        }
        
        /**
         * Sets ith "nameList" element
         */
        public void setNameListArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType nameList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(NAMELIST$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(nameList);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "nameList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType insertNewNameList(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().insert_element_user(NAMELIST$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "nameList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(NAMELIST$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "nameList" element
         */
        public void removeNameList(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NAMELIST$0, i);
            }
        }
    }
}
