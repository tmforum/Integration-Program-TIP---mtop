/*
 * An XML document type.
 * Localname: pmParameterName
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pm/v1
 * Java type: org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pm.v1.impl;
/**
 * A document containing one pmParameterName(@http://www.tmforum.org/mtop/nra/xsd/pm/v1) element.
 *
 * This is a complex type.
 */
public class PmParameterNameDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameDocument
{
    
    public PmParameterNameDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMPARAMETERNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pm/v1", "pmParameterName");
    
    
    /**
     * Gets the "pmParameterName" element
     */
    public java.lang.String getPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "pmParameterName" element
     */
    public void setPmParameterName(java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    public void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$0);
            }
            target.set(pmParameterName);
        }
    }
}
