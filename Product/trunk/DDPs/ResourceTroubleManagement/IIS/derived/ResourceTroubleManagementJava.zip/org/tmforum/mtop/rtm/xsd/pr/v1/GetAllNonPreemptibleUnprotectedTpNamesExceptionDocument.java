/*
 * An XML document type.
 * Localname: getAllNonPreemptibleUnprotectedTpNamesException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/pr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.pr.v1;


/**
 * A document containing one getAllNonPreemptibleUnprotectedTpNamesException(@http://www.tmforum.org/mtop/rtm/xsd/pr/v1) element.
 *
 * This is a complex type.
 */
public interface GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2C8DED09A1FFD775DAAB49672DE07087").resolveHandle("getallnonpreemptibleunprotectedtpnamesexception7711doctype");
    
    /**
     * Gets the "getAllNonPreemptibleUnprotectedTpNamesException" element
     */
    org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument.GetAllNonPreemptibleUnprotectedTpNamesException getGetAllNonPreemptibleUnprotectedTpNamesException();
    
    /**
     * Sets the "getAllNonPreemptibleUnprotectedTpNamesException" element
     */
    void setGetAllNonPreemptibleUnprotectedTpNamesException(org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument.GetAllNonPreemptibleUnprotectedTpNamesException getAllNonPreemptibleUnprotectedTpNamesException);
    
    /**
     * Appends and returns a new empty "getAllNonPreemptibleUnprotectedTpNamesException" element
     */
    org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument.GetAllNonPreemptibleUnprotectedTpNamesException addNewGetAllNonPreemptibleUnprotectedTpNamesException();
    
    /**
     * An XML getAllNonPreemptibleUnprotectedTpNamesException(@http://www.tmforum.org/mtop/rtm/xsd/pr/v1).
     *
     * This is a complex type.
     */
    public interface GetAllNonPreemptibleUnprotectedTpNamesException extends org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetAllNonPreemptibleUnprotectedTpNamesException.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2C8DED09A1FFD775DAAB49672DE07087").resolveHandle("getallnonpreemptibleunprotectedtpnamesexceptionb076elemtype");
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument.GetAllNonPreemptibleUnprotectedTpNamesException newInstance() {
              return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument.GetAllNonPreemptibleUnprotectedTpNamesException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument.GetAllNonPreemptibleUnprotectedTpNamesException newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument.GetAllNonPreemptibleUnprotectedTpNamesException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument newInstance() {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllNonPreemptibleUnprotectedTpNamesExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
