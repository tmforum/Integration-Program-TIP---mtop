/*
 * An XML document type.
 * Localname: alarmId
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alarmid/v1
 * Java type: org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alarmid.v1.impl;
/**
 * A document containing one alarmId(@http://www.tmforum.org/mtop/nra/xsd/alarmid/v1) element.
 *
 * This is a complex type.
 */
public class AlarmIdDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdDocument
{
    
    public AlarmIdDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARMID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alarmid/v1", "alarmId");
    
    
    /**
     * Gets the "alarmId" element
     */
    public org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType getAlarmId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType)get_store().find_element_user(ALARMID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "alarmId" element
     */
    public void setAlarmId(org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType alarmId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType)get_store().find_element_user(ALARMID$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType)get_store().add_element_user(ALARMID$0);
            }
            target.set(alarmId);
        }
    }
    
    /**
     * Appends and returns a new empty "alarmId" element
     */
    public org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType addNewAlarmId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType)get_store().add_element_user(ALARMID$0);
            return target;
        }
    }
}
