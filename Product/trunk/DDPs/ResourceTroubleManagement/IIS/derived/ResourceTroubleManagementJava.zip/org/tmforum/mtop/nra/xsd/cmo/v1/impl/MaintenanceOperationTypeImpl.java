/*
 * XML Type:  MaintenanceOperationType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/cmo/v1
 * Java type: org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.cmo.v1.impl;
/**
 * An XML MaintenanceOperationType(@http://www.tmforum.org/mtop/nra/xsd/cmo/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType.
 */
public class MaintenanceOperationTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType
{
    
    public MaintenanceOperationTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected MaintenanceOperationTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
