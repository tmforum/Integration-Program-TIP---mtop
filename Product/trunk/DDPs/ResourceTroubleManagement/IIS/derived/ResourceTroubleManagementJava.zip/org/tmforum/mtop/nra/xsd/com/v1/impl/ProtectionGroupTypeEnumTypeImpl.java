/*
 * XML Type:  ProtectionGroupTypeEnumType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1.impl;
/**
 * An XML ProtectionGroupTypeEnumType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeEnumType.
 */
public class ProtectionGroupTypeEnumTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeEnumType
{
    
    public ProtectionGroupTypeEnumTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ProtectionGroupTypeEnumTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
