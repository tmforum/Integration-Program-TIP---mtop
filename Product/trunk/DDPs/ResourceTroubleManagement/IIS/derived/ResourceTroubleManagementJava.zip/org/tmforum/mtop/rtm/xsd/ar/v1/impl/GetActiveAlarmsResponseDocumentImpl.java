/*
 * An XML document type.
 * Localname: getActiveAlarmsResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1.impl;
/**
 * A document containing one getActiveAlarmsResponse(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveAlarmsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsResponseDocument
{
    
    public GetActiveAlarmsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEALARMSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "getActiveAlarmsResponse");
    
    
    /**
     * Gets the "getActiveAlarmsResponse" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType getGetActiveAlarmsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType)get_store().find_element_user(GETACTIVEALARMSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveAlarmsResponse" element
     */
    public void setGetActiveAlarmsResponse(org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType getActiveAlarmsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType)get_store().find_element_user(GETACTIVEALARMSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType)get_store().add_element_user(GETACTIVEALARMSRESPONSE$0);
            }
            target.set(getActiveAlarmsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveAlarmsResponse" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType addNewGetActiveAlarmsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType)get_store().add_element_user(GETACTIVEALARMSRESPONSE$0);
            return target;
        }
    }
}
