/*
 * An XML document type.
 * Localname: pgp
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pg/v1
 * Java type: org.tmforum.mtop.nra.xsd.pg.v1.PgpDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pg.v1.impl;
/**
 * A document containing one pgp(@http://www.tmforum.org/mtop/nra/xsd/pg/v1) element.
 *
 * This is a complex type.
 */
public class PgpDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pg.v1.PgpDocument
{
    
    public PgpDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PGP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "pgp");
    
    
    /**
     * Gets the "pgp" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType getPgp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PGP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pgp" element
     */
    public void setPgp(org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType pgp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PGP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().add_element_user(PGP$0);
            }
            target.set(pgp);
        }
    }
    
    /**
     * Appends and returns a new empty "pgp" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType addNewPgp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().add_element_user(PGP$0);
            return target;
        }
    }
}
