/*
 * XML Type:  AlarmSourceType
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1.impl;
/**
 * An XML AlarmSourceType(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType.
 */
public class AlarmSourceTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType
{
    
    public AlarmSourceTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected AlarmSourceTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
