/*
 * An XML document type.
 * Localname: acknowledgeAlarmsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ah/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ah.v1.impl;
/**
 * A document containing one acknowledgeAlarmsRequest(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1) element.
 *
 * This is a complex type.
 */
public class AcknowledgeAlarmsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument
{
    
    public AcknowledgeAlarmsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACKNOWLEDGEALARMSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "acknowledgeAlarmsRequest");
    
    
    /**
     * Gets the "acknowledgeAlarmsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest getAcknowledgeAlarmsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest)get_store().find_element_user(ACKNOWLEDGEALARMSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "acknowledgeAlarmsRequest" element
     */
    public void setAcknowledgeAlarmsRequest(org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest acknowledgeAlarmsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest)get_store().find_element_user(ACKNOWLEDGEALARMSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest)get_store().add_element_user(ACKNOWLEDGEALARMSREQUEST$0);
            }
            target.set(acknowledgeAlarmsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "acknowledgeAlarmsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest addNewAcknowledgeAlarmsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest)get_store().add_element_user(ACKNOWLEDGEALARMSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML acknowledgeAlarmsRequest(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1).
     *
     * This is a complex type.
     */
    public static class AcknowledgeAlarmsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsRequestDocument.AcknowledgeAlarmsRequest
    {
        
        public AcknowledgeAlarmsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ACKNOWLEDGEIDLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "acknowledgeIdList");
        private static final javax.xml.namespace.QName USERNAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "username");
        private static final javax.xml.namespace.QName NOTEPAD$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "notepad");
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "vendorExtensions");
        
        
        /**
         * Gets the "acknowledgeIdList" element
         */
        public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType getAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(ACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "acknowledgeIdList" element
         */
        public boolean isNilAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(ACKNOWLEDGEIDLIST$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "acknowledgeIdList" element
         */
        public boolean isSetAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ACKNOWLEDGEIDLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "acknowledgeIdList" element
         */
        public void setAcknowledgeIdList(org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType acknowledgeIdList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(ACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(ACKNOWLEDGEIDLIST$0);
                }
                target.set(acknowledgeIdList);
            }
        }
        
        /**
         * Appends and returns a new empty "acknowledgeIdList" element
         */
        public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType addNewAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(ACKNOWLEDGEIDLIST$0);
                return target;
            }
        }
        
        /**
         * Nils the "acknowledgeIdList" element
         */
        public void setNilAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(ACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(ACKNOWLEDGEIDLIST$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "acknowledgeIdList" element
         */
        public void unsetAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ACKNOWLEDGEIDLIST$0, 0);
            }
        }
        
        /**
         * Gets the "username" element
         */
        public java.lang.String getUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERNAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "username" element
         */
        public org.apache.xmlbeans.XmlString xgetUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$2, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "username" element
         */
        public boolean isNilUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "username" element
         */
        public boolean isSetUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(USERNAME$2) != 0;
            }
        }
        
        /**
         * Sets the "username" element
         */
        public void setUsername(java.lang.String username)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERNAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERNAME$2);
                }
                target.setStringValue(username);
            }
        }
        
        /**
         * Sets (as xml) the "username" element
         */
        public void xsetUsername(org.apache.xmlbeans.XmlString username)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERNAME$2);
                }
                target.set(username);
            }
        }
        
        /**
         * Nils the "username" element
         */
        public void setNilUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERNAME$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "username" element
         */
        public void unsetUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(USERNAME$2, 0);
            }
        }
        
        /**
         * Gets the "notepad" element
         */
        public java.lang.String getNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "notepad" element
         */
        public org.apache.xmlbeans.XmlString xgetNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOTEPAD$4, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "notepad" element
         */
        public boolean isNilNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "notepad" element
         */
        public boolean isSetNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NOTEPAD$4) != 0;
            }
        }
        
        /**
         * Sets the "notepad" element
         */
        public void setNotepad(java.lang.String notepad)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOTEPAD$4);
                }
                target.setStringValue(notepad);
            }
        }
        
        /**
         * Sets (as xml) the "notepad" element
         */
        public void xsetNotepad(org.apache.xmlbeans.XmlString notepad)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOTEPAD$4);
                }
                target.set(notepad);
            }
        }
        
        /**
         * Nils the "notepad" element
         */
        public void setNilNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOTEPAD$4);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "notepad" element
         */
        public void unsetNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NOTEPAD$4, 0);
            }
        }
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        public boolean isNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$6) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                return target;
            }
        }
        
        /**
         * Nils the "vendorExtensions" element
         */
        public void setNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$6, 0);
            }
        }
    }
}
