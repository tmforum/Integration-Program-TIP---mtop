/*
 * An XML document type.
 * Localname: getAsapResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAsapResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAsapResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument
{
    
    public GetAsapResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASAPRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAsapResponse");
    
    
    /**
     * Gets the "getAsapResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse getGetAsapResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse)get_store().find_element_user(GETASAPRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAsapResponse" element
     */
    public void setGetAsapResponse(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse getAsapResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse)get_store().find_element_user(GETASAPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse)get_store().add_element_user(GETASAPRESPONSE$0);
            }
            target.set(getAsapResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAsapResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse addNewGetAsapResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse)get_store().add_element_user(GETASAPRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAsapResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAsapResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapResponseDocument.GetAsapResponse
    {
        
        public GetAsapResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "asap");
        
        
        /**
         * Gets the "asap" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType getAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "asap" element
         */
        public boolean isNilAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "asap" element
         */
        public boolean isSetAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAP$0) != 0;
            }
        }
        
        /**
         * Sets the "asap" element
         */
        public void setAsap(org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType asap)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(ASAP$0);
                }
                target.set(asap);
            }
        }
        
        /**
         * Appends and returns a new empty "asap" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType addNewAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(ASAP$0);
                return target;
            }
        }
        
        /**
         * Nils the "asap" element
         */
        public void setNilAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(ASAP$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "asap" element
         */
        public void unsetAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAP$0, 0);
            }
        }
    }
}
