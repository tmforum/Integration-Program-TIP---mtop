/*
 * XML Type:  SwitchDataType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/sd/v1
 * Java type: org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.sd.v1;


/**
 * An XML SwitchDataType(@http://www.tmforum.org/mtop/nra/xsd/sd/v1).
 *
 * This is a complex type.
 */
public interface SwitchDataType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(SwitchDataType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sBE6052E03D6741DEC166ADB27BB9B6C3").resolveHandle("switchdatatypeb895type");
    
    /**
     * Gets the "protectionType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType getProtectionType();
    
    /**
     * Tests for nil "protectionType" element
     */
    boolean isNilProtectionType();
    
    /**
     * True if has "protectionType" element
     */
    boolean isSetProtectionType();
    
    /**
     * Sets the "protectionType" element
     */
    void setProtectionType(org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType protectionType);
    
    /**
     * Appends and returns a new empty "protectionType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProtectionTypeType addNewProtectionType();
    
    /**
     * Nils the "protectionType" element
     */
    void setNilProtectionType();
    
    /**
     * Unsets the "protectionType" element
     */
    void unsetProtectionType();
    
    /**
     * Gets the "switchReason" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum getSwitchReason();
    
    /**
     * Gets (as xml) the "switchReason" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType xgetSwitchReason();
    
    /**
     * Tests for nil "switchReason" element
     */
    boolean isNilSwitchReason();
    
    /**
     * True if has "switchReason" element
     */
    boolean isSetSwitchReason();
    
    /**
     * Sets the "switchReason" element
     */
    void setSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.Enum switchReason);
    
    /**
     * Sets (as xml) the "switchReason" element
     */
    void xsetSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType switchReason);
    
    /**
     * Nils the "switchReason" element
     */
    void setNilSwitchReason();
    
    /**
     * Unsets the "switchReason" element
     */
    void unsetSwitchReason();
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * Tests for nil "layerRate" element
     */
    boolean isNilLayerRate();
    
    /**
     * True if has "layerRate" element
     */
    boolean isSetLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Nils the "layerRate" element
     */
    void setNilLayerRate();
    
    /**
     * Unsets the "layerRate" element
     */
    void unsetLayerRate();
    
    /**
     * Gets the "groupName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getGroupName();
    
    /**
     * Tests for nil "groupName" element
     */
    boolean isNilGroupName();
    
    /**
     * True if has "groupName" element
     */
    boolean isSetGroupName();
    
    /**
     * Sets the "groupName" element
     */
    void setGroupName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType groupName);
    
    /**
     * Appends and returns a new empty "groupName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewGroupName();
    
    /**
     * Nils the "groupName" element
     */
    void setNilGroupName();
    
    /**
     * Unsets the "groupName" element
     */
    void unsetGroupName();
    
    /**
     * Gets the "protectedTp" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProtectedTp();
    
    /**
     * Tests for nil "protectedTp" element
     */
    boolean isNilProtectedTp();
    
    /**
     * True if has "protectedTp" element
     */
    boolean isSetProtectedTp();
    
    /**
     * Sets the "protectedTp" element
     */
    void setProtectedTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType protectedTp);
    
    /**
     * Appends and returns a new empty "protectedTp" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProtectedTp();
    
    /**
     * Nils the "protectedTp" element
     */
    void setNilProtectedTp();
    
    /**
     * Unsets the "protectedTp" element
     */
    void unsetProtectedTp();
    
    /**
     * Gets the "switchToTp" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSwitchToTp();
    
    /**
     * Tests for nil "switchToTp" element
     */
    boolean isNilSwitchToTp();
    
    /**
     * True if has "switchToTp" element
     */
    boolean isSetSwitchToTp();
    
    /**
     * Sets the "switchToTp" element
     */
    void setSwitchToTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType switchToTp);
    
    /**
     * Appends and returns a new empty "switchToTp" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSwitchToTp();
    
    /**
     * Nils the "switchToTp" element
     */
    void setNilSwitchToTp();
    
    /**
     * Unsets the "switchToTp" element
     */
    void unsetSwitchToTp();
    
    /**
     * Gets the "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
    
    /**
     * Tests for nil "vendorExtensions" element
     */
    boolean isNilVendorExtensions();
    
    /**
     * True if has "vendorExtensions" element
     */
    boolean isSetVendorExtensions();
    
    /**
     * Sets the "vendorExtensions" element
     */
    void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
    
    /**
     * Nils the "vendorExtensions" element
     */
    void setNilVendorExtensions();
    
    /**
     * Unsets the "vendorExtensions" element
     */
    void unsetVendorExtensions();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType newInstance() {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
