/*
 * XML Type:  PerceivedSeverityListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1.impl;
/**
 * An XML PerceivedSeverityListType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is a complex type.
 */
public class PerceivedSeverityListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType
{
    
    public PerceivedSeverityListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERCEIVEDSEVERITY$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/com/v1", "perceivedSeverity");
    
    
    /**
     * Gets a List of "perceivedSeverity" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum> getPerceivedSeverityList()
    {
        final class PerceivedSeverityList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum>
        {
            public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum get(int i)
                { return PerceivedSeverityListTypeImpl.this.getPerceivedSeverityArray(i); }
            
            public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum set(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum o)
            {
                org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum old = PerceivedSeverityListTypeImpl.this.getPerceivedSeverityArray(i);
                PerceivedSeverityListTypeImpl.this.setPerceivedSeverityArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum o)
                { PerceivedSeverityListTypeImpl.this.insertPerceivedSeverity(i, o); }
            
            public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum remove(int i)
            {
                org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum old = PerceivedSeverityListTypeImpl.this.getPerceivedSeverityArray(i);
                PerceivedSeverityListTypeImpl.this.removePerceivedSeverity(i);
                return old;
            }
            
            public int size()
                { return PerceivedSeverityListTypeImpl.this.sizeOfPerceivedSeverityArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PerceivedSeverityList();
        }
    }
    
    /**
     * Gets array of all "perceivedSeverity" elements
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum[] getPerceivedSeverityArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PERCEIVEDSEVERITY$0, targetList);
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum[] result = new org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
            return result;
        }
    }
    
    /**
     * Gets ith "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum getPerceivedSeverityArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCEIVEDSEVERITY$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "perceivedSeverity" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType> xgetPerceivedSeverityList()
    {
        final class PerceivedSeverityList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType>
        {
            public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType get(int i)
                { return PerceivedSeverityListTypeImpl.this.xgetPerceivedSeverityArray(i); }
            
            public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType set(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType o)
            {
                org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType old = PerceivedSeverityListTypeImpl.this.xgetPerceivedSeverityArray(i);
                PerceivedSeverityListTypeImpl.this.xsetPerceivedSeverityArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType o)
                { PerceivedSeverityListTypeImpl.this.insertNewPerceivedSeverity(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType old = PerceivedSeverityListTypeImpl.this.xgetPerceivedSeverityArray(i);
                PerceivedSeverityListTypeImpl.this.removePerceivedSeverity(i);
                return old;
            }
            
            public int size()
                { return PerceivedSeverityListTypeImpl.this.sizeOfPerceivedSeverityArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PerceivedSeverityList();
        }
    }
    
    /**
     * Gets (as xml) array of all "perceivedSeverity" elements
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType[] xgetPerceivedSeverityArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PERCEIVEDSEVERITY$0, targetList);
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType[] result = new org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType xgetPerceivedSeverityArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().find_element_user(PERCEIVEDSEVERITY$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)target;
        }
    }
    
    /**
     * Returns number of "perceivedSeverity" element
     */
    public int sizeOfPerceivedSeverityArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PERCEIVEDSEVERITY$0);
        }
    }
    
    /**
     * Sets array of all "perceivedSeverity" element
     */
    public void setPerceivedSeverityArray(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum[] perceivedSeverityArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(perceivedSeverityArray, PERCEIVEDSEVERITY$0);
        }
    }
    
    /**
     * Sets ith "perceivedSeverity" element
     */
    public void setPerceivedSeverityArray(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCEIVEDSEVERITY$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setEnumValue(perceivedSeverity);
        }
    }
    
    /**
     * Sets (as xml) array of all "perceivedSeverity" element
     */
    public void xsetPerceivedSeverityArray(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType[]perceivedSeverityArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(perceivedSeverityArray, PERCEIVEDSEVERITY$0);
        }
    }
    
    /**
     * Sets (as xml) ith "perceivedSeverity" element
     */
    public void xsetPerceivedSeverityArray(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().find_element_user(PERCEIVEDSEVERITY$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(perceivedSeverity);
        }
    }
    
    /**
     * Inserts the value as the ith "perceivedSeverity" element
     */
    public void insertPerceivedSeverity(int i, org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PERCEIVEDSEVERITY$0, i);
            target.setEnumValue(perceivedSeverity);
        }
    }
    
    /**
     * Appends the value as the last "perceivedSeverity" element
     */
    public void addPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PERCEIVEDSEVERITY$0);
            target.setEnumValue(perceivedSeverity);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType insertNewPerceivedSeverity(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().insert_element_user(PERCEIVEDSEVERITY$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType addNewPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().add_element_user(PERCEIVEDSEVERITY$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "perceivedSeverity" element
     */
    public void removePerceivedSeverity(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PERCEIVEDSEVERITY$0, i);
        }
    }
}
