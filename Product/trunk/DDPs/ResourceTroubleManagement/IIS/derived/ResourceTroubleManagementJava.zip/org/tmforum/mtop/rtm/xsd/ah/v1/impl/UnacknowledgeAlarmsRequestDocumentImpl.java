/*
 * An XML document type.
 * Localname: unacknowledgeAlarmsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ah/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ah.v1.impl;
/**
 * A document containing one unacknowledgeAlarmsRequest(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1) element.
 *
 * This is a complex type.
 */
public class UnacknowledgeAlarmsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument
{
    
    public UnacknowledgeAlarmsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UNACKNOWLEDGEALARMSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "unacknowledgeAlarmsRequest");
    
    
    /**
     * Gets the "unacknowledgeAlarmsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest getUnacknowledgeAlarmsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest)get_store().find_element_user(UNACKNOWLEDGEALARMSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "unacknowledgeAlarmsRequest" element
     */
    public void setUnacknowledgeAlarmsRequest(org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest unacknowledgeAlarmsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest)get_store().find_element_user(UNACKNOWLEDGEALARMSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest)get_store().add_element_user(UNACKNOWLEDGEALARMSREQUEST$0);
            }
            target.set(unacknowledgeAlarmsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "unacknowledgeAlarmsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest addNewUnacknowledgeAlarmsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest)get_store().add_element_user(UNACKNOWLEDGEALARMSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML unacknowledgeAlarmsRequest(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1).
     *
     * This is a complex type.
     */
    public static class UnacknowledgeAlarmsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsRequestDocument.UnacknowledgeAlarmsRequest
    {
        
        public UnacknowledgeAlarmsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName UNACKNOWLEDGEIDLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "unacknowledgeIdList");
        private static final javax.xml.namespace.QName USERNAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "username");
        private static final javax.xml.namespace.QName NOTEPAD$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "notepad");
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "vendorExtensions");
        
        
        /**
         * Gets the "unacknowledgeIdList" element
         */
        public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType getUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(UNACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "unacknowledgeIdList" element
         */
        public boolean isNilUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(UNACKNOWLEDGEIDLIST$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "unacknowledgeIdList" element
         */
        public boolean isSetUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(UNACKNOWLEDGEIDLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "unacknowledgeIdList" element
         */
        public void setUnacknowledgeIdList(org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType unacknowledgeIdList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(UNACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(UNACKNOWLEDGEIDLIST$0);
                }
                target.set(unacknowledgeIdList);
            }
        }
        
        /**
         * Appends and returns a new empty "unacknowledgeIdList" element
         */
        public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType addNewUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(UNACKNOWLEDGEIDLIST$0);
                return target;
            }
        }
        
        /**
         * Nils the "unacknowledgeIdList" element
         */
        public void setNilUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(UNACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(UNACKNOWLEDGEIDLIST$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "unacknowledgeIdList" element
         */
        public void unsetUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(UNACKNOWLEDGEIDLIST$0, 0);
            }
        }
        
        /**
         * Gets the "username" element
         */
        public java.lang.String getUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERNAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "username" element
         */
        public org.apache.xmlbeans.XmlString xgetUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$2, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "username" element
         */
        public boolean isNilUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "username" element
         */
        public boolean isSetUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(USERNAME$2) != 0;
            }
        }
        
        /**
         * Sets the "username" element
         */
        public void setUsername(java.lang.String username)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERNAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERNAME$2);
                }
                target.setStringValue(username);
            }
        }
        
        /**
         * Sets (as xml) the "username" element
         */
        public void xsetUsername(org.apache.xmlbeans.XmlString username)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERNAME$2);
                }
                target.set(username);
            }
        }
        
        /**
         * Nils the "username" element
         */
        public void setNilUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(USERNAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(USERNAME$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "username" element
         */
        public void unsetUsername()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(USERNAME$2, 0);
            }
        }
        
        /**
         * Gets the "notepad" element
         */
        public java.lang.String getNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "notepad" element
         */
        public org.apache.xmlbeans.XmlString xgetNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOTEPAD$4, 0);
                return target;
            }
        }
        
        /**
         * Tests for nil "notepad" element
         */
        public boolean isNilNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "notepad" element
         */
        public boolean isSetNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NOTEPAD$4) != 0;
            }
        }
        
        /**
         * Sets the "notepad" element
         */
        public void setNotepad(java.lang.String notepad)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NOTEPAD$4);
                }
                target.setStringValue(notepad);
            }
        }
        
        /**
         * Sets (as xml) the "notepad" element
         */
        public void xsetNotepad(org.apache.xmlbeans.XmlString notepad)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOTEPAD$4);
                }
                target.set(notepad);
            }
        }
        
        /**
         * Nils the "notepad" element
         */
        public void setNilNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NOTEPAD$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NOTEPAD$4);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "notepad" element
         */
        public void unsetNotepad()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NOTEPAD$4, 0);
            }
        }
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        public boolean isNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$6) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                return target;
            }
        }
        
        /**
         * Nils the "vendorExtensions" element
         */
        public void setNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$6, 0);
            }
        }
    }
}
