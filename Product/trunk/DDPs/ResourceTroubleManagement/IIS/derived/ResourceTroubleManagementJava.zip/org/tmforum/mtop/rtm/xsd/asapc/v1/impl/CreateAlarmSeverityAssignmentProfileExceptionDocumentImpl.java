/*
 * An XML document type.
 * Localname: createAlarmSeverityAssignmentProfileException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one createAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAlarmSeverityAssignmentProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument
{
    
    public CreateAlarmSeverityAssignmentProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "createAlarmSeverityAssignmentProfileException");
    
    
    /**
     * Gets the "createAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException getCreateAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException)get_store().find_element_user(CREATEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAlarmSeverityAssignmentProfileException" element
     */
    public void setCreateAlarmSeverityAssignmentProfileException(org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException createAlarmSeverityAssignmentProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException)get_store().find_element_user(CREATEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException)get_store().add_element_user(CREATEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            }
            target.set(createAlarmSeverityAssignmentProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "createAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException addNewCreateAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException)get_store().add_element_user(CREATEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML createAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAlarmSeverityAssignmentProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileExceptionDocument.CreateAlarmSeverityAssignmentProfileException
    {
        
        public CreateAlarmSeverityAssignmentProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
