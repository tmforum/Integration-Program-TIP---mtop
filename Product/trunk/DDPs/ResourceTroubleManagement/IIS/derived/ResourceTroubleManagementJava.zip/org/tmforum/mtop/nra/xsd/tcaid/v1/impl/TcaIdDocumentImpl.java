/*
 * An XML document type.
 * Localname: tcaId
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcaid/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcaid.v1.impl;
/**
 * A document containing one tcaId(@http://www.tmforum.org/mtop/nra/xsd/tcaid/v1) element.
 *
 * This is a complex type.
 */
public class TcaIdDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdDocument
{
    
    public TcaIdDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TCAID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcaid/v1", "tcaId");
    
    
    /**
     * Gets the "tcaId" element
     */
    public org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType getTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType)get_store().find_element_user(TCAID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "tcaId" element
     */
    public void setTcaId(org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType tcaId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType)get_store().find_element_user(TCAID$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType)get_store().add_element_user(TCAID$0);
            }
            target.set(tcaId);
        }
    }
    
    /**
     * Appends and returns a new empty "tcaId" element
     */
    public org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType addNewTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType)get_store().add_element_user(TCAID$0);
            return target;
        }
    }
}
