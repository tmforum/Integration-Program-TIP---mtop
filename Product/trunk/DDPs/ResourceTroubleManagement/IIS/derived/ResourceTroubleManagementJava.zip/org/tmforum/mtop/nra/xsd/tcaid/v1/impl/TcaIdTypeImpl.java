/*
 * XML Type:  TcaIdType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcaid/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcaid.v1.impl;
/**
 * An XML TcaIdType(@http://www.tmforum.org/mtop/nra/xsd/tcaid/v1).
 *
 * This is a complex type.
 */
public class TcaIdTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType
{
    
    public TcaIdTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcaid/v1", "objectName");
    private static final javax.xml.namespace.QName LAYERRATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcaid/v1", "layerRate");
    private static final javax.xml.namespace.QName PMPARAMETERNAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcaid/v1", "pmParameterName");
    private static final javax.xml.namespace.QName PMLOCATION$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcaid/v1", "pmLocation");
    private static final javax.xml.namespace.QName GRANULARITY$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/tcaid/v1", "granularity");
    
    
    /**
     * Gets the "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OBJECTNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "objectName" element
     */
    public boolean isSetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "objectName" element
     */
    public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType objectName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OBJECTNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OBJECTNAME$0);
            }
            target.set(objectName);
        }
    }
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OBJECTNAME$0);
            return target;
        }
    }
    
    /**
     * Unsets the "objectName" element
     */
    public void unsetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTNAME$0, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$2) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$2);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$2, 0);
        }
    }
    
    /**
     * Gets the "pmParameterName" element
     */
    public java.lang.String getPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "pmParameterName" element
     */
    public boolean isSetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMPARAMETERNAME$4) != 0;
        }
    }
    
    /**
     * Sets the "pmParameterName" element
     */
    public void setPmParameterName(java.lang.String pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMPARAMETERNAME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMPARAMETERNAME$4);
            }
            target.setStringValue(pmParameterName);
        }
    }
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    public void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().find_element_user(PMPARAMETERNAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType)get_store().add_element_user(PMPARAMETERNAME$4);
            }
            target.set(pmParameterName);
        }
    }
    
    /**
     * Unsets the "pmParameterName" element
     */
    public void unsetPmParameterName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMPARAMETERNAME$4, 0);
        }
    }
    
    /**
     * Gets the "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$6, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "pmLocation" element
     */
    public boolean isSetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMLOCATION$6) != 0;
        }
    }
    
    /**
     * Sets the "pmLocation" element
     */
    public void setPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMLOCATION$6);
            }
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Sets (as xml) the "pmLocation" element
     */
    public void xsetPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().add_element_user(PMLOCATION$6);
            }
            target.set(pmLocation);
        }
    }
    
    /**
     * Unsets the "pmLocation" element
     */
    public void unsetPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMLOCATION$6, 0);
        }
    }
    
    /**
     * Gets the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "granularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "granularity" element
     */
    public boolean isSetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(GRANULARITY$8) != 0;
        }
    }
    
    /**
     * Sets the "granularity" element
     */
    public void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(GRANULARITY$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(GRANULARITY$8);
            }
            target.setEnumValue(granularity);
        }
    }
    
    /**
     * Sets (as xml) the "granularity" element
     */
    public void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(GRANULARITY$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(GRANULARITY$8);
            }
            target.set(granularity);
        }
    }
    
    /**
     * Unsets the "granularity" element
     */
    public void unsetGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(GRANULARITY$8, 0);
        }
    }
}
