/*
 * An XML document type.
 * Localname: setAlarmReportingOffException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setAlarmReportingOffException(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetAlarmReportingOffExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument
{
    
    public SetAlarmReportingOffExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALARMREPORTINGOFFEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setAlarmReportingOffException");
    
    
    /**
     * Gets the "setAlarmReportingOffException" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException getSetAlarmReportingOffException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException)get_store().find_element_user(SETALARMREPORTINGOFFEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAlarmReportingOffException" element
     */
    public void setSetAlarmReportingOffException(org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException setAlarmReportingOffException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException)get_store().find_element_user(SETALARMREPORTINGOFFEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException)get_store().add_element_user(SETALARMREPORTINGOFFEXCEPTION$0);
            }
            target.set(setAlarmReportingOffException);
        }
    }
    
    /**
     * Appends and returns a new empty "setAlarmReportingOffException" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException addNewSetAlarmReportingOffException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException)get_store().add_element_user(SETALARMREPORTINGOFFEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setAlarmReportingOffException(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetAlarmReportingOffExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffExceptionDocument.SetAlarmReportingOffException
    {
        
        public SetAlarmReportingOffExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
