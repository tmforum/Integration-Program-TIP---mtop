/*
 * XML Type:  WtrTimeType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pgp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pgp.v1.impl;
/**
 * An XML WtrTimeType(@http://www.tmforum.org/mtop/nra/xsd/pgp/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType.
 */
public class WtrTimeTypeImpl extends org.apache.xmlbeans.impl.values.JavaIntegerHolderEx implements org.tmforum.mtop.nra.xsd.pgp.v1.WtrTimeType
{
    
    public WtrTimeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected WtrTimeTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
