/*
 * An XML document type.
 * Localname: assignAsapException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one assignAsapException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class AssignAsapExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument
{
    
    public AssignAsapExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASSIGNASAPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "assignAsapException");
    
    
    /**
     * Gets the "assignAsapException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException getAssignAsapException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException)get_store().find_element_user(ASSIGNASAPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "assignAsapException" element
     */
    public void setAssignAsapException(org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException assignAsapException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException)get_store().find_element_user(ASSIGNASAPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException)get_store().add_element_user(ASSIGNASAPEXCEPTION$0);
            }
            target.set(assignAsapException);
        }
    }
    
    /**
     * Appends and returns a new empty "assignAsapException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException addNewAssignAsapException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException)get_store().add_element_user(ASSIGNASAPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML assignAsapException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class AssignAsapExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapExceptionDocument.AssignAsapException
    {
        
        public AssignAsapExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
