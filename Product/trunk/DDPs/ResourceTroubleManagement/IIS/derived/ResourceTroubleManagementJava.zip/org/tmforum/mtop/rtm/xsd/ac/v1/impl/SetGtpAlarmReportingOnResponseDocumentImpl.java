/*
 * An XML document type.
 * Localname: setGtpAlarmReportingOnResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setGtpAlarmReportingOnResponse(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetGtpAlarmReportingOnResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument
{
    
    public SetGtpAlarmReportingOnResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETGTPALARMREPORTINGONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setGtpAlarmReportingOnResponse");
    
    
    /**
     * Gets the "setGtpAlarmReportingOnResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse getSetGtpAlarmReportingOnResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse)get_store().find_element_user(SETGTPALARMREPORTINGONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setGtpAlarmReportingOnResponse" element
     */
    public void setSetGtpAlarmReportingOnResponse(org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse setGtpAlarmReportingOnResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse)get_store().find_element_user(SETGTPALARMREPORTINGONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse)get_store().add_element_user(SETGTPALARMREPORTINGONRESPONSE$0);
            }
            target.set(setGtpAlarmReportingOnResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setGtpAlarmReportingOnResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse addNewSetGtpAlarmReportingOnResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse)get_store().add_element_user(SETGTPALARMREPORTINGONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setGtpAlarmReportingOnResponse(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetGtpAlarmReportingOnResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOnResponseDocument.SetGtpAlarmReportingOnResponse
    {
        
        public SetGtpAlarmReportingOnResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
