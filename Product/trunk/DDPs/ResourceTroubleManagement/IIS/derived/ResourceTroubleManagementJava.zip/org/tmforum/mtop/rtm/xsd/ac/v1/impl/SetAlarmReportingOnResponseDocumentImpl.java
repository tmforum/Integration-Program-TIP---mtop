/*
 * An XML document type.
 * Localname: setAlarmReportingOnResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setAlarmReportingOnResponse(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetAlarmReportingOnResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument
{
    
    public SetAlarmReportingOnResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALARMREPORTINGONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setAlarmReportingOnResponse");
    
    
    /**
     * Gets the "setAlarmReportingOnResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse getSetAlarmReportingOnResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse)get_store().find_element_user(SETALARMREPORTINGONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAlarmReportingOnResponse" element
     */
    public void setSetAlarmReportingOnResponse(org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse setAlarmReportingOnResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse)get_store().find_element_user(SETALARMREPORTINGONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse)get_store().add_element_user(SETALARMREPORTINGONRESPONSE$0);
            }
            target.set(setAlarmReportingOnResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setAlarmReportingOnResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse addNewSetAlarmReportingOnResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse)get_store().add_element_user(SETALARMREPORTINGONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setAlarmReportingOnResponse(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetAlarmReportingOnResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnResponseDocument.SetAlarmReportingOnResponse
    {
        
        public SetAlarmReportingOnResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
