/*
 * XML Type:  AlarmOrTcaIdListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/atcaid/v1
 * Java type: org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.atcaid.v1.impl;
/**
 * An XML AlarmOrTcaIdListType(@http://www.tmforum.org/mtop/nra/xsd/atcaid/v1).
 *
 * This is a complex type.
 */
public class AlarmOrTcaIdListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType
{
    
    public AlarmOrTcaIdListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARMORTCAID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/atcaid/v1", "alarmOrTcaId");
    
    
    /**
     * Gets a List of "alarmOrTcaId" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType> getAlarmOrTcaIdList()
    {
        final class AlarmOrTcaIdList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType>
        {
            public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType get(int i)
                { return AlarmOrTcaIdListTypeImpl.this.getAlarmOrTcaIdArray(i); }
            
            public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType set(int i, org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType o)
            {
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType old = AlarmOrTcaIdListTypeImpl.this.getAlarmOrTcaIdArray(i);
                AlarmOrTcaIdListTypeImpl.this.setAlarmOrTcaIdArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType o)
                { AlarmOrTcaIdListTypeImpl.this.insertNewAlarmOrTcaId(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType old = AlarmOrTcaIdListTypeImpl.this.getAlarmOrTcaIdArray(i);
                AlarmOrTcaIdListTypeImpl.this.removeAlarmOrTcaId(i);
                return old;
            }
            
            public int size()
                { return AlarmOrTcaIdListTypeImpl.this.sizeOfAlarmOrTcaIdArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new AlarmOrTcaIdList();
        }
    }
    
    /**
     * Gets array of all "alarmOrTcaId" elements
     */
    public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType[] getAlarmOrTcaIdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(ALARMORTCAID$0, targetList);
            org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType[] result = new org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "alarmOrTcaId" element
     */
    public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType getAlarmOrTcaIdArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType)get_store().find_element_user(ALARMORTCAID$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "alarmOrTcaId" element
     */
    public int sizeOfAlarmOrTcaIdArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMORTCAID$0);
        }
    }
    
    /**
     * Sets array of all "alarmOrTcaId" element
     */
    public void setAlarmOrTcaIdArray(org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType[] alarmOrTcaIdArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(alarmOrTcaIdArray, ALARMORTCAID$0);
        }
    }
    
    /**
     * Sets ith "alarmOrTcaId" element
     */
    public void setAlarmOrTcaIdArray(int i, org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType alarmOrTcaId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType)get_store().find_element_user(ALARMORTCAID$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(alarmOrTcaId);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "alarmOrTcaId" element
     */
    public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType insertNewAlarmOrTcaId(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType)get_store().insert_element_user(ALARMORTCAID$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "alarmOrTcaId" element
     */
    public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType addNewAlarmOrTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType)get_store().add_element_user(ALARMORTCAID$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "alarmOrTcaId" element
     */
    public void removeAlarmOrTcaId(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMORTCAID$0, i);
        }
    }
}
