/*
 * An XML document type.
 * Localname: createAsapResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one createAsapResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAsapResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument
{
    
    public CreateAsapResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEASAPRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "createAsapResponse");
    
    
    /**
     * Gets the "createAsapResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse getCreateAsapResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse)get_store().find_element_user(CREATEASAPRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAsapResponse" element
     */
    public void setCreateAsapResponse(org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse createAsapResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse)get_store().find_element_user(CREATEASAPRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse)get_store().add_element_user(CREATEASAPRESPONSE$0);
            }
            target.set(createAsapResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "createAsapResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse addNewCreateAsapResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse)get_store().add_element_user(CREATEASAPRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML createAsapResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAsapResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapResponseDocument.CreateAsapResponse
    {
        
        public CreateAsapResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName NEWASAP$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "newAsap");
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "vendorExtensions");
        
        
        /**
         * Gets the "newAsap" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType getNewAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(NEWASAP$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "newAsap" element
         */
        public boolean isNilNewAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(NEWASAP$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "newAsap" element
         */
        public boolean isSetNewAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NEWASAP$0) != 0;
            }
        }
        
        /**
         * Sets the "newAsap" element
         */
        public void setNewAsap(org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType newAsap)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(NEWASAP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(NEWASAP$0);
                }
                target.set(newAsap);
            }
        }
        
        /**
         * Appends and returns a new empty "newAsap" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType addNewNewAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(NEWASAP$0);
                return target;
            }
        }
        
        /**
         * Nils the "newAsap" element
         */
        public void setNilNewAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(NEWASAP$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(NEWASAP$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "newAsap" element
         */
        public void unsetNewAsap()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NEWASAP$0, 0);
            }
        }
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        public boolean isNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$2) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$2);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$2);
                return target;
            }
        }
        
        /**
         * Nils the "vendorExtensions" element
         */
        public void setNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$2, 0);
            }
        }
    }
}
