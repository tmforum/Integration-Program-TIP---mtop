/*
 * An XML document type.
 * Localname: getActiveAlarmsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1.impl;
/**
 * A document containing one getActiveAlarmsRequest(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveAlarmsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument
{
    
    public GetActiveAlarmsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEALARMSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "getActiveAlarmsRequest");
    
    
    /**
     * Gets the "getActiveAlarmsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest getGetActiveAlarmsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest)get_store().find_element_user(GETACTIVEALARMSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveAlarmsRequest" element
     */
    public void setGetActiveAlarmsRequest(org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest getActiveAlarmsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest)get_store().find_element_user(GETACTIVEALARMSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest)get_store().add_element_user(GETACTIVEALARMSREQUEST$0);
            }
            target.set(getActiveAlarmsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveAlarmsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest addNewGetActiveAlarmsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest)get_store().add_element_user(GETACTIVEALARMSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getActiveAlarmsRequest(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1).
     *
     * This is a complex type.
     */
    public static class GetActiveAlarmsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsRequestDocument.GetActiveAlarmsRequest
    {
        
        public GetActiveAlarmsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FILTER$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "filter");
        
        
        /**
         * Gets the "filter" element
         */
        public org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType getFilter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType target = null;
                target = (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType)get_store().find_element_user(FILTER$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "filter" element
         */
        public boolean isSetFilter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FILTER$0) != 0;
            }
        }
        
        /**
         * Sets the "filter" element
         */
        public void setFilter(org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType filter)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType target = null;
                target = (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType)get_store().find_element_user(FILTER$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType)get_store().add_element_user(FILTER$0);
                }
                target.set(filter);
            }
        }
        
        /**
         * Appends and returns a new empty "filter" element
         */
        public org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType addNewFilter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType target = null;
                target = (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType)get_store().add_element_user(FILTER$0);
                return target;
            }
        }
        
        /**
         * Unsets the "filter" element
         */
        public void unsetFilter()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FILTER$0, 0);
            }
        }
    }
}
