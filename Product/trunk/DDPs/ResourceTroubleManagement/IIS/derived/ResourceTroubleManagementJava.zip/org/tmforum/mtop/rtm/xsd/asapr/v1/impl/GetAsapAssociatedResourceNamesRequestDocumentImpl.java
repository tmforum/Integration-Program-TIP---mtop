/*
 * An XML document type.
 * Localname: getAsapAssociatedResourceNamesRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAsapAssociatedResourceNamesRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAsapAssociatedResourceNamesRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument
{
    
    public GetAsapAssociatedResourceNamesRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASAPASSOCIATEDRESOURCENAMESREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAsapAssociatedResourceNamesRequest");
    
    
    /**
     * Gets the "getAsapAssociatedResourceNamesRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest getGetAsapAssociatedResourceNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest)get_store().find_element_user(GETASAPASSOCIATEDRESOURCENAMESREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAsapAssociatedResourceNamesRequest" element
     */
    public void setGetAsapAssociatedResourceNamesRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest getAsapAssociatedResourceNamesRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest)get_store().find_element_user(GETASAPASSOCIATEDRESOURCENAMESREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest)get_store().add_element_user(GETASAPASSOCIATEDRESOURCENAMESREQUEST$0);
            }
            target.set(getAsapAssociatedResourceNamesRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAsapAssociatedResourceNamesRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest addNewGetAsapAssociatedResourceNamesRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest)get_store().add_element_user(GETASAPASSOCIATEDRESOURCENAMESREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAsapAssociatedResourceNamesRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAsapAssociatedResourceNamesRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesRequestDocument.GetAsapAssociatedResourceNamesRequest
    {
        
        public GetAsapAssociatedResourceNamesRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "asapName");
        
        
        /**
         * Gets the "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "asapName" element
         */
        public void setAsapName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType asapName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ASAPNAME$0);
                }
                target.set(asapName);
            }
        }
        
        /**
         * Appends and returns a new empty "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ASAPNAME$0);
                return target;
            }
        }
    }
}
