/*
 * An XML document type.
 * Localname: getAsapIteratorException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAsapIteratorException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAsapIteratorExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorExceptionDocument
{
    
    public GetAsapIteratorExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASAPITERATOREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAsapIteratorException");
    
    
    /**
     * Gets the "getAsapIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getGetAsapIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETASAPITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAsapIteratorException" element
     */
    public void setGetAsapIteratorException(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getAsapIteratorException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETASAPITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETASAPITERATOREXCEPTION$0);
            }
            target.set(getAsapIteratorException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAsapIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType addNewGetAsapIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETASAPITERATOREXCEPTION$0);
            return target;
        }
    }
}
