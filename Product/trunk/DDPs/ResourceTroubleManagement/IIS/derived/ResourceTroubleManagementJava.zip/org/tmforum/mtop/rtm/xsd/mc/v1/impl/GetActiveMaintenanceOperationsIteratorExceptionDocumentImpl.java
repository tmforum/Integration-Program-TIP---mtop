/*
 * An XML document type.
 * Localname: getActiveMaintenanceOperationsIteratorException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/mc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.mc.v1.impl;
/**
 * A document containing one getActiveMaintenanceOperationsIteratorException(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveMaintenanceOperationsIteratorExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorExceptionDocument
{
    
    public GetActiveMaintenanceOperationsIteratorExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEMAINTENANCEOPERATIONSITERATOREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "getActiveMaintenanceOperationsIteratorException");
    
    
    /**
     * Gets the "getActiveMaintenanceOperationsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getGetActiveMaintenanceOperationsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveMaintenanceOperationsIteratorException" element
     */
    public void setGetActiveMaintenanceOperationsIteratorException(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getActiveMaintenanceOperationsIteratorException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATOREXCEPTION$0);
            }
            target.set(getActiveMaintenanceOperationsIteratorException);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveMaintenanceOperationsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType addNewGetActiveMaintenanceOperationsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATOREXCEPTION$0);
            return target;
        }
    }
}
