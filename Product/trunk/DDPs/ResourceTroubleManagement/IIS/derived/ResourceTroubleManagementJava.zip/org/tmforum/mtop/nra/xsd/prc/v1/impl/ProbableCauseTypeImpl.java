/*
 * XML Type:  ProbableCauseType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/prc/v1
 * Java type: org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.prc.v1.impl;
/**
 * An XML ProbableCauseType(@http://www.tmforum.org/mtop/nra/xsd/prc/v1).
 *
 * This is a complex type.
 */
public class ProbableCauseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType
{
    
    public ProbableCauseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RU$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/prc/v1", "ru");
    private static final javax.xml.namespace.QName CONTRA$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/prc/v1", "contra");
    private static final javax.xml.namespace.QName PROBABLECAUSE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/prc/v1", "probableCause");
    private static final javax.xml.namespace.QName EXTENSION$6 = 
        new javax.xml.namespace.QName("", "extension");
    private static final javax.xml.namespace.QName QUALIFIER$8 = 
        new javax.xml.namespace.QName("", "qualifier");
    
    
    /**
     * Gets the "ru" element
     */
    public boolean getRu()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RU$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "ru" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRu()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(RU$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "ru" element
     */
    public boolean isSetRu()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RU$0) != 0;
        }
    }
    
    /**
     * Sets the "ru" element
     */
    public void setRu(boolean ru)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RU$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RU$0);
            }
            target.setBooleanValue(ru);
        }
    }
    
    /**
     * Sets (as xml) the "ru" element
     */
    public void xsetRu(org.apache.xmlbeans.XmlBoolean ru)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(RU$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(RU$0);
            }
            target.set(ru);
        }
    }
    
    /**
     * Unsets the "ru" element
     */
    public void unsetRu()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RU$0, 0);
        }
    }
    
    /**
     * Gets the "contra" element
     */
    public boolean getContra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTRA$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "contra" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetContra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CONTRA$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "contra" element
     */
    public boolean isSetContra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CONTRA$2) != 0;
        }
    }
    
    /**
     * Sets the "contra" element
     */
    public void setContra(boolean contra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CONTRA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CONTRA$2);
            }
            target.setBooleanValue(contra);
        }
    }
    
    /**
     * Sets (as xml) the "contra" element
     */
    public void xsetContra(org.apache.xmlbeans.XmlBoolean contra)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(CONTRA$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(CONTRA$2);
            }
            target.set(contra);
        }
    }
    
    /**
     * Unsets the "contra" element
     */
    public void unsetContra()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CONTRA$2, 0);
        }
    }
    
    /**
     * Gets the "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType.Enum getProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROBABLECAUSE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType xgetProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType)get_store().find_element_user(PROBABLECAUSE$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "probableCause" element
     */
    public void setProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType.Enum probableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROBABLECAUSE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROBABLECAUSE$4);
            }
            target.setEnumValue(probableCause);
        }
    }
    
    /**
     * Sets (as xml) the "probableCause" element
     */
    public void xsetProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType probableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType)get_store().find_element_user(PROBABLECAUSE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseEnumType)get_store().add_element_user(PROBABLECAUSE$4);
            }
            target.set(probableCause);
        }
    }
    
    /**
     * Gets the "extension" attribute
     */
    public java.lang.String getExtension()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(EXTENSION$6);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "extension" attribute
     */
    public org.apache.xmlbeans.XmlString xgetExtension()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(EXTENSION$6);
            return target;
        }
    }
    
    /**
     * True if has "extension" attribute
     */
    public boolean isSetExtension()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(EXTENSION$6) != null;
        }
    }
    
    /**
     * Sets the "extension" attribute
     */
    public void setExtension(java.lang.String extension)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(EXTENSION$6);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(EXTENSION$6);
            }
            target.setStringValue(extension);
        }
    }
    
    /**
     * Sets (as xml) the "extension" attribute
     */
    public void xsetExtension(org.apache.xmlbeans.XmlString extension)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(EXTENSION$6);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(EXTENSION$6);
            }
            target.set(extension);
        }
    }
    
    /**
     * Unsets the "extension" attribute
     */
    public void unsetExtension()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(EXTENSION$6);
        }
    }
    
    /**
     * Gets the "qualifier" attribute
     */
    public java.lang.String getQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(QUALIFIER$8);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "qualifier" attribute
     */
    public org.apache.xmlbeans.XmlString xgetQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(QUALIFIER$8);
            return target;
        }
    }
    
    /**
     * True if has "qualifier" attribute
     */
    public boolean isSetQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().find_attribute_user(QUALIFIER$8) != null;
        }
    }
    
    /**
     * Sets the "qualifier" attribute
     */
    public void setQualifier(java.lang.String qualifier)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_attribute_user(QUALIFIER$8);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_attribute_user(QUALIFIER$8);
            }
            target.setStringValue(qualifier);
        }
    }
    
    /**
     * Sets (as xml) the "qualifier" attribute
     */
    public void xsetQualifier(org.apache.xmlbeans.XmlString qualifier)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_attribute_user(QUALIFIER$8);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_attribute_user(QUALIFIER$8);
            }
            target.set(qualifier);
        }
    }
    
    /**
     * Unsets the "qualifier" attribute
     */
    public void unsetQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_attribute(QUALIFIER$8);
        }
    }
}
