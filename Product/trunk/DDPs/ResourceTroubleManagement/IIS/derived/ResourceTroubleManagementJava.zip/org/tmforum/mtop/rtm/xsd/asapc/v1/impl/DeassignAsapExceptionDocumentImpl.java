/*
 * An XML document type.
 * Localname: deassignAsapException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one deassignAsapException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class DeassignAsapExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument
{
    
    public DeassignAsapExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DEASSIGNASAPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "deassignAsapException");
    
    
    /**
     * Gets the "deassignAsapException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException getDeassignAsapException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException)get_store().find_element_user(DEASSIGNASAPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deassignAsapException" element
     */
    public void setDeassignAsapException(org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException deassignAsapException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException)get_store().find_element_user(DEASSIGNASAPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException)get_store().add_element_user(DEASSIGNASAPEXCEPTION$0);
            }
            target.set(deassignAsapException);
        }
    }
    
    /**
     * Appends and returns a new empty "deassignAsapException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException addNewDeassignAsapException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException)get_store().add_element_user(DEASSIGNASAPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deassignAsapException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class DeassignAsapExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAsapExceptionDocument.DeassignAsapException
    {
        
        public DeassignAsapExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
