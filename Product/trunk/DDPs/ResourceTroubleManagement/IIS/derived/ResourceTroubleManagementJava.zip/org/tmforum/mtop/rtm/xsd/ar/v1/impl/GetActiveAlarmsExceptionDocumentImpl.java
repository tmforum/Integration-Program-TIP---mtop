/*
 * An XML document type.
 * Localname: getActiveAlarmsException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1.impl;
/**
 * A document containing one getActiveAlarmsException(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveAlarmsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument
{
    
    public GetActiveAlarmsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEALARMSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "getActiveAlarmsException");
    
    
    /**
     * Gets the "getActiveAlarmsException" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException getGetActiveAlarmsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException)get_store().find_element_user(GETACTIVEALARMSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveAlarmsException" element
     */
    public void setGetActiveAlarmsException(org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException getActiveAlarmsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException)get_store().find_element_user(GETACTIVEALARMSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException)get_store().add_element_user(GETACTIVEALARMSEXCEPTION$0);
            }
            target.set(getActiveAlarmsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveAlarmsException" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException addNewGetActiveAlarmsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException)get_store().add_element_user(GETACTIVEALARMSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getActiveAlarmsException(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1).
     *
     * This is a complex type.
     */
    public static class GetActiveAlarmsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsExceptionDocument.GetActiveAlarmsException
    {
        
        public GetActiveAlarmsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
