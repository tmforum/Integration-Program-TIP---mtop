/*
 * XML Type:  PgParametersListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pgp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pgp.v1.impl;
/**
 * An XML PgParametersListType(@http://www.tmforum.org/mtop/nra/xsd/pgp/v1).
 *
 * This is a complex type.
 */
public class PgParametersListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType
{
    
    public PgParametersListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PGPARAMETER$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pgp/v1", "pgParameter");
    
    
    /**
     * Gets a List of "pgParameter" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType> getPgParameterList()
    {
        final class PgParameterList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType>
        {
            public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType get(int i)
                { return PgParametersListTypeImpl.this.getPgParameterArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType set(int i, org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType o)
            {
                org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType old = PgParametersListTypeImpl.this.getPgParameterArray(i);
                PgParametersListTypeImpl.this.setPgParameterArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType o)
                { PgParametersListTypeImpl.this.insertNewPgParameter(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType old = PgParametersListTypeImpl.this.getPgParameterArray(i);
                PgParametersListTypeImpl.this.removePgParameter(i);
                return old;
            }
            
            public int size()
                { return PgParametersListTypeImpl.this.sizeOfPgParameterArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PgParameterList();
        }
    }
    
    /**
     * Gets array of all "pgParameter" elements
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType[] getPgParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PGPARAMETER$0, targetList);
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType[] result = new org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pgParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType getPgParameterArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().find_element_user(PGPARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pgParameter" element
     */
    public int sizeOfPgParameterArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PGPARAMETER$0);
        }
    }
    
    /**
     * Sets array of all "pgParameter" element
     */
    public void setPgParameterArray(org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType[] pgParameterArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pgParameterArray, PGPARAMETER$0);
        }
    }
    
    /**
     * Sets ith "pgParameter" element
     */
    public void setPgParameterArray(int i, org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType pgParameter)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().find_element_user(PGPARAMETER$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pgParameter);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pgParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType insertNewPgParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().insert_element_user(PGPARAMETER$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pgParameter" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType addNewPgParameter()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().add_element_user(PGPARAMETER$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pgParameter" element
     */
    public void removePgParameter(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PGPARAMETER$0, i);
        }
    }
}
