/*
 * XML Type:  LodNumSwitchesType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pgp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pgp.v1.impl;
/**
 * An XML LodNumSwitchesType(@http://www.tmforum.org/mtop/nra/xsd/pgp/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType.
 */
public class LodNumSwitchesTypeImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.tmforum.mtop.nra.xsd.pgp.v1.LodNumSwitchesType
{
    
    public LodNumSwitchesTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected LodNumSwitchesTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
