/*
 * An XML document type.
 * Localname: commonResourceModifyData
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/crmd/v1
 * Java type: org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.crmd.v1.impl;
/**
 * A document containing one commonResourceModifyData(@http://www.tmforum.org/mtop/nrb/xsd/crmd/v1) element.
 *
 * This is a complex type.
 */
public class CommonResourceModifyDataDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataDocument
{
    
    public CommonResourceModifyDataDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONRESOURCEMODIFYDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/crmd/v1", "commonResourceModifyData");
    
    
    /**
     * Gets the "commonResourceModifyData" element
     */
    public org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType getCommonResourceModifyData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType target = null;
            target = (org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType)get_store().find_element_user(COMMONRESOURCEMODIFYDATA$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonResourceModifyData" element
     */
    public void setCommonResourceModifyData(org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType commonResourceModifyData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType target = null;
            target = (org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType)get_store().find_element_user(COMMONRESOURCEMODIFYDATA$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType)get_store().add_element_user(COMMONRESOURCEMODIFYDATA$0);
            }
            target.set(commonResourceModifyData);
        }
    }
    
    /**
     * Appends and returns a new empty "commonResourceModifyData" element
     */
    public org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType addNewCommonResourceModifyData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType target = null;
            target = (org.tmforum.mtop.nrb.xsd.crmd.v1.CommonResourceModifyDataType)get_store().add_element_user(COMMONRESOURCEMODIFYDATA$0);
            return target;
        }
    }
}
