/*
 * XML Type:  EquipmentProtectionGroupType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/epg/v1
 * Java type: org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.epg.v1;


/**
 * An XML EquipmentProtectionGroupType(@http://www.tmforum.org/mtop/nra/xsd/epg/v1).
 *
 * This is a complex type.
 */
public interface EquipmentProtectionGroupType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EquipmentProtectionGroupType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2C8DED09A1FFD775DAAB49672DE07087").resolveHandle("equipmentprotectiongrouptype27f8type");
    
    /**
     * Gets the "eProtectionGroupType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType getEProtectionGroupType();
    
    /**
     * Tests for nil "eProtectionGroupType" element
     */
    boolean isNilEProtectionGroupType();
    
    /**
     * True if has "eProtectionGroupType" element
     */
    boolean isSetEProtectionGroupType();
    
    /**
     * Sets the "eProtectionGroupType" element
     */
    void setEProtectionGroupType(org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType eProtectionGroupType);
    
    /**
     * Appends and returns a new empty "eProtectionGroupType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType addNewEProtectionGroupType();
    
    /**
     * Nils the "eProtectionGroupType" element
     */
    void setNilEProtectionGroupType();
    
    /**
     * Unsets the "eProtectionGroupType" element
     */
    void unsetEProtectionGroupType();
    
    /**
     * Gets the "protectionSchemeState" element
     */
    org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType getProtectionSchemeState();
    
    /**
     * Tests for nil "protectionSchemeState" element
     */
    boolean isNilProtectionSchemeState();
    
    /**
     * True if has "protectionSchemeState" element
     */
    boolean isSetProtectionSchemeState();
    
    /**
     * Sets the "protectionSchemeState" element
     */
    void setProtectionSchemeState(org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType protectionSchemeState);
    
    /**
     * Appends and returns a new empty "protectionSchemeState" element
     */
    org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType addNewProtectionSchemeState();
    
    /**
     * Nils the "protectionSchemeState" element
     */
    void setNilProtectionSchemeState();
    
    /**
     * Unsets the "protectionSchemeState" element
     */
    void unsetProtectionSchemeState();
    
    /**
     * Gets the "reversionMode" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum getReversionMode();
    
    /**
     * Gets (as xml) the "reversionMode" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType xgetReversionMode();
    
    /**
     * Tests for nil "reversionMode" element
     */
    boolean isNilReversionMode();
    
    /**
     * True if has "reversionMode" element
     */
    boolean isSetReversionMode();
    
    /**
     * Sets the "reversionMode" element
     */
    void setReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum reversionMode);
    
    /**
     * Sets (as xml) the "reversionMode" element
     */
    void xsetReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType reversionMode);
    
    /**
     * Nils the "reversionMode" element
     */
    void setNilReversionMode();
    
    /**
     * Unsets the "reversionMode" element
     */
    void unsetReversionMode();
    
    /**
     * Gets the "epgParameters" element
     */
    org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters getEpgParameters();
    
    /**
     * Tests for nil "epgParameters" element
     */
    boolean isNilEpgParameters();
    
    /**
     * True if has "epgParameters" element
     */
    boolean isSetEpgParameters();
    
    /**
     * Sets the "epgParameters" element
     */
    void setEpgParameters(org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters epgParameters);
    
    /**
     * Appends and returns a new empty "epgParameters" element
     */
    org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters addNewEpgParameters();
    
    /**
     * Nils the "epgParameters" element
     */
    void setNilEpgParameters();
    
    /**
     * Unsets the "epgParameters" element
     */
    void unsetEpgParameters();
    
    /**
     * Gets the "protectedList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getProtectedList();
    
    /**
     * Tests for nil "protectedList" element
     */
    boolean isNilProtectedList();
    
    /**
     * True if has "protectedList" element
     */
    boolean isSetProtectedList();
    
    /**
     * Sets the "protectedList" element
     */
    void setProtectedList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType protectedList);
    
    /**
     * Appends and returns a new empty "protectedList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewProtectedList();
    
    /**
     * Nils the "protectedList" element
     */
    void setNilProtectedList();
    
    /**
     * Unsets the "protectedList" element
     */
    void unsetProtectedList();
    
    /**
     * Gets the "protectingList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getProtectingList();
    
    /**
     * Tests for nil "protectingList" element
     */
    boolean isNilProtectingList();
    
    /**
     * True if has "protectingList" element
     */
    boolean isSetProtectingList();
    
    /**
     * Sets the "protectingList" element
     */
    void setProtectingList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType protectingList);
    
    /**
     * Appends and returns a new empty "protectingList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewProtectingList();
    
    /**
     * Nils the "protectingList" element
     */
    void setNilProtectingList();
    
    /**
     * Unsets the "protectingList" element
     */
    void unsetProtectingList();
    
    /**
     * Gets the "G_774_3_APSfunction" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType getG7743APSfunction();
    
    /**
     * Tests for nil "G_774_3_APSfunction" element
     */
    boolean isNilG7743APSfunction();
    
    /**
     * True if has "G_774_3_APSfunction" element
     */
    boolean isSetG7743APSfunction();
    
    /**
     * Sets the "G_774_3_APSfunction" element
     */
    void setG7743APSfunction(org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType g7743APSfunction);
    
    /**
     * Appends and returns a new empty "G_774_3_APSfunction" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType addNewG7743APSfunction();
    
    /**
     * Nils the "G_774_3_APSfunction" element
     */
    void setNilG7743APSfunction();
    
    /**
     * Unsets the "G_774_3_APSfunction" element
     */
    void unsetG7743APSfunction();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * An XML epgParameters(@http://www.tmforum.org/mtop/nra/xsd/epg/v1).
     *
     * This is a complex type.
     */
    public interface EpgParameters extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(EpgParameters.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2C8DED09A1FFD775DAAB49672DE07087").resolveHandle("epgparameters2c0aelemtype");
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters newInstance() {
              return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType newInstance() {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
