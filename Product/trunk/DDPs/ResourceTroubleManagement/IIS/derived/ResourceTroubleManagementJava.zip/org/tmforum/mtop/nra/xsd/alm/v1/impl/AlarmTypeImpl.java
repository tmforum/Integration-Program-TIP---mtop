/*
 * XML Type:  AlarmType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alm/v1
 * Java type: org.tmforum.mtop.nra.xsd.alm.v1.AlarmType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alm.v1.impl;
/**
 * An XML AlarmType(@http://www.tmforum.org/mtop/nra/xsd/alm/v1).
 *
 * This is a complex type.
 */
public class AlarmTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoTypeImpl implements org.tmforum.mtop.nra.xsd.alm.v1.AlarmType
{
    
    public AlarmTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "objectType");
    private static final javax.xml.namespace.QName OBJECTNAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "objectName");
    private static final javax.xml.namespace.QName NETIME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "neTime");
    private static final javax.xml.namespace.QName EDGEPOINTRELATED$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "edgePointRelated");
    private static final javax.xml.namespace.QName ISCLEARABLE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "isClearable");
    private static final javax.xml.namespace.QName ALIASNAMELIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "aliasNameList");
    private static final javax.xml.namespace.QName LAYERRATE$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "layerRate");
    private static final javax.xml.namespace.QName PROBABLECAUSE$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "probableCause");
    private static final javax.xml.namespace.QName NATIVEPROBABLECAUSE$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "nativeProbableCause");
    private static final javax.xml.namespace.QName ADDITIONALTEXT$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "additionalText");
    private static final javax.xml.namespace.QName PERCEIVEDSEVERITY$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "perceivedSeverity");
    private static final javax.xml.namespace.QName AFFECTEDTPLIST$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "affectedTpList");
    private static final javax.xml.namespace.QName SERVICEAFFECTING$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "serviceAffecting");
    private static final javax.xml.namespace.QName RCAIINDICATOR$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "rcaiIndicator");
    private static final javax.xml.namespace.QName ACKNOWLEDGEINDICATION$28 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "acknowledgeIndication");
    private static final javax.xml.namespace.QName X733EVENTTYPE$30 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_EventType");
    private static final javax.xml.namespace.QName X733SPECIFICPROBLEMS$32 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_SpecificProblems");
    private static final javax.xml.namespace.QName X733BACKEDUPSTATUS$34 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_BackedUpStatus");
    private static final javax.xml.namespace.QName X733BACKUPOBJECT$36 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_BackUpObject");
    private static final javax.xml.namespace.QName X733TRENDINDICATION$38 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_TrendIndication");
    private static final javax.xml.namespace.QName X733CORRELATEDNOTIFICATIONS$40 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_CorrelatedNotifications");
    private static final javax.xml.namespace.QName X733MONITOREDATTRIBUTES$42 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_MonitoredAttributes");
    private static final javax.xml.namespace.QName X733PROPOSEDREPAIRACTIONS$44 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_ProposedRepairActions");
    
    
    /**
     * Gets the "objectType" element
     */
    public java.lang.String getObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "objectType" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "objectType" element
     */
    public boolean isSetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "objectType" element
     */
    public void setObjectType(java.lang.String objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OBJECTTYPE$0);
            }
            target.setStringValue(objectType);
        }
    }
    
    /**
     * Sets (as xml) the "objectType" element
     */
    public void xsetObjectType(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType objectType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(OBJECTTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().add_element_user(OBJECTTYPE$0);
            }
            target.set(objectType);
        }
    }
    
    /**
     * Unsets the "objectType" element
     */
    public void unsetObjectType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "objectName" element
     */
    public boolean isSetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECTNAME$2) != 0;
        }
    }
    
    /**
     * Sets the "objectName" element
     */
    public void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTNAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$2);
            }
            target.set(objectName);
        }
    }
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTNAME$2);
            return target;
        }
    }
    
    /**
     * Unsets the "objectName" element
     */
    public void unsetObjectName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECTNAME$2, 0);
        }
    }
    
    /**
     * Gets the "neTime" element
     */
    public java.util.Calendar getNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETIME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "neTime" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(NETIME$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "neTime" element
     */
    public boolean isSetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETIME$4) != 0;
        }
    }
    
    /**
     * Sets the "neTime" element
     */
    public void setNeTime(java.util.Calendar neTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETIME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETIME$4);
            }
            target.setCalendarValue(neTime);
        }
    }
    
    /**
     * Sets (as xml) the "neTime" element
     */
    public void xsetNeTime(org.apache.xmlbeans.XmlDateTime neTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(NETIME$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(NETIME$4);
            }
            target.set(neTime);
        }
    }
    
    /**
     * Unsets the "neTime" element
     */
    public void unsetNeTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETIME$4, 0);
        }
    }
    
    /**
     * Gets the "edgePointRelated" element
     */
    public boolean getEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EDGEPOINTRELATED$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "edgePointRelated" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINTRELATED$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "edgePointRelated" element
     */
    public boolean isSetEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EDGEPOINTRELATED$6) != 0;
        }
    }
    
    /**
     * Sets the "edgePointRelated" element
     */
    public void setEdgePointRelated(boolean edgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EDGEPOINTRELATED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EDGEPOINTRELATED$6);
            }
            target.setBooleanValue(edgePointRelated);
        }
    }
    
    /**
     * Sets (as xml) the "edgePointRelated" element
     */
    public void xsetEdgePointRelated(org.apache.xmlbeans.XmlBoolean edgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(EDGEPOINTRELATED$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(EDGEPOINTRELATED$6);
            }
            target.set(edgePointRelated);
        }
    }
    
    /**
     * Unsets the "edgePointRelated" element
     */
    public void unsetEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EDGEPOINTRELATED$6, 0);
        }
    }
    
    /**
     * Gets the "isClearable" element
     */
    public boolean getIsClearable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISCLEARABLE$8, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isClearable" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsClearable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISCLEARABLE$8, 0);
            return target;
        }
    }
    
    /**
     * Sets the "isClearable" element
     */
    public void setIsClearable(boolean isClearable)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISCLEARABLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISCLEARABLE$8);
            }
            target.setBooleanValue(isClearable);
        }
    }
    
    /**
     * Sets (as xml) the "isClearable" element
     */
    public void xsetIsClearable(org.apache.xmlbeans.XmlBoolean isClearable)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISCLEARABLE$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISCLEARABLE$8);
            }
            target.set(isClearable);
        }
    }
    
    /**
     * Gets the "aliasNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "aliasNameList" element
     */
    public boolean isSetAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALIASNAMELIST$10) != 0;
        }
    }
    
    /**
     * Sets the "aliasNameList" element
     */
    public void setAliasNameList(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNameList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$10);
            }
            target.set(aliasNameList);
        }
    }
    
    /**
     * Appends and returns a new empty "aliasNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$10);
            return target;
        }
    }
    
    /**
     * Unsets the "aliasNameList" element
     */
    public void unsetAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALIASNAMELIST$10, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$12);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$12);
            return target;
        }
    }
    
    /**
     * Gets the "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType getProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$14, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "probableCause" element
     */
    public void setProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType probableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$14);
            }
            target.set(probableCause);
        }
    }
    
    /**
     * Appends and returns a new empty "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType addNewProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$14);
            return target;
        }
    }
    
    /**
     * Gets the "nativeProbableCause" element
     */
    public java.lang.String getNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NATIVEPROBABLECAUSE$16, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nativeProbableCause" element
     */
    public org.apache.xmlbeans.XmlString xgetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NATIVEPROBABLECAUSE$16, 0);
            return target;
        }
    }
    
    /**
     * True if has "nativeProbableCause" element
     */
    public boolean isSetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NATIVEPROBABLECAUSE$16) != 0;
        }
    }
    
    /**
     * Sets the "nativeProbableCause" element
     */
    public void setNativeProbableCause(java.lang.String nativeProbableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NATIVEPROBABLECAUSE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NATIVEPROBABLECAUSE$16);
            }
            target.setStringValue(nativeProbableCause);
        }
    }
    
    /**
     * Sets (as xml) the "nativeProbableCause" element
     */
    public void xsetNativeProbableCause(org.apache.xmlbeans.XmlString nativeProbableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NATIVEPROBABLECAUSE$16, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NATIVEPROBABLECAUSE$16);
            }
            target.set(nativeProbableCause);
        }
    }
    
    /**
     * Unsets the "nativeProbableCause" element
     */
    public void unsetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NATIVEPROBABLECAUSE$16, 0);
        }
    }
    
    /**
     * Gets the "additionalText" element
     */
    public java.lang.String getAdditionalText()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADDITIONALTEXT$18, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "additionalText" element
     */
    public org.apache.xmlbeans.XmlString xgetAdditionalText()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ADDITIONALTEXT$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "additionalText" element
     */
    public boolean isSetAdditionalText()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ADDITIONALTEXT$18) != 0;
        }
    }
    
    /**
     * Sets the "additionalText" element
     */
    public void setAdditionalText(java.lang.String additionalText)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADDITIONALTEXT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ADDITIONALTEXT$18);
            }
            target.setStringValue(additionalText);
        }
    }
    
    /**
     * Sets (as xml) the "additionalText" element
     */
    public void xsetAdditionalText(org.apache.xmlbeans.XmlString additionalText)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ADDITIONALTEXT$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ADDITIONALTEXT$18);
            }
            target.set(additionalText);
        }
    }
    
    /**
     * Unsets the "additionalText" element
     */
    public void unsetAdditionalText()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ADDITIONALTEXT$18, 0);
        }
    }
    
    /**
     * Gets the "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum getPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCEIVEDSEVERITY$20, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType xgetPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().find_element_user(PERCEIVEDSEVERITY$20, 0);
            return target;
        }
    }
    
    /**
     * Sets the "perceivedSeverity" element
     */
    public void setPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCEIVEDSEVERITY$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PERCEIVEDSEVERITY$20);
            }
            target.setEnumValue(perceivedSeverity);
        }
    }
    
    /**
     * Sets (as xml) the "perceivedSeverity" element
     */
    public void xsetPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().find_element_user(PERCEIVEDSEVERITY$20, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().add_element_user(PERCEIVEDSEVERITY$20);
            }
            target.set(perceivedSeverity);
        }
    }
    
    /**
     * Gets the "affectedTpList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getAffectedTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(AFFECTEDTPLIST$22, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "affectedTpList" element
     */
    public boolean isSetAffectedTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AFFECTEDTPLIST$22) != 0;
        }
    }
    
    /**
     * Sets the "affectedTpList" element
     */
    public void setAffectedTpList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType affectedTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(AFFECTEDTPLIST$22, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(AFFECTEDTPLIST$22);
            }
            target.set(affectedTpList);
        }
    }
    
    /**
     * Appends and returns a new empty "affectedTpList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewAffectedTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(AFFECTEDTPLIST$22);
            return target;
        }
    }
    
    /**
     * Unsets the "affectedTpList" element
     */
    public void unsetAffectedTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AFFECTEDTPLIST$22, 0);
        }
    }
    
    /**
     * Gets the "serviceAffecting" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum getServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEAFFECTING$24, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceAffecting" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType xgetServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType)get_store().find_element_user(SERVICEAFFECTING$24, 0);
            return target;
        }
    }
    
    /**
     * Sets the "serviceAffecting" element
     */
    public void setServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum serviceAffecting)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEAFFECTING$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICEAFFECTING$24);
            }
            target.setEnumValue(serviceAffecting);
        }
    }
    
    /**
     * Sets (as xml) the "serviceAffecting" element
     */
    public void xsetServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType serviceAffecting)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType)get_store().find_element_user(SERVICEAFFECTING$24, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType)get_store().add_element_user(SERVICEAFFECTING$24);
            }
            target.set(serviceAffecting);
        }
    }
    
    /**
     * Gets the "rcaiIndicator" element
     */
    public boolean getRcaiIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RCAIINDICATOR$26, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "rcaiIndicator" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRcaiIndicator()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(RCAIINDICATOR$26, 0);
            return target;
        }
    }
    
    /**
     * Sets the "rcaiIndicator" element
     */
    public void setRcaiIndicator(boolean rcaiIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RCAIINDICATOR$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RCAIINDICATOR$26);
            }
            target.setBooleanValue(rcaiIndicator);
        }
    }
    
    /**
     * Sets (as xml) the "rcaiIndicator" element
     */
    public void xsetRcaiIndicator(org.apache.xmlbeans.XmlBoolean rcaiIndicator)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(RCAIINDICATOR$26, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(RCAIINDICATOR$26);
            }
            target.set(rcaiIndicator);
        }
    }
    
    /**
     * Gets the "acknowledgeIndication" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum getAcknowledgeIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACKNOWLEDGEINDICATION$28, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "acknowledgeIndication" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType xgetAcknowledgeIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().find_element_user(ACKNOWLEDGEINDICATION$28, 0);
            return target;
        }
    }
    
    /**
     * True if has "acknowledgeIndication" element
     */
    public boolean isSetAcknowledgeIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACKNOWLEDGEINDICATION$28) != 0;
        }
    }
    
    /**
     * Sets the "acknowledgeIndication" element
     */
    public void setAcknowledgeIndication(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum acknowledgeIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACKNOWLEDGEINDICATION$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACKNOWLEDGEINDICATION$28);
            }
            target.setEnumValue(acknowledgeIndication);
        }
    }
    
    /**
     * Sets (as xml) the "acknowledgeIndication" element
     */
    public void xsetAcknowledgeIndication(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType acknowledgeIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().find_element_user(ACKNOWLEDGEINDICATION$28, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().add_element_user(ACKNOWLEDGEINDICATION$28);
            }
            target.set(acknowledgeIndication);
        }
    }
    
    /**
     * Unsets the "acknowledgeIndication" element
     */
    public void unsetAcknowledgeIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACKNOWLEDGEINDICATION$28, 0);
        }
    }
    
    /**
     * Gets the "X733_EventType" element
     */
    public java.lang.String getX733EventType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733EVENTTYPE$30, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "X733_EventType" element
     */
    public org.apache.xmlbeans.XmlString xgetX733EventType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733EVENTTYPE$30, 0);
            return target;
        }
    }
    
    /**
     * True if has "X733_EventType" element
     */
    public boolean isSetX733EventType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733EVENTTYPE$30) != 0;
        }
    }
    
    /**
     * Sets the "X733_EventType" element
     */
    public void setX733EventType(java.lang.String x733EventType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733EVENTTYPE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X733EVENTTYPE$30);
            }
            target.setStringValue(x733EventType);
        }
    }
    
    /**
     * Sets (as xml) the "X733_EventType" element
     */
    public void xsetX733EventType(org.apache.xmlbeans.XmlString x733EventType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733EVENTTYPE$30, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(X733EVENTTYPE$30);
            }
            target.set(x733EventType);
        }
    }
    
    /**
     * Unsets the "X733_EventType" element
     */
    public void unsetX733EventType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733EVENTTYPE$30, 0);
        }
    }
    
    /**
     * Gets the "X733_SpecificProblems" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType getX733SpecificProblems()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType)get_store().find_element_user(X733SPECIFICPROBLEMS$32, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_SpecificProblems" element
     */
    public boolean isSetX733SpecificProblems()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733SPECIFICPROBLEMS$32) != 0;
        }
    }
    
    /**
     * Sets the "X733_SpecificProblems" element
     */
    public void setX733SpecificProblems(org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType x733SpecificProblems)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType)get_store().find_element_user(X733SPECIFICPROBLEMS$32, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType)get_store().add_element_user(X733SPECIFICPROBLEMS$32);
            }
            target.set(x733SpecificProblems);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_SpecificProblems" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType addNewX733SpecificProblems()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType)get_store().add_element_user(X733SPECIFICPROBLEMS$32);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_SpecificProblems" element
     */
    public void unsetX733SpecificProblems()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733SPECIFICPROBLEMS$32, 0);
        }
    }
    
    /**
     * Gets the "X733_BackedUpStatus" element
     */
    public java.lang.String getX733BackedUpStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733BACKEDUPSTATUS$34, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "X733_BackedUpStatus" element
     */
    public org.apache.xmlbeans.XmlString xgetX733BackedUpStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733BACKEDUPSTATUS$34, 0);
            return target;
        }
    }
    
    /**
     * True if has "X733_BackedUpStatus" element
     */
    public boolean isSetX733BackedUpStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733BACKEDUPSTATUS$34) != 0;
        }
    }
    
    /**
     * Sets the "X733_BackedUpStatus" element
     */
    public void setX733BackedUpStatus(java.lang.String x733BackedUpStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733BACKEDUPSTATUS$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X733BACKEDUPSTATUS$34);
            }
            target.setStringValue(x733BackedUpStatus);
        }
    }
    
    /**
     * Sets (as xml) the "X733_BackedUpStatus" element
     */
    public void xsetX733BackedUpStatus(org.apache.xmlbeans.XmlString x733BackedUpStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733BACKEDUPSTATUS$34, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(X733BACKEDUPSTATUS$34);
            }
            target.set(x733BackedUpStatus);
        }
    }
    
    /**
     * Unsets the "X733_BackedUpStatus" element
     */
    public void unsetX733BackedUpStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733BACKEDUPSTATUS$34, 0);
        }
    }
    
    /**
     * Gets the "X733_BackUpObject" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getX733BackUpObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(X733BACKUPOBJECT$36, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_BackUpObject" element
     */
    public boolean isSetX733BackUpObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733BACKUPOBJECT$36) != 0;
        }
    }
    
    /**
     * Sets the "X733_BackUpObject" element
     */
    public void setX733BackUpObject(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType x733BackUpObject)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(X733BACKUPOBJECT$36, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(X733BACKUPOBJECT$36);
            }
            target.set(x733BackUpObject);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_BackUpObject" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewX733BackUpObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(X733BACKUPOBJECT$36);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_BackUpObject" element
     */
    public void unsetX733BackUpObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733BACKUPOBJECT$36, 0);
        }
    }
    
    /**
     * Gets the "X733_TrendIndication" element
     */
    public java.lang.String getX733TrendIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733TRENDINDICATION$38, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "X733_TrendIndication" element
     */
    public org.apache.xmlbeans.XmlString xgetX733TrendIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733TRENDINDICATION$38, 0);
            return target;
        }
    }
    
    /**
     * True if has "X733_TrendIndication" element
     */
    public boolean isSetX733TrendIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733TRENDINDICATION$38) != 0;
        }
    }
    
    /**
     * Sets the "X733_TrendIndication" element
     */
    public void setX733TrendIndication(java.lang.String x733TrendIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733TRENDINDICATION$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X733TRENDINDICATION$38);
            }
            target.setStringValue(x733TrendIndication);
        }
    }
    
    /**
     * Sets (as xml) the "X733_TrendIndication" element
     */
    public void xsetX733TrendIndication(org.apache.xmlbeans.XmlString x733TrendIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733TRENDINDICATION$38, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(X733TRENDINDICATION$38);
            }
            target.set(x733TrendIndication);
        }
    }
    
    /**
     * Unsets the "X733_TrendIndication" element
     */
    public void unsetX733TrendIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733TRENDINDICATION$38, 0);
        }
    }
    
    /**
     * Gets the "X733_CorrelatedNotifications" element
     */
    public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType getX733CorrelatedNotifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType)get_store().find_element_user(X733CORRELATEDNOTIFICATIONS$40, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_CorrelatedNotifications" element
     */
    public boolean isSetX733CorrelatedNotifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733CORRELATEDNOTIFICATIONS$40) != 0;
        }
    }
    
    /**
     * Sets the "X733_CorrelatedNotifications" element
     */
    public void setX733CorrelatedNotifications(org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType x733CorrelatedNotifications)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType)get_store().find_element_user(X733CORRELATEDNOTIFICATIONS$40, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType)get_store().add_element_user(X733CORRELATEDNOTIFICATIONS$40);
            }
            target.set(x733CorrelatedNotifications);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_CorrelatedNotifications" element
     */
    public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType addNewX733CorrelatedNotifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType)get_store().add_element_user(X733CORRELATEDNOTIFICATIONS$40);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_CorrelatedNotifications" element
     */
    public void unsetX733CorrelatedNotifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733CORRELATEDNOTIFICATIONS$40, 0);
        }
    }
    
    /**
     * Gets the "X733_MonitoredAttributes" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType getX733MonitoredAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(X733MONITOREDATTRIBUTES$42, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_MonitoredAttributes" element
     */
    public boolean isSetX733MonitoredAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733MONITOREDATTRIBUTES$42) != 0;
        }
    }
    
    /**
     * Sets the "X733_MonitoredAttributes" element
     */
    public void setX733MonitoredAttributes(org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType x733MonitoredAttributes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(X733MONITOREDATTRIBUTES$42, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(X733MONITOREDATTRIBUTES$42);
            }
            target.set(x733MonitoredAttributes);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_MonitoredAttributes" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType addNewX733MonitoredAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(X733MONITOREDATTRIBUTES$42);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_MonitoredAttributes" element
     */
    public void unsetX733MonitoredAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733MONITOREDATTRIBUTES$42, 0);
        }
    }
    
    /**
     * Gets the "X733_ProposedRepairActions" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType getX733ProposedRepairActions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType)get_store().find_element_user(X733PROPOSEDREPAIRACTIONS$44, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_ProposedRepairActions" element
     */
    public boolean isSetX733ProposedRepairActions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733PROPOSEDREPAIRACTIONS$44) != 0;
        }
    }
    
    /**
     * Sets the "X733_ProposedRepairActions" element
     */
    public void setX733ProposedRepairActions(org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType x733ProposedRepairActions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType)get_store().find_element_user(X733PROPOSEDREPAIRACTIONS$44, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType)get_store().add_element_user(X733PROPOSEDREPAIRACTIONS$44);
            }
            target.set(x733ProposedRepairActions);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_ProposedRepairActions" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType addNewX733ProposedRepairActions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType)get_store().add_element_user(X733PROPOSEDREPAIRACTIONS$44);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_ProposedRepairActions" element
     */
    public void unsetX733ProposedRepairActions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733PROPOSEDREPAIRACTIONS$44, 0);
        }
    }
}
