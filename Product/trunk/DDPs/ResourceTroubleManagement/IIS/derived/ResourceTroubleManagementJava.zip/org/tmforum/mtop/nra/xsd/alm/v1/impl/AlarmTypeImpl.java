/*
 * XML Type:  AlarmType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alm/v1
 * Java type: org.tmforum.mtop.nra.xsd.alm.v1.AlarmType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alm.v1.impl;
/**
 * An XML AlarmType(@http://www.tmforum.org/mtop/nra/xsd/alm/v1).
 *
 * This is a complex type.
 */
public class AlarmTypeImpl extends org.tmforum.mtop.fmw.xsd.ei.v1.impl.EventInformationTypeImpl implements org.tmforum.mtop.nra.xsd.alm.v1.AlarmType
{
    
    public AlarmTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ISEDGEPOINTRELATED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "isEdgePointRelated");
    private static final javax.xml.namespace.QName ISCLEARABLE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "isClearable");
    private static final javax.xml.namespace.QName ALIASNAMELIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "aliasNameList");
    private static final javax.xml.namespace.QName LAYERRATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "layerRate");
    private static final javax.xml.namespace.QName PROBABLECAUSE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "probableCause");
    private static final javax.xml.namespace.QName NATIVEPROBABLECAUSE$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "nativeProbableCause");
    private static final javax.xml.namespace.QName ADDITIONALTEXT$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "additionalText");
    private static final javax.xml.namespace.QName PERCEIVEDSEVERITY$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "perceivedSeverity");
    private static final javax.xml.namespace.QName AFFECTEDTPREFLIST$16 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "affectedTpRefList");
    private static final javax.xml.namespace.QName SERVICEAFFECTING$18 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "serviceAffecting");
    private static final javax.xml.namespace.QName ROOTCAUSEALARMINDICATION$20 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "rootCauseAlarmIndication");
    private static final javax.xml.namespace.QName ACKNOWLEDGEMENT$22 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "acknowledgement");
    private static final javax.xml.namespace.QName X733EVENTTYPE$24 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_EventType");
    private static final javax.xml.namespace.QName X733SPECIFICPROBLEMS$26 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_SpecificProblems");
    private static final javax.xml.namespace.QName X733BACKEDUPSTATUS$28 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_BackedUpStatus");
    private static final javax.xml.namespace.QName X733BACKUPOBJECTREF$30 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_BackUpObjectRef");
    private static final javax.xml.namespace.QName X733TRENDINDICATION$32 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_TrendIndication");
    private static final javax.xml.namespace.QName X733CORRELATEDNOTIFICATIONLIST$34 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_CorrelatedNotificationList");
    private static final javax.xml.namespace.QName X733MONITOREDATTRIBUTELIST$36 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_MonitoredAttributeList");
    private static final javax.xml.namespace.QName X733PROPOSEDREPAIRACTIONLIST$38 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_ProposedRepairActionList");
    private static final javax.xml.namespace.QName X733ADDITIONALINFORMATION$40 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "X733_AdditionalInformation");
    
    
    /**
     * Gets the "isEdgePointRelated" element
     */
    public boolean getIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEDGEPOINTRELATED$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isEdgePointRelated" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINTRELATED$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "isEdgePointRelated" element
     */
    public boolean isSetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISEDGEPOINTRELATED$0) != 0;
        }
    }
    
    /**
     * Sets the "isEdgePointRelated" element
     */
    public void setIsEdgePointRelated(boolean isEdgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISEDGEPOINTRELATED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISEDGEPOINTRELATED$0);
            }
            target.setBooleanValue(isEdgePointRelated);
        }
    }
    
    /**
     * Sets (as xml) the "isEdgePointRelated" element
     */
    public void xsetIsEdgePointRelated(org.apache.xmlbeans.XmlBoolean isEdgePointRelated)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISEDGEPOINTRELATED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISEDGEPOINTRELATED$0);
            }
            target.set(isEdgePointRelated);
        }
    }
    
    /**
     * Unsets the "isEdgePointRelated" element
     */
    public void unsetIsEdgePointRelated()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISEDGEPOINTRELATED$0, 0);
        }
    }
    
    /**
     * Gets the "isClearable" element
     */
    public boolean getIsClearable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISCLEARABLE$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "isClearable" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetIsClearable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISCLEARABLE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "isClearable" element
     */
    public boolean isSetIsClearable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ISCLEARABLE$2) != 0;
        }
    }
    
    /**
     * Sets the "isClearable" element
     */
    public void setIsClearable(boolean isClearable)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ISCLEARABLE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ISCLEARABLE$2);
            }
            target.setBooleanValue(isClearable);
        }
    }
    
    /**
     * Sets (as xml) the "isClearable" element
     */
    public void xsetIsClearable(org.apache.xmlbeans.XmlBoolean isClearable)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ISCLEARABLE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ISCLEARABLE$2);
            }
            target.set(isClearable);
        }
    }
    
    /**
     * Unsets the "isClearable" element
     */
    public void unsetIsClearable()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ISCLEARABLE$2, 0);
        }
    }
    
    /**
     * Gets the "aliasNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "aliasNameList" element
     */
    public boolean isSetAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALIASNAMELIST$4) != 0;
        }
    }
    
    /**
     * Sets the "aliasNameList" element
     */
    public void setAliasNameList(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNameList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().find_element_user(ALIASNAMELIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$4);
            }
            target.set(aliasNameList);
        }
    }
    
    /**
     * Appends and returns a new empty "aliasNameList" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType)get_store().add_element_user(ALIASNAMELIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "aliasNameList" element
     */
    public void unsetAliasNameList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALIASNAMELIST$4, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$6) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            return target;
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$6, 0);
        }
    }
    
    /**
     * Gets the "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType getProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "probableCause" element
     */
    public boolean isSetProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROBABLECAUSE$8) != 0;
        }
    }
    
    /**
     * Sets the "probableCause" element
     */
    public void setProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType probableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$8);
            }
            target.set(probableCause);
        }
    }
    
    /**
     * Appends and returns a new empty "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType addNewProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$8);
            return target;
        }
    }
    
    /**
     * Unsets the "probableCause" element
     */
    public void unsetProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROBABLECAUSE$8, 0);
        }
    }
    
    /**
     * Gets the "nativeProbableCause" element
     */
    public java.lang.String getNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NATIVEPROBABLECAUSE$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nativeProbableCause" element
     */
    public org.apache.xmlbeans.XmlString xgetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NATIVEPROBABLECAUSE$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "nativeProbableCause" element
     */
    public boolean isSetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NATIVEPROBABLECAUSE$10) != 0;
        }
    }
    
    /**
     * Sets the "nativeProbableCause" element
     */
    public void setNativeProbableCause(java.lang.String nativeProbableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NATIVEPROBABLECAUSE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NATIVEPROBABLECAUSE$10);
            }
            target.setStringValue(nativeProbableCause);
        }
    }
    
    /**
     * Sets (as xml) the "nativeProbableCause" element
     */
    public void xsetNativeProbableCause(org.apache.xmlbeans.XmlString nativeProbableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NATIVEPROBABLECAUSE$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NATIVEPROBABLECAUSE$10);
            }
            target.set(nativeProbableCause);
        }
    }
    
    /**
     * Unsets the "nativeProbableCause" element
     */
    public void unsetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NATIVEPROBABLECAUSE$10, 0);
        }
    }
    
    /**
     * Gets the "additionalText" element
     */
    public java.lang.String getAdditionalText()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADDITIONALTEXT$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "additionalText" element
     */
    public org.apache.xmlbeans.XmlString xgetAdditionalText()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ADDITIONALTEXT$12, 0);
            return target;
        }
    }
    
    /**
     * True if has "additionalText" element
     */
    public boolean isSetAdditionalText()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ADDITIONALTEXT$12) != 0;
        }
    }
    
    /**
     * Sets the "additionalText" element
     */
    public void setAdditionalText(java.lang.String additionalText)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ADDITIONALTEXT$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ADDITIONALTEXT$12);
            }
            target.setStringValue(additionalText);
        }
    }
    
    /**
     * Sets (as xml) the "additionalText" element
     */
    public void xsetAdditionalText(org.apache.xmlbeans.XmlString additionalText)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ADDITIONALTEXT$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ADDITIONALTEXT$12);
            }
            target.set(additionalText);
        }
    }
    
    /**
     * Unsets the "additionalText" element
     */
    public void unsetAdditionalText()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ADDITIONALTEXT$12, 0);
        }
    }
    
    /**
     * Gets the "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum getPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCEIVEDSEVERITY$14, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "perceivedSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType xgetPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().find_element_user(PERCEIVEDSEVERITY$14, 0);
            return target;
        }
    }
    
    /**
     * True if has "perceivedSeverity" element
     */
    public boolean isSetPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PERCEIVEDSEVERITY$14) != 0;
        }
    }
    
    /**
     * Sets the "perceivedSeverity" element
     */
    public void setPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PERCEIVEDSEVERITY$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PERCEIVEDSEVERITY$14);
            }
            target.setEnumValue(perceivedSeverity);
        }
    }
    
    /**
     * Sets (as xml) the "perceivedSeverity" element
     */
    public void xsetPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType perceivedSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().find_element_user(PERCEIVEDSEVERITY$14, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType)get_store().add_element_user(PERCEIVEDSEVERITY$14);
            }
            target.set(perceivedSeverity);
        }
    }
    
    /**
     * Unsets the "perceivedSeverity" element
     */
    public void unsetPerceivedSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PERCEIVEDSEVERITY$14, 0);
        }
    }
    
    /**
     * Gets the "affectedTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAffectedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(AFFECTEDTPREFLIST$16, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "affectedTpRefList" element
     */
    public boolean isSetAffectedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AFFECTEDTPREFLIST$16) != 0;
        }
    }
    
    /**
     * Sets the "affectedTpRefList" element
     */
    public void setAffectedTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType affectedTpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(AFFECTEDTPREFLIST$16, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(AFFECTEDTPREFLIST$16);
            }
            target.set(affectedTpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "affectedTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAffectedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(AFFECTEDTPREFLIST$16);
            return target;
        }
    }
    
    /**
     * Unsets the "affectedTpRefList" element
     */
    public void unsetAffectedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AFFECTEDTPREFLIST$16, 0);
        }
    }
    
    /**
     * Gets the "serviceAffecting" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum getServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEAFFECTING$18, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceAffecting" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType xgetServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType)get_store().find_element_user(SERVICEAFFECTING$18, 0);
            return target;
        }
    }
    
    /**
     * True if has "serviceAffecting" element
     */
    public boolean isSetServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICEAFFECTING$18) != 0;
        }
    }
    
    /**
     * Sets the "serviceAffecting" element
     */
    public void setServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum serviceAffecting)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEAFFECTING$18, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICEAFFECTING$18);
            }
            target.setEnumValue(serviceAffecting);
        }
    }
    
    /**
     * Sets (as xml) the "serviceAffecting" element
     */
    public void xsetServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType serviceAffecting)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType)get_store().find_element_user(SERVICEAFFECTING$18, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType)get_store().add_element_user(SERVICEAFFECTING$18);
            }
            target.set(serviceAffecting);
        }
    }
    
    /**
     * Unsets the "serviceAffecting" element
     */
    public void unsetServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICEAFFECTING$18, 0);
        }
    }
    
    /**
     * Gets the "rootCauseAlarmIndication" element
     */
    public boolean getRootCauseAlarmIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROOTCAUSEALARMINDICATION$20, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "rootCauseAlarmIndication" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetRootCauseAlarmIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROOTCAUSEALARMINDICATION$20, 0);
            return target;
        }
    }
    
    /**
     * True if has "rootCauseAlarmIndication" element
     */
    public boolean isSetRootCauseAlarmIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ROOTCAUSEALARMINDICATION$20) != 0;
        }
    }
    
    /**
     * Sets the "rootCauseAlarmIndication" element
     */
    public void setRootCauseAlarmIndication(boolean rootCauseAlarmIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ROOTCAUSEALARMINDICATION$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ROOTCAUSEALARMINDICATION$20);
            }
            target.setBooleanValue(rootCauseAlarmIndication);
        }
    }
    
    /**
     * Sets (as xml) the "rootCauseAlarmIndication" element
     */
    public void xsetRootCauseAlarmIndication(org.apache.xmlbeans.XmlBoolean rootCauseAlarmIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ROOTCAUSEALARMINDICATION$20, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ROOTCAUSEALARMINDICATION$20);
            }
            target.set(rootCauseAlarmIndication);
        }
    }
    
    /**
     * Unsets the "rootCauseAlarmIndication" element
     */
    public void unsetRootCauseAlarmIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ROOTCAUSEALARMINDICATION$20, 0);
        }
    }
    
    /**
     * Gets the "acknowledgement" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum getAcknowledgement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACKNOWLEDGEMENT$22, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "acknowledgement" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType xgetAcknowledgement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().find_element_user(ACKNOWLEDGEMENT$22, 0);
            return target;
        }
    }
    
    /**
     * True if has "acknowledgement" element
     */
    public boolean isSetAcknowledgement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACKNOWLEDGEMENT$22) != 0;
        }
    }
    
    /**
     * Sets the "acknowledgement" element
     */
    public void setAcknowledgement(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum acknowledgement)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACKNOWLEDGEMENT$22, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACKNOWLEDGEMENT$22);
            }
            target.setEnumValue(acknowledgement);
        }
    }
    
    /**
     * Sets (as xml) the "acknowledgement" element
     */
    public void xsetAcknowledgement(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType acknowledgement)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().find_element_user(ACKNOWLEDGEMENT$22, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().add_element_user(ACKNOWLEDGEMENT$22);
            }
            target.set(acknowledgement);
        }
    }
    
    /**
     * Unsets the "acknowledgement" element
     */
    public void unsetAcknowledgement()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACKNOWLEDGEMENT$22, 0);
        }
    }
    
    /**
     * Gets the "X733_EventType" element
     */
    public java.lang.String getX733EventType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733EVENTTYPE$24, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "X733_EventType" element
     */
    public org.apache.xmlbeans.XmlString xgetX733EventType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733EVENTTYPE$24, 0);
            return target;
        }
    }
    
    /**
     * True if has "X733_EventType" element
     */
    public boolean isSetX733EventType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733EVENTTYPE$24) != 0;
        }
    }
    
    /**
     * Sets the "X733_EventType" element
     */
    public void setX733EventType(java.lang.String x733EventType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733EVENTTYPE$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X733EVENTTYPE$24);
            }
            target.setStringValue(x733EventType);
        }
    }
    
    /**
     * Sets (as xml) the "X733_EventType" element
     */
    public void xsetX733EventType(org.apache.xmlbeans.XmlString x733EventType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733EVENTTYPE$24, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(X733EVENTTYPE$24);
            }
            target.set(x733EventType);
        }
    }
    
    /**
     * Unsets the "X733_EventType" element
     */
    public void unsetX733EventType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733EVENTTYPE$24, 0);
        }
    }
    
    /**
     * Gets the "X733_SpecificProblems" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType getX733SpecificProblems()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType)get_store().find_element_user(X733SPECIFICPROBLEMS$26, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_SpecificProblems" element
     */
    public boolean isSetX733SpecificProblems()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733SPECIFICPROBLEMS$26) != 0;
        }
    }
    
    /**
     * Sets the "X733_SpecificProblems" element
     */
    public void setX733SpecificProblems(org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType x733SpecificProblems)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType)get_store().find_element_user(X733SPECIFICPROBLEMS$26, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType)get_store().add_element_user(X733SPECIFICPROBLEMS$26);
            }
            target.set(x733SpecificProblems);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_SpecificProblems" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType addNewX733SpecificProblems()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType)get_store().add_element_user(X733SPECIFICPROBLEMS$26);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_SpecificProblems" element
     */
    public void unsetX733SpecificProblems()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733SPECIFICPROBLEMS$26, 0);
        }
    }
    
    /**
     * Gets the "X733_BackedUpStatus" element
     */
    public java.lang.String getX733BackedUpStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733BACKEDUPSTATUS$28, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "X733_BackedUpStatus" element
     */
    public org.apache.xmlbeans.XmlString xgetX733BackedUpStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733BACKEDUPSTATUS$28, 0);
            return target;
        }
    }
    
    /**
     * True if has "X733_BackedUpStatus" element
     */
    public boolean isSetX733BackedUpStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733BACKEDUPSTATUS$28) != 0;
        }
    }
    
    /**
     * Sets the "X733_BackedUpStatus" element
     */
    public void setX733BackedUpStatus(java.lang.String x733BackedUpStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733BACKEDUPSTATUS$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X733BACKEDUPSTATUS$28);
            }
            target.setStringValue(x733BackedUpStatus);
        }
    }
    
    /**
     * Sets (as xml) the "X733_BackedUpStatus" element
     */
    public void xsetX733BackedUpStatus(org.apache.xmlbeans.XmlString x733BackedUpStatus)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733BACKEDUPSTATUS$28, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(X733BACKEDUPSTATUS$28);
            }
            target.set(x733BackedUpStatus);
        }
    }
    
    /**
     * Unsets the "X733_BackedUpStatus" element
     */
    public void unsetX733BackedUpStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733BACKEDUPSTATUS$28, 0);
        }
    }
    
    /**
     * Gets the "X733_BackUpObjectRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getX733BackUpObjectRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(X733BACKUPOBJECTREF$30, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_BackUpObjectRef" element
     */
    public boolean isSetX733BackUpObjectRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733BACKUPOBJECTREF$30) != 0;
        }
    }
    
    /**
     * Sets the "X733_BackUpObjectRef" element
     */
    public void setX733BackUpObjectRef(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType x733BackUpObjectRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(X733BACKUPOBJECTREF$30, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(X733BACKUPOBJECTREF$30);
            }
            target.set(x733BackUpObjectRef);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_BackUpObjectRef" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewX733BackUpObjectRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(X733BACKUPOBJECTREF$30);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_BackUpObjectRef" element
     */
    public void unsetX733BackUpObjectRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733BACKUPOBJECTREF$30, 0);
        }
    }
    
    /**
     * Gets the "X733_TrendIndication" element
     */
    public java.lang.String getX733TrendIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733TRENDINDICATION$32, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "X733_TrendIndication" element
     */
    public org.apache.xmlbeans.XmlString xgetX733TrendIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733TRENDINDICATION$32, 0);
            return target;
        }
    }
    
    /**
     * True if has "X733_TrendIndication" element
     */
    public boolean isSetX733TrendIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733TRENDINDICATION$32) != 0;
        }
    }
    
    /**
     * Sets the "X733_TrendIndication" element
     */
    public void setX733TrendIndication(java.lang.String x733TrendIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(X733TRENDINDICATION$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(X733TRENDINDICATION$32);
            }
            target.setStringValue(x733TrendIndication);
        }
    }
    
    /**
     * Sets (as xml) the "X733_TrendIndication" element
     */
    public void xsetX733TrendIndication(org.apache.xmlbeans.XmlString x733TrendIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(X733TRENDINDICATION$32, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(X733TRENDINDICATION$32);
            }
            target.set(x733TrendIndication);
        }
    }
    
    /**
     * Unsets the "X733_TrendIndication" element
     */
    public void unsetX733TrendIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733TRENDINDICATION$32, 0);
        }
    }
    
    /**
     * Gets the "X733_CorrelatedNotificationList" element
     */
    public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType getX733CorrelatedNotificationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType)get_store().find_element_user(X733CORRELATEDNOTIFICATIONLIST$34, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_CorrelatedNotificationList" element
     */
    public boolean isSetX733CorrelatedNotificationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733CORRELATEDNOTIFICATIONLIST$34) != 0;
        }
    }
    
    /**
     * Sets the "X733_CorrelatedNotificationList" element
     */
    public void setX733CorrelatedNotificationList(org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType x733CorrelatedNotificationList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType)get_store().find_element_user(X733CORRELATEDNOTIFICATIONLIST$34, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType)get_store().add_element_user(X733CORRELATEDNOTIFICATIONLIST$34);
            }
            target.set(x733CorrelatedNotificationList);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_CorrelatedNotificationList" element
     */
    public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType addNewX733CorrelatedNotificationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType)get_store().add_element_user(X733CORRELATEDNOTIFICATIONLIST$34);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_CorrelatedNotificationList" element
     */
    public void unsetX733CorrelatedNotificationList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733CORRELATEDNOTIFICATIONLIST$34, 0);
        }
    }
    
    /**
     * Gets the "X733_MonitoredAttributeList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType getX733MonitoredAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().find_element_user(X733MONITOREDATTRIBUTELIST$36, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_MonitoredAttributeList" element
     */
    public boolean isSetX733MonitoredAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733MONITOREDATTRIBUTELIST$36) != 0;
        }
    }
    
    /**
     * Sets the "X733_MonitoredAttributeList" element
     */
    public void setX733MonitoredAttributeList(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType x733MonitoredAttributeList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().find_element_user(X733MONITOREDATTRIBUTELIST$36, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().add_element_user(X733MONITOREDATTRIBUTELIST$36);
            }
            target.set(x733MonitoredAttributeList);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_MonitoredAttributeList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType addNewX733MonitoredAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndValueStringListType)get_store().add_element_user(X733MONITOREDATTRIBUTELIST$36);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_MonitoredAttributeList" element
     */
    public void unsetX733MonitoredAttributeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733MONITOREDATTRIBUTELIST$36, 0);
        }
    }
    
    /**
     * Gets the "X733_ProposedRepairActionList" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType getX733ProposedRepairActionList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType)get_store().find_element_user(X733PROPOSEDREPAIRACTIONLIST$38, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_ProposedRepairActionList" element
     */
    public boolean isSetX733ProposedRepairActionList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733PROPOSEDREPAIRACTIONLIST$38) != 0;
        }
    }
    
    /**
     * Sets the "X733_ProposedRepairActionList" element
     */
    public void setX733ProposedRepairActionList(org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType x733ProposedRepairActionList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType)get_store().find_element_user(X733PROPOSEDREPAIRACTIONLIST$38, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType)get_store().add_element_user(X733PROPOSEDREPAIRACTIONLIST$38);
            }
            target.set(x733ProposedRepairActionList);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_ProposedRepairActionList" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType addNewX733ProposedRepairActionList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType)get_store().add_element_user(X733PROPOSEDREPAIRACTIONLIST$38);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_ProposedRepairActionList" element
     */
    public void unsetX733ProposedRepairActionList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733PROPOSEDREPAIRACTIONLIST$38, 0);
        }
    }
    
    /**
     * Gets the "X733_AdditionalInformation" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType getX733AdditionalInformation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType)get_store().find_element_user(X733ADDITIONALINFORMATION$40, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "X733_AdditionalInformation" element
     */
    public boolean isSetX733AdditionalInformation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(X733ADDITIONALINFORMATION$40) != 0;
        }
    }
    
    /**
     * Sets the "X733_AdditionalInformation" element
     */
    public void setX733AdditionalInformation(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType x733AdditionalInformation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType)get_store().find_element_user(X733ADDITIONALINFORMATION$40, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType)get_store().add_element_user(X733ADDITIONALINFORMATION$40);
            }
            target.set(x733AdditionalInformation);
        }
    }
    
    /**
     * Appends and returns a new empty "X733_AdditionalInformation" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType addNewX733AdditionalInformation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType)get_store().add_element_user(X733ADDITIONALINFORMATION$40);
            return target;
        }
    }
    
    /**
     * Unsets the "X733_AdditionalInformation" element
     */
    public void unsetX733AdditionalInformation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(X733ADDITIONALINFORMATION$40, 0);
        }
    }
}
