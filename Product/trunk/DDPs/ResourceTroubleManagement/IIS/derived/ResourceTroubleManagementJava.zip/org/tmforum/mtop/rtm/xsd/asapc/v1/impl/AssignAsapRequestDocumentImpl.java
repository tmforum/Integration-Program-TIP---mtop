/*
 * An XML document type.
 * Localname: assignAsapRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one assignAsapRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class AssignAsapRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument
{
    
    public AssignAsapRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASSIGNASAPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "assignAsapRequest");
    
    
    /**
     * Gets the "assignAsapRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest getAssignAsapRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest)get_store().find_element_user(ASSIGNASAPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "assignAsapRequest" element
     */
    public void setAssignAsapRequest(org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest assignAsapRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest)get_store().find_element_user(ASSIGNASAPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest)get_store().add_element_user(ASSIGNASAPREQUEST$0);
            }
            target.set(assignAsapRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "assignAsapRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest addNewAssignAsapRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest)get_store().add_element_user(ASSIGNASAPREQUEST$0);
            return target;
        }
    }
    /**
     * An XML assignAsapRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class AssignAsapRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAsapRequestDocument.AssignAsapRequest
    {
        
        public AssignAsapRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "asapName");
        private static final javax.xml.namespace.QName RESOURCENAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "resourceName");
        private static final javax.xml.namespace.QName LAYERRATE$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "layerRate");
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "vendorExtensions");
        
        
        /**
         * Gets the "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "asapName" element
         */
        public boolean isNilAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "asapName" element
         */
        public boolean isSetAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "asapName" element
         */
        public void setAsapName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType asapName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ASAPNAME$0);
                }
                target.set(asapName);
            }
        }
        
        /**
         * Appends and returns a new empty "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ASAPNAME$0);
                return target;
            }
        }
        
        /**
         * Nils the "asapName" element
         */
        public void setNilAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ASAPNAME$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "asapName" element
         */
        public void unsetAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPNAME$0, 0);
            }
        }
        
        /**
         * Gets the "resourceName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(RESOURCENAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "resourceName" element
         */
        public boolean isNilResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(RESOURCENAME$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "resourceName" element
         */
        public boolean isSetResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(RESOURCENAME$2) != 0;
            }
        }
        
        /**
         * Sets the "resourceName" element
         */
        public void setResourceName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType resourceName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(RESOURCENAME$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(RESOURCENAME$2);
                }
                target.set(resourceName);
            }
        }
        
        /**
         * Appends and returns a new empty "resourceName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(RESOURCENAME$2);
                return target;
            }
        }
        
        /**
         * Nils the "resourceName" element
         */
        public void setNilResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(RESOURCENAME$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(RESOURCENAME$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "resourceName" element
         */
        public void unsetResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(RESOURCENAME$2, 0);
            }
        }
        
        /**
         * Gets the "layerRate" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "layerRate" element
         */
        public boolean isNilLayerRate()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "layerRate" element
         */
        public boolean isSetLayerRate()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LAYERRATE$4) != 0;
            }
        }
        
        /**
         * Sets the "layerRate" element
         */
        public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$4);
                }
                target.set(layerRate);
            }
        }
        
        /**
         * Appends and returns a new empty "layerRate" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$4);
                return target;
            }
        }
        
        /**
         * Nils the "layerRate" element
         */
        public void setNilLayerRate()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$4);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "layerRate" element
         */
        public void unsetLayerRate()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LAYERRATE$4, 0);
            }
        }
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        public boolean isNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$6) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                return target;
            }
        }
        
        /**
         * Nils the "vendorExtensions" element
         */
        public void setNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$6, 0);
            }
        }
    }
}
