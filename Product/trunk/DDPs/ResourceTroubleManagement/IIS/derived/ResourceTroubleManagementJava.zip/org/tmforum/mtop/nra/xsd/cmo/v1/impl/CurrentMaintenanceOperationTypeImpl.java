/*
 * XML Type:  CurrentMaintenanceOperationType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/cmo/v1
 * Java type: org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.cmo.v1.impl;
/**
 * An XML CurrentMaintenanceOperationType(@http://www.tmforum.org/mtop/nra/xsd/cmo/v1).
 *
 * This is a complex type.
 */
public class CurrentMaintenanceOperationTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType
{
    
    public CurrentMaintenanceOperationTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TPNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/cmo/v1", "tpName");
    private static final javax.xml.namespace.QName MAINTENANCEOPERATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/cmo/v1", "maintenanceOperation");
    private static final javax.xml.namespace.QName LAYERRATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/cmo/v1", "layerRate");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/cmo/v1", "vendorExtensions");
    
    
    /**
     * Gets the "tpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tpName" element
     */
    public boolean isSetTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TPNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "tpName" element
     */
    public void setTpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType tpName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(TPNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(TPNAME$0);
            }
            target.set(tpName);
        }
    }
    
    /**
     * Appends and returns a new empty "tpName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(TPNAME$0);
            return target;
        }
    }
    
    /**
     * Unsets the "tpName" element
     */
    public void unsetTpName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TPNAME$0, 0);
        }
    }
    
    /**
     * Gets the "maintenanceOperation" element
     */
    public java.lang.String getMaintenanceOperation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAINTENANCEOPERATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "maintenanceOperation" element
     */
    public org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType xgetMaintenanceOperation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType target = null;
            target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType)get_store().find_element_user(MAINTENANCEOPERATION$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "maintenanceOperation" element
     */
    public boolean isSetMaintenanceOperation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MAINTENANCEOPERATION$2) != 0;
        }
    }
    
    /**
     * Sets the "maintenanceOperation" element
     */
    public void setMaintenanceOperation(java.lang.String maintenanceOperation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(MAINTENANCEOPERATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(MAINTENANCEOPERATION$2);
            }
            target.setStringValue(maintenanceOperation);
        }
    }
    
    /**
     * Sets (as xml) the "maintenanceOperation" element
     */
    public void xsetMaintenanceOperation(org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType maintenanceOperation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType target = null;
            target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType)get_store().find_element_user(MAINTENANCEOPERATION$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.MaintenanceOperationType)get_store().add_element_user(MAINTENANCEOPERATION$2);
            }
            target.set(maintenanceOperation);
        }
    }
    
    /**
     * Unsets the "maintenanceOperation" element
     */
    public void unsetMaintenanceOperation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MAINTENANCEOPERATION$2, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$4) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$4);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$4);
            return target;
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$4, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "vendorExtensions" element
     */
    public boolean isNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$6) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
            return target;
        }
    }
    
    /**
     * Nils the "vendorExtensions" element
     */
    public void setNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$6, 0);
        }
    }
}
