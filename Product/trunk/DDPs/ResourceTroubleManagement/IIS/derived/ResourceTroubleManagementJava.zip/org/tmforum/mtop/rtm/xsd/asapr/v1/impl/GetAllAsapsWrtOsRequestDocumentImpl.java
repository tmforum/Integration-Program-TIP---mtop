/*
 * An XML document type.
 * Localname: getAllAsapsWrtOsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAsapsWrtOsRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAsapsWrtOsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument
{
    
    public GetAllAsapsWrtOsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLASAPSWRTOSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAsapsWrtOsRequest");
    
    
    /**
     * Gets the "getAllAsapsWrtOsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest getGetAllAsapsWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest)get_store().find_element_user(GETALLASAPSWRTOSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAsapsWrtOsRequest" element
     */
    public void setGetAllAsapsWrtOsRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest getAllAsapsWrtOsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest)get_store().find_element_user(GETALLASAPSWRTOSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest)get_store().add_element_user(GETALLASAPSWRTOSREQUEST$0);
            }
            target.set(getAllAsapsWrtOsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAsapsWrtOsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest addNewGetAllAsapsWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest)get_store().add_element_user(GETALLASAPSWRTOSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllAsapsWrtOsRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAsapsWrtOsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapsWrtOsRequestDocument.GetAllAsapsWrtOsRequest
    {
        
        public GetAllAsapsWrtOsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OSNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "osName");
        
        
        /**
         * Gets the "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "osName" element
         */
        public void setOsName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType osName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OSNAME$0);
                }
                target.set(osName);
            }
        }
        
        /**
         * Appends and returns a new empty "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OSNAME$0);
                return target;
            }
        }
    }
}
