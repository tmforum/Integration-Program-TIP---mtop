/*
 * An XML document type.
 * Localname: deleteAsapException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one deleteAsapException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class DeleteAsapExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument
{
    
    public DeleteAsapExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETEASAPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "deleteAsapException");
    
    
    /**
     * Gets the "deleteAsapException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException getDeleteAsapException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException)get_store().find_element_user(DELETEASAPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteAsapException" element
     */
    public void setDeleteAsapException(org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException deleteAsapException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException)get_store().find_element_user(DELETEASAPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException)get_store().add_element_user(DELETEASAPEXCEPTION$0);
            }
            target.set(deleteAsapException);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteAsapException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException addNewDeleteAsapException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException)get_store().add_element_user(DELETEASAPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deleteAsapException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class DeleteAsapExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAsapExceptionDocument.DeleteAsapException
    {
        
        public DeleteAsapExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
