/*
 * An XML document type.
 * Localname: getAllAsapNamesWrtOsException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAsapNamesWrtOsException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAsapNamesWrtOsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument
{
    
    public GetAllAsapNamesWrtOsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLASAPNAMESWRTOSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAsapNamesWrtOsException");
    
    
    /**
     * Gets the "getAllAsapNamesWrtOsException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException getGetAllAsapNamesWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException)get_store().find_element_user(GETALLASAPNAMESWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAsapNamesWrtOsException" element
     */
    public void setGetAllAsapNamesWrtOsException(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException getAllAsapNamesWrtOsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException)get_store().find_element_user(GETALLASAPNAMESWRTOSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException)get_store().add_element_user(GETALLASAPNAMESWRTOSEXCEPTION$0);
            }
            target.set(getAllAsapNamesWrtOsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAsapNamesWrtOsException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException addNewGetAllAsapNamesWrtOsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException)get_store().add_element_user(GETALLASAPNAMESWRTOSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllAsapNamesWrtOsException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAsapNamesWrtOsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsExceptionDocument.GetAllAsapNamesWrtOsException
    {
        
        public GetAllAsapNamesWrtOsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
