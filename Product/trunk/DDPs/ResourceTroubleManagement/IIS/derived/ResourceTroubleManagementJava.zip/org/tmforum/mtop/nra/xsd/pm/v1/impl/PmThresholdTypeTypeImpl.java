/*
 * XML Type:  PmThresholdTypeType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pm/v1
 * Java type: org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pm.v1.impl;
/**
 * An XML PmThresholdTypeType(@http://www.tmforum.org/mtop/nra/xsd/pm/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType.
 */
public class PmThresholdTypeTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.pm.v1.PmThresholdTypeType
{
    
    public PmThresholdTypeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected PmThresholdTypeTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
