/*
 * An XML document type.
 * Localname: getAllAsapNamesWrtOsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAsapNamesWrtOsRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAsapNamesWrtOsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument
{
    
    public GetAllAsapNamesWrtOsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLASAPNAMESWRTOSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAsapNamesWrtOsRequest");
    
    
    /**
     * Gets the "getAllAsapNamesWrtOsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest getGetAllAsapNamesWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest)get_store().find_element_user(GETALLASAPNAMESWRTOSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAsapNamesWrtOsRequest" element
     */
    public void setGetAllAsapNamesWrtOsRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest getAllAsapNamesWrtOsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest)get_store().find_element_user(GETALLASAPNAMESWRTOSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest)get_store().add_element_user(GETALLASAPNAMESWRTOSREQUEST$0);
            }
            target.set(getAllAsapNamesWrtOsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAsapNamesWrtOsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest addNewGetAllAsapNamesWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest)get_store().add_element_user(GETALLASAPNAMESWRTOSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllAsapNamesWrtOsRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAsapNamesWrtOsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAsapNamesWrtOsRequestDocument.GetAllAsapNamesWrtOsRequest
    {
        
        public GetAllAsapNamesWrtOsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OSNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "osName");
        
        
        /**
         * Gets the "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "osName" element
         */
        public void setOsName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType osName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OSNAME$0);
                }
                target.set(osName);
            }
        }
        
        /**
         * Appends and returns a new empty "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OSNAME$0);
                return target;
            }
        }
    }
}
