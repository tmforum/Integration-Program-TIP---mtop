/*
 * An XML document type.
 * Localname: setAlarmReportingOnException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setAlarmReportingOnException(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetAlarmReportingOnExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument
{
    
    public SetAlarmReportingOnExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALARMREPORTINGONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setAlarmReportingOnException");
    
    
    /**
     * Gets the "setAlarmReportingOnException" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException getSetAlarmReportingOnException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException)get_store().find_element_user(SETALARMREPORTINGONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAlarmReportingOnException" element
     */
    public void setSetAlarmReportingOnException(org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException setAlarmReportingOnException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException)get_store().find_element_user(SETALARMREPORTINGONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException)get_store().add_element_user(SETALARMREPORTINGONEXCEPTION$0);
            }
            target.set(setAlarmReportingOnException);
        }
    }
    
    /**
     * Appends and returns a new empty "setAlarmReportingOnException" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException addNewSetAlarmReportingOnException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException)get_store().add_element_user(SETALARMREPORTINGONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setAlarmReportingOnException(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetAlarmReportingOnExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnExceptionDocument.SetAlarmReportingOnException
    {
        
        public SetAlarmReportingOnExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
