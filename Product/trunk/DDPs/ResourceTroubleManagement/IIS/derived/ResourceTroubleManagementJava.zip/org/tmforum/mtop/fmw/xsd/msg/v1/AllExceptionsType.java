/*
 * XML Type:  AllExceptionsType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1;


/**
 * An XML AllExceptionsType(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1).
 *
 * This is a complex type.
 */
public interface AllExceptionsType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AllExceptionsType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sBE6052E03D6741DEC166ADB27BB9B6C3").resolveHandle("allexceptionstypea765type");
    
    /**
     * Gets the "accessDenied" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getAccessDenied();
    
    /**
     * True if has "accessDenied" element
     */
    boolean isSetAccessDenied();
    
    /**
     * Sets the "accessDenied" element
     */
    void setAccessDenied(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType accessDenied);
    
    /**
     * Appends and returns a new empty "accessDenied" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewAccessDenied();
    
    /**
     * Unsets the "accessDenied" element
     */
    void unsetAccessDenied();
    
    /**
     * Gets the "capacityExceeded" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getCapacityExceeded();
    
    /**
     * True if has "capacityExceeded" element
     */
    boolean isSetCapacityExceeded();
    
    /**
     * Sets the "capacityExceeded" element
     */
    void setCapacityExceeded(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType capacityExceeded);
    
    /**
     * Appends and returns a new empty "capacityExceeded" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewCapacityExceeded();
    
    /**
     * Unsets the "capacityExceeded" element
     */
    void unsetCapacityExceeded();
    
    /**
     * Gets the "communicationFailure" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getCommunicationFailure();
    
    /**
     * True if has "communicationFailure" element
     */
    boolean isSetCommunicationFailure();
    
    /**
     * Sets the "communicationFailure" element
     */
    void setCommunicationFailure(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType communicationFailure);
    
    /**
     * Appends and returns a new empty "communicationFailure" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewCommunicationFailure();
    
    /**
     * Unsets the "communicationFailure" element
     */
    void unsetCommunicationFailure();
    
    /**
     * Gets the "entityNotFound" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getEntityNotFound();
    
    /**
     * True if has "entityNotFound" element
     */
    boolean isSetEntityNotFound();
    
    /**
     * Sets the "entityNotFound" element
     */
    void setEntityNotFound(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType entityNotFound);
    
    /**
     * Appends and returns a new empty "entityNotFound" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewEntityNotFound();
    
    /**
     * Unsets the "entityNotFound" element
     */
    void unsetEntityNotFound();
    
    /**
     * Gets the "internalError" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInternalError();
    
    /**
     * True if has "internalError" element
     */
    boolean isSetInternalError();
    
    /**
     * Sets the "internalError" element
     */
    void setInternalError(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType internalError);
    
    /**
     * Appends and returns a new empty "internalError" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInternalError();
    
    /**
     * Unsets the "internalError" element
     */
    void unsetInternalError();
    
    /**
     * Gets the "invalidFilterDefinition" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInvalidFilterDefinition();
    
    /**
     * True if has "invalidFilterDefinition" element
     */
    boolean isSetInvalidFilterDefinition();
    
    /**
     * Sets the "invalidFilterDefinition" element
     */
    void setInvalidFilterDefinition(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType invalidFilterDefinition);
    
    /**
     * Appends and returns a new empty "invalidFilterDefinition" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInvalidFilterDefinition();
    
    /**
     * Unsets the "invalidFilterDefinition" element
     */
    void unsetInvalidFilterDefinition();
    
    /**
     * Gets the "invalidInput" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInvalidInput();
    
    /**
     * True if has "invalidInput" element
     */
    boolean isSetInvalidInput();
    
    /**
     * Sets the "invalidInput" element
     */
    void setInvalidInput(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType invalidInput);
    
    /**
     * Appends and returns a new empty "invalidInput" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInvalidInput();
    
    /**
     * Unsets the "invalidInput" element
     */
    void unsetInvalidInput();
    
    /**
     * Gets the "invalidTopic" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getInvalidTopic();
    
    /**
     * True if has "invalidTopic" element
     */
    boolean isSetInvalidTopic();
    
    /**
     * Sets the "invalidTopic" element
     */
    void setInvalidTopic(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType invalidTopic);
    
    /**
     * Appends and returns a new empty "invalidTopic" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewInvalidTopic();
    
    /**
     * Unsets the "invalidTopic" element
     */
    void unsetInvalidTopic();
    
    /**
     * Gets the "notificationServiceProblem" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getNotificationServiceProblem();
    
    /**
     * True if has "notificationServiceProblem" element
     */
    boolean isSetNotificationServiceProblem();
    
    /**
     * Sets the "notificationServiceProblem" element
     */
    void setNotificationServiceProblem(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType notificationServiceProblem);
    
    /**
     * Appends and returns a new empty "notificationServiceProblem" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewNotificationServiceProblem();
    
    /**
     * Unsets the "notificationServiceProblem" element
     */
    void unsetNotificationServiceProblem();
    
    /**
     * Gets the "notImplemented" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getNotImplemented();
    
    /**
     * True if has "notImplemented" element
     */
    boolean isSetNotImplemented();
    
    /**
     * Sets the "notImplemented" element
     */
    void setNotImplemented(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType notImplemented);
    
    /**
     * Appends and returns a new empty "notImplemented" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewNotImplemented();
    
    /**
     * Unsets the "notImplemented" element
     */
    void unsetNotImplemented();
    
    /**
     * Gets the "notInValidState" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getNotInValidState();
    
    /**
     * True if has "notInValidState" element
     */
    boolean isSetNotInValidState();
    
    /**
     * Sets the "notInValidState" element
     */
    void setNotInValidState(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType notInValidState);
    
    /**
     * Appends and returns a new empty "notInValidState" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewNotInValidState();
    
    /**
     * Unsets the "notInValidState" element
     */
    void unsetNotInValidState();
    
    /**
     * Gets the "objectInUse" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getObjectInUse();
    
    /**
     * True if has "objectInUse" element
     */
    boolean isSetObjectInUse();
    
    /**
     * Sets the "objectInUse" element
     */
    void setObjectInUse(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType objectInUse);
    
    /**
     * Appends and returns a new empty "objectInUse" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewObjectInUse();
    
    /**
     * Unsets the "objectInUse" element
     */
    void unsetObjectInUse();
    
    /**
     * Gets the "protectionEffortNotMet" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getProtectionEffortNotMet();
    
    /**
     * True if has "protectionEffortNotMet" element
     */
    boolean isSetProtectionEffortNotMet();
    
    /**
     * Sets the "protectionEffortNotMet" element
     */
    void setProtectionEffortNotMet(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType protectionEffortNotMet);
    
    /**
     * Appends and returns a new empty "protectionEffortNotMet" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewProtectionEffortNotMet();
    
    /**
     * Unsets the "protectionEffortNotMet" element
     */
    void unsetProtectionEffortNotMet();
    
    /**
     * Gets the "timeslotInUse" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getTimeslotInUse();
    
    /**
     * True if has "timeslotInUse" element
     */
    boolean isSetTimeslotInUse();
    
    /**
     * Sets the "timeslotInUse" element
     */
    void setTimeslotInUse(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType timeslotInUse);
    
    /**
     * Appends and returns a new empty "timeslotInUse" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewTimeslotInUse();
    
    /**
     * Unsets the "timeslotInUse" element
     */
    void unsetTimeslotInUse();
    
    /**
     * Gets the "tooManyOpenIterators" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getTooManyOpenIterators();
    
    /**
     * True if has "tooManyOpenIterators" element
     */
    boolean isSetTooManyOpenIterators();
    
    /**
     * Sets the "tooManyOpenIterators" element
     */
    void setTooManyOpenIterators(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType tooManyOpenIterators);
    
    /**
     * Appends and returns a new empty "tooManyOpenIterators" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewTooManyOpenIterators();
    
    /**
     * Unsets the "tooManyOpenIterators" element
     */
    void unsetTooManyOpenIterators();
    
    /**
     * Gets the "tpInvalidEndPoint" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getTpInvalidEndPoint();
    
    /**
     * True if has "tpInvalidEndPoint" element
     */
    boolean isSetTpInvalidEndPoint();
    
    /**
     * Sets the "tpInvalidEndPoint" element
     */
    void setTpInvalidEndPoint(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType tpInvalidEndPoint);
    
    /**
     * Appends and returns a new empty "tpInvalidEndPoint" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewTpInvalidEndPoint();
    
    /**
     * Unsets the "tpInvalidEndPoint" element
     */
    void unsetTpInvalidEndPoint();
    
    /**
     * Gets the "unableToComply" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnableToComply();
    
    /**
     * True if has "unableToComply" element
     */
    boolean isSetUnableToComply();
    
    /**
     * Sets the "unableToComply" element
     */
    void setUnableToComply(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unableToComply);
    
    /**
     * Appends and returns a new empty "unableToComply" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnableToComply();
    
    /**
     * Unsets the "unableToComply" element
     */
    void unsetUnableToComply();
    
    /**
     * Gets the "unsupportedCompressionFormat" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnsupportedCompressionFormat();
    
    /**
     * True if has "unsupportedCompressionFormat" element
     */
    boolean isSetUnsupportedCompressionFormat();
    
    /**
     * Sets the "unsupportedCompressionFormat" element
     */
    void setUnsupportedCompressionFormat(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unsupportedCompressionFormat);
    
    /**
     * Appends and returns a new empty "unsupportedCompressionFormat" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnsupportedCompressionFormat();
    
    /**
     * Unsets the "unsupportedCompressionFormat" element
     */
    void unsetUnsupportedCompressionFormat();
    
    /**
     * Gets the "unsupportedPackingFormat" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnsupportedPackingFormat();
    
    /**
     * True if has "unsupportedPackingFormat" element
     */
    boolean isSetUnsupportedPackingFormat();
    
    /**
     * Sets the "unsupportedPackingFormat" element
     */
    void setUnsupportedPackingFormat(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unsupportedPackingFormat);
    
    /**
     * Appends and returns a new empty "unsupportedPackingFormat" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnsupportedPackingFormat();
    
    /**
     * Unsets the "unsupportedPackingFormat" element
     */
    void unsetUnsupportedPackingFormat();
    
    /**
     * Gets the "unsupportedRoutingConstraints" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnsupportedRoutingConstraints();
    
    /**
     * True if has "unsupportedRoutingConstraints" element
     */
    boolean isSetUnsupportedRoutingConstraints();
    
    /**
     * Sets the "unsupportedRoutingConstraints" element
     */
    void setUnsupportedRoutingConstraints(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unsupportedRoutingConstraints);
    
    /**
     * Appends and returns a new empty "unsupportedRoutingConstraints" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnsupportedRoutingConstraints();
    
    /**
     * Unsets the "unsupportedRoutingConstraints" element
     */
    void unsetUnsupportedRoutingConstraints();
    
    /**
     * Gets the "userlabelInUse" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUserlabelInUse();
    
    /**
     * True if has "userlabelInUse" element
     */
    boolean isSetUserlabelInUse();
    
    /**
     * Sets the "userlabelInUse" element
     */
    void setUserlabelInUse(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType userlabelInUse);
    
    /**
     * Appends and returns a new empty "userlabelInUse" element
     */
    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUserlabelInUse();
    
    /**
     * Unsets the "userlabelInUse" element
     */
    void unsetUserlabelInUse();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType newInstance() {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.fmw.xsd.msg.v1.AllExceptionsType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
