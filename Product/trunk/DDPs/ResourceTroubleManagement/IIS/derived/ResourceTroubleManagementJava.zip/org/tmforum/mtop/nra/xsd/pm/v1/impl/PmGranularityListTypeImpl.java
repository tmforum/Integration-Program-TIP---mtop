/*
 * XML Type:  PmGranularityListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pm/v1
 * Java type: org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pm.v1.impl;
/**
 * An XML PmGranularityListType(@http://www.tmforum.org/mtop/nra/xsd/pm/v1).
 *
 * This is a complex type.
 */
public class PmGranularityListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityListType
{
    
    public PmGranularityListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMGRANULARITY$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pm/v1", "pmGranularity");
    
    
    /**
     * Gets a List of "pmGranularity" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum> getPmGranularityList()
    {
        final class PmGranularityList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum get(int i)
                { return PmGranularityListTypeImpl.this.getPmGranularityArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum old = PmGranularityListTypeImpl.this.getPmGranularityArray(i);
                PmGranularityListTypeImpl.this.setPmGranularityArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum o)
                { PmGranularityListTypeImpl.this.insertPmGranularity(i, o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum old = PmGranularityListTypeImpl.this.getPmGranularityArray(i);
                PmGranularityListTypeImpl.this.removePmGranularity(i);
                return old;
            }
            
            public int size()
                { return PmGranularityListTypeImpl.this.sizeOfPmGranularityArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmGranularityList();
        }
    }
    
    /**
     * Gets array of all "pmGranularity" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum[] getPmGranularityArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMGRANULARITY$0, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
            return result;
        }
    }
    
    /**
     * Gets ith "pmGranularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getPmGranularityArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMGRANULARITY$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "pmGranularity" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType> xgetPmGranularityList()
    {
        final class PmGranularityList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType get(int i)
                { return PmGranularityListTypeImpl.this.xgetPmGranularityArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType old = PmGranularityListTypeImpl.this.xgetPmGranularityArray(i);
                PmGranularityListTypeImpl.this.xsetPmGranularityArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType o)
                { PmGranularityListTypeImpl.this.insertNewPmGranularity(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType old = PmGranularityListTypeImpl.this.xgetPmGranularityArray(i);
                PmGranularityListTypeImpl.this.removePmGranularity(i);
                return old;
            }
            
            public int size()
                { return PmGranularityListTypeImpl.this.sizeOfPmGranularityArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmGranularityList();
        }
    }
    
    /**
     * Gets (as xml) array of all "pmGranularity" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType[] xgetPmGranularityArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMGRANULARITY$0, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "pmGranularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetPmGranularityArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(PMGRANULARITY$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)target;
        }
    }
    
    /**
     * Returns number of "pmGranularity" element
     */
    public int sizeOfPmGranularityArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMGRANULARITY$0);
        }
    }
    
    /**
     * Sets array of all "pmGranularity" element
     */
    public void setPmGranularityArray(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum[] pmGranularityArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmGranularityArray, PMGRANULARITY$0);
        }
    }
    
    /**
     * Sets ith "pmGranularity" element
     */
    public void setPmGranularityArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum pmGranularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMGRANULARITY$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setEnumValue(pmGranularity);
        }
    }
    
    /**
     * Sets (as xml) array of all "pmGranularity" element
     */
    public void xsetPmGranularityArray(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType[]pmGranularityArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmGranularityArray, PMGRANULARITY$0);
        }
    }
    
    /**
     * Sets (as xml) ith "pmGranularity" element
     */
    public void xsetPmGranularityArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType pmGranularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().find_element_user(PMGRANULARITY$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmGranularity);
        }
    }
    
    /**
     * Inserts the value as the ith "pmGranularity" element
     */
    public void insertPmGranularity(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum pmGranularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PMGRANULARITY$0, i);
            target.setEnumValue(pmGranularity);
        }
    }
    
    /**
     * Appends the value as the last "pmGranularity" element
     */
    public void addPmGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum pmGranularity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMGRANULARITY$0);
            target.setEnumValue(pmGranularity);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmGranularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType insertNewPmGranularity(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().insert_element_user(PMGRANULARITY$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmGranularity" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType addNewPmGranularity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType)get_store().add_element_user(PMGRANULARITY$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmGranularity" element
     */
    public void removePmGranularity(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMGRANULARITY$0, i);
        }
    }
}
