/*
 * An XML document type.
 * Localname: getActiveMaintenanceOperationsIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/mc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.mc.v1.impl;
/**
 * A document containing one getActiveMaintenanceOperationsIteratorRequest(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveMaintenanceOperationsIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument
{
    
    public GetActiveMaintenanceOperationsIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEMAINTENANCEOPERATIONSITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "getActiveMaintenanceOperationsIteratorRequest");
    
    
    /**
     * Gets the "getActiveMaintenanceOperationsIteratorRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest getGetActiveMaintenanceOperationsIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveMaintenanceOperationsIteratorRequest" element
     */
    public void setGetActiveMaintenanceOperationsIteratorRequest(org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest getActiveMaintenanceOperationsIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATORREQUEST$0);
            }
            target.set(getActiveMaintenanceOperationsIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveMaintenanceOperationsIteratorRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest addNewGetActiveMaintenanceOperationsIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATORREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getActiveMaintenanceOperationsIteratorRequest(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1).
     *
     * This is a complex type.
     */
    public static class GetActiveMaintenanceOperationsIteratorRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorRequestDocument.GetActiveMaintenanceOperationsIteratorRequest
    {
        
        public GetActiveMaintenanceOperationsIteratorRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
