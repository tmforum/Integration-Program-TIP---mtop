/*
 * An XML document type.
 * Localname: setAlarmReportingOnRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setAlarmReportingOnRequest(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetAlarmReportingOnRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument
{
    
    public SetAlarmReportingOnRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALARMREPORTINGONREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setAlarmReportingOnRequest");
    
    
    /**
     * Gets the "setAlarmReportingOnRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest getSetAlarmReportingOnRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest)get_store().find_element_user(SETALARMREPORTINGONREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAlarmReportingOnRequest" element
     */
    public void setSetAlarmReportingOnRequest(org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest setAlarmReportingOnRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest)get_store().find_element_user(SETALARMREPORTINGONREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest)get_store().add_element_user(SETALARMREPORTINGONREQUEST$0);
            }
            target.set(setAlarmReportingOnRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setAlarmReportingOnRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest addNewSetAlarmReportingOnRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest)get_store().add_element_user(SETALARMREPORTINGONREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setAlarmReportingOnRequest(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetAlarmReportingOnRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOnRequestDocument.SetAlarmReportingOnRequest
    {
        
        public SetAlarmReportingOnRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EQUIPMENTORHOLDERNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "equipmentOrHolderName");
        
        
        /**
         * Gets the "equipmentOrHolderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "equipmentOrHolderName" element
         */
        public boolean isNilEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "equipmentOrHolderName" element
         */
        public boolean isSetEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EQUIPMENTORHOLDERNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "equipmentOrHolderName" element
         */
        public void setEquipmentOrHolderName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType equipmentOrHolderName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EQUIPMENTORHOLDERNAME$0);
                }
                target.set(equipmentOrHolderName);
            }
        }
        
        /**
         * Appends and returns a new empty "equipmentOrHolderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EQUIPMENTORHOLDERNAME$0);
                return target;
            }
        }
        
        /**
         * Nils the "equipmentOrHolderName" element
         */
        public void setNilEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EQUIPMENTORHOLDERNAME$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "equipmentOrHolderName" element
         */
        public void unsetEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EQUIPMENTORHOLDERNAME$0, 0);
            }
        }
    }
}
