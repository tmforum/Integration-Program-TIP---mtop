/*
 * XML Type:  AlarmSeverityAssignmentProfileModifyDataType
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * An XML AlarmSeverityAssignmentProfileModifyDataType(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
 *
 * This is a complex type.
 */
public class AlarmSeverityAssignmentProfileModifyDataTypeImpl extends org.tmforum.mtop.nrb.xsd.crmd.v1.impl.CommonResourceModifyDataTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType
{
    
    public AlarmSeverityAssignmentProfileModifyDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASALIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "asaList");
    
    
    /**
     * Gets the "asaList" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType getAsaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ASALIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "asaList" element
     */
    public boolean isNilAsaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ASALIST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asaList" element
     */
    public boolean isSetAsaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASALIST$0) != 0;
        }
    }
    
    /**
     * Sets the "asaList" element
     */
    public void setAsaList(org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType asaList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ASALIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ASALIST$0);
            }
            target.set(asaList);
        }
    }
    
    /**
     * Appends and returns a new empty "asaList" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType addNewAsaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ASALIST$0);
            return target;
        }
    }
    
    /**
     * Nils the "asaList" element
     */
    public void setNilAsaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ASALIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ASALIST$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asaList" element
     */
    public void unsetAsaList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASALIST$0, 0);
        }
    }
}
