/*
 * An XML document type.
 * Localname: pg
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pg/v1
 * Java type: org.tmforum.mtop.nra.xsd.pg.v1.PgDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pg.v1.impl;
/**
 * A document containing one pg(@http://www.tmforum.org/mtop/nra/xsd/pg/v1) element.
 *
 * This is a complex type.
 */
public class PgDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pg.v1.PgDocument
{
    
    public PgDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PG$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "pg");
    
    
    /**
     * Gets the "pg" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType getPg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PG$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "pg" element
     */
    public void setPg(org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType pg)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PG$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().add_element_user(PG$0);
            }
            target.set(pg);
        }
    }
    
    /**
     * Appends and returns a new empty "pg" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType addNewPg()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().add_element_user(PG$0);
            return target;
        }
    }
}
