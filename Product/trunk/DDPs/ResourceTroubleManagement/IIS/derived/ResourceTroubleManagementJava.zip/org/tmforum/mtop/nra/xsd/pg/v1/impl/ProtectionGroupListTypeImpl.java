/*
 * XML Type:  ProtectionGroupListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pg/v1
 * Java type: org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pg.v1.impl;
/**
 * An XML ProtectionGroupListType(@http://www.tmforum.org/mtop/nra/xsd/pg/v1).
 *
 * This is a complex type.
 */
public class ProtectionGroupListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupListType
{
    
    public ProtectionGroupListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PGP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "pgp");
    
    
    /**
     * Gets a List of "pgp" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType> getPgpList()
    {
        final class PgpList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType>
        {
            public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType get(int i)
                { return ProtectionGroupListTypeImpl.this.getPgpArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType set(int i, org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType o)
            {
                org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType old = ProtectionGroupListTypeImpl.this.getPgpArray(i);
                ProtectionGroupListTypeImpl.this.setPgpArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType o)
                { ProtectionGroupListTypeImpl.this.insertNewPgp(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType old = ProtectionGroupListTypeImpl.this.getPgpArray(i);
                ProtectionGroupListTypeImpl.this.removePgp(i);
                return old;
            }
            
            public int size()
                { return ProtectionGroupListTypeImpl.this.sizeOfPgpArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PgpList();
        }
    }
    
    /**
     * Gets array of all "pgp" elements
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType[] getPgpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PGP$0, targetList);
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType[] result = new org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "pgp" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType getPgpArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PGP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "pgp" element
     */
    public int sizeOfPgpArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PGP$0);
        }
    }
    
    /**
     * Sets array of all "pgp" element
     */
    public void setPgpArray(org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType[] pgpArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pgpArray, PGP$0);
        }
    }
    
    /**
     * Sets ith "pgp" element
     */
    public void setPgpArray(int i, org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType pgp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().find_element_user(PGP$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pgp);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pgp" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType insertNewPgp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().insert_element_user(PGP$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pgp" element
     */
    public org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType addNewPgp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType target = null;
            target = (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType)get_store().add_element_user(PGP$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pgp" element
     */
    public void removePgp(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PGP$0, i);
        }
    }
}
