/*
 * XML Type:  PmIntervalStatusType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pm/v1
 * Java type: org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pm.v1.impl;
/**
 * An XML PmIntervalStatusType(@http://www.tmforum.org/mtop/nra/xsd/pm/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType.
 */
public class PmIntervalStatusTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.pm.v1.PmIntervalStatusType
{
    
    public PmIntervalStatusTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected PmIntervalStatusTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
