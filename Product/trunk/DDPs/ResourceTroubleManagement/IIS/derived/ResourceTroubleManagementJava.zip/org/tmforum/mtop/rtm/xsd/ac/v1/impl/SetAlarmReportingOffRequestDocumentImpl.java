/*
 * An XML document type.
 * Localname: setAlarmReportingOffRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setAlarmReportingOffRequest(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetAlarmReportingOffRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument
{
    
    public SetAlarmReportingOffRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALARMREPORTINGOFFREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setAlarmReportingOffRequest");
    
    
    /**
     * Gets the "setAlarmReportingOffRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest getSetAlarmReportingOffRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest)get_store().find_element_user(SETALARMREPORTINGOFFREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAlarmReportingOffRequest" element
     */
    public void setSetAlarmReportingOffRequest(org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest setAlarmReportingOffRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest)get_store().find_element_user(SETALARMREPORTINGOFFREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest)get_store().add_element_user(SETALARMREPORTINGOFFREQUEST$0);
            }
            target.set(setAlarmReportingOffRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "setAlarmReportingOffRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest addNewSetAlarmReportingOffRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest)get_store().add_element_user(SETALARMREPORTINGOFFREQUEST$0);
            return target;
        }
    }
    /**
     * An XML setAlarmReportingOffRequest(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetAlarmReportingOffRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffRequestDocument.SetAlarmReportingOffRequest
    {
        
        public SetAlarmReportingOffRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EQUIPMENTORHOLDERNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "equipmentOrHolderName");
        
        
        /**
         * Gets the "equipmentOrHolderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "equipmentOrHolderName" element
         */
        public boolean isNilEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "equipmentOrHolderName" element
         */
        public boolean isSetEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EQUIPMENTORHOLDERNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "equipmentOrHolderName" element
         */
        public void setEquipmentOrHolderName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType equipmentOrHolderName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EQUIPMENTORHOLDERNAME$0);
                }
                target.set(equipmentOrHolderName);
            }
        }
        
        /**
         * Appends and returns a new empty "equipmentOrHolderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EQUIPMENTORHOLDERNAME$0);
                return target;
            }
        }
        
        /**
         * Nils the "equipmentOrHolderName" element
         */
        public void setNilEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(EQUIPMENTORHOLDERNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(EQUIPMENTORHOLDERNAME$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "equipmentOrHolderName" element
         */
        public void unsetEquipmentOrHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EQUIPMENTORHOLDERNAME$0, 0);
            }
        }
    }
}
