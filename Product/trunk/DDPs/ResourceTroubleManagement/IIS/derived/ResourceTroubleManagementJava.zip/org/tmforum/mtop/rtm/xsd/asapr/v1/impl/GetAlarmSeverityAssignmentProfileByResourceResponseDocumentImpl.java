/*
 * An XML document type.
 * Localname: getAlarmSeverityAssignmentProfileByResourceResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAlarmSeverityAssignmentProfileByResourceResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAlarmSeverityAssignmentProfileByResourceResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument
{
    
    public GetAlarmSeverityAssignmentProfileByResourceResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAlarmSeverityAssignmentProfileByResourceResponse");
    
    
    /**
     * Gets the "getAlarmSeverityAssignmentProfileByResourceResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse getGetAlarmSeverityAssignmentProfileByResourceResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAlarmSeverityAssignmentProfileByResourceResponse" element
     */
    public void setGetAlarmSeverityAssignmentProfileByResourceResponse(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse getAlarmSeverityAssignmentProfileByResourceResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCERESPONSE$0);
            }
            target.set(getAlarmSeverityAssignmentProfileByResourceResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAlarmSeverityAssignmentProfileByResourceResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse addNewGetAlarmSeverityAssignmentProfileByResourceResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAlarmSeverityAssignmentProfileByResourceResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAlarmSeverityAssignmentProfileByResourceResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceResponseDocument.GetAlarmSeverityAssignmentProfileByResourceResponse
    {
        
        public GetAlarmSeverityAssignmentProfileByResourceResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "asapList");
        
        
        /**
         * Gets the "asapList" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType getAsapList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType)get_store().find_element_user(ASAPLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "asapList" element
         */
        public boolean isSetAsapList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "asapList" element
         */
        public void setAsapList(org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType asapList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType)get_store().find_element_user(ASAPLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType)get_store().add_element_user(ASAPLIST$0);
                }
                target.set(asapList);
            }
        }
        
        /**
         * Appends and returns a new empty "asapList" element
         */
        public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType addNewAsapList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType target = null;
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileListType)get_store().add_element_user(ASAPLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "asapList" element
         */
        public void unsetAsapList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPLIST$0, 0);
            }
        }
    }
}
