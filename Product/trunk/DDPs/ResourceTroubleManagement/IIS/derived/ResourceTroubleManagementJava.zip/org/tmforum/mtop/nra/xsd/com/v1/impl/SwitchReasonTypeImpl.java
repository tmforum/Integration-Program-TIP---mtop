/*
 * XML Type:  SwitchReasonType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1.impl;
/**
 * An XML SwitchReasonType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType.
 */
public class SwitchReasonTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.nra.xsd.com.v1.SwitchReasonType
{
    
    public SwitchReasonTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected SwitchReasonTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
