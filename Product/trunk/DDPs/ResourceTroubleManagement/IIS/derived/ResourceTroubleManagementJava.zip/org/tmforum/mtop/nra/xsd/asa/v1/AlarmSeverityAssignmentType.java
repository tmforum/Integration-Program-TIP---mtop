/*
 * XML Type:  AlarmSeverityAssignmentType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/asa/v1
 * Java type: org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.asa.v1;


/**
 * An XML AlarmSeverityAssignmentType(@http://www.tmforum.org/mtop/nra/xsd/asa/v1).
 *
 * This is a complex type.
 */
public interface AlarmSeverityAssignmentType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AlarmSeverityAssignmentType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD7F14712642FA7BC89FBCB45763AB9FB").resolveHandle("alarmseverityassignmenttype7fb4type");
    
    /**
     * Gets the "probableCause" element
     */
    org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType getProbableCause();
    
    /**
     * Tests for nil "probableCause" element
     */
    boolean isNilProbableCause();
    
    /**
     * Sets the "probableCause" element
     */
    void setProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType probableCause);
    
    /**
     * Appends and returns a new empty "probableCause" element
     */
    org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType addNewProbableCause();
    
    /**
     * Nils the "probableCause" element
     */
    void setNilProbableCause();
    
    /**
     * Gets the "probableCauseQualifier" element
     */
    java.lang.String getProbableCauseQualifier();
    
    /**
     * Gets (as xml) the "probableCauseQualifier" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType xgetProbableCauseQualifier();
    
    /**
     * Tests for nil "probableCauseQualifier" element
     */
    boolean isNilProbableCauseQualifier();
    
    /**
     * True if has "probableCauseQualifier" element
     */
    boolean isSetProbableCauseQualifier();
    
    /**
     * Sets the "probableCauseQualifier" element
     */
    void setProbableCauseQualifier(java.lang.String probableCauseQualifier);
    
    /**
     * Sets (as xml) the "probableCauseQualifier" element
     */
    void xsetProbableCauseQualifier(org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType probableCauseQualifier);
    
    /**
     * Nils the "probableCauseQualifier" element
     */
    void setNilProbableCauseQualifier();
    
    /**
     * Unsets the "probableCauseQualifier" element
     */
    void unsetProbableCauseQualifier();
    
    /**
     * Gets the "nativeProbableCause" element
     */
    java.lang.String getNativeProbableCause();
    
    /**
     * Gets (as xml) the "nativeProbableCause" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType xgetNativeProbableCause();
    
    /**
     * Tests for nil "nativeProbableCause" element
     */
    boolean isNilNativeProbableCause();
    
    /**
     * True if has "nativeProbableCause" element
     */
    boolean isSetNativeProbableCause();
    
    /**
     * Sets the "nativeProbableCause" element
     */
    void setNativeProbableCause(java.lang.String nativeProbableCause);
    
    /**
     * Sets (as xml) the "nativeProbableCause" element
     */
    void xsetNativeProbableCause(org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType nativeProbableCause);
    
    /**
     * Nils the "nativeProbableCause" element
     */
    void setNilNativeProbableCause();
    
    /**
     * Unsets the "nativeProbableCause" element
     */
    void unsetNativeProbableCause();
    
    /**
     * Gets the "serviceAffectingSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType getServiceAffectingSeverity();
    
    /**
     * Tests for nil "serviceAffectingSeverity" element
     */
    boolean isNilServiceAffectingSeverity();
    
    /**
     * Sets the "serviceAffectingSeverity" element
     */
    void setServiceAffectingSeverity(org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType serviceAffectingSeverity);
    
    /**
     * Appends and returns a new empty "serviceAffectingSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType addNewServiceAffectingSeverity();
    
    /**
     * Nils the "serviceAffectingSeverity" element
     */
    void setNilServiceAffectingSeverity();
    
    /**
     * Gets the "nonServiceAffectingSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType getNonServiceAffectingSeverity();
    
    /**
     * Tests for nil "nonServiceAffectingSeverity" element
     */
    boolean isNilNonServiceAffectingSeverity();
    
    /**
     * Sets the "nonServiceAffectingSeverity" element
     */
    void setNonServiceAffectingSeverity(org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType nonServiceAffectingSeverity);
    
    /**
     * Appends and returns a new empty "nonServiceAffectingSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType addNewNonServiceAffectingSeverity();
    
    /**
     * Nils the "nonServiceAffectingSeverity" element
     */
    void setNilNonServiceAffectingSeverity();
    
    /**
     * Gets the "serviceIndependentSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType getServiceIndependentSeverity();
    
    /**
     * Tests for nil "serviceIndependentSeverity" element
     */
    boolean isNilServiceIndependentSeverity();
    
    /**
     * Sets the "serviceIndependentSeverity" element
     */
    void setServiceIndependentSeverity(org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType serviceIndependentSeverity);
    
    /**
     * Appends and returns a new empty "serviceIndependentSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType addNewServiceIndependentSeverity();
    
    /**
     * Nils the "serviceIndependentSeverity" element
     */
    void setNilServiceIndependentSeverity();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType newInstance() {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
