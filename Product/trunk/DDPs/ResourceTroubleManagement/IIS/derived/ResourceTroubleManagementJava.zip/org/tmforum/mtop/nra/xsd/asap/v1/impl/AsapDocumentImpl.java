/*
 * An XML document type.
 * Localname: asap
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/asap/v1
 * Java type: org.tmforum.mtop.nra.xsd.asap.v1.AsapDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.asap.v1.impl;
/**
 * A document containing one asap(@http://www.tmforum.org/mtop/nra/xsd/asap/v1) element.
 *
 * This is a complex type.
 */
public class AsapDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.asap.v1.AsapDocument
{
    
    public AsapDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASAP$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asap/v1", "asap");
    
    
    /**
     * Gets the "asap" element
     */
    public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType getAsap()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "asap" element
     */
    public void setAsap(org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType asap)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().find_element_user(ASAP$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(ASAP$0);
            }
            target.set(asap);
        }
    }
    
    /**
     * Appends and returns a new empty "asap" element
     */
    public org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType addNewAsap()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType target = null;
            target = (org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType)get_store().add_element_user(ASAP$0);
            return target;
        }
    }
}
