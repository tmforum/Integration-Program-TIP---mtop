/*
 * XML Type:  TcaIdType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/tcaid/v1
 * Java type: org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.tcaid.v1;


/**
 * An XML TcaIdType(@http://www.tmforum.org/mtop/nra/xsd/tcaid/v1).
 *
 * This is a complex type.
 */
public interface TcaIdType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(TcaIdType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sE4E00909D8AE0EC9AD2FEF6A1C16943D").resolveHandle("tcaidtype9684type");
    
    /**
     * Gets the "objectName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getObjectName();
    
    /**
     * True if has "objectName" element
     */
    boolean isSetObjectName();
    
    /**
     * Sets the "objectName" element
     */
    void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType objectName);
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewObjectName();
    
    /**
     * Unsets the "objectName" element
     */
    void unsetObjectName();
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * True if has "layerRate" element
     */
    boolean isSetLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Unsets the "layerRate" element
     */
    void unsetLayerRate();
    
    /**
     * Gets the "pmParameterName" element
     */
    java.lang.String getPmParameterName();
    
    /**
     * Gets (as xml) the "pmParameterName" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType xgetPmParameterName();
    
    /**
     * True if has "pmParameterName" element
     */
    boolean isSetPmParameterName();
    
    /**
     * Sets the "pmParameterName" element
     */
    void setPmParameterName(java.lang.String pmParameterName);
    
    /**
     * Sets (as xml) the "pmParameterName" element
     */
    void xsetPmParameterName(org.tmforum.mtop.nra.xsd.pm.v1.PmParameterNameType pmParameterName);
    
    /**
     * Unsets the "pmParameterName" element
     */
    void unsetPmParameterName();
    
    /**
     * Gets the "pmLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getPmLocation();
    
    /**
     * Gets (as xml) the "pmLocation" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetPmLocation();
    
    /**
     * True if has "pmLocation" element
     */
    boolean isSetPmLocation();
    
    /**
     * Sets the "pmLocation" element
     */
    void setPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation);
    
    /**
     * Sets (as xml) the "pmLocation" element
     */
    void xsetPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType pmLocation);
    
    /**
     * Unsets the "pmLocation" element
     */
    void unsetPmLocation();
    
    /**
     * Gets the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum getGranularity();
    
    /**
     * Gets (as xml) the "granularity" element
     */
    org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType xgetGranularity();
    
    /**
     * True if has "granularity" element
     */
    boolean isSetGranularity();
    
    /**
     * Sets the "granularity" element
     */
    void setGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType.Enum granularity);
    
    /**
     * Sets (as xml) the "granularity" element
     */
    void xsetGranularity(org.tmforum.mtop.nra.xsd.pm.v1.PmGranularityType granularity);
    
    /**
     * Unsets the "granularity" element
     */
    void unsetGranularity();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType newInstance() {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
