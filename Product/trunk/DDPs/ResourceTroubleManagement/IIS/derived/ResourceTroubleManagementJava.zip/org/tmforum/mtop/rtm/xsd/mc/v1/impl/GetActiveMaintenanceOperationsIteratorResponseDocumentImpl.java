/*
 * An XML document type.
 * Localname: getActiveMaintenanceOperationsIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/mc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.mc.v1.impl;
/**
 * A document containing one getActiveMaintenanceOperationsIteratorResponse(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveMaintenanceOperationsIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument
{
    
    public GetActiveMaintenanceOperationsIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEMAINTENANCEOPERATIONSITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "getActiveMaintenanceOperationsIteratorResponse");
    
    
    /**
     * Gets the "getActiveMaintenanceOperationsIteratorResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse getGetActiveMaintenanceOperationsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveMaintenanceOperationsIteratorResponse" element
     */
    public void setGetActiveMaintenanceOperationsIteratorResponse(org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse getActiveMaintenanceOperationsIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATORRESPONSE$0);
            }
            target.set(getActiveMaintenanceOperationsIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveMaintenanceOperationsIteratorResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse addNewGetActiveMaintenanceOperationsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSITERATORRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getActiveMaintenanceOperationsIteratorResponse(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1).
     *
     * This is a complex type.
     */
    public static class GetActiveMaintenanceOperationsIteratorResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsIteratorResponseDocument.GetActiveMaintenanceOperationsIteratorResponse
    {
        
        public GetActiveMaintenanceOperationsIteratorResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CURRENTMAINTENANCEOPERATIONLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "currentMaintenanceOperationList");
        
        
        /**
         * Gets the "currentMaintenanceOperationList" element
         */
        public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType getCurrentMaintenanceOperationList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType)get_store().find_element_user(CURRENTMAINTENANCEOPERATIONLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "currentMaintenanceOperationList" element
         */
        public boolean isNilCurrentMaintenanceOperationList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType)get_store().find_element_user(CURRENTMAINTENANCEOPERATIONLIST$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "currentMaintenanceOperationList" element
         */
        public boolean isSetCurrentMaintenanceOperationList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CURRENTMAINTENANCEOPERATIONLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "currentMaintenanceOperationList" element
         */
        public void setCurrentMaintenanceOperationList(org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType currentMaintenanceOperationList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType)get_store().find_element_user(CURRENTMAINTENANCEOPERATIONLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType)get_store().add_element_user(CURRENTMAINTENANCEOPERATIONLIST$0);
                }
                target.set(currentMaintenanceOperationList);
            }
        }
        
        /**
         * Appends and returns a new empty "currentMaintenanceOperationList" element
         */
        public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType addNewCurrentMaintenanceOperationList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType)get_store().add_element_user(CURRENTMAINTENANCEOPERATIONLIST$0);
                return target;
            }
        }
        
        /**
         * Nils the "currentMaintenanceOperationList" element
         */
        public void setNilCurrentMaintenanceOperationList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType target = null;
                target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType)get_store().find_element_user(CURRENTMAINTENANCEOPERATIONLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType)get_store().add_element_user(CURRENTMAINTENANCEOPERATIONLIST$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "currentMaintenanceOperationList" element
         */
        public void unsetCurrentMaintenanceOperationList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CURRENTMAINTENANCEOPERATIONLIST$0, 0);
            }
        }
    }
}
