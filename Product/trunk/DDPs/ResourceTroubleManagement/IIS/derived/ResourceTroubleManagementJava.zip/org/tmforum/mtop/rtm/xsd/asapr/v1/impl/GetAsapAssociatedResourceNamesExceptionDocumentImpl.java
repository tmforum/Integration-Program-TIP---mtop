/*
 * An XML document type.
 * Localname: getAsapAssociatedResourceNamesException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAsapAssociatedResourceNamesException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAsapAssociatedResourceNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument
{
    
    public GetAsapAssociatedResourceNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASAPASSOCIATEDRESOURCENAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAsapAssociatedResourceNamesException");
    
    
    /**
     * Gets the "getAsapAssociatedResourceNamesException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException getGetAsapAssociatedResourceNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException)get_store().find_element_user(GETASAPASSOCIATEDRESOURCENAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAsapAssociatedResourceNamesException" element
     */
    public void setGetAsapAssociatedResourceNamesException(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException getAsapAssociatedResourceNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException)get_store().find_element_user(GETASAPASSOCIATEDRESOURCENAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException)get_store().add_element_user(GETASAPASSOCIATEDRESOURCENAMESEXCEPTION$0);
            }
            target.set(getAsapAssociatedResourceNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAsapAssociatedResourceNamesException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException addNewGetAsapAssociatedResourceNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException)get_store().add_element_user(GETASAPASSOCIATEDRESOURCENAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAsapAssociatedResourceNamesException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAsapAssociatedResourceNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapAssociatedResourceNamesExceptionDocument.GetAsapAssociatedResourceNamesException
    {
        
        public GetAsapAssociatedResourceNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
