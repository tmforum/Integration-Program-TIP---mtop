/*
 * An XML document type.
 * Localname: performProtectionCommandRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/pc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.pc.v1.impl;
/**
 * A document containing one performProtectionCommandRequest(@http://www.tmforum.org/mtop/rtm/xsd/pc/v1) element.
 *
 * This is a complex type.
 */
public class PerformProtectionCommandRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument
{
    
    public PerformProtectionCommandRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERFORMPROTECTIONCOMMANDREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/pc/v1", "performProtectionCommandRequest");
    
    
    /**
     * Gets the "performProtectionCommandRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest getPerformProtectionCommandRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest)get_store().find_element_user(PERFORMPROTECTIONCOMMANDREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "performProtectionCommandRequest" element
     */
    public void setPerformProtectionCommandRequest(org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest performProtectionCommandRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest)get_store().find_element_user(PERFORMPROTECTIONCOMMANDREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest)get_store().add_element_user(PERFORMPROTECTIONCOMMANDREQUEST$0);
            }
            target.set(performProtectionCommandRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "performProtectionCommandRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest addNewPerformProtectionCommandRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest)get_store().add_element_user(PERFORMPROTECTIONCOMMANDREQUEST$0);
            return target;
        }
    }
    /**
     * An XML performProtectionCommandRequest(@http://www.tmforum.org/mtop/rtm/xsd/pc/v1).
     *
     * This is a complex type.
     */
    public static class PerformProtectionCommandRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.pc.v1.PerformProtectionCommandRequestDocument.PerformProtectionCommandRequest
    {
        
        public PerformProtectionCommandRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName PROTECTIONCOMMAND$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/pc/v1", "protectionCommand");
        private static final javax.xml.namespace.QName RELIABLESINKCTPORGROUPNAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/pc/v1", "reliableSinkCtpOrGroupName");
        private static final javax.xml.namespace.QName FROMTP$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/pc/v1", "fromTp");
        private static final javax.xml.namespace.QName TOTP$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/pc/v1", "toTp");
        
        
        /**
         * Gets the "protectionCommand" element
         */
        public org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType.Enum getProtectionCommand()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTECTIONCOMMAND$0, 0);
                if (target == null)
                {
                    return null;
                }
                return (org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType.Enum)target.getEnumValue();
            }
        }
        
        /**
         * Gets (as xml) the "protectionCommand" element
         */
        public org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType xgetProtectionCommand()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType target = null;
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType)get_store().find_element_user(PROTECTIONCOMMAND$0, 0);
                return target;
            }
        }
        
        /**
         * True if has "protectionCommand" element
         */
        public boolean isSetProtectionCommand()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(PROTECTIONCOMMAND$0) != 0;
            }
        }
        
        /**
         * Sets the "protectionCommand" element
         */
        public void setProtectionCommand(org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType.Enum protectionCommand)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROTECTIONCOMMAND$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROTECTIONCOMMAND$0);
                }
                target.setEnumValue(protectionCommand);
            }
        }
        
        /**
         * Sets (as xml) the "protectionCommand" element
         */
        public void xsetProtectionCommand(org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType protectionCommand)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType target = null;
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType)get_store().find_element_user(PROTECTIONCOMMAND$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionCommandType)get_store().add_element_user(PROTECTIONCOMMAND$0);
                }
                target.set(protectionCommand);
            }
        }
        
        /**
         * Unsets the "protectionCommand" element
         */
        public void unsetProtectionCommand()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(PROTECTIONCOMMAND$0, 0);
            }
        }
        
        /**
         * Gets the "reliableSinkCtpOrGroupName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getReliableSinkCtpOrGroupName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(RELIABLESINKCTPORGROUPNAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "reliableSinkCtpOrGroupName" element
         */
        public boolean isSetReliableSinkCtpOrGroupName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(RELIABLESINKCTPORGROUPNAME$2) != 0;
            }
        }
        
        /**
         * Sets the "reliableSinkCtpOrGroupName" element
         */
        public void setReliableSinkCtpOrGroupName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType reliableSinkCtpOrGroupName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(RELIABLESINKCTPORGROUPNAME$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(RELIABLESINKCTPORGROUPNAME$2);
                }
                target.set(reliableSinkCtpOrGroupName);
            }
        }
        
        /**
         * Appends and returns a new empty "reliableSinkCtpOrGroupName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewReliableSinkCtpOrGroupName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(RELIABLESINKCTPORGROUPNAME$2);
                return target;
            }
        }
        
        /**
         * Unsets the "reliableSinkCtpOrGroupName" element
         */
        public void unsetReliableSinkCtpOrGroupName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(RELIABLESINKCTPORGROUPNAME$2, 0);
            }
        }
        
        /**
         * Gets the "fromTp" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getFromTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FROMTP$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fromTp" element
         */
        public boolean isSetFromTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FROMTP$4) != 0;
            }
        }
        
        /**
         * Sets the "fromTp" element
         */
        public void setFromTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType fromTp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FROMTP$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FROMTP$4);
                }
                target.set(fromTp);
            }
        }
        
        /**
         * Appends and returns a new empty "fromTp" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewFromTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FROMTP$4);
                return target;
            }
        }
        
        /**
         * Unsets the "fromTp" element
         */
        public void unsetFromTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FROMTP$4, 0);
            }
        }
        
        /**
         * Gets the "toTp" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getToTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TOTP$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "toTp" element
         */
        public boolean isSetToTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TOTP$6) != 0;
            }
        }
        
        /**
         * Sets the "toTp" element
         */
        public void setToTp(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType toTp)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TOTP$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TOTP$6);
                }
                target.set(toTp);
            }
        }
        
        /**
         * Appends and returns a new empty "toTp" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewToTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TOTP$6);
                return target;
            }
        }
        
        /**
         * Unsets the "toTp" element
         */
        public void unsetToTp()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TOTP$6, 0);
            }
        }
    }
}
