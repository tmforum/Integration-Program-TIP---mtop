/*
 * XML Type:  SpecificProblemType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/com/v1
 * Java type: org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.com.v1.impl;
/**
 * An XML SpecificProblemType(@http://www.tmforum.org/mtop/nra/xsd/com/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType.
 */
public class SpecificProblemTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemType
{
    
    public SpecificProblemTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected SpecificProblemTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
