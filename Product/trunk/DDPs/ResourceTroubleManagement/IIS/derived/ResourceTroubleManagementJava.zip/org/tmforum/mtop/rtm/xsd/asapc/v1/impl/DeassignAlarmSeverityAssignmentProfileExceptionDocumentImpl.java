/*
 * An XML document type.
 * Localname: deassignAlarmSeverityAssignmentProfileException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one deassignAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class DeassignAlarmSeverityAssignmentProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument
{
    
    public DeassignAlarmSeverityAssignmentProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DEASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "deassignAlarmSeverityAssignmentProfileException");
    
    
    /**
     * Gets the "deassignAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException getDeassignAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException)get_store().find_element_user(DEASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deassignAlarmSeverityAssignmentProfileException" element
     */
    public void setDeassignAlarmSeverityAssignmentProfileException(org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException deassignAlarmSeverityAssignmentProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException)get_store().find_element_user(DEASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException)get_store().add_element_user(DEASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            }
            target.set(deassignAlarmSeverityAssignmentProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "deassignAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException addNewDeassignAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException)get_store().add_element_user(DEASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deassignAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class DeassignAlarmSeverityAssignmentProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileExceptionDocument.DeassignAlarmSeverityAssignmentProfileException
    {
        
        public DeassignAlarmSeverityAssignmentProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
