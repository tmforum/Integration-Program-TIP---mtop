/*
 * An XML document type.
 * Localname: unsupportedCompressionFormat
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/msg/v1
 * Java type: org.tmforum.mtop.fmw.xsd.msg.v1.UnsupportedCompressionFormatDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.msg.v1.impl;
/**
 * A document containing one unsupportedCompressionFormat(@http://www.tmforum.org/mtop/fmw/xsd/msg/v1) element.
 *
 * This is a complex type.
 */
public class UnsupportedCompressionFormatDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.msg.v1.UnsupportedCompressionFormatDocument
{
    
    public UnsupportedCompressionFormatDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UNSUPPORTEDCOMPRESSIONFORMAT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/msg/v1", "unsupportedCompressionFormat");
    
    
    /**
     * Gets the "unsupportedCompressionFormat" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getUnsupportedCompressionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNSUPPORTEDCOMPRESSIONFORMAT$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "unsupportedCompressionFormat" element
     */
    public void setUnsupportedCompressionFormat(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType unsupportedCompressionFormat)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(UNSUPPORTEDCOMPRESSIONFORMAT$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNSUPPORTEDCOMPRESSIONFORMAT$0);
            }
            target.set(unsupportedCompressionFormat);
        }
    }
    
    /**
     * Appends and returns a new empty "unsupportedCompressionFormat" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewUnsupportedCompressionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(UNSUPPORTEDCOMPRESSIONFORMAT$0);
            return target;
        }
    }
}
