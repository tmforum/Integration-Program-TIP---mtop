/*
 * XML Type:  AsapModifyDataType
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.AsapModifyDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * An XML AsapModifyDataType(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
 *
 * This is a complex type.
 */
public class AsapModifyDataTypeImpl extends org.tmforum.mtop.nrb.xsd.crmd.v1.impl.CommonResourceModifyDataTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AsapModifyDataType
{
    
    public AsapModifyDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARMSEVERITYASSIGNMENTLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "alarmSeverityAssignmentList");
    
    
    /**
     * Gets the "alarmSeverityAssignmentList" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType getAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ALARMSEVERITYASSIGNMENTLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "alarmSeverityAssignmentList" element
     */
    public boolean isNilAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ALARMSEVERITYASSIGNMENTLIST$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "alarmSeverityAssignmentList" element
     */
    public boolean isSetAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMSEVERITYASSIGNMENTLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "alarmSeverityAssignmentList" element
     */
    public void setAlarmSeverityAssignmentList(org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType alarmSeverityAssignmentList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ALARMSEVERITYASSIGNMENTLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ALARMSEVERITYASSIGNMENTLIST$0);
            }
            target.set(alarmSeverityAssignmentList);
        }
    }
    
    /**
     * Appends and returns a new empty "alarmSeverityAssignmentList" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType addNewAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ALARMSEVERITYASSIGNMENTLIST$0);
            return target;
        }
    }
    
    /**
     * Nils the "alarmSeverityAssignmentList" element
     */
    public void setNilAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ALARMSEVERITYASSIGNMENTLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ALARMSEVERITYASSIGNMENTLIST$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "alarmSeverityAssignmentList" element
     */
    public void unsetAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMSEVERITYASSIGNMENTLIST$0, 0);
        }
    }
}
