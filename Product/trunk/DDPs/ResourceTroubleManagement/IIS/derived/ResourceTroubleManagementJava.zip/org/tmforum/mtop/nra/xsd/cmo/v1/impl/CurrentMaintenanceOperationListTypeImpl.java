/*
 * XML Type:  CurrentMaintenanceOperationListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/cmo/v1
 * Java type: org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.cmo.v1.impl;
/**
 * An XML CurrentMaintenanceOperationListType(@http://www.tmforum.org/mtop/nra/xsd/cmo/v1).
 *
 * This is a complex type.
 */
public class CurrentMaintenanceOperationListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationListType
{
    
    public CurrentMaintenanceOperationListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MAINTENANCEOPERATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/cmo/v1", "maintenanceOperation");
    
    
    /**
     * Gets a List of "maintenanceOperation" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType> getMaintenanceOperationList()
    {
        final class MaintenanceOperationList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType>
        {
            public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType get(int i)
                { return CurrentMaintenanceOperationListTypeImpl.this.getMaintenanceOperationArray(i); }
            
            public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType set(int i, org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType o)
            {
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType old = CurrentMaintenanceOperationListTypeImpl.this.getMaintenanceOperationArray(i);
                CurrentMaintenanceOperationListTypeImpl.this.setMaintenanceOperationArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType o)
                { CurrentMaintenanceOperationListTypeImpl.this.insertNewMaintenanceOperation(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType old = CurrentMaintenanceOperationListTypeImpl.this.getMaintenanceOperationArray(i);
                CurrentMaintenanceOperationListTypeImpl.this.removeMaintenanceOperation(i);
                return old;
            }
            
            public int size()
                { return CurrentMaintenanceOperationListTypeImpl.this.sizeOfMaintenanceOperationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new MaintenanceOperationList();
        }
    }
    
    /**
     * Gets array of all "maintenanceOperation" elements
     */
    public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType[] getMaintenanceOperationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(MAINTENANCEOPERATION$0, targetList);
            org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType[] result = new org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "maintenanceOperation" element
     */
    public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType getMaintenanceOperationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
            target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().find_element_user(MAINTENANCEOPERATION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "maintenanceOperation" element
     */
    public int sizeOfMaintenanceOperationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MAINTENANCEOPERATION$0);
        }
    }
    
    /**
     * Sets array of all "maintenanceOperation" element
     */
    public void setMaintenanceOperationArray(org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType[] maintenanceOperationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(maintenanceOperationArray, MAINTENANCEOPERATION$0);
        }
    }
    
    /**
     * Sets ith "maintenanceOperation" element
     */
    public void setMaintenanceOperationArray(int i, org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType maintenanceOperation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
            target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().find_element_user(MAINTENANCEOPERATION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(maintenanceOperation);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "maintenanceOperation" element
     */
    public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType insertNewMaintenanceOperation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
            target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().insert_element_user(MAINTENANCEOPERATION$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "maintenanceOperation" element
     */
    public org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType addNewMaintenanceOperation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType target = null;
            target = (org.tmforum.mtop.nra.xsd.cmo.v1.CurrentMaintenanceOperationType)get_store().add_element_user(MAINTENANCEOPERATION$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "maintenanceOperation" element
     */
    public void removeMaintenanceOperation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MAINTENANCEOPERATION$0, i);
        }
    }
}
