/*
 * XML Type:  ProtectionGroupType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pg/v1
 * Java type: org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pg.v1.impl;
/**
 * An XML ProtectionGroupType(@http://www.tmforum.org/mtop/nra/xsd/pg/v1).
 *
 * This is a complex type.
 */
public class ProtectionGroupTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType
{
    
    public ProtectionGroupTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROTECTIONGROUPTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "protectionGroupType");
    private static final javax.xml.namespace.QName PROTECTIONSCHEMESTATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "protectionSchemeState");
    private static final javax.xml.namespace.QName REVERSIONMODE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "reversionMode");
    private static final javax.xml.namespace.QName RATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "rate");
    private static final javax.xml.namespace.QName PGPARAMETERS$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "pgParameters");
    private static final javax.xml.namespace.QName PGTPLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "pgTpList");
    private static final javax.xml.namespace.QName G7743APSFUNCTION$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "G_774_3_APSfunction");
    private static final javax.xml.namespace.QName ASAPREF$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "asapRef");
    
    
    /**
     * Gets the "protectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType getProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().find_element_user(PROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionGroupType" element
     */
    public boolean isNilProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().find_element_user(PROTECTIONGROUPTYPE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionGroupType" element
     */
    public boolean isSetProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONGROUPTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "protectionGroupType" element
     */
    public void setProtectionGroupType(org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType protectionGroupType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().find_element_user(PROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().add_element_user(PROTECTIONGROUPTYPE$0);
            }
            target.set(protectionGroupType);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType addNewProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().add_element_user(PROTECTIONGROUPTYPE$0);
            return target;
        }
    }
    
    /**
     * Nils the "protectionGroupType" element
     */
    public void setNilProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().find_element_user(PROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().add_element_user(PROTECTIONGROUPTYPE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionGroupType" element
     */
    public void unsetProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONGROUPTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType getProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionSchemeState" element
     */
    public boolean isNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionSchemeState" element
     */
    public boolean isSetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONSCHEMESTATE$2) != 0;
        }
    }
    
    /**
     * Sets the "protectionSchemeState" element
     */
    public void setProtectionSchemeState(org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType protectionSchemeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            }
            target.set(protectionSchemeState);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType addNewProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            return target;
        }
    }
    
    /**
     * Nils the "protectionSchemeState" element
     */
    public void setNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionSchemeState" element
     */
    public void unsetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONSCHEMESTATE$2, 0);
        }
    }
    
    /**
     * Gets the "reversionMode" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum getReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "reversionMode" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType xgetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "reversionMode" element
     */
    public boolean isNilReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "reversionMode" element
     */
    public boolean isSetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REVERSIONMODE$4) != 0;
        }
    }
    
    /**
     * Sets the "reversionMode" element
     */
    public void setReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum reversionMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.setEnumValue(reversionMode);
        }
    }
    
    /**
     * Sets (as xml) the "reversionMode" element
     */
    public void xsetReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType reversionMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.set(reversionMode);
        }
    }
    
    /**
     * Nils the "reversionMode" element
     */
    public void setNilReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "reversionMode" element
     */
    public void unsetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REVERSIONMODE$4, 0);
        }
    }
    
    /**
     * Gets the "rate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "rate" element
     */
    public boolean isNilRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "rate" element
     */
    public boolean isSetRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RATE$6) != 0;
        }
    }
    
    /**
     * Sets the "rate" element
     */
    public void setRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType rate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$6);
            }
            target.set(rate);
        }
    }
    
    /**
     * Appends and returns a new empty "rate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$6);
            return target;
        }
    }
    
    /**
     * Nils the "rate" element
     */
    public void setNilRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(RATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(RATE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "rate" element
     */
    public void unsetRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RATE$6, 0);
        }
    }
    
    /**
     * Gets the "pgParameters" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType getPgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().find_element_user(PGPARAMETERS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "pgParameters" element
     */
    public boolean isNilPgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().find_element_user(PGPARAMETERS$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pgParameters" element
     */
    public boolean isSetPgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PGPARAMETERS$8) != 0;
        }
    }
    
    /**
     * Sets the "pgParameters" element
     */
    public void setPgParameters(org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType pgParameters)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().find_element_user(PGPARAMETERS$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().add_element_user(PGPARAMETERS$8);
            }
            target.set(pgParameters);
        }
    }
    
    /**
     * Appends and returns a new empty "pgParameters" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType addNewPgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().add_element_user(PGPARAMETERS$8);
            return target;
        }
    }
    
    /**
     * Nils the "pgParameters" element
     */
    public void setNilPgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().find_element_user(PGPARAMETERS$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType)get_store().add_element_user(PGPARAMETERS$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pgParameters" element
     */
    public void unsetPgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PGPARAMETERS$8, 0);
        }
    }
    
    /**
     * Gets the "pgTpList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getPgTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PGTPLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "pgTpList" element
     */
    public boolean isNilPgTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PGTPLIST$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "pgTpList" element
     */
    public boolean isSetPgTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PGTPLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "pgTpList" element
     */
    public void setPgTpList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType pgTpList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PGTPLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PGTPLIST$10);
            }
            target.set(pgTpList);
        }
    }
    
    /**
     * Appends and returns a new empty "pgTpList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewPgTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PGTPLIST$10);
            return target;
        }
    }
    
    /**
     * Nils the "pgTpList" element
     */
    public void setNilPgTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PGTPLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PGTPLIST$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "pgTpList" element
     */
    public void unsetPgTpList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PGTPLIST$10, 0);
        }
    }
    
    /**
     * Gets the "G_774_3_APSfunction" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType getG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(G7743APSFUNCTION$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "G_774_3_APSfunction" element
     */
    public boolean isNilG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(G7743APSFUNCTION$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "G_774_3_APSfunction" element
     */
    public boolean isSetG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(G7743APSFUNCTION$12) != 0;
        }
    }
    
    /**
     * Sets the "G_774_3_APSfunction" element
     */
    public void setG7743APSfunction(org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType g7743APSfunction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(G7743APSFUNCTION$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(G7743APSFUNCTION$12);
            }
            target.set(g7743APSfunction);
        }
    }
    
    /**
     * Appends and returns a new empty "G_774_3_APSfunction" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType addNewG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(G7743APSFUNCTION$12);
            return target;
        }
    }
    
    /**
     * Nils the "G_774_3_APSfunction" element
     */
    public void setNilG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(G7743APSFUNCTION$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(G7743APSFUNCTION$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "G_774_3_APSfunction" element
     */
    public void unsetG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(G7743APSFUNCTION$12, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$14) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$14);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$14);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$14, 0);
        }
    }
}
