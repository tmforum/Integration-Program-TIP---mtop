/*
 * XML Type:  ProtectionGroupType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pg/v1
 * Java type: org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pg.v1.impl;
/**
 * An XML ProtectionGroupType(@http://www.tmforum.org/mtop/nra/xsd/pg/v1).
 *
 * This is a complex type.
 */
public class ProtectionGroupTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType
{
    
    public ProtectionGroupTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROTECTIONGROUPTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "protectionGroupType");
    private static final javax.xml.namespace.QName PROTECTIONSCHEMESTATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "protectionSchemeState");
    private static final javax.xml.namespace.QName REVERSIONMODE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "reversionMode");
    private static final javax.xml.namespace.QName LAYERRATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "layerRate");
    private static final javax.xml.namespace.QName PROTECTIONGROUPPARAMETERLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "protectionGroupParameterList");
    private static final javax.xml.namespace.QName PROTECTIONRELATEDTPREFLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "protectionRelatedTpRefList");
    private static final javax.xml.namespace.QName APSPROTOCOLTYPE$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "apsProtocolType");
    private static final javax.xml.namespace.QName ASAPREF$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pg/v1", "asapRef");
    
    
    /**
     * Gets the "protectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType getProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().find_element_user(PROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionGroupType" element
     */
    public boolean isNilProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().find_element_user(PROTECTIONGROUPTYPE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionGroupType" element
     */
    public boolean isSetProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONGROUPTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "protectionGroupType" element
     */
    public void setProtectionGroupType(org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType protectionGroupType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().find_element_user(PROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().add_element_user(PROTECTIONGROUPTYPE$0);
            }
            target.set(protectionGroupType);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType addNewProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().add_element_user(PROTECTIONGROUPTYPE$0);
            return target;
        }
    }
    
    /**
     * Nils the "protectionGroupType" element
     */
    public void setNilProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().find_element_user(PROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType)get_store().add_element_user(PROTECTIONGROUPTYPE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionGroupType" element
     */
    public void unsetProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONGROUPTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType getProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionSchemeState" element
     */
    public boolean isNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionSchemeState" element
     */
    public boolean isSetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONSCHEMESTATE$2) != 0;
        }
    }
    
    /**
     * Sets the "protectionSchemeState" element
     */
    public void setProtectionSchemeState(org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType protectionSchemeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            }
            target.set(protectionSchemeState);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType addNewProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            return target;
        }
    }
    
    /**
     * Nils the "protectionSchemeState" element
     */
    public void setNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionSchemeState" element
     */
    public void unsetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONSCHEMESTATE$2, 0);
        }
    }
    
    /**
     * Gets the "reversionMode" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum getReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "reversionMode" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType xgetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "reversionMode" element
     */
    public boolean isNilReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "reversionMode" element
     */
    public boolean isSetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REVERSIONMODE$4) != 0;
        }
    }
    
    /**
     * Sets the "reversionMode" element
     */
    public void setReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum reversionMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.setEnumValue(reversionMode);
        }
    }
    
    /**
     * Sets (as xml) the "reversionMode" element
     */
    public void xsetReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType reversionMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.set(reversionMode);
        }
    }
    
    /**
     * Nils the "reversionMode" element
     */
    public void setNilReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "reversionMode" element
     */
    public void unsetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REVERSIONMODE$4, 0);
        }
    }
    
    /**
     * Gets the "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "layerRate" element
     */
    public boolean isNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "layerRate" element
     */
    public boolean isSetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAYERRATE$6) != 0;
        }
    }
    
    /**
     * Sets the "layerRate" element
     */
    public void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            }
            target.set(layerRate);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            return target;
        }
    }
    
    /**
     * Nils the "layerRate" element
     */
    public void setNilLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().find_element_user(LAYERRATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType)get_store().add_element_user(LAYERRATE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "layerRate" element
     */
    public void unsetLayerRate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAYERRATE$6, 0);
        }
    }
    
    /**
     * Gets the "protectionGroupParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType getProtectionGroupParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().find_element_user(PROTECTIONGROUPPARAMETERLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionGroupParameterList" element
     */
    public boolean isNilProtectionGroupParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().find_element_user(PROTECTIONGROUPPARAMETERLIST$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionGroupParameterList" element
     */
    public boolean isSetProtectionGroupParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONGROUPPARAMETERLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "protectionGroupParameterList" element
     */
    public void setProtectionGroupParameterList(org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType protectionGroupParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().find_element_user(PROTECTIONGROUPPARAMETERLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().add_element_user(PROTECTIONGROUPPARAMETERLIST$8);
            }
            target.set(protectionGroupParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionGroupParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType addNewProtectionGroupParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().add_element_user(PROTECTIONGROUPPARAMETERLIST$8);
            return target;
        }
    }
    
    /**
     * Nils the "protectionGroupParameterList" element
     */
    public void setNilProtectionGroupParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().find_element_user(PROTECTIONGROUPPARAMETERLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().add_element_user(PROTECTIONGROUPPARAMETERLIST$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionGroupParameterList" element
     */
    public void unsetProtectionGroupParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONGROUPPARAMETERLIST$8, 0);
        }
    }
    
    /**
     * Gets the "protectionRelatedTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getProtectionRelatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTIONRELATEDTPREFLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionRelatedTpRefList" element
     */
    public boolean isNilProtectionRelatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTIONRELATEDTPREFLIST$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionRelatedTpRefList" element
     */
    public boolean isSetProtectionRelatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONRELATEDTPREFLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "protectionRelatedTpRefList" element
     */
    public void setProtectionRelatedTpRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType protectionRelatedTpRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTIONRELATEDTPREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTIONRELATEDTPREFLIST$10);
            }
            target.set(protectionRelatedTpRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionRelatedTpRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewProtectionRelatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTIONRELATEDTPREFLIST$10);
            return target;
        }
    }
    
    /**
     * Nils the "protectionRelatedTpRefList" element
     */
    public void setNilProtectionRelatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTIONRELATEDTPREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTIONRELATEDTPREFLIST$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionRelatedTpRefList" element
     */
    public void unsetProtectionRelatedTpRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONRELATEDTPREFLIST$10, 0);
        }
    }
    
    /**
     * Gets the "apsProtocolType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType getApsProtocolType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(APSPROTOCOLTYPE$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "apsProtocolType" element
     */
    public boolean isNilApsProtocolType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(APSPROTOCOLTYPE$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "apsProtocolType" element
     */
    public boolean isSetApsProtocolType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(APSPROTOCOLTYPE$12) != 0;
        }
    }
    
    /**
     * Sets the "apsProtocolType" element
     */
    public void setApsProtocolType(org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType apsProtocolType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(APSPROTOCOLTYPE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(APSPROTOCOLTYPE$12);
            }
            target.set(apsProtocolType);
        }
    }
    
    /**
     * Appends and returns a new empty "apsProtocolType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType addNewApsProtocolType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(APSPROTOCOLTYPE$12);
            return target;
        }
    }
    
    /**
     * Nils the "apsProtocolType" element
     */
    public void setNilApsProtocolType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(APSPROTOCOLTYPE$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(APSPROTOCOLTYPE$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "apsProtocolType" element
     */
    public void unsetApsProtocolType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(APSPROTOCOLTYPE$12, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$14) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$14);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$14);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$14, 0);
        }
    }
}
