/*
 * XML Type:  PrivilegedChannelType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pgp/v1
 * Java type: org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pgp.v1.impl;
/**
 * An XML PrivilegedChannelType(@http://www.tmforum.org/mtop/nra/xsd/pgp/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType.
 */
public class PrivilegedChannelTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.nra.xsd.pgp.v1.PrivilegedChannelType
{
    
    public PrivilegedChannelTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected PrivilegedChannelTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
