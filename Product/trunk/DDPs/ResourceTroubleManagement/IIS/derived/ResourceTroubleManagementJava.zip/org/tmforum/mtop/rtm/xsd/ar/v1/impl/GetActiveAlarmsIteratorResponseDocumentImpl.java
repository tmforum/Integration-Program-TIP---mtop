/*
 * An XML document type.
 * Localname: getActiveAlarmsIteratorResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsIteratorResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1.impl;
/**
 * A document containing one getActiveAlarmsIteratorResponse(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveAlarmsIteratorResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsIteratorResponseDocument
{
    
    public GetActiveAlarmsIteratorResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEALARMSITERATORRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "getActiveAlarmsIteratorResponse");
    
    
    /**
     * Gets the "getActiveAlarmsIteratorResponse" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType getGetActiveAlarmsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType)get_store().find_element_user(GETACTIVEALARMSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveAlarmsIteratorResponse" element
     */
    public void setGetActiveAlarmsIteratorResponse(org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType getActiveAlarmsIteratorResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType)get_store().find_element_user(GETACTIVEALARMSITERATORRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType)get_store().add_element_user(GETACTIVEALARMSITERATORRESPONSE$0);
            }
            target.set(getActiveAlarmsIteratorResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveAlarmsIteratorResponse" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType addNewGetActiveAlarmsIteratorResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType)get_store().add_element_user(GETACTIVEALARMSITERATORRESPONSE$0);
            return target;
        }
    }
}
