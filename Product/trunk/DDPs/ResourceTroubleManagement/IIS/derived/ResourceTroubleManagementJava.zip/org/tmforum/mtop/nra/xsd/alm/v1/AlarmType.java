/*
 * XML Type:  AlarmType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alm/v1
 * Java type: org.tmforum.mtop.nra.xsd.alm.v1.AlarmType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alm.v1;


/**
 * An XML AlarmType(@http://www.tmforum.org/mtop/nra/xsd/alm/v1).
 *
 * This is a complex type.
 */
public interface AlarmType extends org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AlarmType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2C8DED09A1FFD775DAAB49672DE07087").resolveHandle("alarmtype44abtype");
    
    /**
     * Gets the "objectType" element
     */
    java.lang.String getObjectType();
    
    /**
     * Gets (as xml) the "objectType" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetObjectType();
    
    /**
     * True if has "objectType" element
     */
    boolean isSetObjectType();
    
    /**
     * Sets the "objectType" element
     */
    void setObjectType(java.lang.String objectType);
    
    /**
     * Sets (as xml) the "objectType" element
     */
    void xsetObjectType(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType objectType);
    
    /**
     * Unsets the "objectType" element
     */
    void unsetObjectType();
    
    /**
     * Gets the "objectName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectName();
    
    /**
     * True if has "objectName" element
     */
    boolean isSetObjectName();
    
    /**
     * Sets the "objectName" element
     */
    void setObjectName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectName);
    
    /**
     * Appends and returns a new empty "objectName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectName();
    
    /**
     * Unsets the "objectName" element
     */
    void unsetObjectName();
    
    /**
     * Gets the "neTime" element
     */
    java.util.Calendar getNeTime();
    
    /**
     * Gets (as xml) the "neTime" element
     */
    org.apache.xmlbeans.XmlDateTime xgetNeTime();
    
    /**
     * True if has "neTime" element
     */
    boolean isSetNeTime();
    
    /**
     * Sets the "neTime" element
     */
    void setNeTime(java.util.Calendar neTime);
    
    /**
     * Sets (as xml) the "neTime" element
     */
    void xsetNeTime(org.apache.xmlbeans.XmlDateTime neTime);
    
    /**
     * Unsets the "neTime" element
     */
    void unsetNeTime();
    
    /**
     * Gets the "edgePointRelated" element
     */
    boolean getEdgePointRelated();
    
    /**
     * Gets (as xml) the "edgePointRelated" element
     */
    org.apache.xmlbeans.XmlBoolean xgetEdgePointRelated();
    
    /**
     * True if has "edgePointRelated" element
     */
    boolean isSetEdgePointRelated();
    
    /**
     * Sets the "edgePointRelated" element
     */
    void setEdgePointRelated(boolean edgePointRelated);
    
    /**
     * Sets (as xml) the "edgePointRelated" element
     */
    void xsetEdgePointRelated(org.apache.xmlbeans.XmlBoolean edgePointRelated);
    
    /**
     * Unsets the "edgePointRelated" element
     */
    void unsetEdgePointRelated();
    
    /**
     * Gets the "isClearable" element
     */
    boolean getIsClearable();
    
    /**
     * Gets (as xml) the "isClearable" element
     */
    org.apache.xmlbeans.XmlBoolean xgetIsClearable();
    
    /**
     * Sets the "isClearable" element
     */
    void setIsClearable(boolean isClearable);
    
    /**
     * Sets (as xml) the "isClearable" element
     */
    void xsetIsClearable(org.apache.xmlbeans.XmlBoolean isClearable);
    
    /**
     * Gets the "aliasNameList" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType getAliasNameList();
    
    /**
     * True if has "aliasNameList" element
     */
    boolean isSetAliasNameList();
    
    /**
     * Sets the "aliasNameList" element
     */
    void setAliasNameList(org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType aliasNameList);
    
    /**
     * Appends and returns a new empty "aliasNameList" element
     */
    org.tmforum.mtop.fmw.xsd.gen.v1.AliasNameListType addNewAliasNameList();
    
    /**
     * Unsets the "aliasNameList" element
     */
    void unsetAliasNameList();
    
    /**
     * Gets the "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getLayerRate();
    
    /**
     * Sets the "layerRate" element
     */
    void setLayerRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType layerRate);
    
    /**
     * Appends and returns a new empty "layerRate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewLayerRate();
    
    /**
     * Gets the "probableCause" element
     */
    org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType getProbableCause();
    
    /**
     * Sets the "probableCause" element
     */
    void setProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType probableCause);
    
    /**
     * Appends and returns a new empty "probableCause" element
     */
    org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType addNewProbableCause();
    
    /**
     * Gets the "nativeProbableCause" element
     */
    java.lang.String getNativeProbableCause();
    
    /**
     * Gets (as xml) the "nativeProbableCause" element
     */
    org.apache.xmlbeans.XmlString xgetNativeProbableCause();
    
    /**
     * True if has "nativeProbableCause" element
     */
    boolean isSetNativeProbableCause();
    
    /**
     * Sets the "nativeProbableCause" element
     */
    void setNativeProbableCause(java.lang.String nativeProbableCause);
    
    /**
     * Sets (as xml) the "nativeProbableCause" element
     */
    void xsetNativeProbableCause(org.apache.xmlbeans.XmlString nativeProbableCause);
    
    /**
     * Unsets the "nativeProbableCause" element
     */
    void unsetNativeProbableCause();
    
    /**
     * Gets the "additionalText" element
     */
    java.lang.String getAdditionalText();
    
    /**
     * Gets (as xml) the "additionalText" element
     */
    org.apache.xmlbeans.XmlString xgetAdditionalText();
    
    /**
     * True if has "additionalText" element
     */
    boolean isSetAdditionalText();
    
    /**
     * Sets the "additionalText" element
     */
    void setAdditionalText(java.lang.String additionalText);
    
    /**
     * Sets (as xml) the "additionalText" element
     */
    void xsetAdditionalText(org.apache.xmlbeans.XmlString additionalText);
    
    /**
     * Unsets the "additionalText" element
     */
    void unsetAdditionalText();
    
    /**
     * Gets the "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum getPerceivedSeverity();
    
    /**
     * Gets (as xml) the "perceivedSeverity" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType xgetPerceivedSeverity();
    
    /**
     * Sets the "perceivedSeverity" element
     */
    void setPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType.Enum perceivedSeverity);
    
    /**
     * Sets (as xml) the "perceivedSeverity" element
     */
    void xsetPerceivedSeverity(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityType perceivedSeverity);
    
    /**
     * Gets the "affectedTpList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getAffectedTpList();
    
    /**
     * True if has "affectedTpList" element
     */
    boolean isSetAffectedTpList();
    
    /**
     * Sets the "affectedTpList" element
     */
    void setAffectedTpList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType affectedTpList);
    
    /**
     * Appends and returns a new empty "affectedTpList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewAffectedTpList();
    
    /**
     * Unsets the "affectedTpList" element
     */
    void unsetAffectedTpList();
    
    /**
     * Gets the "serviceAffecting" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum getServiceAffecting();
    
    /**
     * Gets (as xml) the "serviceAffecting" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType xgetServiceAffecting();
    
    /**
     * Sets the "serviceAffecting" element
     */
    void setServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType.Enum serviceAffecting);
    
    /**
     * Sets (as xml) the "serviceAffecting" element
     */
    void xsetServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.ServiceAffectingType serviceAffecting);
    
    /**
     * Gets the "rcaiIndicator" element
     */
    boolean getRcaiIndicator();
    
    /**
     * Gets (as xml) the "rcaiIndicator" element
     */
    org.apache.xmlbeans.XmlBoolean xgetRcaiIndicator();
    
    /**
     * Sets the "rcaiIndicator" element
     */
    void setRcaiIndicator(boolean rcaiIndicator);
    
    /**
     * Sets (as xml) the "rcaiIndicator" element
     */
    void xsetRcaiIndicator(org.apache.xmlbeans.XmlBoolean rcaiIndicator);
    
    /**
     * Gets the "acknowledgeIndication" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum getAcknowledgeIndication();
    
    /**
     * Gets (as xml) the "acknowledgeIndication" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType xgetAcknowledgeIndication();
    
    /**
     * True if has "acknowledgeIndication" element
     */
    boolean isSetAcknowledgeIndication();
    
    /**
     * Sets the "acknowledgeIndication" element
     */
    void setAcknowledgeIndication(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum acknowledgeIndication);
    
    /**
     * Sets (as xml) the "acknowledgeIndication" element
     */
    void xsetAcknowledgeIndication(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType acknowledgeIndication);
    
    /**
     * Unsets the "acknowledgeIndication" element
     */
    void unsetAcknowledgeIndication();
    
    /**
     * Gets the "X733_EventType" element
     */
    java.lang.String getX733EventType();
    
    /**
     * Gets (as xml) the "X733_EventType" element
     */
    org.apache.xmlbeans.XmlString xgetX733EventType();
    
    /**
     * True if has "X733_EventType" element
     */
    boolean isSetX733EventType();
    
    /**
     * Sets the "X733_EventType" element
     */
    void setX733EventType(java.lang.String x733EventType);
    
    /**
     * Sets (as xml) the "X733_EventType" element
     */
    void xsetX733EventType(org.apache.xmlbeans.XmlString x733EventType);
    
    /**
     * Unsets the "X733_EventType" element
     */
    void unsetX733EventType();
    
    /**
     * Gets the "X733_SpecificProblems" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType getX733SpecificProblems();
    
    /**
     * True if has "X733_SpecificProblems" element
     */
    boolean isSetX733SpecificProblems();
    
    /**
     * Sets the "X733_SpecificProblems" element
     */
    void setX733SpecificProblems(org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType x733SpecificProblems);
    
    /**
     * Appends and returns a new empty "X733_SpecificProblems" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.SpecificProblemListType addNewX733SpecificProblems();
    
    /**
     * Unsets the "X733_SpecificProblems" element
     */
    void unsetX733SpecificProblems();
    
    /**
     * Gets the "X733_BackedUpStatus" element
     */
    java.lang.String getX733BackedUpStatus();
    
    /**
     * Gets (as xml) the "X733_BackedUpStatus" element
     */
    org.apache.xmlbeans.XmlString xgetX733BackedUpStatus();
    
    /**
     * True if has "X733_BackedUpStatus" element
     */
    boolean isSetX733BackedUpStatus();
    
    /**
     * Sets the "X733_BackedUpStatus" element
     */
    void setX733BackedUpStatus(java.lang.String x733BackedUpStatus);
    
    /**
     * Sets (as xml) the "X733_BackedUpStatus" element
     */
    void xsetX733BackedUpStatus(org.apache.xmlbeans.XmlString x733BackedUpStatus);
    
    /**
     * Unsets the "X733_BackedUpStatus" element
     */
    void unsetX733BackedUpStatus();
    
    /**
     * Gets the "X733_BackUpObject" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getX733BackUpObject();
    
    /**
     * True if has "X733_BackUpObject" element
     */
    boolean isSetX733BackUpObject();
    
    /**
     * Sets the "X733_BackUpObject" element
     */
    void setX733BackUpObject(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType x733BackUpObject);
    
    /**
     * Appends and returns a new empty "X733_BackUpObject" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewX733BackUpObject();
    
    /**
     * Unsets the "X733_BackUpObject" element
     */
    void unsetX733BackUpObject();
    
    /**
     * Gets the "X733_TrendIndication" element
     */
    java.lang.String getX733TrendIndication();
    
    /**
     * Gets (as xml) the "X733_TrendIndication" element
     */
    org.apache.xmlbeans.XmlString xgetX733TrendIndication();
    
    /**
     * True if has "X733_TrendIndication" element
     */
    boolean isSetX733TrendIndication();
    
    /**
     * Sets the "X733_TrendIndication" element
     */
    void setX733TrendIndication(java.lang.String x733TrendIndication);
    
    /**
     * Sets (as xml) the "X733_TrendIndication" element
     */
    void xsetX733TrendIndication(org.apache.xmlbeans.XmlString x733TrendIndication);
    
    /**
     * Unsets the "X733_TrendIndication" element
     */
    void unsetX733TrendIndication();
    
    /**
     * Gets the "X733_CorrelatedNotifications" element
     */
    org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType getX733CorrelatedNotifications();
    
    /**
     * True if has "X733_CorrelatedNotifications" element
     */
    boolean isSetX733CorrelatedNotifications();
    
    /**
     * Sets the "X733_CorrelatedNotifications" element
     */
    void setX733CorrelatedNotifications(org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType x733CorrelatedNotifications);
    
    /**
     * Appends and returns a new empty "X733_CorrelatedNotifications" element
     */
    org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType addNewX733CorrelatedNotifications();
    
    /**
     * Unsets the "X733_CorrelatedNotifications" element
     */
    void unsetX733CorrelatedNotifications();
    
    /**
     * Gets the "X733_MonitoredAttributes" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType getX733MonitoredAttributes();
    
    /**
     * True if has "X733_MonitoredAttributes" element
     */
    boolean isSetX733MonitoredAttributes();
    
    /**
     * Sets the "X733_MonitoredAttributes" element
     */
    void setX733MonitoredAttributes(org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType x733MonitoredAttributes);
    
    /**
     * Appends and returns a new empty "X733_MonitoredAttributes" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType addNewX733MonitoredAttributes();
    
    /**
     * Unsets the "X733_MonitoredAttributes" element
     */
    void unsetX733MonitoredAttributes();
    
    /**
     * Gets the "X733_ProposedRepairActions" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType getX733ProposedRepairActions();
    
    /**
     * True if has "X733_ProposedRepairActions" element
     */
    boolean isSetX733ProposedRepairActions();
    
    /**
     * Sets the "X733_ProposedRepairActions" element
     */
    void setX733ProposedRepairActions(org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType x733ProposedRepairActions);
    
    /**
     * Appends and returns a new empty "X733_ProposedRepairActions" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProposedRepairActionListType addNewX733ProposedRepairActions();
    
    /**
     * Unsets the "X733_ProposedRepairActions" element
     */
    void unsetX733ProposedRepairActions();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType newInstance() {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
