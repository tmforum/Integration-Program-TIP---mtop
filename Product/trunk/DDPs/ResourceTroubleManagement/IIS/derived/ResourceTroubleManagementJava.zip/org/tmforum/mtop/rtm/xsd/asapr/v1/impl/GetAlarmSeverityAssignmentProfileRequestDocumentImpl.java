/*
 * An XML document type.
 * Localname: getAlarmSeverityAssignmentProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAlarmSeverityAssignmentProfileRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument
{
    
    public GetAlarmSeverityAssignmentProfileRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALARMSEVERITYASSIGNMENTPROFILEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAlarmSeverityAssignmentProfileRequest");
    
    
    /**
     * Gets the "getAlarmSeverityAssignmentProfileRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest getGetAlarmSeverityAssignmentProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAlarmSeverityAssignmentProfileRequest" element
     */
    public void setGetAlarmSeverityAssignmentProfileRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest getAlarmSeverityAssignmentProfileRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEREQUEST$0);
            }
            target.set(getAlarmSeverityAssignmentProfileRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAlarmSeverityAssignmentProfileRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest addNewGetAlarmSeverityAssignmentProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAlarmSeverityAssignmentProfileRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileRequestDocument.GetAlarmSeverityAssignmentProfileRequest
    {
        
        public GetAlarmSeverityAssignmentProfileRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "asapName");
        
        
        /**
         * Gets the "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "asapName" element
         */
        public boolean isSetAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "asapName" element
         */
        public void setAsapName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType asapName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(ASAPNAME$0);
                }
                target.set(asapName);
            }
        }
        
        /**
         * Appends and returns a new empty "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(ASAPNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "asapName" element
         */
        public void unsetAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPNAME$0, 0);
            }
        }
    }
}
