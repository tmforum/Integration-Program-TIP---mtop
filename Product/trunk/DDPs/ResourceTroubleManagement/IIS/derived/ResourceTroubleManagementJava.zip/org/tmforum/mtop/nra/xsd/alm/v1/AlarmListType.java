/*
 * XML Type:  AlarmListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alm/v1
 * Java type: org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alm.v1;


/**
 * An XML AlarmListType(@http://www.tmforum.org/mtop/nra/xsd/alm/v1).
 *
 * This is a complex type.
 */
public interface AlarmListType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(AlarmListType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sBE6052E03D6741DEC166ADB27BB9B6C3").resolveHandle("alarmlisttype382dtype");
    
    /**
     * Gets a List of "alarm" elements
     */
    java.util.List<org.tmforum.mtop.nra.xsd.alm.v1.AlarmType> getAlarmList();
    
    /**
     * Gets array of all "alarm" elements
     * @deprecated
     */
    org.tmforum.mtop.nra.xsd.alm.v1.AlarmType[] getAlarmArray();
    
    /**
     * Gets ith "alarm" element
     */
    org.tmforum.mtop.nra.xsd.alm.v1.AlarmType getAlarmArray(int i);
    
    /**
     * Returns number of "alarm" element
     */
    int sizeOfAlarmArray();
    
    /**
     * Sets array of all "alarm" element
     */
    void setAlarmArray(org.tmforum.mtop.nra.xsd.alm.v1.AlarmType[] alarmArray);
    
    /**
     * Sets ith "alarm" element
     */
    void setAlarmArray(int i, org.tmforum.mtop.nra.xsd.alm.v1.AlarmType alarm);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "alarm" element
     */
    org.tmforum.mtop.nra.xsd.alm.v1.AlarmType insertNewAlarm(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "alarm" element
     */
    org.tmforum.mtop.nra.xsd.alm.v1.AlarmType addNewAlarm();
    
    /**
     * Removes the ith "alarm" element
     */
    void removeAlarm(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType newInstance() {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.alm.v1.AlarmListType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
