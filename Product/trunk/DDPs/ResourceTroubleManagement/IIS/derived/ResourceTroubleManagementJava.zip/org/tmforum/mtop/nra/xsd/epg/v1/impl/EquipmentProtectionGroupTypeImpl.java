/*
 * XML Type:  EquipmentProtectionGroupType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/epg/v1
 * Java type: org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.epg.v1.impl;
/**
 * An XML EquipmentProtectionGroupType(@http://www.tmforum.org/mtop/nra/xsd/epg/v1).
 *
 * This is a complex type.
 */
public class EquipmentProtectionGroupTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType
{
    
    public EquipmentProtectionGroupTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EPROTECTIONGROUPTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "eProtectionGroupType");
    private static final javax.xml.namespace.QName PROTECTIONSCHEMESTATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "protectionSchemeState");
    private static final javax.xml.namespace.QName REVERSIONMODE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "reversionMode");
    private static final javax.xml.namespace.QName EPGPARAMETERS$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "epgParameters");
    private static final javax.xml.namespace.QName PROTECTEDLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "protectedList");
    private static final javax.xml.namespace.QName PROTECTINGLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "protectingList");
    private static final javax.xml.namespace.QName G7743APSFUNCTION$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "G_774_3_APSfunction");
    private static final javax.xml.namespace.QName ASAPREF$14 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "asapRef");
    
    
    /**
     * Gets the "eProtectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType getEProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "eProtectionGroupType" element
     */
    public boolean isNilEProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EPROTECTIONGROUPTYPE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "eProtectionGroupType" element
     */
    public boolean isSetEProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPROTECTIONGROUPTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "eProtectionGroupType" element
     */
    public void setEProtectionGroupType(org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType eProtectionGroupType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EPROTECTIONGROUPTYPE$0);
            }
            target.set(eProtectionGroupType);
        }
    }
    
    /**
     * Appends and returns a new empty "eProtectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType addNewEProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EPROTECTIONGROUPTYPE$0);
            return target;
        }
    }
    
    /**
     * Nils the "eProtectionGroupType" element
     */
    public void setNilEProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EPROTECTIONGROUPTYPE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "eProtectionGroupType" element
     */
    public void unsetEProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPROTECTIONGROUPTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType getProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionSchemeState" element
     */
    public boolean isNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionSchemeState" element
     */
    public boolean isSetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONSCHEMESTATE$2) != 0;
        }
    }
    
    /**
     * Sets the "protectionSchemeState" element
     */
    public void setProtectionSchemeState(org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType protectionSchemeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            }
            target.set(protectionSchemeState);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType addNewProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            return target;
        }
    }
    
    /**
     * Nils the "protectionSchemeState" element
     */
    public void setNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionSchemeState" element
     */
    public void unsetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONSCHEMESTATE$2, 0);
        }
    }
    
    /**
     * Gets the "reversionMode" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum getReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "reversionMode" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType xgetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "reversionMode" element
     */
    public boolean isNilReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "reversionMode" element
     */
    public boolean isSetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REVERSIONMODE$4) != 0;
        }
    }
    
    /**
     * Sets the "reversionMode" element
     */
    public void setReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum reversionMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.setEnumValue(reversionMode);
        }
    }
    
    /**
     * Sets (as xml) the "reversionMode" element
     */
    public void xsetReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType reversionMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.set(reversionMode);
        }
    }
    
    /**
     * Nils the "reversionMode" element
     */
    public void setNilReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "reversionMode" element
     */
    public void unsetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REVERSIONMODE$4, 0);
        }
    }
    
    /**
     * Gets the "epgParameters" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters getEpgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters)get_store().find_element_user(EPGPARAMETERS$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "epgParameters" element
     */
    public boolean isNilEpgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters)get_store().find_element_user(EPGPARAMETERS$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "epgParameters" element
     */
    public boolean isSetEpgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGPARAMETERS$6) != 0;
        }
    }
    
    /**
     * Sets the "epgParameters" element
     */
    public void setEpgParameters(org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters epgParameters)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters)get_store().find_element_user(EPGPARAMETERS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters)get_store().add_element_user(EPGPARAMETERS$6);
            }
            target.set(epgParameters);
        }
    }
    
    /**
     * Appends and returns a new empty "epgParameters" element
     */
    public org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters addNewEpgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters)get_store().add_element_user(EPGPARAMETERS$6);
            return target;
        }
    }
    
    /**
     * Nils the "epgParameters" element
     */
    public void setNilEpgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters target = null;
            target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters)get_store().find_element_user(EPGPARAMETERS$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters)get_store().add_element_user(EPGPARAMETERS$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "epgParameters" element
     */
    public void unsetEpgParameters()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGPARAMETERS$6, 0);
        }
    }
    
    /**
     * Gets the "protectedList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getProtectedList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PROTECTEDLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectedList" element
     */
    public boolean isNilProtectedList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PROTECTEDLIST$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectedList" element
     */
    public boolean isSetProtectedList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTEDLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "protectedList" element
     */
    public void setProtectedList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType protectedList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PROTECTEDLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PROTECTEDLIST$8);
            }
            target.set(protectedList);
        }
    }
    
    /**
     * Appends and returns a new empty "protectedList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewProtectedList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PROTECTEDLIST$8);
            return target;
        }
    }
    
    /**
     * Nils the "protectedList" element
     */
    public void setNilProtectedList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PROTECTEDLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PROTECTEDLIST$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectedList" element
     */
    public void unsetProtectedList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTEDLIST$8, 0);
        }
    }
    
    /**
     * Gets the "protectingList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getProtectingList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PROTECTINGLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectingList" element
     */
    public boolean isNilProtectingList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PROTECTINGLIST$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectingList" element
     */
    public boolean isSetProtectingList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTINGLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "protectingList" element
     */
    public void setProtectingList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType protectingList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PROTECTINGLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PROTECTINGLIST$10);
            }
            target.set(protectingList);
        }
    }
    
    /**
     * Appends and returns a new empty "protectingList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewProtectingList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PROTECTINGLIST$10);
            return target;
        }
    }
    
    /**
     * Nils the "protectingList" element
     */
    public void setNilProtectingList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().find_element_user(PROTECTINGLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType)get_store().add_element_user(PROTECTINGLIST$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectingList" element
     */
    public void unsetProtectingList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTINGLIST$10, 0);
        }
    }
    
    /**
     * Gets the "G_774_3_APSfunction" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType getG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(G7743APSFUNCTION$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "G_774_3_APSfunction" element
     */
    public boolean isNilG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(G7743APSFUNCTION$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "G_774_3_APSfunction" element
     */
    public boolean isSetG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(G7743APSFUNCTION$12) != 0;
        }
    }
    
    /**
     * Sets the "G_774_3_APSfunction" element
     */
    public void setG7743APSfunction(org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType g7743APSfunction)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(G7743APSFUNCTION$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(G7743APSFUNCTION$12);
            }
            target.set(g7743APSfunction);
        }
    }
    
    /**
     * Appends and returns a new empty "G_774_3_APSfunction" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType addNewG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(G7743APSFUNCTION$12);
            return target;
        }
    }
    
    /**
     * Nils the "G_774_3_APSfunction" element
     */
    public void setNilG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().find_element_user(G7743APSFUNCTION$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType)get_store().add_element_user(G7743APSFUNCTION$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "G_774_3_APSfunction" element
     */
    public void unsetG7743APSfunction()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(G7743APSFUNCTION$12, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$14) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$14);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$14);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$14, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$14);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$14, 0);
        }
    }
    /**
     * An XML epgParameters(@http://www.tmforum.org/mtop/nra/xsd/epg/v1).
     *
     * This is a complex type.
     */
    public static class EpgParametersImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType.EpgParameters
    {
        
        public EpgParametersImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
