/*
 * XML Type:  EquipmentProtectionGroupType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/epg/v1
 * Java type: org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.epg.v1.impl;
/**
 * An XML EquipmentProtectionGroupType(@http://www.tmforum.org/mtop/nra/xsd/epg/v1).
 *
 * This is a complex type.
 */
public class EquipmentProtectionGroupTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupType
{
    
    public EquipmentProtectionGroupTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EQUIPMENTPROTECTIONGROUPTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "equipmentProtectionGroupType");
    private static final javax.xml.namespace.QName PROTECTIONSCHEMESTATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "protectionSchemeState");
    private static final javax.xml.namespace.QName REVERSIONMODE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "reversionMode");
    private static final javax.xml.namespace.QName EPGPARAMETERLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "epgParameterList");
    private static final javax.xml.namespace.QName PROTECTEDEQUIPMENTREFLIST$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "protectedEquipmentRefList");
    private static final javax.xml.namespace.QName PROTECTINGEQUIPMENTREFLIST$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "protectingEquipmentRefList");
    private static final javax.xml.namespace.QName ASAPREF$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/epg/v1", "asapRef");
    
    
    /**
     * Gets the "equipmentProtectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType getEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "equipmentProtectionGroupType" element
     */
    public boolean isNilEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "equipmentProtectionGroupType" element
     */
    public boolean isSetEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQUIPMENTPROTECTIONGROUPTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "equipmentProtectionGroupType" element
     */
    public void setEquipmentProtectionGroupType(org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType equipmentProtectionGroupType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0);
            }
            target.set(equipmentProtectionGroupType);
        }
    }
    
    /**
     * Appends and returns a new empty "equipmentProtectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType addNewEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0);
            return target;
        }
    }
    
    /**
     * Nils the "equipmentProtectionGroupType" element
     */
    public void setNilEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "equipmentProtectionGroupType" element
     */
    public void unsetEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType getProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectionSchemeState" element
     */
    public boolean isNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectionSchemeState" element
     */
    public boolean isSetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTIONSCHEMESTATE$2) != 0;
        }
    }
    
    /**
     * Sets the "protectionSchemeState" element
     */
    public void setProtectionSchemeState(org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType protectionSchemeState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            }
            target.set(protectionSchemeState);
        }
    }
    
    /**
     * Appends and returns a new empty "protectionSchemeState" element
     */
    public org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType addNewProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            return target;
        }
    }
    
    /**
     * Nils the "protectionSchemeState" element
     */
    public void setNilProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().find_element_user(PROTECTIONSCHEMESTATE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType)get_store().add_element_user(PROTECTIONSCHEMESTATE$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectionSchemeState" element
     */
    public void unsetProtectionSchemeState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTIONSCHEMESTATE$2, 0);
        }
    }
    
    /**
     * Gets the "reversionMode" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum getReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "reversionMode" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType xgetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "reversionMode" element
     */
    public boolean isNilReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "reversionMode" element
     */
    public boolean isSetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(REVERSIONMODE$4) != 0;
        }
    }
    
    /**
     * Sets the "reversionMode" element
     */
    public void setReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum reversionMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.setEnumValue(reversionMode);
        }
    }
    
    /**
     * Sets (as xml) the "reversionMode" element
     */
    public void xsetReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType reversionMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.set(reversionMode);
        }
    }
    
    /**
     * Nils the "reversionMode" element
     */
    public void setNilReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().find_element_user(REVERSIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType)get_store().add_element_user(REVERSIONMODE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "reversionMode" element
     */
    public void unsetReversionMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(REVERSIONMODE$4, 0);
        }
    }
    
    /**
     * Gets the "epgParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType getEpgParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().find_element_user(EPGPARAMETERLIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "epgParameterList" element
     */
    public boolean isNilEpgParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().find_element_user(EPGPARAMETERLIST$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "epgParameterList" element
     */
    public boolean isSetEpgParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGPARAMETERLIST$6) != 0;
        }
    }
    
    /**
     * Sets the "epgParameterList" element
     */
    public void setEpgParameterList(org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType epgParameterList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().find_element_user(EPGPARAMETERLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().add_element_user(EPGPARAMETERLIST$6);
            }
            target.set(epgParameterList);
        }
    }
    
    /**
     * Appends and returns a new empty "epgParameterList" element
     */
    public org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType addNewEpgParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().add_element_user(EPGPARAMETERLIST$6);
            return target;
        }
    }
    
    /**
     * Nils the "epgParameterList" element
     */
    public void setNilEpgParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType target = null;
            target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().find_element_user(EPGPARAMETERLIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersListType)get_store().add_element_user(EPGPARAMETERLIST$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "epgParameterList" element
     */
    public void unsetEpgParameterList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGPARAMETERLIST$6, 0);
        }
    }
    
    /**
     * Gets the "protectedEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTEDEQUIPMENTREFLIST$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectedEquipmentRefList" element
     */
    public boolean isNilProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTEDEQUIPMENTREFLIST$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectedEquipmentRefList" element
     */
    public boolean isSetProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTEDEQUIPMENTREFLIST$8) != 0;
        }
    }
    
    /**
     * Sets the "protectedEquipmentRefList" element
     */
    public void setProtectedEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType protectedEquipmentRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTEDEQUIPMENTREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTEDEQUIPMENTREFLIST$8);
            }
            target.set(protectedEquipmentRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "protectedEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTEDEQUIPMENTREFLIST$8);
            return target;
        }
    }
    
    /**
     * Nils the "protectedEquipmentRefList" element
     */
    public void setNilProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTEDEQUIPMENTREFLIST$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTEDEQUIPMENTREFLIST$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectedEquipmentRefList" element
     */
    public void unsetProtectedEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTEDEQUIPMENTREFLIST$8, 0);
        }
    }
    
    /**
     * Gets the "protectingEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getProtectingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTINGEQUIPMENTREFLIST$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectingEquipmentRefList" element
     */
    public boolean isNilProtectingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTINGEQUIPMENTREFLIST$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectingEquipmentRefList" element
     */
    public boolean isSetProtectingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTINGEQUIPMENTREFLIST$10) != 0;
        }
    }
    
    /**
     * Sets the "protectingEquipmentRefList" element
     */
    public void setProtectingEquipmentRefList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType protectingEquipmentRefList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTINGEQUIPMENTREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTINGEQUIPMENTREFLIST$10);
            }
            target.set(protectingEquipmentRefList);
        }
    }
    
    /**
     * Appends and returns a new empty "protectingEquipmentRefList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewProtectingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTINGEQUIPMENTREFLIST$10);
            return target;
        }
    }
    
    /**
     * Nils the "protectingEquipmentRefList" element
     */
    public void setNilProtectingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(PROTECTINGEQUIPMENTREFLIST$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(PROTECTINGEQUIPMENTREFLIST$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectingEquipmentRefList" element
     */
    public void unsetProtectingEquipmentRefList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTINGEQUIPMENTREFLIST$10, 0);
        }
    }
    
    /**
     * Gets the "asapRef" element
     */
    public java.lang.String getAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    public org.apache.xmlbeans.XmlString xgetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$12, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "asapRef" element
     */
    public boolean isNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "asapRef" element
     */
    public boolean isSetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ASAPREF$12) != 0;
        }
    }
    
    /**
     * Sets the "asapRef" element
     */
    public void setAsapRef(java.lang.String asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ASAPREF$12);
            }
            target.setStringValue(asapRef);
        }
    }
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    public void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$12);
            }
            target.set(asapRef);
        }
    }
    
    /**
     * Nils the "asapRef" element
     */
    public void setNilAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(ASAPREF$12, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(ASAPREF$12);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "asapRef" element
     */
    public void unsetAsapRef()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ASAPREF$12, 0);
        }
    }
}
