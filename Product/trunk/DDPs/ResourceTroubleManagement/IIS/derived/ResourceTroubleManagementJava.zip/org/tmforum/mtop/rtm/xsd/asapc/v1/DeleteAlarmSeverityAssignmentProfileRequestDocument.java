/*
 * An XML document type.
 * Localname: deleteAlarmSeverityAssignmentProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1;


/**
 * A document containing one deleteAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public interface DeleteAlarmSeverityAssignmentProfileRequestDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DeleteAlarmSeverityAssignmentProfileRequestDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sBE6052E03D6741DEC166ADB27BB9B6C3").resolveHandle("deletealarmseverityassignmentprofilerequest1ea2doctype");
    
    /**
     * Gets the "deleteAlarmSeverityAssignmentProfileRequest" element
     */
    org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument.DeleteAlarmSeverityAssignmentProfileRequest getDeleteAlarmSeverityAssignmentProfileRequest();
    
    /**
     * Sets the "deleteAlarmSeverityAssignmentProfileRequest" element
     */
    void setDeleteAlarmSeverityAssignmentProfileRequest(org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument.DeleteAlarmSeverityAssignmentProfileRequest deleteAlarmSeverityAssignmentProfileRequest);
    
    /**
     * Appends and returns a new empty "deleteAlarmSeverityAssignmentProfileRequest" element
     */
    org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument.DeleteAlarmSeverityAssignmentProfileRequest addNewDeleteAlarmSeverityAssignmentProfileRequest();
    
    /**
     * An XML deleteAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public interface DeleteAlarmSeverityAssignmentProfileRequest extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DeleteAlarmSeverityAssignmentProfileRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sBE6052E03D6741DEC166ADB27BB9B6C3").resolveHandle("deletealarmseverityassignmentprofilerequest2c80elemtype");
        
        /**
         * Gets the "asapName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getAsapName();
        
        /**
         * Tests for nil "asapName" element
         */
        boolean isNilAsapName();
        
        /**
         * True if has "asapName" element
         */
        boolean isSetAsapName();
        
        /**
         * Sets the "asapName" element
         */
        void setAsapName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType asapName);
        
        /**
         * Appends and returns a new empty "asapName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewAsapName();
        
        /**
         * Nils the "asapName" element
         */
        void setNilAsapName();
        
        /**
         * Unsets the "asapName" element
         */
        void unsetAsapName();
        
        /**
         * Gets the "vendorExtensions" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions();
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        boolean isNilVendorExtensions();
        
        /**
         * True if has "vendorExtensions" element
         */
        boolean isSetVendorExtensions();
        
        /**
         * Sets the "vendorExtensions" element
         */
        void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions);
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions();
        
        /**
         * Nils the "vendorExtensions" element
         */
        void setNilVendorExtensions();
        
        /**
         * Unsets the "vendorExtensions" element
         */
        void unsetVendorExtensions();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument.DeleteAlarmSeverityAssignmentProfileRequest newInstance() {
              return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument.DeleteAlarmSeverityAssignmentProfileRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument.DeleteAlarmSeverityAssignmentProfileRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument.DeleteAlarmSeverityAssignmentProfileRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument newInstance() {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileRequestDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
