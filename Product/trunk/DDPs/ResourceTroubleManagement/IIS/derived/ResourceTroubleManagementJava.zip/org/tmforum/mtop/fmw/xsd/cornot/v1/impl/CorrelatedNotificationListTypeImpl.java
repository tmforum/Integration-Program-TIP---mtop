/*
 * XML Type:  CorrelatedNotificationListType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cornot/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cornot.v1.impl;
/**
 * An XML CorrelatedNotificationListType(@http://www.tmforum.org/mtop/fmw/xsd/cornot/v1).
 *
 * This is a complex type.
 */
public class CorrelatedNotificationListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationListType
{
    
    public CorrelatedNotificationListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CORRELATEDNOTIFICATIONS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cornot/v1", "correlatedNotifications");
    
    
    /**
     * Gets a List of "correlatedNotifications" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType> getCorrelatedNotificationsList()
    {
        final class CorrelatedNotificationsList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType>
        {
            public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType get(int i)
                { return CorrelatedNotificationListTypeImpl.this.getCorrelatedNotificationsArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType set(int i, org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType o)
            {
                org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType old = CorrelatedNotificationListTypeImpl.this.getCorrelatedNotificationsArray(i);
                CorrelatedNotificationListTypeImpl.this.setCorrelatedNotificationsArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType o)
                { CorrelatedNotificationListTypeImpl.this.insertNewCorrelatedNotifications(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType old = CorrelatedNotificationListTypeImpl.this.getCorrelatedNotificationsArray(i);
                CorrelatedNotificationListTypeImpl.this.removeCorrelatedNotifications(i);
                return old;
            }
            
            public int size()
                { return CorrelatedNotificationListTypeImpl.this.sizeOfCorrelatedNotificationsArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CorrelatedNotificationsList();
        }
    }
    
    /**
     * Gets array of all "correlatedNotifications" elements
     */
    public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType[] getCorrelatedNotificationsArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CORRELATEDNOTIFICATIONS$0, targetList);
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType[] result = new org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "correlatedNotifications" element
     */
    public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType getCorrelatedNotificationsArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType)get_store().find_element_user(CORRELATEDNOTIFICATIONS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "correlatedNotifications" element
     */
    public int sizeOfCorrelatedNotificationsArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CORRELATEDNOTIFICATIONS$0);
        }
    }
    
    /**
     * Sets array of all "correlatedNotifications" element
     */
    public void setCorrelatedNotificationsArray(org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType[] correlatedNotificationsArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(correlatedNotificationsArray, CORRELATEDNOTIFICATIONS$0);
        }
    }
    
    /**
     * Sets ith "correlatedNotifications" element
     */
    public void setCorrelatedNotificationsArray(int i, org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType correlatedNotifications)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType)get_store().find_element_user(CORRELATEDNOTIFICATIONS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(correlatedNotifications);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "correlatedNotifications" element
     */
    public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType insertNewCorrelatedNotifications(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType)get_store().insert_element_user(CORRELATEDNOTIFICATIONS$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "correlatedNotifications" element
     */
    public org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType addNewCorrelatedNotifications()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType)get_store().add_element_user(CORRELATEDNOTIFICATIONS$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "correlatedNotifications" element
     */
    public void removeCorrelatedNotifications(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CORRELATEDNOTIFICATIONS$0, i);
        }
    }
}
