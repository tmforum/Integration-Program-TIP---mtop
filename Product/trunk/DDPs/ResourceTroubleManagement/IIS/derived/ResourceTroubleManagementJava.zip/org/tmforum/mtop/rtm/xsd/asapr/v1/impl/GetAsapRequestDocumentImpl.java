/*
 * An XML document type.
 * Localname: getAsapRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAsapRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAsapRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument
{
    
    public GetAsapRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASAPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAsapRequest");
    
    
    /**
     * Gets the "getAsapRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest getGetAsapRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest)get_store().find_element_user(GETASAPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAsapRequest" element
     */
    public void setGetAsapRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest getAsapRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest)get_store().find_element_user(GETASAPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest)get_store().add_element_user(GETASAPREQUEST$0);
            }
            target.set(getAsapRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAsapRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest addNewGetAsapRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest)get_store().add_element_user(GETASAPREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAsapRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAsapRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapRequestDocument.GetAsapRequest
    {
        
        public GetAsapRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "asapName");
        
        
        /**
         * Gets the "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "asapName" element
         */
        public void setAsapName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType asapName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ASAPNAME$0);
                }
                target.set(asapName);
            }
        }
        
        /**
         * Appends and returns a new empty "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(ASAPNAME$0);
                return target;
            }
        }
    }
}
