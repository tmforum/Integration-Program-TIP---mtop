/*
 * XML Type:  AlarmOrTcaIdType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/atcaid/v1
 * Java type: org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.atcaid.v1.impl;
/**
 * An XML AlarmOrTcaIdType(@http://www.tmforum.org/mtop/nra/xsd/atcaid/v1).
 *
 * This is a complex type.
 */
public class AlarmOrTcaIdTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdType
{
    
    public AlarmOrTcaIdTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARMID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/atcaid/v1", "alarmId");
    private static final javax.xml.namespace.QName TCAID$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/atcaid/v1", "tcaId");
    
    
    /**
     * Gets the "alarmId" element
     */
    public org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType getAlarmId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType)get_store().find_element_user(ALARMID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "alarmId" element
     */
    public boolean isSetAlarmId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMID$0) != 0;
        }
    }
    
    /**
     * Sets the "alarmId" element
     */
    public void setAlarmId(org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType alarmId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType)get_store().find_element_user(ALARMID$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType)get_store().add_element_user(ALARMID$0);
            }
            target.set(alarmId);
        }
    }
    
    /**
     * Appends and returns a new empty "alarmId" element
     */
    public org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType addNewAlarmId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.alarmid.v1.AlarmIdType)get_store().add_element_user(ALARMID$0);
            return target;
        }
    }
    
    /**
     * Unsets the "alarmId" element
     */
    public void unsetAlarmId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMID$0, 0);
        }
    }
    
    /**
     * Gets the "tcaId" element
     */
    public org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType getTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType)get_store().find_element_user(TCAID$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "tcaId" element
     */
    public boolean isSetTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(TCAID$2) != 0;
        }
    }
    
    /**
     * Sets the "tcaId" element
     */
    public void setTcaId(org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType tcaId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType)get_store().find_element_user(TCAID$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType)get_store().add_element_user(TCAID$2);
            }
            target.set(tcaId);
        }
    }
    
    /**
     * Appends and returns a new empty "tcaId" element
     */
    public org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType addNewTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType target = null;
            target = (org.tmforum.mtop.nra.xsd.tcaid.v1.TcaIdType)get_store().add_element_user(TCAID$2);
            return target;
        }
    }
    
    /**
     * Unsets the "tcaId" element
     */
    public void unsetTcaId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(TCAID$2, 0);
        }
    }
}
