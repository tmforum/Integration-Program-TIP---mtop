/*
 * XML Type:  ActiveAlarmFilterType
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1;


/**
 * An XML ActiveAlarmFilterType(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1).
 *
 * This is a complex type.
 */
public interface ActiveAlarmFilterType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ActiveAlarmFilterType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sD7F14712642FA7BC89FBCB45763AB9FB").resolveHandle("activealarmfiltertypee1d6type");
    
    /**
     * Gets the "source" element
     */
    org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType.Enum getSource();
    
    /**
     * Gets (as xml) the "source" element
     */
    org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType xgetSource();
    
    /**
     * True if has "source" element
     */
    boolean isSetSource();
    
    /**
     * Sets the "source" element
     */
    void setSource(org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType.Enum source);
    
    /**
     * Sets (as xml) the "source" element
     */
    void xsetSource(org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType source);
    
    /**
     * Unsets the "source" element
     */
    void unsetSource();
    
    /**
     * Gets the "scope" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getScope();
    
    /**
     * True if has "scope" element
     */
    boolean isSetScope();
    
    /**
     * Sets the "scope" element
     */
    void setScope(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType scope);
    
    /**
     * Appends and returns a new empty "scope" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewScope();
    
    /**
     * Unsets the "scope" element
     */
    void unsetScope();
    
    /**
     * Gets the "perceivedSeverityList" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType getPerceivedSeverityList();
    
    /**
     * True if has "perceivedSeverityList" element
     */
    boolean isSetPerceivedSeverityList();
    
    /**
     * Sets the "perceivedSeverityList" element
     */
    void setPerceivedSeverityList(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType perceivedSeverityList);
    
    /**
     * Appends and returns a new empty "perceivedSeverityList" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType addNewPerceivedSeverityList();
    
    /**
     * Unsets the "perceivedSeverityList" element
     */
    void unsetPerceivedSeverityList();
    
    /**
     * Gets the "probableCauseList" element
     */
    org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType getProbableCauseList();
    
    /**
     * True if has "probableCauseList" element
     */
    boolean isSetProbableCauseList();
    
    /**
     * Sets the "probableCauseList" element
     */
    void setProbableCauseList(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType probableCauseList);
    
    /**
     * Appends and returns a new empty "probableCauseList" element
     */
    org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType addNewProbableCauseList();
    
    /**
     * Unsets the "probableCauseList" element
     */
    void unsetProbableCauseList();
    
    /**
     * Gets the "acknowledgeIndication" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum getAcknowledgeIndication();
    
    /**
     * Gets (as xml) the "acknowledgeIndication" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType xgetAcknowledgeIndication();
    
    /**
     * True if has "acknowledgeIndication" element
     */
    boolean isSetAcknowledgeIndication();
    
    /**
     * Sets the "acknowledgeIndication" element
     */
    void setAcknowledgeIndication(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum acknowledgeIndication);
    
    /**
     * Sets (as xml) the "acknowledgeIndication" element
     */
    void xsetAcknowledgeIndication(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType acknowledgeIndication);
    
    /**
     * Unsets the "acknowledgeIndication" element
     */
    void unsetAcknowledgeIndication();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType newInstance() {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
