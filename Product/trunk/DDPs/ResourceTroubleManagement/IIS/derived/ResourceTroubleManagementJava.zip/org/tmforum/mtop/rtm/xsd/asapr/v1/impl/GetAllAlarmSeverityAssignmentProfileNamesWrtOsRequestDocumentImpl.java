/*
 * An XML document type.
 * Localname: getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument
{
    
    public GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest");
    
    
    /**
     * Gets the "getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest getGetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest" element
     */
    public void setGetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSREQUEST$0);
            }
            target.set(getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest addNewGetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllAlarmSeverityAssignmentProfileNamesWrtOsRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequest
    {
        
        public GetAllAlarmSeverityAssignmentProfileNamesWrtOsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName OSNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "osName");
        
        
        /**
         * Gets the "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "osName" element
         */
        public boolean isSetOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OSNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "osName" element
         */
        public void setOsName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType osName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(OSNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OSNAME$0);
                }
                target.set(osName);
            }
        }
        
        /**
         * Appends and returns a new empty "osName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(OSNAME$0);
                return target;
            }
        }
        
        /**
         * Unsets the "osName" element
         */
        public void unsetOsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OSNAME$0, 0);
            }
        }
    }
}
