/*
 * An XML document type.
 * Localname: performMaintenanceOperationResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/mc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.mc.v1.impl;
/**
 * A document containing one performMaintenanceOperationResponse(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1) element.
 *
 * This is a complex type.
 */
public class PerformMaintenanceOperationResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument
{
    
    public PerformMaintenanceOperationResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERFORMMAINTENANCEOPERATIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "performMaintenanceOperationResponse");
    
    
    /**
     * Gets the "performMaintenanceOperationResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse getPerformMaintenanceOperationResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse)get_store().find_element_user(PERFORMMAINTENANCEOPERATIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "performMaintenanceOperationResponse" element
     */
    public void setPerformMaintenanceOperationResponse(org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse performMaintenanceOperationResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse)get_store().find_element_user(PERFORMMAINTENANCEOPERATIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse)get_store().add_element_user(PERFORMMAINTENANCEOPERATIONRESPONSE$0);
            }
            target.set(performMaintenanceOperationResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "performMaintenanceOperationResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse addNewPerformMaintenanceOperationResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse)get_store().add_element_user(PERFORMMAINTENANCEOPERATIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML performMaintenanceOperationResponse(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1).
     *
     * This is a complex type.
     */
    public static class PerformMaintenanceOperationResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationResponseDocument.PerformMaintenanceOperationResponse
    {
        
        public PerformMaintenanceOperationResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
