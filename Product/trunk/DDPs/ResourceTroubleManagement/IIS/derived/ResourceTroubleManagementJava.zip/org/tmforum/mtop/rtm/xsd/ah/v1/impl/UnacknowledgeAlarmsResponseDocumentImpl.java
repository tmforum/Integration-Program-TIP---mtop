/*
 * An XML document type.
 * Localname: unacknowledgeAlarmsResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ah/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ah.v1.impl;
/**
 * A document containing one unacknowledgeAlarmsResponse(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1) element.
 *
 * This is a complex type.
 */
public class UnacknowledgeAlarmsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument
{
    
    public UnacknowledgeAlarmsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UNACKNOWLEDGEALARMSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "unacknowledgeAlarmsResponse");
    
    
    /**
     * Gets the "unacknowledgeAlarmsResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse getUnacknowledgeAlarmsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse)get_store().find_element_user(UNACKNOWLEDGEALARMSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "unacknowledgeAlarmsResponse" element
     */
    public void setUnacknowledgeAlarmsResponse(org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse unacknowledgeAlarmsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse)get_store().find_element_user(UNACKNOWLEDGEALARMSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse)get_store().add_element_user(UNACKNOWLEDGEALARMSRESPONSE$0);
            }
            target.set(unacknowledgeAlarmsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "unacknowledgeAlarmsResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse addNewUnacknowledgeAlarmsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse)get_store().add_element_user(UNACKNOWLEDGEALARMSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML unacknowledgeAlarmsResponse(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1).
     *
     * This is a complex type.
     */
    public static class UnacknowledgeAlarmsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.UnacknowledgeAlarmsResponseDocument.UnacknowledgeAlarmsResponse
    {
        
        public UnacknowledgeAlarmsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FAILEDUNACKNOWLEDGEIDLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "failedUnacknowledgeIdList");
        
        
        /**
         * Gets the "failedUnacknowledgeIdList" element
         */
        public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType getFailedUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(FAILEDUNACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "failedUnacknowledgeIdList" element
         */
        public boolean isNilFailedUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(FAILEDUNACKNOWLEDGEIDLIST$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "failedUnacknowledgeIdList" element
         */
        public boolean isSetFailedUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILEDUNACKNOWLEDGEIDLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "failedUnacknowledgeIdList" element
         */
        public void setFailedUnacknowledgeIdList(org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType failedUnacknowledgeIdList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(FAILEDUNACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(FAILEDUNACKNOWLEDGEIDLIST$0);
                }
                target.set(failedUnacknowledgeIdList);
            }
        }
        
        /**
         * Appends and returns a new empty "failedUnacknowledgeIdList" element
         */
        public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType addNewFailedUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(FAILEDUNACKNOWLEDGEIDLIST$0);
                return target;
            }
        }
        
        /**
         * Nils the "failedUnacknowledgeIdList" element
         */
        public void setNilFailedUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(FAILEDUNACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(FAILEDUNACKNOWLEDGEIDLIST$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "failedUnacknowledgeIdList" element
         */
        public void unsetFailedUnacknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILEDUNACKNOWLEDGEIDLIST$0, 0);
            }
        }
    }
}
