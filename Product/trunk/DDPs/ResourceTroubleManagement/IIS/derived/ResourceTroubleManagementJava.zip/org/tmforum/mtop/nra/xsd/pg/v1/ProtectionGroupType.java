/*
 * XML Type:  ProtectionGroupType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pg/v1
 * Java type: org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pg.v1;


/**
 * An XML ProtectionGroupType(@http://www.tmforum.org/mtop/nra/xsd/pg/v1).
 *
 * This is a complex type.
 */
public interface ProtectionGroupType extends org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProtectionGroupType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2C8DED09A1FFD775DAAB49672DE07087").resolveHandle("protectiongrouptype41e5type");
    
    /**
     * Gets the "protectionGroupType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType getProtectionGroupType();
    
    /**
     * Tests for nil "protectionGroupType" element
     */
    boolean isNilProtectionGroupType();
    
    /**
     * True if has "protectionGroupType" element
     */
    boolean isSetProtectionGroupType();
    
    /**
     * Sets the "protectionGroupType" element
     */
    void setProtectionGroupType(org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType protectionGroupType);
    
    /**
     * Appends and returns a new empty "protectionGroupType" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ProtectionGroupTypeType addNewProtectionGroupType();
    
    /**
     * Nils the "protectionGroupType" element
     */
    void setNilProtectionGroupType();
    
    /**
     * Unsets the "protectionGroupType" element
     */
    void unsetProtectionGroupType();
    
    /**
     * Gets the "protectionSchemeState" element
     */
    org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType getProtectionSchemeState();
    
    /**
     * Tests for nil "protectionSchemeState" element
     */
    boolean isNilProtectionSchemeState();
    
    /**
     * True if has "protectionSchemeState" element
     */
    boolean isSetProtectionSchemeState();
    
    /**
     * Sets the "protectionSchemeState" element
     */
    void setProtectionSchemeState(org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType protectionSchemeState);
    
    /**
     * Appends and returns a new empty "protectionSchemeState" element
     */
    org.tmforum.mtop.nrb.xsd.com.v1.ProtectionSchemeStateType addNewProtectionSchemeState();
    
    /**
     * Nils the "protectionSchemeState" element
     */
    void setNilProtectionSchemeState();
    
    /**
     * Unsets the "protectionSchemeState" element
     */
    void unsetProtectionSchemeState();
    
    /**
     * Gets the "reversionMode" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum getReversionMode();
    
    /**
     * Gets (as xml) the "reversionMode" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType xgetReversionMode();
    
    /**
     * Tests for nil "reversionMode" element
     */
    boolean isNilReversionMode();
    
    /**
     * True if has "reversionMode" element
     */
    boolean isSetReversionMode();
    
    /**
     * Sets the "reversionMode" element
     */
    void setReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType.Enum reversionMode);
    
    /**
     * Sets (as xml) the "reversionMode" element
     */
    void xsetReversionMode(org.tmforum.mtop.nra.xsd.com.v1.ReversionModeType reversionMode);
    
    /**
     * Nils the "reversionMode" element
     */
    void setNilReversionMode();
    
    /**
     * Unsets the "reversionMode" element
     */
    void unsetReversionMode();
    
    /**
     * Gets the "rate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType getRate();
    
    /**
     * Tests for nil "rate" element
     */
    boolean isNilRate();
    
    /**
     * True if has "rate" element
     */
    boolean isSetRate();
    
    /**
     * Sets the "rate" element
     */
    void setRate(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType rate);
    
    /**
     * Appends and returns a new empty "rate" element
     */
    org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateType addNewRate();
    
    /**
     * Nils the "rate" element
     */
    void setNilRate();
    
    /**
     * Unsets the "rate" element
     */
    void unsetRate();
    
    /**
     * Gets the "pgParameters" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType getPgParameters();
    
    /**
     * Tests for nil "pgParameters" element
     */
    boolean isNilPgParameters();
    
    /**
     * True if has "pgParameters" element
     */
    boolean isSetPgParameters();
    
    /**
     * Sets the "pgParameters" element
     */
    void setPgParameters(org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType pgParameters);
    
    /**
     * Appends and returns a new empty "pgParameters" element
     */
    org.tmforum.mtop.nra.xsd.pgp.v1.PgParametersType addNewPgParameters();
    
    /**
     * Nils the "pgParameters" element
     */
    void setNilPgParameters();
    
    /**
     * Unsets the "pgParameters" element
     */
    void unsetPgParameters();
    
    /**
     * Gets the "pgTpList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType getPgTpList();
    
    /**
     * Tests for nil "pgTpList" element
     */
    boolean isNilPgTpList();
    
    /**
     * True if has "pgTpList" element
     */
    boolean isSetPgTpList();
    
    /**
     * Sets the "pgTpList" element
     */
    void setPgTpList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType pgTpList);
    
    /**
     * Appends and returns a new empty "pgTpList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesListType addNewPgTpList();
    
    /**
     * Nils the "pgTpList" element
     */
    void setNilPgTpList();
    
    /**
     * Unsets the "pgTpList" element
     */
    void unsetPgTpList();
    
    /**
     * Gets the "G_774_3_APSfunction" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType getG7743APSfunction();
    
    /**
     * Tests for nil "G_774_3_APSfunction" element
     */
    boolean isNilG7743APSfunction();
    
    /**
     * True if has "G_774_3_APSfunction" element
     */
    boolean isSetG7743APSfunction();
    
    /**
     * Sets the "G_774_3_APSfunction" element
     */
    void setG7743APSfunction(org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType g7743APSfunction);
    
    /**
     * Appends and returns a new empty "G_774_3_APSfunction" element
     */
    org.tmforum.mtop.nra.xsd.com.v1.G7743APSfunctionType addNewG7743APSfunction();
    
    /**
     * Nils the "G_774_3_APSfunction" element
     */
    void setNilG7743APSfunction();
    
    /**
     * Unsets the "G_774_3_APSfunction" element
     */
    void unsetG7743APSfunction();
    
    /**
     * Gets the "asapRef" element
     */
    java.lang.String getAsapRef();
    
    /**
     * Gets (as xml) the "asapRef" element
     */
    org.apache.xmlbeans.XmlString xgetAsapRef();
    
    /**
     * Tests for nil "asapRef" element
     */
    boolean isNilAsapRef();
    
    /**
     * True if has "asapRef" element
     */
    boolean isSetAsapRef();
    
    /**
     * Sets the "asapRef" element
     */
    void setAsapRef(java.lang.String asapRef);
    
    /**
     * Sets (as xml) the "asapRef" element
     */
    void xsetAsapRef(org.apache.xmlbeans.XmlString asapRef);
    
    /**
     * Nils the "asapRef" element
     */
    void setNilAsapRef();
    
    /**
     * Unsets the "asapRef" element
     */
    void unsetAsapRef();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType newInstance() {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nra.xsd.pg.v1.ProtectionGroupType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
