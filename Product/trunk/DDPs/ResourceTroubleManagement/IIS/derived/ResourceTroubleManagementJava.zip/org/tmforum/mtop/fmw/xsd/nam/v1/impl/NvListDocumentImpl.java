/*
 * An XML document type.
 * Localname: nvList
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/nam/v1
 * Java type: org.tmforum.mtop.fmw.xsd.nam.v1.NvListDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.nam.v1.impl;
/**
 * A document containing one nvList(@http://www.tmforum.org/mtop/fmw/xsd/nam/v1) element.
 *
 * This is a complex type.
 */
public class NvListDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.nam.v1.NvListDocument
{
    
    public NvListDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NVLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "nvList");
    
    
    /**
     * Gets the "nvList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType getNvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType)get_store().find_element_user(NVLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "nvList" element
     */
    public void setNvList(org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType nvList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType)get_store().find_element_user(NVLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType)get_store().add_element_user(NVLIST$0);
            }
            target.set(nvList);
        }
    }
    
    /**
     * Appends and returns a new empty "nvList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType addNewNvList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NameAndAnyValueListType)get_store().add_element_user(NVLIST$0);
            return target;
        }
    }
}
