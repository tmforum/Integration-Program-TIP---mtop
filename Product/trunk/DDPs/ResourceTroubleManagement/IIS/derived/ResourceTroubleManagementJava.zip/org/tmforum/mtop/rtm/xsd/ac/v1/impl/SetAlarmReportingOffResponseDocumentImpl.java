/*
 * An XML document type.
 * Localname: setAlarmReportingOffResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setAlarmReportingOffResponse(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetAlarmReportingOffResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument
{
    
    public SetAlarmReportingOffResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETALARMREPORTINGOFFRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setAlarmReportingOffResponse");
    
    
    /**
     * Gets the "setAlarmReportingOffResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse getSetAlarmReportingOffResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse)get_store().find_element_user(SETALARMREPORTINGOFFRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setAlarmReportingOffResponse" element
     */
    public void setSetAlarmReportingOffResponse(org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse setAlarmReportingOffResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse)get_store().find_element_user(SETALARMREPORTINGOFFRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse)get_store().add_element_user(SETALARMREPORTINGOFFRESPONSE$0);
            }
            target.set(setAlarmReportingOffResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "setAlarmReportingOffResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse addNewSetAlarmReportingOffResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse)get_store().add_element_user(SETALARMREPORTINGOFFRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML setAlarmReportingOffResponse(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetAlarmReportingOffResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetAlarmReportingOffResponseDocument.SetAlarmReportingOffResponse
    {
        
        public SetAlarmReportingOffResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
