/*
 * An XML document type.
 * Localname: layerRateListType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/lay/v1
 * Java type: org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListTypeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.lay.v1.impl;
/**
 * A document containing one layerRateListType(@http://www.tmforum.org/mtop/nrb/xsd/lay/v1) element.
 *
 * This is a complex type.
 */
public class LayerRateListTypeDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListTypeDocument
{
    
    public LayerRateListTypeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName LAYERRATELISTTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/lay/v1", "layerRateListType");
    
    
    /**
     * Gets the "layerRateListType" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getLayerRateListType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATELISTTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "layerRateListType" element
     */
    public void setLayerRateListType(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType layerRateListType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATELISTTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATELISTTYPE$0);
            }
            target.set(layerRateListType);
        }
    }
    
    /**
     * Appends and returns a new empty "layerRateListType" element
     */
    public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewLayerRateListType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
            target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATELISTTYPE$0);
            return target;
        }
    }
}
