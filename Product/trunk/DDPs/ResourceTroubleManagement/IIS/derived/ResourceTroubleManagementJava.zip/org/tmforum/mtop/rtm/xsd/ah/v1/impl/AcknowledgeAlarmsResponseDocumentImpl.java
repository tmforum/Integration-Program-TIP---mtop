/*
 * An XML document type.
 * Localname: acknowledgeAlarmsResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ah/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ah.v1.impl;
/**
 * A document containing one acknowledgeAlarmsResponse(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1) element.
 *
 * This is a complex type.
 */
public class AcknowledgeAlarmsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument
{
    
    public AcknowledgeAlarmsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACKNOWLEDGEALARMSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "acknowledgeAlarmsResponse");
    
    
    /**
     * Gets the "acknowledgeAlarmsResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse getAcknowledgeAlarmsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse)get_store().find_element_user(ACKNOWLEDGEALARMSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "acknowledgeAlarmsResponse" element
     */
    public void setAcknowledgeAlarmsResponse(org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse acknowledgeAlarmsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse)get_store().find_element_user(ACKNOWLEDGEALARMSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse)get_store().add_element_user(ACKNOWLEDGEALARMSRESPONSE$0);
            }
            target.set(acknowledgeAlarmsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "acknowledgeAlarmsResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse addNewAcknowledgeAlarmsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse)get_store().add_element_user(ACKNOWLEDGEALARMSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML acknowledgeAlarmsResponse(@http://www.tmforum.org/mtop/rtm/xsd/ah/v1).
     *
     * This is a complex type.
     */
    public static class AcknowledgeAlarmsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ah.v1.AcknowledgeAlarmsResponseDocument.AcknowledgeAlarmsResponse
    {
        
        public AcknowledgeAlarmsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FAILEDACKNOWLEDGEIDLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ah/v1", "failedAcknowledgeIdList");
        
        
        /**
         * Gets the "failedAcknowledgeIdList" element
         */
        public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType getFailedAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(FAILEDACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "failedAcknowledgeIdList" element
         */
        public boolean isNilFailedAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(FAILEDACKNOWLEDGEIDLIST$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "failedAcknowledgeIdList" element
         */
        public boolean isSetFailedAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FAILEDACKNOWLEDGEIDLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "failedAcknowledgeIdList" element
         */
        public void setFailedAcknowledgeIdList(org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType failedAcknowledgeIdList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(FAILEDACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(FAILEDACKNOWLEDGEIDLIST$0);
                }
                target.set(failedAcknowledgeIdList);
            }
        }
        
        /**
         * Appends and returns a new empty "failedAcknowledgeIdList" element
         */
        public org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType addNewFailedAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(FAILEDACKNOWLEDGEIDLIST$0);
                return target;
            }
        }
        
        /**
         * Nils the "failedAcknowledgeIdList" element
         */
        public void setNilFailedAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType target = null;
                target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().find_element_user(FAILEDACKNOWLEDGEIDLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nra.xsd.atcaid.v1.AlarmOrTcaIdListType)get_store().add_element_user(FAILEDACKNOWLEDGEIDLIST$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "failedAcknowledgeIdList" element
         */
        public void unsetFailedAcknowledgeIdList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FAILEDACKNOWLEDGEIDLIST$0, 0);
            }
        }
    }
}
