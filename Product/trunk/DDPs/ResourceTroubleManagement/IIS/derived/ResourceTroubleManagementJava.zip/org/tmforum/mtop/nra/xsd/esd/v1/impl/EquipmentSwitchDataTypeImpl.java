/*
 * XML Type:  EquipmentSwitchDataType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/esd/v1
 * Java type: org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.esd.v1.impl;
/**
 * An XML EquipmentSwitchDataType(@http://www.tmforum.org/mtop/nra/xsd/esd/v1).
 *
 * This is a complex type.
 */
public class EquipmentSwitchDataTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.esd.v1.EquipmentSwitchDataType
{
    
    public EquipmentSwitchDataTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EQUIPMENTPROTECTIONGROUPTYPE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/esd/v1", "equipmentProtectionGroupType");
    private static final javax.xml.namespace.QName EQUIPMENTSWITCHREASON$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/esd/v1", "equipmentSwitchReason");
    private static final javax.xml.namespace.QName EPGNAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/esd/v1", "epgName");
    private static final javax.xml.namespace.QName PROTECTEDEQUIPMENT$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/esd/v1", "protectedEquipment");
    private static final javax.xml.namespace.QName SWITCHTOEQUIPMENT$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/esd/v1", "switchToEquipment");
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/esd/v1", "vendorExtensions");
    
    
    /**
     * Gets the "equipmentProtectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType getEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "equipmentProtectionGroupType" element
     */
    public boolean isNilEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "equipmentProtectionGroupType" element
     */
    public boolean isSetEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQUIPMENTPROTECTIONGROUPTYPE$0) != 0;
        }
    }
    
    /**
     * Sets the "equipmentProtectionGroupType" element
     */
    public void setEquipmentProtectionGroupType(org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType equipmentProtectionGroupType)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0);
            }
            target.set(equipmentProtectionGroupType);
        }
    }
    
    /**
     * Appends and returns a new empty "equipmentProtectionGroupType" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType addNewEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0);
            return target;
        }
    }
    
    /**
     * Nils the "equipmentProtectionGroupType" element
     */
    public void setNilEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().find_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentProtectionGroupTypeType)get_store().add_element_user(EQUIPMENTPROTECTIONGROUPTYPE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "equipmentProtectionGroupType" element
     */
    public void unsetEquipmentProtectionGroupType()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQUIPMENTPROTECTIONGROUPTYPE$0, 0);
        }
    }
    
    /**
     * Gets the "equipmentSwitchReason" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType getEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().find_element_user(EQUIPMENTSWITCHREASON$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "equipmentSwitchReason" element
     */
    public boolean isNilEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().find_element_user(EQUIPMENTSWITCHREASON$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "equipmentSwitchReason" element
     */
    public boolean isSetEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EQUIPMENTSWITCHREASON$2) != 0;
        }
    }
    
    /**
     * Sets the "equipmentSwitchReason" element
     */
    public void setEquipmentSwitchReason(org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType equipmentSwitchReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().find_element_user(EQUIPMENTSWITCHREASON$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().add_element_user(EQUIPMENTSWITCHREASON$2);
            }
            target.set(equipmentSwitchReason);
        }
    }
    
    /**
     * Appends and returns a new empty "equipmentSwitchReason" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType addNewEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().add_element_user(EQUIPMENTSWITCHREASON$2);
            return target;
        }
    }
    
    /**
     * Nils the "equipmentSwitchReason" element
     */
    public void setNilEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().find_element_user(EQUIPMENTSWITCHREASON$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.EquipmentSwitchReasonType)get_store().add_element_user(EQUIPMENTSWITCHREASON$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "equipmentSwitchReason" element
     */
    public void unsetEquipmentSwitchReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EQUIPMENTSWITCHREASON$2, 0);
        }
    }
    
    /**
     * Gets the "epgName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getEpgName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EPGNAME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "epgName" element
     */
    public boolean isNilEpgName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EPGNAME$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "epgName" element
     */
    public boolean isSetEpgName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EPGNAME$4) != 0;
        }
    }
    
    /**
     * Sets the "epgName" element
     */
    public void setEpgName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType epgName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EPGNAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EPGNAME$4);
            }
            target.set(epgName);
        }
    }
    
    /**
     * Appends and returns a new empty "epgName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewEpgName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EPGNAME$4);
            return target;
        }
    }
    
    /**
     * Nils the "epgName" element
     */
    public void setNilEpgName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(EPGNAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(EPGNAME$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "epgName" element
     */
    public void unsetEpgName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EPGNAME$4, 0);
        }
    }
    
    /**
     * Gets the "protectedEquipment" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getProtectedEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROTECTEDEQUIPMENT$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "protectedEquipment" element
     */
    public boolean isNilProtectedEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROTECTEDEQUIPMENT$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "protectedEquipment" element
     */
    public boolean isSetProtectedEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROTECTEDEQUIPMENT$6) != 0;
        }
    }
    
    /**
     * Sets the "protectedEquipment" element
     */
    public void setProtectedEquipment(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType protectedEquipment)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROTECTEDEQUIPMENT$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PROTECTEDEQUIPMENT$6);
            }
            target.set(protectedEquipment);
        }
    }
    
    /**
     * Appends and returns a new empty "protectedEquipment" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewProtectedEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PROTECTEDEQUIPMENT$6);
            return target;
        }
    }
    
    /**
     * Nils the "protectedEquipment" element
     */
    public void setNilProtectedEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(PROTECTEDEQUIPMENT$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(PROTECTEDEQUIPMENT$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "protectedEquipment" element
     */
    public void unsetProtectedEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROTECTEDEQUIPMENT$6, 0);
        }
    }
    
    /**
     * Gets the "switchToEquipment" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getSwitchToEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SWITCHTOEQUIPMENT$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "switchToEquipment" element
     */
    public boolean isNilSwitchToEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SWITCHTOEQUIPMENT$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "switchToEquipment" element
     */
    public boolean isSetSwitchToEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHTOEQUIPMENT$8) != 0;
        }
    }
    
    /**
     * Sets the "switchToEquipment" element
     */
    public void setSwitchToEquipment(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType switchToEquipment)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SWITCHTOEQUIPMENT$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SWITCHTOEQUIPMENT$8);
            }
            target.set(switchToEquipment);
        }
    }
    
    /**
     * Appends and returns a new empty "switchToEquipment" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewSwitchToEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SWITCHTOEQUIPMENT$8);
            return target;
        }
    }
    
    /**
     * Nils the "switchToEquipment" element
     */
    public void setNilSwitchToEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(SWITCHTOEQUIPMENT$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(SWITCHTOEQUIPMENT$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "switchToEquipment" element
     */
    public void unsetSwitchToEquipment()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHTOEQUIPMENT$8, 0);
        }
    }
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "vendorExtensions" element
     */
    public boolean isNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$10) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$10);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$10);
            return target;
        }
    }
    
    /**
     * Nils the "vendorExtensions" element
     */
    public void setNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$10);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$10, 0);
        }
    }
}
