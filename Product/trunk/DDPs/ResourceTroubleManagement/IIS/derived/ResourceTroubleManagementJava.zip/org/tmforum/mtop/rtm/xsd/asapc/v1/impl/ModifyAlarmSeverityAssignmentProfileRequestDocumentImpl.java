/*
 * An XML document type.
 * Localname: modifyAlarmSeverityAssignmentProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one modifyAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class ModifyAlarmSeverityAssignmentProfileRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument
{
    
    public ModifyAlarmSeverityAssignmentProfileRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MODIFYALARMSEVERITYASSIGNMENTPROFILEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "modifyAlarmSeverityAssignmentProfileRequest");
    
    
    /**
     * Gets the "modifyAlarmSeverityAssignmentProfileRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest getModifyAlarmSeverityAssignmentProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest)get_store().find_element_user(MODIFYALARMSEVERITYASSIGNMENTPROFILEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "modifyAlarmSeverityAssignmentProfileRequest" element
     */
    public void setModifyAlarmSeverityAssignmentProfileRequest(org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest modifyAlarmSeverityAssignmentProfileRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest)get_store().find_element_user(MODIFYALARMSEVERITYASSIGNMENTPROFILEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest)get_store().add_element_user(MODIFYALARMSEVERITYASSIGNMENTPROFILEREQUEST$0);
            }
            target.set(modifyAlarmSeverityAssignmentProfileRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "modifyAlarmSeverityAssignmentProfileRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest addNewModifyAlarmSeverityAssignmentProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest)get_store().add_element_user(MODIFYALARMSEVERITYASSIGNMENTPROFILEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML modifyAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class ModifyAlarmSeverityAssignmentProfileRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.ModifyAlarmSeverityAssignmentProfileRequestDocument.ModifyAlarmSeverityAssignmentProfileRequest
    {
        
        public ModifyAlarmSeverityAssignmentProfileRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "asapName");
        private static final javax.xml.namespace.QName ASAPMODIFYDATA$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "asapModifyData");
        
        
        /**
         * Gets the "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "asapName" element
         */
        public boolean isNilAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "asapName" element
         */
        public boolean isSetAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPNAME$0) != 0;
            }
        }
        
        /**
         * Sets the "asapName" element
         */
        public void setAsapName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType asapName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(ASAPNAME$0);
                }
                target.set(asapName);
            }
        }
        
        /**
         * Appends and returns a new empty "asapName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(ASAPNAME$0);
                return target;
            }
        }
        
        /**
         * Nils the "asapName" element
         */
        public void setNilAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(ASAPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(ASAPNAME$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "asapName" element
         */
        public void unsetAsapName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPNAME$0, 0);
            }
        }
        
        /**
         * Gets the "asapModifyData" element
         */
        public org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType getAsapModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType)get_store().find_element_user(ASAPMODIFYDATA$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "asapModifyData" element
         */
        public boolean isNilAsapModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType)get_store().find_element_user(ASAPMODIFYDATA$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "asapModifyData" element
         */
        public boolean isSetAsapModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPMODIFYDATA$2) != 0;
            }
        }
        
        /**
         * Sets the "asapModifyData" element
         */
        public void setAsapModifyData(org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType asapModifyData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType)get_store().find_element_user(ASAPMODIFYDATA$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType)get_store().add_element_user(ASAPMODIFYDATA$2);
                }
                target.set(asapModifyData);
            }
        }
        
        /**
         * Appends and returns a new empty "asapModifyData" element
         */
        public org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType addNewAsapModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType)get_store().add_element_user(ASAPMODIFYDATA$2);
                return target;
            }
        }
        
        /**
         * Nils the "asapModifyData" element
         */
        public void setNilAsapModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType)get_store().find_element_user(ASAPMODIFYDATA$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileModifyDataType)get_store().add_element_user(ASAPMODIFYDATA$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "asapModifyData" element
         */
        public void unsetAsapModifyData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPMODIFYDATA$2, 0);
            }
        }
    }
}
