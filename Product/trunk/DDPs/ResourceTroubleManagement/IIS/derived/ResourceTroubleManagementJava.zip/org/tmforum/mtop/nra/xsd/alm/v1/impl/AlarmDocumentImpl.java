/*
 * An XML document type.
 * Localname: alarm
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/alm/v1
 * Java type: org.tmforum.mtop.nra.xsd.alm.v1.AlarmDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.alm.v1.impl;
/**
 * A document containing one alarm(@http://www.tmforum.org/mtop/nra/xsd/alm/v1) element.
 *
 * This is a complex type.
 */
public class AlarmDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoDocumentImpl implements org.tmforum.mtop.nra.xsd.alm.v1.AlarmDocument
{
    
    public AlarmDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ALARM$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/alm/v1", "alarm");
    
    
    /**
     * Gets the "alarm" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType getAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType)get_store().find_element_user(ALARM$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "alarm" element
     */
    public void setAlarm(org.tmforum.mtop.nra.xsd.alm.v1.AlarmType alarm)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType)get_store().find_element_user(ALARM$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType)get_store().add_element_user(ALARM$0);
            }
            target.set(alarm);
        }
    }
    
    /**
     * Appends and returns a new empty "alarm" element
     */
    public org.tmforum.mtop.nra.xsd.alm.v1.AlarmType addNewAlarm()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.alm.v1.AlarmType target = null;
            target = (org.tmforum.mtop.nra.xsd.alm.v1.AlarmType)get_store().add_element_user(ALARM$0);
            return target;
        }
    }
}
