/*
 * An XML document type.
 * Localname: deleteAlarmSeverityAssignmentProfileException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one deleteAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class DeleteAlarmSeverityAssignmentProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument
{
    
    public DeleteAlarmSeverityAssignmentProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "deleteAlarmSeverityAssignmentProfileException");
    
    
    /**
     * Gets the "deleteAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException getDeleteAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException)get_store().find_element_user(DELETEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteAlarmSeverityAssignmentProfileException" element
     */
    public void setDeleteAlarmSeverityAssignmentProfileException(org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException deleteAlarmSeverityAssignmentProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException)get_store().find_element_user(DELETEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException)get_store().add_element_user(DELETEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            }
            target.set(deleteAlarmSeverityAssignmentProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException addNewDeleteAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException)get_store().add_element_user(DELETEALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML deleteAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class DeleteAlarmSeverityAssignmentProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileExceptionDocument.DeleteAlarmSeverityAssignmentProfileException
    {
        
        public DeleteAlarmSeverityAssignmentProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
