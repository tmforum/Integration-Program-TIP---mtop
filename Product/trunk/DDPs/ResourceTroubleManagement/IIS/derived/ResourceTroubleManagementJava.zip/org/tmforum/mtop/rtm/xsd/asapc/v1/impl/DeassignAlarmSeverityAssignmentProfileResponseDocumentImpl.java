/*
 * An XML document type.
 * Localname: deassignAlarmSeverityAssignmentProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one deassignAlarmSeverityAssignmentProfileResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class DeassignAlarmSeverityAssignmentProfileResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument
{
    
    public DeassignAlarmSeverityAssignmentProfileResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DEASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "deassignAlarmSeverityAssignmentProfileResponse");
    
    
    /**
     * Gets the "deassignAlarmSeverityAssignmentProfileResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse getDeassignAlarmSeverityAssignmentProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse)get_store().find_element_user(DEASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deassignAlarmSeverityAssignmentProfileResponse" element
     */
    public void setDeassignAlarmSeverityAssignmentProfileResponse(org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse deassignAlarmSeverityAssignmentProfileResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse)get_store().find_element_user(DEASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse)get_store().add_element_user(DEASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0);
            }
            target.set(deassignAlarmSeverityAssignmentProfileResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "deassignAlarmSeverityAssignmentProfileResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse addNewDeassignAlarmSeverityAssignmentProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse)get_store().add_element_user(DEASSIGNALARMSEVERITYASSIGNMENTPROFILERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML deassignAlarmSeverityAssignmentProfileResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class DeassignAlarmSeverityAssignmentProfileResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeassignAlarmSeverityAssignmentProfileResponseDocument.DeassignAlarmSeverityAssignmentProfileResponse
    {
        
        public DeassignAlarmSeverityAssignmentProfileResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "vendorExtensions");
        
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        public boolean isNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$0) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                return target;
            }
        }
        
        /**
         * Nils the "vendorExtensions" element
         */
        public void setNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$0, 0);
            }
        }
    }
}
