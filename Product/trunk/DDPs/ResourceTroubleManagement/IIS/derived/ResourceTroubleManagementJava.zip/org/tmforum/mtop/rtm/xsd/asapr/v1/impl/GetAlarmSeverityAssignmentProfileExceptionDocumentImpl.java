/*
 * An XML document type.
 * Localname: getAlarmSeverityAssignmentProfileException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAlarmSeverityAssignmentProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument
{
    
    public GetAlarmSeverityAssignmentProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAlarmSeverityAssignmentProfileException");
    
    
    /**
     * Gets the "getAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException getGetAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAlarmSeverityAssignmentProfileException" element
     */
    public void setGetAlarmSeverityAssignmentProfileException(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException getAlarmSeverityAssignmentProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            }
            target.set(getAlarmSeverityAssignmentProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException addNewGetAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAlarmSeverityAssignmentProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileExceptionDocument.GetAlarmSeverityAssignmentProfileException
    {
        
        public GetAlarmSeverityAssignmentProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
