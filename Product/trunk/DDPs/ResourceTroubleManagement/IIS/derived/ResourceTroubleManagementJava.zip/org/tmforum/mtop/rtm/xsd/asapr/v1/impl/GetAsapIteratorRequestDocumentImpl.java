/*
 * An XML document type.
 * Localname: getAsapIteratorRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAsapIteratorRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAsapIteratorRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument
{
    
    public GetAsapIteratorRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASAPITERATORREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAsapIteratorRequest");
    
    
    /**
     * Gets the "getAsapIteratorRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest getGetAsapIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest)get_store().find_element_user(GETASAPITERATORREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAsapIteratorRequest" element
     */
    public void setGetAsapIteratorRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest getAsapIteratorRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest)get_store().find_element_user(GETASAPITERATORREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest)get_store().add_element_user(GETASAPITERATORREQUEST$0);
            }
            target.set(getAsapIteratorRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAsapIteratorRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest addNewGetAsapIteratorRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest)get_store().add_element_user(GETASAPITERATORREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAsapIteratorRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAsapIteratorRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapIteratorRequestDocument.GetAsapIteratorRequest
    {
        
        public GetAsapIteratorRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
