/*
 * An XML document type.
 * Localname: setGtpAlarmReportingOffException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ac/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ac.v1.impl;
/**
 * A document containing one setGtpAlarmReportingOffException(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1) element.
 *
 * This is a complex type.
 */
public class SetGtpAlarmReportingOffExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument
{
    
    public SetGtpAlarmReportingOffExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SETGTPALARMREPORTINGOFFEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ac/v1", "setGtpAlarmReportingOffException");
    
    
    /**
     * Gets the "setGtpAlarmReportingOffException" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException getSetGtpAlarmReportingOffException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException)get_store().find_element_user(SETGTPALARMREPORTINGOFFEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "setGtpAlarmReportingOffException" element
     */
    public void setSetGtpAlarmReportingOffException(org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException setGtpAlarmReportingOffException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException)get_store().find_element_user(SETGTPALARMREPORTINGOFFEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException)get_store().add_element_user(SETGTPALARMREPORTINGOFFEXCEPTION$0);
            }
            target.set(setGtpAlarmReportingOffException);
        }
    }
    
    /**
     * Appends and returns a new empty "setGtpAlarmReportingOffException" element
     */
    public org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException addNewSetGtpAlarmReportingOffException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException target = null;
            target = (org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException)get_store().add_element_user(SETGTPALARMREPORTINGOFFEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML setGtpAlarmReportingOffException(@http://www.tmforum.org/mtop/rtm/xsd/ac/v1).
     *
     * This is a complex type.
     */
    public static class SetGtpAlarmReportingOffExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.ac.v1.SetGtpAlarmReportingOffExceptionDocument.SetGtpAlarmReportingOffException
    {
        
        public SetGtpAlarmReportingOffExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
