/*
 * An XML document type.
 * Localname: createAlarmSeverityAssignmentProfileRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one createAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAlarmSeverityAssignmentProfileRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument
{
    
    public CreateAlarmSeverityAssignmentProfileRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEALARMSEVERITYASSIGNMENTPROFILEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "createAlarmSeverityAssignmentProfileRequest");
    
    
    /**
     * Gets the "createAlarmSeverityAssignmentProfileRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest getCreateAlarmSeverityAssignmentProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest)get_store().find_element_user(CREATEALARMSEVERITYASSIGNMENTPROFILEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAlarmSeverityAssignmentProfileRequest" element
     */
    public void setCreateAlarmSeverityAssignmentProfileRequest(org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest createAlarmSeverityAssignmentProfileRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest)get_store().find_element_user(CREATEALARMSEVERITYASSIGNMENTPROFILEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest)get_store().add_element_user(CREATEALARMSEVERITYASSIGNMENTPROFILEREQUEST$0);
            }
            target.set(createAlarmSeverityAssignmentProfileRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "createAlarmSeverityAssignmentProfileRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest addNewCreateAlarmSeverityAssignmentProfileRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest)get_store().add_element_user(CREATEALARMSEVERITYASSIGNMENTPROFILEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML createAlarmSeverityAssignmentProfileRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAlarmSeverityAssignmentProfileRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAlarmSeverityAssignmentProfileRequestDocument.CreateAlarmSeverityAssignmentProfileRequest
    {
        
        public CreateAlarmSeverityAssignmentProfileRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPCREATEDATA$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "asapCreateData");
        
        
        /**
         * Gets the "asapCreateData" element
         */
        public org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType getAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType)get_store().find_element_user(ASAPCREATEDATA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "asapCreateData" element
         */
        public boolean isNilAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType)get_store().find_element_user(ASAPCREATEDATA$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "asapCreateData" element
         */
        public boolean isSetAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPCREATEDATA$0) != 0;
            }
        }
        
        /**
         * Sets the "asapCreateData" element
         */
        public void setAsapCreateData(org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType asapCreateData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType)get_store().find_element_user(ASAPCREATEDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType)get_store().add_element_user(ASAPCREATEDATA$0);
                }
                target.set(asapCreateData);
            }
        }
        
        /**
         * Appends and returns a new empty "asapCreateData" element
         */
        public org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType addNewAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType)get_store().add_element_user(ASAPCREATEDATA$0);
                return target;
            }
        }
        
        /**
         * Nils the "asapCreateData" element
         */
        public void setNilAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType)get_store().find_element_user(ASAPCREATEDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AlarmSeverityAssignmentProfileCreateDataType)get_store().add_element_user(ASAPCREATEDATA$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "asapCreateData" element
         */
        public void unsetAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPCREATEDATA$0, 0);
            }
        }
    }
}
