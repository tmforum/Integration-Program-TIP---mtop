/*
 * XML Type:  ActiveAlarmFilterType
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1.impl;
/**
 * An XML ActiveAlarmFilterType(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1).
 *
 * This is a complex type.
 */
public class ActiveAlarmFilterTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.ActiveAlarmFilterType
{
    
    public ActiveAlarmFilterTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SOURCE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "source");
    private static final javax.xml.namespace.QName SCOPE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "scope");
    private static final javax.xml.namespace.QName PERCEIVEDSEVERITYLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "perceivedSeverityList");
    private static final javax.xml.namespace.QName PROBABLECAUSELIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "probableCauseList");
    private static final javax.xml.namespace.QName ACKNOWLEDGEINDICATION$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "acknowledgeIndication");
    
    
    /**
     * Gets the "source" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType.Enum getSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "source" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType xgetSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType)get_store().find_element_user(SOURCE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "source" element
     */
    public boolean isSetSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SOURCE$0) != 0;
        }
    }
    
    /**
     * Sets the "source" element
     */
    public void setSource(org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType.Enum source)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SOURCE$0);
            }
            target.setEnumValue(source);
        }
    }
    
    /**
     * Sets (as xml) the "source" element
     */
    public void xsetSource(org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType source)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ar.v1.AlarmSourceType)get_store().add_element_user(SOURCE$0);
            }
            target.set(source);
        }
    }
    
    /**
     * Unsets the "source" element
     */
    public void unsetSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SOURCE$0, 0);
        }
    }
    
    /**
     * Gets the "scope" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getScope()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SCOPE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "scope" element
     */
    public boolean isSetScope()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SCOPE$2) != 0;
        }
    }
    
    /**
     * Sets the "scope" element
     */
    public void setScope(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType scope)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(SCOPE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SCOPE$2);
            }
            target.set(scope);
        }
    }
    
    /**
     * Appends and returns a new empty "scope" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewScope()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(SCOPE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "scope" element
     */
    public void unsetScope()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SCOPE$2, 0);
        }
    }
    
    /**
     * Gets the "perceivedSeverityList" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType getPerceivedSeverityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType)get_store().find_element_user(PERCEIVEDSEVERITYLIST$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "perceivedSeverityList" element
     */
    public boolean isSetPerceivedSeverityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PERCEIVEDSEVERITYLIST$4) != 0;
        }
    }
    
    /**
     * Sets the "perceivedSeverityList" element
     */
    public void setPerceivedSeverityList(org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType perceivedSeverityList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType)get_store().find_element_user(PERCEIVEDSEVERITYLIST$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType)get_store().add_element_user(PERCEIVEDSEVERITYLIST$4);
            }
            target.set(perceivedSeverityList);
        }
    }
    
    /**
     * Appends and returns a new empty "perceivedSeverityList" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType addNewPerceivedSeverityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.PerceivedSeverityListType)get_store().add_element_user(PERCEIVEDSEVERITYLIST$4);
            return target;
        }
    }
    
    /**
     * Unsets the "perceivedSeverityList" element
     */
    public void unsetPerceivedSeverityList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PERCEIVEDSEVERITYLIST$4, 0);
        }
    }
    
    /**
     * Gets the "probableCauseList" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType getProbableCauseList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType)get_store().find_element_user(PROBABLECAUSELIST$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "probableCauseList" element
     */
    public boolean isSetProbableCauseList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROBABLECAUSELIST$6) != 0;
        }
    }
    
    /**
     * Sets the "probableCauseList" element
     */
    public void setProbableCauseList(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType probableCauseList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType)get_store().find_element_user(PROBABLECAUSELIST$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType)get_store().add_element_user(PROBABLECAUSELIST$6);
            }
            target.set(probableCauseList);
        }
    }
    
    /**
     * Appends and returns a new empty "probableCauseList" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType addNewProbableCauseList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseListType)get_store().add_element_user(PROBABLECAUSELIST$6);
            return target;
        }
    }
    
    /**
     * Unsets the "probableCauseList" element
     */
    public void unsetProbableCauseList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROBABLECAUSELIST$6, 0);
        }
    }
    
    /**
     * Gets the "acknowledgeIndication" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum getAcknowledgeIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACKNOWLEDGEINDICATION$8, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "acknowledgeIndication" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType xgetAcknowledgeIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().find_element_user(ACKNOWLEDGEINDICATION$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "acknowledgeIndication" element
     */
    public boolean isSetAcknowledgeIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ACKNOWLEDGEINDICATION$8) != 0;
        }
    }
    
    /**
     * Sets the "acknowledgeIndication" element
     */
    public void setAcknowledgeIndication(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType.Enum acknowledgeIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACKNOWLEDGEINDICATION$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACKNOWLEDGEINDICATION$8);
            }
            target.setEnumValue(acknowledgeIndication);
        }
    }
    
    /**
     * Sets (as xml) the "acknowledgeIndication" element
     */
    public void xsetAcknowledgeIndication(org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType acknowledgeIndication)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().find_element_user(ACKNOWLEDGEINDICATION$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AcknowledgeIndicationType)get_store().add_element_user(ACKNOWLEDGEINDICATION$8);
            }
            target.set(acknowledgeIndication);
        }
    }
    
    /**
     * Unsets the "acknowledgeIndication" element
     */
    public void unsetAcknowledgeIndication()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ACKNOWLEDGEINDICATION$8, 0);
        }
    }
}
