/*
 * XML Type:  CommonResourceInfoType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/cri/v1
 * Java type: org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.cri.v1.impl;
/**
 * An XML CommonResourceInfoType(@http://www.tmforum.org/mtop/nrb/xsd/cri/v1).
 *
 * This is a complex type.
 */
public class CommonResourceInfoTypeImpl extends org.tmforum.mtop.fmw.xsd.coi.v1.impl.CommonObjectInfoTypeImpl implements org.tmforum.mtop.nrb.xsd.cri.v1.CommonResourceInfoType
{
    
    public CommonResourceInfoTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SOURCE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/cri/v1", "source");
    private static final javax.xml.namespace.QName NETWORKACCESSDOMAIN$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/cri/v1", "networkAccessDomain");
    private static final javax.xml.namespace.QName MEIATTRIBUTES$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/cri/v1", "meiAttributes");
    private static final javax.xml.namespace.QName RESOURCESTATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nrb/xsd/cri/v1", "resourceState");
    
    
    /**
     * Gets the "source" element
     */
    public org.tmforum.mtop.nrb.xsd.cri.v1.SourceType getSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.SourceType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.SourceType)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "source" element
     */
    public boolean isNilSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.SourceType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.SourceType)get_store().find_element_user(SOURCE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "source" element
     */
    public boolean isSetSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SOURCE$0) != 0;
        }
    }
    
    /**
     * Sets the "source" element
     */
    public void setSource(org.tmforum.mtop.nrb.xsd.cri.v1.SourceType source)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.SourceType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.SourceType)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.cri.v1.SourceType)get_store().add_element_user(SOURCE$0);
            }
            target.set(source);
        }
    }
    
    /**
     * Appends and returns a new empty "source" element
     */
    public org.tmforum.mtop.nrb.xsd.cri.v1.SourceType addNewSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.SourceType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.SourceType)get_store().add_element_user(SOURCE$0);
            return target;
        }
    }
    
    /**
     * Nils the "source" element
     */
    public void setNilSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.SourceType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.SourceType)get_store().find_element_user(SOURCE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.cri.v1.SourceType)get_store().add_element_user(SOURCE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "source" element
     */
    public void unsetSource()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SOURCE$0, 0);
        }
    }
    
    /**
     * Gets the "networkAccessDomain" element
     */
    public java.lang.String getNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "networkAccessDomain" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType xgetNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "networkAccessDomain" element
     */
    public boolean isNilNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "networkAccessDomain" element
     */
    public boolean isSetNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NETWORKACCESSDOMAIN$2) != 0;
        }
    }
    
    /**
     * Sets the "networkAccessDomain" element
     */
    public void setNetworkAccessDomain(java.lang.String networkAccessDomain)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NETWORKACCESSDOMAIN$2);
            }
            target.setStringValue(networkAccessDomain);
        }
    }
    
    /**
     * Sets (as xml) the "networkAccessDomain" element
     */
    public void xsetNetworkAccessDomain(org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType networkAccessDomain)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().add_element_user(NETWORKACCESSDOMAIN$2);
            }
            target.set(networkAccessDomain);
        }
    }
    
    /**
     * Nils the "networkAccessDomain" element
     */
    public void setNilNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().find_element_user(NETWORKACCESSDOMAIN$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NetworkAccessDomainType)get_store().add_element_user(NETWORKACCESSDOMAIN$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "networkAccessDomain" element
     */
    public void unsetNetworkAccessDomain()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NETWORKACCESSDOMAIN$2, 0);
        }
    }
    
    /**
     * Gets the "meiAttributes" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType getMeiAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType)get_store().find_element_user(MEIATTRIBUTES$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "meiAttributes" element
     */
    public boolean isNilMeiAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType)get_store().find_element_user(MEIATTRIBUTES$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "meiAttributes" element
     */
    public boolean isSetMeiAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MEIATTRIBUTES$4) != 0;
        }
    }
    
    /**
     * Sets the "meiAttributes" element
     */
    public void setMeiAttributes(org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType meiAttributes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType)get_store().find_element_user(MEIATTRIBUTES$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType)get_store().add_element_user(MEIATTRIBUTES$4);
            }
            target.set(meiAttributes);
        }
    }
    
    /**
     * Appends and returns a new empty "meiAttributes" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType addNewMeiAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType)get_store().add_element_user(MEIATTRIBUTES$4);
            return target;
        }
    }
    
    /**
     * Nils the "meiAttributes" element
     */
    public void setNilMeiAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType)get_store().find_element_user(MEIATTRIBUTES$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.MultiEventInventoryAttributesType)get_store().add_element_user(MEIATTRIBUTES$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "meiAttributes" element
     */
    public void unsetMeiAttributes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MEIATTRIBUTES$4, 0);
        }
    }
    
    /**
     * Gets the "resourceState" element
     */
    public org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType getResourceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType)get_store().find_element_user(RESOURCESTATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "resourceState" element
     */
    public boolean isNilResourceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType)get_store().find_element_user(RESOURCESTATE$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "resourceState" element
     */
    public boolean isSetResourceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RESOURCESTATE$6) != 0;
        }
    }
    
    /**
     * Sets the "resourceState" element
     */
    public void setResourceState(org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType resourceState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType)get_store().find_element_user(RESOURCESTATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType)get_store().add_element_user(RESOURCESTATE$6);
            }
            target.set(resourceState);
        }
    }
    
    /**
     * Appends and returns a new empty "resourceState" element
     */
    public org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType addNewResourceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType)get_store().add_element_user(RESOURCESTATE$6);
            return target;
        }
    }
    
    /**
     * Nils the "resourceState" element
     */
    public void setNilResourceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType target = null;
            target = (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType)get_store().find_element_user(RESOURCESTATE$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrb.xsd.cri.v1.ResourceStateType)get_store().add_element_user(RESOURCESTATE$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "resourceState" element
     */
    public void unsetResourceState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RESOURCESTATE$6, 0);
        }
    }
}
