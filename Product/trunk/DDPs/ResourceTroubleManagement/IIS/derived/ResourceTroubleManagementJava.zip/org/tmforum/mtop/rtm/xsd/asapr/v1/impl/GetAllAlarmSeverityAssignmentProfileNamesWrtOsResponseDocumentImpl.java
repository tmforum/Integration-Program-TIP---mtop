/*
 * An XML document type.
 * Localname: getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument
{
    
    public GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse");
    
    
    /**
     * Gets the "getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse getGetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse" element
     */
    public void setGetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse)get_store().find_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSRESPONSE$0);
            }
            target.set(getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse addNewGetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse)get_store().add_element_user(GETALLALARMSEVERITYASSIGNMENTPROFILENAMESWRTOSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAllAlarmSeverityAssignmentProfileNamesWrtOsResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseDocument.GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponse
    {
        
        public GetAllAlarmSeverityAssignmentProfileNamesWrtOsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPNAMELIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "asapNameList");
        
        
        /**
         * Gets the "asapNameList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType getAsapNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ASAPNAMELIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "asapNameList" element
         */
        public boolean isSetAsapNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPNAMELIST$0) != 0;
            }
        }
        
        /**
         * Sets the "asapNameList" element
         */
        public void setAsapNameList(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType asapNameList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().find_element_user(ASAPNAMELIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ASAPNAMELIST$0);
                }
                target.set(asapNameList);
            }
        }
        
        /**
         * Appends and returns a new empty "asapNameList" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType addNewAsapNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeListType)get_store().add_element_user(ASAPNAMELIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "asapNameList" element
         */
        public void unsetAsapNameList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPNAMELIST$0, 0);
            }
        }
    }
}
