/*
 * XML Type:  PmLocationListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/pm/v1
 * Java type: org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.pm.v1.impl;
/**
 * An XML PmLocationListType(@http://www.tmforum.org/mtop/nra/xsd/pm/v1).
 *
 * This is a complex type.
 */
public class PmLocationListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.pm.v1.PmLocationListType
{
    
    public PmLocationListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PMLOCATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/pm/v1", "pmLocation");
    
    
    /**
     * Gets a List of "pmLocation" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum> getPmLocationList()
    {
        final class PmLocationList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum get(int i)
                { return PmLocationListTypeImpl.this.getPmLocationArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum old = PmLocationListTypeImpl.this.getPmLocationArray(i);
                PmLocationListTypeImpl.this.setPmLocationArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum o)
                { PmLocationListTypeImpl.this.insertPmLocation(i, o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum old = PmLocationListTypeImpl.this.getPmLocationArray(i);
                PmLocationListTypeImpl.this.removePmLocation(i);
                return old;
            }
            
            public int size()
                { return PmLocationListTypeImpl.this.sizeOfPmLocationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmLocationList();
        }
    }
    
    /**
     * Gets array of all "pmLocation" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] getPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMLOCATION$0, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getEnumValue();
            return result;
        }
    }
    
    /**
     * Gets ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum getPmLocationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "pmLocation" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType> xgetPmLocationList()
    {
        final class PmLocationList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType>
        {
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType get(int i)
                { return PmLocationListTypeImpl.this.xgetPmLocationArray(i); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType set(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType o)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType old = PmLocationListTypeImpl.this.xgetPmLocationArray(i);
                PmLocationListTypeImpl.this.xsetPmLocationArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType o)
                { PmLocationListTypeImpl.this.insertNewPmLocation(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType old = PmLocationListTypeImpl.this.xgetPmLocationArray(i);
                PmLocationListTypeImpl.this.removePmLocation(i);
                return old;
            }
            
            public int size()
                { return PmLocationListTypeImpl.this.sizeOfPmLocationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new PmLocationList();
        }
    }
    
    /**
     * Gets (as xml) array of all "pmLocation" elements
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[] xgetPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PMLOCATION$0, targetList);
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[] result = new org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType xgetPmLocationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)target;
        }
    }
    
    /**
     * Returns number of "pmLocation" element
     */
    public int sizeOfPmLocationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PMLOCATION$0);
        }
    }
    
    /**
     * Sets array of all "pmLocation" element
     */
    public void setPmLocationArray(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum[] pmLocationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmLocationArray, PMLOCATION$0);
        }
    }
    
    /**
     * Sets ith "pmLocation" element
     */
    public void setPmLocationArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PMLOCATION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Sets (as xml) array of all "pmLocation" element
     */
    public void xsetPmLocationArray(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType[]pmLocationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(pmLocationArray, PMLOCATION$0);
        }
    }
    
    /**
     * Sets (as xml) ith "pmLocation" element
     */
    public void xsetPmLocationArray(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().find_element_user(PMLOCATION$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(pmLocation);
        }
    }
    
    /**
     * Inserts the value as the ith "pmLocation" element
     */
    public void insertPmLocation(int i, org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(PMLOCATION$0, i);
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Appends the value as the last "pmLocation" element
     */
    public void addPmLocation(org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType.Enum pmLocation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PMLOCATION$0);
            target.setEnumValue(pmLocation);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType insertNewPmLocation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().insert_element_user(PMLOCATION$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "pmLocation" element
     */
    public org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType addNewPmLocation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType target = null;
            target = (org.tmforum.mtop.nra.xsd.pm.v1.PmLocationType)get_store().add_element_user(PMLOCATION$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "pmLocation" element
     */
    public void removePmLocation(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PMLOCATION$0, i);
        }
    }
}
