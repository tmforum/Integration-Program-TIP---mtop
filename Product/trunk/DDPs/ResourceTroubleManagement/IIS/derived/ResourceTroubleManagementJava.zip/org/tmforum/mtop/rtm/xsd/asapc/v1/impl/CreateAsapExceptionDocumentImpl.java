/*
 * An XML document type.
 * Localname: createAsapException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one createAsapException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAsapExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument
{
    
    public CreateAsapExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEASAPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "createAsapException");
    
    
    /**
     * Gets the "createAsapException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException getCreateAsapException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException)get_store().find_element_user(CREATEASAPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAsapException" element
     */
    public void setCreateAsapException(org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException createAsapException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException)get_store().find_element_user(CREATEASAPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException)get_store().add_element_user(CREATEASAPEXCEPTION$0);
            }
            target.set(createAsapException);
        }
    }
    
    /**
     * Appends and returns a new empty "createAsapException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException addNewCreateAsapException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException)get_store().add_element_user(CREATEASAPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML createAsapException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAsapExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapExceptionDocument.CreateAsapException
    {
        
        public CreateAsapExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
