/*
 * XML Type:  CorrelatedNotificationsType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cornot/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cornot.v1.impl;
/**
 * An XML CorrelatedNotificationsType(@http://www.tmforum.org/mtop/fmw/xsd/cornot/v1).
 *
 * This is a complex type.
 */
public class CorrelatedNotificationsTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.cornot.v1.CorrelatedNotificationsType
{
    
    public CorrelatedNotificationsTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName NAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cornot/v1", "name");
    private static final javax.xml.namespace.QName NOTIFIDS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cornot/v1", "notifIds");
    
    
    /**
     * Gets the "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "name" element
     */
    public void setName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType name)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(NAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            }
            target.set(name);
        }
    }
    
    /**
     * Appends and returns a new empty "name" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(NAME$0);
            return target;
        }
    }
    
    /**
     * Gets the "notifIds" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType getNotifIds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType)get_store().find_element_user(NOTIFIDS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "notifIds" element
     */
    public void setNotifIds(org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType notifIds)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType)get_store().find_element_user(NOTIFIDS$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType)get_store().add_element_user(NOTIFIDS$2);
            }
            target.set(notifIds);
        }
    }
    
    /**
     * Appends and returns a new empty "notifIds" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType addNewNotifIds()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.NotificationIdentifierListType)get_store().add_element_user(NOTIFIDS$2);
            return target;
        }
    }
}
