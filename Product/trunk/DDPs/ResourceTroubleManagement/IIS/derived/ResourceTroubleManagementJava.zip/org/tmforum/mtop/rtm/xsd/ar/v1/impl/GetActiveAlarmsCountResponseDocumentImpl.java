/*
 * An XML document type.
 * Localname: getActiveAlarmsCountResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/ar/v1
 * Java type: org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.ar.v1.impl;
/**
 * A document containing one getActiveAlarmsCountResponse(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveAlarmsCountResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument
{
    
    public GetActiveAlarmsCountResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEALARMSCOUNTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "getActiveAlarmsCountResponse");
    
    
    /**
     * Gets the "getActiveAlarmsCountResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse getGetActiveAlarmsCountResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse)get_store().find_element_user(GETACTIVEALARMSCOUNTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveAlarmsCountResponse" element
     */
    public void setGetActiveAlarmsCountResponse(org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse getActiveAlarmsCountResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse)get_store().find_element_user(GETACTIVEALARMSCOUNTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse)get_store().add_element_user(GETACTIVEALARMSCOUNTRESPONSE$0);
            }
            target.set(getActiveAlarmsCountResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveAlarmsCountResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse addNewGetActiveAlarmsCountResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse)get_store().add_element_user(GETACTIVEALARMSCOUNTRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getActiveAlarmsCountResponse(@http://www.tmforum.org/mtop/rtm/xsd/ar/v1).
     *
     * This is a complex type.
     */
    public static class GetActiveAlarmsCountResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.ar.v1.GetActiveAlarmsCountResponseDocument.GetActiveAlarmsCountResponse
    {
        
        public GetActiveAlarmsCountResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ACTIVEALARMCOUNT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/ar/v1", "activeAlarmCount");
        
        
        /**
         * Gets the "activeAlarmCount" element
         */
        public long getActiveAlarmCount()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVEALARMCOUNT$0, 0);
                if (target == null)
                {
                    return 0L;
                }
                return target.getLongValue();
            }
        }
        
        /**
         * Gets (as xml) the "activeAlarmCount" element
         */
        public org.apache.xmlbeans.XmlUnsignedInt xgetActiveAlarmCount()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlUnsignedInt target = null;
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(ACTIVEALARMCOUNT$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "activeAlarmCount" element
         */
        public void setActiveAlarmCount(long activeAlarmCount)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACTIVEALARMCOUNT$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACTIVEALARMCOUNT$0);
                }
                target.setLongValue(activeAlarmCount);
            }
        }
        
        /**
         * Sets (as xml) the "activeAlarmCount" element
         */
        public void xsetActiveAlarmCount(org.apache.xmlbeans.XmlUnsignedInt activeAlarmCount)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlUnsignedInt target = null;
                target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().find_element_user(ACTIVEALARMCOUNT$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlUnsignedInt)get_store().add_element_user(ACTIVEALARMCOUNT$0);
                }
                target.set(activeAlarmCount);
            }
        }
    }
}
