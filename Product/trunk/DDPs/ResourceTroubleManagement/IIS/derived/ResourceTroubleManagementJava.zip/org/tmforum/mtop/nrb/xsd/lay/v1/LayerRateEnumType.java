/*
 * XML Type:  LayerRateEnumType
 * Namespace: http://www.tmforum.org/mtop/nrb/xsd/lay/v1
 * Java type: org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nrb.xsd.lay.v1;


/**
 * An XML LayerRateEnumType(@http://www.tmforum.org/mtop/nrb/xsd/lay/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType.
 */
public interface LayerRateEnumType extends org.apache.xmlbeans.XmlString
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(LayerRateEnumType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sBE6052E03D6741DEC166ADB27BB9B6C3").resolveHandle("layerrateenumtype2b87type");
    
    org.apache.xmlbeans.StringEnumAbstractBase enumValue();
    void set(org.apache.xmlbeans.StringEnumAbstractBase e);
    
    static final Enum VENDOR_EXT = Enum.forString("VENDOR_EXT");
    static final Enum MINOR_EXT = Enum.forString("MINOR_EXT");
    static final Enum LR_DS_0_64_K = Enum.forString("LR_DS0_64K");
    static final Enum LR_DSL = Enum.forString("LR_DSL");
    static final Enum LR_NOT_APPLICABLE = Enum.forString("LR_Not_Applicable");
    static final Enum LR_ASYNC_FOTS_150_M = Enum.forString("LR_Async_FOTS_150M");
    static final Enum LR_ASYNC_FOTS_417_M = Enum.forString("LR_Async_FOTS_417M");
    static final Enum LR_ASYNC_FOTS_560_M = Enum.forString("LR_Async_FOTS_560M");
    static final Enum LR_ASYNC_FOTS_565_M = Enum.forString("LR_Async_FOTS_565M");
    static final Enum LR_ASYNC_FOTS_1130_M = Enum.forString("LR_Async_FOTS_1130M");
    static final Enum LR_ASYNC_FOTS_1_G_7 = Enum.forString("LR_Async_FOTS_1G7");
    static final Enum LR_ASYNC_FOTS_1_G_8 = Enum.forString("LR_Async_FOTS_1G8");
    static final Enum LR_ATM_NI = Enum.forString("LR_ATM_NI");
    static final Enum LR_ATM_VC = Enum.forString("LR_ATM_VC");
    static final Enum LR_ATM_VP = Enum.forString("LR_ATM_VP");
    static final Enum LR_D_1_VIDEO = Enum.forString("LR_D1_Video");
    static final Enum LR_DIGITAL_SIGNAL_RATE = Enum.forString("LR_DIGITAL_SIGNAL_RATE");
    static final Enum LR_PHYSICAL_ELECTRICAL = Enum.forString("LR_PHYSICAL_ELECTRICAL.");
    static final Enum LR_DSR_1_5_M = Enum.forString("LR_DSR_1_5M");
    static final Enum LR_DSR_2_M = Enum.forString("LR_DSR_2M");
    static final Enum LR_DSR_4_M = Enum.forString("LR_DSR_4M");
    static final Enum LR_DSR_6_M = Enum.forString("LR_DSR_6M");
    static final Enum LR_DSR_8_M = Enum.forString("LR_DSR_8M");
    static final Enum LR_DSR_16_M = Enum.forString("LR_DSR_16M");
    static final Enum LR_DSR_34_M = Enum.forString("LR_DSR_34M");
    static final Enum LR_E_2_8_M = Enum.forString("LR_E2_8M");
    static final Enum LR_E_5_565_M = Enum.forString("LR_E5_565M");
    static final Enum LR_ENCAPSULATION = Enum.forString("LR_Encapsulation");
    static final Enum LR_FRAGMENT = Enum.forString("LR_Fragment");
    static final Enum LR_DSR_45_M = Enum.forString("LR_DSR_45M");
    static final Enum LR_DSR_140_M = Enum.forString("LR_DSR_140M");
    static final Enum LR_DSR_565_M = Enum.forString("LR_DSR_565M");
    static final Enum LR_DSR_FAST_ETHERNET = Enum.forString("LR_DSR_Fast_Ethernet");
    static final Enum LR_DSR_GIGABIT_ETHERNET = Enum.forString("LR_DSR_Gigabit_Ethernet");
    static final Enum LR_DSR_10_GIGABIT_ETHERNET = Enum.forString("LR_DSR_10Gigabit_Ethernet");
    static final Enum LR_DSR_OC_1_STM_0 = Enum.forString("LR_DSR_OC1_STM0");
    static final Enum LR_DSR_OC_3_STM_1 = Enum.forString("LR_DSR_OC3_STM1");
    static final Enum LR_DSR_2_X_STM_1 = Enum.forString("LR_DSR_2xSTM1");
    static final Enum LR_DSR_OC_12_STM_4 = Enum.forString("LR_DSR_OC12_STM4");
    static final Enum LR_DSR_OC_24_STM_8 = Enum.forString("LR_DSR_OC24_STM8");
    static final Enum LR_DSR_OC_48_AND_STM_16 = Enum.forString("LR_DSR_OC48_and_STM16");
    static final Enum LR_DSR_OC_192_AND_STM_64 = Enum.forString("LR_DSR_OC192_and_STM64");
    static final Enum LR_DSR_OC_768_AND_STM_256 = Enum.forString("LR_DSR_OC768_and_STM256");
    static final Enum LR_DSR_OTU_1 = Enum.forString("LR_DSR_OTU1");
    static final Enum LR_DSR_OTU_2 = Enum.forString("LR_DSR_OTU2");
    static final Enum LR_DSR_OTU_3 = Enum.forString("LR_DSR_OTU3");
    static final Enum LR_E_1_2_M = Enum.forString("LR_E1_2M");
    static final Enum LR_E_20_2_X_2_M = Enum.forString("LR_E20_2x2M");
    static final Enum LR_E_30_8_X_2_M = Enum.forString("LR_E30_8x2M");
    static final Enum LR_E_3_34_M = Enum.forString("LR_E3_34M");
    static final Enum LR_E_4_140_M = Enum.forString("LR_E4_140M");
    static final Enum LR_ESCON = Enum.forString("LR_ESCON");
    static final Enum LR_ETHERNET = Enum.forString("LR_Ethernet");
    static final Enum LR_ETR = Enum.forString("LR_ETR");
    static final Enum LR_FAST_ETHERNET = Enum.forString("LR_Fast_Ethernet");
    static final Enum LR_FC_12_133_M = Enum.forString("LR_FC_12_133M");
    static final Enum LR_FC_25_266_M = Enum.forString("LR_FC_25_266M");
    static final Enum LR_FC_50_531_M = Enum.forString("LR_FC_50_531M");
    static final Enum LR_FC_100_1063_M = Enum.forString("LR_FC_100_1063M");
    static final Enum LR_FDDI = Enum.forString("LR_FDDI");
    static final Enum LR_FICON = Enum.forString("LR_FICON");
    static final Enum LR_FR_IF = Enum.forString("LR_FR_IF");
    static final Enum LR_FR_PVC = Enum.forString("LR_FR_PVC");
    static final Enum LR_GIGABIT_ETHERNET = Enum.forString("LR_Gigabit_Ethernet");
    static final Enum LR_ISDN_BRI = Enum.forString("LR_ISDN_BRI");
    static final Enum LR_LINE_OC_1_STS_1_AND_MS_STM_0 = Enum.forString("LR_Line_OC1_STS1_and_MS_STM0");
    static final Enum LR_LINE_OC_3_STS_3_AND_MS_STM_1 = Enum.forString("LR_Line_OC3_STS3_and_MS_STM1");
    static final Enum LR_LINE_OC_12_STS_12_AND_MS_STM_4 = Enum.forString("LR_Line_OC12_STS12_and_MS_STM4");
    static final Enum LR_LINE_OC_24_STS_24_AND_MS_STM_8 = Enum.forString("LR_Line_OC24_STS24_and_MS_STM8");
    static final Enum LR_LINE_OC_48_STS_48_AND_MS_STM_16 = Enum.forString("LR_Line_OC48_STS48_and_MS_STM16");
    static final Enum LR_LINE_OC_192_STS_192_AND_MS_STM_64 = Enum.forString("LR_Line_OC192_STS192_and_MS_STM64");
    static final Enum LR_LINE_OC_768_STS_768_AND_MS_STM_256 = Enum.forString("LR_Line_OC768_STS768_and_MS_STM256");
    static final Enum LR_LOW_ORDER_TU_3_VC_3 = Enum.forString("LR_Low_Order_TU3_VC3");
    static final Enum LR_OCH_DATA_UNIT_1 = Enum.forString("LR_OCH_Data_Unit_1");
    static final Enum LR_OCH_DATA_UNIT_2 = Enum.forString("LR_OCH_Data_Unit_2");
    static final Enum LR_OCH_DATA_UNIT_3 = Enum.forString("LR_OCH_Data_Unit_3");
    static final Enum LR_OCH_TRANSPORT_UNIT_1 = Enum.forString("LR_OCH_Transport_Unit_1");
    static final Enum LR_OCH_TRANSPORT_UNIT_2 = Enum.forString("LR_OCH_Transport_Unit_2");
    static final Enum LR_OCH_TRANSPORT_UNIT_3 = Enum.forString("LR_OCH_Transport_Unit_3");
    static final Enum LR_STS_3_C_AND_AU_4_VC_4 = Enum.forString("LR_STS3c_and_AU4_VC4");
    static final Enum LR_STS_4_C_AND_VC_3_4_C = Enum.forString("LR_STS4c_and_VC3_4c");
    static final Enum LR_STS_5_C_AND_VC_3_5_C = Enum.forString("LR_STS5c_and_VC3_5c");
    static final Enum LR_STS_6_C_AND_VC_4_2_C = Enum.forString("LR_STS6c_and_VC4_2c");
    static final Enum LR_STS_7_C_AND_VC_3_7_C = Enum.forString("LR_STS7c_and_VC3_7c");
    static final Enum LR_STS_8_C_AND_VC_3_8_C = Enum.forString("LR_STS8c_and_VC3_8c");
    static final Enum LR_STS_9_C_AND_VC_4_3_C = Enum.forString("LR_STS9c_and_VC4_3c");
    static final Enum LR_OPTICAL_CHANNEL = Enum.forString("LR_Optical_Channel");
    static final Enum LR_OPTICAL_MULTIPLEX_SECTION = Enum.forString("LR_Optical_Multiplex_Section");
    static final Enum LR_OPTICAL_SECTION = Enum.forString("LR_OPTICAL_SECTION");
    static final Enum LR_OPTICAL_TRANSMISSION_SECTION = Enum.forString("LR_Optical_Transmission_Section");
    static final Enum LR_PHYSICAL_ELECTRICAL_2 = Enum.forString("LR_PHYSICAL_ELECTRICAL");
    static final Enum LR_PHYSICAL_MEDIALESS = Enum.forString("LR_PHYSICAL_MEDIALESS");
    static final Enum LR_PHYSICAL_OPTICAL = Enum.forString("LR_PHYSICAL_OPTICAL");
    static final Enum LR_POTS = Enum.forString("LR_POTS");
    static final Enum LR_SECTION_OC_1_STS_1_AND_RS_STM_0 = Enum.forString("LR_Section_OC1_STS1_and_RS_STM0");
    static final Enum LR_SECTION_OC_3_STS_3_AND_RS_STM_1 = Enum.forString("LR_Section_OC3_STS3_and_RS_STM1");
    static final Enum LR_SECTION_OC_12_STS_12_AND_RS_STM_4 = Enum.forString("LR_Section_OC12_STS12_and_RS_STM4");
    static final Enum LR_SECTION_OC_24_STS_24_AND_RS_STM_8 = Enum.forString("LR_Section_OC24_STS24_and_RS_STM8");
    static final Enum LR_SECTION_OC_48_STS_48_AND_RS_STM_16 = Enum.forString("LR_Section_OC48_STS48_and_RS_STM16");
    static final Enum LR_SECTION_OC_192_STS_192_AND_RS_STM_64 = Enum.forString("LR_Section_OC192_STS192_and_RS_STM64");
    static final Enum LR_SECTION_OC_768_STS_768_AND_RS_STM_256 = Enum.forString("LR_Section_OC768_STS768_and_RS_STM256");
    static final Enum LR_STS_1_AND_AU_3_HIGH_ORDER_VC_3 = Enum.forString("LR_STS1_and_AU3_High_Order_VC3");
    static final Enum LR_STS_2_C_AND_VC_3_2_C = Enum.forString("LR_STS2c_and_VC3_2c");
    static final Enum LR_STS_10_C_AND_VC_3_10_C = Enum.forString("LR_STS10c_and_VC3_10c");
    static final Enum LR_STS_11_C_AND_VC_3_11_C = Enum.forString("LR_STS11c_and_VC3_11c");
    static final Enum LR_STS_12_C_AND_VC_4_4_C = Enum.forString("LR_STS12c_and_VC4_4c");
    static final Enum LR_STS_13_C_AND_VC_3_13_C = Enum.forString("LR_STS13c_and_VC3_13c");
    static final Enum LR_STS_14_C_AND_VC_3_14_C = Enum.forString("LR_STS14c_and_VC3_14c");
    static final Enum LR_STS_15_C_AND_VC_4_5_C = Enum.forString("LR_STS15c_and_VC4_5c");
    static final Enum LR_STS_16_C_AND_VC_3_16_C = Enum.forString("LR_STS16c_and_VC3_16c");
    static final Enum LR_STS_17_C_AND_VC_3_17_C = Enum.forString("LR_STS17c_and_VC3_17c");
    static final Enum LR_STS_18_C_AND_VC_4_6_C = Enum.forString("LR_STS18c_and_VC4_6c");
    static final Enum LR_STS_19_C_AND_VC_3_19_C = Enum.forString("LR_STS19c_and_VC3_19c");
    static final Enum LR_STS_20_C_AND_VC_3_20_C = Enum.forString("LR_STS20c_and_VC3_20c");
    static final Enum LR_STS_21_C_AND_VC_4_7_C = Enum.forString("LR_STS21c_and_VC4_7c");
    static final Enum LR_STS_22_C_AND_VC_3_22_C = Enum.forString("LR_STS22c_and_VC3_22c");
    static final Enum LR_STS_23_C_AND_VC_3_23_C = Enum.forString("LR_STS23c_and_VC3_23c");
    static final Enum LR_STS_24_C_AND_VC_4_8_C = Enum.forString("LR_STS24c_and_VC4_8c");
    static final Enum LR_STS_25_C_AND_VC_3_25_C = Enum.forString("LR_STS25c_and_VC3_25c");
    static final Enum LR_STS_26_C_AND_VC_3_26_C = Enum.forString("LR_STS26c_and_VC3_26c");
    static final Enum LR_STS_27_C_AND_VC_4_9_C = Enum.forString("LR_STS27c_and_VC4_9c");
    static final Enum LR_STS_28_C_AND_VC_3_28_C = Enum.forString("LR_STS28c_and_VC3_28c");
    static final Enum LR_STS_29_C_AND_VC_3_29_C = Enum.forString("LR_STS29c_and_VC3_29c");
    static final Enum LR_STS_30_C_AND_VC_4_10_C = Enum.forString("LR_STS30c_and_VC4_10c");
    static final Enum LR_STS_31_C_AND_VC_3_31_C = Enum.forString("LR_STS31c_and_VC3_31c");
    static final Enum LR_STS_32_C_AND_VC_3_32_C = Enum.forString("LR_STS32c_and_VC3_32c");
    static final Enum LR_STS_33_C_AND_VC_4_11_C = Enum.forString("LR_STS33c_and_VC4_11c");
    static final Enum LR_STS_34_C_AND_VC_3_34_C = Enum.forString("LR_STS34c_and_VC3_34c");
    static final Enum LR_STS_35_C_AND_VC_3_35_C = Enum.forString("LR_STS35c_and_VC3_35c");
    static final Enum LR_STS_36_C_AND_VC_4_12_C = Enum.forString("LR_STS36c_and_VC4_12c");
    static final Enum LR_STS_37_C_AND_VC_3_37_C = Enum.forString("LR_STS37c_and_VC3_37c");
    static final Enum LR_STS_38_C_AND_VC_3_38_C = Enum.forString("LR_STS38c_and_VC3_38c");
    static final Enum LR_STS_39_C_AND_VC_4_13_C = Enum.forString("LR_STS39c_and_VC4_13c");
    static final Enum LR_STS_40_C_AND_VC_3_40_C = Enum.forString("LR_STS40c_and_VC3_40c");
    static final Enum LR_STS_41_C_AND_VC_3_41_C = Enum.forString("LR_STS41c_and_VC3_41c");
    static final Enum LR_STS_42_C_AND_VC_4_14_C = Enum.forString("LR_STS42c_and_VC4_14c");
    static final Enum LR_STS_43_C_AND_VC_3_43_C = Enum.forString("LR_STS43c_and_VC3_43c");
    static final Enum LR_STS_44_C_AND_VC_3_44_C = Enum.forString("LR_STS44c_and_VC3_44c");
    static final Enum LR_STS_45_C_AND_VC_4_15_C = Enum.forString("LR_STS45c_and_VC4_15c");
    static final Enum LR_STS_46_C_AND_VC_3_46_C = Enum.forString("LR_STS46c_and_VC3_46c");
    static final Enum LR_STS_47_C_AND_VC_3_47_C = Enum.forString("LR_STS47c_and_VC3_47c");
    static final Enum LR_STS_48_C_AND_VC_4_16_C = Enum.forString("LR_STS48c_and_VC4_16c");
    static final Enum LR_STS_49_C_AND_VC_3_49_C = Enum.forString("LR_STS49c_and_VC3_49c");
    static final Enum LR_STS_50_C_AND_VC_3_50_C = Enum.forString("LR_STS50c_and_VC3_50c");
    static final Enum LR_STS_51_C_AND_VC_4_17_C = Enum.forString("LR_STS51c_and_VC4_17c");
    static final Enum LR_STS_52_C_AND_VC_3_52_C = Enum.forString("LR_STS52c_and_VC3_52c");
    static final Enum LR_STS_53_C_AND_VC_3_53_C = Enum.forString("LR_STS53c_and_VC3_53c");
    static final Enum LR_STS_54_C_AND_VC_4_18_C = Enum.forString("LR_STS54c_and_VC4_18c");
    static final Enum LR_STS_55_C_AND_VC_3_55_C = Enum.forString("LR_STS55c_and_VC3_55c");
    static final Enum LR_STS_56_C_AND_VC_3_56_C = Enum.forString("LR_STS56c_and_VC3_56c");
    static final Enum LR_STS_57_C_AND_VC_4_19_C = Enum.forString("LR_STS57c_and_VC4_19c");
    static final Enum LR_STS_58_C_AND_VC_3_58_C = Enum.forString("LR_STS58c_and_VC3_58c");
    static final Enum LR_STS_59_C_AND_VC_3_59_C = Enum.forString("LR_STS59c_and_VC3_59c");
    static final Enum LR_STS_60_C_AND_VC_4_20_C = Enum.forString("LR_STS60c_and_VC4_20c");
    static final Enum LR_STS_61_C_AND_VC_3_61_C = Enum.forString("LR_STS61c_and_VC3_61c");
    static final Enum LR_STS_62_C_AND_VC_3_62_C = Enum.forString("LR_STS62c_and_VC3_62c");
    static final Enum LR_STS_63_C_AND_VC_4_21_C = Enum.forString("LR_STS63c_and_VC4_21c");
    static final Enum LR_STS_64_C_AND_VC_3_64_C = Enum.forString("LR_STS64c_and_VC3_64c");
    static final Enum LR_STS_65_C_AND_VC_3_65_C = Enum.forString("LR_STS65c_and_VC3_65c");
    static final Enum LR_STS_66_C_AND_VC_4_22_C = Enum.forString("LR_STS66c_and_VC4_22c");
    static final Enum LR_STS_67_C_AND_VC_3_67_C = Enum.forString("LR_STS67c_and_VC3_67c");
    static final Enum LR_STS_68_C_AND_VC_3_68_C = Enum.forString("LR_STS68c_and_VC3_68c");
    static final Enum LR_STS_69_C_AND_VC_4_23_C = Enum.forString("LR_STS69c_and_VC4_23c");
    static final Enum LR_STS_70_C_AND_VC_3_70_C = Enum.forString("LR_STS70c_and_VC3_70c");
    static final Enum LR_STS_71_C_AND_VC_3_71_C = Enum.forString("LR_STS71c_and_VC3_71c");
    static final Enum LR_STS_72_C_AND_VC_4_24_C = Enum.forString("LR_STS72c_and_VC4_24c");
    static final Enum LR_STS_73_C_AND_VC_3_73_C = Enum.forString("LR_STS73c_and_VC3_73c");
    static final Enum LR_STS_74_C_AND_VC_3_74_C = Enum.forString("LR_STS74c_and_VC3_74c");
    static final Enum LR_STS_75_C_AND_VC_4_25_C = Enum.forString("LR_STS75c_and_VC4_25c");
    static final Enum LR_STS_76_C_AND_VC_3_76_C = Enum.forString("LR_STS76c_and_VC3_76c");
    static final Enum LR_STS_77_C_AND_VC_3_77_C = Enum.forString("LR_STS77c_and_VC3_77c");
    static final Enum LR_STS_78_C_AND_VC_4_26_C = Enum.forString("LR_STS78c_and_VC4_26c");
    static final Enum LR_STS_79_C_AND_VC_3_79_C = Enum.forString("LR_STS79c_and_VC3_79c");
    static final Enum LR_STS_80_C_AND_VC_3_80_C = Enum.forString("LR_STS80c_and_VC3_80c");
    static final Enum LR_STS_81_C_AND_VC_4_27_C = Enum.forString("LR_STS81c_and_VC4_27c");
    static final Enum LR_STS_82_C_AND_VC_3_82_C = Enum.forString("LR_STS82c_and_VC3_82c");
    static final Enum LR_STS_83_C_AND_VC_3_83_C = Enum.forString("LR_STS83c_and_VC3_83c");
    static final Enum LR_STS_84_C_AND_VC_4_28_C = Enum.forString("LR_STS84c_and_VC4_28c");
    static final Enum LR_STS_85_C_AND_VC_3_85_C = Enum.forString("LR_STS85c_and_VC3_85c");
    static final Enum LR_STS_86_C_AND_VC_3_86_C = Enum.forString("LR_STS86c_and_VC3_86c");
    static final Enum LR_STS_87_C_AND_VC_4_29_C = Enum.forString("LR_STS87c_and_VC4_29c");
    static final Enum LR_STS_88_C_AND_VC_3_88_C = Enum.forString("LR_STS88c_and_VC3_88c");
    static final Enum LR_STS_89_C_AND_VC_3_89_C = Enum.forString("LR_STS89c_and_VC3_89c");
    static final Enum LR_STS_90_C_AND_VC_4_30_C = Enum.forString("LR_STS90c_and_VC4_30c");
    static final Enum LR_STS_91_C_AND_VC_3_91_C = Enum.forString("LR_STS91c_and_VC3_91c");
    static final Enum LR_STS_92_C_AND_VC_3_92_C = Enum.forString("LR_STS92c_and_VC3_92c");
    static final Enum LR_STS_93_C_AND_VC_4_31_C = Enum.forString("LR_STS93c_and_VC4_31c");
    static final Enum LR_STS_94_C_AND_VC_3_94_C = Enum.forString("LR_STS94c_and_VC3_94c");
    static final Enum LR_STS_95_C_AND_VC_3_95_C = Enum.forString("LR_STS95c_and_VC3_95c");
    static final Enum LR_STS_96_C_AND_VC_4_32_C = Enum.forString("LR_STS96c_and_VC4_32c");
    static final Enum LR_STS_97_C_AND_VC_3_97_C = Enum.forString("LR_STS97c_and_VC3_97c");
    static final Enum LR_STS_98_C_AND_VC_3_98_C = Enum.forString("LR_STS98c_and_VC3_98c");
    static final Enum LR_STS_99_C_AND_VC_4_33_C = Enum.forString("LR_STS99c_and_VC4_33c");
    static final Enum LR_STS_100_C_AND_VC_3_100_C = Enum.forString("LR_STS100c_and_VC3_100c");
    static final Enum LR_STS_101_C_AND_VC_3_101_C = Enum.forString("LR_STS101c_and_VC3_101c");
    static final Enum LR_STS_102_C_AND_VC_4_34_C = Enum.forString("LR_STS102c_and_VC4_34c");
    static final Enum LR_STS_103_C_AND_VC_3_103_C = Enum.forString("LR_STS103c_and_VC3_103c");
    static final Enum LR_STS_104_C_AND_VC_3_104_C = Enum.forString("LR_STS104c_and_VC3_104c");
    static final Enum LR_STS_105_C_AND_VC_4_35_C = Enum.forString("LR_STS105c_and_VC4_35c");
    static final Enum LR_STS_106_C_AND_VC_3_106_C = Enum.forString("LR_STS106c_and_VC3_106c");
    static final Enum LR_STS_107_C_AND_VC_3_107_C = Enum.forString("LR_STS107c_and_VC3_107c");
    static final Enum LR_STS_108_C_AND_VC_4_36_C = Enum.forString("LR_STS108c_and_VC4_36c");
    static final Enum LR_STS_109_C_AND_VC_3_109_C = Enum.forString("LR_STS109c_and_VC3_109c");
    static final Enum LR_STS_110_C_AND_VC_3_110_C = Enum.forString("LR_STS110c_and_VC3_110c");
    static final Enum LR_STS_111_C_AND_VC_4_37_C = Enum.forString("LR_STS111c_and_VC4_37c");
    static final Enum LR_STS_112_C_AND_VC_3_112_C = Enum.forString("LR_STS112c_and_VC3_112c");
    static final Enum LR_STS_113_C_AND_VC_3_113_C = Enum.forString("LR_STS113c_and_VC3_113c");
    static final Enum LR_STS_114_C_AND_VC_4_38_C = Enum.forString("LR_STS114c_and_VC4_38c");
    static final Enum LR_STS_115_C_AND_VC_3_115_C = Enum.forString("LR_STS115c_and_VC3_115c");
    static final Enum LR_STS_116_C_AND_VC_3_116_C = Enum.forString("LR_STS116c_and_VC3_116c");
    static final Enum LR_STS_117_C_AND_VC_4_39_C = Enum.forString("LR_STS117c_and_VC4_39c");
    static final Enum LR_STS_118_C_AND_VC_3_118_C = Enum.forString("LR_STS118c_and_VC3_118c");
    static final Enum LR_STS_119_C_AND_VC_3_119_C = Enum.forString("LR_STS119c_and_VC3_119c");
    static final Enum LR_STS_120_C_AND_VC_4_40_C = Enum.forString("LR_STS120c_and_VC4_40c");
    static final Enum LR_STS_121_C_AND_VC_3_121_C = Enum.forString("LR_STS121c_and_VC3_121c");
    static final Enum LR_STS_122_C_AND_VC_3_122_C = Enum.forString("LR_STS122c_and_VC3_122c");
    static final Enum LR_STS_123_C_AND_VC_4_41_C = Enum.forString("LR_STS123c_and_VC4_41c");
    static final Enum LR_STS_124_C_AND_VC_3_124_C = Enum.forString("LR_STS124c_and_VC3_124c");
    static final Enum LR_STS_125_C_AND_VC_3_125_C = Enum.forString("LR_STS125c_and_VC3_125c");
    static final Enum LR_STS_126_C_AND_VC_4_42_C = Enum.forString("LR_STS126c_and_VC4_42c");
    static final Enum LR_STS_127_C_AND_VC_3_127_C = Enum.forString("LR_STS127c_and_VC3_127c");
    static final Enum LR_STS_128_C_AND_VC_3_128_C = Enum.forString("LR_STS128c_and_VC3_128c");
    static final Enum LR_STS_129_C_AND_VC_4_43_C = Enum.forString("LR_STS129c_and_VC4_43c");
    static final Enum LR_STS_130_C_AND_VC_3_130_C = Enum.forString("LR_STS130c_and_VC3_130c");
    static final Enum LR_STS_131_C_AND_VC_3_131_C = Enum.forString("LR_STS131c_and_VC3_131c");
    static final Enum LR_STS_132_C_AND_VC_4_44_C = Enum.forString("LR_STS132c_and_VC4_44c");
    static final Enum LR_STS_133_C_AND_VC_3_133_C = Enum.forString("LR_STS133c_and_VC3_133c");
    static final Enum LR_STS_134_C_AND_VC_3_134_C = Enum.forString("LR_STS134c_and_VC3_134c");
    static final Enum LR_STS_135_C_AND_VC_4_45_C = Enum.forString("LR_STS135c_and_VC4_45c");
    static final Enum LR_STS_136_C_AND_VC_3_136_C = Enum.forString("LR_STS136c_and_VC3_136c");
    static final Enum LR_STS_137_C_AND_VC_3_137_C = Enum.forString("LR_STS137c_and_VC3_137c");
    static final Enum LR_STS_138_C_AND_VC_4_46_C = Enum.forString("LR_STS138c_and_VC4_46c");
    static final Enum LR_STS_139_C_AND_VC_3_139_C = Enum.forString("LR_STS139c_and_VC3_139c");
    static final Enum LR_STS_140_C_AND_VC_3_140_C = Enum.forString("LR_STS140c_and_VC3_140c");
    static final Enum LR_STS_141_C_AND_VC_4_47_C = Enum.forString("LR_STS141c_and_VC4_47c");
    static final Enum LR_STS_142_C_AND_VC_3_142_C = Enum.forString("LR_STS142c_and_VC3_142c");
    static final Enum LR_STS_143_C_AND_VC_3_143_C = Enum.forString("LR_STS143c_and_VC3_143c");
    static final Enum LR_STS_144_C_AND_VC_4_48_C = Enum.forString("LR_STS144c_and_VC4_48c");
    static final Enum LR_STS_145_C_AND_VC_3_145_C = Enum.forString("LR_STS145c_and_VC3_145c");
    static final Enum LR_STS_146_C_AND_VC_3_146_C = Enum.forString("LR_STS146c_and_VC3_146c");
    static final Enum LR_STS_147_C_AND_VC_4_49_C = Enum.forString("LR_STS147c_and_VC4_49c");
    static final Enum LR_STS_148_C_AND_VC_3_148_C = Enum.forString("LR_STS148c_and_VC3_148c");
    static final Enum LR_STS_149_C_AND_VC_3_149_C = Enum.forString("LR_STS149c_and_VC3_149c");
    static final Enum LR_STS_150_C_AND_VC_4_50_C = Enum.forString("LR_STS150c_and_VC4_50c");
    static final Enum LR_STS_151_C_AND_VC_3_151_C = Enum.forString("LR_STS151c_and_VC3_151c");
    static final Enum LR_STS_152_C_AND_VC_3_152_C = Enum.forString("LR_STS152c_and_VC3_152c");
    static final Enum LR_STS_153_C_AND_VC_4_51_C = Enum.forString("LR_STS153c_and_VC4_51c");
    static final Enum LR_STS_154_C_AND_VC_3_154_C = Enum.forString("LR_STS154c_and_VC3_154c");
    static final Enum LR_STS_155_C_AND_VC_3_155_C = Enum.forString("LR_STS155c_and_VC3_155c");
    static final Enum LR_STS_156_C_AND_VC_4_52_C = Enum.forString("LR_STS156c_and_VC4_52c");
    static final Enum LR_STS_157_C_AND_VC_3_157_C = Enum.forString("LR_STS157c_and_VC3_157c");
    static final Enum LR_STS_158_C_AND_VC_3_158_C = Enum.forString("LR_STS158c_and_VC3_158c");
    static final Enum LR_STS_159_C_AND_VC_4_53_C = Enum.forString("LR_STS159c_and_VC4_53c");
    static final Enum LR_STS_160_C_AND_VC_3_160_C = Enum.forString("LR_STS160c_and_VC3_160c");
    static final Enum LR_STS_161_C_AND_VC_3_161_C = Enum.forString("LR_STS161c_and_VC3_161c");
    static final Enum LR_STS_162_C_AND_VC_4_54_C = Enum.forString("LR_STS162c_and_VC4_54c");
    static final Enum LR_STS_163_C_AND_VC_3_163_C = Enum.forString("LR_STS163c_and_VC3_163c");
    static final Enum LR_STS_164_C_AND_VC_3_164_C = Enum.forString("LR_STS164c_and_VC3_164c");
    static final Enum LR_STS_165_C_AND_VC_4_55_C = Enum.forString("LR_STS165c_and_VC4_55c");
    static final Enum LR_STS_166_C_AND_VC_3_166_C = Enum.forString("LR_STS166c_and_VC3_166c");
    static final Enum LR_STS_167_C_AND_VC_3_167_C = Enum.forString("LR_STS167c_and_VC3_167c");
    static final Enum LR_STS_168_C_AND_VC_4_56_C = Enum.forString("LR_STS168c_and_VC4_56c");
    static final Enum LR_STS_169_C_AND_VC_3_169_C = Enum.forString("LR_STS169c_and_VC3_169c");
    static final Enum LR_STS_170_C_AND_VC_3_170_C = Enum.forString("LR_STS170c_and_VC3_170c");
    static final Enum LR_STS_171_C_AND_VC_4_57_C = Enum.forString("LR_STS171c_and_VC4_57c");
    static final Enum LR_STS_172_C_AND_VC_3_172_C = Enum.forString("LR_STS172c_and_VC3_172c");
    static final Enum LR_STS_173_C_AND_VC_3_173_C = Enum.forString("LR_STS173c_and_VC3_173c");
    static final Enum LR_STS_174_C_AND_VC_4_58_C = Enum.forString("LR_STS174c_and_VC4_58c");
    static final Enum LR_STS_175_C_AND_VC_3_175_C = Enum.forString("LR_STS175c_and_VC3_175c");
    static final Enum LR_STS_176_C_AND_VC_3_176_C = Enum.forString("LR_STS176c_and_VC3_176c");
    static final Enum LR_STS_177_C_AND_VC_4_59_C = Enum.forString("LR_STS177c_and_VC4_59c");
    static final Enum LR_STS_178_C_AND_VC_3_178_C = Enum.forString("LR_STS178c_and_VC3_178c");
    static final Enum LR_STS_179_C_AND_VC_3_179_C = Enum.forString("LR_STS179c_and_VC3_179c");
    static final Enum LR_STS_180_C_AND_VC_4_60_C = Enum.forString("LR_STS180c_and_VC4_60c");
    static final Enum LR_STS_181_C_AND_VC_3_181_C = Enum.forString("LR_STS181c_and_VC3_181c");
    static final Enum LR_STS_182_C_AND_VC_3_182_C = Enum.forString("LR_STS182c_and_VC3_182c");
    static final Enum LR_STS_183_C_AND_VC_4_61_C = Enum.forString("LR_STS183c_and_VC4_61c");
    static final Enum LR_STS_184_C_AND_VC_3_184_C = Enum.forString("LR_STS184c_and_VC3_184c");
    static final Enum LR_STS_185_C_AND_VC_3_185_C = Enum.forString("LR_STS185c_and_VC3_185c");
    static final Enum LR_STS_186_C_AND_VC_4_62_C = Enum.forString("LR_STS186c_and_VC4_62c");
    static final Enum LR_STS_187_C_AND_VC_3_187_C = Enum.forString("LR_STS187c_and_VC3_187c");
    static final Enum LR_STS_188_C_AND_VC_3_188_C = Enum.forString("LR_STS188c_and_VC3_188c");
    static final Enum LR_STS_189_C_AND_VC_4_63_C = Enum.forString("LR_STS189c_and_VC4_63c");
    static final Enum LR_STS_190_C_AND_VC_3_190_C = Enum.forString("LR_STS190c_and_VC3_190c");
    static final Enum LR_STS_191_C_AND_VC_3_191_C = Enum.forString("LR_STS191c_and_VC3_191c");
    static final Enum LR_STS_192_C_AND_VC_4_64_C = Enum.forString("LR_STS192c_and_VC4_64c");
    static final Enum LR_STS_768_C_AND_VC_4_256_C = Enum.forString("LR_STS768c_and_VC4_256c");
    static final Enum LR_T_1_AND_DS_1_1_5_M = Enum.forString("LR_T1_and_DS1_1_5M");
    static final Enum LR_T_2_AND_DS_2_6_M = Enum.forString("LR_T2_and_DS2_6M");
    static final Enum LR_T_3_AND_DS_3_45_M = Enum.forString("LR_T3_and_DS3_45M");
    static final Enum LR_VT_1_5_AND_TU_11_VC_11 = Enum.forString("LR_VT1_5_and_TU11_VC11");
    static final Enum LR_VT_2_AND_TU_12_VC_12 = Enum.forString("LR_VT2_and_TU12_VC12");
    static final Enum LR_VT_6_AND_TU_2_VC_2 = Enum.forString("LR_VT6_and_TU2_VC2");
    
    static final int INT_VENDOR_EXT = Enum.INT_VENDOR_EXT;
    static final int INT_MINOR_EXT = Enum.INT_MINOR_EXT;
    static final int INT_LR_DS_0_64_K = Enum.INT_LR_DS_0_64_K;
    static final int INT_LR_DSL = Enum.INT_LR_DSL;
    static final int INT_LR_NOT_APPLICABLE = Enum.INT_LR_NOT_APPLICABLE;
    static final int INT_LR_ASYNC_FOTS_150_M = Enum.INT_LR_ASYNC_FOTS_150_M;
    static final int INT_LR_ASYNC_FOTS_417_M = Enum.INT_LR_ASYNC_FOTS_417_M;
    static final int INT_LR_ASYNC_FOTS_560_M = Enum.INT_LR_ASYNC_FOTS_560_M;
    static final int INT_LR_ASYNC_FOTS_565_M = Enum.INT_LR_ASYNC_FOTS_565_M;
    static final int INT_LR_ASYNC_FOTS_1130_M = Enum.INT_LR_ASYNC_FOTS_1130_M;
    static final int INT_LR_ASYNC_FOTS_1_G_7 = Enum.INT_LR_ASYNC_FOTS_1_G_7;
    static final int INT_LR_ASYNC_FOTS_1_G_8 = Enum.INT_LR_ASYNC_FOTS_1_G_8;
    static final int INT_LR_ATM_NI = Enum.INT_LR_ATM_NI;
    static final int INT_LR_ATM_VC = Enum.INT_LR_ATM_VC;
    static final int INT_LR_ATM_VP = Enum.INT_LR_ATM_VP;
    static final int INT_LR_D_1_VIDEO = Enum.INT_LR_D_1_VIDEO;
    static final int INT_LR_DIGITAL_SIGNAL_RATE = Enum.INT_LR_DIGITAL_SIGNAL_RATE;
    static final int INT_LR_PHYSICAL_ELECTRICAL = Enum.INT_LR_PHYSICAL_ELECTRICAL;
    static final int INT_LR_DSR_1_5_M = Enum.INT_LR_DSR_1_5_M;
    static final int INT_LR_DSR_2_M = Enum.INT_LR_DSR_2_M;
    static final int INT_LR_DSR_4_M = Enum.INT_LR_DSR_4_M;
    static final int INT_LR_DSR_6_M = Enum.INT_LR_DSR_6_M;
    static final int INT_LR_DSR_8_M = Enum.INT_LR_DSR_8_M;
    static final int INT_LR_DSR_16_M = Enum.INT_LR_DSR_16_M;
    static final int INT_LR_DSR_34_M = Enum.INT_LR_DSR_34_M;
    static final int INT_LR_E_2_8_M = Enum.INT_LR_E_2_8_M;
    static final int INT_LR_E_5_565_M = Enum.INT_LR_E_5_565_M;
    static final int INT_LR_ENCAPSULATION = Enum.INT_LR_ENCAPSULATION;
    static final int INT_LR_FRAGMENT = Enum.INT_LR_FRAGMENT;
    static final int INT_LR_DSR_45_M = Enum.INT_LR_DSR_45_M;
    static final int INT_LR_DSR_140_M = Enum.INT_LR_DSR_140_M;
    static final int INT_LR_DSR_565_M = Enum.INT_LR_DSR_565_M;
    static final int INT_LR_DSR_FAST_ETHERNET = Enum.INT_LR_DSR_FAST_ETHERNET;
    static final int INT_LR_DSR_GIGABIT_ETHERNET = Enum.INT_LR_DSR_GIGABIT_ETHERNET;
    static final int INT_LR_DSR_10_GIGABIT_ETHERNET = Enum.INT_LR_DSR_10_GIGABIT_ETHERNET;
    static final int INT_LR_DSR_OC_1_STM_0 = Enum.INT_LR_DSR_OC_1_STM_0;
    static final int INT_LR_DSR_OC_3_STM_1 = Enum.INT_LR_DSR_OC_3_STM_1;
    static final int INT_LR_DSR_2_X_STM_1 = Enum.INT_LR_DSR_2_X_STM_1;
    static final int INT_LR_DSR_OC_12_STM_4 = Enum.INT_LR_DSR_OC_12_STM_4;
    static final int INT_LR_DSR_OC_24_STM_8 = Enum.INT_LR_DSR_OC_24_STM_8;
    static final int INT_LR_DSR_OC_48_AND_STM_16 = Enum.INT_LR_DSR_OC_48_AND_STM_16;
    static final int INT_LR_DSR_OC_192_AND_STM_64 = Enum.INT_LR_DSR_OC_192_AND_STM_64;
    static final int INT_LR_DSR_OC_768_AND_STM_256 = Enum.INT_LR_DSR_OC_768_AND_STM_256;
    static final int INT_LR_DSR_OTU_1 = Enum.INT_LR_DSR_OTU_1;
    static final int INT_LR_DSR_OTU_2 = Enum.INT_LR_DSR_OTU_2;
    static final int INT_LR_DSR_OTU_3 = Enum.INT_LR_DSR_OTU_3;
    static final int INT_LR_E_1_2_M = Enum.INT_LR_E_1_2_M;
    static final int INT_LR_E_20_2_X_2_M = Enum.INT_LR_E_20_2_X_2_M;
    static final int INT_LR_E_30_8_X_2_M = Enum.INT_LR_E_30_8_X_2_M;
    static final int INT_LR_E_3_34_M = Enum.INT_LR_E_3_34_M;
    static final int INT_LR_E_4_140_M = Enum.INT_LR_E_4_140_M;
    static final int INT_LR_ESCON = Enum.INT_LR_ESCON;
    static final int INT_LR_ETHERNET = Enum.INT_LR_ETHERNET;
    static final int INT_LR_ETR = Enum.INT_LR_ETR;
    static final int INT_LR_FAST_ETHERNET = Enum.INT_LR_FAST_ETHERNET;
    static final int INT_LR_FC_12_133_M = Enum.INT_LR_FC_12_133_M;
    static final int INT_LR_FC_25_266_M = Enum.INT_LR_FC_25_266_M;
    static final int INT_LR_FC_50_531_M = Enum.INT_LR_FC_50_531_M;
    static final int INT_LR_FC_100_1063_M = Enum.INT_LR_FC_100_1063_M;
    static final int INT_LR_FDDI = Enum.INT_LR_FDDI;
    static final int INT_LR_FICON = Enum.INT_LR_FICON;
    static final int INT_LR_FR_IF = Enum.INT_LR_FR_IF;
    static final int INT_LR_FR_PVC = Enum.INT_LR_FR_PVC;
    static final int INT_LR_GIGABIT_ETHERNET = Enum.INT_LR_GIGABIT_ETHERNET;
    static final int INT_LR_ISDN_BRI = Enum.INT_LR_ISDN_BRI;
    static final int INT_LR_LINE_OC_1_STS_1_AND_MS_STM_0 = Enum.INT_LR_LINE_OC_1_STS_1_AND_MS_STM_0;
    static final int INT_LR_LINE_OC_3_STS_3_AND_MS_STM_1 = Enum.INT_LR_LINE_OC_3_STS_3_AND_MS_STM_1;
    static final int INT_LR_LINE_OC_12_STS_12_AND_MS_STM_4 = Enum.INT_LR_LINE_OC_12_STS_12_AND_MS_STM_4;
    static final int INT_LR_LINE_OC_24_STS_24_AND_MS_STM_8 = Enum.INT_LR_LINE_OC_24_STS_24_AND_MS_STM_8;
    static final int INT_LR_LINE_OC_48_STS_48_AND_MS_STM_16 = Enum.INT_LR_LINE_OC_48_STS_48_AND_MS_STM_16;
    static final int INT_LR_LINE_OC_192_STS_192_AND_MS_STM_64 = Enum.INT_LR_LINE_OC_192_STS_192_AND_MS_STM_64;
    static final int INT_LR_LINE_OC_768_STS_768_AND_MS_STM_256 = Enum.INT_LR_LINE_OC_768_STS_768_AND_MS_STM_256;
    static final int INT_LR_LOW_ORDER_TU_3_VC_3 = Enum.INT_LR_LOW_ORDER_TU_3_VC_3;
    static final int INT_LR_OCH_DATA_UNIT_1 = Enum.INT_LR_OCH_DATA_UNIT_1;
    static final int INT_LR_OCH_DATA_UNIT_2 = Enum.INT_LR_OCH_DATA_UNIT_2;
    static final int INT_LR_OCH_DATA_UNIT_3 = Enum.INT_LR_OCH_DATA_UNIT_3;
    static final int INT_LR_OCH_TRANSPORT_UNIT_1 = Enum.INT_LR_OCH_TRANSPORT_UNIT_1;
    static final int INT_LR_OCH_TRANSPORT_UNIT_2 = Enum.INT_LR_OCH_TRANSPORT_UNIT_2;
    static final int INT_LR_OCH_TRANSPORT_UNIT_3 = Enum.INT_LR_OCH_TRANSPORT_UNIT_3;
    static final int INT_LR_STS_3_C_AND_AU_4_VC_4 = Enum.INT_LR_STS_3_C_AND_AU_4_VC_4;
    static final int INT_LR_STS_4_C_AND_VC_3_4_C = Enum.INT_LR_STS_4_C_AND_VC_3_4_C;
    static final int INT_LR_STS_5_C_AND_VC_3_5_C = Enum.INT_LR_STS_5_C_AND_VC_3_5_C;
    static final int INT_LR_STS_6_C_AND_VC_4_2_C = Enum.INT_LR_STS_6_C_AND_VC_4_2_C;
    static final int INT_LR_STS_7_C_AND_VC_3_7_C = Enum.INT_LR_STS_7_C_AND_VC_3_7_C;
    static final int INT_LR_STS_8_C_AND_VC_3_8_C = Enum.INT_LR_STS_8_C_AND_VC_3_8_C;
    static final int INT_LR_STS_9_C_AND_VC_4_3_C = Enum.INT_LR_STS_9_C_AND_VC_4_3_C;
    static final int INT_LR_OPTICAL_CHANNEL = Enum.INT_LR_OPTICAL_CHANNEL;
    static final int INT_LR_OPTICAL_MULTIPLEX_SECTION = Enum.INT_LR_OPTICAL_MULTIPLEX_SECTION;
    static final int INT_LR_OPTICAL_SECTION = Enum.INT_LR_OPTICAL_SECTION;
    static final int INT_LR_OPTICAL_TRANSMISSION_SECTION = Enum.INT_LR_OPTICAL_TRANSMISSION_SECTION;
    static final int INT_LR_PHYSICAL_ELECTRICAL_2 = Enum.INT_LR_PHYSICAL_ELECTRICAL_2;
    static final int INT_LR_PHYSICAL_MEDIALESS = Enum.INT_LR_PHYSICAL_MEDIALESS;
    static final int INT_LR_PHYSICAL_OPTICAL = Enum.INT_LR_PHYSICAL_OPTICAL;
    static final int INT_LR_POTS = Enum.INT_LR_POTS;
    static final int INT_LR_SECTION_OC_1_STS_1_AND_RS_STM_0 = Enum.INT_LR_SECTION_OC_1_STS_1_AND_RS_STM_0;
    static final int INT_LR_SECTION_OC_3_STS_3_AND_RS_STM_1 = Enum.INT_LR_SECTION_OC_3_STS_3_AND_RS_STM_1;
    static final int INT_LR_SECTION_OC_12_STS_12_AND_RS_STM_4 = Enum.INT_LR_SECTION_OC_12_STS_12_AND_RS_STM_4;
    static final int INT_LR_SECTION_OC_24_STS_24_AND_RS_STM_8 = Enum.INT_LR_SECTION_OC_24_STS_24_AND_RS_STM_8;
    static final int INT_LR_SECTION_OC_48_STS_48_AND_RS_STM_16 = Enum.INT_LR_SECTION_OC_48_STS_48_AND_RS_STM_16;
    static final int INT_LR_SECTION_OC_192_STS_192_AND_RS_STM_64 = Enum.INT_LR_SECTION_OC_192_STS_192_AND_RS_STM_64;
    static final int INT_LR_SECTION_OC_768_STS_768_AND_RS_STM_256 = Enum.INT_LR_SECTION_OC_768_STS_768_AND_RS_STM_256;
    static final int INT_LR_STS_1_AND_AU_3_HIGH_ORDER_VC_3 = Enum.INT_LR_STS_1_AND_AU_3_HIGH_ORDER_VC_3;
    static final int INT_LR_STS_2_C_AND_VC_3_2_C = Enum.INT_LR_STS_2_C_AND_VC_3_2_C;
    static final int INT_LR_STS_10_C_AND_VC_3_10_C = Enum.INT_LR_STS_10_C_AND_VC_3_10_C;
    static final int INT_LR_STS_11_C_AND_VC_3_11_C = Enum.INT_LR_STS_11_C_AND_VC_3_11_C;
    static final int INT_LR_STS_12_C_AND_VC_4_4_C = Enum.INT_LR_STS_12_C_AND_VC_4_4_C;
    static final int INT_LR_STS_13_C_AND_VC_3_13_C = Enum.INT_LR_STS_13_C_AND_VC_3_13_C;
    static final int INT_LR_STS_14_C_AND_VC_3_14_C = Enum.INT_LR_STS_14_C_AND_VC_3_14_C;
    static final int INT_LR_STS_15_C_AND_VC_4_5_C = Enum.INT_LR_STS_15_C_AND_VC_4_5_C;
    static final int INT_LR_STS_16_C_AND_VC_3_16_C = Enum.INT_LR_STS_16_C_AND_VC_3_16_C;
    static final int INT_LR_STS_17_C_AND_VC_3_17_C = Enum.INT_LR_STS_17_C_AND_VC_3_17_C;
    static final int INT_LR_STS_18_C_AND_VC_4_6_C = Enum.INT_LR_STS_18_C_AND_VC_4_6_C;
    static final int INT_LR_STS_19_C_AND_VC_3_19_C = Enum.INT_LR_STS_19_C_AND_VC_3_19_C;
    static final int INT_LR_STS_20_C_AND_VC_3_20_C = Enum.INT_LR_STS_20_C_AND_VC_3_20_C;
    static final int INT_LR_STS_21_C_AND_VC_4_7_C = Enum.INT_LR_STS_21_C_AND_VC_4_7_C;
    static final int INT_LR_STS_22_C_AND_VC_3_22_C = Enum.INT_LR_STS_22_C_AND_VC_3_22_C;
    static final int INT_LR_STS_23_C_AND_VC_3_23_C = Enum.INT_LR_STS_23_C_AND_VC_3_23_C;
    static final int INT_LR_STS_24_C_AND_VC_4_8_C = Enum.INT_LR_STS_24_C_AND_VC_4_8_C;
    static final int INT_LR_STS_25_C_AND_VC_3_25_C = Enum.INT_LR_STS_25_C_AND_VC_3_25_C;
    static final int INT_LR_STS_26_C_AND_VC_3_26_C = Enum.INT_LR_STS_26_C_AND_VC_3_26_C;
    static final int INT_LR_STS_27_C_AND_VC_4_9_C = Enum.INT_LR_STS_27_C_AND_VC_4_9_C;
    static final int INT_LR_STS_28_C_AND_VC_3_28_C = Enum.INT_LR_STS_28_C_AND_VC_3_28_C;
    static final int INT_LR_STS_29_C_AND_VC_3_29_C = Enum.INT_LR_STS_29_C_AND_VC_3_29_C;
    static final int INT_LR_STS_30_C_AND_VC_4_10_C = Enum.INT_LR_STS_30_C_AND_VC_4_10_C;
    static final int INT_LR_STS_31_C_AND_VC_3_31_C = Enum.INT_LR_STS_31_C_AND_VC_3_31_C;
    static final int INT_LR_STS_32_C_AND_VC_3_32_C = Enum.INT_LR_STS_32_C_AND_VC_3_32_C;
    static final int INT_LR_STS_33_C_AND_VC_4_11_C = Enum.INT_LR_STS_33_C_AND_VC_4_11_C;
    static final int INT_LR_STS_34_C_AND_VC_3_34_C = Enum.INT_LR_STS_34_C_AND_VC_3_34_C;
    static final int INT_LR_STS_35_C_AND_VC_3_35_C = Enum.INT_LR_STS_35_C_AND_VC_3_35_C;
    static final int INT_LR_STS_36_C_AND_VC_4_12_C = Enum.INT_LR_STS_36_C_AND_VC_4_12_C;
    static final int INT_LR_STS_37_C_AND_VC_3_37_C = Enum.INT_LR_STS_37_C_AND_VC_3_37_C;
    static final int INT_LR_STS_38_C_AND_VC_3_38_C = Enum.INT_LR_STS_38_C_AND_VC_3_38_C;
    static final int INT_LR_STS_39_C_AND_VC_4_13_C = Enum.INT_LR_STS_39_C_AND_VC_4_13_C;
    static final int INT_LR_STS_40_C_AND_VC_3_40_C = Enum.INT_LR_STS_40_C_AND_VC_3_40_C;
    static final int INT_LR_STS_41_C_AND_VC_3_41_C = Enum.INT_LR_STS_41_C_AND_VC_3_41_C;
    static final int INT_LR_STS_42_C_AND_VC_4_14_C = Enum.INT_LR_STS_42_C_AND_VC_4_14_C;
    static final int INT_LR_STS_43_C_AND_VC_3_43_C = Enum.INT_LR_STS_43_C_AND_VC_3_43_C;
    static final int INT_LR_STS_44_C_AND_VC_3_44_C = Enum.INT_LR_STS_44_C_AND_VC_3_44_C;
    static final int INT_LR_STS_45_C_AND_VC_4_15_C = Enum.INT_LR_STS_45_C_AND_VC_4_15_C;
    static final int INT_LR_STS_46_C_AND_VC_3_46_C = Enum.INT_LR_STS_46_C_AND_VC_3_46_C;
    static final int INT_LR_STS_47_C_AND_VC_3_47_C = Enum.INT_LR_STS_47_C_AND_VC_3_47_C;
    static final int INT_LR_STS_48_C_AND_VC_4_16_C = Enum.INT_LR_STS_48_C_AND_VC_4_16_C;
    static final int INT_LR_STS_49_C_AND_VC_3_49_C = Enum.INT_LR_STS_49_C_AND_VC_3_49_C;
    static final int INT_LR_STS_50_C_AND_VC_3_50_C = Enum.INT_LR_STS_50_C_AND_VC_3_50_C;
    static final int INT_LR_STS_51_C_AND_VC_4_17_C = Enum.INT_LR_STS_51_C_AND_VC_4_17_C;
    static final int INT_LR_STS_52_C_AND_VC_3_52_C = Enum.INT_LR_STS_52_C_AND_VC_3_52_C;
    static final int INT_LR_STS_53_C_AND_VC_3_53_C = Enum.INT_LR_STS_53_C_AND_VC_3_53_C;
    static final int INT_LR_STS_54_C_AND_VC_4_18_C = Enum.INT_LR_STS_54_C_AND_VC_4_18_C;
    static final int INT_LR_STS_55_C_AND_VC_3_55_C = Enum.INT_LR_STS_55_C_AND_VC_3_55_C;
    static final int INT_LR_STS_56_C_AND_VC_3_56_C = Enum.INT_LR_STS_56_C_AND_VC_3_56_C;
    static final int INT_LR_STS_57_C_AND_VC_4_19_C = Enum.INT_LR_STS_57_C_AND_VC_4_19_C;
    static final int INT_LR_STS_58_C_AND_VC_3_58_C = Enum.INT_LR_STS_58_C_AND_VC_3_58_C;
    static final int INT_LR_STS_59_C_AND_VC_3_59_C = Enum.INT_LR_STS_59_C_AND_VC_3_59_C;
    static final int INT_LR_STS_60_C_AND_VC_4_20_C = Enum.INT_LR_STS_60_C_AND_VC_4_20_C;
    static final int INT_LR_STS_61_C_AND_VC_3_61_C = Enum.INT_LR_STS_61_C_AND_VC_3_61_C;
    static final int INT_LR_STS_62_C_AND_VC_3_62_C = Enum.INT_LR_STS_62_C_AND_VC_3_62_C;
    static final int INT_LR_STS_63_C_AND_VC_4_21_C = Enum.INT_LR_STS_63_C_AND_VC_4_21_C;
    static final int INT_LR_STS_64_C_AND_VC_3_64_C = Enum.INT_LR_STS_64_C_AND_VC_3_64_C;
    static final int INT_LR_STS_65_C_AND_VC_3_65_C = Enum.INT_LR_STS_65_C_AND_VC_3_65_C;
    static final int INT_LR_STS_66_C_AND_VC_4_22_C = Enum.INT_LR_STS_66_C_AND_VC_4_22_C;
    static final int INT_LR_STS_67_C_AND_VC_3_67_C = Enum.INT_LR_STS_67_C_AND_VC_3_67_C;
    static final int INT_LR_STS_68_C_AND_VC_3_68_C = Enum.INT_LR_STS_68_C_AND_VC_3_68_C;
    static final int INT_LR_STS_69_C_AND_VC_4_23_C = Enum.INT_LR_STS_69_C_AND_VC_4_23_C;
    static final int INT_LR_STS_70_C_AND_VC_3_70_C = Enum.INT_LR_STS_70_C_AND_VC_3_70_C;
    static final int INT_LR_STS_71_C_AND_VC_3_71_C = Enum.INT_LR_STS_71_C_AND_VC_3_71_C;
    static final int INT_LR_STS_72_C_AND_VC_4_24_C = Enum.INT_LR_STS_72_C_AND_VC_4_24_C;
    static final int INT_LR_STS_73_C_AND_VC_3_73_C = Enum.INT_LR_STS_73_C_AND_VC_3_73_C;
    static final int INT_LR_STS_74_C_AND_VC_3_74_C = Enum.INT_LR_STS_74_C_AND_VC_3_74_C;
    static final int INT_LR_STS_75_C_AND_VC_4_25_C = Enum.INT_LR_STS_75_C_AND_VC_4_25_C;
    static final int INT_LR_STS_76_C_AND_VC_3_76_C = Enum.INT_LR_STS_76_C_AND_VC_3_76_C;
    static final int INT_LR_STS_77_C_AND_VC_3_77_C = Enum.INT_LR_STS_77_C_AND_VC_3_77_C;
    static final int INT_LR_STS_78_C_AND_VC_4_26_C = Enum.INT_LR_STS_78_C_AND_VC_4_26_C;
    static final int INT_LR_STS_79_C_AND_VC_3_79_C = Enum.INT_LR_STS_79_C_AND_VC_3_79_C;
    static final int INT_LR_STS_80_C_AND_VC_3_80_C = Enum.INT_LR_STS_80_C_AND_VC_3_80_C;
    static final int INT_LR_STS_81_C_AND_VC_4_27_C = Enum.INT_LR_STS_81_C_AND_VC_4_27_C;
    static final int INT_LR_STS_82_C_AND_VC_3_82_C = Enum.INT_LR_STS_82_C_AND_VC_3_82_C;
    static final int INT_LR_STS_83_C_AND_VC_3_83_C = Enum.INT_LR_STS_83_C_AND_VC_3_83_C;
    static final int INT_LR_STS_84_C_AND_VC_4_28_C = Enum.INT_LR_STS_84_C_AND_VC_4_28_C;
    static final int INT_LR_STS_85_C_AND_VC_3_85_C = Enum.INT_LR_STS_85_C_AND_VC_3_85_C;
    static final int INT_LR_STS_86_C_AND_VC_3_86_C = Enum.INT_LR_STS_86_C_AND_VC_3_86_C;
    static final int INT_LR_STS_87_C_AND_VC_4_29_C = Enum.INT_LR_STS_87_C_AND_VC_4_29_C;
    static final int INT_LR_STS_88_C_AND_VC_3_88_C = Enum.INT_LR_STS_88_C_AND_VC_3_88_C;
    static final int INT_LR_STS_89_C_AND_VC_3_89_C = Enum.INT_LR_STS_89_C_AND_VC_3_89_C;
    static final int INT_LR_STS_90_C_AND_VC_4_30_C = Enum.INT_LR_STS_90_C_AND_VC_4_30_C;
    static final int INT_LR_STS_91_C_AND_VC_3_91_C = Enum.INT_LR_STS_91_C_AND_VC_3_91_C;
    static final int INT_LR_STS_92_C_AND_VC_3_92_C = Enum.INT_LR_STS_92_C_AND_VC_3_92_C;
    static final int INT_LR_STS_93_C_AND_VC_4_31_C = Enum.INT_LR_STS_93_C_AND_VC_4_31_C;
    static final int INT_LR_STS_94_C_AND_VC_3_94_C = Enum.INT_LR_STS_94_C_AND_VC_3_94_C;
    static final int INT_LR_STS_95_C_AND_VC_3_95_C = Enum.INT_LR_STS_95_C_AND_VC_3_95_C;
    static final int INT_LR_STS_96_C_AND_VC_4_32_C = Enum.INT_LR_STS_96_C_AND_VC_4_32_C;
    static final int INT_LR_STS_97_C_AND_VC_3_97_C = Enum.INT_LR_STS_97_C_AND_VC_3_97_C;
    static final int INT_LR_STS_98_C_AND_VC_3_98_C = Enum.INT_LR_STS_98_C_AND_VC_3_98_C;
    static final int INT_LR_STS_99_C_AND_VC_4_33_C = Enum.INT_LR_STS_99_C_AND_VC_4_33_C;
    static final int INT_LR_STS_100_C_AND_VC_3_100_C = Enum.INT_LR_STS_100_C_AND_VC_3_100_C;
    static final int INT_LR_STS_101_C_AND_VC_3_101_C = Enum.INT_LR_STS_101_C_AND_VC_3_101_C;
    static final int INT_LR_STS_102_C_AND_VC_4_34_C = Enum.INT_LR_STS_102_C_AND_VC_4_34_C;
    static final int INT_LR_STS_103_C_AND_VC_3_103_C = Enum.INT_LR_STS_103_C_AND_VC_3_103_C;
    static final int INT_LR_STS_104_C_AND_VC_3_104_C = Enum.INT_LR_STS_104_C_AND_VC_3_104_C;
    static final int INT_LR_STS_105_C_AND_VC_4_35_C = Enum.INT_LR_STS_105_C_AND_VC_4_35_C;
    static final int INT_LR_STS_106_C_AND_VC_3_106_C = Enum.INT_LR_STS_106_C_AND_VC_3_106_C;
    static final int INT_LR_STS_107_C_AND_VC_3_107_C = Enum.INT_LR_STS_107_C_AND_VC_3_107_C;
    static final int INT_LR_STS_108_C_AND_VC_4_36_C = Enum.INT_LR_STS_108_C_AND_VC_4_36_C;
    static final int INT_LR_STS_109_C_AND_VC_3_109_C = Enum.INT_LR_STS_109_C_AND_VC_3_109_C;
    static final int INT_LR_STS_110_C_AND_VC_3_110_C = Enum.INT_LR_STS_110_C_AND_VC_3_110_C;
    static final int INT_LR_STS_111_C_AND_VC_4_37_C = Enum.INT_LR_STS_111_C_AND_VC_4_37_C;
    static final int INT_LR_STS_112_C_AND_VC_3_112_C = Enum.INT_LR_STS_112_C_AND_VC_3_112_C;
    static final int INT_LR_STS_113_C_AND_VC_3_113_C = Enum.INT_LR_STS_113_C_AND_VC_3_113_C;
    static final int INT_LR_STS_114_C_AND_VC_4_38_C = Enum.INT_LR_STS_114_C_AND_VC_4_38_C;
    static final int INT_LR_STS_115_C_AND_VC_3_115_C = Enum.INT_LR_STS_115_C_AND_VC_3_115_C;
    static final int INT_LR_STS_116_C_AND_VC_3_116_C = Enum.INT_LR_STS_116_C_AND_VC_3_116_C;
    static final int INT_LR_STS_117_C_AND_VC_4_39_C = Enum.INT_LR_STS_117_C_AND_VC_4_39_C;
    static final int INT_LR_STS_118_C_AND_VC_3_118_C = Enum.INT_LR_STS_118_C_AND_VC_3_118_C;
    static final int INT_LR_STS_119_C_AND_VC_3_119_C = Enum.INT_LR_STS_119_C_AND_VC_3_119_C;
    static final int INT_LR_STS_120_C_AND_VC_4_40_C = Enum.INT_LR_STS_120_C_AND_VC_4_40_C;
    static final int INT_LR_STS_121_C_AND_VC_3_121_C = Enum.INT_LR_STS_121_C_AND_VC_3_121_C;
    static final int INT_LR_STS_122_C_AND_VC_3_122_C = Enum.INT_LR_STS_122_C_AND_VC_3_122_C;
    static final int INT_LR_STS_123_C_AND_VC_4_41_C = Enum.INT_LR_STS_123_C_AND_VC_4_41_C;
    static final int INT_LR_STS_124_C_AND_VC_3_124_C = Enum.INT_LR_STS_124_C_AND_VC_3_124_C;
    static final int INT_LR_STS_125_C_AND_VC_3_125_C = Enum.INT_LR_STS_125_C_AND_VC_3_125_C;
    static final int INT_LR_STS_126_C_AND_VC_4_42_C = Enum.INT_LR_STS_126_C_AND_VC_4_42_C;
    static final int INT_LR_STS_127_C_AND_VC_3_127_C = Enum.INT_LR_STS_127_C_AND_VC_3_127_C;
    static final int INT_LR_STS_128_C_AND_VC_3_128_C = Enum.INT_LR_STS_128_C_AND_VC_3_128_C;
    static final int INT_LR_STS_129_C_AND_VC_4_43_C = Enum.INT_LR_STS_129_C_AND_VC_4_43_C;
    static final int INT_LR_STS_130_C_AND_VC_3_130_C = Enum.INT_LR_STS_130_C_AND_VC_3_130_C;
    static final int INT_LR_STS_131_C_AND_VC_3_131_C = Enum.INT_LR_STS_131_C_AND_VC_3_131_C;
    static final int INT_LR_STS_132_C_AND_VC_4_44_C = Enum.INT_LR_STS_132_C_AND_VC_4_44_C;
    static final int INT_LR_STS_133_C_AND_VC_3_133_C = Enum.INT_LR_STS_133_C_AND_VC_3_133_C;
    static final int INT_LR_STS_134_C_AND_VC_3_134_C = Enum.INT_LR_STS_134_C_AND_VC_3_134_C;
    static final int INT_LR_STS_135_C_AND_VC_4_45_C = Enum.INT_LR_STS_135_C_AND_VC_4_45_C;
    static final int INT_LR_STS_136_C_AND_VC_3_136_C = Enum.INT_LR_STS_136_C_AND_VC_3_136_C;
    static final int INT_LR_STS_137_C_AND_VC_3_137_C = Enum.INT_LR_STS_137_C_AND_VC_3_137_C;
    static final int INT_LR_STS_138_C_AND_VC_4_46_C = Enum.INT_LR_STS_138_C_AND_VC_4_46_C;
    static final int INT_LR_STS_139_C_AND_VC_3_139_C = Enum.INT_LR_STS_139_C_AND_VC_3_139_C;
    static final int INT_LR_STS_140_C_AND_VC_3_140_C = Enum.INT_LR_STS_140_C_AND_VC_3_140_C;
    static final int INT_LR_STS_141_C_AND_VC_4_47_C = Enum.INT_LR_STS_141_C_AND_VC_4_47_C;
    static final int INT_LR_STS_142_C_AND_VC_3_142_C = Enum.INT_LR_STS_142_C_AND_VC_3_142_C;
    static final int INT_LR_STS_143_C_AND_VC_3_143_C = Enum.INT_LR_STS_143_C_AND_VC_3_143_C;
    static final int INT_LR_STS_144_C_AND_VC_4_48_C = Enum.INT_LR_STS_144_C_AND_VC_4_48_C;
    static final int INT_LR_STS_145_C_AND_VC_3_145_C = Enum.INT_LR_STS_145_C_AND_VC_3_145_C;
    static final int INT_LR_STS_146_C_AND_VC_3_146_C = Enum.INT_LR_STS_146_C_AND_VC_3_146_C;
    static final int INT_LR_STS_147_C_AND_VC_4_49_C = Enum.INT_LR_STS_147_C_AND_VC_4_49_C;
    static final int INT_LR_STS_148_C_AND_VC_3_148_C = Enum.INT_LR_STS_148_C_AND_VC_3_148_C;
    static final int INT_LR_STS_149_C_AND_VC_3_149_C = Enum.INT_LR_STS_149_C_AND_VC_3_149_C;
    static final int INT_LR_STS_150_C_AND_VC_4_50_C = Enum.INT_LR_STS_150_C_AND_VC_4_50_C;
    static final int INT_LR_STS_151_C_AND_VC_3_151_C = Enum.INT_LR_STS_151_C_AND_VC_3_151_C;
    static final int INT_LR_STS_152_C_AND_VC_3_152_C = Enum.INT_LR_STS_152_C_AND_VC_3_152_C;
    static final int INT_LR_STS_153_C_AND_VC_4_51_C = Enum.INT_LR_STS_153_C_AND_VC_4_51_C;
    static final int INT_LR_STS_154_C_AND_VC_3_154_C = Enum.INT_LR_STS_154_C_AND_VC_3_154_C;
    static final int INT_LR_STS_155_C_AND_VC_3_155_C = Enum.INT_LR_STS_155_C_AND_VC_3_155_C;
    static final int INT_LR_STS_156_C_AND_VC_4_52_C = Enum.INT_LR_STS_156_C_AND_VC_4_52_C;
    static final int INT_LR_STS_157_C_AND_VC_3_157_C = Enum.INT_LR_STS_157_C_AND_VC_3_157_C;
    static final int INT_LR_STS_158_C_AND_VC_3_158_C = Enum.INT_LR_STS_158_C_AND_VC_3_158_C;
    static final int INT_LR_STS_159_C_AND_VC_4_53_C = Enum.INT_LR_STS_159_C_AND_VC_4_53_C;
    static final int INT_LR_STS_160_C_AND_VC_3_160_C = Enum.INT_LR_STS_160_C_AND_VC_3_160_C;
    static final int INT_LR_STS_161_C_AND_VC_3_161_C = Enum.INT_LR_STS_161_C_AND_VC_3_161_C;
    static final int INT_LR_STS_162_C_AND_VC_4_54_C = Enum.INT_LR_STS_162_C_AND_VC_4_54_C;
    static final int INT_LR_STS_163_C_AND_VC_3_163_C = Enum.INT_LR_STS_163_C_AND_VC_3_163_C;
    static final int INT_LR_STS_164_C_AND_VC_3_164_C = Enum.INT_LR_STS_164_C_AND_VC_3_164_C;
    static final int INT_LR_STS_165_C_AND_VC_4_55_C = Enum.INT_LR_STS_165_C_AND_VC_4_55_C;
    static final int INT_LR_STS_166_C_AND_VC_3_166_C = Enum.INT_LR_STS_166_C_AND_VC_3_166_C;
    static final int INT_LR_STS_167_C_AND_VC_3_167_C = Enum.INT_LR_STS_167_C_AND_VC_3_167_C;
    static final int INT_LR_STS_168_C_AND_VC_4_56_C = Enum.INT_LR_STS_168_C_AND_VC_4_56_C;
    static final int INT_LR_STS_169_C_AND_VC_3_169_C = Enum.INT_LR_STS_169_C_AND_VC_3_169_C;
    static final int INT_LR_STS_170_C_AND_VC_3_170_C = Enum.INT_LR_STS_170_C_AND_VC_3_170_C;
    static final int INT_LR_STS_171_C_AND_VC_4_57_C = Enum.INT_LR_STS_171_C_AND_VC_4_57_C;
    static final int INT_LR_STS_172_C_AND_VC_3_172_C = Enum.INT_LR_STS_172_C_AND_VC_3_172_C;
    static final int INT_LR_STS_173_C_AND_VC_3_173_C = Enum.INT_LR_STS_173_C_AND_VC_3_173_C;
    static final int INT_LR_STS_174_C_AND_VC_4_58_C = Enum.INT_LR_STS_174_C_AND_VC_4_58_C;
    static final int INT_LR_STS_175_C_AND_VC_3_175_C = Enum.INT_LR_STS_175_C_AND_VC_3_175_C;
    static final int INT_LR_STS_176_C_AND_VC_3_176_C = Enum.INT_LR_STS_176_C_AND_VC_3_176_C;
    static final int INT_LR_STS_177_C_AND_VC_4_59_C = Enum.INT_LR_STS_177_C_AND_VC_4_59_C;
    static final int INT_LR_STS_178_C_AND_VC_3_178_C = Enum.INT_LR_STS_178_C_AND_VC_3_178_C;
    static final int INT_LR_STS_179_C_AND_VC_3_179_C = Enum.INT_LR_STS_179_C_AND_VC_3_179_C;
    static final int INT_LR_STS_180_C_AND_VC_4_60_C = Enum.INT_LR_STS_180_C_AND_VC_4_60_C;
    static final int INT_LR_STS_181_C_AND_VC_3_181_C = Enum.INT_LR_STS_181_C_AND_VC_3_181_C;
    static final int INT_LR_STS_182_C_AND_VC_3_182_C = Enum.INT_LR_STS_182_C_AND_VC_3_182_C;
    static final int INT_LR_STS_183_C_AND_VC_4_61_C = Enum.INT_LR_STS_183_C_AND_VC_4_61_C;
    static final int INT_LR_STS_184_C_AND_VC_3_184_C = Enum.INT_LR_STS_184_C_AND_VC_3_184_C;
    static final int INT_LR_STS_185_C_AND_VC_3_185_C = Enum.INT_LR_STS_185_C_AND_VC_3_185_C;
    static final int INT_LR_STS_186_C_AND_VC_4_62_C = Enum.INT_LR_STS_186_C_AND_VC_4_62_C;
    static final int INT_LR_STS_187_C_AND_VC_3_187_C = Enum.INT_LR_STS_187_C_AND_VC_3_187_C;
    static final int INT_LR_STS_188_C_AND_VC_3_188_C = Enum.INT_LR_STS_188_C_AND_VC_3_188_C;
    static final int INT_LR_STS_189_C_AND_VC_4_63_C = Enum.INT_LR_STS_189_C_AND_VC_4_63_C;
    static final int INT_LR_STS_190_C_AND_VC_3_190_C = Enum.INT_LR_STS_190_C_AND_VC_3_190_C;
    static final int INT_LR_STS_191_C_AND_VC_3_191_C = Enum.INT_LR_STS_191_C_AND_VC_3_191_C;
    static final int INT_LR_STS_192_C_AND_VC_4_64_C = Enum.INT_LR_STS_192_C_AND_VC_4_64_C;
    static final int INT_LR_STS_768_C_AND_VC_4_256_C = Enum.INT_LR_STS_768_C_AND_VC_4_256_C;
    static final int INT_LR_T_1_AND_DS_1_1_5_M = Enum.INT_LR_T_1_AND_DS_1_1_5_M;
    static final int INT_LR_T_2_AND_DS_2_6_M = Enum.INT_LR_T_2_AND_DS_2_6_M;
    static final int INT_LR_T_3_AND_DS_3_45_M = Enum.INT_LR_T_3_AND_DS_3_45_M;
    static final int INT_LR_VT_1_5_AND_TU_11_VC_11 = Enum.INT_LR_VT_1_5_AND_TU_11_VC_11;
    static final int INT_LR_VT_2_AND_TU_12_VC_12 = Enum.INT_LR_VT_2_AND_TU_12_VC_12;
    static final int INT_LR_VT_6_AND_TU_2_VC_2 = Enum.INT_LR_VT_6_AND_TU_2_VC_2;
    
    /**
     * Enumeration value class for org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType.
     * These enum values can be used as follows:
     * <pre>
     * enum.toString(); // returns the string value of the enum
     * enum.intValue(); // returns an int value, useful for switches
     * // e.g., case Enum.INT_VENDOR_EXT
     * Enum.forString(s); // returns the enum value for a string
     * Enum.forInt(i); // returns the enum value for an int
     * </pre>
     * Enumeration objects are immutable singleton objects that
     * can be compared using == object equality. They have no
     * public constructor. See the constants defined within this
     * class for all the valid values.
     */
    static final class Enum extends org.apache.xmlbeans.StringEnumAbstractBase
    {
        /**
         * Returns the enum value for a string, or null if none.
         */
        public static Enum forString(java.lang.String s)
            { return (Enum)table.forString(s); }
        /**
         * Returns the enum value corresponding to an int, or null if none.
         */
        public static Enum forInt(int i)
            { return (Enum)table.forInt(i); }
        
        private Enum(java.lang.String s, int i)
            { super(s, i); }
        
        static final int INT_VENDOR_EXT = 1;
        static final int INT_MINOR_EXT = 2;
        static final int INT_LR_DS_0_64_K = 3;
        static final int INT_LR_DSL = 4;
        static final int INT_LR_NOT_APPLICABLE = 5;
        static final int INT_LR_ASYNC_FOTS_150_M = 6;
        static final int INT_LR_ASYNC_FOTS_417_M = 7;
        static final int INT_LR_ASYNC_FOTS_560_M = 8;
        static final int INT_LR_ASYNC_FOTS_565_M = 9;
        static final int INT_LR_ASYNC_FOTS_1130_M = 10;
        static final int INT_LR_ASYNC_FOTS_1_G_7 = 11;
        static final int INT_LR_ASYNC_FOTS_1_G_8 = 12;
        static final int INT_LR_ATM_NI = 13;
        static final int INT_LR_ATM_VC = 14;
        static final int INT_LR_ATM_VP = 15;
        static final int INT_LR_D_1_VIDEO = 16;
        static final int INT_LR_DIGITAL_SIGNAL_RATE = 17;
        static final int INT_LR_PHYSICAL_ELECTRICAL = 18;
        static final int INT_LR_DSR_1_5_M = 19;
        static final int INT_LR_DSR_2_M = 20;
        static final int INT_LR_DSR_4_M = 21;
        static final int INT_LR_DSR_6_M = 22;
        static final int INT_LR_DSR_8_M = 23;
        static final int INT_LR_DSR_16_M = 24;
        static final int INT_LR_DSR_34_M = 25;
        static final int INT_LR_E_2_8_M = 26;
        static final int INT_LR_E_5_565_M = 27;
        static final int INT_LR_ENCAPSULATION = 28;
        static final int INT_LR_FRAGMENT = 29;
        static final int INT_LR_DSR_45_M = 30;
        static final int INT_LR_DSR_140_M = 31;
        static final int INT_LR_DSR_565_M = 32;
        static final int INT_LR_DSR_FAST_ETHERNET = 33;
        static final int INT_LR_DSR_GIGABIT_ETHERNET = 34;
        static final int INT_LR_DSR_10_GIGABIT_ETHERNET = 35;
        static final int INT_LR_DSR_OC_1_STM_0 = 36;
        static final int INT_LR_DSR_OC_3_STM_1 = 37;
        static final int INT_LR_DSR_2_X_STM_1 = 38;
        static final int INT_LR_DSR_OC_12_STM_4 = 39;
        static final int INT_LR_DSR_OC_24_STM_8 = 40;
        static final int INT_LR_DSR_OC_48_AND_STM_16 = 41;
        static final int INT_LR_DSR_OC_192_AND_STM_64 = 42;
        static final int INT_LR_DSR_OC_768_AND_STM_256 = 43;
        static final int INT_LR_DSR_OTU_1 = 44;
        static final int INT_LR_DSR_OTU_2 = 45;
        static final int INT_LR_DSR_OTU_3 = 46;
        static final int INT_LR_E_1_2_M = 47;
        static final int INT_LR_E_20_2_X_2_M = 48;
        static final int INT_LR_E_30_8_X_2_M = 49;
        static final int INT_LR_E_3_34_M = 50;
        static final int INT_LR_E_4_140_M = 51;
        static final int INT_LR_ESCON = 52;
        static final int INT_LR_ETHERNET = 53;
        static final int INT_LR_ETR = 54;
        static final int INT_LR_FAST_ETHERNET = 55;
        static final int INT_LR_FC_12_133_M = 56;
        static final int INT_LR_FC_25_266_M = 57;
        static final int INT_LR_FC_50_531_M = 58;
        static final int INT_LR_FC_100_1063_M = 59;
        static final int INT_LR_FDDI = 60;
        static final int INT_LR_FICON = 61;
        static final int INT_LR_FR_IF = 62;
        static final int INT_LR_FR_PVC = 63;
        static final int INT_LR_GIGABIT_ETHERNET = 64;
        static final int INT_LR_ISDN_BRI = 65;
        static final int INT_LR_LINE_OC_1_STS_1_AND_MS_STM_0 = 66;
        static final int INT_LR_LINE_OC_3_STS_3_AND_MS_STM_1 = 67;
        static final int INT_LR_LINE_OC_12_STS_12_AND_MS_STM_4 = 68;
        static final int INT_LR_LINE_OC_24_STS_24_AND_MS_STM_8 = 69;
        static final int INT_LR_LINE_OC_48_STS_48_AND_MS_STM_16 = 70;
        static final int INT_LR_LINE_OC_192_STS_192_AND_MS_STM_64 = 71;
        static final int INT_LR_LINE_OC_768_STS_768_AND_MS_STM_256 = 72;
        static final int INT_LR_LOW_ORDER_TU_3_VC_3 = 73;
        static final int INT_LR_OCH_DATA_UNIT_1 = 74;
        static final int INT_LR_OCH_DATA_UNIT_2 = 75;
        static final int INT_LR_OCH_DATA_UNIT_3 = 76;
        static final int INT_LR_OCH_TRANSPORT_UNIT_1 = 77;
        static final int INT_LR_OCH_TRANSPORT_UNIT_2 = 78;
        static final int INT_LR_OCH_TRANSPORT_UNIT_3 = 79;
        static final int INT_LR_STS_3_C_AND_AU_4_VC_4 = 80;
        static final int INT_LR_STS_4_C_AND_VC_3_4_C = 81;
        static final int INT_LR_STS_5_C_AND_VC_3_5_C = 82;
        static final int INT_LR_STS_6_C_AND_VC_4_2_C = 83;
        static final int INT_LR_STS_7_C_AND_VC_3_7_C = 84;
        static final int INT_LR_STS_8_C_AND_VC_3_8_C = 85;
        static final int INT_LR_STS_9_C_AND_VC_4_3_C = 86;
        static final int INT_LR_OPTICAL_CHANNEL = 87;
        static final int INT_LR_OPTICAL_MULTIPLEX_SECTION = 88;
        static final int INT_LR_OPTICAL_SECTION = 89;
        static final int INT_LR_OPTICAL_TRANSMISSION_SECTION = 90;
        static final int INT_LR_PHYSICAL_ELECTRICAL_2 = 91;
        static final int INT_LR_PHYSICAL_MEDIALESS = 92;
        static final int INT_LR_PHYSICAL_OPTICAL = 93;
        static final int INT_LR_POTS = 94;
        static final int INT_LR_SECTION_OC_1_STS_1_AND_RS_STM_0 = 95;
        static final int INT_LR_SECTION_OC_3_STS_3_AND_RS_STM_1 = 96;
        static final int INT_LR_SECTION_OC_12_STS_12_AND_RS_STM_4 = 97;
        static final int INT_LR_SECTION_OC_24_STS_24_AND_RS_STM_8 = 98;
        static final int INT_LR_SECTION_OC_48_STS_48_AND_RS_STM_16 = 99;
        static final int INT_LR_SECTION_OC_192_STS_192_AND_RS_STM_64 = 100;
        static final int INT_LR_SECTION_OC_768_STS_768_AND_RS_STM_256 = 101;
        static final int INT_LR_STS_1_AND_AU_3_HIGH_ORDER_VC_3 = 102;
        static final int INT_LR_STS_2_C_AND_VC_3_2_C = 103;
        static final int INT_LR_STS_10_C_AND_VC_3_10_C = 104;
        static final int INT_LR_STS_11_C_AND_VC_3_11_C = 105;
        static final int INT_LR_STS_12_C_AND_VC_4_4_C = 106;
        static final int INT_LR_STS_13_C_AND_VC_3_13_C = 107;
        static final int INT_LR_STS_14_C_AND_VC_3_14_C = 108;
        static final int INT_LR_STS_15_C_AND_VC_4_5_C = 109;
        static final int INT_LR_STS_16_C_AND_VC_3_16_C = 110;
        static final int INT_LR_STS_17_C_AND_VC_3_17_C = 111;
        static final int INT_LR_STS_18_C_AND_VC_4_6_C = 112;
        static final int INT_LR_STS_19_C_AND_VC_3_19_C = 113;
        static final int INT_LR_STS_20_C_AND_VC_3_20_C = 114;
        static final int INT_LR_STS_21_C_AND_VC_4_7_C = 115;
        static final int INT_LR_STS_22_C_AND_VC_3_22_C = 116;
        static final int INT_LR_STS_23_C_AND_VC_3_23_C = 117;
        static final int INT_LR_STS_24_C_AND_VC_4_8_C = 118;
        static final int INT_LR_STS_25_C_AND_VC_3_25_C = 119;
        static final int INT_LR_STS_26_C_AND_VC_3_26_C = 120;
        static final int INT_LR_STS_27_C_AND_VC_4_9_C = 121;
        static final int INT_LR_STS_28_C_AND_VC_3_28_C = 122;
        static final int INT_LR_STS_29_C_AND_VC_3_29_C = 123;
        static final int INT_LR_STS_30_C_AND_VC_4_10_C = 124;
        static final int INT_LR_STS_31_C_AND_VC_3_31_C = 125;
        static final int INT_LR_STS_32_C_AND_VC_3_32_C = 126;
        static final int INT_LR_STS_33_C_AND_VC_4_11_C = 127;
        static final int INT_LR_STS_34_C_AND_VC_3_34_C = 128;
        static final int INT_LR_STS_35_C_AND_VC_3_35_C = 129;
        static final int INT_LR_STS_36_C_AND_VC_4_12_C = 130;
        static final int INT_LR_STS_37_C_AND_VC_3_37_C = 131;
        static final int INT_LR_STS_38_C_AND_VC_3_38_C = 132;
        static final int INT_LR_STS_39_C_AND_VC_4_13_C = 133;
        static final int INT_LR_STS_40_C_AND_VC_3_40_C = 134;
        static final int INT_LR_STS_41_C_AND_VC_3_41_C = 135;
        static final int INT_LR_STS_42_C_AND_VC_4_14_C = 136;
        static final int INT_LR_STS_43_C_AND_VC_3_43_C = 137;
        static final int INT_LR_STS_44_C_AND_VC_3_44_C = 138;
        static final int INT_LR_STS_45_C_AND_VC_4_15_C = 139;
        static final int INT_LR_STS_46_C_AND_VC_3_46_C = 140;
        static final int INT_LR_STS_47_C_AND_VC_3_47_C = 141;
        static final int INT_LR_STS_48_C_AND_VC_4_16_C = 142;
        static final int INT_LR_STS_49_C_AND_VC_3_49_C = 143;
        static final int INT_LR_STS_50_C_AND_VC_3_50_C = 144;
        static final int INT_LR_STS_51_C_AND_VC_4_17_C = 145;
        static final int INT_LR_STS_52_C_AND_VC_3_52_C = 146;
        static final int INT_LR_STS_53_C_AND_VC_3_53_C = 147;
        static final int INT_LR_STS_54_C_AND_VC_4_18_C = 148;
        static final int INT_LR_STS_55_C_AND_VC_3_55_C = 149;
        static final int INT_LR_STS_56_C_AND_VC_3_56_C = 150;
        static final int INT_LR_STS_57_C_AND_VC_4_19_C = 151;
        static final int INT_LR_STS_58_C_AND_VC_3_58_C = 152;
        static final int INT_LR_STS_59_C_AND_VC_3_59_C = 153;
        static final int INT_LR_STS_60_C_AND_VC_4_20_C = 154;
        static final int INT_LR_STS_61_C_AND_VC_3_61_C = 155;
        static final int INT_LR_STS_62_C_AND_VC_3_62_C = 156;
        static final int INT_LR_STS_63_C_AND_VC_4_21_C = 157;
        static final int INT_LR_STS_64_C_AND_VC_3_64_C = 158;
        static final int INT_LR_STS_65_C_AND_VC_3_65_C = 159;
        static final int INT_LR_STS_66_C_AND_VC_4_22_C = 160;
        static final int INT_LR_STS_67_C_AND_VC_3_67_C = 161;
        static final int INT_LR_STS_68_C_AND_VC_3_68_C = 162;
        static final int INT_LR_STS_69_C_AND_VC_4_23_C = 163;
        static final int INT_LR_STS_70_C_AND_VC_3_70_C = 164;
        static final int INT_LR_STS_71_C_AND_VC_3_71_C = 165;
        static final int INT_LR_STS_72_C_AND_VC_4_24_C = 166;
        static final int INT_LR_STS_73_C_AND_VC_3_73_C = 167;
        static final int INT_LR_STS_74_C_AND_VC_3_74_C = 168;
        static final int INT_LR_STS_75_C_AND_VC_4_25_C = 169;
        static final int INT_LR_STS_76_C_AND_VC_3_76_C = 170;
        static final int INT_LR_STS_77_C_AND_VC_3_77_C = 171;
        static final int INT_LR_STS_78_C_AND_VC_4_26_C = 172;
        static final int INT_LR_STS_79_C_AND_VC_3_79_C = 173;
        static final int INT_LR_STS_80_C_AND_VC_3_80_C = 174;
        static final int INT_LR_STS_81_C_AND_VC_4_27_C = 175;
        static final int INT_LR_STS_82_C_AND_VC_3_82_C = 176;
        static final int INT_LR_STS_83_C_AND_VC_3_83_C = 177;
        static final int INT_LR_STS_84_C_AND_VC_4_28_C = 178;
        static final int INT_LR_STS_85_C_AND_VC_3_85_C = 179;
        static final int INT_LR_STS_86_C_AND_VC_3_86_C = 180;
        static final int INT_LR_STS_87_C_AND_VC_4_29_C = 181;
        static final int INT_LR_STS_88_C_AND_VC_3_88_C = 182;
        static final int INT_LR_STS_89_C_AND_VC_3_89_C = 183;
        static final int INT_LR_STS_90_C_AND_VC_4_30_C = 184;
        static final int INT_LR_STS_91_C_AND_VC_3_91_C = 185;
        static final int INT_LR_STS_92_C_AND_VC_3_92_C = 186;
        static final int INT_LR_STS_93_C_AND_VC_4_31_C = 187;
        static final int INT_LR_STS_94_C_AND_VC_3_94_C = 188;
        static final int INT_LR_STS_95_C_AND_VC_3_95_C = 189;
        static final int INT_LR_STS_96_C_AND_VC_4_32_C = 190;
        static final int INT_LR_STS_97_C_AND_VC_3_97_C = 191;
        static final int INT_LR_STS_98_C_AND_VC_3_98_C = 192;
        static final int INT_LR_STS_99_C_AND_VC_4_33_C = 193;
        static final int INT_LR_STS_100_C_AND_VC_3_100_C = 194;
        static final int INT_LR_STS_101_C_AND_VC_3_101_C = 195;
        static final int INT_LR_STS_102_C_AND_VC_4_34_C = 196;
        static final int INT_LR_STS_103_C_AND_VC_3_103_C = 197;
        static final int INT_LR_STS_104_C_AND_VC_3_104_C = 198;
        static final int INT_LR_STS_105_C_AND_VC_4_35_C = 199;
        static final int INT_LR_STS_106_C_AND_VC_3_106_C = 200;
        static final int INT_LR_STS_107_C_AND_VC_3_107_C = 201;
        static final int INT_LR_STS_108_C_AND_VC_4_36_C = 202;
        static final int INT_LR_STS_109_C_AND_VC_3_109_C = 203;
        static final int INT_LR_STS_110_C_AND_VC_3_110_C = 204;
        static final int INT_LR_STS_111_C_AND_VC_4_37_C = 205;
        static final int INT_LR_STS_112_C_AND_VC_3_112_C = 206;
        static final int INT_LR_STS_113_C_AND_VC_3_113_C = 207;
        static final int INT_LR_STS_114_C_AND_VC_4_38_C = 208;
        static final int INT_LR_STS_115_C_AND_VC_3_115_C = 209;
        static final int INT_LR_STS_116_C_AND_VC_3_116_C = 210;
        static final int INT_LR_STS_117_C_AND_VC_4_39_C = 211;
        static final int INT_LR_STS_118_C_AND_VC_3_118_C = 212;
        static final int INT_LR_STS_119_C_AND_VC_3_119_C = 213;
        static final int INT_LR_STS_120_C_AND_VC_4_40_C = 214;
        static final int INT_LR_STS_121_C_AND_VC_3_121_C = 215;
        static final int INT_LR_STS_122_C_AND_VC_3_122_C = 216;
        static final int INT_LR_STS_123_C_AND_VC_4_41_C = 217;
        static final int INT_LR_STS_124_C_AND_VC_3_124_C = 218;
        static final int INT_LR_STS_125_C_AND_VC_3_125_C = 219;
        static final int INT_LR_STS_126_C_AND_VC_4_42_C = 220;
        static final int INT_LR_STS_127_C_AND_VC_3_127_C = 221;
        static final int INT_LR_STS_128_C_AND_VC_3_128_C = 222;
        static final int INT_LR_STS_129_C_AND_VC_4_43_C = 223;
        static final int INT_LR_STS_130_C_AND_VC_3_130_C = 224;
        static final int INT_LR_STS_131_C_AND_VC_3_131_C = 225;
        static final int INT_LR_STS_132_C_AND_VC_4_44_C = 226;
        static final int INT_LR_STS_133_C_AND_VC_3_133_C = 227;
        static final int INT_LR_STS_134_C_AND_VC_3_134_C = 228;
        static final int INT_LR_STS_135_C_AND_VC_4_45_C = 229;
        static final int INT_LR_STS_136_C_AND_VC_3_136_C = 230;
        static final int INT_LR_STS_137_C_AND_VC_3_137_C = 231;
        static final int INT_LR_STS_138_C_AND_VC_4_46_C = 232;
        static final int INT_LR_STS_139_C_AND_VC_3_139_C = 233;
        static final int INT_LR_STS_140_C_AND_VC_3_140_C = 234;
        static final int INT_LR_STS_141_C_AND_VC_4_47_C = 235;
        static final int INT_LR_STS_142_C_AND_VC_3_142_C = 236;
        static final int INT_LR_STS_143_C_AND_VC_3_143_C = 237;
        static final int INT_LR_STS_144_C_AND_VC_4_48_C = 238;
        static final int INT_LR_STS_145_C_AND_VC_3_145_C = 239;
        static final int INT_LR_STS_146_C_AND_VC_3_146_C = 240;
        static final int INT_LR_STS_147_C_AND_VC_4_49_C = 241;
        static final int INT_LR_STS_148_C_AND_VC_3_148_C = 242;
        static final int INT_LR_STS_149_C_AND_VC_3_149_C = 243;
        static final int INT_LR_STS_150_C_AND_VC_4_50_C = 244;
        static final int INT_LR_STS_151_C_AND_VC_3_151_C = 245;
        static final int INT_LR_STS_152_C_AND_VC_3_152_C = 246;
        static final int INT_LR_STS_153_C_AND_VC_4_51_C = 247;
        static final int INT_LR_STS_154_C_AND_VC_3_154_C = 248;
        static final int INT_LR_STS_155_C_AND_VC_3_155_C = 249;
        static final int INT_LR_STS_156_C_AND_VC_4_52_C = 250;
        static final int INT_LR_STS_157_C_AND_VC_3_157_C = 251;
        static final int INT_LR_STS_158_C_AND_VC_3_158_C = 252;
        static final int INT_LR_STS_159_C_AND_VC_4_53_C = 253;
        static final int INT_LR_STS_160_C_AND_VC_3_160_C = 254;
        static final int INT_LR_STS_161_C_AND_VC_3_161_C = 255;
        static final int INT_LR_STS_162_C_AND_VC_4_54_C = 256;
        static final int INT_LR_STS_163_C_AND_VC_3_163_C = 257;
        static final int INT_LR_STS_164_C_AND_VC_3_164_C = 258;
        static final int INT_LR_STS_165_C_AND_VC_4_55_C = 259;
        static final int INT_LR_STS_166_C_AND_VC_3_166_C = 260;
        static final int INT_LR_STS_167_C_AND_VC_3_167_C = 261;
        static final int INT_LR_STS_168_C_AND_VC_4_56_C = 262;
        static final int INT_LR_STS_169_C_AND_VC_3_169_C = 263;
        static final int INT_LR_STS_170_C_AND_VC_3_170_C = 264;
        static final int INT_LR_STS_171_C_AND_VC_4_57_C = 265;
        static final int INT_LR_STS_172_C_AND_VC_3_172_C = 266;
        static final int INT_LR_STS_173_C_AND_VC_3_173_C = 267;
        static final int INT_LR_STS_174_C_AND_VC_4_58_C = 268;
        static final int INT_LR_STS_175_C_AND_VC_3_175_C = 269;
        static final int INT_LR_STS_176_C_AND_VC_3_176_C = 270;
        static final int INT_LR_STS_177_C_AND_VC_4_59_C = 271;
        static final int INT_LR_STS_178_C_AND_VC_3_178_C = 272;
        static final int INT_LR_STS_179_C_AND_VC_3_179_C = 273;
        static final int INT_LR_STS_180_C_AND_VC_4_60_C = 274;
        static final int INT_LR_STS_181_C_AND_VC_3_181_C = 275;
        static final int INT_LR_STS_182_C_AND_VC_3_182_C = 276;
        static final int INT_LR_STS_183_C_AND_VC_4_61_C = 277;
        static final int INT_LR_STS_184_C_AND_VC_3_184_C = 278;
        static final int INT_LR_STS_185_C_AND_VC_3_185_C = 279;
        static final int INT_LR_STS_186_C_AND_VC_4_62_C = 280;
        static final int INT_LR_STS_187_C_AND_VC_3_187_C = 281;
        static final int INT_LR_STS_188_C_AND_VC_3_188_C = 282;
        static final int INT_LR_STS_189_C_AND_VC_4_63_C = 283;
        static final int INT_LR_STS_190_C_AND_VC_3_190_C = 284;
        static final int INT_LR_STS_191_C_AND_VC_3_191_C = 285;
        static final int INT_LR_STS_192_C_AND_VC_4_64_C = 286;
        static final int INT_LR_STS_768_C_AND_VC_4_256_C = 287;
        static final int INT_LR_T_1_AND_DS_1_1_5_M = 288;
        static final int INT_LR_T_2_AND_DS_2_6_M = 289;
        static final int INT_LR_T_3_AND_DS_3_45_M = 290;
        static final int INT_LR_VT_1_5_AND_TU_11_VC_11 = 291;
        static final int INT_LR_VT_2_AND_TU_12_VC_12 = 292;
        static final int INT_LR_VT_6_AND_TU_2_VC_2 = 293;
        
        public static final org.apache.xmlbeans.StringEnumAbstractBase.Table table =
            new org.apache.xmlbeans.StringEnumAbstractBase.Table
        (
            new Enum[]
            {
                new Enum("VENDOR_EXT", INT_VENDOR_EXT),
                new Enum("MINOR_EXT", INT_MINOR_EXT),
                new Enum("LR_DS0_64K", INT_LR_DS_0_64_K),
                new Enum("LR_DSL", INT_LR_DSL),
                new Enum("LR_Not_Applicable", INT_LR_NOT_APPLICABLE),
                new Enum("LR_Async_FOTS_150M", INT_LR_ASYNC_FOTS_150_M),
                new Enum("LR_Async_FOTS_417M", INT_LR_ASYNC_FOTS_417_M),
                new Enum("LR_Async_FOTS_560M", INT_LR_ASYNC_FOTS_560_M),
                new Enum("LR_Async_FOTS_565M", INT_LR_ASYNC_FOTS_565_M),
                new Enum("LR_Async_FOTS_1130M", INT_LR_ASYNC_FOTS_1130_M),
                new Enum("LR_Async_FOTS_1G7", INT_LR_ASYNC_FOTS_1_G_7),
                new Enum("LR_Async_FOTS_1G8", INT_LR_ASYNC_FOTS_1_G_8),
                new Enum("LR_ATM_NI", INT_LR_ATM_NI),
                new Enum("LR_ATM_VC", INT_LR_ATM_VC),
                new Enum("LR_ATM_VP", INT_LR_ATM_VP),
                new Enum("LR_D1_Video", INT_LR_D_1_VIDEO),
                new Enum("LR_DIGITAL_SIGNAL_RATE", INT_LR_DIGITAL_SIGNAL_RATE),
                new Enum("LR_PHYSICAL_ELECTRICAL.", INT_LR_PHYSICAL_ELECTRICAL),
                new Enum("LR_DSR_1_5M", INT_LR_DSR_1_5_M),
                new Enum("LR_DSR_2M", INT_LR_DSR_2_M),
                new Enum("LR_DSR_4M", INT_LR_DSR_4_M),
                new Enum("LR_DSR_6M", INT_LR_DSR_6_M),
                new Enum("LR_DSR_8M", INT_LR_DSR_8_M),
                new Enum("LR_DSR_16M", INT_LR_DSR_16_M),
                new Enum("LR_DSR_34M", INT_LR_DSR_34_M),
                new Enum("LR_E2_8M", INT_LR_E_2_8_M),
                new Enum("LR_E5_565M", INT_LR_E_5_565_M),
                new Enum("LR_Encapsulation", INT_LR_ENCAPSULATION),
                new Enum("LR_Fragment", INT_LR_FRAGMENT),
                new Enum("LR_DSR_45M", INT_LR_DSR_45_M),
                new Enum("LR_DSR_140M", INT_LR_DSR_140_M),
                new Enum("LR_DSR_565M", INT_LR_DSR_565_M),
                new Enum("LR_DSR_Fast_Ethernet", INT_LR_DSR_FAST_ETHERNET),
                new Enum("LR_DSR_Gigabit_Ethernet", INT_LR_DSR_GIGABIT_ETHERNET),
                new Enum("LR_DSR_10Gigabit_Ethernet", INT_LR_DSR_10_GIGABIT_ETHERNET),
                new Enum("LR_DSR_OC1_STM0", INT_LR_DSR_OC_1_STM_0),
                new Enum("LR_DSR_OC3_STM1", INT_LR_DSR_OC_3_STM_1),
                new Enum("LR_DSR_2xSTM1", INT_LR_DSR_2_X_STM_1),
                new Enum("LR_DSR_OC12_STM4", INT_LR_DSR_OC_12_STM_4),
                new Enum("LR_DSR_OC24_STM8", INT_LR_DSR_OC_24_STM_8),
                new Enum("LR_DSR_OC48_and_STM16", INT_LR_DSR_OC_48_AND_STM_16),
                new Enum("LR_DSR_OC192_and_STM64", INT_LR_DSR_OC_192_AND_STM_64),
                new Enum("LR_DSR_OC768_and_STM256", INT_LR_DSR_OC_768_AND_STM_256),
                new Enum("LR_DSR_OTU1", INT_LR_DSR_OTU_1),
                new Enum("LR_DSR_OTU2", INT_LR_DSR_OTU_2),
                new Enum("LR_DSR_OTU3", INT_LR_DSR_OTU_3),
                new Enum("LR_E1_2M", INT_LR_E_1_2_M),
                new Enum("LR_E20_2x2M", INT_LR_E_20_2_X_2_M),
                new Enum("LR_E30_8x2M", INT_LR_E_30_8_X_2_M),
                new Enum("LR_E3_34M", INT_LR_E_3_34_M),
                new Enum("LR_E4_140M", INT_LR_E_4_140_M),
                new Enum("LR_ESCON", INT_LR_ESCON),
                new Enum("LR_Ethernet", INT_LR_ETHERNET),
                new Enum("LR_ETR", INT_LR_ETR),
                new Enum("LR_Fast_Ethernet", INT_LR_FAST_ETHERNET),
                new Enum("LR_FC_12_133M", INT_LR_FC_12_133_M),
                new Enum("LR_FC_25_266M", INT_LR_FC_25_266_M),
                new Enum("LR_FC_50_531M", INT_LR_FC_50_531_M),
                new Enum("LR_FC_100_1063M", INT_LR_FC_100_1063_M),
                new Enum("LR_FDDI", INT_LR_FDDI),
                new Enum("LR_FICON", INT_LR_FICON),
                new Enum("LR_FR_IF", INT_LR_FR_IF),
                new Enum("LR_FR_PVC", INT_LR_FR_PVC),
                new Enum("LR_Gigabit_Ethernet", INT_LR_GIGABIT_ETHERNET),
                new Enum("LR_ISDN_BRI", INT_LR_ISDN_BRI),
                new Enum("LR_Line_OC1_STS1_and_MS_STM0", INT_LR_LINE_OC_1_STS_1_AND_MS_STM_0),
                new Enum("LR_Line_OC3_STS3_and_MS_STM1", INT_LR_LINE_OC_3_STS_3_AND_MS_STM_1),
                new Enum("LR_Line_OC12_STS12_and_MS_STM4", INT_LR_LINE_OC_12_STS_12_AND_MS_STM_4),
                new Enum("LR_Line_OC24_STS24_and_MS_STM8", INT_LR_LINE_OC_24_STS_24_AND_MS_STM_8),
                new Enum("LR_Line_OC48_STS48_and_MS_STM16", INT_LR_LINE_OC_48_STS_48_AND_MS_STM_16),
                new Enum("LR_Line_OC192_STS192_and_MS_STM64", INT_LR_LINE_OC_192_STS_192_AND_MS_STM_64),
                new Enum("LR_Line_OC768_STS768_and_MS_STM256", INT_LR_LINE_OC_768_STS_768_AND_MS_STM_256),
                new Enum("LR_Low_Order_TU3_VC3", INT_LR_LOW_ORDER_TU_3_VC_3),
                new Enum("LR_OCH_Data_Unit_1", INT_LR_OCH_DATA_UNIT_1),
                new Enum("LR_OCH_Data_Unit_2", INT_LR_OCH_DATA_UNIT_2),
                new Enum("LR_OCH_Data_Unit_3", INT_LR_OCH_DATA_UNIT_3),
                new Enum("LR_OCH_Transport_Unit_1", INT_LR_OCH_TRANSPORT_UNIT_1),
                new Enum("LR_OCH_Transport_Unit_2", INT_LR_OCH_TRANSPORT_UNIT_2),
                new Enum("LR_OCH_Transport_Unit_3", INT_LR_OCH_TRANSPORT_UNIT_3),
                new Enum("LR_STS3c_and_AU4_VC4", INT_LR_STS_3_C_AND_AU_4_VC_4),
                new Enum("LR_STS4c_and_VC3_4c", INT_LR_STS_4_C_AND_VC_3_4_C),
                new Enum("LR_STS5c_and_VC3_5c", INT_LR_STS_5_C_AND_VC_3_5_C),
                new Enum("LR_STS6c_and_VC4_2c", INT_LR_STS_6_C_AND_VC_4_2_C),
                new Enum("LR_STS7c_and_VC3_7c", INT_LR_STS_7_C_AND_VC_3_7_C),
                new Enum("LR_STS8c_and_VC3_8c", INT_LR_STS_8_C_AND_VC_3_8_C),
                new Enum("LR_STS9c_and_VC4_3c", INT_LR_STS_9_C_AND_VC_4_3_C),
                new Enum("LR_Optical_Channel", INT_LR_OPTICAL_CHANNEL),
                new Enum("LR_Optical_Multiplex_Section", INT_LR_OPTICAL_MULTIPLEX_SECTION),
                new Enum("LR_OPTICAL_SECTION", INT_LR_OPTICAL_SECTION),
                new Enum("LR_Optical_Transmission_Section", INT_LR_OPTICAL_TRANSMISSION_SECTION),
                new Enum("LR_PHYSICAL_ELECTRICAL", INT_LR_PHYSICAL_ELECTRICAL_2),
                new Enum("LR_PHYSICAL_MEDIALESS", INT_LR_PHYSICAL_MEDIALESS),
                new Enum("LR_PHYSICAL_OPTICAL", INT_LR_PHYSICAL_OPTICAL),
                new Enum("LR_POTS", INT_LR_POTS),
                new Enum("LR_Section_OC1_STS1_and_RS_STM0", INT_LR_SECTION_OC_1_STS_1_AND_RS_STM_0),
                new Enum("LR_Section_OC3_STS3_and_RS_STM1", INT_LR_SECTION_OC_3_STS_3_AND_RS_STM_1),
                new Enum("LR_Section_OC12_STS12_and_RS_STM4", INT_LR_SECTION_OC_12_STS_12_AND_RS_STM_4),
                new Enum("LR_Section_OC24_STS24_and_RS_STM8", INT_LR_SECTION_OC_24_STS_24_AND_RS_STM_8),
                new Enum("LR_Section_OC48_STS48_and_RS_STM16", INT_LR_SECTION_OC_48_STS_48_AND_RS_STM_16),
                new Enum("LR_Section_OC192_STS192_and_RS_STM64", INT_LR_SECTION_OC_192_STS_192_AND_RS_STM_64),
                new Enum("LR_Section_OC768_STS768_and_RS_STM256", INT_LR_SECTION_OC_768_STS_768_AND_RS_STM_256),
                new Enum("LR_STS1_and_AU3_High_Order_VC3", INT_LR_STS_1_AND_AU_3_HIGH_ORDER_VC_3),
                new Enum("LR_STS2c_and_VC3_2c", INT_LR_STS_2_C_AND_VC_3_2_C),
                new Enum("LR_STS10c_and_VC3_10c", INT_LR_STS_10_C_AND_VC_3_10_C),
                new Enum("LR_STS11c_and_VC3_11c", INT_LR_STS_11_C_AND_VC_3_11_C),
                new Enum("LR_STS12c_and_VC4_4c", INT_LR_STS_12_C_AND_VC_4_4_C),
                new Enum("LR_STS13c_and_VC3_13c", INT_LR_STS_13_C_AND_VC_3_13_C),
                new Enum("LR_STS14c_and_VC3_14c", INT_LR_STS_14_C_AND_VC_3_14_C),
                new Enum("LR_STS15c_and_VC4_5c", INT_LR_STS_15_C_AND_VC_4_5_C),
                new Enum("LR_STS16c_and_VC3_16c", INT_LR_STS_16_C_AND_VC_3_16_C),
                new Enum("LR_STS17c_and_VC3_17c", INT_LR_STS_17_C_AND_VC_3_17_C),
                new Enum("LR_STS18c_and_VC4_6c", INT_LR_STS_18_C_AND_VC_4_6_C),
                new Enum("LR_STS19c_and_VC3_19c", INT_LR_STS_19_C_AND_VC_3_19_C),
                new Enum("LR_STS20c_and_VC3_20c", INT_LR_STS_20_C_AND_VC_3_20_C),
                new Enum("LR_STS21c_and_VC4_7c", INT_LR_STS_21_C_AND_VC_4_7_C),
                new Enum("LR_STS22c_and_VC3_22c", INT_LR_STS_22_C_AND_VC_3_22_C),
                new Enum("LR_STS23c_and_VC3_23c", INT_LR_STS_23_C_AND_VC_3_23_C),
                new Enum("LR_STS24c_and_VC4_8c", INT_LR_STS_24_C_AND_VC_4_8_C),
                new Enum("LR_STS25c_and_VC3_25c", INT_LR_STS_25_C_AND_VC_3_25_C),
                new Enum("LR_STS26c_and_VC3_26c", INT_LR_STS_26_C_AND_VC_3_26_C),
                new Enum("LR_STS27c_and_VC4_9c", INT_LR_STS_27_C_AND_VC_4_9_C),
                new Enum("LR_STS28c_and_VC3_28c", INT_LR_STS_28_C_AND_VC_3_28_C),
                new Enum("LR_STS29c_and_VC3_29c", INT_LR_STS_29_C_AND_VC_3_29_C),
                new Enum("LR_STS30c_and_VC4_10c", INT_LR_STS_30_C_AND_VC_4_10_C),
                new Enum("LR_STS31c_and_VC3_31c", INT_LR_STS_31_C_AND_VC_3_31_C),
                new Enum("LR_STS32c_and_VC3_32c", INT_LR_STS_32_C_AND_VC_3_32_C),
                new Enum("LR_STS33c_and_VC4_11c", INT_LR_STS_33_C_AND_VC_4_11_C),
                new Enum("LR_STS34c_and_VC3_34c", INT_LR_STS_34_C_AND_VC_3_34_C),
                new Enum("LR_STS35c_and_VC3_35c", INT_LR_STS_35_C_AND_VC_3_35_C),
                new Enum("LR_STS36c_and_VC4_12c", INT_LR_STS_36_C_AND_VC_4_12_C),
                new Enum("LR_STS37c_and_VC3_37c", INT_LR_STS_37_C_AND_VC_3_37_C),
                new Enum("LR_STS38c_and_VC3_38c", INT_LR_STS_38_C_AND_VC_3_38_C),
                new Enum("LR_STS39c_and_VC4_13c", INT_LR_STS_39_C_AND_VC_4_13_C),
                new Enum("LR_STS40c_and_VC3_40c", INT_LR_STS_40_C_AND_VC_3_40_C),
                new Enum("LR_STS41c_and_VC3_41c", INT_LR_STS_41_C_AND_VC_3_41_C),
                new Enum("LR_STS42c_and_VC4_14c", INT_LR_STS_42_C_AND_VC_4_14_C),
                new Enum("LR_STS43c_and_VC3_43c", INT_LR_STS_43_C_AND_VC_3_43_C),
                new Enum("LR_STS44c_and_VC3_44c", INT_LR_STS_44_C_AND_VC_3_44_C),
                new Enum("LR_STS45c_and_VC4_15c", INT_LR_STS_45_C_AND_VC_4_15_C),
                new Enum("LR_STS46c_and_VC3_46c", INT_LR_STS_46_C_AND_VC_3_46_C),
                new Enum("LR_STS47c_and_VC3_47c", INT_LR_STS_47_C_AND_VC_3_47_C),
                new Enum("LR_STS48c_and_VC4_16c", INT_LR_STS_48_C_AND_VC_4_16_C),
                new Enum("LR_STS49c_and_VC3_49c", INT_LR_STS_49_C_AND_VC_3_49_C),
                new Enum("LR_STS50c_and_VC3_50c", INT_LR_STS_50_C_AND_VC_3_50_C),
                new Enum("LR_STS51c_and_VC4_17c", INT_LR_STS_51_C_AND_VC_4_17_C),
                new Enum("LR_STS52c_and_VC3_52c", INT_LR_STS_52_C_AND_VC_3_52_C),
                new Enum("LR_STS53c_and_VC3_53c", INT_LR_STS_53_C_AND_VC_3_53_C),
                new Enum("LR_STS54c_and_VC4_18c", INT_LR_STS_54_C_AND_VC_4_18_C),
                new Enum("LR_STS55c_and_VC3_55c", INT_LR_STS_55_C_AND_VC_3_55_C),
                new Enum("LR_STS56c_and_VC3_56c", INT_LR_STS_56_C_AND_VC_3_56_C),
                new Enum("LR_STS57c_and_VC4_19c", INT_LR_STS_57_C_AND_VC_4_19_C),
                new Enum("LR_STS58c_and_VC3_58c", INT_LR_STS_58_C_AND_VC_3_58_C),
                new Enum("LR_STS59c_and_VC3_59c", INT_LR_STS_59_C_AND_VC_3_59_C),
                new Enum("LR_STS60c_and_VC4_20c", INT_LR_STS_60_C_AND_VC_4_20_C),
                new Enum("LR_STS61c_and_VC3_61c", INT_LR_STS_61_C_AND_VC_3_61_C),
                new Enum("LR_STS62c_and_VC3_62c", INT_LR_STS_62_C_AND_VC_3_62_C),
                new Enum("LR_STS63c_and_VC4_21c", INT_LR_STS_63_C_AND_VC_4_21_C),
                new Enum("LR_STS64c_and_VC3_64c", INT_LR_STS_64_C_AND_VC_3_64_C),
                new Enum("LR_STS65c_and_VC3_65c", INT_LR_STS_65_C_AND_VC_3_65_C),
                new Enum("LR_STS66c_and_VC4_22c", INT_LR_STS_66_C_AND_VC_4_22_C),
                new Enum("LR_STS67c_and_VC3_67c", INT_LR_STS_67_C_AND_VC_3_67_C),
                new Enum("LR_STS68c_and_VC3_68c", INT_LR_STS_68_C_AND_VC_3_68_C),
                new Enum("LR_STS69c_and_VC4_23c", INT_LR_STS_69_C_AND_VC_4_23_C),
                new Enum("LR_STS70c_and_VC3_70c", INT_LR_STS_70_C_AND_VC_3_70_C),
                new Enum("LR_STS71c_and_VC3_71c", INT_LR_STS_71_C_AND_VC_3_71_C),
                new Enum("LR_STS72c_and_VC4_24c", INT_LR_STS_72_C_AND_VC_4_24_C),
                new Enum("LR_STS73c_and_VC3_73c", INT_LR_STS_73_C_AND_VC_3_73_C),
                new Enum("LR_STS74c_and_VC3_74c", INT_LR_STS_74_C_AND_VC_3_74_C),
                new Enum("LR_STS75c_and_VC4_25c", INT_LR_STS_75_C_AND_VC_4_25_C),
                new Enum("LR_STS76c_and_VC3_76c", INT_LR_STS_76_C_AND_VC_3_76_C),
                new Enum("LR_STS77c_and_VC3_77c", INT_LR_STS_77_C_AND_VC_3_77_C),
                new Enum("LR_STS78c_and_VC4_26c", INT_LR_STS_78_C_AND_VC_4_26_C),
                new Enum("LR_STS79c_and_VC3_79c", INT_LR_STS_79_C_AND_VC_3_79_C),
                new Enum("LR_STS80c_and_VC3_80c", INT_LR_STS_80_C_AND_VC_3_80_C),
                new Enum("LR_STS81c_and_VC4_27c", INT_LR_STS_81_C_AND_VC_4_27_C),
                new Enum("LR_STS82c_and_VC3_82c", INT_LR_STS_82_C_AND_VC_3_82_C),
                new Enum("LR_STS83c_and_VC3_83c", INT_LR_STS_83_C_AND_VC_3_83_C),
                new Enum("LR_STS84c_and_VC4_28c", INT_LR_STS_84_C_AND_VC_4_28_C),
                new Enum("LR_STS85c_and_VC3_85c", INT_LR_STS_85_C_AND_VC_3_85_C),
                new Enum("LR_STS86c_and_VC3_86c", INT_LR_STS_86_C_AND_VC_3_86_C),
                new Enum("LR_STS87c_and_VC4_29c", INT_LR_STS_87_C_AND_VC_4_29_C),
                new Enum("LR_STS88c_and_VC3_88c", INT_LR_STS_88_C_AND_VC_3_88_C),
                new Enum("LR_STS89c_and_VC3_89c", INT_LR_STS_89_C_AND_VC_3_89_C),
                new Enum("LR_STS90c_and_VC4_30c", INT_LR_STS_90_C_AND_VC_4_30_C),
                new Enum("LR_STS91c_and_VC3_91c", INT_LR_STS_91_C_AND_VC_3_91_C),
                new Enum("LR_STS92c_and_VC3_92c", INT_LR_STS_92_C_AND_VC_3_92_C),
                new Enum("LR_STS93c_and_VC4_31c", INT_LR_STS_93_C_AND_VC_4_31_C),
                new Enum("LR_STS94c_and_VC3_94c", INT_LR_STS_94_C_AND_VC_3_94_C),
                new Enum("LR_STS95c_and_VC3_95c", INT_LR_STS_95_C_AND_VC_3_95_C),
                new Enum("LR_STS96c_and_VC4_32c", INT_LR_STS_96_C_AND_VC_4_32_C),
                new Enum("LR_STS97c_and_VC3_97c", INT_LR_STS_97_C_AND_VC_3_97_C),
                new Enum("LR_STS98c_and_VC3_98c", INT_LR_STS_98_C_AND_VC_3_98_C),
                new Enum("LR_STS99c_and_VC4_33c", INT_LR_STS_99_C_AND_VC_4_33_C),
                new Enum("LR_STS100c_and_VC3_100c", INT_LR_STS_100_C_AND_VC_3_100_C),
                new Enum("LR_STS101c_and_VC3_101c", INT_LR_STS_101_C_AND_VC_3_101_C),
                new Enum("LR_STS102c_and_VC4_34c", INT_LR_STS_102_C_AND_VC_4_34_C),
                new Enum("LR_STS103c_and_VC3_103c", INT_LR_STS_103_C_AND_VC_3_103_C),
                new Enum("LR_STS104c_and_VC3_104c", INT_LR_STS_104_C_AND_VC_3_104_C),
                new Enum("LR_STS105c_and_VC4_35c", INT_LR_STS_105_C_AND_VC_4_35_C),
                new Enum("LR_STS106c_and_VC3_106c", INT_LR_STS_106_C_AND_VC_3_106_C),
                new Enum("LR_STS107c_and_VC3_107c", INT_LR_STS_107_C_AND_VC_3_107_C),
                new Enum("LR_STS108c_and_VC4_36c", INT_LR_STS_108_C_AND_VC_4_36_C),
                new Enum("LR_STS109c_and_VC3_109c", INT_LR_STS_109_C_AND_VC_3_109_C),
                new Enum("LR_STS110c_and_VC3_110c", INT_LR_STS_110_C_AND_VC_3_110_C),
                new Enum("LR_STS111c_and_VC4_37c", INT_LR_STS_111_C_AND_VC_4_37_C),
                new Enum("LR_STS112c_and_VC3_112c", INT_LR_STS_112_C_AND_VC_3_112_C),
                new Enum("LR_STS113c_and_VC3_113c", INT_LR_STS_113_C_AND_VC_3_113_C),
                new Enum("LR_STS114c_and_VC4_38c", INT_LR_STS_114_C_AND_VC_4_38_C),
                new Enum("LR_STS115c_and_VC3_115c", INT_LR_STS_115_C_AND_VC_3_115_C),
                new Enum("LR_STS116c_and_VC3_116c", INT_LR_STS_116_C_AND_VC_3_116_C),
                new Enum("LR_STS117c_and_VC4_39c", INT_LR_STS_117_C_AND_VC_4_39_C),
                new Enum("LR_STS118c_and_VC3_118c", INT_LR_STS_118_C_AND_VC_3_118_C),
                new Enum("LR_STS119c_and_VC3_119c", INT_LR_STS_119_C_AND_VC_3_119_C),
                new Enum("LR_STS120c_and_VC4_40c", INT_LR_STS_120_C_AND_VC_4_40_C),
                new Enum("LR_STS121c_and_VC3_121c", INT_LR_STS_121_C_AND_VC_3_121_C),
                new Enum("LR_STS122c_and_VC3_122c", INT_LR_STS_122_C_AND_VC_3_122_C),
                new Enum("LR_STS123c_and_VC4_41c", INT_LR_STS_123_C_AND_VC_4_41_C),
                new Enum("LR_STS124c_and_VC3_124c", INT_LR_STS_124_C_AND_VC_3_124_C),
                new Enum("LR_STS125c_and_VC3_125c", INT_LR_STS_125_C_AND_VC_3_125_C),
                new Enum("LR_STS126c_and_VC4_42c", INT_LR_STS_126_C_AND_VC_4_42_C),
                new Enum("LR_STS127c_and_VC3_127c", INT_LR_STS_127_C_AND_VC_3_127_C),
                new Enum("LR_STS128c_and_VC3_128c", INT_LR_STS_128_C_AND_VC_3_128_C),
                new Enum("LR_STS129c_and_VC4_43c", INT_LR_STS_129_C_AND_VC_4_43_C),
                new Enum("LR_STS130c_and_VC3_130c", INT_LR_STS_130_C_AND_VC_3_130_C),
                new Enum("LR_STS131c_and_VC3_131c", INT_LR_STS_131_C_AND_VC_3_131_C),
                new Enum("LR_STS132c_and_VC4_44c", INT_LR_STS_132_C_AND_VC_4_44_C),
                new Enum("LR_STS133c_and_VC3_133c", INT_LR_STS_133_C_AND_VC_3_133_C),
                new Enum("LR_STS134c_and_VC3_134c", INT_LR_STS_134_C_AND_VC_3_134_C),
                new Enum("LR_STS135c_and_VC4_45c", INT_LR_STS_135_C_AND_VC_4_45_C),
                new Enum("LR_STS136c_and_VC3_136c", INT_LR_STS_136_C_AND_VC_3_136_C),
                new Enum("LR_STS137c_and_VC3_137c", INT_LR_STS_137_C_AND_VC_3_137_C),
                new Enum("LR_STS138c_and_VC4_46c", INT_LR_STS_138_C_AND_VC_4_46_C),
                new Enum("LR_STS139c_and_VC3_139c", INT_LR_STS_139_C_AND_VC_3_139_C),
                new Enum("LR_STS140c_and_VC3_140c", INT_LR_STS_140_C_AND_VC_3_140_C),
                new Enum("LR_STS141c_and_VC4_47c", INT_LR_STS_141_C_AND_VC_4_47_C),
                new Enum("LR_STS142c_and_VC3_142c", INT_LR_STS_142_C_AND_VC_3_142_C),
                new Enum("LR_STS143c_and_VC3_143c", INT_LR_STS_143_C_AND_VC_3_143_C),
                new Enum("LR_STS144c_and_VC4_48c", INT_LR_STS_144_C_AND_VC_4_48_C),
                new Enum("LR_STS145c_and_VC3_145c", INT_LR_STS_145_C_AND_VC_3_145_C),
                new Enum("LR_STS146c_and_VC3_146c", INT_LR_STS_146_C_AND_VC_3_146_C),
                new Enum("LR_STS147c_and_VC4_49c", INT_LR_STS_147_C_AND_VC_4_49_C),
                new Enum("LR_STS148c_and_VC3_148c", INT_LR_STS_148_C_AND_VC_3_148_C),
                new Enum("LR_STS149c_and_VC3_149c", INT_LR_STS_149_C_AND_VC_3_149_C),
                new Enum("LR_STS150c_and_VC4_50c", INT_LR_STS_150_C_AND_VC_4_50_C),
                new Enum("LR_STS151c_and_VC3_151c", INT_LR_STS_151_C_AND_VC_3_151_C),
                new Enum("LR_STS152c_and_VC3_152c", INT_LR_STS_152_C_AND_VC_3_152_C),
                new Enum("LR_STS153c_and_VC4_51c", INT_LR_STS_153_C_AND_VC_4_51_C),
                new Enum("LR_STS154c_and_VC3_154c", INT_LR_STS_154_C_AND_VC_3_154_C),
                new Enum("LR_STS155c_and_VC3_155c", INT_LR_STS_155_C_AND_VC_3_155_C),
                new Enum("LR_STS156c_and_VC4_52c", INT_LR_STS_156_C_AND_VC_4_52_C),
                new Enum("LR_STS157c_and_VC3_157c", INT_LR_STS_157_C_AND_VC_3_157_C),
                new Enum("LR_STS158c_and_VC3_158c", INT_LR_STS_158_C_AND_VC_3_158_C),
                new Enum("LR_STS159c_and_VC4_53c", INT_LR_STS_159_C_AND_VC_4_53_C),
                new Enum("LR_STS160c_and_VC3_160c", INT_LR_STS_160_C_AND_VC_3_160_C),
                new Enum("LR_STS161c_and_VC3_161c", INT_LR_STS_161_C_AND_VC_3_161_C),
                new Enum("LR_STS162c_and_VC4_54c", INT_LR_STS_162_C_AND_VC_4_54_C),
                new Enum("LR_STS163c_and_VC3_163c", INT_LR_STS_163_C_AND_VC_3_163_C),
                new Enum("LR_STS164c_and_VC3_164c", INT_LR_STS_164_C_AND_VC_3_164_C),
                new Enum("LR_STS165c_and_VC4_55c", INT_LR_STS_165_C_AND_VC_4_55_C),
                new Enum("LR_STS166c_and_VC3_166c", INT_LR_STS_166_C_AND_VC_3_166_C),
                new Enum("LR_STS167c_and_VC3_167c", INT_LR_STS_167_C_AND_VC_3_167_C),
                new Enum("LR_STS168c_and_VC4_56c", INT_LR_STS_168_C_AND_VC_4_56_C),
                new Enum("LR_STS169c_and_VC3_169c", INT_LR_STS_169_C_AND_VC_3_169_C),
                new Enum("LR_STS170c_and_VC3_170c", INT_LR_STS_170_C_AND_VC_3_170_C),
                new Enum("LR_STS171c_and_VC4_57c", INT_LR_STS_171_C_AND_VC_4_57_C),
                new Enum("LR_STS172c_and_VC3_172c", INT_LR_STS_172_C_AND_VC_3_172_C),
                new Enum("LR_STS173c_and_VC3_173c", INT_LR_STS_173_C_AND_VC_3_173_C),
                new Enum("LR_STS174c_and_VC4_58c", INT_LR_STS_174_C_AND_VC_4_58_C),
                new Enum("LR_STS175c_and_VC3_175c", INT_LR_STS_175_C_AND_VC_3_175_C),
                new Enum("LR_STS176c_and_VC3_176c", INT_LR_STS_176_C_AND_VC_3_176_C),
                new Enum("LR_STS177c_and_VC4_59c", INT_LR_STS_177_C_AND_VC_4_59_C),
                new Enum("LR_STS178c_and_VC3_178c", INT_LR_STS_178_C_AND_VC_3_178_C),
                new Enum("LR_STS179c_and_VC3_179c", INT_LR_STS_179_C_AND_VC_3_179_C),
                new Enum("LR_STS180c_and_VC4_60c", INT_LR_STS_180_C_AND_VC_4_60_C),
                new Enum("LR_STS181c_and_VC3_181c", INT_LR_STS_181_C_AND_VC_3_181_C),
                new Enum("LR_STS182c_and_VC3_182c", INT_LR_STS_182_C_AND_VC_3_182_C),
                new Enum("LR_STS183c_and_VC4_61c", INT_LR_STS_183_C_AND_VC_4_61_C),
                new Enum("LR_STS184c_and_VC3_184c", INT_LR_STS_184_C_AND_VC_3_184_C),
                new Enum("LR_STS185c_and_VC3_185c", INT_LR_STS_185_C_AND_VC_3_185_C),
                new Enum("LR_STS186c_and_VC4_62c", INT_LR_STS_186_C_AND_VC_4_62_C),
                new Enum("LR_STS187c_and_VC3_187c", INT_LR_STS_187_C_AND_VC_3_187_C),
                new Enum("LR_STS188c_and_VC3_188c", INT_LR_STS_188_C_AND_VC_3_188_C),
                new Enum("LR_STS189c_and_VC4_63c", INT_LR_STS_189_C_AND_VC_4_63_C),
                new Enum("LR_STS190c_and_VC3_190c", INT_LR_STS_190_C_AND_VC_3_190_C),
                new Enum("LR_STS191c_and_VC3_191c", INT_LR_STS_191_C_AND_VC_3_191_C),
                new Enum("LR_STS192c_and_VC4_64c", INT_LR_STS_192_C_AND_VC_4_64_C),
                new Enum("LR_STS768c_and_VC4_256c", INT_LR_STS_768_C_AND_VC_4_256_C),
                new Enum("LR_T1_and_DS1_1_5M", INT_LR_T_1_AND_DS_1_1_5_M),
                new Enum("LR_T2_and_DS2_6M", INT_LR_T_2_AND_DS_2_6_M),
                new Enum("LR_T3_and_DS3_45M", INT_LR_T_3_AND_DS_3_45_M),
                new Enum("LR_VT1_5_and_TU11_VC11", INT_LR_VT_1_5_AND_TU_11_VC_11),
                new Enum("LR_VT2_and_TU12_VC12", INT_LR_VT_2_AND_TU_12_VC_12),
                new Enum("LR_VT6_and_TU2_VC2", INT_LR_VT_6_AND_TU_2_VC_2),
            }
        );
        private static final long serialVersionUID = 1L;
        private java.lang.Object readResolve() { return forInt(intValue()); } 
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType newValue(java.lang.Object obj) {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) type.newValue( obj ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType newInstance() {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateEnumType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
