/*
 * An XML document type.
 * Localname: assignAlarmSeverityAssignmentProfileException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one assignAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class AssignAlarmSeverityAssignmentProfileExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument
{
    
    public AssignAlarmSeverityAssignmentProfileExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "assignAlarmSeverityAssignmentProfileException");
    
    
    /**
     * Gets the "assignAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException getAssignAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException)get_store().find_element_user(ASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "assignAlarmSeverityAssignmentProfileException" element
     */
    public void setAssignAlarmSeverityAssignmentProfileException(org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException assignAlarmSeverityAssignmentProfileException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException)get_store().find_element_user(ASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException)get_store().add_element_user(ASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            }
            target.set(assignAlarmSeverityAssignmentProfileException);
        }
    }
    
    /**
     * Appends and returns a new empty "assignAlarmSeverityAssignmentProfileException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException addNewAssignAlarmSeverityAssignmentProfileException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException)get_store().add_element_user(ASSIGNALARMSEVERITYASSIGNMENTPROFILEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML assignAlarmSeverityAssignmentProfileException(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class AssignAlarmSeverityAssignmentProfileExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.AssignAlarmSeverityAssignmentProfileExceptionDocument.AssignAlarmSeverityAssignmentProfileException
    {
        
        public AssignAlarmSeverityAssignmentProfileExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
