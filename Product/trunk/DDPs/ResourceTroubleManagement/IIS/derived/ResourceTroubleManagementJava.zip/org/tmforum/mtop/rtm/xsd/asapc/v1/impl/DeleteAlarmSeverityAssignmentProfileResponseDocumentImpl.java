/*
 * An XML document type.
 * Localname: deleteAlarmSeverityAssignmentProfileResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one deleteAlarmSeverityAssignmentProfileResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class DeleteAlarmSeverityAssignmentProfileResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument
{
    
    public DeleteAlarmSeverityAssignmentProfileResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DELETEALARMSEVERITYASSIGNMENTPROFILERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "deleteAlarmSeverityAssignmentProfileResponse");
    
    
    /**
     * Gets the "deleteAlarmSeverityAssignmentProfileResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse getDeleteAlarmSeverityAssignmentProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse)get_store().find_element_user(DELETEALARMSEVERITYASSIGNMENTPROFILERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deleteAlarmSeverityAssignmentProfileResponse" element
     */
    public void setDeleteAlarmSeverityAssignmentProfileResponse(org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse deleteAlarmSeverityAssignmentProfileResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse)get_store().find_element_user(DELETEALARMSEVERITYASSIGNMENTPROFILERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse)get_store().add_element_user(DELETEALARMSEVERITYASSIGNMENTPROFILERESPONSE$0);
            }
            target.set(deleteAlarmSeverityAssignmentProfileResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "deleteAlarmSeverityAssignmentProfileResponse" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse addNewDeleteAlarmSeverityAssignmentProfileResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse)get_store().add_element_user(DELETEALARMSEVERITYASSIGNMENTPROFILERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML deleteAlarmSeverityAssignmentProfileResponse(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class DeleteAlarmSeverityAssignmentProfileResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.DeleteAlarmSeverityAssignmentProfileResponseDocument.DeleteAlarmSeverityAssignmentProfileResponse
    {
        
        public DeleteAlarmSeverityAssignmentProfileResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName VENDOREXTENSIONS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "vendorExtensions");
        
        
        /**
         * Gets the "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "vendorExtensions" element
         */
        public boolean isNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "vendorExtensions" element
         */
        public boolean isSetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(VENDOREXTENSIONS$0) != 0;
            }
        }
        
        /**
         * Sets the "vendorExtensions" element
         */
        public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.set(vendorExtensions);
            }
        }
        
        /**
         * Appends and returns a new empty "vendorExtensions" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                return target;
            }
        }
        
        /**
         * Nils the "vendorExtensions" element
         */
        public void setNilVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "vendorExtensions" element
         */
        public void unsetVendorExtensions()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(VENDOREXTENSIONS$0, 0);
            }
        }
    }
}
