/*
 * An XML document type.
 * Localname: getAsapByResourceRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAsapByResourceRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAsapByResourceRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument
{
    
    public GetAsapByResourceRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASAPBYRESOURCEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAsapByResourceRequest");
    
    
    /**
     * Gets the "getAsapByResourceRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest getGetAsapByResourceRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest)get_store().find_element_user(GETASAPBYRESOURCEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAsapByResourceRequest" element
     */
    public void setGetAsapByResourceRequest(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest getAsapByResourceRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest)get_store().find_element_user(GETASAPBYRESOURCEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest)get_store().add_element_user(GETASAPBYRESOURCEREQUEST$0);
            }
            target.set(getAsapByResourceRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAsapByResourceRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest addNewGetAsapByResourceRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest)get_store().add_element_user(GETASAPBYRESOURCEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAsapByResourceRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAsapByResourceRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAsapByResourceRequestDocument.GetAsapByResourceRequest
    {
        
        public GetAsapByResourceRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName RESOURCENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "resourceName");
        private static final javax.xml.namespace.QName LAYERRATELIST$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "layerRateList");
        
        
        /**
         * Gets the "resourceName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(RESOURCENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "resourceName" element
         */
        public void setResourceName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType resourceName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(RESOURCENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(RESOURCENAME$0);
                }
                target.set(resourceName);
            }
        }
        
        /**
         * Appends and returns a new empty "resourceName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewResourceName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(RESOURCENAME$0);
                return target;
            }
        }
        
        /**
         * Gets the "layerRateList" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType getLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATELIST$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "layerRateList" element
         */
        public boolean isNilLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATELIST$2, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "layerRateList" element
         */
        public boolean isSetLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(LAYERRATELIST$2) != 0;
            }
        }
        
        /**
         * Sets the "layerRateList" element
         */
        public void setLayerRateList(org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType layerRateList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATELIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATELIST$2);
                }
                target.set(layerRateList);
            }
        }
        
        /**
         * Appends and returns a new empty "layerRateList" element
         */
        public org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType addNewLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATELIST$2);
                return target;
            }
        }
        
        /**
         * Nils the "layerRateList" element
         */
        public void setNilLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType target = null;
                target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().find_element_user(LAYERRATELIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrb.xsd.lay.v1.LayerRateListType)get_store().add_element_user(LAYERRATELIST$2);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "layerRateList" element
         */
        public void unsetLayerRateList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(LAYERRATELIST$2, 0);
            }
        }
    }
}
