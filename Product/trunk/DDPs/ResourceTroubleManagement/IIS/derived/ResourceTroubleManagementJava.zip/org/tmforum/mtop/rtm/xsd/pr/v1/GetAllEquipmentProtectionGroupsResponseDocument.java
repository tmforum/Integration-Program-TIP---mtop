/*
 * An XML document type.
 * Localname: getAllEquipmentProtectionGroupsResponse
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/pr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.pr.v1;


/**
 * A document containing one getAllEquipmentProtectionGroupsResponse(@http://www.tmforum.org/mtop/rtm/xsd/pr/v1) element.
 *
 * This is a complex type.
 */
public interface GetAllEquipmentProtectionGroupsResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetAllEquipmentProtectionGroupsResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2C8DED09A1FFD775DAAB49672DE07087").resolveHandle("getallequipmentprotectiongroupsresponse5589doctype");
    
    /**
     * Gets the "getAllEquipmentProtectionGroupsResponse" element
     */
    org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument.GetAllEquipmentProtectionGroupsResponse getGetAllEquipmentProtectionGroupsResponse();
    
    /**
     * Sets the "getAllEquipmentProtectionGroupsResponse" element
     */
    void setGetAllEquipmentProtectionGroupsResponse(org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument.GetAllEquipmentProtectionGroupsResponse getAllEquipmentProtectionGroupsResponse);
    
    /**
     * Appends and returns a new empty "getAllEquipmentProtectionGroupsResponse" element
     */
    org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument.GetAllEquipmentProtectionGroupsResponse addNewGetAllEquipmentProtectionGroupsResponse();
    
    /**
     * An XML getAllEquipmentProtectionGroupsResponse(@http://www.tmforum.org/mtop/rtm/xsd/pr/v1).
     *
     * This is a complex type.
     */
    public interface GetAllEquipmentProtectionGroupsResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetAllEquipmentProtectionGroupsResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s2C8DED09A1FFD775DAAB49672DE07087").resolveHandle("getallequipmentprotectiongroupsresponse1d66elemtype");
        
        /**
         * Gets the "epgList" element
         */
        org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupListType getEpgList();
        
        /**
         * Tests for nil "epgList" element
         */
        boolean isNilEpgList();
        
        /**
         * True if has "epgList" element
         */
        boolean isSetEpgList();
        
        /**
         * Sets the "epgList" element
         */
        void setEpgList(org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupListType epgList);
        
        /**
         * Appends and returns a new empty "epgList" element
         */
        org.tmforum.mtop.nra.xsd.epg.v1.EquipmentProtectionGroupListType addNewEpgList();
        
        /**
         * Nils the "epgList" element
         */
        void setNilEpgList();
        
        /**
         * Unsets the "epgList" element
         */
        void unsetEpgList();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument.GetAllEquipmentProtectionGroupsResponse newInstance() {
              return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument.GetAllEquipmentProtectionGroupsResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument.GetAllEquipmentProtectionGroupsResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument.GetAllEquipmentProtectionGroupsResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument newInstance() {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.rtm.xsd.pr.v1.GetAllEquipmentProtectionGroupsResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
