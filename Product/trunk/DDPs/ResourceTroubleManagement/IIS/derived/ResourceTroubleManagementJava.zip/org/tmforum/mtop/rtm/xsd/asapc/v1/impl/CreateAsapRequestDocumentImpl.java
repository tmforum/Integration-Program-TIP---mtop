/*
 * An XML document type.
 * Localname: createAsapRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapc.v1.impl;
/**
 * A document containing one createAsapRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1) element.
 *
 * This is a complex type.
 */
public class CreateAsapRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument
{
    
    public CreateAsapRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CREATEASAPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "createAsapRequest");
    
    
    /**
     * Gets the "createAsapRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest getCreateAsapRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest)get_store().find_element_user(CREATEASAPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "createAsapRequest" element
     */
    public void setCreateAsapRequest(org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest createAsapRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest)get_store().find_element_user(CREATEASAPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest)get_store().add_element_user(CREATEASAPREQUEST$0);
            }
            target.set(createAsapRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "createAsapRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest addNewCreateAsapRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest)get_store().add_element_user(CREATEASAPREQUEST$0);
            return target;
        }
    }
    /**
     * An XML createAsapRequest(@http://www.tmforum.org/mtop/rtm/xsd/asapc/v1).
     *
     * This is a complex type.
     */
    public static class CreateAsapRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapc.v1.CreateAsapRequestDocument.CreateAsapRequest
    {
        
        public CreateAsapRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ASAPCREATEDATA$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapc/v1", "asapCreateData");
        
        
        /**
         * Gets the "asapCreateData" element
         */
        public org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType getAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType)get_store().find_element_user(ASAPCREATEDATA$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "asapCreateData" element
         */
        public boolean isNilAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType)get_store().find_element_user(ASAPCREATEDATA$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "asapCreateData" element
         */
        public boolean isSetAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ASAPCREATEDATA$0) != 0;
            }
        }
        
        /**
         * Sets the "asapCreateData" element
         */
        public void setAsapCreateData(org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType asapCreateData)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType)get_store().find_element_user(ASAPCREATEDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType)get_store().add_element_user(ASAPCREATEDATA$0);
                }
                target.set(asapCreateData);
            }
        }
        
        /**
         * Appends and returns a new empty "asapCreateData" element
         */
        public org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType addNewAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType)get_store().add_element_user(ASAPCREATEDATA$0);
                return target;
            }
        }
        
        /**
         * Nils the "asapCreateData" element
         */
        public void setNilAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType target = null;
                target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType)get_store().find_element_user(ASAPCREATEDATA$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.rtm.xsd.asapc.v1.AsapCreateDataType)get_store().add_element_user(ASAPCREATEDATA$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "asapCreateData" element
         */
        public void unsetAsapCreateData()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ASAPCREATEDATA$0, 0);
            }
        }
    }
}
