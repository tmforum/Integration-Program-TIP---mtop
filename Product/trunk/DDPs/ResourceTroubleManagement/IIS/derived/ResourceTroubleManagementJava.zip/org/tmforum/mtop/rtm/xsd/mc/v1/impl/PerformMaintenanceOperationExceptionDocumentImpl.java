/*
 * An XML document type.
 * Localname: performMaintenanceOperationException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/mc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.mc.v1.impl;
/**
 * A document containing one performMaintenanceOperationException(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1) element.
 *
 * This is a complex type.
 */
public class PerformMaintenanceOperationExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument
{
    
    public PerformMaintenanceOperationExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERFORMMAINTENANCEOPERATIONEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "performMaintenanceOperationException");
    
    
    /**
     * Gets the "performMaintenanceOperationException" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException getPerformMaintenanceOperationException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException)get_store().find_element_user(PERFORMMAINTENANCEOPERATIONEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "performMaintenanceOperationException" element
     */
    public void setPerformMaintenanceOperationException(org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException performMaintenanceOperationException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException)get_store().find_element_user(PERFORMMAINTENANCEOPERATIONEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException)get_store().add_element_user(PERFORMMAINTENANCEOPERATIONEXCEPTION$0);
            }
            target.set(performMaintenanceOperationException);
        }
    }
    
    /**
     * Appends and returns a new empty "performMaintenanceOperationException" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException addNewPerformMaintenanceOperationException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException)get_store().add_element_user(PERFORMMAINTENANCEOPERATIONEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML performMaintenanceOperationException(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1).
     *
     * This is a complex type.
     */
    public static class PerformMaintenanceOperationExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.PerformMaintenanceOperationExceptionDocument.PerformMaintenanceOperationException
    {
        
        public PerformMaintenanceOperationExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
