/*
 * An XML document type.
 * Localname: getActiveMaintenanceOperationsException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/mc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.mc.v1.impl;
/**
 * A document containing one getActiveMaintenanceOperationsException(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveMaintenanceOperationsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument
{
    
    public GetActiveMaintenanceOperationsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEMAINTENANCEOPERATIONSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "getActiveMaintenanceOperationsException");
    
    
    /**
     * Gets the "getActiveMaintenanceOperationsException" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException getGetActiveMaintenanceOperationsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveMaintenanceOperationsException" element
     */
    public void setGetActiveMaintenanceOperationsException(org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException getActiveMaintenanceOperationsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSEXCEPTION$0);
            }
            target.set(getActiveMaintenanceOperationsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveMaintenanceOperationsException" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException addNewGetActiveMaintenanceOperationsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getActiveMaintenanceOperationsException(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1).
     *
     * This is a complex type.
     */
    public static class GetActiveMaintenanceOperationsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsExceptionDocument.GetActiveMaintenanceOperationsException
    {
        
        public GetActiveMaintenanceOperationsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
