/*
 * An XML document type.
 * Localname: getActiveMaintenanceOperationsRequest
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/mc/v1
 * Java type: org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.mc.v1.impl;
/**
 * A document containing one getActiveMaintenanceOperationsRequest(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1) element.
 *
 * This is a complex type.
 */
public class GetActiveMaintenanceOperationsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument
{
    
    public GetActiveMaintenanceOperationsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETACTIVEMAINTENANCEOPERATIONSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "getActiveMaintenanceOperationsRequest");
    
    
    /**
     * Gets the "getActiveMaintenanceOperationsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest getGetActiveMaintenanceOperationsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getActiveMaintenanceOperationsRequest" element
     */
    public void setGetActiveMaintenanceOperationsRequest(org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest getActiveMaintenanceOperationsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest)get_store().find_element_user(GETACTIVEMAINTENANCEOPERATIONSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSREQUEST$0);
            }
            target.set(getActiveMaintenanceOperationsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getActiveMaintenanceOperationsRequest" element
     */
    public org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest addNewGetActiveMaintenanceOperationsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest target = null;
            target = (org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest)get_store().add_element_user(GETACTIVEMAINTENANCEOPERATIONSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getActiveMaintenanceOperationsRequest(@http://www.tmforum.org/mtop/rtm/xsd/mc/v1).
     *
     * This is a complex type.
     */
    public static class GetActiveMaintenanceOperationsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.mc.v1.GetActiveMaintenanceOperationsRequestDocument.GetActiveMaintenanceOperationsRequest
    {
        
        public GetActiveMaintenanceOperationsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TPORMENAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/mc/v1", "tpOrMeName");
        
        
        /**
         * Gets the "tpOrMeName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPORMENAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Tests for nil "tpOrMeName" element
         */
        public boolean isNilTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPORMENAME$0, 0);
                if (target == null) return false;
                return target.isNil();
            }
        }
        
        /**
         * True if has "tpOrMeName" element
         */
        public boolean isSetTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(TPORMENAME$0) != 0;
            }
        }
        
        /**
         * Sets the "tpOrMeName" element
         */
        public void setTpOrMeName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType tpOrMeName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPORMENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPORMENAME$0);
                }
                target.set(tpOrMeName);
            }
        }
        
        /**
         * Appends and returns a new empty "tpOrMeName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPORMENAME$0);
                return target;
            }
        }
        
        /**
         * Nils the "tpOrMeName" element
         */
        public void setNilTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(TPORMENAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(TPORMENAME$0);
                }
                target.setNil();
            }
        }
        
        /**
         * Unsets the "tpOrMeName" element
         */
        public void unsetTpOrMeName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(TPORMENAME$0, 0);
            }
        }
    }
}
