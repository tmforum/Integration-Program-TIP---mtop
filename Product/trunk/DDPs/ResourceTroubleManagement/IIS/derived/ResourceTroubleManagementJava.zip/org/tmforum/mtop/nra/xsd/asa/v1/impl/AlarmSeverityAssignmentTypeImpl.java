/*
 * XML Type:  AlarmSeverityAssignmentType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/asa/v1
 * Java type: org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.asa.v1.impl;
/**
 * An XML AlarmSeverityAssignmentType(@http://www.tmforum.org/mtop/nra/xsd/asa/v1).
 *
 * This is a complex type.
 */
public class AlarmSeverityAssignmentTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentType
{
    
    public AlarmSeverityAssignmentTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROBABLECAUSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asa/v1", "probableCause");
    private static final javax.xml.namespace.QName PROBABLECAUSEQUALIFIER$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asa/v1", "probableCauseQualifier");
    private static final javax.xml.namespace.QName NATIVEPROBABLECAUSE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asa/v1", "nativeProbableCause");
    private static final javax.xml.namespace.QName SERVICEAFFECTING$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asa/v1", "serviceAffecting");
    private static final javax.xml.namespace.QName NONSERVICEAFFECTINGSEVERITY$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asa/v1", "nonServiceAffectingSeverity");
    private static final javax.xml.namespace.QName SERVICEINDEPENDENTSEVERITY$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asa/v1", "serviceIndependentSeverity");
    
    
    /**
     * Gets the "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType getProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "probableCause" element
     */
    public boolean isNilProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "probableCause" element
     */
    public void setProbableCause(org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType probableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$0);
            }
            target.set(probableCause);
        }
    }
    
    /**
     * Appends and returns a new empty "probableCause" element
     */
    public org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType addNewProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$0);
            return target;
        }
    }
    
    /**
     * Nils the "probableCause" element
     */
    public void setNilProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().find_element_user(PROBABLECAUSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.prc.v1.ProbableCauseType)get_store().add_element_user(PROBABLECAUSE$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "probableCauseQualifier" element
     */
    public java.lang.String getProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROBABLECAUSEQUALIFIER$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "probableCauseQualifier" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType xgetProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType)get_store().find_element_user(PROBABLECAUSEQUALIFIER$2, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "probableCauseQualifier" element
     */
    public boolean isNilProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType)get_store().find_element_user(PROBABLECAUSEQUALIFIER$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "probableCauseQualifier" element
     */
    public boolean isSetProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PROBABLECAUSEQUALIFIER$2) != 0;
        }
    }
    
    /**
     * Sets the "probableCauseQualifier" element
     */
    public void setProbableCauseQualifier(java.lang.String probableCauseQualifier)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PROBABLECAUSEQUALIFIER$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PROBABLECAUSEQUALIFIER$2);
            }
            target.setStringValue(probableCauseQualifier);
        }
    }
    
    /**
     * Sets (as xml) the "probableCauseQualifier" element
     */
    public void xsetProbableCauseQualifier(org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType probableCauseQualifier)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType)get_store().find_element_user(PROBABLECAUSEQUALIFIER$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType)get_store().add_element_user(PROBABLECAUSEQUALIFIER$2);
            }
            target.set(probableCauseQualifier);
        }
    }
    
    /**
     * Nils the "probableCauseQualifier" element
     */
    public void setNilProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType)get_store().find_element_user(PROBABLECAUSEQUALIFIER$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.ProbableCauseQualifierType)get_store().add_element_user(PROBABLECAUSEQUALIFIER$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "probableCauseQualifier" element
     */
    public void unsetProbableCauseQualifier()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PROBABLECAUSEQUALIFIER$2, 0);
        }
    }
    
    /**
     * Gets the "nativeProbableCause" element
     */
    public java.lang.String getNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NATIVEPROBABLECAUSE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "nativeProbableCause" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType xgetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType)get_store().find_element_user(NATIVEPROBABLECAUSE$4, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "nativeProbableCause" element
     */
    public boolean isNilNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType)get_store().find_element_user(NATIVEPROBABLECAUSE$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "nativeProbableCause" element
     */
    public boolean isSetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(NATIVEPROBABLECAUSE$4) != 0;
        }
    }
    
    /**
     * Sets the "nativeProbableCause" element
     */
    public void setNativeProbableCause(java.lang.String nativeProbableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NATIVEPROBABLECAUSE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NATIVEPROBABLECAUSE$4);
            }
            target.setStringValue(nativeProbableCause);
        }
    }
    
    /**
     * Sets (as xml) the "nativeProbableCause" element
     */
    public void xsetNativeProbableCause(org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType nativeProbableCause)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType)get_store().find_element_user(NATIVEPROBABLECAUSE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType)get_store().add_element_user(NATIVEPROBABLECAUSE$4);
            }
            target.set(nativeProbableCause);
        }
    }
    
    /**
     * Nils the "nativeProbableCause" element
     */
    public void setNilNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType)get_store().find_element_user(NATIVEPROBABLECAUSE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.NativeProbableCauseType)get_store().add_element_user(NATIVEPROBABLECAUSE$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "nativeProbableCause" element
     */
    public void unsetNativeProbableCause()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(NATIVEPROBABLECAUSE$4, 0);
        }
    }
    
    /**
     * Gets the "serviceAffecting" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType getServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(SERVICEAFFECTING$6, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "serviceAffecting" element
     */
    public boolean isNilServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(SERVICEAFFECTING$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "serviceAffecting" element
     */
    public void setServiceAffecting(org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType serviceAffecting)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(SERVICEAFFECTING$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(SERVICEAFFECTING$6);
            }
            target.set(serviceAffecting);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceAffecting" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType addNewServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(SERVICEAFFECTING$6);
            return target;
        }
    }
    
    /**
     * Nils the "serviceAffecting" element
     */
    public void setNilServiceAffecting()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(SERVICEAFFECTING$6, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(SERVICEAFFECTING$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "nonServiceAffectingSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType getNonServiceAffectingSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(NONSERVICEAFFECTINGSEVERITY$8, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "nonServiceAffectingSeverity" element
     */
    public boolean isNilNonServiceAffectingSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(NONSERVICEAFFECTINGSEVERITY$8, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "nonServiceAffectingSeverity" element
     */
    public void setNonServiceAffectingSeverity(org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType nonServiceAffectingSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(NONSERVICEAFFECTINGSEVERITY$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(NONSERVICEAFFECTINGSEVERITY$8);
            }
            target.set(nonServiceAffectingSeverity);
        }
    }
    
    /**
     * Appends and returns a new empty "nonServiceAffectingSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType addNewNonServiceAffectingSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(NONSERVICEAFFECTINGSEVERITY$8);
            return target;
        }
    }
    
    /**
     * Nils the "nonServiceAffectingSeverity" element
     */
    public void setNilNonServiceAffectingSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(NONSERVICEAFFECTINGSEVERITY$8, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(NONSERVICEAFFECTINGSEVERITY$8);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "serviceIndependentSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType getServiceIndependentSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(SERVICEINDEPENDENTSEVERITY$10, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "serviceIndependentSeverity" element
     */
    public boolean isNilServiceIndependentSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(SERVICEINDEPENDENTSEVERITY$10, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "serviceIndependentSeverity" element
     */
    public void setServiceIndependentSeverity(org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType serviceIndependentSeverity)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(SERVICEINDEPENDENTSEVERITY$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(SERVICEINDEPENDENTSEVERITY$10);
            }
            target.set(serviceIndependentSeverity);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceIndependentSeverity" element
     */
    public org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType addNewServiceIndependentSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(SERVICEINDEPENDENTSEVERITY$10);
            return target;
        }
    }
    
    /**
     * Nils the "serviceIndependentSeverity" element
     */
    public void setNilServiceIndependentSeverity()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType target = null;
            target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().find_element_user(SERVICEINDEPENDENTSEVERITY$10, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.com.v1.AssignedSeverityType)get_store().add_element_user(SERVICEINDEPENDENTSEVERITY$10);
            }
            target.setNil();
        }
    }
}
