/*
 * An XML document type.
 * Localname: getAlarmSeverityAssignmentProfileByResourceException
 * Namespace: http://www.tmforum.org/mtop/rtm/xsd/asapr/v1
 * Java type: org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.rtm.xsd.asapr.v1.impl;
/**
 * A document containing one getAlarmSeverityAssignmentProfileByResourceException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1) element.
 *
 * This is a complex type.
 */
public class GetAlarmSeverityAssignmentProfileByResourceExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument
{
    
    public GetAlarmSeverityAssignmentProfileByResourceExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/rtm/xsd/asapr/v1", "getAlarmSeverityAssignmentProfileByResourceException");
    
    
    /**
     * Gets the "getAlarmSeverityAssignmentProfileByResourceException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException getGetAlarmSeverityAssignmentProfileByResourceException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAlarmSeverityAssignmentProfileByResourceException" element
     */
    public void setGetAlarmSeverityAssignmentProfileByResourceException(org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException getAlarmSeverityAssignmentProfileByResourceException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException)get_store().find_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEEXCEPTION$0);
            }
            target.set(getAlarmSeverityAssignmentProfileByResourceException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAlarmSeverityAssignmentProfileByResourceException" element
     */
    public org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException addNewGetAlarmSeverityAssignmentProfileByResourceException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException target = null;
            target = (org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException)get_store().add_element_user(GETALARMSEVERITYASSIGNMENTPROFILEBYRESOURCEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAlarmSeverityAssignmentProfileByResourceException(@http://www.tmforum.org/mtop/rtm/xsd/asapr/v1).
     *
     * This is a complex type.
     */
    public static class GetAlarmSeverityAssignmentProfileByResourceExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.rtm.xsd.asapr.v1.GetAlarmSeverityAssignmentProfileByResourceExceptionDocument.GetAlarmSeverityAssignmentProfileByResourceException
    {
        
        public GetAlarmSeverityAssignmentProfileByResourceExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
