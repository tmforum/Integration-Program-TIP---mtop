/*
 * XML Type:  SwitchDataListType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/sd/v1
 * Java type: org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataListType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.sd.v1.impl;
/**
 * An XML SwitchDataListType(@http://www.tmforum.org/mtop/nra/xsd/sd/v1).
 *
 * This is a complex type.
 */
public class SwitchDataListTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataListType
{
    
    public SwitchDataListTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SWITCHDATA$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/sd/v1", "switchData");
    
    
    /**
     * Gets a List of "switchData" elements
     */
    public java.util.List<org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType> getSwitchDataList()
    {
        final class SwitchDataList extends java.util.AbstractList<org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType>
        {
            public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType get(int i)
                { return SwitchDataListTypeImpl.this.getSwitchDataArray(i); }
            
            public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType set(int i, org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType o)
            {
                org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType old = SwitchDataListTypeImpl.this.getSwitchDataArray(i);
                SwitchDataListTypeImpl.this.setSwitchDataArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType o)
                { SwitchDataListTypeImpl.this.insertNewSwitchData(i).set(o); }
            
            public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType remove(int i)
            {
                org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType old = SwitchDataListTypeImpl.this.getSwitchDataArray(i);
                SwitchDataListTypeImpl.this.removeSwitchData(i);
                return old;
            }
            
            public int size()
                { return SwitchDataListTypeImpl.this.sizeOfSwitchDataArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new SwitchDataList();
        }
    }
    
    /**
     * Gets array of all "switchData" elements
     */
    public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType[] getSwitchDataArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SWITCHDATA$0, targetList);
            org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType[] result = new org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "switchData" element
     */
    public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType getSwitchDataArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType)get_store().find_element_user(SWITCHDATA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "switchData" element
     */
    public int sizeOfSwitchDataArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SWITCHDATA$0);
        }
    }
    
    /**
     * Sets array of all "switchData" element
     */
    public void setSwitchDataArray(org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType[] switchDataArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(switchDataArray, SWITCHDATA$0);
        }
    }
    
    /**
     * Sets ith "switchData" element
     */
    public void setSwitchDataArray(int i, org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType switchData)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType)get_store().find_element_user(SWITCHDATA$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(switchData);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "switchData" element
     */
    public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType insertNewSwitchData(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType)get_store().insert_element_user(SWITCHDATA$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "switchData" element
     */
    public org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType addNewSwitchData()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType target = null;
            target = (org.tmforum.mtop.nra.xsd.sd.v1.SwitchDataType)get_store().add_element_user(SWITCHDATA$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "switchData" element
     */
    public void removeSwitchData(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SWITCHDATA$0, i);
        }
    }
}
