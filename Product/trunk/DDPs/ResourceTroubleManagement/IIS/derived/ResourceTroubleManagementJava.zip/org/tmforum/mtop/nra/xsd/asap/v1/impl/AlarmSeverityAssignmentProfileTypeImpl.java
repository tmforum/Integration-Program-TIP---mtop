/*
 * XML Type:  AlarmSeverityAssignmentProfileType
 * Namespace: http://www.tmforum.org/mtop/nra/xsd/asap/v1
 * Java type: org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.nra.xsd.asap.v1.impl;
/**
 * An XML AlarmSeverityAssignmentProfileType(@http://www.tmforum.org/mtop/nra/xsd/asap/v1).
 *
 * This is a complex type.
 */
public class AlarmSeverityAssignmentProfileTypeImpl extends org.tmforum.mtop.nrb.xsd.cri.v1.impl.CommonResourceInfoTypeImpl implements org.tmforum.mtop.nra.xsd.asap.v1.AlarmSeverityAssignmentProfileType
{
    
    public AlarmSeverityAssignmentProfileTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FIXED$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asap/v1", "fixed");
    private static final javax.xml.namespace.QName ALARMSEVERITYASSIGNMENTLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/nra/xsd/asap/v1", "alarmSeverityAssignmentList");
    
    
    /**
     * Gets the "fixed" element
     */
    public boolean getFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FIXED$0, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "fixed" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$0, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "fixed" element
     */
    public boolean isNilFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "fixed" element
     */
    public boolean isSetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FIXED$0) != 0;
        }
    }
    
    /**
     * Sets the "fixed" element
     */
    public void setFixed(boolean fixed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FIXED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FIXED$0);
            }
            target.setBooleanValue(fixed);
        }
    }
    
    /**
     * Sets (as xml) the "fixed" element
     */
    public void xsetFixed(org.apache.xmlbeans.XmlBoolean fixed)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FIXED$0);
            }
            target.set(fixed);
        }
    }
    
    /**
     * Nils the "fixed" element
     */
    public void setNilFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FIXED$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FIXED$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "fixed" element
     */
    public void unsetFixed()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FIXED$0, 0);
        }
    }
    
    /**
     * Gets the "alarmSeverityAssignmentList" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType getAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ALARMSEVERITYASSIGNMENTLIST$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "alarmSeverityAssignmentList" element
     */
    public boolean isNilAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ALARMSEVERITYASSIGNMENTLIST$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "alarmSeverityAssignmentList" element
     */
    public boolean isSetAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ALARMSEVERITYASSIGNMENTLIST$2) != 0;
        }
    }
    
    /**
     * Sets the "alarmSeverityAssignmentList" element
     */
    public void setAlarmSeverityAssignmentList(org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType alarmSeverityAssignmentList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ALARMSEVERITYASSIGNMENTLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ALARMSEVERITYASSIGNMENTLIST$2);
            }
            target.set(alarmSeverityAssignmentList);
        }
    }
    
    /**
     * Appends and returns a new empty "alarmSeverityAssignmentList" element
     */
    public org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType addNewAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ALARMSEVERITYASSIGNMENTLIST$2);
            return target;
        }
    }
    
    /**
     * Nils the "alarmSeverityAssignmentList" element
     */
    public void setNilAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType target = null;
            target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().find_element_user(ALARMSEVERITYASSIGNMENTLIST$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nra.xsd.asa.v1.AlarmSeverityAssignmentListType)get_store().add_element_user(ALARMSEVERITYASSIGNMENTLIST$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "alarmSeverityAssignmentList" element
     */
    public void unsetAlarmSeverityAssignmentList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ALARMSEVERITYASSIGNMENTLIST$2, 0);
        }
    }
}
