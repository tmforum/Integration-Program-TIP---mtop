/*
 * XML Type:  ServiceAttributeValueChangeType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/savc/v1
 * Java type: org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.savc.v1.impl;
/**
 * An XML ServiceAttributeValueChangeType(@http://www.tmforum.org/mtop/sb/xsd/savc/v1).
 *
 * This is a complex type.
 */
public class ServiceAttributeValueChangeTypeImpl extends org.tmforum.mtop.fmw.xsd.avc.v1.impl.AttributeValueChangeTypeImpl implements org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType
{
    
    public ServiceAttributeValueChangeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
