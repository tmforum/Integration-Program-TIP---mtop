/*
 * An XML document type.
 * Localname: retrieveServiceStatesResponse
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one retrieveServiceStatesResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class RetrieveServiceStatesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument
{
    
    public RetrieveServiceStatesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RETRIEVESERVICESTATESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "retrieveServiceStatesResponse");
    
    
    /**
     * Gets the "retrieveServiceStatesResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse getRetrieveServiceStatesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse)get_store().find_element_user(RETRIEVESERVICESTATESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "retrieveServiceStatesResponse" element
     */
    public void setRetrieveServiceStatesResponse(org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse retrieveServiceStatesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse)get_store().find_element_user(RETRIEVESERVICESTATESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse)get_store().add_element_user(RETRIEVESERVICESTATESRESPONSE$0);
            }
            target.set(retrieveServiceStatesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "retrieveServiceStatesResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse addNewRetrieveServiceStatesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse)get_store().add_element_user(RETRIEVESERVICESTATESRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML retrieveServiceStatesResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class RetrieveServiceStatesResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse
    {
        
        public RetrieveServiceStatesResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CFSNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "cfsName");
        private static final javax.xml.namespace.QName CFSSTATE$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "cfsState");
        
        
        /**
         * Gets a List of "cfsName" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getCfsNameList()
        {
            final class CfsNameList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
            {
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                    { return RetrieveServiceStatesResponseImpl.this.getCfsNameArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = RetrieveServiceStatesResponseImpl.this.getCfsNameArray(i);
                    RetrieveServiceStatesResponseImpl.this.setCfsNameArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                    { RetrieveServiceStatesResponseImpl.this.insertNewCfsName(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = RetrieveServiceStatesResponseImpl.this.getCfsNameArray(i);
                    RetrieveServiceStatesResponseImpl.this.removeCfsName(i);
                    return old;
                }
                
                public int size()
                    { return RetrieveServiceStatesResponseImpl.this.sizeOfCfsNameArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new CfsNameList();
            }
        }
        
        /**
         * Gets array of all "cfsName" elements
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getCfsNameArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CFSNAME$0, targetList);
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "cfsName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getCfsNameArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CFSNAME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "cfsName" element
         */
        public int sizeOfCfsNameArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CFSNAME$0);
            }
        }
        
        /**
         * Sets array of all "cfsName" element
         */
        public void setCfsNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] cfsNameArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(cfsNameArray, CFSNAME$0);
            }
        }
        
        /**
         * Sets ith "cfsName" element
         */
        public void setCfsNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType cfsName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CFSNAME$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(cfsName);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewCfsName(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(CFSNAME$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewCfsName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CFSNAME$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "cfsName" element
         */
        public void removeCfsName(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CFSNAME$0, i);
            }
        }
        
        /**
         * Gets a List of "cfsState" elements
         */
        public java.util.List<java.lang.String> getCfsStateList()
        {
            final class CfsStateList extends java.util.AbstractList<java.lang.String>
            {
                public java.lang.String get(int i)
                    { return RetrieveServiceStatesResponseImpl.this.getCfsStateArray(i); }
                
                public java.lang.String set(int i, java.lang.String o)
                {
                    java.lang.String old = RetrieveServiceStatesResponseImpl.this.getCfsStateArray(i);
                    RetrieveServiceStatesResponseImpl.this.setCfsStateArray(i, o);
                    return old;
                }
                
                public void add(int i, java.lang.String o)
                    { RetrieveServiceStatesResponseImpl.this.insertCfsState(i, o); }
                
                public java.lang.String remove(int i)
                {
                    java.lang.String old = RetrieveServiceStatesResponseImpl.this.getCfsStateArray(i);
                    RetrieveServiceStatesResponseImpl.this.removeCfsState(i);
                    return old;
                }
                
                public int size()
                    { return RetrieveServiceStatesResponseImpl.this.sizeOfCfsStateArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new CfsStateList();
            }
        }
        
        /**
         * Gets array of all "cfsState" elements
         */
        public java.lang.String[] getCfsStateArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CFSSTATE$2, targetList);
                java.lang.String[] result = new java.lang.String[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
                return result;
            }
        }
        
        /**
         * Gets ith "cfsState" element
         */
        public java.lang.String getCfsStateArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CFSSTATE$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "cfsState" elements
         */
        public java.util.List<org.apache.xmlbeans.XmlString> xgetCfsStateList()
        {
            final class CfsStateList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
            {
                public org.apache.xmlbeans.XmlString get(int i)
                    { return RetrieveServiceStatesResponseImpl.this.xgetCfsStateArray(i); }
                
                public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
                {
                    org.apache.xmlbeans.XmlString old = RetrieveServiceStatesResponseImpl.this.xgetCfsStateArray(i);
                    RetrieveServiceStatesResponseImpl.this.xsetCfsStateArray(i, o);
                    return old;
                }
                
                public void add(int i, org.apache.xmlbeans.XmlString o)
                    { RetrieveServiceStatesResponseImpl.this.insertNewCfsState(i).set(o); }
                
                public org.apache.xmlbeans.XmlString remove(int i)
                {
                    org.apache.xmlbeans.XmlString old = RetrieveServiceStatesResponseImpl.this.xgetCfsStateArray(i);
                    RetrieveServiceStatesResponseImpl.this.removeCfsState(i);
                    return old;
                }
                
                public int size()
                    { return RetrieveServiceStatesResponseImpl.this.sizeOfCfsStateArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new CfsStateList();
            }
        }
        
        /**
         * Gets (as xml) array of all "cfsState" elements
         */
        public org.apache.xmlbeans.XmlString[] xgetCfsStateArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CFSSTATE$2, targetList);
                org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "cfsState" element
         */
        public org.apache.xmlbeans.XmlString xgetCfsStateArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CFSSTATE$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.apache.xmlbeans.XmlString)target;
            }
        }
        
        /**
         * Returns number of "cfsState" element
         */
        public int sizeOfCfsStateArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CFSSTATE$2);
            }
        }
        
        /**
         * Sets array of all "cfsState" element
         */
        public void setCfsStateArray(java.lang.String[] cfsStateArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(cfsStateArray, CFSSTATE$2);
            }
        }
        
        /**
         * Sets ith "cfsState" element
         */
        public void setCfsStateArray(int i, java.lang.String cfsState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CFSSTATE$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setStringValue(cfsState);
            }
        }
        
        /**
         * Sets (as xml) array of all "cfsState" element
         */
        public void xsetCfsStateArray(org.apache.xmlbeans.XmlString[]cfsStateArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(cfsStateArray, CFSSTATE$2);
            }
        }
        
        /**
         * Sets (as xml) ith "cfsState" element
         */
        public void xsetCfsStateArray(int i, org.apache.xmlbeans.XmlString cfsState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CFSSTATE$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(cfsState);
            }
        }
        
        /**
         * Inserts the value as the ith "cfsState" element
         */
        public void insertCfsState(int i, java.lang.String cfsState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(CFSSTATE$2, i);
                target.setStringValue(cfsState);
            }
        }
        
        /**
         * Appends the value as the last "cfsState" element
         */
        public void addCfsState(java.lang.String cfsState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CFSSTATE$2);
                target.setStringValue(cfsState);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsState" element
         */
        public org.apache.xmlbeans.XmlString insertNewCfsState(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(CFSSTATE$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsState" element
         */
        public org.apache.xmlbeans.XmlString addNewCfsState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CFSSTATE$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "cfsState" element
         */
        public void removeCfsState(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CFSSTATE$2, i);
            }
        }
    }
}
