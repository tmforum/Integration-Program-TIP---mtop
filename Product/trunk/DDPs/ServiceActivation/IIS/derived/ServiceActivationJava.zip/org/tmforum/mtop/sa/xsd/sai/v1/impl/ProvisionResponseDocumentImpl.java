/*
 * An XML document type.
 * Localname: provisionResponse
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one provisionResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class ProvisionResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument
{
    
    public ProvisionResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PROVISIONRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "provisionResponse");
    
    
    /**
     * Gets the "provisionResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse getProvisionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse)get_store().find_element_user(PROVISIONRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "provisionResponse" element
     */
    public void setProvisionResponse(org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse provisionResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse)get_store().find_element_user(PROVISIONRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse)get_store().add_element_user(PROVISIONRESPONSE$0);
            }
            target.set(provisionResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "provisionResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse addNewProvisionResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse)get_store().add_element_user(PROVISIONRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML provisionResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class ProvisionResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ProvisionResponseDocument.ProvisionResponse
    {
        
        public ProvisionResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INITIALRESPONSE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "initialResponse");
        private static final javax.xml.namespace.QName BEGINPROCESSINGEVENT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "beginProcessingEvent");
        private static final javax.xml.namespace.QName CFSCREATION$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "cfsCreation");
        private static final javax.xml.namespace.QName CFSSTATECHANGE$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "cfsStateChange");
        
        
        /**
         * Gets a List of "initialResponse" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType> getInitialResponseList()
        {
            final class InitialResponseList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType get(int i)
                    { return ProvisionResponseImpl.this.getInitialResponseArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType old = ProvisionResponseImpl.this.getInitialResponseArray(i);
                    ProvisionResponseImpl.this.setInitialResponseArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType o)
                    { ProvisionResponseImpl.this.insertNewInitialResponse(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType old = ProvisionResponseImpl.this.getInitialResponseArray(i);
                    ProvisionResponseImpl.this.removeInitialResponse(i);
                    return old;
                }
                
                public int size()
                    { return ProvisionResponseImpl.this.sizeOfInitialResponseArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new InitialResponseList();
            }
        }
        
        /**
         * Gets array of all "initialResponse" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] getInitialResponseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(INITIALRESPONSE$0, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType getInitialResponseArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().find_element_user(INITIALRESPONSE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "initialResponse" element
         */
        public int sizeOfInitialResponseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INITIALRESPONSE$0);
            }
        }
        
        /**
         * Sets array of all "initialResponse" element
         */
        public void setInitialResponseArray(org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] initialResponseArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(initialResponseArray, INITIALRESPONSE$0);
            }
        }
        
        /**
         * Sets ith "initialResponse" element
         */
        public void setInitialResponseArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType initialResponse)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().find_element_user(INITIALRESPONSE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(initialResponse);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType insertNewInitialResponse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().insert_element_user(INITIALRESPONSE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType addNewInitialResponse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().add_element_user(INITIALRESPONSE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "initialResponse" element
         */
        public void removeInitialResponse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INITIALRESPONSE$0, i);
            }
        }
        
        /**
         * Gets a List of "beginProcessingEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType> getBeginProcessingEventList()
        {
            final class BeginProcessingEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType get(int i)
                    { return ProvisionResponseImpl.this.getBeginProcessingEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType old = ProvisionResponseImpl.this.getBeginProcessingEventArray(i);
                    ProvisionResponseImpl.this.setBeginProcessingEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType o)
                    { ProvisionResponseImpl.this.insertNewBeginProcessingEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType old = ProvisionResponseImpl.this.getBeginProcessingEventArray(i);
                    ProvisionResponseImpl.this.removeBeginProcessingEvent(i);
                    return old;
                }
                
                public int size()
                    { return ProvisionResponseImpl.this.sizeOfBeginProcessingEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new BeginProcessingEventList();
            }
        }
        
        /**
         * Gets array of all "beginProcessingEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] getBeginProcessingEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(BEGINPROCESSINGEVENT$2, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType getBeginProcessingEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().find_element_user(BEGINPROCESSINGEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "beginProcessingEvent" element
         */
        public int sizeOfBeginProcessingEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BEGINPROCESSINGEVENT$2);
            }
        }
        
        /**
         * Sets array of all "beginProcessingEvent" element
         */
        public void setBeginProcessingEventArray(org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] beginProcessingEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(beginProcessingEventArray, BEGINPROCESSINGEVENT$2);
            }
        }
        
        /**
         * Sets ith "beginProcessingEvent" element
         */
        public void setBeginProcessingEventArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType beginProcessingEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().find_element_user(BEGINPROCESSINGEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(beginProcessingEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType insertNewBeginProcessingEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().insert_element_user(BEGINPROCESSINGEVENT$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType addNewBeginProcessingEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().add_element_user(BEGINPROCESSINGEVENT$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "beginProcessingEvent" element
         */
        public void removeBeginProcessingEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BEGINPROCESSINGEVENT$2, i);
            }
        }
        
        /**
         * Gets a List of "cfsCreation" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType> getCfsCreationList()
        {
            final class CfsCreationList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType get(int i)
                    { return ProvisionResponseImpl.this.getCfsCreationArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType old = ProvisionResponseImpl.this.getCfsCreationArray(i);
                    ProvisionResponseImpl.this.setCfsCreationArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType o)
                    { ProvisionResponseImpl.this.insertNewCfsCreation(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType old = ProvisionResponseImpl.this.getCfsCreationArray(i);
                    ProvisionResponseImpl.this.removeCfsCreation(i);
                    return old;
                }
                
                public int size()
                    { return ProvisionResponseImpl.this.sizeOfCfsCreationArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new CfsCreationList();
            }
        }
        
        /**
         * Gets array of all "cfsCreation" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType[] getCfsCreationArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CFSCREATION$4, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "cfsCreation" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType getCfsCreationArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType)get_store().find_element_user(CFSCREATION$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "cfsCreation" element
         */
        public int sizeOfCfsCreationArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CFSCREATION$4);
            }
        }
        
        /**
         * Sets array of all "cfsCreation" element
         */
        public void setCfsCreationArray(org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType[] cfsCreationArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(cfsCreationArray, CFSCREATION$4);
            }
        }
        
        /**
         * Sets ith "cfsCreation" element
         */
        public void setCfsCreationArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType cfsCreation)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType)get_store().find_element_user(CFSCREATION$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(cfsCreation);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsCreation" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType insertNewCfsCreation(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType)get_store().insert_element_user(CFSCREATION$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsCreation" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType addNewCfsCreation()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType)get_store().add_element_user(CFSCREATION$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "cfsCreation" element
         */
        public void removeCfsCreation(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CFSCREATION$4, i);
            }
        }
        
        /**
         * Gets a List of "cfsStateChange" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType> getCfsStateChangeList()
        {
            final class CfsStateChangeList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType get(int i)
                    { return ProvisionResponseImpl.this.getCfsStateChangeArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType old = ProvisionResponseImpl.this.getCfsStateChangeArray(i);
                    ProvisionResponseImpl.this.setCfsStateChangeArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType o)
                    { ProvisionResponseImpl.this.insertNewCfsStateChange(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType old = ProvisionResponseImpl.this.getCfsStateChangeArray(i);
                    ProvisionResponseImpl.this.removeCfsStateChange(i);
                    return old;
                }
                
                public int size()
                    { return ProvisionResponseImpl.this.sizeOfCfsStateChangeArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new CfsStateChangeList();
            }
        }
        
        /**
         * Gets array of all "cfsStateChange" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[] getCfsStateChangeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CFSSTATECHANGE$6, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "cfsStateChange" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType getCfsStateChangeArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType)get_store().find_element_user(CFSSTATECHANGE$6, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "cfsStateChange" element
         */
        public int sizeOfCfsStateChangeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CFSSTATECHANGE$6);
            }
        }
        
        /**
         * Sets array of all "cfsStateChange" element
         */
        public void setCfsStateChangeArray(org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[] cfsStateChangeArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(cfsStateChangeArray, CFSSTATECHANGE$6);
            }
        }
        
        /**
         * Sets ith "cfsStateChange" element
         */
        public void setCfsStateChangeArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType cfsStateChange)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType)get_store().find_element_user(CFSSTATECHANGE$6, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(cfsStateChange);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsStateChange" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType insertNewCfsStateChange(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType)get_store().insert_element_user(CFSSTATECHANGE$6, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsStateChange" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType addNewCfsStateChange()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType)get_store().add_element_user(CFSSTATECHANGE$6);
                return target;
            }
        }
        
        /**
         * Removes the ith "cfsStateChange" element
         */
        public void removeCfsStateChange(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CFSSTATECHANGE$6, i);
            }
        }
    }
}
