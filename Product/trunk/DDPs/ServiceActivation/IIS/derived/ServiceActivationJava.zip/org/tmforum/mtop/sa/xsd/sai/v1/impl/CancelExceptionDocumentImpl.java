/*
 * An XML document type.
 * Localname: cancelException
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one cancelException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class CancelExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument
{
    
    public CancelExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CANCELEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "cancelException");
    
    
    /**
     * Gets the "cancelException" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException getCancelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException)get_store().find_element_user(CANCELEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "cancelException" element
     */
    public void setCancelException(org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException cancelException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException)get_store().find_element_user(CANCELEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException)get_store().add_element_user(CANCELEXCEPTION$0);
            }
            target.set(cancelException);
        }
    }
    
    /**
     * Appends and returns a new empty "cancelException" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException addNewCancelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException)get_store().add_element_user(CANCELEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML cancelException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class CancelExceptionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.CancelExceptionDocument.CancelException
    {
        
        public CancelExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName BASICFAILUREEVENT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "basicFailureEvent");
        private static final javax.xml.namespace.QName SERVICEDELETIONFAILUREEVENT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "serviceDeletionFailureEvent");
        
        
        /**
         * Gets a List of "basicFailureEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType> getBasicFailureEventList()
        {
            final class BasicFailureEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType>
            {
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType get(int i)
                    { return CancelExceptionImpl.this.getBasicFailureEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType set(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType o)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType old = CancelExceptionImpl.this.getBasicFailureEventArray(i);
                    CancelExceptionImpl.this.setBasicFailureEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType o)
                    { CancelExceptionImpl.this.insertNewBasicFailureEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType old = CancelExceptionImpl.this.getBasicFailureEventArray(i);
                    CancelExceptionImpl.this.removeBasicFailureEvent(i);
                    return old;
                }
                
                public int size()
                    { return CancelExceptionImpl.this.sizeOfBasicFailureEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new BasicFailureEventList();
            }
        }
        
        /**
         * Gets array of all "basicFailureEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] getBasicFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(BASICFAILUREEVENT$0, targetList);
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] result = new org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType getBasicFailureEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().find_element_user(BASICFAILUREEVENT$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "basicFailureEvent" element
         */
        public int sizeOfBasicFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BASICFAILUREEVENT$0);
            }
        }
        
        /**
         * Sets array of all "basicFailureEvent" element
         */
        public void setBasicFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] basicFailureEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(basicFailureEventArray, BASICFAILUREEVENT$0);
            }
        }
        
        /**
         * Sets ith "basicFailureEvent" element
         */
        public void setBasicFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType basicFailureEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().find_element_user(BASICFAILUREEVENT$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(basicFailureEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType insertNewBasicFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().insert_element_user(BASICFAILUREEVENT$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType addNewBasicFailureEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().add_element_user(BASICFAILUREEVENT$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "basicFailureEvent" element
         */
        public void removeBasicFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BASICFAILUREEVENT$0, i);
            }
        }
        
        /**
         * Gets a List of "serviceDeletionFailureEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType> getServiceDeletionFailureEventList()
        {
            final class ServiceDeletionFailureEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType>
            {
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType get(int i)
                    { return CancelExceptionImpl.this.getServiceDeletionFailureEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType set(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType o)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType old = CancelExceptionImpl.this.getServiceDeletionFailureEventArray(i);
                    CancelExceptionImpl.this.setServiceDeletionFailureEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType o)
                    { CancelExceptionImpl.this.insertNewServiceDeletionFailureEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType old = CancelExceptionImpl.this.getServiceDeletionFailureEventArray(i);
                    CancelExceptionImpl.this.removeServiceDeletionFailureEvent(i);
                    return old;
                }
                
                public int size()
                    { return CancelExceptionImpl.this.sizeOfServiceDeletionFailureEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ServiceDeletionFailureEventList();
            }
        }
        
        /**
         * Gets array of all "serviceDeletionFailureEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType[] getServiceDeletionFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(SERVICEDELETIONFAILUREEVENT$2, targetList);
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType[] result = new org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "serviceDeletionFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType getServiceDeletionFailureEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType)get_store().find_element_user(SERVICEDELETIONFAILUREEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "serviceDeletionFailureEvent" element
         */
        public int sizeOfServiceDeletionFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SERVICEDELETIONFAILUREEVENT$2);
            }
        }
        
        /**
         * Sets array of all "serviceDeletionFailureEvent" element
         */
        public void setServiceDeletionFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType[] serviceDeletionFailureEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(serviceDeletionFailureEventArray, SERVICEDELETIONFAILUREEVENT$2);
            }
        }
        
        /**
         * Sets ith "serviceDeletionFailureEvent" element
         */
        public void setServiceDeletionFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType serviceDeletionFailureEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType)get_store().find_element_user(SERVICEDELETIONFAILUREEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(serviceDeletionFailureEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "serviceDeletionFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType insertNewServiceDeletionFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType)get_store().insert_element_user(SERVICEDELETIONFAILUREEVENT$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "serviceDeletionFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType addNewServiceDeletionFailureEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType)get_store().add_element_user(SERVICEDELETIONFAILUREEVENT$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "serviceDeletionFailureEvent" element
         */
        public void removeServiceDeletionFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SERVICEDELETIONFAILUREEVENT$2, i);
            }
        }
    }
}
