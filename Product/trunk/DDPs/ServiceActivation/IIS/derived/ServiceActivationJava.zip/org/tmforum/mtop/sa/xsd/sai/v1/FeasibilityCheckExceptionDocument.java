/*
 * An XML document type.
 * Localname: feasibilityCheckException
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1;


/**
 * A document containing one feasibilityCheckException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public interface FeasibilityCheckExceptionDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FeasibilityCheckExceptionDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("feasibilitycheckexceptione9d8doctype");
    
    /**
     * Gets the "feasibilityCheckException" element
     */
    org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument.FeasibilityCheckException getFeasibilityCheckException();
    
    /**
     * Sets the "feasibilityCheckException" element
     */
    void setFeasibilityCheckException(org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument.FeasibilityCheckException feasibilityCheckException);
    
    /**
     * Appends and returns a new empty "feasibilityCheckException" element
     */
    org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument.FeasibilityCheckException addNewFeasibilityCheckException();
    
    /**
     * An XML feasibilityCheckException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public interface FeasibilityCheckException extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(FeasibilityCheckException.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("feasibilitycheckexceptionf0acelemtype");
        
        /**
         * Gets a List of "basicFailureEvent" elements
         */
        java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType> getBasicFailureEventList();
        
        /**
         * Gets array of all "basicFailureEvent" elements
         * @deprecated
         */
        org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] getBasicFailureEventArray();
        
        /**
         * Gets ith "basicFailureEvent" element
         */
        org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType getBasicFailureEventArray(int i);
        
        /**
         * Returns number of "basicFailureEvent" element
         */
        int sizeOfBasicFailureEventArray();
        
        /**
         * Sets array of all "basicFailureEvent" element
         */
        void setBasicFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] basicFailureEventArray);
        
        /**
         * Sets ith "basicFailureEvent" element
         */
        void setBasicFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType basicFailureEvent);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "basicFailureEvent" element
         */
        org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType insertNewBasicFailureEvent(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "basicFailureEvent" element
         */
        org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType addNewBasicFailureEvent();
        
        /**
         * Removes the ith "basicFailureEvent" element
         */
        void removeBasicFailureEvent(int i);
        
        /**
         * Gets a List of "serviceCreationFailureEvent" elements
         */
        java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType> getServiceCreationFailureEventList();
        
        /**
         * Gets array of all "serviceCreationFailureEvent" elements
         * @deprecated
         */
        org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType[] getServiceCreationFailureEventArray();
        
        /**
         * Gets ith "serviceCreationFailureEvent" element
         */
        org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType getServiceCreationFailureEventArray(int i);
        
        /**
         * Returns number of "serviceCreationFailureEvent" element
         */
        int sizeOfServiceCreationFailureEventArray();
        
        /**
         * Sets array of all "serviceCreationFailureEvent" element
         */
        void setServiceCreationFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType[] serviceCreationFailureEventArray);
        
        /**
         * Sets ith "serviceCreationFailureEvent" element
         */
        void setServiceCreationFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType serviceCreationFailureEvent);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "serviceCreationFailureEvent" element
         */
        org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType insertNewServiceCreationFailureEvent(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "serviceCreationFailureEvent" element
         */
        org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType addNewServiceCreationFailureEvent();
        
        /**
         * Removes the ith "serviceCreationFailureEvent" element
         */
        void removeServiceCreationFailureEvent(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument.FeasibilityCheckException newInstance() {
              return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument.FeasibilityCheckException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument.FeasibilityCheckException newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument.FeasibilityCheckException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument newInstance() {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
