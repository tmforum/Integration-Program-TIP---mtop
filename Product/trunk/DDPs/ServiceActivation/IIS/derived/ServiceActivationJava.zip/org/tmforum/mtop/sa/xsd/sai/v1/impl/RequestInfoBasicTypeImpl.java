/*
 * XML Type:  RequestInfoBasicType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * An XML RequestInfoBasicType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public class RequestInfoBasicTypeImpl extends org.tmforum.mtop.sa.xsd.sai.v1.impl.RootRequestTypeImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType
{
    
    public RequestInfoBasicTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PRODUCTINFO$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productInfo");
    private static final javax.xml.namespace.QName SUBSCRIBERLIST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "subscriberList");
    private static final javax.xml.namespace.QName USERLIST$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "userList");
    private static final javax.xml.namespace.QName SAPLIST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "sapList");
    
    
    /**
     * Gets the "productInfo" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType getProductInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType)get_store().find_element_user(PRODUCTINFO$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "productInfo" element
     */
    public void setProductInfo(org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType productInfo)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType)get_store().find_element_user(PRODUCTINFO$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType)get_store().add_element_user(PRODUCTINFO$0);
            }
            target.set(productInfo);
        }
    }
    
    /**
     * Appends and returns a new empty "productInfo" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType addNewProductInfo()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType)get_store().add_element_user(PRODUCTINFO$0);
            return target;
        }
    }
    
    /**
     * Gets a List of "subscriberList" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getSubscriberListList()
    {
        final class SubscriberListList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return RequestInfoBasicTypeImpl.this.getSubscriberListArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = RequestInfoBasicTypeImpl.this.getSubscriberListArray(i);
                RequestInfoBasicTypeImpl.this.setSubscriberListArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { RequestInfoBasicTypeImpl.this.insertNewSubscriberList(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = RequestInfoBasicTypeImpl.this.getSubscriberListArray(i);
                RequestInfoBasicTypeImpl.this.removeSubscriberList(i);
                return old;
            }
            
            public int size()
                { return RequestInfoBasicTypeImpl.this.sizeOfSubscriberListArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new SubscriberListList();
        }
    }
    
    /**
     * Gets array of all "subscriberList" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getSubscriberListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SUBSCRIBERLIST$2, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "subscriberList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSubscriberListArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SUBSCRIBERLIST$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "subscriberList" element
     */
    public int sizeOfSubscriberListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SUBSCRIBERLIST$2);
        }
    }
    
    /**
     * Sets array of all "subscriberList" element
     */
    public void setSubscriberListArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] subscriberListArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(subscriberListArray, SUBSCRIBERLIST$2);
        }
    }
    
    /**
     * Sets ith "subscriberList" element
     */
    public void setSubscriberListArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType subscriberList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SUBSCRIBERLIST$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(subscriberList);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "subscriberList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewSubscriberList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(SUBSCRIBERLIST$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "subscriberList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSubscriberList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SUBSCRIBERLIST$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "subscriberList" element
     */
    public void removeSubscriberList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SUBSCRIBERLIST$2, i);
        }
    }
    
    /**
     * Gets a List of "userList" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getUserListList()
    {
        final class UserListList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return RequestInfoBasicTypeImpl.this.getUserListArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = RequestInfoBasicTypeImpl.this.getUserListArray(i);
                RequestInfoBasicTypeImpl.this.setUserListArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { RequestInfoBasicTypeImpl.this.insertNewUserList(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = RequestInfoBasicTypeImpl.this.getUserListArray(i);
                RequestInfoBasicTypeImpl.this.removeUserList(i);
                return old;
            }
            
            public int size()
                { return RequestInfoBasicTypeImpl.this.sizeOfUserListArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new UserListList();
        }
    }
    
    /**
     * Gets array of all "userList" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getUserListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(USERLIST$4, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "userList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getUserListArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(USERLIST$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "userList" element
     */
    public int sizeOfUserListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(USERLIST$4);
        }
    }
    
    /**
     * Sets array of all "userList" element
     */
    public void setUserListArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] userListArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(userListArray, USERLIST$4);
        }
    }
    
    /**
     * Sets ith "userList" element
     */
    public void setUserListArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType userList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(USERLIST$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(userList);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "userList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewUserList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(USERLIST$4, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "userList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewUserList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(USERLIST$4);
            return target;
        }
    }
    
    /**
     * Removes the ith "userList" element
     */
    public void removeUserList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(USERLIST$4, i);
        }
    }
    
    /**
     * Gets a List of "sapList" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getSapListList()
    {
        final class SapListList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return RequestInfoBasicTypeImpl.this.getSapListArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = RequestInfoBasicTypeImpl.this.getSapListArray(i);
                RequestInfoBasicTypeImpl.this.setSapListArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { RequestInfoBasicTypeImpl.this.insertNewSapList(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = RequestInfoBasicTypeImpl.this.getSapListArray(i);
                RequestInfoBasicTypeImpl.this.removeSapList(i);
                return old;
            }
            
            public int size()
                { return RequestInfoBasicTypeImpl.this.sizeOfSapListArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new SapListList();
        }
    }
    
    /**
     * Gets array of all "sapList" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getSapListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SAPLIST$6, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "sapList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSapListArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SAPLIST$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "sapList" element
     */
    public int sizeOfSapListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SAPLIST$6);
        }
    }
    
    /**
     * Sets array of all "sapList" element
     */
    public void setSapListArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] sapListArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(sapListArray, SAPLIST$6);
        }
    }
    
    /**
     * Sets ith "sapList" element
     */
    public void setSapListArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType sapList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SAPLIST$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(sapList);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "sapList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewSapList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(SAPLIST$6, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "sapList" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSapList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SAPLIST$6);
            return target;
        }
    }
    
    /**
     * Removes the ith "sapList" element
     */
    public void removeSapList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SAPLIST$6, i);
        }
    }
}
