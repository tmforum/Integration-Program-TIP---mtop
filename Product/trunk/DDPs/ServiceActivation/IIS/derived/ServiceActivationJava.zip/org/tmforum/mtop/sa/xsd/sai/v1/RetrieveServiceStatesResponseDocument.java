/*
 * An XML document type.
 * Localname: retrieveServiceStatesResponse
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1;


/**
 * A document containing one retrieveServiceStatesResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public interface RetrieveServiceStatesResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RetrieveServiceStatesResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("retrieveservicestatesresponsebd8cdoctype");
    
    /**
     * Gets the "retrieveServiceStatesResponse" element
     */
    org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse getRetrieveServiceStatesResponse();
    
    /**
     * Sets the "retrieveServiceStatesResponse" element
     */
    void setRetrieveServiceStatesResponse(org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse retrieveServiceStatesResponse);
    
    /**
     * Appends and returns a new empty "retrieveServiceStatesResponse" element
     */
    org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse addNewRetrieveServiceStatesResponse();
    
    /**
     * An XML retrieveServiceStatesResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public interface RetrieveServiceStatesResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RetrieveServiceStatesResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("retrieveservicestatesresponse9594elemtype");
        
        /**
         * Gets a List of "cfsName" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getCfsNameList();
        
        /**
         * Gets array of all "cfsName" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getCfsNameArray();
        
        /**
         * Gets ith "cfsName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getCfsNameArray(int i);
        
        /**
         * Returns number of "cfsName" element
         */
        int sizeOfCfsNameArray();
        
        /**
         * Sets array of all "cfsName" element
         */
        void setCfsNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] cfsNameArray);
        
        /**
         * Sets ith "cfsName" element
         */
        void setCfsNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType cfsName);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewCfsName(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsName" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewCfsName();
        
        /**
         * Removes the ith "cfsName" element
         */
        void removeCfsName(int i);
        
        /**
         * Gets a List of "cfsState" elements
         */
        java.util.List<java.lang.String> getCfsStateList();
        
        /**
         * Gets array of all "cfsState" elements
         * @deprecated
         */
        java.lang.String[] getCfsStateArray();
        
        /**
         * Gets ith "cfsState" element
         */
        java.lang.String getCfsStateArray(int i);
        
        /**
         * Gets (as xml) a List of "cfsState" elements
         */
        java.util.List<org.apache.xmlbeans.XmlString> xgetCfsStateList();
        
        /**
         * Gets (as xml) array of all "cfsState" elements
         * @deprecated
         */
        org.apache.xmlbeans.XmlString[] xgetCfsStateArray();
        
        /**
         * Gets (as xml) ith "cfsState" element
         */
        org.apache.xmlbeans.XmlString xgetCfsStateArray(int i);
        
        /**
         * Returns number of "cfsState" element
         */
        int sizeOfCfsStateArray();
        
        /**
         * Sets array of all "cfsState" element
         */
        void setCfsStateArray(java.lang.String[] cfsStateArray);
        
        /**
         * Sets ith "cfsState" element
         */
        void setCfsStateArray(int i, java.lang.String cfsState);
        
        /**
         * Sets (as xml) array of all "cfsState" element
         */
        void xsetCfsStateArray(org.apache.xmlbeans.XmlString[] cfsStateArray);
        
        /**
         * Sets (as xml) ith "cfsState" element
         */
        void xsetCfsStateArray(int i, org.apache.xmlbeans.XmlString cfsState);
        
        /**
         * Inserts the value as the ith "cfsState" element
         */
        void insertCfsState(int i, java.lang.String cfsState);
        
        /**
         * Appends the value as the last "cfsState" element
         */
        void addCfsState(java.lang.String cfsState);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsState" element
         */
        org.apache.xmlbeans.XmlString insertNewCfsState(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsState" element
         */
        org.apache.xmlbeans.XmlString addNewCfsState();
        
        /**
         * Removes the ith "cfsState" element
         */
        void removeCfsState(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse newInstance() {
              return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument.RetrieveServiceStatesResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument newInstance() {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
