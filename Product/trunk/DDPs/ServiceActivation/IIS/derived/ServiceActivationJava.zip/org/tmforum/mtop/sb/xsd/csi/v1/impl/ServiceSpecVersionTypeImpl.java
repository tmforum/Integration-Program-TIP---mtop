/*
 * XML Type:  ServiceSpecVersionType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML ServiceSpecVersionType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public class ServiceSpecVersionTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType
{
    
    public ServiceSpecVersionTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SVCSPECREVISIONNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "svcSpecRevisionName");
    private static final javax.xml.namespace.QName SVCSPECREVISIONFORMAT$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "svcSpecRevisionFormat");
    private static final javax.xml.namespace.QName SVCSPECREVISIONNUMBER$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "svcSpecRevisionNumber");
    private static final javax.xml.namespace.QName SVCSPECREVISIONREASON$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "svcSpecRevisionReason");
    private static final javax.xml.namespace.QName SVCSPECREVISIONSEMANTICS$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "svcSpecRevisionSemantics");
    private static final javax.xml.namespace.QName SVCSPECREVISIONTIMESTAMP$10 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "svcSpecRevisionTimestamp");
    private static final javax.xml.namespace.QName SVCSPECREVISIONVALIDITYPERIOD$12 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "svcSpecRevisionValidityPeriod");
    
    
    /**
     * Gets the "svcSpecRevisionName" element
     */
    public java.lang.String getSvcSpecRevisionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "svcSpecRevisionName" element
     */
    public org.apache.xmlbeans.XmlString xgetSvcSpecRevisionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONNAME$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "svcSpecRevisionName" element
     */
    public boolean isSetSvcSpecRevisionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SVCSPECREVISIONNAME$0) != 0;
        }
    }
    
    /**
     * Sets the "svcSpecRevisionName" element
     */
    public void setSvcSpecRevisionName(java.lang.String svcSpecRevisionName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONNAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SVCSPECREVISIONNAME$0);
            }
            target.setStringValue(svcSpecRevisionName);
        }
    }
    
    /**
     * Sets (as xml) the "svcSpecRevisionName" element
     */
    public void xsetSvcSpecRevisionName(org.apache.xmlbeans.XmlString svcSpecRevisionName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONNAME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SVCSPECREVISIONNAME$0);
            }
            target.set(svcSpecRevisionName);
        }
    }
    
    /**
     * Unsets the "svcSpecRevisionName" element
     */
    public void unsetSvcSpecRevisionName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SVCSPECREVISIONNAME$0, 0);
        }
    }
    
    /**
     * Gets the "svcSpecRevisionFormat" element
     */
    public java.lang.String getSvcSpecRevisionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONFORMAT$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "svcSpecRevisionFormat" element
     */
    public org.apache.xmlbeans.XmlString xgetSvcSpecRevisionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONFORMAT$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "svcSpecRevisionFormat" element
     */
    public boolean isSetSvcSpecRevisionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SVCSPECREVISIONFORMAT$2) != 0;
        }
    }
    
    /**
     * Sets the "svcSpecRevisionFormat" element
     */
    public void setSvcSpecRevisionFormat(java.lang.String svcSpecRevisionFormat)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONFORMAT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SVCSPECREVISIONFORMAT$2);
            }
            target.setStringValue(svcSpecRevisionFormat);
        }
    }
    
    /**
     * Sets (as xml) the "svcSpecRevisionFormat" element
     */
    public void xsetSvcSpecRevisionFormat(org.apache.xmlbeans.XmlString svcSpecRevisionFormat)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONFORMAT$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SVCSPECREVISIONFORMAT$2);
            }
            target.set(svcSpecRevisionFormat);
        }
    }
    
    /**
     * Unsets the "svcSpecRevisionFormat" element
     */
    public void unsetSvcSpecRevisionFormat()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SVCSPECREVISIONFORMAT$2, 0);
        }
    }
    
    /**
     * Gets the "svcSpecRevisionNumber" element
     */
    public java.lang.String getSvcSpecRevisionNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONNUMBER$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "svcSpecRevisionNumber" element
     */
    public org.apache.xmlbeans.XmlString xgetSvcSpecRevisionNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONNUMBER$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "svcSpecRevisionNumber" element
     */
    public boolean isSetSvcSpecRevisionNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SVCSPECREVISIONNUMBER$4) != 0;
        }
    }
    
    /**
     * Sets the "svcSpecRevisionNumber" element
     */
    public void setSvcSpecRevisionNumber(java.lang.String svcSpecRevisionNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONNUMBER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SVCSPECREVISIONNUMBER$4);
            }
            target.setStringValue(svcSpecRevisionNumber);
        }
    }
    
    /**
     * Sets (as xml) the "svcSpecRevisionNumber" element
     */
    public void xsetSvcSpecRevisionNumber(org.apache.xmlbeans.XmlString svcSpecRevisionNumber)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONNUMBER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SVCSPECREVISIONNUMBER$4);
            }
            target.set(svcSpecRevisionNumber);
        }
    }
    
    /**
     * Unsets the "svcSpecRevisionNumber" element
     */
    public void unsetSvcSpecRevisionNumber()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SVCSPECREVISIONNUMBER$4, 0);
        }
    }
    
    /**
     * Gets the "svcSpecRevisionReason" element
     */
    public java.lang.String getSvcSpecRevisionReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONREASON$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "svcSpecRevisionReason" element
     */
    public org.apache.xmlbeans.XmlString xgetSvcSpecRevisionReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONREASON$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "svcSpecRevisionReason" element
     */
    public boolean isSetSvcSpecRevisionReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SVCSPECREVISIONREASON$6) != 0;
        }
    }
    
    /**
     * Sets the "svcSpecRevisionReason" element
     */
    public void setSvcSpecRevisionReason(java.lang.String svcSpecRevisionReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONREASON$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SVCSPECREVISIONREASON$6);
            }
            target.setStringValue(svcSpecRevisionReason);
        }
    }
    
    /**
     * Sets (as xml) the "svcSpecRevisionReason" element
     */
    public void xsetSvcSpecRevisionReason(org.apache.xmlbeans.XmlString svcSpecRevisionReason)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONREASON$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SVCSPECREVISIONREASON$6);
            }
            target.set(svcSpecRevisionReason);
        }
    }
    
    /**
     * Unsets the "svcSpecRevisionReason" element
     */
    public void unsetSvcSpecRevisionReason()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SVCSPECREVISIONREASON$6, 0);
        }
    }
    
    /**
     * Gets the "svcSpecRevisionSemantics" element
     */
    public java.lang.String getSvcSpecRevisionSemantics()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONSEMANTICS$8, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "svcSpecRevisionSemantics" element
     */
    public org.apache.xmlbeans.XmlString xgetSvcSpecRevisionSemantics()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONSEMANTICS$8, 0);
            return target;
        }
    }
    
    /**
     * True if has "svcSpecRevisionSemantics" element
     */
    public boolean isSetSvcSpecRevisionSemantics()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SVCSPECREVISIONSEMANTICS$8) != 0;
        }
    }
    
    /**
     * Sets the "svcSpecRevisionSemantics" element
     */
    public void setSvcSpecRevisionSemantics(java.lang.String svcSpecRevisionSemantics)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONSEMANTICS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SVCSPECREVISIONSEMANTICS$8);
            }
            target.setStringValue(svcSpecRevisionSemantics);
        }
    }
    
    /**
     * Sets (as xml) the "svcSpecRevisionSemantics" element
     */
    public void xsetSvcSpecRevisionSemantics(org.apache.xmlbeans.XmlString svcSpecRevisionSemantics)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SVCSPECREVISIONSEMANTICS$8, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SVCSPECREVISIONSEMANTICS$8);
            }
            target.set(svcSpecRevisionSemantics);
        }
    }
    
    /**
     * Unsets the "svcSpecRevisionSemantics" element
     */
    public void unsetSvcSpecRevisionSemantics()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SVCSPECREVISIONSEMANTICS$8, 0);
        }
    }
    
    /**
     * Gets the "svcSpecRevisionTimestamp" element
     */
    public java.util.Calendar getSvcSpecRevisionTimestamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONTIMESTAMP$10, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "svcSpecRevisionTimestamp" element
     */
    public org.apache.xmlbeans.XmlDate xgetSvcSpecRevisionTimestamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(SVCSPECREVISIONTIMESTAMP$10, 0);
            return target;
        }
    }
    
    /**
     * True if has "svcSpecRevisionTimestamp" element
     */
    public boolean isSetSvcSpecRevisionTimestamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SVCSPECREVISIONTIMESTAMP$10) != 0;
        }
    }
    
    /**
     * Sets the "svcSpecRevisionTimestamp" element
     */
    public void setSvcSpecRevisionTimestamp(java.util.Calendar svcSpecRevisionTimestamp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SVCSPECREVISIONTIMESTAMP$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SVCSPECREVISIONTIMESTAMP$10);
            }
            target.setCalendarValue(svcSpecRevisionTimestamp);
        }
    }
    
    /**
     * Sets (as xml) the "svcSpecRevisionTimestamp" element
     */
    public void xsetSvcSpecRevisionTimestamp(org.apache.xmlbeans.XmlDate svcSpecRevisionTimestamp)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDate target = null;
            target = (org.apache.xmlbeans.XmlDate)get_store().find_element_user(SVCSPECREVISIONTIMESTAMP$10, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDate)get_store().add_element_user(SVCSPECREVISIONTIMESTAMP$10);
            }
            target.set(svcSpecRevisionTimestamp);
        }
    }
    
    /**
     * Unsets the "svcSpecRevisionTimestamp" element
     */
    public void unsetSvcSpecRevisionTimestamp()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SVCSPECREVISIONTIMESTAMP$10, 0);
        }
    }
    
    /**
     * Gets the "svcSpecRevisionValidityPeriod" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType getSvcSpecRevisionValidityPeriod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(SVCSPECREVISIONVALIDITYPERIOD$12, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "svcSpecRevisionValidityPeriod" element
     */
    public boolean isSetSvcSpecRevisionValidityPeriod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SVCSPECREVISIONVALIDITYPERIOD$12) != 0;
        }
    }
    
    /**
     * Sets the "svcSpecRevisionValidityPeriod" element
     */
    public void setSvcSpecRevisionValidityPeriod(org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType svcSpecRevisionValidityPeriod)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(SVCSPECREVISIONVALIDITYPERIOD$12, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(SVCSPECREVISIONVALIDITYPERIOD$12);
            }
            target.set(svcSpecRevisionValidityPeriod);
        }
    }
    
    /**
     * Appends and returns a new empty "svcSpecRevisionValidityPeriod" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType addNewSvcSpecRevisionValidityPeriod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(SVCSPECREVISIONVALIDITYPERIOD$12);
            return target;
        }
    }
    
    /**
     * Unsets the "svcSpecRevisionValidityPeriod" element
     */
    public void unsetSvcSpecRevisionValidityPeriod()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SVCSPECREVISIONVALIDITYPERIOD$12, 0);
        }
    }
}
