/*
 * XML Type:  ServiceCharValueType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML ServiceCharValueType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public class ServiceCharValueTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sb.xsd.csi.v1.ServiceCharValueType
{
    
    public ServiceCharValueTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VALUE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "value");
    private static final javax.xml.namespace.QName VALIDFOR$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "validFor");
    private static final javax.xml.namespace.QName SERVICESPECCHARACTERISTIC$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "serviceSpecCharacteristic");
    
    
    /**
     * Gets the "value" element
     */
    public java.lang.String getValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "value" element
     */
    public org.apache.xmlbeans.XmlString xgetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUE$0, 0);
            return target;
        }
    }
    
    /**
     * True if has "value" element
     */
    public boolean isSetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALUE$0) != 0;
        }
    }
    
    /**
     * Sets the "value" element
     */
    public void setValue(java.lang.String value)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALUE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALUE$0);
            }
            target.setStringValue(value);
        }
    }
    
    /**
     * Sets (as xml) the "value" element
     */
    public void xsetValue(org.apache.xmlbeans.XmlString value)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(VALUE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(VALUE$0);
            }
            target.set(value);
        }
    }
    
    /**
     * Unsets the "value" element
     */
    public void unsetValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALUE$0, 0);
        }
    }
    
    /**
     * Gets the "validFor" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType getValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(VALIDFOR$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "validFor" element
     */
    public boolean isSetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALIDFOR$2) != 0;
        }
    }
    
    /**
     * Sets the "validFor" element
     */
    public void setValidFor(org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType validFor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(VALIDFOR$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(VALIDFOR$2);
            }
            target.set(validFor);
        }
    }
    
    /**
     * Appends and returns a new empty "validFor" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType addNewValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(VALIDFOR$2);
            return target;
        }
    }
    
    /**
     * Unsets the "validFor" element
     */
    public void unsetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALIDFOR$2, 0);
        }
    }
    
    /**
     * Gets the "serviceSpecCharacteristic" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType getServiceSpecCharacteristic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType)get_store().find_element_user(SERVICESPECCHARACTERISTIC$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "serviceSpecCharacteristic" element
     */
    public boolean isSetServiceSpecCharacteristic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESPECCHARACTERISTIC$4) != 0;
        }
    }
    
    /**
     * Sets the "serviceSpecCharacteristic" element
     */
    public void setServiceSpecCharacteristic(org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType serviceSpecCharacteristic)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType)get_store().find_element_user(SERVICESPECCHARACTERISTIC$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType)get_store().add_element_user(SERVICESPECCHARACTERISTIC$4);
            }
            target.set(serviceSpecCharacteristic);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceSpecCharacteristic" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType addNewServiceSpecCharacteristic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecCharType)get_store().add_element_user(SERVICESPECCHARACTERISTIC$4);
            return target;
        }
    }
    
    /**
     * Unsets the "serviceSpecCharacteristic" element
     */
    public void unsetServiceSpecCharacteristic()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESPECCHARACTERISTIC$4, 0);
        }
    }
}
