/*
 * XML Type:  RequestInfoBasicType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1;


/**
 * An XML RequestInfoBasicType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public interface RequestInfoBasicType extends org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RequestInfoBasicType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("requestinfobasictypee3bdtype");
    
    /**
     * Gets the "productInfo" element
     */
    org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType getProductInfo();
    
    /**
     * Sets the "productInfo" element
     */
    void setProductInfo(org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType productInfo);
    
    /**
     * Appends and returns a new empty "productInfo" element
     */
    org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType addNewProductInfo();
    
    /**
     * Gets a List of "subscriberList" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getSubscriberListList();
    
    /**
     * Gets array of all "subscriberList" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getSubscriberListArray();
    
    /**
     * Gets ith "subscriberList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSubscriberListArray(int i);
    
    /**
     * Returns number of "subscriberList" element
     */
    int sizeOfSubscriberListArray();
    
    /**
     * Sets array of all "subscriberList" element
     */
    void setSubscriberListArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] subscriberListArray);
    
    /**
     * Sets ith "subscriberList" element
     */
    void setSubscriberListArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType subscriberList);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "subscriberList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewSubscriberList(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "subscriberList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSubscriberList();
    
    /**
     * Removes the ith "subscriberList" element
     */
    void removeSubscriberList(int i);
    
    /**
     * Gets a List of "userList" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getUserListList();
    
    /**
     * Gets array of all "userList" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getUserListArray();
    
    /**
     * Gets ith "userList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getUserListArray(int i);
    
    /**
     * Returns number of "userList" element
     */
    int sizeOfUserListArray();
    
    /**
     * Sets array of all "userList" element
     */
    void setUserListArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] userListArray);
    
    /**
     * Sets ith "userList" element
     */
    void setUserListArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType userList);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "userList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewUserList(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "userList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewUserList();
    
    /**
     * Removes the ith "userList" element
     */
    void removeUserList(int i);
    
    /**
     * Gets a List of "sapList" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getSapListList();
    
    /**
     * Gets array of all "sapList" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getSapListArray();
    
    /**
     * Gets ith "sapList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getSapListArray(int i);
    
    /**
     * Returns number of "sapList" element
     */
    int sizeOfSapListArray();
    
    /**
     * Sets array of all "sapList" element
     */
    void setSapListArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] sapListArray);
    
    /**
     * Sets ith "sapList" element
     */
    void setSapListArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType sapList);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "sapList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewSapList(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "sapList" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewSapList();
    
    /**
     * Removes the ith "sapList" element
     */
    void removeSapList(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType newInstance() {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
