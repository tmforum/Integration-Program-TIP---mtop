/*
 * An XML document type.
 * Localname: retireResponse
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one retireResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class RetireResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument
{
    
    public RetireResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RETIRERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "retireResponse");
    
    
    /**
     * Gets the "retireResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse getRetireResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse)get_store().find_element_user(RETIRERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "retireResponse" element
     */
    public void setRetireResponse(org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse retireResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse)get_store().find_element_user(RETIRERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse)get_store().add_element_user(RETIRERESPONSE$0);
            }
            target.set(retireResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "retireResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse addNewRetireResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse)get_store().add_element_user(RETIRERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML retireResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class RetireResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RetireResponseDocument.RetireResponse
    {
        
        public RetireResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INITIALRESPONSE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "initialResponse");
        private static final javax.xml.namespace.QName BEGINPROCESSINGEVENT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "beginProcessingEvent");
        private static final javax.xml.namespace.QName CFSDELETEEVENT$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "cfsDeleteEvent");
        
        
        /**
         * Gets a List of "initialResponse" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType> getInitialResponseList()
        {
            final class InitialResponseList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType get(int i)
                    { return RetireResponseImpl.this.getInitialResponseArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType old = RetireResponseImpl.this.getInitialResponseArray(i);
                    RetireResponseImpl.this.setInitialResponseArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType o)
                    { RetireResponseImpl.this.insertNewInitialResponse(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType old = RetireResponseImpl.this.getInitialResponseArray(i);
                    RetireResponseImpl.this.removeInitialResponse(i);
                    return old;
                }
                
                public int size()
                    { return RetireResponseImpl.this.sizeOfInitialResponseArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new InitialResponseList();
            }
        }
        
        /**
         * Gets array of all "initialResponse" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] getInitialResponseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(INITIALRESPONSE$0, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType getInitialResponseArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().find_element_user(INITIALRESPONSE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "initialResponse" element
         */
        public int sizeOfInitialResponseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INITIALRESPONSE$0);
            }
        }
        
        /**
         * Sets array of all "initialResponse" element
         */
        public void setInitialResponseArray(org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] initialResponseArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(initialResponseArray, INITIALRESPONSE$0);
            }
        }
        
        /**
         * Sets ith "initialResponse" element
         */
        public void setInitialResponseArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType initialResponse)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().find_element_user(INITIALRESPONSE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(initialResponse);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType insertNewInitialResponse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().insert_element_user(INITIALRESPONSE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType addNewInitialResponse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().add_element_user(INITIALRESPONSE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "initialResponse" element
         */
        public void removeInitialResponse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INITIALRESPONSE$0, i);
            }
        }
        
        /**
         * Gets a List of "beginProcessingEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType> getBeginProcessingEventList()
        {
            final class BeginProcessingEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType get(int i)
                    { return RetireResponseImpl.this.getBeginProcessingEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType old = RetireResponseImpl.this.getBeginProcessingEventArray(i);
                    RetireResponseImpl.this.setBeginProcessingEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType o)
                    { RetireResponseImpl.this.insertNewBeginProcessingEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType old = RetireResponseImpl.this.getBeginProcessingEventArray(i);
                    RetireResponseImpl.this.removeBeginProcessingEvent(i);
                    return old;
                }
                
                public int size()
                    { return RetireResponseImpl.this.sizeOfBeginProcessingEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new BeginProcessingEventList();
            }
        }
        
        /**
         * Gets array of all "beginProcessingEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] getBeginProcessingEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(BEGINPROCESSINGEVENT$2, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType getBeginProcessingEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().find_element_user(BEGINPROCESSINGEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "beginProcessingEvent" element
         */
        public int sizeOfBeginProcessingEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BEGINPROCESSINGEVENT$2);
            }
        }
        
        /**
         * Sets array of all "beginProcessingEvent" element
         */
        public void setBeginProcessingEventArray(org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] beginProcessingEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(beginProcessingEventArray, BEGINPROCESSINGEVENT$2);
            }
        }
        
        /**
         * Sets ith "beginProcessingEvent" element
         */
        public void setBeginProcessingEventArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType beginProcessingEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().find_element_user(BEGINPROCESSINGEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(beginProcessingEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType insertNewBeginProcessingEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().insert_element_user(BEGINPROCESSINGEVENT$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType addNewBeginProcessingEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().add_element_user(BEGINPROCESSINGEVENT$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "beginProcessingEvent" element
         */
        public void removeBeginProcessingEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BEGINPROCESSINGEVENT$2, i);
            }
        }
        
        /**
         * Gets a List of "cfsDeleteEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType> getCfsDeleteEventList()
        {
            final class CfsDeleteEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType get(int i)
                    { return RetireResponseImpl.this.getCfsDeleteEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType old = RetireResponseImpl.this.getCfsDeleteEventArray(i);
                    RetireResponseImpl.this.setCfsDeleteEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType o)
                    { RetireResponseImpl.this.insertNewCfsDeleteEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType old = RetireResponseImpl.this.getCfsDeleteEventArray(i);
                    RetireResponseImpl.this.removeCfsDeleteEvent(i);
                    return old;
                }
                
                public int size()
                    { return RetireResponseImpl.this.sizeOfCfsDeleteEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new CfsDeleteEventList();
            }
        }
        
        /**
         * Gets array of all "cfsDeleteEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType[] getCfsDeleteEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CFSDELETEEVENT$4, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "cfsDeleteEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType getCfsDeleteEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType)get_store().find_element_user(CFSDELETEEVENT$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "cfsDeleteEvent" element
         */
        public int sizeOfCfsDeleteEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CFSDELETEEVENT$4);
            }
        }
        
        /**
         * Sets array of all "cfsDeleteEvent" element
         */
        public void setCfsDeleteEventArray(org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType[] cfsDeleteEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(cfsDeleteEventArray, CFSDELETEEVENT$4);
            }
        }
        
        /**
         * Sets ith "cfsDeleteEvent" element
         */
        public void setCfsDeleteEventArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType cfsDeleteEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType)get_store().find_element_user(CFSDELETEEVENT$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(cfsDeleteEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsDeleteEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType insertNewCfsDeleteEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType)get_store().insert_element_user(CFSDELETEEVENT$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsDeleteEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType addNewCfsDeleteEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType)get_store().add_element_user(CFSDELETEEVENT$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "cfsDeleteEvent" element
         */
        public void removeCfsDeleteEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CFSDELETEEVENT$4, i);
            }
        }
    }
}
