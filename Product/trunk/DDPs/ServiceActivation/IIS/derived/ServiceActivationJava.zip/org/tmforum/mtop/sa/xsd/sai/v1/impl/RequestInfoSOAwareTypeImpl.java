/*
 * XML Type:  RequestInfoSOAwareType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * An XML RequestInfoSOAwareType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public class RequestInfoSOAwareTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType
{
    
    public RequestInfoSOAwareTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName REQUESTEDCOMPLETIONDATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "requestedCompletionDate");
    private static final javax.xml.namespace.QName PRIORITY$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "priority");
    private static final javax.xml.namespace.QName PURCHASEORDER$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "purchaseOrder");
    private static final javax.xml.namespace.QName VALIDFOR$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "validFor");
    
    
    /**
     * Gets the "requestedCompletionDate" element
     */
    public java.util.Calendar getRequestedCompletionDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REQUESTEDCOMPLETIONDATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "requestedCompletionDate" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetRequestedCompletionDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(REQUESTEDCOMPLETIONDATE$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "requestedCompletionDate" element
     */
    public void setRequestedCompletionDate(java.util.Calendar requestedCompletionDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(REQUESTEDCOMPLETIONDATE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(REQUESTEDCOMPLETIONDATE$0);
            }
            target.setCalendarValue(requestedCompletionDate);
        }
    }
    
    /**
     * Sets (as xml) the "requestedCompletionDate" element
     */
    public void xsetRequestedCompletionDate(org.apache.xmlbeans.XmlDateTime requestedCompletionDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(REQUESTEDCOMPLETIONDATE$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(REQUESTEDCOMPLETIONDATE$0);
            }
            target.set(requestedCompletionDate);
        }
    }
    
    /**
     * Gets the "priority" element
     */
    public java.math.BigInteger getPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getBigIntegerValue();
        }
    }
    
    /**
     * Gets (as xml) the "priority" element
     */
    public org.apache.xmlbeans.XmlInteger xgetPriority()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInteger target = null;
            target = (org.apache.xmlbeans.XmlInteger)get_store().find_element_user(PRIORITY$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "priority" element
     */
    public void setPriority(java.math.BigInteger priority)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRIORITY$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRIORITY$2);
            }
            target.setBigIntegerValue(priority);
        }
    }
    
    /**
     * Sets (as xml) the "priority" element
     */
    public void xsetPriority(org.apache.xmlbeans.XmlInteger priority)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlInteger target = null;
            target = (org.apache.xmlbeans.XmlInteger)get_store().find_element_user(PRIORITY$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlInteger)get_store().add_element_user(PRIORITY$2);
            }
            target.set(priority);
        }
    }
    
    /**
     * Gets the "purchaseOrder" element
     */
    public java.lang.String getPurchaseOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PURCHASEORDER$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "purchaseOrder" element
     */
    public org.apache.xmlbeans.XmlString xgetPurchaseOrder()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PURCHASEORDER$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "purchaseOrder" element
     */
    public void setPurchaseOrder(java.lang.String purchaseOrder)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PURCHASEORDER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PURCHASEORDER$4);
            }
            target.setStringValue(purchaseOrder);
        }
    }
    
    /**
     * Sets (as xml) the "purchaseOrder" element
     */
    public void xsetPurchaseOrder(org.apache.xmlbeans.XmlString purchaseOrder)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PURCHASEORDER$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PURCHASEORDER$4);
            }
            target.set(purchaseOrder);
        }
    }
    
    /**
     * Gets the "validFor" element
     */
    public java.util.Calendar getValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALIDFOR$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "validFor" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(VALIDFOR$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "validFor" element
     */
    public void setValidFor(java.util.Calendar validFor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(VALIDFOR$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(VALIDFOR$6);
            }
            target.setCalendarValue(validFor);
        }
    }
    
    /**
     * Sets (as xml) the "validFor" element
     */
    public void xsetValidFor(org.apache.xmlbeans.XmlDateTime validFor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(VALIDFOR$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(VALIDFOR$6);
            }
            target.set(validFor);
        }
    }
}
