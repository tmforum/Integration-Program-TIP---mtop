/*
 * XML Type:  ServiceStateType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML ServiceStateType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType.
 */
public class ServiceStateTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.sb.xsd.csi.v1.ServiceStateType
{
    
    public ServiceStateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected ServiceStateTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
