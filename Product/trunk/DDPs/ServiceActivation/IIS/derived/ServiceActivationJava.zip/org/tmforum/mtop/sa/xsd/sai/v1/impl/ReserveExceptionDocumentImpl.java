/*
 * An XML document type.
 * Localname: reserveException
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one reserveException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class ReserveExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument
{
    
    public ReserveExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RESERVEEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "reserveException");
    
    
    /**
     * Gets the "reserveException" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException getReserveException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException)get_store().find_element_user(RESERVEEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "reserveException" element
     */
    public void setReserveException(org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException reserveException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException)get_store().find_element_user(RESERVEEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException)get_store().add_element_user(RESERVEEXCEPTION$0);
            }
            target.set(reserveException);
        }
    }
    
    /**
     * Appends and returns a new empty "reserveException" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException addNewReserveException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException)get_store().add_element_user(RESERVEEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML reserveException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class ReserveExceptionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ReserveExceptionDocument.ReserveException
    {
        
        public ReserveExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName BASICFAILUREEVENT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "basicFailureEvent");
        private static final javax.xml.namespace.QName SERVICECREATIONFAILUREEVENT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "serviceCreationFailureEvent");
        private static final javax.xml.namespace.QName SERVICESTATETRANSITIONFAILUREEVENT$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "serviceStateTransitionFailureEvent");
        
        
        /**
         * Gets a List of "basicFailureEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType> getBasicFailureEventList()
        {
            final class BasicFailureEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType>
            {
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType get(int i)
                    { return ReserveExceptionImpl.this.getBasicFailureEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType set(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType o)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType old = ReserveExceptionImpl.this.getBasicFailureEventArray(i);
                    ReserveExceptionImpl.this.setBasicFailureEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType o)
                    { ReserveExceptionImpl.this.insertNewBasicFailureEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType old = ReserveExceptionImpl.this.getBasicFailureEventArray(i);
                    ReserveExceptionImpl.this.removeBasicFailureEvent(i);
                    return old;
                }
                
                public int size()
                    { return ReserveExceptionImpl.this.sizeOfBasicFailureEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new BasicFailureEventList();
            }
        }
        
        /**
         * Gets array of all "basicFailureEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] getBasicFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(BASICFAILUREEVENT$0, targetList);
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] result = new org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType getBasicFailureEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().find_element_user(BASICFAILUREEVENT$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "basicFailureEvent" element
         */
        public int sizeOfBasicFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BASICFAILUREEVENT$0);
            }
        }
        
        /**
         * Sets array of all "basicFailureEvent" element
         */
        public void setBasicFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] basicFailureEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(basicFailureEventArray, BASICFAILUREEVENT$0);
            }
        }
        
        /**
         * Sets ith "basicFailureEvent" element
         */
        public void setBasicFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType basicFailureEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().find_element_user(BASICFAILUREEVENT$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(basicFailureEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType insertNewBasicFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().insert_element_user(BASICFAILUREEVENT$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType addNewBasicFailureEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().add_element_user(BASICFAILUREEVENT$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "basicFailureEvent" element
         */
        public void removeBasicFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BASICFAILUREEVENT$0, i);
            }
        }
        
        /**
         * Gets a List of "serviceCreationFailureEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType> getServiceCreationFailureEventList()
        {
            final class ServiceCreationFailureEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType>
            {
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType get(int i)
                    { return ReserveExceptionImpl.this.getServiceCreationFailureEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType set(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType o)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType old = ReserveExceptionImpl.this.getServiceCreationFailureEventArray(i);
                    ReserveExceptionImpl.this.setServiceCreationFailureEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType o)
                    { ReserveExceptionImpl.this.insertNewServiceCreationFailureEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType old = ReserveExceptionImpl.this.getServiceCreationFailureEventArray(i);
                    ReserveExceptionImpl.this.removeServiceCreationFailureEvent(i);
                    return old;
                }
                
                public int size()
                    { return ReserveExceptionImpl.this.sizeOfServiceCreationFailureEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ServiceCreationFailureEventList();
            }
        }
        
        /**
         * Gets array of all "serviceCreationFailureEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType[] getServiceCreationFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(SERVICECREATIONFAILUREEVENT$2, targetList);
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType[] result = new org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "serviceCreationFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType getServiceCreationFailureEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType)get_store().find_element_user(SERVICECREATIONFAILUREEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "serviceCreationFailureEvent" element
         */
        public int sizeOfServiceCreationFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SERVICECREATIONFAILUREEVENT$2);
            }
        }
        
        /**
         * Sets array of all "serviceCreationFailureEvent" element
         */
        public void setServiceCreationFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType[] serviceCreationFailureEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(serviceCreationFailureEventArray, SERVICECREATIONFAILUREEVENT$2);
            }
        }
        
        /**
         * Sets ith "serviceCreationFailureEvent" element
         */
        public void setServiceCreationFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType serviceCreationFailureEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType)get_store().find_element_user(SERVICECREATIONFAILUREEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(serviceCreationFailureEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "serviceCreationFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType insertNewServiceCreationFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType)get_store().insert_element_user(SERVICECREATIONFAILUREEVENT$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "serviceCreationFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType addNewServiceCreationFailureEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType)get_store().add_element_user(SERVICECREATIONFAILUREEVENT$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "serviceCreationFailureEvent" element
         */
        public void removeServiceCreationFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SERVICECREATIONFAILUREEVENT$2, i);
            }
        }
        
        /**
         * Gets a List of "serviceStateTransitionFailureEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType> getServiceStateTransitionFailureEventList()
        {
            final class ServiceStateTransitionFailureEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType>
            {
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType get(int i)
                    { return ReserveExceptionImpl.this.getServiceStateTransitionFailureEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType set(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType o)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType old = ReserveExceptionImpl.this.getServiceStateTransitionFailureEventArray(i);
                    ReserveExceptionImpl.this.setServiceStateTransitionFailureEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType o)
                    { ReserveExceptionImpl.this.insertNewServiceStateTransitionFailureEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType old = ReserveExceptionImpl.this.getServiceStateTransitionFailureEventArray(i);
                    ReserveExceptionImpl.this.removeServiceStateTransitionFailureEvent(i);
                    return old;
                }
                
                public int size()
                    { return ReserveExceptionImpl.this.sizeOfServiceStateTransitionFailureEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ServiceStateTransitionFailureEventList();
            }
        }
        
        /**
         * Gets array of all "serviceStateTransitionFailureEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType[] getServiceStateTransitionFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(SERVICESTATETRANSITIONFAILUREEVENT$4, targetList);
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType[] result = new org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "serviceStateTransitionFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType getServiceStateTransitionFailureEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType)get_store().find_element_user(SERVICESTATETRANSITIONFAILUREEVENT$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "serviceStateTransitionFailureEvent" element
         */
        public int sizeOfServiceStateTransitionFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SERVICESTATETRANSITIONFAILUREEVENT$4);
            }
        }
        
        /**
         * Sets array of all "serviceStateTransitionFailureEvent" element
         */
        public void setServiceStateTransitionFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType[] serviceStateTransitionFailureEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(serviceStateTransitionFailureEventArray, SERVICESTATETRANSITIONFAILUREEVENT$4);
            }
        }
        
        /**
         * Sets ith "serviceStateTransitionFailureEvent" element
         */
        public void setServiceStateTransitionFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType serviceStateTransitionFailureEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType)get_store().find_element_user(SERVICESTATETRANSITIONFAILUREEVENT$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(serviceStateTransitionFailureEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "serviceStateTransitionFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType insertNewServiceStateTransitionFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType)get_store().insert_element_user(SERVICESTATETRANSITIONFAILUREEVENT$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "serviceStateTransitionFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType addNewServiceStateTransitionFailureEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceStateTransitionFailureEventType)get_store().add_element_user(SERVICESTATETRANSITIONFAILUREEVENT$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "serviceStateTransitionFailureEvent" element
         */
        public void removeServiceStateTransitionFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SERVICESTATETRANSITIONFAILUREEVENT$4, i);
            }
        }
    }
}
