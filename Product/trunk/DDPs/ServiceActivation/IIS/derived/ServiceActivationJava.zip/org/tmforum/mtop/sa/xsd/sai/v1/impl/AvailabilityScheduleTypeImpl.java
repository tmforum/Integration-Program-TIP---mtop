/*
 * XML Type:  AvailabilityScheduleType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * An XML AvailabilityScheduleType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public class AvailabilityScheduleTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType
{
    
    public AvailabilityScheduleTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PERIODICSCHEDULE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "periodicSchedule");
    private static final javax.xml.namespace.QName RANDOMSCHEDULE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "randomSchedule");
    
    
    /**
     * Gets the "periodicSchedule" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType getPeriodicSchedule()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType)get_store().find_element_user(PERIODICSCHEDULE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "periodicSchedule" element
     */
    public boolean isSetPeriodicSchedule()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PERIODICSCHEDULE$0) != 0;
        }
    }
    
    /**
     * Sets the "periodicSchedule" element
     */
    public void setPeriodicSchedule(org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType periodicSchedule)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType)get_store().find_element_user(PERIODICSCHEDULE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType)get_store().add_element_user(PERIODICSCHEDULE$0);
            }
            target.set(periodicSchedule);
        }
    }
    
    /**
     * Appends and returns a new empty "periodicSchedule" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType addNewPeriodicSchedule()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType)get_store().add_element_user(PERIODICSCHEDULE$0);
            return target;
        }
    }
    
    /**
     * Unsets the "periodicSchedule" element
     */
    public void unsetPeriodicSchedule()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PERIODICSCHEDULE$0, 0);
        }
    }
    
    /**
     * Gets the "randomSchedule" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType getRandomSchedule()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType)get_store().find_element_user(RANDOMSCHEDULE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "randomSchedule" element
     */
    public boolean isSetRandomSchedule()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(RANDOMSCHEDULE$2) != 0;
        }
    }
    
    /**
     * Sets the "randomSchedule" element
     */
    public void setRandomSchedule(org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType randomSchedule)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType)get_store().find_element_user(RANDOMSCHEDULE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType)get_store().add_element_user(RANDOMSCHEDULE$2);
            }
            target.set(randomSchedule);
        }
    }
    
    /**
     * Appends and returns a new empty "randomSchedule" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType addNewRandomSchedule()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType)get_store().add_element_user(RANDOMSCHEDULE$2);
            return target;
        }
    }
    
    /**
     * Unsets the "randomSchedule" element
     */
    public void unsetRandomSchedule()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(RANDOMSCHEDULE$2, 0);
        }
    }
}
