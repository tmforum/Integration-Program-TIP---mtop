/*
 * XML Type:  ProductInfoType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * An XML ProductInfoType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public class ProductInfoTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType
{
    
    public ProductInfoTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PRODUCTNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productName");
    private static final javax.xml.namespace.QName PRODUCTSPECIFICATIONNAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productSpecificationName");
    private static final javax.xml.namespace.QName PRODUCTBUNDLENAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productBundleName");
    private static final javax.xml.namespace.QName PRODUCTSPECCHARACTERISTICID$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productSpecCharacteristicID");
    private static final javax.xml.namespace.QName PRODUCTCHARACTERISTICVALUE$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productCharacteristicValue");
    
    
    /**
     * Gets the "productName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "productName" element
     */
    public void setProductName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTNAME$0);
            }
            target.set(productName);
        }
    }
    
    /**
     * Appends and returns a new empty "productName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTNAME$0);
            return target;
        }
    }
    
    /**
     * Gets the "productSpecificationName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductSpecificationName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECIFICATIONNAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "productSpecificationName" element
     */
    public boolean isNilProductSpecificationName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECIFICATIONNAME$2, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "productSpecificationName" element
     */
    public void setProductSpecificationName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productSpecificationName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECIFICATIONNAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTSPECIFICATIONNAME$2);
            }
            target.set(productSpecificationName);
        }
    }
    
    /**
     * Appends and returns a new empty "productSpecificationName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductSpecificationName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTSPECIFICATIONNAME$2);
            return target;
        }
    }
    
    /**
     * Nils the "productSpecificationName" element
     */
    public void setNilProductSpecificationName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECIFICATIONNAME$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTSPECIFICATIONNAME$2);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets the "productBundleName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductBundleName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTBUNDLENAME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "productBundleName" element
     */
    public boolean isNilProductBundleName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTBUNDLENAME$4, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "productBundleName" element
     */
    public void setProductBundleName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productBundleName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTBUNDLENAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTBUNDLENAME$4);
            }
            target.set(productBundleName);
        }
    }
    
    /**
     * Appends and returns a new empty "productBundleName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductBundleName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTBUNDLENAME$4);
            return target;
        }
    }
    
    /**
     * Nils the "productBundleName" element
     */
    public void setNilProductBundleName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTBUNDLENAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTBUNDLENAME$4);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets a List of "productSpecCharacteristicID" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getProductSpecCharacteristicIDList()
    {
        final class ProductSpecCharacteristicIDList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return ProductInfoTypeImpl.this.getProductSpecCharacteristicIDArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ProductInfoTypeImpl.this.getProductSpecCharacteristicIDArray(i);
                ProductInfoTypeImpl.this.setProductSpecCharacteristicIDArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { ProductInfoTypeImpl.this.insertNewProductSpecCharacteristicID(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ProductInfoTypeImpl.this.getProductSpecCharacteristicIDArray(i);
                ProductInfoTypeImpl.this.removeProductSpecCharacteristicID(i);
                return old;
            }
            
            public int size()
                { return ProductInfoTypeImpl.this.sizeOfProductSpecCharacteristicIDArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ProductSpecCharacteristicIDList();
        }
    }
    
    /**
     * Gets array of all "productSpecCharacteristicID" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getProductSpecCharacteristicIDArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PRODUCTSPECCHARACTERISTICID$6, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "productSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductSpecCharacteristicIDArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECCHARACTERISTICID$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "productSpecCharacteristicID" element
     */
    public boolean isNilProductSpecCharacteristicIDArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECCHARACTERISTICID$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "productSpecCharacteristicID" element
     */
    public int sizeOfProductSpecCharacteristicIDArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUCTSPECCHARACTERISTICID$6);
        }
    }
    
    /**
     * Sets array of all "productSpecCharacteristicID" element
     */
    public void setProductSpecCharacteristicIDArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] productSpecCharacteristicIDArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(productSpecCharacteristicIDArray, PRODUCTSPECCHARACTERISTICID$6);
        }
    }
    
    /**
     * Sets ith "productSpecCharacteristicID" element
     */
    public void setProductSpecCharacteristicIDArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productSpecCharacteristicID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECCHARACTERISTICID$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(productSpecCharacteristicID);
        }
    }
    
    /**
     * Nils the ith "productSpecCharacteristicID" element
     */
    public void setNilProductSpecCharacteristicIDArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECCHARACTERISTICID$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "productSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewProductSpecCharacteristicID(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(PRODUCTSPECCHARACTERISTICID$6, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "productSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductSpecCharacteristicID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTSPECCHARACTERISTICID$6);
            return target;
        }
    }
    
    /**
     * Removes the ith "productSpecCharacteristicID" element
     */
    public void removeProductSpecCharacteristicID(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUCTSPECCHARACTERISTICID$6, i);
        }
    }
    
    /**
     * Gets a List of "productCharacteristicValue" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getProductCharacteristicValueList()
    {
        final class ProductCharacteristicValueList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return ProductInfoTypeImpl.this.getProductCharacteristicValueArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ProductInfoTypeImpl.this.getProductCharacteristicValueArray(i);
                ProductInfoTypeImpl.this.setProductCharacteristicValueArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { ProductInfoTypeImpl.this.insertNewProductCharacteristicValue(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ProductInfoTypeImpl.this.getProductCharacteristicValueArray(i);
                ProductInfoTypeImpl.this.removeProductCharacteristicValue(i);
                return old;
            }
            
            public int size()
                { return ProductInfoTypeImpl.this.sizeOfProductCharacteristicValueArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ProductCharacteristicValueList();
        }
    }
    
    /**
     * Gets array of all "productCharacteristicValue" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getProductCharacteristicValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PRODUCTCHARACTERISTICVALUE$8, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "productCharacteristicValue" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductCharacteristicValueArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTCHARACTERISTICVALUE$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Tests for nil ith "productCharacteristicValue" element
     */
    public boolean isNilProductCharacteristicValueArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTCHARACTERISTICVALUE$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "productCharacteristicValue" element
     */
    public int sizeOfProductCharacteristicValueArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUCTCHARACTERISTICVALUE$8);
        }
    }
    
    /**
     * Sets array of all "productCharacteristicValue" element
     */
    public void setProductCharacteristicValueArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] productCharacteristicValueArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(productCharacteristicValueArray, PRODUCTCHARACTERISTICVALUE$8);
        }
    }
    
    /**
     * Sets ith "productCharacteristicValue" element
     */
    public void setProductCharacteristicValueArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productCharacteristicValue)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTCHARACTERISTICVALUE$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(productCharacteristicValue);
        }
    }
    
    /**
     * Nils the ith "productCharacteristicValue" element
     */
    public void setNilProductCharacteristicValueArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTCHARACTERISTICVALUE$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "productCharacteristicValue" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewProductCharacteristicValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(PRODUCTCHARACTERISTICVALUE$8, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "productCharacteristicValue" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductCharacteristicValue()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTCHARACTERISTICVALUE$8);
            return target;
        }
    }
    
    /**
     * Removes the ith "productCharacteristicValue" element
     */
    public void removeProductCharacteristicValue(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUCTCHARACTERISTICVALUE$8, i);
        }
    }
}
