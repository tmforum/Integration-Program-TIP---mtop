/*
 * An XML document type.
 * Localname: retireRequest
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one retireRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class RetireRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument
{
    
    public RetireRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RETIREREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "retireRequest");
    
    
    /**
     * Gets the "retireRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest getRetireRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest)get_store().find_element_user(RETIREREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "retireRequest" element
     */
    public void setRetireRequest(org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest retireRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest)get_store().find_element_user(RETIREREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest)get_store().add_element_user(RETIREREQUEST$0);
            }
            target.set(retireRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "retireRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest addNewRetireRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest)get_store().add_element_user(RETIREREQUEST$0);
            return target;
        }
    }
    /**
     * An XML retireRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class RetireRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RetireRequestDocument.RetireRequest
    {
        
        public RetireRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROOTREQUEST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "rootRequest");
        private static final javax.xml.namespace.QName PRODUCTNAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productName");
        private static final javax.xml.namespace.QName SOAINPUT$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "soaInput");
        
        
        /**
         * Gets the "rootRequest" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType getRootRequest()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType)get_store().find_element_user(ROOTREQUEST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "rootRequest" element
         */
        public void setRootRequest(org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType rootRequest)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType)get_store().find_element_user(ROOTREQUEST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType)get_store().add_element_user(ROOTREQUEST$0);
                }
                target.set(rootRequest);
            }
        }
        
        /**
         * Appends and returns a new empty "rootRequest" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType addNewRootRequest()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType)get_store().add_element_user(ROOTREQUEST$0);
                return target;
            }
        }
        
        /**
         * Gets the "productName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTNAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "productName" element
         */
        public void setProductName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTNAME$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTNAME$2);
                }
                target.set(productName);
            }
        }
        
        /**
         * Appends and returns a new empty "productName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTNAME$2);
                return target;
            }
        }
        
        /**
         * Gets the "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType getSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "soaInput" element
         */
        public void setSoaInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType soaInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$4, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$4);
                }
                target.set(soaInput);
            }
        }
        
        /**
         * Appends and returns a new empty "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType addNewSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$4);
                return target;
            }
        }
    }
}
