/*
 * An XML document type.
 * Localname: amendResponse
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one amendResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class AmendResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument
{
    
    public AmendResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName AMENDRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "amendResponse");
    
    
    /**
     * Gets the "amendResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse getAmendResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse)get_store().find_element_user(AMENDRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "amendResponse" element
     */
    public void setAmendResponse(org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse amendResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse)get_store().find_element_user(AMENDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse)get_store().add_element_user(AMENDRESPONSE$0);
            }
            target.set(amendResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "amendResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse addNewAmendResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse)get_store().add_element_user(AMENDRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML amendResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class AmendResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.AmendResponseDocument.AmendResponse
    {
        
        public AmendResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ACK$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "ack");
        private static final javax.xml.namespace.QName NACKREASON$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "nackReason");
        
        
        /**
         * Gets the "ack" element
         */
        public boolean getAck()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACK$0, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "ack" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetAck()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACK$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "ack" element
         */
        public void setAck(boolean ack)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(ACK$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(ACK$0);
                }
                target.setBooleanValue(ack);
            }
        }
        
        /**
         * Sets (as xml) the "ack" element
         */
        public void xsetAck(org.apache.xmlbeans.XmlBoolean ack)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(ACK$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(ACK$0);
                }
                target.set(ack);
            }
        }
        
        /**
         * Gets the "nackReason" element
         */
        public java.lang.String getNackReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NACKREASON$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "nackReason" element
         */
        public org.apache.xmlbeans.XmlString xgetNackReason()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NACKREASON$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "nackReason" element
         */
        public void setNackReason(java.lang.String nackReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NACKREASON$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NACKREASON$2);
                }
                target.setStringValue(nackReason);
            }
        }
        
        /**
         * Sets (as xml) the "nackReason" element
         */
        public void xsetNackReason(org.apache.xmlbeans.XmlString nackReason)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NACKREASON$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NACKREASON$2);
                }
                target.set(nackReason);
            }
        }
    }
}
