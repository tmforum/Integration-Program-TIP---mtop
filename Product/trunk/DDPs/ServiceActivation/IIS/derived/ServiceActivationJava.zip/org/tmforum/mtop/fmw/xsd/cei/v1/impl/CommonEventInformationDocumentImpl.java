/*
 * An XML document type.
 * Localname: commonEventInformation
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/cei/v1
 * Java type: org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.cei.v1.impl;
/**
 * A document containing one commonEventInformation(@http://www.tmforum.org/mtop/fmw/xsd/cei/v1) element.
 *
 * This is a complex type.
 */
public class CommonEventInformationDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationDocument
{
    
    public CommonEventInformationDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName COMMONEVENTINFORMATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "commonEventInformation");
    private static final org.apache.xmlbeans.QNameSet COMMONEVENTINFORMATION$1 = org.apache.xmlbeans.QNameSet.forArray( new javax.xml.namespace.QName[] { 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/savc/v1", "serviceAttributeValueChange"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/soc/v1", "serviceObjectCreation"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/cei/v1", "commonEventInformation"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/sodel/v1", "serviceObjectDeletion"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/ssc/v1", "ServiceStateChange"),
    });
    
    
    /**
     * Gets the "commonEventInformation" element
     */
    public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType getCommonEventInformation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().find_element_user(COMMONEVENTINFORMATION$1, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "commonEventInformation" element
     */
    public void setCommonEventInformation(org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType commonEventInformation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().find_element_user(COMMONEVENTINFORMATION$1, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().add_element_user(COMMONEVENTINFORMATION$0);
            }
            target.set(commonEventInformation);
        }
    }
    
    /**
     * Appends and returns a new empty "commonEventInformation" element
     */
    public org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType addNewCommonEventInformation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.cei.v1.CommonEventInformationType)get_store().add_element_user(COMMONEVENTINFORMATION$0);
            return target;
        }
    }
}
