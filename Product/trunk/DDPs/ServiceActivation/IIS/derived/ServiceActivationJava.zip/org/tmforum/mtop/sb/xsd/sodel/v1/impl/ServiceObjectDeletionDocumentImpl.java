/*
 * An XML document type.
 * Localname: serviceObjectDeletion
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/sodel/v1
 * Java type: org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.sodel.v1.impl;
/**
 * A document containing one serviceObjectDeletion(@http://www.tmforum.org/mtop/sb/xsd/sodel/v1) element.
 *
 * This is a complex type.
 */
public class ServiceObjectDeletionDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionDocument
{
    
    public ServiceObjectDeletionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEOBJECTDELETION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/sodel/v1", "serviceObjectDeletion");
    
    
    /**
     * Gets the "serviceObjectDeletion" element
     */
    public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType getServiceObjectDeletion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType target = null;
            target = (org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType)get_store().find_element_user(SERVICEOBJECTDELETION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "serviceObjectDeletion" element
     */
    public void setServiceObjectDeletion(org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType serviceObjectDeletion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType target = null;
            target = (org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType)get_store().find_element_user(SERVICEOBJECTDELETION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType)get_store().add_element_user(SERVICEOBJECTDELETION$0);
            }
            target.set(serviceObjectDeletion);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceObjectDeletion" element
     */
    public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType addNewServiceObjectDeletion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType target = null;
            target = (org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType)get_store().add_element_user(SERVICEOBJECTDELETION$0);
            return target;
        }
    }
}
