/*
 * XML Type:  ServiceAvcFailureEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1
 * Java type: org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.saiexcpt.v1;


/**
 * An XML ServiceAvcFailureEventType(@http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1).
 *
 * This is a complex type.
 */
public interface ServiceAvcFailureEventType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ServiceAvcFailureEventType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("serviceavcfailureeventtype65cbtype");
    
    /**
     * Gets the "serviceRequestID" element
     */
    java.lang.String getServiceRequestID();
    
    /**
     * Gets (as xml) the "serviceRequestID" element
     */
    org.apache.xmlbeans.XmlString xgetServiceRequestID();
    
    /**
     * Sets the "serviceRequestID" element
     */
    void setServiceRequestID(java.lang.String serviceRequestID);
    
    /**
     * Sets (as xml) the "serviceRequestID" element
     */
    void xsetServiceRequestID(org.apache.xmlbeans.XmlString serviceRequestID);
    
    /**
     * Gets the "productName" element
     */
    java.lang.String getProductName();
    
    /**
     * Gets (as xml) the "productName" element
     */
    org.apache.xmlbeans.XmlString xgetProductName();
    
    /**
     * Sets the "productName" element
     */
    void setProductName(java.lang.String productName);
    
    /**
     * Sets (as xml) the "productName" element
     */
    void xsetProductName(org.apache.xmlbeans.XmlString productName);
    
    /**
     * Gets a List of "cfsName" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getCfsNameList();
    
    /**
     * Gets array of all "cfsName" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getCfsNameArray();
    
    /**
     * Gets ith "cfsName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getCfsNameArray(int i);
    
    /**
     * Returns number of "cfsName" element
     */
    int sizeOfCfsNameArray();
    
    /**
     * Sets array of all "cfsName" element
     */
    void setCfsNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] cfsNameArray);
    
    /**
     * Sets ith "cfsName" element
     */
    void setCfsNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType cfsName);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "cfsName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewCfsName(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "cfsName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewCfsName();
    
    /**
     * Removes the ith "cfsName" element
     */
    void removeCfsName(int i);
    
    /**
     * Gets a List of "productSpecCharacteristicID" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getProductSpecCharacteristicIDList();
    
    /**
     * Gets array of all "productSpecCharacteristicID" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getProductSpecCharacteristicIDArray();
    
    /**
     * Gets ith "productSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductSpecCharacteristicIDArray(int i);
    
    /**
     * Returns number of "productSpecCharacteristicID" element
     */
    int sizeOfProductSpecCharacteristicIDArray();
    
    /**
     * Sets array of all "productSpecCharacteristicID" element
     */
    void setProductSpecCharacteristicIDArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] productSpecCharacteristicIDArray);
    
    /**
     * Sets ith "productSpecCharacteristicID" element
     */
    void setProductSpecCharacteristicIDArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productSpecCharacteristicID);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "productSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewProductSpecCharacteristicID(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "productSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductSpecCharacteristicID();
    
    /**
     * Removes the ith "productSpecCharacteristicID" element
     */
    void removeProductSpecCharacteristicID(int i);
    
    /**
     * Gets a List of "serviceSpecCharacteristicID" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getServiceSpecCharacteristicIDList();
    
    /**
     * Gets array of all "serviceSpecCharacteristicID" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getServiceSpecCharacteristicIDArray();
    
    /**
     * Gets ith "serviceSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getServiceSpecCharacteristicIDArray(int i);
    
    /**
     * Returns number of "serviceSpecCharacteristicID" element
     */
    int sizeOfServiceSpecCharacteristicIDArray();
    
    /**
     * Sets array of all "serviceSpecCharacteristicID" element
     */
    void setServiceSpecCharacteristicIDArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] serviceSpecCharacteristicIDArray);
    
    /**
     * Sets ith "serviceSpecCharacteristicID" element
     */
    void setServiceSpecCharacteristicIDArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType serviceSpecCharacteristicID);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewServiceSpecCharacteristicID(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewServiceSpecCharacteristicID();
    
    /**
     * Removes the ith "serviceSpecCharacteristicID" element
     */
    void removeServiceSpecCharacteristicID(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType newInstance() {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
