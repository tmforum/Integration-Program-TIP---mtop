/*
 * XML Type:  RandomScheduleType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1;


/**
 * An XML RandomScheduleType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public interface RandomScheduleType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(RandomScheduleType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("randomscheduletypeb066type");
    
    /**
     * Gets a List of "start" elements
     */
    java.util.List<java.util.Calendar> getStartList();
    
    /**
     * Gets array of all "start" elements
     * @deprecated
     */
    java.util.Calendar[] getStartArray();
    
    /**
     * Gets ith "start" element
     */
    java.util.Calendar getStartArray(int i);
    
    /**
     * Gets (as xml) a List of "start" elements
     */
    java.util.List<org.apache.xmlbeans.XmlDateTime> xgetStartList();
    
    /**
     * Gets (as xml) array of all "start" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlDateTime[] xgetStartArray();
    
    /**
     * Gets (as xml) ith "start" element
     */
    org.apache.xmlbeans.XmlDateTime xgetStartArray(int i);
    
    /**
     * Returns number of "start" element
     */
    int sizeOfStartArray();
    
    /**
     * Sets array of all "start" element
     */
    void setStartArray(java.util.Calendar[] startArray);
    
    /**
     * Sets ith "start" element
     */
    void setStartArray(int i, java.util.Calendar start);
    
    /**
     * Sets (as xml) array of all "start" element
     */
    void xsetStartArray(org.apache.xmlbeans.XmlDateTime[] startArray);
    
    /**
     * Sets (as xml) ith "start" element
     */
    void xsetStartArray(int i, org.apache.xmlbeans.XmlDateTime start);
    
    /**
     * Inserts the value as the ith "start" element
     */
    void insertStart(int i, java.util.Calendar start);
    
    /**
     * Appends the value as the last "start" element
     */
    void addStart(java.util.Calendar start);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "start" element
     */
    org.apache.xmlbeans.XmlDateTime insertNewStart(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "start" element
     */
    org.apache.xmlbeans.XmlDateTime addNewStart();
    
    /**
     * Removes the ith "start" element
     */
    void removeStart(int i);
    
    /**
     * Gets a List of "availabilityDuration" elements
     */
    java.util.List<org.apache.xmlbeans.GDuration> getAvailabilityDurationList();
    
    /**
     * Gets array of all "availabilityDuration" elements
     * @deprecated
     */
    org.apache.xmlbeans.GDuration[] getAvailabilityDurationArray();
    
    /**
     * Gets ith "availabilityDuration" element
     */
    org.apache.xmlbeans.GDuration getAvailabilityDurationArray(int i);
    
    /**
     * Gets (as xml) a List of "availabilityDuration" elements
     */
    java.util.List<org.apache.xmlbeans.XmlDuration> xgetAvailabilityDurationList();
    
    /**
     * Gets (as xml) array of all "availabilityDuration" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlDuration[] xgetAvailabilityDurationArray();
    
    /**
     * Gets (as xml) ith "availabilityDuration" element
     */
    org.apache.xmlbeans.XmlDuration xgetAvailabilityDurationArray(int i);
    
    /**
     * Returns number of "availabilityDuration" element
     */
    int sizeOfAvailabilityDurationArray();
    
    /**
     * Sets array of all "availabilityDuration" element
     */
    void setAvailabilityDurationArray(org.apache.xmlbeans.GDuration[] availabilityDurationArray);
    
    /**
     * Sets ith "availabilityDuration" element
     */
    void setAvailabilityDurationArray(int i, org.apache.xmlbeans.GDuration availabilityDuration);
    
    /**
     * Sets (as xml) array of all "availabilityDuration" element
     */
    void xsetAvailabilityDurationArray(org.apache.xmlbeans.XmlDuration[] availabilityDurationArray);
    
    /**
     * Sets (as xml) ith "availabilityDuration" element
     */
    void xsetAvailabilityDurationArray(int i, org.apache.xmlbeans.XmlDuration availabilityDuration);
    
    /**
     * Inserts the value as the ith "availabilityDuration" element
     */
    void insertAvailabilityDuration(int i, org.apache.xmlbeans.GDuration availabilityDuration);
    
    /**
     * Appends the value as the last "availabilityDuration" element
     */
    void addAvailabilityDuration(org.apache.xmlbeans.GDuration availabilityDuration);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "availabilityDuration" element
     */
    org.apache.xmlbeans.XmlDuration insertNewAvailabilityDuration(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "availabilityDuration" element
     */
    org.apache.xmlbeans.XmlDuration addNewAvailabilityDuration();
    
    /**
     * Removes the ith "availabilityDuration" element
     */
    void removeAvailabilityDuration(int i);
    
    /**
     * Gets a List of "extensionTime" elements
     */
    java.util.List<org.apache.xmlbeans.GDuration> getExtensionTimeList();
    
    /**
     * Gets array of all "extensionTime" elements
     * @deprecated
     */
    org.apache.xmlbeans.GDuration[] getExtensionTimeArray();
    
    /**
     * Gets ith "extensionTime" element
     */
    org.apache.xmlbeans.GDuration getExtensionTimeArray(int i);
    
    /**
     * Gets (as xml) a List of "extensionTime" elements
     */
    java.util.List<org.apache.xmlbeans.XmlDuration> xgetExtensionTimeList();
    
    /**
     * Gets (as xml) array of all "extensionTime" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlDuration[] xgetExtensionTimeArray();
    
    /**
     * Gets (as xml) ith "extensionTime" element
     */
    org.apache.xmlbeans.XmlDuration xgetExtensionTimeArray(int i);
    
    /**
     * Tests for nil ith "extensionTime" element
     */
    boolean isNilExtensionTimeArray(int i);
    
    /**
     * Returns number of "extensionTime" element
     */
    int sizeOfExtensionTimeArray();
    
    /**
     * Sets array of all "extensionTime" element
     */
    void setExtensionTimeArray(org.apache.xmlbeans.GDuration[] extensionTimeArray);
    
    /**
     * Sets ith "extensionTime" element
     */
    void setExtensionTimeArray(int i, org.apache.xmlbeans.GDuration extensionTime);
    
    /**
     * Sets (as xml) array of all "extensionTime" element
     */
    void xsetExtensionTimeArray(org.apache.xmlbeans.XmlDuration[] extensionTimeArray);
    
    /**
     * Sets (as xml) ith "extensionTime" element
     */
    void xsetExtensionTimeArray(int i, org.apache.xmlbeans.XmlDuration extensionTime);
    
    /**
     * Nils the ith "extensionTime" element
     */
    void setNilExtensionTimeArray(int i);
    
    /**
     * Inserts the value as the ith "extensionTime" element
     */
    void insertExtensionTime(int i, org.apache.xmlbeans.GDuration extensionTime);
    
    /**
     * Appends the value as the last "extensionTime" element
     */
    void addExtensionTime(org.apache.xmlbeans.GDuration extensionTime);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "extensionTime" element
     */
    org.apache.xmlbeans.XmlDuration insertNewExtensionTime(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "extensionTime" element
     */
    org.apache.xmlbeans.XmlDuration addNewExtensionTime();
    
    /**
     * Removes the ith "extensionTime" element
     */
    void removeExtensionTime(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType newInstance() {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
