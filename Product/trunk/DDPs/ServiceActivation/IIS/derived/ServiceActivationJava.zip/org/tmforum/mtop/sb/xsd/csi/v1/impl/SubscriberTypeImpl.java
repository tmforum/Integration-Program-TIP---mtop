/*
 * XML Type:  SubscriberType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.SubscriberType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML SubscriberType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public class SubscriberTypeImpl extends org.tmforum.mtop.sb.xsd.csi.v1.impl.PartyRoleTypeImpl implements org.tmforum.mtop.sb.xsd.csi.v1.SubscriberType
{
    
    public SubscriberTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
