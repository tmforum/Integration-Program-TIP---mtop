/*
 * An XML document type.
 * Localname: testRequest
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one testRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class TestRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument
{
    
    public TestRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TESTREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "testRequest");
    
    
    /**
     * Gets the "testRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest getTestRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest)get_store().find_element_user(TESTREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "testRequest" element
     */
    public void setTestRequest(org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest testRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest)get_store().find_element_user(TESTREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest)get_store().add_element_user(TESTREQUEST$0);
            }
            target.set(testRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "testRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest addNewTestRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest)get_store().add_element_user(TESTREQUEST$0);
            return target;
        }
    }
    /**
     * An XML testRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class TestRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.TestRequestDocument.TestRequest
    {
        
        public TestRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROOTREQUEST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "rootRequest");
        private static final javax.xml.namespace.QName PRODUCTNAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productName");
        
        
        /**
         * Gets the "rootRequest" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType getRootRequest()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType)get_store().find_element_user(ROOTREQUEST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "rootRequest" element
         */
        public void setRootRequest(org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType rootRequest)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType)get_store().find_element_user(ROOTREQUEST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType)get_store().add_element_user(ROOTREQUEST$0);
                }
                target.set(rootRequest);
            }
        }
        
        /**
         * Appends and returns a new empty "rootRequest" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType addNewRootRequest()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType)get_store().add_element_user(ROOTREQUEST$0);
                return target;
            }
        }
        
        /**
         * Gets the "productName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTNAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "productName" element
         */
        public void setProductName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTNAME$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTNAME$2);
                }
                target.set(productName);
            }
        }
        
        /**
         * Appends and returns a new empty "productName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTNAME$2);
                return target;
            }
        }
    }
}
