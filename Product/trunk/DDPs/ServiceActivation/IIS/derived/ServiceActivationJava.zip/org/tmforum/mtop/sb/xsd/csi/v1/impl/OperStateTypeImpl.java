/*
 * XML Type:  OperStateType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.OperStateType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML OperStateType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.sb.xsd.csi.v1.OperStateType.
 */
public class OperStateTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.sb.xsd.csi.v1.OperStateType
{
    
    public OperStateTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected OperStateTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
