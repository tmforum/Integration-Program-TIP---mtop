/*
 * XML Type:  CfsCreationEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sairsp/v1
 * Java type: org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sairsp.v1;


/**
 * An XML CfsCreationEventType(@http://www.tmforum.org/mtop/sa/xsd/sairsp/v1).
 *
 * This is a complex type.
 */
public interface CfsCreationEventType extends org.tmforum.mtop.sa.xsd.sairsp.v1.RootResponseType
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(CfsCreationEventType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("cfscreationeventtype81aetype");
    
    /**
     * Gets a List of "cfsCreationEvent" elements
     */
    java.util.List<java.lang.String> getCfsCreationEventList();
    
    /**
     * Gets array of all "cfsCreationEvent" elements
     * @deprecated
     */
    java.lang.String[] getCfsCreationEventArray();
    
    /**
     * Gets ith "cfsCreationEvent" element
     */
    java.lang.String getCfsCreationEventArray(int i);
    
    /**
     * Gets (as xml) a List of "cfsCreationEvent" elements
     */
    java.util.List<org.apache.xmlbeans.XmlString> xgetCfsCreationEventList();
    
    /**
     * Gets (as xml) array of all "cfsCreationEvent" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlString[] xgetCfsCreationEventArray();
    
    /**
     * Gets (as xml) ith "cfsCreationEvent" element
     */
    org.apache.xmlbeans.XmlString xgetCfsCreationEventArray(int i);
    
    /**
     * Returns number of "cfsCreationEvent" element
     */
    int sizeOfCfsCreationEventArray();
    
    /**
     * Sets array of all "cfsCreationEvent" element
     */
    void setCfsCreationEventArray(java.lang.String[] cfsCreationEventArray);
    
    /**
     * Sets ith "cfsCreationEvent" element
     */
    void setCfsCreationEventArray(int i, java.lang.String cfsCreationEvent);
    
    /**
     * Sets (as xml) array of all "cfsCreationEvent" element
     */
    void xsetCfsCreationEventArray(org.apache.xmlbeans.XmlString[] cfsCreationEventArray);
    
    /**
     * Sets (as xml) ith "cfsCreationEvent" element
     */
    void xsetCfsCreationEventArray(int i, org.apache.xmlbeans.XmlString cfsCreationEvent);
    
    /**
     * Inserts the value as the ith "cfsCreationEvent" element
     */
    void insertCfsCreationEvent(int i, java.lang.String cfsCreationEvent);
    
    /**
     * Appends the value as the last "cfsCreationEvent" element
     */
    void addCfsCreationEvent(java.lang.String cfsCreationEvent);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "cfsCreationEvent" element
     */
    org.apache.xmlbeans.XmlString insertNewCfsCreationEvent(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "cfsCreationEvent" element
     */
    org.apache.xmlbeans.XmlString addNewCfsCreationEvent();
    
    /**
     * Removes the ith "cfsCreationEvent" element
     */
    void removeCfsCreationEvent(int i);
    
    /**
     * Gets a List of "feasibilityFlag" elements
     */
    java.util.List<java.lang.Boolean> getFeasibilityFlagList();
    
    /**
     * Gets array of all "feasibilityFlag" elements
     * @deprecated
     */
    boolean[] getFeasibilityFlagArray();
    
    /**
     * Gets ith "feasibilityFlag" element
     */
    boolean getFeasibilityFlagArray(int i);
    
    /**
     * Gets (as xml) a List of "feasibilityFlag" elements
     */
    java.util.List<org.apache.xmlbeans.XmlBoolean> xgetFeasibilityFlagList();
    
    /**
     * Gets (as xml) array of all "feasibilityFlag" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlBoolean[] xgetFeasibilityFlagArray();
    
    /**
     * Gets (as xml) ith "feasibilityFlag" element
     */
    org.apache.xmlbeans.XmlBoolean xgetFeasibilityFlagArray(int i);
    
    /**
     * Returns number of "feasibilityFlag" element
     */
    int sizeOfFeasibilityFlagArray();
    
    /**
     * Sets array of all "feasibilityFlag" element
     */
    void setFeasibilityFlagArray(boolean[] feasibilityFlagArray);
    
    /**
     * Sets ith "feasibilityFlag" element
     */
    void setFeasibilityFlagArray(int i, boolean feasibilityFlag);
    
    /**
     * Sets (as xml) array of all "feasibilityFlag" element
     */
    void xsetFeasibilityFlagArray(org.apache.xmlbeans.XmlBoolean[] feasibilityFlagArray);
    
    /**
     * Sets (as xml) ith "feasibilityFlag" element
     */
    void xsetFeasibilityFlagArray(int i, org.apache.xmlbeans.XmlBoolean feasibilityFlag);
    
    /**
     * Inserts the value as the ith "feasibilityFlag" element
     */
    void insertFeasibilityFlag(int i, boolean feasibilityFlag);
    
    /**
     * Appends the value as the last "feasibilityFlag" element
     */
    void addFeasibilityFlag(boolean feasibilityFlag);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "feasibilityFlag" element
     */
    org.apache.xmlbeans.XmlBoolean insertNewFeasibilityFlag(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "feasibilityFlag" element
     */
    org.apache.xmlbeans.XmlBoolean addNewFeasibilityFlag();
    
    /**
     * Removes the ith "feasibilityFlag" element
     */
    void removeFeasibilityFlag(int i);
    
    /**
     * Gets a List of "offeredActivationTime" elements
     */
    java.util.List<org.apache.xmlbeans.GDuration> getOfferedActivationTimeList();
    
    /**
     * Gets array of all "offeredActivationTime" elements
     * @deprecated
     */
    org.apache.xmlbeans.GDuration[] getOfferedActivationTimeArray();
    
    /**
     * Gets ith "offeredActivationTime" element
     */
    org.apache.xmlbeans.GDuration getOfferedActivationTimeArray(int i);
    
    /**
     * Gets (as xml) a List of "offeredActivationTime" elements
     */
    java.util.List<org.apache.xmlbeans.XmlDuration> xgetOfferedActivationTimeList();
    
    /**
     * Gets (as xml) array of all "offeredActivationTime" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlDuration[] xgetOfferedActivationTimeArray();
    
    /**
     * Gets (as xml) ith "offeredActivationTime" element
     */
    org.apache.xmlbeans.XmlDuration xgetOfferedActivationTimeArray(int i);
    
    /**
     * Returns number of "offeredActivationTime" element
     */
    int sizeOfOfferedActivationTimeArray();
    
    /**
     * Sets array of all "offeredActivationTime" element
     */
    void setOfferedActivationTimeArray(org.apache.xmlbeans.GDuration[] offeredActivationTimeArray);
    
    /**
     * Sets ith "offeredActivationTime" element
     */
    void setOfferedActivationTimeArray(int i, org.apache.xmlbeans.GDuration offeredActivationTime);
    
    /**
     * Sets (as xml) array of all "offeredActivationTime" element
     */
    void xsetOfferedActivationTimeArray(org.apache.xmlbeans.XmlDuration[] offeredActivationTimeArray);
    
    /**
     * Sets (as xml) ith "offeredActivationTime" element
     */
    void xsetOfferedActivationTimeArray(int i, org.apache.xmlbeans.XmlDuration offeredActivationTime);
    
    /**
     * Inserts the value as the ith "offeredActivationTime" element
     */
    void insertOfferedActivationTime(int i, org.apache.xmlbeans.GDuration offeredActivationTime);
    
    /**
     * Appends the value as the last "offeredActivationTime" element
     */
    void addOfferedActivationTime(org.apache.xmlbeans.GDuration offeredActivationTime);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "offeredActivationTime" element
     */
    org.apache.xmlbeans.XmlDuration insertNewOfferedActivationTime(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "offeredActivationTime" element
     */
    org.apache.xmlbeans.XmlDuration addNewOfferedActivationTime();
    
    /**
     * Removes the ith "offeredActivationTime" element
     */
    void removeOfferedActivationTime(int i);
    
    /**
     * Gets the "last" element
     */
    boolean getLast();
    
    /**
     * Gets (as xml) the "last" element
     */
    org.apache.xmlbeans.XmlBoolean xgetLast();
    
    /**
     * True if has "last" element
     */
    boolean isSetLast();
    
    /**
     * Sets the "last" element
     */
    void setLast(boolean last);
    
    /**
     * Sets (as xml) the "last" element
     */
    void xsetLast(org.apache.xmlbeans.XmlBoolean last);
    
    /**
     * Unsets the "last" element
     */
    void unsetLast();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType newInstance() {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
