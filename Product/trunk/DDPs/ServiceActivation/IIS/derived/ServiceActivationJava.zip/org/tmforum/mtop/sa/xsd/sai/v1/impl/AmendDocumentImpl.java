/*
 * An XML document type.
 * Localname: amend
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one amend(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class AmendDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument
{
    
    public AmendDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName AMEND$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "amend");
    
    
    /**
     * Gets the "amend" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend getAmend()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend)get_store().find_element_user(AMEND$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "amend" element
     */
    public void setAmend(org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend amend)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend)get_store().find_element_user(AMEND$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend)get_store().add_element_user(AMEND$0);
            }
            target.set(amend);
        }
    }
    
    /**
     * Appends and returns a new empty "amend" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend addNewAmend()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend)get_store().add_element_user(AMEND$0);
            return target;
        }
    }
    /**
     * An XML amend(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class AmendImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.AmendDocument.Amend
    {
        
        public AmendImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SERVICEREQUESTID$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "serviceRequestID");
        
        
        /**
         * Gets the "serviceRequestID" element
         */
        public java.lang.String getServiceRequestID()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEREQUESTID$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "serviceRequestID" element
         */
        public org.apache.xmlbeans.XmlString xgetServiceRequestID()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICEREQUESTID$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "serviceRequestID" element
         */
        public void setServiceRequestID(java.lang.String serviceRequestID)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEREQUESTID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICEREQUESTID$0);
                }
                target.setStringValue(serviceRequestID);
            }
        }
        
        /**
         * Sets (as xml) the "serviceRequestID" element
         */
        public void xsetServiceRequestID(org.apache.xmlbeans.XmlString serviceRequestID)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICEREQUESTID$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICEREQUESTID$0);
                }
                target.set(serviceRequestID);
            }
        }
    }
}
