/*
 * XML Type:  CfsAvcEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sairsp/v1
 * Java type: org.tmforum.mtop.sa.xsd.sairsp.v1.CfsAvcEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sairsp.v1.impl;
/**
 * An XML CfsAvcEventType(@http://www.tmforum.org/mtop/sa/xsd/sairsp/v1).
 *
 * This is a complex type.
 */
public class CfsAvcEventTypeImpl extends org.tmforum.mtop.sa.xsd.sairsp.v1.impl.RootResponseTypeImpl implements org.tmforum.mtop.sa.xsd.sairsp.v1.CfsAvcEventType
{
    
    public CfsAvcEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEATTRIBUTEVALUECHANGELIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "serviceAttributeValueChangeList");
    private static final javax.xml.namespace.QName LAST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "last");
    
    
    /**
     * Gets a List of "serviceAttributeValueChangeList" elements
     */
    public java.util.List<org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType> getServiceAttributeValueChangeListList()
    {
        final class ServiceAttributeValueChangeListList extends java.util.AbstractList<org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType>
        {
            public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType get(int i)
                { return CfsAvcEventTypeImpl.this.getServiceAttributeValueChangeListArray(i); }
            
            public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType set(int i, org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType o)
            {
                org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType old = CfsAvcEventTypeImpl.this.getServiceAttributeValueChangeListArray(i);
                CfsAvcEventTypeImpl.this.setServiceAttributeValueChangeListArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType o)
                { CfsAvcEventTypeImpl.this.insertNewServiceAttributeValueChangeList(i).set(o); }
            
            public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType remove(int i)
            {
                org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType old = CfsAvcEventTypeImpl.this.getServiceAttributeValueChangeListArray(i);
                CfsAvcEventTypeImpl.this.removeServiceAttributeValueChangeList(i);
                return old;
            }
            
            public int size()
                { return CfsAvcEventTypeImpl.this.sizeOfServiceAttributeValueChangeListArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceAttributeValueChangeListList();
        }
    }
    
    /**
     * Gets array of all "serviceAttributeValueChangeList" elements
     */
    public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType[] getServiceAttributeValueChangeListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICEATTRIBUTEVALUECHANGELIST$0, targetList);
            org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType[] result = new org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceAttributeValueChangeList" element
     */
    public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType getServiceAttributeValueChangeListArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType)get_store().find_element_user(SERVICEATTRIBUTEVALUECHANGELIST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceAttributeValueChangeList" element
     */
    public int sizeOfServiceAttributeValueChangeListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICEATTRIBUTEVALUECHANGELIST$0);
        }
    }
    
    /**
     * Sets array of all "serviceAttributeValueChangeList" element
     */
    public void setServiceAttributeValueChangeListArray(org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType[] serviceAttributeValueChangeListArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceAttributeValueChangeListArray, SERVICEATTRIBUTEVALUECHANGELIST$0);
        }
    }
    
    /**
     * Sets ith "serviceAttributeValueChangeList" element
     */
    public void setServiceAttributeValueChangeListArray(int i, org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType serviceAttributeValueChangeList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType)get_store().find_element_user(SERVICEATTRIBUTEVALUECHANGELIST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceAttributeValueChangeList);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceAttributeValueChangeList" element
     */
    public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType insertNewServiceAttributeValueChangeList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType)get_store().insert_element_user(SERVICEATTRIBUTEVALUECHANGELIST$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceAttributeValueChangeList" element
     */
    public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType addNewServiceAttributeValueChangeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType)get_store().add_element_user(SERVICEATTRIBUTEVALUECHANGELIST$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceAttributeValueChangeList" element
     */
    public void removeServiceAttributeValueChangeList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICEATTRIBUTEVALUECHANGELIST$0, i);
        }
    }
    
    /**
     * Gets the "last" element
     */
    public boolean getLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "last" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(LAST$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "last" element
     */
    public boolean isSetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAST$2) != 0;
        }
    }
    
    /**
     * Sets the "last" element
     */
    public void setLast(boolean last)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LAST$2);
            }
            target.setBooleanValue(last);
        }
    }
    
    /**
     * Sets (as xml) the "last" element
     */
    public void xsetLast(org.apache.xmlbeans.XmlBoolean last)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(LAST$2);
            }
            target.set(last);
        }
    }
    
    /**
     * Unsets the "last" element
     */
    public void unsetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAST$2, 0);
        }
    }
}
