/*
 * An XML document type.
 * Localname: designRequest
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one designRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class DesignRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument
{
    
    public DesignRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DESIGNREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "designRequest");
    
    
    /**
     * Gets the "designRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest getDesignRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest)get_store().find_element_user(DESIGNREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "designRequest" element
     */
    public void setDesignRequest(org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest designRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest)get_store().find_element_user(DESIGNREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest)get_store().add_element_user(DESIGNREQUEST$0);
            }
            target.set(designRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "designRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest addNewDesignRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest)get_store().add_element_user(DESIGNREQUEST$0);
            return target;
        }
    }
    /**
     * An XML designRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class DesignRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.DesignRequestDocument.DesignRequest
    {
        
        public DesignRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName BASICINPUT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "basicInput");
        private static final javax.xml.namespace.QName SOAINPUT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "soaInput");
        
        
        /**
         * Gets the "basicInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType getBasicInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(BASICINPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "basicInput" element
         */
        public void setBasicInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType basicInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(BASICINPUT$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(BASICINPUT$0);
                }
                target.set(basicInput);
            }
        }
        
        /**
         * Appends and returns a new empty "basicInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType addNewBasicInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(BASICINPUT$0);
                return target;
            }
        }
        
        /**
         * Gets the "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType getSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "soaInput" element
         */
        public void setSoaInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType soaInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$2);
                }
                target.set(soaInput);
            }
        }
        
        /**
         * Appends and returns a new empty "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType addNewSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$2);
                return target;
            }
        }
    }
}
