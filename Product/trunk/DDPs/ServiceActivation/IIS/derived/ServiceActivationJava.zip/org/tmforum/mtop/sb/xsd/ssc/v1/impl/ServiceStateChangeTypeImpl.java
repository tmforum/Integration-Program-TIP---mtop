/*
 * XML Type:  ServiceStateChangeType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/ssc/v1
 * Java type: org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.ssc.v1.impl;
/**
 * An XML ServiceStateChangeType(@http://www.tmforum.org/mtop/sb/xsd/ssc/v1).
 *
 * This is a complex type.
 */
public class ServiceStateChangeTypeImpl extends org.tmforum.mtop.fmw.xsd.sc.v1.impl.StateChangeTypeImpl implements org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType
{
    
    public ServiceStateChangeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
