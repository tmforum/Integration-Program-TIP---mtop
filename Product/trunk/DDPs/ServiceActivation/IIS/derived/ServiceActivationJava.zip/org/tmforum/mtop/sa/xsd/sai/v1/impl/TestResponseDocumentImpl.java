/*
 * An XML document type.
 * Localname: testResponse
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one testResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class TestResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument
{
    
    public TestResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName TESTRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "testResponse");
    
    
    /**
     * Gets the "testResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse getTestResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse)get_store().find_element_user(TESTRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "testResponse" element
     */
    public void setTestResponse(org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse testResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse)get_store().find_element_user(TESTRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse)get_store().add_element_user(TESTRESPONSE$0);
            }
            target.set(testResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "testResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse addNewTestResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse)get_store().add_element_user(TESTRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML testResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class TestResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.TestResponseDocument.TestResponse
    {
        
        public TestResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INITIALRESPONSE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "initialResponse");
        
        
        /**
         * Gets a List of "initialResponse" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType> getInitialResponseList()
        {
            final class InitialResponseList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType get(int i)
                    { return TestResponseImpl.this.getInitialResponseArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType old = TestResponseImpl.this.getInitialResponseArray(i);
                    TestResponseImpl.this.setInitialResponseArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType o)
                    { TestResponseImpl.this.insertNewInitialResponse(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType old = TestResponseImpl.this.getInitialResponseArray(i);
                    TestResponseImpl.this.removeInitialResponse(i);
                    return old;
                }
                
                public int size()
                    { return TestResponseImpl.this.sizeOfInitialResponseArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new InitialResponseList();
            }
        }
        
        /**
         * Gets array of all "initialResponse" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] getInitialResponseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(INITIALRESPONSE$0, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType getInitialResponseArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().find_element_user(INITIALRESPONSE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "initialResponse" element
         */
        public int sizeOfInitialResponseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INITIALRESPONSE$0);
            }
        }
        
        /**
         * Sets array of all "initialResponse" element
         */
        public void setInitialResponseArray(org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] initialResponseArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(initialResponseArray, INITIALRESPONSE$0);
            }
        }
        
        /**
         * Sets ith "initialResponse" element
         */
        public void setInitialResponseArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType initialResponse)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().find_element_user(INITIALRESPONSE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(initialResponse);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType insertNewInitialResponse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().insert_element_user(INITIALRESPONSE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType addNewInitialResponse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().add_element_user(INITIALRESPONSE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "initialResponse" element
         */
        public void removeInitialResponse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INITIALRESPONSE$0, i);
            }
        }
    }
}
