/*
 * XML Type:  CfsDeletionEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sairsp/v1
 * Java type: org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sairsp.v1.impl;
/**
 * An XML CfsDeletionEventType(@http://www.tmforum.org/mtop/sa/xsd/sairsp/v1).
 *
 * This is a complex type.
 */
public class CfsDeletionEventTypeImpl extends org.tmforum.mtop.sa.xsd.sairsp.v1.impl.RootResponseTypeImpl implements org.tmforum.mtop.sa.xsd.sairsp.v1.CfsDeletionEventType
{
    
    public CfsDeletionEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CFSDELETIONEVENTS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "cfsDeletionEvents");
    private static final javax.xml.namespace.QName LAST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "last");
    
    
    /**
     * Gets a List of "cfsDeletionEvents" elements
     */
    public java.util.List<org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType> getCfsDeletionEventsList()
    {
        final class CfsDeletionEventsList extends java.util.AbstractList<org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType>
        {
            public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType get(int i)
                { return CfsDeletionEventTypeImpl.this.getCfsDeletionEventsArray(i); }
            
            public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType set(int i, org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType o)
            {
                org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType old = CfsDeletionEventTypeImpl.this.getCfsDeletionEventsArray(i);
                CfsDeletionEventTypeImpl.this.setCfsDeletionEventsArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType o)
                { CfsDeletionEventTypeImpl.this.insertNewCfsDeletionEvents(i).set(o); }
            
            public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType remove(int i)
            {
                org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType old = CfsDeletionEventTypeImpl.this.getCfsDeletionEventsArray(i);
                CfsDeletionEventTypeImpl.this.removeCfsDeletionEvents(i);
                return old;
            }
            
            public int size()
                { return CfsDeletionEventTypeImpl.this.sizeOfCfsDeletionEventsArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CfsDeletionEventsList();
        }
    }
    
    /**
     * Gets array of all "cfsDeletionEvents" elements
     */
    public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType[] getCfsDeletionEventsArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CFSDELETIONEVENTS$0, targetList);
            org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType[] result = new org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "cfsDeletionEvents" element
     */
    public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType getCfsDeletionEventsArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType target = null;
            target = (org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType)get_store().find_element_user(CFSDELETIONEVENTS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "cfsDeletionEvents" element
     */
    public int sizeOfCfsDeletionEventsArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CFSDELETIONEVENTS$0);
        }
    }
    
    /**
     * Sets array of all "cfsDeletionEvents" element
     */
    public void setCfsDeletionEventsArray(org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType[] cfsDeletionEventsArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(cfsDeletionEventsArray, CFSDELETIONEVENTS$0);
        }
    }
    
    /**
     * Sets ith "cfsDeletionEvents" element
     */
    public void setCfsDeletionEventsArray(int i, org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType cfsDeletionEvents)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType target = null;
            target = (org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType)get_store().find_element_user(CFSDELETIONEVENTS$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(cfsDeletionEvents);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "cfsDeletionEvents" element
     */
    public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType insertNewCfsDeletionEvents(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType target = null;
            target = (org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType)get_store().insert_element_user(CFSDELETIONEVENTS$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "cfsDeletionEvents" element
     */
    public org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType addNewCfsDeletionEvents()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType target = null;
            target = (org.tmforum.mtop.sb.xsd.sodel.v1.ServiceObjectDeletionType)get_store().add_element_user(CFSDELETIONEVENTS$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "cfsDeletionEvents" element
     */
    public void removeCfsDeletionEvents(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CFSDELETIONEVENTS$0, i);
        }
    }
    
    /**
     * Gets the "last" element
     */
    public boolean getLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "last" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(LAST$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "last" element
     */
    public boolean isSetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAST$2) != 0;
        }
    }
    
    /**
     * Sets the "last" element
     */
    public void setLast(boolean last)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LAST$2);
            }
            target.setBooleanValue(last);
        }
    }
    
    /**
     * Sets (as xml) the "last" element
     */
    public void xsetLast(org.apache.xmlbeans.XmlBoolean last)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(LAST$2);
            }
            target.set(last);
        }
    }
    
    /**
     * Unsets the "last" element
     */
    public void unsetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAST$2, 0);
        }
    }
}
