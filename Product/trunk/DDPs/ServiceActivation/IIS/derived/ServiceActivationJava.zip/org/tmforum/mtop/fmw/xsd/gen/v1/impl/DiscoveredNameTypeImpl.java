/*
 * XML Type:  DiscoveredNameType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/gen/v1
 * Java type: org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.gen.v1.impl;
/**
 * An XML DiscoveredNameType(@http://www.tmforum.org/mtop/fmw/xsd/gen/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType.
 */
public class DiscoveredNameTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.tmforum.mtop.fmw.xsd.gen.v1.DiscoveredNameType
{
    
    public DiscoveredNameTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected DiscoveredNameTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
