/*
 * An XML document type.
 * Localname: amendException
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one amendException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class AmendExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument
{
    
    public AmendExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName AMENDEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "amendException");
    
    
    /**
     * Gets the "amendException" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException getAmendException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException)get_store().find_element_user(AMENDEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "amendException" element
     */
    public void setAmendException(org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException amendException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException)get_store().find_element_user(AMENDEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException)get_store().add_element_user(AMENDEXCEPTION$0);
            }
            target.set(amendException);
        }
    }
    
    /**
     * Appends and returns a new empty "amendException" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException addNewAmendException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException)get_store().add_element_user(AMENDEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML amendException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class AmendExceptionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.AmendExceptionDocument.AmendException
    {
        
        public AmendExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName BASICFAILUREEVENT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "basicFailureEvent");
        
        
        /**
         * Gets a List of "basicFailureEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType> getBasicFailureEventList()
        {
            final class BasicFailureEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType>
            {
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType get(int i)
                    { return AmendExceptionImpl.this.getBasicFailureEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType set(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType o)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType old = AmendExceptionImpl.this.getBasicFailureEventArray(i);
                    AmendExceptionImpl.this.setBasicFailureEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType o)
                    { AmendExceptionImpl.this.insertNewBasicFailureEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType old = AmendExceptionImpl.this.getBasicFailureEventArray(i);
                    AmendExceptionImpl.this.removeBasicFailureEvent(i);
                    return old;
                }
                
                public int size()
                    { return AmendExceptionImpl.this.sizeOfBasicFailureEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new BasicFailureEventList();
            }
        }
        
        /**
         * Gets array of all "basicFailureEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] getBasicFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(BASICFAILUREEVENT$0, targetList);
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] result = new org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType getBasicFailureEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().find_element_user(BASICFAILUREEVENT$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "basicFailureEvent" element
         */
        public int sizeOfBasicFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BASICFAILUREEVENT$0);
            }
        }
        
        /**
         * Sets array of all "basicFailureEvent" element
         */
        public void setBasicFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] basicFailureEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(basicFailureEventArray, BASICFAILUREEVENT$0);
            }
        }
        
        /**
         * Sets ith "basicFailureEvent" element
         */
        public void setBasicFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType basicFailureEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().find_element_user(BASICFAILUREEVENT$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(basicFailureEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType insertNewBasicFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().insert_element_user(BASICFAILUREEVENT$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType addNewBasicFailureEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().add_element_user(BASICFAILUREEVENT$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "basicFailureEvent" element
         */
        public void removeBasicFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BASICFAILUREEVENT$0, i);
            }
        }
    }
}
