/*
 * XML Type:  CfsCreationEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sairsp/v1
 * Java type: org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sairsp.v1.impl;
/**
 * An XML CfsCreationEventType(@http://www.tmforum.org/mtop/sa/xsd/sairsp/v1).
 *
 * This is a complex type.
 */
public class CfsCreationEventTypeImpl extends org.tmforum.mtop.sa.xsd.sairsp.v1.impl.RootResponseTypeImpl implements org.tmforum.mtop.sa.xsd.sairsp.v1.CfsCreationEventType
{
    
    public CfsCreationEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CFSCREATIONEVENT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "cfsCreationEvent");
    private static final javax.xml.namespace.QName FEASIBILITYFLAG$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "feasibilityFlag");
    private static final javax.xml.namespace.QName OFFEREDACTIVATIONTIME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "offeredActivationTime");
    private static final javax.xml.namespace.QName LAST$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "last");
    
    
    /**
     * Gets a List of "cfsCreationEvent" elements
     */
    public java.util.List<java.lang.String> getCfsCreationEventList()
    {
        final class CfsCreationEventList extends java.util.AbstractList<java.lang.String>
        {
            public java.lang.String get(int i)
                { return CfsCreationEventTypeImpl.this.getCfsCreationEventArray(i); }
            
            public java.lang.String set(int i, java.lang.String o)
            {
                java.lang.String old = CfsCreationEventTypeImpl.this.getCfsCreationEventArray(i);
                CfsCreationEventTypeImpl.this.setCfsCreationEventArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.String o)
                { CfsCreationEventTypeImpl.this.insertCfsCreationEvent(i, o); }
            
            public java.lang.String remove(int i)
            {
                java.lang.String old = CfsCreationEventTypeImpl.this.getCfsCreationEventArray(i);
                CfsCreationEventTypeImpl.this.removeCfsCreationEvent(i);
                return old;
            }
            
            public int size()
                { return CfsCreationEventTypeImpl.this.sizeOfCfsCreationEventArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CfsCreationEventList();
        }
    }
    
    /**
     * Gets array of all "cfsCreationEvent" elements
     */
    public java.lang.String[] getCfsCreationEventArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CFSCREATIONEVENT$0, targetList);
            java.lang.String[] result = new java.lang.String[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
            return result;
        }
    }
    
    /**
     * Gets ith "cfsCreationEvent" element
     */
    public java.lang.String getCfsCreationEventArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CFSCREATIONEVENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "cfsCreationEvent" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlString> xgetCfsCreationEventList()
    {
        final class CfsCreationEventList extends java.util.AbstractList<org.apache.xmlbeans.XmlString>
        {
            public org.apache.xmlbeans.XmlString get(int i)
                { return CfsCreationEventTypeImpl.this.xgetCfsCreationEventArray(i); }
            
            public org.apache.xmlbeans.XmlString set(int i, org.apache.xmlbeans.XmlString o)
            {
                org.apache.xmlbeans.XmlString old = CfsCreationEventTypeImpl.this.xgetCfsCreationEventArray(i);
                CfsCreationEventTypeImpl.this.xsetCfsCreationEventArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlString o)
                { CfsCreationEventTypeImpl.this.insertNewCfsCreationEvent(i).set(o); }
            
            public org.apache.xmlbeans.XmlString remove(int i)
            {
                org.apache.xmlbeans.XmlString old = CfsCreationEventTypeImpl.this.xgetCfsCreationEventArray(i);
                CfsCreationEventTypeImpl.this.removeCfsCreationEvent(i);
                return old;
            }
            
            public int size()
                { return CfsCreationEventTypeImpl.this.sizeOfCfsCreationEventArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CfsCreationEventList();
        }
    }
    
    /**
     * Gets (as xml) array of all "cfsCreationEvent" elements
     */
    public org.apache.xmlbeans.XmlString[] xgetCfsCreationEventArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CFSCREATIONEVENT$0, targetList);
            org.apache.xmlbeans.XmlString[] result = new org.apache.xmlbeans.XmlString[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "cfsCreationEvent" element
     */
    public org.apache.xmlbeans.XmlString xgetCfsCreationEventArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CFSCREATIONEVENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlString)target;
        }
    }
    
    /**
     * Returns number of "cfsCreationEvent" element
     */
    public int sizeOfCfsCreationEventArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CFSCREATIONEVENT$0);
        }
    }
    
    /**
     * Sets array of all "cfsCreationEvent" element
     */
    public void setCfsCreationEventArray(java.lang.String[] cfsCreationEventArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(cfsCreationEventArray, CFSCREATIONEVENT$0);
        }
    }
    
    /**
     * Sets ith "cfsCreationEvent" element
     */
    public void setCfsCreationEventArray(int i, java.lang.String cfsCreationEvent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CFSCREATIONEVENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setStringValue(cfsCreationEvent);
        }
    }
    
    /**
     * Sets (as xml) array of all "cfsCreationEvent" element
     */
    public void xsetCfsCreationEventArray(org.apache.xmlbeans.XmlString[]cfsCreationEventArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(cfsCreationEventArray, CFSCREATIONEVENT$0);
        }
    }
    
    /**
     * Sets (as xml) ith "cfsCreationEvent" element
     */
    public void xsetCfsCreationEventArray(int i, org.apache.xmlbeans.XmlString cfsCreationEvent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CFSCREATIONEVENT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(cfsCreationEvent);
        }
    }
    
    /**
     * Inserts the value as the ith "cfsCreationEvent" element
     */
    public void insertCfsCreationEvent(int i, java.lang.String cfsCreationEvent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(CFSCREATIONEVENT$0, i);
            target.setStringValue(cfsCreationEvent);
        }
    }
    
    /**
     * Appends the value as the last "cfsCreationEvent" element
     */
    public void addCfsCreationEvent(java.lang.String cfsCreationEvent)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CFSCREATIONEVENT$0);
            target.setStringValue(cfsCreationEvent);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "cfsCreationEvent" element
     */
    public org.apache.xmlbeans.XmlString insertNewCfsCreationEvent(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().insert_element_user(CFSCREATIONEVENT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "cfsCreationEvent" element
     */
    public org.apache.xmlbeans.XmlString addNewCfsCreationEvent()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CFSCREATIONEVENT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "cfsCreationEvent" element
     */
    public void removeCfsCreationEvent(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CFSCREATIONEVENT$0, i);
        }
    }
    
    /**
     * Gets a List of "feasibilityFlag" elements
     */
    public java.util.List<java.lang.Boolean> getFeasibilityFlagList()
    {
        final class FeasibilityFlagList extends java.util.AbstractList<java.lang.Boolean>
        {
            public java.lang.Boolean get(int i)
                { return CfsCreationEventTypeImpl.this.getFeasibilityFlagArray(i); }
            
            public java.lang.Boolean set(int i, java.lang.Boolean o)
            {
                java.lang.Boolean old = CfsCreationEventTypeImpl.this.getFeasibilityFlagArray(i);
                CfsCreationEventTypeImpl.this.setFeasibilityFlagArray(i, o);
                return old;
            }
            
            public void add(int i, java.lang.Boolean o)
                { CfsCreationEventTypeImpl.this.insertFeasibilityFlag(i, o); }
            
            public java.lang.Boolean remove(int i)
            {
                java.lang.Boolean old = CfsCreationEventTypeImpl.this.getFeasibilityFlagArray(i);
                CfsCreationEventTypeImpl.this.removeFeasibilityFlag(i);
                return old;
            }
            
            public int size()
                { return CfsCreationEventTypeImpl.this.sizeOfFeasibilityFlagArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new FeasibilityFlagList();
        }
    }
    
    /**
     * Gets array of all "feasibilityFlag" elements
     */
    public boolean[] getFeasibilityFlagArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(FEASIBILITYFLAG$2, targetList);
            boolean[] result = new boolean[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getBooleanValue();
            return result;
        }
    }
    
    /**
     * Gets ith "feasibilityFlag" element
     */
    public boolean getFeasibilityFlagArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FEASIBILITYFLAG$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "feasibilityFlag" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlBoolean> xgetFeasibilityFlagList()
    {
        final class FeasibilityFlagList extends java.util.AbstractList<org.apache.xmlbeans.XmlBoolean>
        {
            public org.apache.xmlbeans.XmlBoolean get(int i)
                { return CfsCreationEventTypeImpl.this.xgetFeasibilityFlagArray(i); }
            
            public org.apache.xmlbeans.XmlBoolean set(int i, org.apache.xmlbeans.XmlBoolean o)
            {
                org.apache.xmlbeans.XmlBoolean old = CfsCreationEventTypeImpl.this.xgetFeasibilityFlagArray(i);
                CfsCreationEventTypeImpl.this.xsetFeasibilityFlagArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlBoolean o)
                { CfsCreationEventTypeImpl.this.insertNewFeasibilityFlag(i).set(o); }
            
            public org.apache.xmlbeans.XmlBoolean remove(int i)
            {
                org.apache.xmlbeans.XmlBoolean old = CfsCreationEventTypeImpl.this.xgetFeasibilityFlagArray(i);
                CfsCreationEventTypeImpl.this.removeFeasibilityFlag(i);
                return old;
            }
            
            public int size()
                { return CfsCreationEventTypeImpl.this.sizeOfFeasibilityFlagArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new FeasibilityFlagList();
        }
    }
    
    /**
     * Gets (as xml) array of all "feasibilityFlag" elements
     */
    public org.apache.xmlbeans.XmlBoolean[] xgetFeasibilityFlagArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(FEASIBILITYFLAG$2, targetList);
            org.apache.xmlbeans.XmlBoolean[] result = new org.apache.xmlbeans.XmlBoolean[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "feasibilityFlag" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetFeasibilityFlagArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FEASIBILITYFLAG$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlBoolean)target;
        }
    }
    
    /**
     * Returns number of "feasibilityFlag" element
     */
    public int sizeOfFeasibilityFlagArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(FEASIBILITYFLAG$2);
        }
    }
    
    /**
     * Sets array of all "feasibilityFlag" element
     */
    public void setFeasibilityFlagArray(boolean[] feasibilityFlagArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(feasibilityFlagArray, FEASIBILITYFLAG$2);
        }
    }
    
    /**
     * Sets ith "feasibilityFlag" element
     */
    public void setFeasibilityFlagArray(int i, boolean feasibilityFlag)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FEASIBILITYFLAG$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setBooleanValue(feasibilityFlag);
        }
    }
    
    /**
     * Sets (as xml) array of all "feasibilityFlag" element
     */
    public void xsetFeasibilityFlagArray(org.apache.xmlbeans.XmlBoolean[]feasibilityFlagArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(feasibilityFlagArray, FEASIBILITYFLAG$2);
        }
    }
    
    /**
     * Sets (as xml) ith "feasibilityFlag" element
     */
    public void xsetFeasibilityFlagArray(int i, org.apache.xmlbeans.XmlBoolean feasibilityFlag)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(FEASIBILITYFLAG$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(feasibilityFlag);
        }
    }
    
    /**
     * Inserts the value as the ith "feasibilityFlag" element
     */
    public void insertFeasibilityFlag(int i, boolean feasibilityFlag)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(FEASIBILITYFLAG$2, i);
            target.setBooleanValue(feasibilityFlag);
        }
    }
    
    /**
     * Appends the value as the last "feasibilityFlag" element
     */
    public void addFeasibilityFlag(boolean feasibilityFlag)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FEASIBILITYFLAG$2);
            target.setBooleanValue(feasibilityFlag);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "feasibilityFlag" element
     */
    public org.apache.xmlbeans.XmlBoolean insertNewFeasibilityFlag(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().insert_element_user(FEASIBILITYFLAG$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "feasibilityFlag" element
     */
    public org.apache.xmlbeans.XmlBoolean addNewFeasibilityFlag()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(FEASIBILITYFLAG$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "feasibilityFlag" element
     */
    public void removeFeasibilityFlag(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(FEASIBILITYFLAG$2, i);
        }
    }
    
    /**
     * Gets a List of "offeredActivationTime" elements
     */
    public java.util.List<org.apache.xmlbeans.GDuration> getOfferedActivationTimeList()
    {
        final class OfferedActivationTimeList extends java.util.AbstractList<org.apache.xmlbeans.GDuration>
        {
            public org.apache.xmlbeans.GDuration get(int i)
                { return CfsCreationEventTypeImpl.this.getOfferedActivationTimeArray(i); }
            
            public org.apache.xmlbeans.GDuration set(int i, org.apache.xmlbeans.GDuration o)
            {
                org.apache.xmlbeans.GDuration old = CfsCreationEventTypeImpl.this.getOfferedActivationTimeArray(i);
                CfsCreationEventTypeImpl.this.setOfferedActivationTimeArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.GDuration o)
                { CfsCreationEventTypeImpl.this.insertOfferedActivationTime(i, o); }
            
            public org.apache.xmlbeans.GDuration remove(int i)
            {
                org.apache.xmlbeans.GDuration old = CfsCreationEventTypeImpl.this.getOfferedActivationTimeArray(i);
                CfsCreationEventTypeImpl.this.removeOfferedActivationTime(i);
                return old;
            }
            
            public int size()
                { return CfsCreationEventTypeImpl.this.sizeOfOfferedActivationTimeArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new OfferedActivationTimeList();
        }
    }
    
    /**
     * Gets array of all "offeredActivationTime" elements
     */
    public org.apache.xmlbeans.GDuration[] getOfferedActivationTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(OFFEREDACTIVATIONTIME$4, targetList);
            org.apache.xmlbeans.GDuration[] result = new org.apache.xmlbeans.GDuration[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getGDurationValue();
            return result;
        }
    }
    
    /**
     * Gets ith "offeredActivationTime" element
     */
    public org.apache.xmlbeans.GDuration getOfferedActivationTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OFFEREDACTIVATIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getGDurationValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "offeredActivationTime" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlDuration> xgetOfferedActivationTimeList()
    {
        final class OfferedActivationTimeList extends java.util.AbstractList<org.apache.xmlbeans.XmlDuration>
        {
            public org.apache.xmlbeans.XmlDuration get(int i)
                { return CfsCreationEventTypeImpl.this.xgetOfferedActivationTimeArray(i); }
            
            public org.apache.xmlbeans.XmlDuration set(int i, org.apache.xmlbeans.XmlDuration o)
            {
                org.apache.xmlbeans.XmlDuration old = CfsCreationEventTypeImpl.this.xgetOfferedActivationTimeArray(i);
                CfsCreationEventTypeImpl.this.xsetOfferedActivationTimeArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlDuration o)
                { CfsCreationEventTypeImpl.this.insertNewOfferedActivationTime(i).set(o); }
            
            public org.apache.xmlbeans.XmlDuration remove(int i)
            {
                org.apache.xmlbeans.XmlDuration old = CfsCreationEventTypeImpl.this.xgetOfferedActivationTimeArray(i);
                CfsCreationEventTypeImpl.this.removeOfferedActivationTime(i);
                return old;
            }
            
            public int size()
                { return CfsCreationEventTypeImpl.this.sizeOfOfferedActivationTimeArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new OfferedActivationTimeList();
        }
    }
    
    /**
     * Gets (as xml) array of all "offeredActivationTime" elements
     */
    public org.apache.xmlbeans.XmlDuration[] xgetOfferedActivationTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(OFFEREDACTIVATIONTIME$4, targetList);
            org.apache.xmlbeans.XmlDuration[] result = new org.apache.xmlbeans.XmlDuration[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "offeredActivationTime" element
     */
    public org.apache.xmlbeans.XmlDuration xgetOfferedActivationTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(OFFEREDACTIVATIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlDuration)target;
        }
    }
    
    /**
     * Returns number of "offeredActivationTime" element
     */
    public int sizeOfOfferedActivationTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OFFEREDACTIVATIONTIME$4);
        }
    }
    
    /**
     * Sets array of all "offeredActivationTime" element
     */
    public void setOfferedActivationTimeArray(org.apache.xmlbeans.GDuration[] offeredActivationTimeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(offeredActivationTimeArray, OFFEREDACTIVATIONTIME$4);
        }
    }
    
    /**
     * Sets ith "offeredActivationTime" element
     */
    public void setOfferedActivationTimeArray(int i, org.apache.xmlbeans.GDuration offeredActivationTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(OFFEREDACTIVATIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setGDurationValue(offeredActivationTime);
        }
    }
    
    /**
     * Sets (as xml) array of all "offeredActivationTime" element
     */
    public void xsetOfferedActivationTimeArray(org.apache.xmlbeans.XmlDuration[]offeredActivationTimeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(offeredActivationTimeArray, OFFEREDACTIVATIONTIME$4);
        }
    }
    
    /**
     * Sets (as xml) ith "offeredActivationTime" element
     */
    public void xsetOfferedActivationTimeArray(int i, org.apache.xmlbeans.XmlDuration offeredActivationTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(OFFEREDACTIVATIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(offeredActivationTime);
        }
    }
    
    /**
     * Inserts the value as the ith "offeredActivationTime" element
     */
    public void insertOfferedActivationTime(int i, org.apache.xmlbeans.GDuration offeredActivationTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(OFFEREDACTIVATIONTIME$4, i);
            target.setGDurationValue(offeredActivationTime);
        }
    }
    
    /**
     * Appends the value as the last "offeredActivationTime" element
     */
    public void addOfferedActivationTime(org.apache.xmlbeans.GDuration offeredActivationTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(OFFEREDACTIVATIONTIME$4);
            target.setGDurationValue(offeredActivationTime);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "offeredActivationTime" element
     */
    public org.apache.xmlbeans.XmlDuration insertNewOfferedActivationTime(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().insert_element_user(OFFEREDACTIVATIONTIME$4, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "offeredActivationTime" element
     */
    public org.apache.xmlbeans.XmlDuration addNewOfferedActivationTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().add_element_user(OFFEREDACTIVATIONTIME$4);
            return target;
        }
    }
    
    /**
     * Removes the ith "offeredActivationTime" element
     */
    public void removeOfferedActivationTime(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OFFEREDACTIVATIONTIME$4, i);
        }
    }
    
    /**
     * Gets the "last" element
     */
    public boolean getLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAST$6, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "last" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(LAST$6, 0);
            return target;
        }
    }
    
    /**
     * True if has "last" element
     */
    public boolean isSetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAST$6) != 0;
        }
    }
    
    /**
     * Sets the "last" element
     */
    public void setLast(boolean last)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAST$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LAST$6);
            }
            target.setBooleanValue(last);
        }
    }
    
    /**
     * Sets (as xml) the "last" element
     */
    public void xsetLast(org.apache.xmlbeans.XmlBoolean last)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(LAST$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(LAST$6);
            }
            target.set(last);
        }
    }
    
    /**
     * Unsets the "last" element
     */
    public void unsetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAST$6, 0);
        }
    }
}
