/*
 * An XML document type.
 * Localname: reserveRequest
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one reserveRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class ReserveRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument
{
    
    public ReserveRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RESERVEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "reserveRequest");
    
    
    /**
     * Gets the "reserveRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest getReserveRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest)get_store().find_element_user(RESERVEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "reserveRequest" element
     */
    public void setReserveRequest(org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest reserveRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest)get_store().find_element_user(RESERVEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest)get_store().add_element_user(RESERVEREQUEST$0);
            }
            target.set(reserveRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "reserveRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest addNewReserveRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest)get_store().add_element_user(RESERVEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML reserveRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class ReserveRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ReserveRequestDocument.ReserveRequest
    {
        
        public ReserveRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName BASICINPUT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "basicInput");
        private static final javax.xml.namespace.QName SOAINPUT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "soaInput");
        private static final javax.xml.namespace.QName EXPIRINGTIME$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "expiringTime");
        private static final javax.xml.namespace.QName PRODUCTAVAILABILITYSCHEDULE$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "productAvailabilitySchedule");
        private static final javax.xml.namespace.QName COMMIT$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "commit");
        private static final javax.xml.namespace.QName DESIREDSTATE$10 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "desiredState");
        
        
        /**
         * Gets the "basicInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType getBasicInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(BASICINPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "basicInput" element
         */
        public void setBasicInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType basicInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(BASICINPUT$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(BASICINPUT$0);
                }
                target.set(basicInput);
            }
        }
        
        /**
         * Appends and returns a new empty "basicInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType addNewBasicInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(BASICINPUT$0);
                return target;
            }
        }
        
        /**
         * Gets the "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType getSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "soaInput" element
         */
        public void setSoaInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType soaInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$2);
                }
                target.set(soaInput);
            }
        }
        
        /**
         * Appends and returns a new empty "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType addNewSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$2);
                return target;
            }
        }
        
        /**
         * Gets the "expiringTime" element
         */
        public java.util.Calendar getExpiringTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXPIRINGTIME$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getCalendarValue();
            }
        }
        
        /**
         * Gets (as xml) the "expiringTime" element
         */
        public org.apache.xmlbeans.XmlDateTime xgetExpiringTime()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(EXPIRINGTIME$4, 0);
                return target;
            }
        }
        
        /**
         * Sets the "expiringTime" element
         */
        public void setExpiringTime(java.util.Calendar expiringTime)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXPIRINGTIME$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXPIRINGTIME$4);
                }
                target.setCalendarValue(expiringTime);
            }
        }
        
        /**
         * Sets (as xml) the "expiringTime" element
         */
        public void xsetExpiringTime(org.apache.xmlbeans.XmlDateTime expiringTime)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlDateTime target = null;
                target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(EXPIRINGTIME$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(EXPIRINGTIME$4);
                }
                target.set(expiringTime);
            }
        }
        
        /**
         * Gets the "productAvailabilitySchedule" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType getProductAvailabilitySchedule()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType)get_store().find_element_user(PRODUCTAVAILABILITYSCHEDULE$6, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "productAvailabilitySchedule" element
         */
        public void setProductAvailabilitySchedule(org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType productAvailabilitySchedule)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType)get_store().find_element_user(PRODUCTAVAILABILITYSCHEDULE$6, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType)get_store().add_element_user(PRODUCTAVAILABILITYSCHEDULE$6);
                }
                target.set(productAvailabilitySchedule);
            }
        }
        
        /**
         * Appends and returns a new empty "productAvailabilitySchedule" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType addNewProductAvailabilitySchedule()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.AvailabilityScheduleType)get_store().add_element_user(PRODUCTAVAILABILITYSCHEDULE$6);
                return target;
            }
        }
        
        /**
         * Gets the "commit" element
         */
        public boolean getCommit()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMMIT$8, 0);
                if (target == null)
                {
                    return false;
                }
                return target.getBooleanValue();
            }
        }
        
        /**
         * Gets (as xml) the "commit" element
         */
        public org.apache.xmlbeans.XmlBoolean xgetCommit()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(COMMIT$8, 0);
                return target;
            }
        }
        
        /**
         * Sets the "commit" element
         */
        public void setCommit(boolean commit)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(COMMIT$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(COMMIT$8);
                }
                target.setBooleanValue(commit);
            }
        }
        
        /**
         * Sets (as xml) the "commit" element
         */
        public void xsetCommit(org.apache.xmlbeans.XmlBoolean commit)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlBoolean target = null;
                target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(COMMIT$8, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(COMMIT$8);
                }
                target.set(commit);
            }
        }
        
        /**
         * Gets the "desiredState" element
         */
        public java.lang.String getDesiredState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESIREDSTATE$10, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "desiredState" element
         */
        public org.apache.xmlbeans.XmlString xgetDesiredState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESIREDSTATE$10, 0);
                return target;
            }
        }
        
        /**
         * Sets the "desiredState" element
         */
        public void setDesiredState(java.lang.String desiredState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(DESIREDSTATE$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(DESIREDSTATE$10);
                }
                target.setStringValue(desiredState);
            }
        }
        
        /**
         * Sets (as xml) the "desiredState" element
         */
        public void xsetDesiredState(org.apache.xmlbeans.XmlString desiredState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(DESIREDSTATE$10, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(DESIREDSTATE$10);
                }
                target.set(desiredState);
            }
        }
    }
}
