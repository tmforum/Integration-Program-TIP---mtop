/*
 * An XML document type.
 * Localname: feasibilityCheckRequest
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one feasibilityCheckRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class FeasibilityCheckRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument
{
    
    public FeasibilityCheckRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName FEASIBILITYCHECKREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "feasibilityCheckRequest");
    
    
    /**
     * Gets the "feasibilityCheckRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest getFeasibilityCheckRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest)get_store().find_element_user(FEASIBILITYCHECKREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "feasibilityCheckRequest" element
     */
    public void setFeasibilityCheckRequest(org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest feasibilityCheckRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest)get_store().find_element_user(FEASIBILITYCHECKREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest)get_store().add_element_user(FEASIBILITYCHECKREQUEST$0);
            }
            target.set(feasibilityCheckRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "feasibilityCheckRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest addNewFeasibilityCheckRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest)get_store().add_element_user(FEASIBILITYCHECKREQUEST$0);
            return target;
        }
    }
    /**
     * An XML feasibilityCheckRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class FeasibilityCheckRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.FeasibilityCheckRequestDocument.FeasibilityCheckRequest
    {
        
        public FeasibilityCheckRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FEASIBILITYCHECKREQUESTINPUT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "feasibilityCheckRequestInput");
        
        
        /**
         * Gets the "feasibilityCheckRequestInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType getFeasibilityCheckRequestInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(FEASIBILITYCHECKREQUESTINPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "feasibilityCheckRequestInput" element
         */
        public void setFeasibilityCheckRequestInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType feasibilityCheckRequestInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(FEASIBILITYCHECKREQUESTINPUT$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(FEASIBILITYCHECKREQUESTINPUT$0);
                }
                target.set(feasibilityCheckRequestInput);
            }
        }
        
        /**
         * Appends and returns a new empty "feasibilityCheckRequestInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType addNewFeasibilityCheckRequestInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(FEASIBILITYCHECKREQUESTINPUT$0);
                return target;
            }
        }
    }
}
