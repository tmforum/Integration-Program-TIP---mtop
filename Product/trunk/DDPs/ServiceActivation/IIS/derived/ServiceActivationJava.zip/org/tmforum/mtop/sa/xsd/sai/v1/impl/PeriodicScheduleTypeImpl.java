/*
 * XML Type:  PeriodicScheduleType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * An XML PeriodicScheduleType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public class PeriodicScheduleTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType
{
    
    public PeriodicScheduleTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName START$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "start");
    private static final javax.xml.namespace.QName AVAILABILITYDURATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "availabilityDuration");
    private static final javax.xml.namespace.QName RECURRENCEINTERVAL$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "recurrenceInterval");
    private static final javax.xml.namespace.QName END$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "end");
    private static final javax.xml.namespace.QName EXTENSIONTIME$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "extensionTime");
    
    
    /**
     * Gets the "start" element
     */
    public java.util.Calendar getStart()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(START$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "start" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetStart()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(START$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "start" element
     */
    public void setStart(java.util.Calendar start)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(START$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(START$0);
            }
            target.setCalendarValue(start);
        }
    }
    
    /**
     * Sets (as xml) the "start" element
     */
    public void xsetStart(org.apache.xmlbeans.XmlDateTime start)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(START$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(START$0);
            }
            target.set(start);
        }
    }
    
    /**
     * Gets the "availabilityDuration" element
     */
    public org.apache.xmlbeans.GDuration getAvailabilityDuration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AVAILABILITYDURATION$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getGDurationValue();
        }
    }
    
    /**
     * Gets (as xml) the "availabilityDuration" element
     */
    public org.apache.xmlbeans.XmlDuration xgetAvailabilityDuration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(AVAILABILITYDURATION$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "availabilityDuration" element
     */
    public void setAvailabilityDuration(org.apache.xmlbeans.GDuration availabilityDuration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AVAILABILITYDURATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AVAILABILITYDURATION$2);
            }
            target.setGDurationValue(availabilityDuration);
        }
    }
    
    /**
     * Sets (as xml) the "availabilityDuration" element
     */
    public void xsetAvailabilityDuration(org.apache.xmlbeans.XmlDuration availabilityDuration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(AVAILABILITYDURATION$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDuration)get_store().add_element_user(AVAILABILITYDURATION$2);
            }
            target.set(availabilityDuration);
        }
    }
    
    /**
     * Gets the "recurrenceInterval" element
     */
    public org.apache.xmlbeans.GDuration getRecurrenceInterval()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RECURRENCEINTERVAL$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getGDurationValue();
        }
    }
    
    /**
     * Gets (as xml) the "recurrenceInterval" element
     */
    public org.apache.xmlbeans.XmlDuration xgetRecurrenceInterval()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(RECURRENCEINTERVAL$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "recurrenceInterval" element
     */
    public void setRecurrenceInterval(org.apache.xmlbeans.GDuration recurrenceInterval)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(RECURRENCEINTERVAL$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(RECURRENCEINTERVAL$4);
            }
            target.setGDurationValue(recurrenceInterval);
        }
    }
    
    /**
     * Sets (as xml) the "recurrenceInterval" element
     */
    public void xsetRecurrenceInterval(org.apache.xmlbeans.XmlDuration recurrenceInterval)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(RECURRENCEINTERVAL$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDuration)get_store().add_element_user(RECURRENCEINTERVAL$4);
            }
            target.set(recurrenceInterval);
        }
    }
    
    /**
     * Gets the "end" element
     */
    public java.util.Calendar getEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(END$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "end" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(END$6, 0);
            return target;
        }
    }
    
    /**
     * Tests for nil "end" element
     */
    public boolean isNilEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(END$6, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * Sets the "end" element
     */
    public void setEnd(java.util.Calendar end)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(END$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(END$6);
            }
            target.setCalendarValue(end);
        }
    }
    
    /**
     * Sets (as xml) the "end" element
     */
    public void xsetEnd(org.apache.xmlbeans.XmlDateTime end)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(END$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(END$6);
            }
            target.set(end);
        }
    }
    
    /**
     * Nils the "end" element
     */
    public void setNilEnd()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(END$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(END$6);
            }
            target.setNil();
        }
    }
    
    /**
     * Gets a List of "extensionTime" elements
     */
    public java.util.List<org.apache.xmlbeans.GDuration> getExtensionTimeList()
    {
        final class ExtensionTimeList extends java.util.AbstractList<org.apache.xmlbeans.GDuration>
        {
            public org.apache.xmlbeans.GDuration get(int i)
                { return PeriodicScheduleTypeImpl.this.getExtensionTimeArray(i); }
            
            public org.apache.xmlbeans.GDuration set(int i, org.apache.xmlbeans.GDuration o)
            {
                org.apache.xmlbeans.GDuration old = PeriodicScheduleTypeImpl.this.getExtensionTimeArray(i);
                PeriodicScheduleTypeImpl.this.setExtensionTimeArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.GDuration o)
                { PeriodicScheduleTypeImpl.this.insertExtensionTime(i, o); }
            
            public org.apache.xmlbeans.GDuration remove(int i)
            {
                org.apache.xmlbeans.GDuration old = PeriodicScheduleTypeImpl.this.getExtensionTimeArray(i);
                PeriodicScheduleTypeImpl.this.removeExtensionTime(i);
                return old;
            }
            
            public int size()
                { return PeriodicScheduleTypeImpl.this.sizeOfExtensionTimeArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ExtensionTimeList();
        }
    }
    
    /**
     * Gets array of all "extensionTime" elements
     */
    public org.apache.xmlbeans.GDuration[] getExtensionTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EXTENSIONTIME$8, targetList);
            org.apache.xmlbeans.GDuration[] result = new org.apache.xmlbeans.GDuration[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getGDurationValue();
            return result;
        }
    }
    
    /**
     * Gets ith "extensionTime" element
     */
    public org.apache.xmlbeans.GDuration getExtensionTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXTENSIONTIME$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getGDurationValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "extensionTime" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlDuration> xgetExtensionTimeList()
    {
        final class ExtensionTimeList extends java.util.AbstractList<org.apache.xmlbeans.XmlDuration>
        {
            public org.apache.xmlbeans.XmlDuration get(int i)
                { return PeriodicScheduleTypeImpl.this.xgetExtensionTimeArray(i); }
            
            public org.apache.xmlbeans.XmlDuration set(int i, org.apache.xmlbeans.XmlDuration o)
            {
                org.apache.xmlbeans.XmlDuration old = PeriodicScheduleTypeImpl.this.xgetExtensionTimeArray(i);
                PeriodicScheduleTypeImpl.this.xsetExtensionTimeArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlDuration o)
                { PeriodicScheduleTypeImpl.this.insertNewExtensionTime(i).set(o); }
            
            public org.apache.xmlbeans.XmlDuration remove(int i)
            {
                org.apache.xmlbeans.XmlDuration old = PeriodicScheduleTypeImpl.this.xgetExtensionTimeArray(i);
                PeriodicScheduleTypeImpl.this.removeExtensionTime(i);
                return old;
            }
            
            public int size()
                { return PeriodicScheduleTypeImpl.this.sizeOfExtensionTimeArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ExtensionTimeList();
        }
    }
    
    /**
     * Gets (as xml) array of all "extensionTime" elements
     */
    public org.apache.xmlbeans.XmlDuration[] xgetExtensionTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EXTENSIONTIME$8, targetList);
            org.apache.xmlbeans.XmlDuration[] result = new org.apache.xmlbeans.XmlDuration[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "extensionTime" element
     */
    public org.apache.xmlbeans.XmlDuration xgetExtensionTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(EXTENSIONTIME$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlDuration)target;
        }
    }
    
    /**
     * Tests for nil ith "extensionTime" element
     */
    public boolean isNilExtensionTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(EXTENSIONTIME$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "extensionTime" element
     */
    public int sizeOfExtensionTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXTENSIONTIME$8);
        }
    }
    
    /**
     * Sets array of all "extensionTime" element
     */
    public void setExtensionTimeArray(org.apache.xmlbeans.GDuration[] extensionTimeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(extensionTimeArray, EXTENSIONTIME$8);
        }
    }
    
    /**
     * Sets ith "extensionTime" element
     */
    public void setExtensionTimeArray(int i, org.apache.xmlbeans.GDuration extensionTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXTENSIONTIME$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setGDurationValue(extensionTime);
        }
    }
    
    /**
     * Sets (as xml) array of all "extensionTime" element
     */
    public void xsetExtensionTimeArray(org.apache.xmlbeans.XmlDuration[]extensionTimeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(extensionTimeArray, EXTENSIONTIME$8);
        }
    }
    
    /**
     * Sets (as xml) ith "extensionTime" element
     */
    public void xsetExtensionTimeArray(int i, org.apache.xmlbeans.XmlDuration extensionTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(EXTENSIONTIME$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(extensionTime);
        }
    }
    
    /**
     * Nils the ith "extensionTime" element
     */
    public void setNilExtensionTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(EXTENSIONTIME$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts the value as the ith "extensionTime" element
     */
    public void insertExtensionTime(int i, org.apache.xmlbeans.GDuration extensionTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(EXTENSIONTIME$8, i);
            target.setGDurationValue(extensionTime);
        }
    }
    
    /**
     * Appends the value as the last "extensionTime" element
     */
    public void addExtensionTime(org.apache.xmlbeans.GDuration extensionTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXTENSIONTIME$8);
            target.setGDurationValue(extensionTime);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "extensionTime" element
     */
    public org.apache.xmlbeans.XmlDuration insertNewExtensionTime(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().insert_element_user(EXTENSIONTIME$8, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "extensionTime" element
     */
    public org.apache.xmlbeans.XmlDuration addNewExtensionTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().add_element_user(EXTENSIONTIME$8);
            return target;
        }
    }
    
    /**
     * Removes the ith "extensionTime" element
     */
    public void removeExtensionTime(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXTENSIONTIME$8, i);
        }
    }
}
