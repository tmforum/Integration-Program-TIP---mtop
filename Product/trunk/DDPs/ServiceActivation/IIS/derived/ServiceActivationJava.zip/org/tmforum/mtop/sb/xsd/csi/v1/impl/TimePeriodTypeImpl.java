/*
 * XML Type:  TimePeriodType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML TimePeriodType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public class TimePeriodTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType
{
    
    public TimePeriodTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName STARTDATETIME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "startDateTime");
    private static final javax.xml.namespace.QName ENDDATETIME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "endDateTime");
    
    
    /**
     * Gets the "startDateTime" element
     */
    public org.apache.xmlbeans.XmlObject getStartDateTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(STARTDATETIME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "startDateTime" element
     */
    public boolean isSetStartDateTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STARTDATETIME$0) != 0;
        }
    }
    
    /**
     * Sets the "startDateTime" element
     */
    public void setStartDateTime(org.apache.xmlbeans.XmlObject startDateTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(STARTDATETIME$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(STARTDATETIME$0);
            }
            target.set(startDateTime);
        }
    }
    
    /**
     * Appends and returns a new empty "startDateTime" element
     */
    public org.apache.xmlbeans.XmlObject addNewStartDateTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(STARTDATETIME$0);
            return target;
        }
    }
    
    /**
     * Unsets the "startDateTime" element
     */
    public void unsetStartDateTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STARTDATETIME$0, 0);
        }
    }
    
    /**
     * Gets the "endDateTime" element
     */
    public org.apache.xmlbeans.XmlObject getEndDateTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(ENDDATETIME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "endDateTime" element
     */
    public boolean isSetEndDateTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(ENDDATETIME$2) != 0;
        }
    }
    
    /**
     * Sets the "endDateTime" element
     */
    public void setEndDateTime(org.apache.xmlbeans.XmlObject endDateTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(ENDDATETIME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(ENDDATETIME$2);
            }
            target.set(endDateTime);
        }
    }
    
    /**
     * Appends and returns a new empty "endDateTime" element
     */
    public org.apache.xmlbeans.XmlObject addNewEndDateTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(ENDDATETIME$2);
            return target;
        }
    }
    
    /**
     * Unsets the "endDateTime" element
     */
    public void unsetEndDateTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(ENDDATETIME$2, 0);
        }
    }
}
