/*
 * XML Type:  ServiceSpecVersionType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1;


/**
 * An XML ServiceSpecVersionType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public interface ServiceSpecVersionType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ServiceSpecVersionType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("servicespecversiontype7015type");
    
    /**
     * Gets the "svcSpecRevisionName" element
     */
    java.lang.String getSvcSpecRevisionName();
    
    /**
     * Gets (as xml) the "svcSpecRevisionName" element
     */
    org.apache.xmlbeans.XmlString xgetSvcSpecRevisionName();
    
    /**
     * True if has "svcSpecRevisionName" element
     */
    boolean isSetSvcSpecRevisionName();
    
    /**
     * Sets the "svcSpecRevisionName" element
     */
    void setSvcSpecRevisionName(java.lang.String svcSpecRevisionName);
    
    /**
     * Sets (as xml) the "svcSpecRevisionName" element
     */
    void xsetSvcSpecRevisionName(org.apache.xmlbeans.XmlString svcSpecRevisionName);
    
    /**
     * Unsets the "svcSpecRevisionName" element
     */
    void unsetSvcSpecRevisionName();
    
    /**
     * Gets the "svcSpecRevisionFormat" element
     */
    java.lang.String getSvcSpecRevisionFormat();
    
    /**
     * Gets (as xml) the "svcSpecRevisionFormat" element
     */
    org.apache.xmlbeans.XmlString xgetSvcSpecRevisionFormat();
    
    /**
     * True if has "svcSpecRevisionFormat" element
     */
    boolean isSetSvcSpecRevisionFormat();
    
    /**
     * Sets the "svcSpecRevisionFormat" element
     */
    void setSvcSpecRevisionFormat(java.lang.String svcSpecRevisionFormat);
    
    /**
     * Sets (as xml) the "svcSpecRevisionFormat" element
     */
    void xsetSvcSpecRevisionFormat(org.apache.xmlbeans.XmlString svcSpecRevisionFormat);
    
    /**
     * Unsets the "svcSpecRevisionFormat" element
     */
    void unsetSvcSpecRevisionFormat();
    
    /**
     * Gets the "svcSpecRevisionNumber" element
     */
    java.lang.String getSvcSpecRevisionNumber();
    
    /**
     * Gets (as xml) the "svcSpecRevisionNumber" element
     */
    org.apache.xmlbeans.XmlString xgetSvcSpecRevisionNumber();
    
    /**
     * True if has "svcSpecRevisionNumber" element
     */
    boolean isSetSvcSpecRevisionNumber();
    
    /**
     * Sets the "svcSpecRevisionNumber" element
     */
    void setSvcSpecRevisionNumber(java.lang.String svcSpecRevisionNumber);
    
    /**
     * Sets (as xml) the "svcSpecRevisionNumber" element
     */
    void xsetSvcSpecRevisionNumber(org.apache.xmlbeans.XmlString svcSpecRevisionNumber);
    
    /**
     * Unsets the "svcSpecRevisionNumber" element
     */
    void unsetSvcSpecRevisionNumber();
    
    /**
     * Gets the "svcSpecRevisionReason" element
     */
    java.lang.String getSvcSpecRevisionReason();
    
    /**
     * Gets (as xml) the "svcSpecRevisionReason" element
     */
    org.apache.xmlbeans.XmlString xgetSvcSpecRevisionReason();
    
    /**
     * True if has "svcSpecRevisionReason" element
     */
    boolean isSetSvcSpecRevisionReason();
    
    /**
     * Sets the "svcSpecRevisionReason" element
     */
    void setSvcSpecRevisionReason(java.lang.String svcSpecRevisionReason);
    
    /**
     * Sets (as xml) the "svcSpecRevisionReason" element
     */
    void xsetSvcSpecRevisionReason(org.apache.xmlbeans.XmlString svcSpecRevisionReason);
    
    /**
     * Unsets the "svcSpecRevisionReason" element
     */
    void unsetSvcSpecRevisionReason();
    
    /**
     * Gets the "svcSpecRevisionSemantics" element
     */
    java.lang.String getSvcSpecRevisionSemantics();
    
    /**
     * Gets (as xml) the "svcSpecRevisionSemantics" element
     */
    org.apache.xmlbeans.XmlString xgetSvcSpecRevisionSemantics();
    
    /**
     * True if has "svcSpecRevisionSemantics" element
     */
    boolean isSetSvcSpecRevisionSemantics();
    
    /**
     * Sets the "svcSpecRevisionSemantics" element
     */
    void setSvcSpecRevisionSemantics(java.lang.String svcSpecRevisionSemantics);
    
    /**
     * Sets (as xml) the "svcSpecRevisionSemantics" element
     */
    void xsetSvcSpecRevisionSemantics(org.apache.xmlbeans.XmlString svcSpecRevisionSemantics);
    
    /**
     * Unsets the "svcSpecRevisionSemantics" element
     */
    void unsetSvcSpecRevisionSemantics();
    
    /**
     * Gets the "svcSpecRevisionTimestamp" element
     */
    java.util.Calendar getSvcSpecRevisionTimestamp();
    
    /**
     * Gets (as xml) the "svcSpecRevisionTimestamp" element
     */
    org.apache.xmlbeans.XmlDate xgetSvcSpecRevisionTimestamp();
    
    /**
     * True if has "svcSpecRevisionTimestamp" element
     */
    boolean isSetSvcSpecRevisionTimestamp();
    
    /**
     * Sets the "svcSpecRevisionTimestamp" element
     */
    void setSvcSpecRevisionTimestamp(java.util.Calendar svcSpecRevisionTimestamp);
    
    /**
     * Sets (as xml) the "svcSpecRevisionTimestamp" element
     */
    void xsetSvcSpecRevisionTimestamp(org.apache.xmlbeans.XmlDate svcSpecRevisionTimestamp);
    
    /**
     * Unsets the "svcSpecRevisionTimestamp" element
     */
    void unsetSvcSpecRevisionTimestamp();
    
    /**
     * Gets the "svcSpecRevisionValidityPeriod" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType getSvcSpecRevisionValidityPeriod();
    
    /**
     * True if has "svcSpecRevisionValidityPeriod" element
     */
    boolean isSetSvcSpecRevisionValidityPeriod();
    
    /**
     * Sets the "svcSpecRevisionValidityPeriod" element
     */
    void setSvcSpecRevisionValidityPeriod(org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType svcSpecRevisionValidityPeriod);
    
    /**
     * Appends and returns a new empty "svcSpecRevisionValidityPeriod" element
     */
    org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType addNewSvcSpecRevisionValidityPeriod();
    
    /**
     * Unsets the "svcSpecRevisionValidityPeriod" element
     */
    void unsetSvcSpecRevisionValidityPeriod();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType newInstance() {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sb.xsd.csi.v1.ServiceSpecVersionType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
