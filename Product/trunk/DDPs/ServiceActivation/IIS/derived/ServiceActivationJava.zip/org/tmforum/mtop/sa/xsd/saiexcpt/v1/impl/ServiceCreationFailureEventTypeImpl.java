/*
 * XML Type:  ServiceCreationFailureEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1
 * Java type: org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.saiexcpt.v1.impl;
/**
 * An XML ServiceCreationFailureEventType(@http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1).
 *
 * This is a complex type.
 */
public class ServiceCreationFailureEventTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceCreationFailureEventType
{
    
    public ServiceCreationFailureEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName CFSNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "cfsName");
    private static final javax.xml.namespace.QName CURRENTSTATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "currentState");
    private static final javax.xml.namespace.QName FAILEDSTATE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "failedState");
    
    
    /**
     * Gets the "cfsName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getCfsName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CFSNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "cfsName" element
     */
    public void setCfsName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType cfsName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CFSNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CFSNAME$0);
            }
            target.set(cfsName);
        }
    }
    
    /**
     * Appends and returns a new empty "cfsName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewCfsName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CFSNAME$0);
            return target;
        }
    }
    
    /**
     * Gets the "currentState" element
     */
    public java.lang.String getCurrentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CURRENTSTATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "currentState" element
     */
    public org.apache.xmlbeans.XmlString xgetCurrentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CURRENTSTATE$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "currentState" element
     */
    public void setCurrentState(java.lang.String currentState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CURRENTSTATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CURRENTSTATE$2);
            }
            target.setStringValue(currentState);
        }
    }
    
    /**
     * Sets (as xml) the "currentState" element
     */
    public void xsetCurrentState(org.apache.xmlbeans.XmlString currentState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CURRENTSTATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CURRENTSTATE$2);
            }
            target.set(currentState);
        }
    }
    
    /**
     * Gets the "failedState" element
     */
    public java.lang.String getFailedState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILEDSTATE$4, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "failedState" element
     */
    public org.apache.xmlbeans.XmlString xgetFailedState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FAILEDSTATE$4, 0);
            return target;
        }
    }
    
    /**
     * Sets the "failedState" element
     */
    public void setFailedState(java.lang.String failedState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(FAILEDSTATE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(FAILEDSTATE$4);
            }
            target.setStringValue(failedState);
        }
    }
    
    /**
     * Sets (as xml) the "failedState" element
     */
    public void xsetFailedState(org.apache.xmlbeans.XmlString failedState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(FAILEDSTATE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(FAILEDSTATE$4);
            }
            target.set(failedState);
        }
    }
}
