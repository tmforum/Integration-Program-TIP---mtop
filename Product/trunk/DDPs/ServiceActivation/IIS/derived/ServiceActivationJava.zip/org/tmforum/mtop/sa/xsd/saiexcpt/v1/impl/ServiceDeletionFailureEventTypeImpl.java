/*
 * XML Type:  ServiceDeletionFailureEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1
 * Java type: org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.saiexcpt.v1.impl;
/**
 * An XML ServiceDeletionFailureEventType(@http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1).
 *
 * This is a complex type.
 */
public class ServiceDeletionFailureEventTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceDeletionFailureEventType
{
    
    public ServiceDeletionFailureEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEREQUESTID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "serviceRequestID");
    private static final javax.xml.namespace.QName PRODUCTNAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "productName");
    private static final javax.xml.namespace.QName CFSNAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "cfsName");
    private static final javax.xml.namespace.QName CURRENTSTATE$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "currentState");
    
    
    /**
     * Gets the "serviceRequestID" element
     */
    public java.lang.String getServiceRequestID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEREQUESTID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceRequestID" element
     */
    public org.apache.xmlbeans.XmlString xgetServiceRequestID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICEREQUESTID$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "serviceRequestID" element
     */
    public void setServiceRequestID(java.lang.String serviceRequestID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEREQUESTID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICEREQUESTID$0);
            }
            target.setStringValue(serviceRequestID);
        }
    }
    
    /**
     * Sets (as xml) the "serviceRequestID" element
     */
    public void xsetServiceRequestID(org.apache.xmlbeans.XmlString serviceRequestID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICEREQUESTID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICEREQUESTID$0);
            }
            target.set(serviceRequestID);
        }
    }
    
    /**
     * Gets the "productName" element
     */
    public java.lang.String getProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "productName" element
     */
    public org.apache.xmlbeans.XmlString xgetProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PRODUCTNAME$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "productName" element
     */
    public void setProductName(java.lang.String productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRODUCTNAME$2);
            }
            target.setStringValue(productName);
        }
    }
    
    /**
     * Sets (as xml) the "productName" element
     */
    public void xsetProductName(org.apache.xmlbeans.XmlString productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PRODUCTNAME$2);
            }
            target.set(productName);
        }
    }
    
    /**
     * Gets the "cfsName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getCfsName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CFSNAME$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "cfsName" element
     */
    public void setCfsName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType cfsName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CFSNAME$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CFSNAME$4);
            }
            target.set(cfsName);
        }
    }
    
    /**
     * Appends and returns a new empty "cfsName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewCfsName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CFSNAME$4);
            return target;
        }
    }
    
    /**
     * Gets the "currentState" element
     */
    public java.lang.String getCurrentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CURRENTSTATE$6, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "currentState" element
     */
    public org.apache.xmlbeans.XmlString xgetCurrentState()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CURRENTSTATE$6, 0);
            return target;
        }
    }
    
    /**
     * Sets the "currentState" element
     */
    public void setCurrentState(java.lang.String currentState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CURRENTSTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CURRENTSTATE$6);
            }
            target.setStringValue(currentState);
        }
    }
    
    /**
     * Sets (as xml) the "currentState" element
     */
    public void xsetCurrentState(org.apache.xmlbeans.XmlString currentState)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CURRENTSTATE$6, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CURRENTSTATE$6);
            }
            target.set(currentState);
        }
    }
}
