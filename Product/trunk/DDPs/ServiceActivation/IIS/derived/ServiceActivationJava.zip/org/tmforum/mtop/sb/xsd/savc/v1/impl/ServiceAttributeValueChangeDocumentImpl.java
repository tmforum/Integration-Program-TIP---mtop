/*
 * An XML document type.
 * Localname: serviceAttributeValueChange
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/savc/v1
 * Java type: org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.savc.v1.impl;
/**
 * A document containing one serviceAttributeValueChange(@http://www.tmforum.org/mtop/sb/xsd/savc/v1) element.
 *
 * This is a complex type.
 */
public class ServiceAttributeValueChangeDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeDocument
{
    
    public ServiceAttributeValueChangeDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEATTRIBUTEVALUECHANGE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/savc/v1", "serviceAttributeValueChange");
    
    
    /**
     * Gets the "serviceAttributeValueChange" element
     */
    public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType getServiceAttributeValueChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType)get_store().find_element_user(SERVICEATTRIBUTEVALUECHANGE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "serviceAttributeValueChange" element
     */
    public void setServiceAttributeValueChange(org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType serviceAttributeValueChange)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType)get_store().find_element_user(SERVICEATTRIBUTEVALUECHANGE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType)get_store().add_element_user(SERVICEATTRIBUTEVALUECHANGE$0);
            }
            target.set(serviceAttributeValueChange);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceAttributeValueChange" element
     */
    public org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType addNewServiceAttributeValueChange()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.savc.v1.ServiceAttributeValueChangeType)get_store().add_element_user(SERVICEATTRIBUTEVALUECHANGE$0);
            return target;
        }
    }
}
