/*
 * XML Type:  RandomScheduleType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * An XML RandomScheduleType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public class RandomScheduleTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RandomScheduleType
{
    
    public RandomScheduleTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName START$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "start");
    private static final javax.xml.namespace.QName AVAILABILITYDURATION$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "availabilityDuration");
    private static final javax.xml.namespace.QName EXTENSIONTIME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "extensionTime");
    
    
    /**
     * Gets a List of "start" elements
     */
    public java.util.List<java.util.Calendar> getStartList()
    {
        final class StartList extends java.util.AbstractList<java.util.Calendar>
        {
            public java.util.Calendar get(int i)
                { return RandomScheduleTypeImpl.this.getStartArray(i); }
            
            public java.util.Calendar set(int i, java.util.Calendar o)
            {
                java.util.Calendar old = RandomScheduleTypeImpl.this.getStartArray(i);
                RandomScheduleTypeImpl.this.setStartArray(i, o);
                return old;
            }
            
            public void add(int i, java.util.Calendar o)
                { RandomScheduleTypeImpl.this.insertStart(i, o); }
            
            public java.util.Calendar remove(int i)
            {
                java.util.Calendar old = RandomScheduleTypeImpl.this.getStartArray(i);
                RandomScheduleTypeImpl.this.removeStart(i);
                return old;
            }
            
            public int size()
                { return RandomScheduleTypeImpl.this.sizeOfStartArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new StartList();
        }
    }
    
    /**
     * Gets array of all "start" elements
     */
    public java.util.Calendar[] getStartArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(START$0, targetList);
            java.util.Calendar[] result = new java.util.Calendar[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getCalendarValue();
            return result;
        }
    }
    
    /**
     * Gets ith "start" element
     */
    public java.util.Calendar getStartArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(START$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "start" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlDateTime> xgetStartList()
    {
        final class StartList extends java.util.AbstractList<org.apache.xmlbeans.XmlDateTime>
        {
            public org.apache.xmlbeans.XmlDateTime get(int i)
                { return RandomScheduleTypeImpl.this.xgetStartArray(i); }
            
            public org.apache.xmlbeans.XmlDateTime set(int i, org.apache.xmlbeans.XmlDateTime o)
            {
                org.apache.xmlbeans.XmlDateTime old = RandomScheduleTypeImpl.this.xgetStartArray(i);
                RandomScheduleTypeImpl.this.xsetStartArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlDateTime o)
                { RandomScheduleTypeImpl.this.insertNewStart(i).set(o); }
            
            public org.apache.xmlbeans.XmlDateTime remove(int i)
            {
                org.apache.xmlbeans.XmlDateTime old = RandomScheduleTypeImpl.this.xgetStartArray(i);
                RandomScheduleTypeImpl.this.removeStart(i);
                return old;
            }
            
            public int size()
                { return RandomScheduleTypeImpl.this.sizeOfStartArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new StartList();
        }
    }
    
    /**
     * Gets (as xml) array of all "start" elements
     */
    public org.apache.xmlbeans.XmlDateTime[] xgetStartArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(START$0, targetList);
            org.apache.xmlbeans.XmlDateTime[] result = new org.apache.xmlbeans.XmlDateTime[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "start" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetStartArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(START$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlDateTime)target;
        }
    }
    
    /**
     * Returns number of "start" element
     */
    public int sizeOfStartArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(START$0);
        }
    }
    
    /**
     * Sets array of all "start" element
     */
    public void setStartArray(java.util.Calendar[] startArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(startArray, START$0);
        }
    }
    
    /**
     * Sets ith "start" element
     */
    public void setStartArray(int i, java.util.Calendar start)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(START$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setCalendarValue(start);
        }
    }
    
    /**
     * Sets (as xml) array of all "start" element
     */
    public void xsetStartArray(org.apache.xmlbeans.XmlDateTime[]startArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(startArray, START$0);
        }
    }
    
    /**
     * Sets (as xml) ith "start" element
     */
    public void xsetStartArray(int i, org.apache.xmlbeans.XmlDateTime start)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(START$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(start);
        }
    }
    
    /**
     * Inserts the value as the ith "start" element
     */
    public void insertStart(int i, java.util.Calendar start)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(START$0, i);
            target.setCalendarValue(start);
        }
    }
    
    /**
     * Appends the value as the last "start" element
     */
    public void addStart(java.util.Calendar start)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(START$0);
            target.setCalendarValue(start);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "start" element
     */
    public org.apache.xmlbeans.XmlDateTime insertNewStart(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().insert_element_user(START$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "start" element
     */
    public org.apache.xmlbeans.XmlDateTime addNewStart()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(START$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "start" element
     */
    public void removeStart(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(START$0, i);
        }
    }
    
    /**
     * Gets a List of "availabilityDuration" elements
     */
    public java.util.List<org.apache.xmlbeans.GDuration> getAvailabilityDurationList()
    {
        final class AvailabilityDurationList extends java.util.AbstractList<org.apache.xmlbeans.GDuration>
        {
            public org.apache.xmlbeans.GDuration get(int i)
                { return RandomScheduleTypeImpl.this.getAvailabilityDurationArray(i); }
            
            public org.apache.xmlbeans.GDuration set(int i, org.apache.xmlbeans.GDuration o)
            {
                org.apache.xmlbeans.GDuration old = RandomScheduleTypeImpl.this.getAvailabilityDurationArray(i);
                RandomScheduleTypeImpl.this.setAvailabilityDurationArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.GDuration o)
                { RandomScheduleTypeImpl.this.insertAvailabilityDuration(i, o); }
            
            public org.apache.xmlbeans.GDuration remove(int i)
            {
                org.apache.xmlbeans.GDuration old = RandomScheduleTypeImpl.this.getAvailabilityDurationArray(i);
                RandomScheduleTypeImpl.this.removeAvailabilityDuration(i);
                return old;
            }
            
            public int size()
                { return RandomScheduleTypeImpl.this.sizeOfAvailabilityDurationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new AvailabilityDurationList();
        }
    }
    
    /**
     * Gets array of all "availabilityDuration" elements
     */
    public org.apache.xmlbeans.GDuration[] getAvailabilityDurationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(AVAILABILITYDURATION$2, targetList);
            org.apache.xmlbeans.GDuration[] result = new org.apache.xmlbeans.GDuration[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getGDurationValue();
            return result;
        }
    }
    
    /**
     * Gets ith "availabilityDuration" element
     */
    public org.apache.xmlbeans.GDuration getAvailabilityDurationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AVAILABILITYDURATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getGDurationValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "availabilityDuration" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlDuration> xgetAvailabilityDurationList()
    {
        final class AvailabilityDurationList extends java.util.AbstractList<org.apache.xmlbeans.XmlDuration>
        {
            public org.apache.xmlbeans.XmlDuration get(int i)
                { return RandomScheduleTypeImpl.this.xgetAvailabilityDurationArray(i); }
            
            public org.apache.xmlbeans.XmlDuration set(int i, org.apache.xmlbeans.XmlDuration o)
            {
                org.apache.xmlbeans.XmlDuration old = RandomScheduleTypeImpl.this.xgetAvailabilityDurationArray(i);
                RandomScheduleTypeImpl.this.xsetAvailabilityDurationArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlDuration o)
                { RandomScheduleTypeImpl.this.insertNewAvailabilityDuration(i).set(o); }
            
            public org.apache.xmlbeans.XmlDuration remove(int i)
            {
                org.apache.xmlbeans.XmlDuration old = RandomScheduleTypeImpl.this.xgetAvailabilityDurationArray(i);
                RandomScheduleTypeImpl.this.removeAvailabilityDuration(i);
                return old;
            }
            
            public int size()
                { return RandomScheduleTypeImpl.this.sizeOfAvailabilityDurationArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new AvailabilityDurationList();
        }
    }
    
    /**
     * Gets (as xml) array of all "availabilityDuration" elements
     */
    public org.apache.xmlbeans.XmlDuration[] xgetAvailabilityDurationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(AVAILABILITYDURATION$2, targetList);
            org.apache.xmlbeans.XmlDuration[] result = new org.apache.xmlbeans.XmlDuration[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "availabilityDuration" element
     */
    public org.apache.xmlbeans.XmlDuration xgetAvailabilityDurationArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(AVAILABILITYDURATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlDuration)target;
        }
    }
    
    /**
     * Returns number of "availabilityDuration" element
     */
    public int sizeOfAvailabilityDurationArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(AVAILABILITYDURATION$2);
        }
    }
    
    /**
     * Sets array of all "availabilityDuration" element
     */
    public void setAvailabilityDurationArray(org.apache.xmlbeans.GDuration[] availabilityDurationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(availabilityDurationArray, AVAILABILITYDURATION$2);
        }
    }
    
    /**
     * Sets ith "availabilityDuration" element
     */
    public void setAvailabilityDurationArray(int i, org.apache.xmlbeans.GDuration availabilityDuration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(AVAILABILITYDURATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setGDurationValue(availabilityDuration);
        }
    }
    
    /**
     * Sets (as xml) array of all "availabilityDuration" element
     */
    public void xsetAvailabilityDurationArray(org.apache.xmlbeans.XmlDuration[]availabilityDurationArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(availabilityDurationArray, AVAILABILITYDURATION$2);
        }
    }
    
    /**
     * Sets (as xml) ith "availabilityDuration" element
     */
    public void xsetAvailabilityDurationArray(int i, org.apache.xmlbeans.XmlDuration availabilityDuration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(AVAILABILITYDURATION$2, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(availabilityDuration);
        }
    }
    
    /**
     * Inserts the value as the ith "availabilityDuration" element
     */
    public void insertAvailabilityDuration(int i, org.apache.xmlbeans.GDuration availabilityDuration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(AVAILABILITYDURATION$2, i);
            target.setGDurationValue(availabilityDuration);
        }
    }
    
    /**
     * Appends the value as the last "availabilityDuration" element
     */
    public void addAvailabilityDuration(org.apache.xmlbeans.GDuration availabilityDuration)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(AVAILABILITYDURATION$2);
            target.setGDurationValue(availabilityDuration);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "availabilityDuration" element
     */
    public org.apache.xmlbeans.XmlDuration insertNewAvailabilityDuration(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().insert_element_user(AVAILABILITYDURATION$2, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "availabilityDuration" element
     */
    public org.apache.xmlbeans.XmlDuration addNewAvailabilityDuration()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().add_element_user(AVAILABILITYDURATION$2);
            return target;
        }
    }
    
    /**
     * Removes the ith "availabilityDuration" element
     */
    public void removeAvailabilityDuration(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(AVAILABILITYDURATION$2, i);
        }
    }
    
    /**
     * Gets a List of "extensionTime" elements
     */
    public java.util.List<org.apache.xmlbeans.GDuration> getExtensionTimeList()
    {
        final class ExtensionTimeList extends java.util.AbstractList<org.apache.xmlbeans.GDuration>
        {
            public org.apache.xmlbeans.GDuration get(int i)
                { return RandomScheduleTypeImpl.this.getExtensionTimeArray(i); }
            
            public org.apache.xmlbeans.GDuration set(int i, org.apache.xmlbeans.GDuration o)
            {
                org.apache.xmlbeans.GDuration old = RandomScheduleTypeImpl.this.getExtensionTimeArray(i);
                RandomScheduleTypeImpl.this.setExtensionTimeArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.GDuration o)
                { RandomScheduleTypeImpl.this.insertExtensionTime(i, o); }
            
            public org.apache.xmlbeans.GDuration remove(int i)
            {
                org.apache.xmlbeans.GDuration old = RandomScheduleTypeImpl.this.getExtensionTimeArray(i);
                RandomScheduleTypeImpl.this.removeExtensionTime(i);
                return old;
            }
            
            public int size()
                { return RandomScheduleTypeImpl.this.sizeOfExtensionTimeArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ExtensionTimeList();
        }
    }
    
    /**
     * Gets array of all "extensionTime" elements
     */
    public org.apache.xmlbeans.GDuration[] getExtensionTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EXTENSIONTIME$4, targetList);
            org.apache.xmlbeans.GDuration[] result = new org.apache.xmlbeans.GDuration[targetList.size()];
            for (int i = 0, len = targetList.size() ; i < len ; i++)
                result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getGDurationValue();
            return result;
        }
    }
    
    /**
     * Gets ith "extensionTime" element
     */
    public org.apache.xmlbeans.GDuration getExtensionTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXTENSIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.getGDurationValue();
        }
    }
    
    /**
     * Gets (as xml) a List of "extensionTime" elements
     */
    public java.util.List<org.apache.xmlbeans.XmlDuration> xgetExtensionTimeList()
    {
        final class ExtensionTimeList extends java.util.AbstractList<org.apache.xmlbeans.XmlDuration>
        {
            public org.apache.xmlbeans.XmlDuration get(int i)
                { return RandomScheduleTypeImpl.this.xgetExtensionTimeArray(i); }
            
            public org.apache.xmlbeans.XmlDuration set(int i, org.apache.xmlbeans.XmlDuration o)
            {
                org.apache.xmlbeans.XmlDuration old = RandomScheduleTypeImpl.this.xgetExtensionTimeArray(i);
                RandomScheduleTypeImpl.this.xsetExtensionTimeArray(i, o);
                return old;
            }
            
            public void add(int i, org.apache.xmlbeans.XmlDuration o)
                { RandomScheduleTypeImpl.this.insertNewExtensionTime(i).set(o); }
            
            public org.apache.xmlbeans.XmlDuration remove(int i)
            {
                org.apache.xmlbeans.XmlDuration old = RandomScheduleTypeImpl.this.xgetExtensionTimeArray(i);
                RandomScheduleTypeImpl.this.removeExtensionTime(i);
                return old;
            }
            
            public int size()
                { return RandomScheduleTypeImpl.this.sizeOfExtensionTimeArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ExtensionTimeList();
        }
    }
    
    /**
     * Gets (as xml) array of all "extensionTime" elements
     */
    public org.apache.xmlbeans.XmlDuration[] xgetExtensionTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(EXTENSIONTIME$4, targetList);
            org.apache.xmlbeans.XmlDuration[] result = new org.apache.xmlbeans.XmlDuration[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets (as xml) ith "extensionTime" element
     */
    public org.apache.xmlbeans.XmlDuration xgetExtensionTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(EXTENSIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return (org.apache.xmlbeans.XmlDuration)target;
        }
    }
    
    /**
     * Tests for nil ith "extensionTime" element
     */
    public boolean isNilExtensionTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(EXTENSIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target.isNil();
        }
    }
    
    /**
     * Returns number of "extensionTime" element
     */
    public int sizeOfExtensionTimeArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EXTENSIONTIME$4);
        }
    }
    
    /**
     * Sets array of all "extensionTime" element
     */
    public void setExtensionTimeArray(org.apache.xmlbeans.GDuration[] extensionTimeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(extensionTimeArray, EXTENSIONTIME$4);
        }
    }
    
    /**
     * Sets ith "extensionTime" element
     */
    public void setExtensionTimeArray(int i, org.apache.xmlbeans.GDuration extensionTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXTENSIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setGDurationValue(extensionTime);
        }
    }
    
    /**
     * Sets (as xml) array of all "extensionTime" element
     */
    public void xsetExtensionTimeArray(org.apache.xmlbeans.XmlDuration[]extensionTimeArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(extensionTimeArray, EXTENSIONTIME$4);
        }
    }
    
    /**
     * Sets (as xml) ith "extensionTime" element
     */
    public void xsetExtensionTimeArray(int i, org.apache.xmlbeans.XmlDuration extensionTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(EXTENSIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(extensionTime);
        }
    }
    
    /**
     * Nils the ith "extensionTime" element
     */
    public void setNilExtensionTimeArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().find_element_user(EXTENSIONTIME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.setNil();
        }
    }
    
    /**
     * Inserts the value as the ith "extensionTime" element
     */
    public void insertExtensionTime(int i, org.apache.xmlbeans.GDuration extensionTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = 
                (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(EXTENSIONTIME$4, i);
            target.setGDurationValue(extensionTime);
        }
    }
    
    /**
     * Appends the value as the last "extensionTime" element
     */
    public void addExtensionTime(org.apache.xmlbeans.GDuration extensionTime)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXTENSIONTIME$4);
            target.setGDurationValue(extensionTime);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "extensionTime" element
     */
    public org.apache.xmlbeans.XmlDuration insertNewExtensionTime(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().insert_element_user(EXTENSIONTIME$4, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "extensionTime" element
     */
    public org.apache.xmlbeans.XmlDuration addNewExtensionTime()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDuration target = null;
            target = (org.apache.xmlbeans.XmlDuration)get_store().add_element_user(EXTENSIONTIME$4);
            return target;
        }
    }
    
    /**
     * Removes the ith "extensionTime" element
     */
    public void removeExtensionTime(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EXTENSIONTIME$4, i);
        }
    }
}
