/*
 * XML Type:  CfsStateChangeEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sairsp/v1
 * Java type: org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sairsp.v1.impl;
/**
 * An XML CfsStateChangeEventType(@http://www.tmforum.org/mtop/sa/xsd/sairsp/v1).
 *
 * This is a complex type.
 */
public class CfsStateChangeEventTypeImpl extends org.tmforum.mtop.sa.xsd.sairsp.v1.impl.RootResponseTypeImpl implements org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType
{
    
    public CfsStateChangeEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICESTATECHANGELIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "serviceStateChangeList");
    private static final javax.xml.namespace.QName LAST$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "last");
    
    
    /**
     * Gets a List of "serviceStateChangeList" elements
     */
    public java.util.List<org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType> getServiceStateChangeListList()
    {
        final class ServiceStateChangeListList extends java.util.AbstractList<org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType>
        {
            public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType get(int i)
                { return CfsStateChangeEventTypeImpl.this.getServiceStateChangeListArray(i); }
            
            public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType set(int i, org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType o)
            {
                org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType old = CfsStateChangeEventTypeImpl.this.getServiceStateChangeListArray(i);
                CfsStateChangeEventTypeImpl.this.setServiceStateChangeListArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType o)
                { CfsStateChangeEventTypeImpl.this.insertNewServiceStateChangeList(i).set(o); }
            
            public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType remove(int i)
            {
                org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType old = CfsStateChangeEventTypeImpl.this.getServiceStateChangeListArray(i);
                CfsStateChangeEventTypeImpl.this.removeServiceStateChangeList(i);
                return old;
            }
            
            public int size()
                { return CfsStateChangeEventTypeImpl.this.sizeOfServiceStateChangeListArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceStateChangeListList();
        }
    }
    
    /**
     * Gets array of all "serviceStateChangeList" elements
     */
    public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType[] getServiceStateChangeListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICESTATECHANGELIST$0, targetList);
            org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType[] result = new org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceStateChangeList" element
     */
    public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType getServiceStateChangeListArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType)get_store().find_element_user(SERVICESTATECHANGELIST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceStateChangeList" element
     */
    public int sizeOfServiceStateChangeListArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESTATECHANGELIST$0);
        }
    }
    
    /**
     * Sets array of all "serviceStateChangeList" element
     */
    public void setServiceStateChangeListArray(org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType[] serviceStateChangeListArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceStateChangeListArray, SERVICESTATECHANGELIST$0);
        }
    }
    
    /**
     * Sets ith "serviceStateChangeList" element
     */
    public void setServiceStateChangeListArray(int i, org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType serviceStateChangeList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType)get_store().find_element_user(SERVICESTATECHANGELIST$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceStateChangeList);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceStateChangeList" element
     */
    public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType insertNewServiceStateChangeList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType)get_store().insert_element_user(SERVICESTATECHANGELIST$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceStateChangeList" element
     */
    public org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType addNewServiceStateChangeList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType target = null;
            target = (org.tmforum.mtop.sb.xsd.ssc.v1.ServiceStateChangeType)get_store().add_element_user(SERVICESTATECHANGELIST$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceStateChangeList" element
     */
    public void removeServiceStateChangeList(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESTATECHANGELIST$0, i);
        }
    }
    
    /**
     * Gets the "last" element
     */
    public boolean getLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                return false;
            }
            return target.getBooleanValue();
        }
    }
    
    /**
     * Gets (as xml) the "last" element
     */
    public org.apache.xmlbeans.XmlBoolean xgetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(LAST$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "last" element
     */
    public boolean isSetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(LAST$2) != 0;
        }
    }
    
    /**
     * Sets the "last" element
     */
    public void setLast(boolean last)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(LAST$2);
            }
            target.setBooleanValue(last);
        }
    }
    
    /**
     * Sets (as xml) the "last" element
     */
    public void xsetLast(org.apache.xmlbeans.XmlBoolean last)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlBoolean target = null;
            target = (org.apache.xmlbeans.XmlBoolean)get_store().find_element_user(LAST$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlBoolean)get_store().add_element_user(LAST$2);
            }
            target.set(last);
        }
    }
    
    /**
     * Unsets the "last" element
     */
    public void unsetLast()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(LAST$2, 0);
        }
    }
}
