/*
 * XML Type:  SOAwareParamsResType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sairsp/v1
 * Java type: org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sairsp.v1.impl;
/**
 * An XML SOAwareParamsResType(@http://www.tmforum.org/mtop/sa/xsd/sairsp/v1).
 *
 * This is a complex type.
 */
public class SOAwareParamsResTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType
{
    
    public SOAwareParamsResTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEORDERID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "serviceOrderID");
    private static final javax.xml.namespace.QName EXPECTEDCOMPLETIONDATE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "expectedCompletionDate");
    
    
    /**
     * Gets the "serviceOrderID" element
     */
    public java.lang.String getServiceOrderID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEORDERID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceOrderID" element
     */
    public org.apache.xmlbeans.XmlString xgetServiceOrderID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICEORDERID$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "serviceOrderID" element
     */
    public void setServiceOrderID(java.lang.String serviceOrderID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEORDERID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICEORDERID$0);
            }
            target.setStringValue(serviceOrderID);
        }
    }
    
    /**
     * Sets (as xml) the "serviceOrderID" element
     */
    public void xsetServiceOrderID(org.apache.xmlbeans.XmlString serviceOrderID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICEORDERID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICEORDERID$0);
            }
            target.set(serviceOrderID);
        }
    }
    
    /**
     * Gets the "expectedCompletionDate" element
     */
    public java.util.Calendar getExpectedCompletionDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXPECTEDCOMPLETIONDATE$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getCalendarValue();
        }
    }
    
    /**
     * Gets (as xml) the "expectedCompletionDate" element
     */
    public org.apache.xmlbeans.XmlDateTime xgetExpectedCompletionDate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(EXPECTEDCOMPLETIONDATE$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "expectedCompletionDate" element
     */
    public void setExpectedCompletionDate(java.util.Calendar expectedCompletionDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EXPECTEDCOMPLETIONDATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EXPECTEDCOMPLETIONDATE$2);
            }
            target.setCalendarValue(expectedCompletionDate);
        }
    }
    
    /**
     * Sets (as xml) the "expectedCompletionDate" element
     */
    public void xsetExpectedCompletionDate(org.apache.xmlbeans.XmlDateTime expectedCompletionDate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlDateTime target = null;
            target = (org.apache.xmlbeans.XmlDateTime)get_store().find_element_user(EXPECTEDCOMPLETIONDATE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlDateTime)get_store().add_element_user(EXPECTEDCOMPLETIONDATE$2);
            }
            target.set(expectedCompletionDate);
        }
    }
}
