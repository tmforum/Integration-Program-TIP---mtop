/*
 * An XML document type.
 * Localname: modifyRequest
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one modifyRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class ModifyRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument
{
    
    public ModifyRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MODIFYREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "modifyRequest");
    
    
    /**
     * Gets the "modifyRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest getModifyRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest)get_store().find_element_user(MODIFYREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "modifyRequest" element
     */
    public void setModifyRequest(org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest modifyRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest)get_store().find_element_user(MODIFYREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest)get_store().add_element_user(MODIFYREQUEST$0);
            }
            target.set(modifyRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "modifyRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest addNewModifyRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest)get_store().add_element_user(MODIFYREQUEST$0);
            return target;
        }
    }
    /**
     * An XML modifyRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class ModifyRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ModifyRequestDocument.ModifyRequest
    {
        
        public ModifyRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName BASICINPUT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "basicInput");
        private static final javax.xml.namespace.QName SOAINPUT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "soaInput");
        private static final javax.xml.namespace.QName TARGETSTATE$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "targetState");
        
        
        /**
         * Gets the "basicInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType getBasicInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(BASICINPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "basicInput" element
         */
        public void setBasicInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType basicInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(BASICINPUT$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(BASICINPUT$0);
                }
                target.set(basicInput);
            }
        }
        
        /**
         * Appends and returns a new empty "basicInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType addNewBasicInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(BASICINPUT$0);
                return target;
            }
        }
        
        /**
         * Gets the "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType getSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "soaInput" element
         */
        public void setSoaInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType soaInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$2);
                }
                target.set(soaInput);
            }
        }
        
        /**
         * Appends and returns a new empty "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType addNewSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$2);
                return target;
            }
        }
        
        /**
         * Gets the "targetState" element
         */
        public java.lang.String getTargetState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TARGETSTATE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "targetState" element
         */
        public org.apache.xmlbeans.XmlString xgetTargetState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TARGETSTATE$4, 0);
                return target;
            }
        }
        
        /**
         * Sets the "targetState" element
         */
        public void setTargetState(java.lang.String targetState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TARGETSTATE$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TARGETSTATE$4);
                }
                target.setStringValue(targetState);
            }
        }
        
        /**
         * Sets (as xml) the "targetState" element
         */
        public void xsetTargetState(org.apache.xmlbeans.XmlString targetState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(TARGETSTATE$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(TARGETSTATE$4);
                }
                target.set(targetState);
            }
        }
    }
}
