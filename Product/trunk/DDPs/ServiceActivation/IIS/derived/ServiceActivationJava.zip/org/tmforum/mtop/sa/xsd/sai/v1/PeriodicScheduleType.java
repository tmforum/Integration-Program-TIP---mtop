/*
 * XML Type:  PeriodicScheduleType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1;


/**
 * An XML PeriodicScheduleType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public interface PeriodicScheduleType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(PeriodicScheduleType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("periodicscheduletype71fetype");
    
    /**
     * Gets the "start" element
     */
    java.util.Calendar getStart();
    
    /**
     * Gets (as xml) the "start" element
     */
    org.apache.xmlbeans.XmlDateTime xgetStart();
    
    /**
     * Sets the "start" element
     */
    void setStart(java.util.Calendar start);
    
    /**
     * Sets (as xml) the "start" element
     */
    void xsetStart(org.apache.xmlbeans.XmlDateTime start);
    
    /**
     * Gets the "availabilityDuration" element
     */
    org.apache.xmlbeans.GDuration getAvailabilityDuration();
    
    /**
     * Gets (as xml) the "availabilityDuration" element
     */
    org.apache.xmlbeans.XmlDuration xgetAvailabilityDuration();
    
    /**
     * Sets the "availabilityDuration" element
     */
    void setAvailabilityDuration(org.apache.xmlbeans.GDuration availabilityDuration);
    
    /**
     * Sets (as xml) the "availabilityDuration" element
     */
    void xsetAvailabilityDuration(org.apache.xmlbeans.XmlDuration availabilityDuration);
    
    /**
     * Gets the "recurrenceInterval" element
     */
    org.apache.xmlbeans.GDuration getRecurrenceInterval();
    
    /**
     * Gets (as xml) the "recurrenceInterval" element
     */
    org.apache.xmlbeans.XmlDuration xgetRecurrenceInterval();
    
    /**
     * Sets the "recurrenceInterval" element
     */
    void setRecurrenceInterval(org.apache.xmlbeans.GDuration recurrenceInterval);
    
    /**
     * Sets (as xml) the "recurrenceInterval" element
     */
    void xsetRecurrenceInterval(org.apache.xmlbeans.XmlDuration recurrenceInterval);
    
    /**
     * Gets the "end" element
     */
    java.util.Calendar getEnd();
    
    /**
     * Gets (as xml) the "end" element
     */
    org.apache.xmlbeans.XmlDateTime xgetEnd();
    
    /**
     * Tests for nil "end" element
     */
    boolean isNilEnd();
    
    /**
     * Sets the "end" element
     */
    void setEnd(java.util.Calendar end);
    
    /**
     * Sets (as xml) the "end" element
     */
    void xsetEnd(org.apache.xmlbeans.XmlDateTime end);
    
    /**
     * Nils the "end" element
     */
    void setNilEnd();
    
    /**
     * Gets a List of "extensionTime" elements
     */
    java.util.List<org.apache.xmlbeans.GDuration> getExtensionTimeList();
    
    /**
     * Gets array of all "extensionTime" elements
     * @deprecated
     */
    org.apache.xmlbeans.GDuration[] getExtensionTimeArray();
    
    /**
     * Gets ith "extensionTime" element
     */
    org.apache.xmlbeans.GDuration getExtensionTimeArray(int i);
    
    /**
     * Gets (as xml) a List of "extensionTime" elements
     */
    java.util.List<org.apache.xmlbeans.XmlDuration> xgetExtensionTimeList();
    
    /**
     * Gets (as xml) array of all "extensionTime" elements
     * @deprecated
     */
    org.apache.xmlbeans.XmlDuration[] xgetExtensionTimeArray();
    
    /**
     * Gets (as xml) ith "extensionTime" element
     */
    org.apache.xmlbeans.XmlDuration xgetExtensionTimeArray(int i);
    
    /**
     * Tests for nil ith "extensionTime" element
     */
    boolean isNilExtensionTimeArray(int i);
    
    /**
     * Returns number of "extensionTime" element
     */
    int sizeOfExtensionTimeArray();
    
    /**
     * Sets array of all "extensionTime" element
     */
    void setExtensionTimeArray(org.apache.xmlbeans.GDuration[] extensionTimeArray);
    
    /**
     * Sets ith "extensionTime" element
     */
    void setExtensionTimeArray(int i, org.apache.xmlbeans.GDuration extensionTime);
    
    /**
     * Sets (as xml) array of all "extensionTime" element
     */
    void xsetExtensionTimeArray(org.apache.xmlbeans.XmlDuration[] extensionTimeArray);
    
    /**
     * Sets (as xml) ith "extensionTime" element
     */
    void xsetExtensionTimeArray(int i, org.apache.xmlbeans.XmlDuration extensionTime);
    
    /**
     * Nils the ith "extensionTime" element
     */
    void setNilExtensionTimeArray(int i);
    
    /**
     * Inserts the value as the ith "extensionTime" element
     */
    void insertExtensionTime(int i, org.apache.xmlbeans.GDuration extensionTime);
    
    /**
     * Appends the value as the last "extensionTime" element
     */
    void addExtensionTime(org.apache.xmlbeans.GDuration extensionTime);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "extensionTime" element
     */
    org.apache.xmlbeans.XmlDuration insertNewExtensionTime(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "extensionTime" element
     */
    org.apache.xmlbeans.XmlDuration addNewExtensionTime();
    
    /**
     * Removes the ith "extensionTime" element
     */
    void removeExtensionTime(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType newInstance() {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.PeriodicScheduleType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
