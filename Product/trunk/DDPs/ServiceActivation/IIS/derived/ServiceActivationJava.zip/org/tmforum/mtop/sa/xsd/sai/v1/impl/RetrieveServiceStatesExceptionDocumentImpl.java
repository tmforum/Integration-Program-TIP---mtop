/*
 * An XML document type.
 * Localname: retrieveServiceStatesException
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one retrieveServiceStatesException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class RetrieveServiceStatesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument
{
    
    public RetrieveServiceStatesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName RETRIEVESERVICESTATESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "retrieveServiceStatesException");
    
    
    /**
     * Gets the "retrieveServiceStatesException" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException getRetrieveServiceStatesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException)get_store().find_element_user(RETRIEVESERVICESTATESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "retrieveServiceStatesException" element
     */
    public void setRetrieveServiceStatesException(org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException retrieveServiceStatesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException)get_store().find_element_user(RETRIEVESERVICESTATESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException)get_store().add_element_user(RETRIEVESERVICESTATESEXCEPTION$0);
            }
            target.set(retrieveServiceStatesException);
        }
    }
    
    /**
     * Appends and returns a new empty "retrieveServiceStatesException" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException addNewRetrieveServiceStatesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException)get_store().add_element_user(RETRIEVESERVICESTATESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML retrieveServiceStatesException(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class RetrieveServiceStatesExceptionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RetrieveServiceStatesExceptionDocument.RetrieveServiceStatesException
    {
        
        public RetrieveServiceStatesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName BASICFAILUREEVENT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "basicFailureEvent");
        
        
        /**
         * Gets a List of "basicFailureEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType> getBasicFailureEventList()
        {
            final class BasicFailureEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType>
            {
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType get(int i)
                    { return RetrieveServiceStatesExceptionImpl.this.getBasicFailureEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType set(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType o)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType old = RetrieveServiceStatesExceptionImpl.this.getBasicFailureEventArray(i);
                    RetrieveServiceStatesExceptionImpl.this.setBasicFailureEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType o)
                    { RetrieveServiceStatesExceptionImpl.this.insertNewBasicFailureEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType old = RetrieveServiceStatesExceptionImpl.this.getBasicFailureEventArray(i);
                    RetrieveServiceStatesExceptionImpl.this.removeBasicFailureEvent(i);
                    return old;
                }
                
                public int size()
                    { return RetrieveServiceStatesExceptionImpl.this.sizeOfBasicFailureEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new BasicFailureEventList();
            }
        }
        
        /**
         * Gets array of all "basicFailureEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] getBasicFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(BASICFAILUREEVENT$0, targetList);
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] result = new org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType getBasicFailureEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().find_element_user(BASICFAILUREEVENT$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "basicFailureEvent" element
         */
        public int sizeOfBasicFailureEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BASICFAILUREEVENT$0);
            }
        }
        
        /**
         * Sets array of all "basicFailureEvent" element
         */
        public void setBasicFailureEventArray(org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType[] basicFailureEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(basicFailureEventArray, BASICFAILUREEVENT$0);
            }
        }
        
        /**
         * Sets ith "basicFailureEvent" element
         */
        public void setBasicFailureEventArray(int i, org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType basicFailureEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().find_element_user(BASICFAILUREEVENT$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(basicFailureEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType insertNewBasicFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().insert_element_user(BASICFAILUREEVENT$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "basicFailureEvent" element
         */
        public org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType addNewBasicFailureEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType)get_store().add_element_user(BASICFAILUREEVENT$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "basicFailureEvent" element
         */
        public void removeBasicFailureEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BASICFAILUREEVENT$0, i);
            }
        }
    }
}
