/*
 * An XML document type.
 * Localname: deactivateResponse
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one deactivateResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class DeactivateResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument
{
    
    public DeactivateResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName DEACTIVATERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "deactivateResponse");
    
    
    /**
     * Gets the "deactivateResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse getDeactivateResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse)get_store().find_element_user(DEACTIVATERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "deactivateResponse" element
     */
    public void setDeactivateResponse(org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse deactivateResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse)get_store().find_element_user(DEACTIVATERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse)get_store().add_element_user(DEACTIVATERESPONSE$0);
            }
            target.set(deactivateResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "deactivateResponse" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse addNewDeactivateResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse)get_store().add_element_user(DEACTIVATERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML deactivateResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class DeactivateResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse
    {
        
        public DeactivateResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName INITIALRESPONSE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "initialResponse");
        private static final javax.xml.namespace.QName BEGINPROCESSINGEVENT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "beginProcessingEvent");
        private static final javax.xml.namespace.QName CFSSTATECHANGE$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "cfsStateChange");
        
        
        /**
         * Gets a List of "initialResponse" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType> getInitialResponseList()
        {
            final class InitialResponseList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType get(int i)
                    { return DeactivateResponseImpl.this.getInitialResponseArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType old = DeactivateResponseImpl.this.getInitialResponseArray(i);
                    DeactivateResponseImpl.this.setInitialResponseArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType o)
                    { DeactivateResponseImpl.this.insertNewInitialResponse(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType old = DeactivateResponseImpl.this.getInitialResponseArray(i);
                    DeactivateResponseImpl.this.removeInitialResponse(i);
                    return old;
                }
                
                public int size()
                    { return DeactivateResponseImpl.this.sizeOfInitialResponseArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new InitialResponseList();
            }
        }
        
        /**
         * Gets array of all "initialResponse" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] getInitialResponseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(INITIALRESPONSE$0, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType getInitialResponseArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().find_element_user(INITIALRESPONSE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "initialResponse" element
         */
        public int sizeOfInitialResponseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(INITIALRESPONSE$0);
            }
        }
        
        /**
         * Sets array of all "initialResponse" element
         */
        public void setInitialResponseArray(org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] initialResponseArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(initialResponseArray, INITIALRESPONSE$0);
            }
        }
        
        /**
         * Sets ith "initialResponse" element
         */
        public void setInitialResponseArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType initialResponse)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().find_element_user(INITIALRESPONSE$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(initialResponse);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType insertNewInitialResponse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().insert_element_user(INITIALRESPONSE$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "initialResponse" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType addNewInitialResponse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType)get_store().add_element_user(INITIALRESPONSE$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "initialResponse" element
         */
        public void removeInitialResponse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(INITIALRESPONSE$0, i);
            }
        }
        
        /**
         * Gets a List of "beginProcessingEvent" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType> getBeginProcessingEventList()
        {
            final class BeginProcessingEventList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType get(int i)
                    { return DeactivateResponseImpl.this.getBeginProcessingEventArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType old = DeactivateResponseImpl.this.getBeginProcessingEventArray(i);
                    DeactivateResponseImpl.this.setBeginProcessingEventArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType o)
                    { DeactivateResponseImpl.this.insertNewBeginProcessingEvent(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType old = DeactivateResponseImpl.this.getBeginProcessingEventArray(i);
                    DeactivateResponseImpl.this.removeBeginProcessingEvent(i);
                    return old;
                }
                
                public int size()
                    { return DeactivateResponseImpl.this.sizeOfBeginProcessingEventArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new BeginProcessingEventList();
            }
        }
        
        /**
         * Gets array of all "beginProcessingEvent" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] getBeginProcessingEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(BEGINPROCESSINGEVENT$2, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType getBeginProcessingEventArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().find_element_user(BEGINPROCESSINGEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "beginProcessingEvent" element
         */
        public int sizeOfBeginProcessingEventArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BEGINPROCESSINGEVENT$2);
            }
        }
        
        /**
         * Sets array of all "beginProcessingEvent" element
         */
        public void setBeginProcessingEventArray(org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] beginProcessingEventArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(beginProcessingEventArray, BEGINPROCESSINGEVENT$2);
            }
        }
        
        /**
         * Sets ith "beginProcessingEvent" element
         */
        public void setBeginProcessingEventArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType beginProcessingEvent)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().find_element_user(BEGINPROCESSINGEVENT$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(beginProcessingEvent);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType insertNewBeginProcessingEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().insert_element_user(BEGINPROCESSINGEVENT$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "beginProcessingEvent" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType addNewBeginProcessingEvent()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType)get_store().add_element_user(BEGINPROCESSINGEVENT$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "beginProcessingEvent" element
         */
        public void removeBeginProcessingEvent(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BEGINPROCESSINGEVENT$2, i);
            }
        }
        
        /**
         * Gets a List of "cfsStateChange" elements
         */
        public java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType> getCfsStateChangeList()
        {
            final class CfsStateChangeList extends java.util.AbstractList<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType>
            {
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType get(int i)
                    { return DeactivateResponseImpl.this.getCfsStateChangeArray(i); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType set(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType o)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType old = DeactivateResponseImpl.this.getCfsStateChangeArray(i);
                    DeactivateResponseImpl.this.setCfsStateChangeArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType o)
                    { DeactivateResponseImpl.this.insertNewCfsStateChange(i).set(o); }
                
                public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType remove(int i)
                {
                    org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType old = DeactivateResponseImpl.this.getCfsStateChangeArray(i);
                    DeactivateResponseImpl.this.removeCfsStateChange(i);
                    return old;
                }
                
                public int size()
                    { return DeactivateResponseImpl.this.sizeOfCfsStateChangeArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new CfsStateChangeList();
            }
        }
        
        /**
         * Gets array of all "cfsStateChange" elements
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[] getCfsStateChangeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(CFSSTATECHANGE$4, targetList);
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[] result = new org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "cfsStateChange" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType getCfsStateChangeArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType)get_store().find_element_user(CFSSTATECHANGE$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "cfsStateChange" element
         */
        public int sizeOfCfsStateChangeArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(CFSSTATECHANGE$4);
            }
        }
        
        /**
         * Sets array of all "cfsStateChange" element
         */
        public void setCfsStateChangeArray(org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[] cfsStateChangeArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(cfsStateChangeArray, CFSSTATECHANGE$4);
            }
        }
        
        /**
         * Sets ith "cfsStateChange" element
         */
        public void setCfsStateChangeArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType cfsStateChange)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType)get_store().find_element_user(CFSSTATECHANGE$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(cfsStateChange);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsStateChange" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType insertNewCfsStateChange(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType)get_store().insert_element_user(CFSSTATECHANGE$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsStateChange" element
         */
        public org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType addNewCfsStateChange()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType target = null;
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType)get_store().add_element_user(CFSSTATECHANGE$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "cfsStateChange" element
         */
        public void removeCfsStateChange(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(CFSSTATECHANGE$4, i);
            }
        }
    }
}
