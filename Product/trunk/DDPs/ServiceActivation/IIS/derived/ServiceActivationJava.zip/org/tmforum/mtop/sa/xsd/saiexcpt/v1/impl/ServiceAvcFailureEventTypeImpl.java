/*
 * XML Type:  ServiceAvcFailureEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1
 * Java type: org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.saiexcpt.v1.impl;
/**
 * An XML ServiceAvcFailureEventType(@http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1).
 *
 * This is a complex type.
 */
public class ServiceAvcFailureEventTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.saiexcpt.v1.ServiceAvcFailureEventType
{
    
    public ServiceAvcFailureEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEREQUESTID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "serviceRequestID");
    private static final javax.xml.namespace.QName PRODUCTNAME$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "productName");
    private static final javax.xml.namespace.QName CFSNAME$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "cfsName");
    private static final javax.xml.namespace.QName PRODUCTSPECCHARACTERISTICID$6 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "productSpecCharacteristicID");
    private static final javax.xml.namespace.QName SERVICESPECCHARACTERISTICID$8 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1", "serviceSpecCharacteristicID");
    
    
    /**
     * Gets the "serviceRequestID" element
     */
    public java.lang.String getServiceRequestID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEREQUESTID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "serviceRequestID" element
     */
    public org.apache.xmlbeans.XmlString xgetServiceRequestID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICEREQUESTID$0, 0);
            return target;
        }
    }
    
    /**
     * Sets the "serviceRequestID" element
     */
    public void setServiceRequestID(java.lang.String serviceRequestID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(SERVICEREQUESTID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(SERVICEREQUESTID$0);
            }
            target.setStringValue(serviceRequestID);
        }
    }
    
    /**
     * Sets (as xml) the "serviceRequestID" element
     */
    public void xsetServiceRequestID(org.apache.xmlbeans.XmlString serviceRequestID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(SERVICEREQUESTID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(SERVICEREQUESTID$0);
            }
            target.set(serviceRequestID);
        }
    }
    
    /**
     * Gets the "productName" element
     */
    public java.lang.String getProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                return null;
            }
            return target.getStringValue();
        }
    }
    
    /**
     * Gets (as xml) the "productName" element
     */
    public org.apache.xmlbeans.XmlString xgetProductName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PRODUCTNAME$2, 0);
            return target;
        }
    }
    
    /**
     * Sets the "productName" element
     */
    public void setProductName(java.lang.String productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(PRODUCTNAME$2);
            }
            target.setStringValue(productName);
        }
    }
    
    /**
     * Sets (as xml) the "productName" element
     */
    public void xsetProductName(org.apache.xmlbeans.XmlString productName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlString target = null;
            target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(PRODUCTNAME$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(PRODUCTNAME$2);
            }
            target.set(productName);
        }
    }
    
    /**
     * Gets a List of "cfsName" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getCfsNameList()
    {
        final class CfsNameList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return ServiceAvcFailureEventTypeImpl.this.getCfsNameArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ServiceAvcFailureEventTypeImpl.this.getCfsNameArray(i);
                ServiceAvcFailureEventTypeImpl.this.setCfsNameArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { ServiceAvcFailureEventTypeImpl.this.insertNewCfsName(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ServiceAvcFailureEventTypeImpl.this.getCfsNameArray(i);
                ServiceAvcFailureEventTypeImpl.this.removeCfsName(i);
                return old;
            }
            
            public int size()
                { return ServiceAvcFailureEventTypeImpl.this.sizeOfCfsNameArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new CfsNameList();
        }
    }
    
    /**
     * Gets array of all "cfsName" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getCfsNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(CFSNAME$4, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "cfsName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getCfsNameArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CFSNAME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "cfsName" element
     */
    public int sizeOfCfsNameArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(CFSNAME$4);
        }
    }
    
    /**
     * Sets array of all "cfsName" element
     */
    public void setCfsNameArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] cfsNameArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(cfsNameArray, CFSNAME$4);
        }
    }
    
    /**
     * Sets ith "cfsName" element
     */
    public void setCfsNameArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType cfsName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(CFSNAME$4, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(cfsName);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "cfsName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewCfsName(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(CFSNAME$4, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "cfsName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewCfsName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(CFSNAME$4);
            return target;
        }
    }
    
    /**
     * Removes the ith "cfsName" element
     */
    public void removeCfsName(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(CFSNAME$4, i);
        }
    }
    
    /**
     * Gets a List of "productSpecCharacteristicID" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getProductSpecCharacteristicIDList()
    {
        final class ProductSpecCharacteristicIDList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return ServiceAvcFailureEventTypeImpl.this.getProductSpecCharacteristicIDArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ServiceAvcFailureEventTypeImpl.this.getProductSpecCharacteristicIDArray(i);
                ServiceAvcFailureEventTypeImpl.this.setProductSpecCharacteristicIDArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { ServiceAvcFailureEventTypeImpl.this.insertNewProductSpecCharacteristicID(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ServiceAvcFailureEventTypeImpl.this.getProductSpecCharacteristicIDArray(i);
                ServiceAvcFailureEventTypeImpl.this.removeProductSpecCharacteristicID(i);
                return old;
            }
            
            public int size()
                { return ServiceAvcFailureEventTypeImpl.this.sizeOfProductSpecCharacteristicIDArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ProductSpecCharacteristicIDList();
        }
    }
    
    /**
     * Gets array of all "productSpecCharacteristicID" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getProductSpecCharacteristicIDArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(PRODUCTSPECCHARACTERISTICID$6, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "productSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductSpecCharacteristicIDArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECCHARACTERISTICID$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "productSpecCharacteristicID" element
     */
    public int sizeOfProductSpecCharacteristicIDArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PRODUCTSPECCHARACTERISTICID$6);
        }
    }
    
    /**
     * Sets array of all "productSpecCharacteristicID" element
     */
    public void setProductSpecCharacteristicIDArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] productSpecCharacteristicIDArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(productSpecCharacteristicIDArray, PRODUCTSPECCHARACTERISTICID$6);
        }
    }
    
    /**
     * Sets ith "productSpecCharacteristicID" element
     */
    public void setProductSpecCharacteristicIDArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productSpecCharacteristicID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(PRODUCTSPECCHARACTERISTICID$6, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(productSpecCharacteristicID);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "productSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewProductSpecCharacteristicID(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(PRODUCTSPECCHARACTERISTICID$6, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "productSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductSpecCharacteristicID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(PRODUCTSPECCHARACTERISTICID$6);
            return target;
        }
    }
    
    /**
     * Removes the ith "productSpecCharacteristicID" element
     */
    public void removeProductSpecCharacteristicID(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PRODUCTSPECCHARACTERISTICID$6, i);
        }
    }
    
    /**
     * Gets a List of "serviceSpecCharacteristicID" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getServiceSpecCharacteristicIDList()
    {
        final class ServiceSpecCharacteristicIDList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType get(int i)
                { return ServiceAvcFailureEventTypeImpl.this.getServiceSpecCharacteristicIDArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ServiceAvcFailureEventTypeImpl.this.getServiceSpecCharacteristicIDArray(i);
                ServiceAvcFailureEventTypeImpl.this.setServiceSpecCharacteristicIDArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType o)
                { ServiceAvcFailureEventTypeImpl.this.insertNewServiceSpecCharacteristicID(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType old = ServiceAvcFailureEventTypeImpl.this.getServiceSpecCharacteristicIDArray(i);
                ServiceAvcFailureEventTypeImpl.this.removeServiceSpecCharacteristicID(i);
                return old;
            }
            
            public int size()
                { return ServiceAvcFailureEventTypeImpl.this.sizeOfServiceSpecCharacteristicIDArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ServiceSpecCharacteristicIDList();
        }
    }
    
    /**
     * Gets array of all "serviceSpecCharacteristicID" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getServiceSpecCharacteristicIDArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(SERVICESPECCHARACTERISTICID$8, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "serviceSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getServiceSpecCharacteristicIDArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SERVICESPECCHARACTERISTICID$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "serviceSpecCharacteristicID" element
     */
    public int sizeOfServiceSpecCharacteristicIDArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SERVICESPECCHARACTERISTICID$8);
        }
    }
    
    /**
     * Sets array of all "serviceSpecCharacteristicID" element
     */
    public void setServiceSpecCharacteristicIDArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] serviceSpecCharacteristicIDArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(serviceSpecCharacteristicIDArray, SERVICESPECCHARACTERISTICID$8);
        }
    }
    
    /**
     * Sets ith "serviceSpecCharacteristicID" element
     */
    public void setServiceSpecCharacteristicIDArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType serviceSpecCharacteristicID)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().find_element_user(SERVICESPECCHARACTERISTICID$8, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(serviceSpecCharacteristicID);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "serviceSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewServiceSpecCharacteristicID(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().insert_element_user(SERVICESPECCHARACTERISTICID$8, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "serviceSpecCharacteristicID" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewServiceSpecCharacteristicID()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType)get_store().add_element_user(SERVICESPECCHARACTERISTICID$8);
            return target;
        }
    }
    
    /**
     * Removes the ith "serviceSpecCharacteristicID" element
     */
    public void removeServiceSpecCharacteristicID(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SERVICESPECCHARACTERISTICID$8, i);
        }
    }
}
