/*
 * XML Type:  ProductInfoType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1;


/**
 * An XML ProductInfoType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public interface ProductInfoType extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(ProductInfoType.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("productinfotype5f77type");
    
    /**
     * Gets the "productName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductName();
    
    /**
     * Sets the "productName" element
     */
    void setProductName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productName);
    
    /**
     * Appends and returns a new empty "productName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductName();
    
    /**
     * Gets the "productSpecificationName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductSpecificationName();
    
    /**
     * Tests for nil "productSpecificationName" element
     */
    boolean isNilProductSpecificationName();
    
    /**
     * Sets the "productSpecificationName" element
     */
    void setProductSpecificationName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productSpecificationName);
    
    /**
     * Appends and returns a new empty "productSpecificationName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductSpecificationName();
    
    /**
     * Nils the "productSpecificationName" element
     */
    void setNilProductSpecificationName();
    
    /**
     * Gets the "productBundleName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductBundleName();
    
    /**
     * Tests for nil "productBundleName" element
     */
    boolean isNilProductBundleName();
    
    /**
     * Sets the "productBundleName" element
     */
    void setProductBundleName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productBundleName);
    
    /**
     * Appends and returns a new empty "productBundleName" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductBundleName();
    
    /**
     * Nils the "productBundleName" element
     */
    void setNilProductBundleName();
    
    /**
     * Gets a List of "productSpecCharacteristicID" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getProductSpecCharacteristicIDList();
    
    /**
     * Gets array of all "productSpecCharacteristicID" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getProductSpecCharacteristicIDArray();
    
    /**
     * Gets ith "productSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductSpecCharacteristicIDArray(int i);
    
    /**
     * Tests for nil ith "productSpecCharacteristicID" element
     */
    boolean isNilProductSpecCharacteristicIDArray(int i);
    
    /**
     * Returns number of "productSpecCharacteristicID" element
     */
    int sizeOfProductSpecCharacteristicIDArray();
    
    /**
     * Sets array of all "productSpecCharacteristicID" element
     */
    void setProductSpecCharacteristicIDArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] productSpecCharacteristicIDArray);
    
    /**
     * Sets ith "productSpecCharacteristicID" element
     */
    void setProductSpecCharacteristicIDArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productSpecCharacteristicID);
    
    /**
     * Nils the ith "productSpecCharacteristicID" element
     */
    void setNilProductSpecCharacteristicIDArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "productSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewProductSpecCharacteristicID(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "productSpecCharacteristicID" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductSpecCharacteristicID();
    
    /**
     * Removes the ith "productSpecCharacteristicID" element
     */
    void removeProductSpecCharacteristicID(int i);
    
    /**
     * Gets a List of "productCharacteristicValue" elements
     */
    java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType> getProductCharacteristicValueList();
    
    /**
     * Gets array of all "productCharacteristicValue" elements
     * @deprecated
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] getProductCharacteristicValueArray();
    
    /**
     * Gets ith "productCharacteristicValue" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType getProductCharacteristicValueArray(int i);
    
    /**
     * Tests for nil ith "productCharacteristicValue" element
     */
    boolean isNilProductCharacteristicValueArray(int i);
    
    /**
     * Returns number of "productCharacteristicValue" element
     */
    int sizeOfProductCharacteristicValueArray();
    
    /**
     * Sets array of all "productCharacteristicValue" element
     */
    void setProductCharacteristicValueArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType[] productCharacteristicValueArray);
    
    /**
     * Sets ith "productCharacteristicValue" element
     */
    void setProductCharacteristicValueArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType productCharacteristicValue);
    
    /**
     * Nils the ith "productCharacteristicValue" element
     */
    void setNilProductCharacteristicValueArray(int i);
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "productCharacteristicValue" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType insertNewProductCharacteristicValue(int i);
    
    /**
     * Appends and returns a new empty value (as xml) as the last "productCharacteristicValue" element
     */
    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributeType addNewProductCharacteristicValue();
    
    /**
     * Removes the ith "productCharacteristicValue" element
     */
    void removeProductCharacteristicValue(int i);
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType newInstance() {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.ProductInfoType) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
