/*
 * An XML document type.
 * Localname: deactivateResponse
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1;


/**
 * A document containing one deactivateResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public interface DeactivateResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DeactivateResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("deactivateresponse0717doctype");
    
    /**
     * Gets the "deactivateResponse" element
     */
    org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse getDeactivateResponse();
    
    /**
     * Sets the "deactivateResponse" element
     */
    void setDeactivateResponse(org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse deactivateResponse);
    
    /**
     * Appends and returns a new empty "deactivateResponse" element
     */
    org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse addNewDeactivateResponse();
    
    /**
     * An XML deactivateResponse(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public interface DeactivateResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(DeactivateResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sA4345E67E59F73544656C99792D2611A").resolveHandle("deactivateresponse3586elemtype");
        
        /**
         * Gets a List of "initialResponse" elements
         */
        java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType> getInitialResponseList();
        
        /**
         * Gets array of all "initialResponse" elements
         * @deprecated
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] getInitialResponseArray();
        
        /**
         * Gets ith "initialResponse" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType getInitialResponseArray(int i);
        
        /**
         * Returns number of "initialResponse" element
         */
        int sizeOfInitialResponseArray();
        
        /**
         * Sets array of all "initialResponse" element
         */
        void setInitialResponseArray(org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType[] initialResponseArray);
        
        /**
         * Sets ith "initialResponse" element
         */
        void setInitialResponseArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType initialResponse);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "initialResponse" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType insertNewInitialResponse(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "initialResponse" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.InitialResponseType addNewInitialResponse();
        
        /**
         * Removes the ith "initialResponse" element
         */
        void removeInitialResponse(int i);
        
        /**
         * Gets a List of "beginProcessingEvent" elements
         */
        java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType> getBeginProcessingEventList();
        
        /**
         * Gets array of all "beginProcessingEvent" elements
         * @deprecated
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] getBeginProcessingEventArray();
        
        /**
         * Gets ith "beginProcessingEvent" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType getBeginProcessingEventArray(int i);
        
        /**
         * Returns number of "beginProcessingEvent" element
         */
        int sizeOfBeginProcessingEventArray();
        
        /**
         * Sets array of all "beginProcessingEvent" element
         */
        void setBeginProcessingEventArray(org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType[] beginProcessingEventArray);
        
        /**
         * Sets ith "beginProcessingEvent" element
         */
        void setBeginProcessingEventArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType beginProcessingEvent);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "beginProcessingEvent" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType insertNewBeginProcessingEvent(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "beginProcessingEvent" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType addNewBeginProcessingEvent();
        
        /**
         * Removes the ith "beginProcessingEvent" element
         */
        void removeBeginProcessingEvent(int i);
        
        /**
         * Gets a List of "cfsStateChange" elements
         */
        java.util.List<org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType> getCfsStateChangeList();
        
        /**
         * Gets array of all "cfsStateChange" elements
         * @deprecated
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[] getCfsStateChangeArray();
        
        /**
         * Gets ith "cfsStateChange" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType getCfsStateChangeArray(int i);
        
        /**
         * Returns number of "cfsStateChange" element
         */
        int sizeOfCfsStateChangeArray();
        
        /**
         * Sets array of all "cfsStateChange" element
         */
        void setCfsStateChangeArray(org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType[] cfsStateChangeArray);
        
        /**
         * Sets ith "cfsStateChange" element
         */
        void setCfsStateChangeArray(int i, org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType cfsStateChange);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "cfsStateChange" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType insertNewCfsStateChange(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "cfsStateChange" element
         */
        org.tmforum.mtop.sa.xsd.sairsp.v1.CfsStateChangeEventType addNewCfsStateChange();
        
        /**
         * Removes the ith "cfsStateChange" element
         */
        void removeCfsStateChange(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse newInstance() {
              return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument.DeactivateResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument newInstance() {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.sa.xsd.sai.v1.DeactivateResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
