/*
 * An XML document type.
 * Localname: activateRequest
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * A document containing one activateRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1) element.
 *
 * This is a complex type.
 */
public class ActivateRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument
{
    
    public ActivateRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName ACTIVATEREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "activateRequest");
    
    
    /**
     * Gets the "activateRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest getActivateRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest)get_store().find_element_user(ACTIVATEREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "activateRequest" element
     */
    public void setActivateRequest(org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest activateRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest)get_store().find_element_user(ACTIVATEREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest)get_store().add_element_user(ACTIVATEREQUEST$0);
            }
            target.set(activateRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "activateRequest" element
     */
    public org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest addNewActivateRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest target = null;
            target = (org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest)get_store().add_element_user(ACTIVATEREQUEST$0);
            return target;
        }
    }
    /**
     * An XML activateRequest(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
     *
     * This is a complex type.
     */
    public static class ActivateRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.ActivateRequestDocument.ActivateRequest
    {
        
        public ActivateRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName BASICINPUT$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "basicInput");
        private static final javax.xml.namespace.QName SOAINPUT$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "soaInput");
        private static final javax.xml.namespace.QName CFSCURRENTSTATE$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "cfsCurrentState");
        
        
        /**
         * Gets the "basicInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType getBasicInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(BASICINPUT$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "basicInput" element
         */
        public void setBasicInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType basicInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().find_element_user(BASICINPUT$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(BASICINPUT$0);
                }
                target.set(basicInput);
            }
        }
        
        /**
         * Appends and returns a new empty "basicInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType addNewBasicInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoBasicType)get_store().add_element_user(BASICINPUT$0);
                return target;
            }
        }
        
        /**
         * Gets the "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType getSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "soaInput" element
         */
        public void setSoaInput(org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType soaInput)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().find_element_user(SOAINPUT$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$2);
                }
                target.set(soaInput);
            }
        }
        
        /**
         * Appends and returns a new empty "soaInput" element
         */
        public org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType addNewSoaInput()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType target = null;
                target = (org.tmforum.mtop.sa.xsd.sai.v1.RequestInfoSOAwareType)get_store().add_element_user(SOAINPUT$2);
                return target;
            }
        }
        
        /**
         * Gets the "cfsCurrentState" element
         */
        public java.lang.String getCfsCurrentState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CFSCURRENTSTATE$4, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "cfsCurrentState" element
         */
        public org.apache.xmlbeans.XmlString xgetCfsCurrentState()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CFSCURRENTSTATE$4, 0);
                return target;
            }
        }
        
        /**
         * Sets the "cfsCurrentState" element
         */
        public void setCfsCurrentState(java.lang.String cfsCurrentState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(CFSCURRENTSTATE$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(CFSCURRENTSTATE$4);
                }
                target.setStringValue(cfsCurrentState);
            }
        }
        
        /**
         * Sets (as xml) the "cfsCurrentState" element
         */
        public void xsetCfsCurrentState(org.apache.xmlbeans.XmlString cfsCurrentState)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(CFSCURRENTSTATE$4, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(CFSCURRENTSTATE$4);
                }
                target.set(cfsCurrentState);
            }
        }
    }
}
