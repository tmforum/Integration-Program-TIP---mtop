/*
 * XML Type:  BeginProcessingEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sairsp/v1
 * Java type: org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sairsp.v1.impl;
/**
 * An XML BeginProcessingEventType(@http://www.tmforum.org/mtop/sa/xsd/sairsp/v1).
 *
 * This is a complex type.
 */
public class BeginProcessingEventTypeImpl extends org.tmforum.mtop.sa.xsd.sairsp.v1.impl.RootResponseTypeImpl implements org.tmforum.mtop.sa.xsd.sairsp.v1.BeginProcessingEventType
{
    
    public BeginProcessingEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SOAWAREPARAMSRES$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sairsp/v1", "soAwareParamsRes");
    
    
    /**
     * Gets the "soAwareParamsRes" element
     */
    public org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType getSoAwareParamsRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType target = null;
            target = (org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType)get_store().find_element_user(SOAWAREPARAMSRES$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "soAwareParamsRes" element
     */
    public boolean isSetSoAwareParamsRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SOAWAREPARAMSRES$0) != 0;
        }
    }
    
    /**
     * Sets the "soAwareParamsRes" element
     */
    public void setSoAwareParamsRes(org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType soAwareParamsRes)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType target = null;
            target = (org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType)get_store().find_element_user(SOAWAREPARAMSRES$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType)get_store().add_element_user(SOAWAREPARAMSRES$0);
            }
            target.set(soAwareParamsRes);
        }
    }
    
    /**
     * Appends and returns a new empty "soAwareParamsRes" element
     */
    public org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType addNewSoAwareParamsRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType target = null;
            target = (org.tmforum.mtop.sa.xsd.sairsp.v1.SOAwareParamsResType)get_store().add_element_user(SOAWAREPARAMSRES$0);
            return target;
        }
    }
    
    /**
     * Unsets the "soAwareParamsRes" element
     */
    public void unsetSoAwareParamsRes()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SOAWAREPARAMSRES$0, 0);
        }
    }
}
