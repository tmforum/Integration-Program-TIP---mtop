/*
 * XML Type:  PartyRoleType
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/csi/v1
 * Java type: org.tmforum.mtop.sb.xsd.csi.v1.PartyRoleType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.csi.v1.impl;
/**
 * An XML PartyRoleType(@http://www.tmforum.org/mtop/sb/xsd/csi/v1).
 *
 * This is a complex type.
 */
public class PartyRoleTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sb.xsd.csi.v1.PartyRoleType
{
    
    public PartyRoleTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName PARTYROLEID$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "partyRoleId");
    private static final javax.xml.namespace.QName STATUS$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "status");
    private static final javax.xml.namespace.QName VALIDFOR$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/csi/v1", "validFor");
    
    
    /**
     * Gets the "partyRoleId" element
     */
    public org.apache.xmlbeans.XmlObject getPartyRoleId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(PARTYROLEID$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "partyRoleId" element
     */
    public boolean isSetPartyRoleId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(PARTYROLEID$0) != 0;
        }
    }
    
    /**
     * Sets the "partyRoleId" element
     */
    public void setPartyRoleId(org.apache.xmlbeans.XmlObject partyRoleId)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(PARTYROLEID$0, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(PARTYROLEID$0);
            }
            target.set(partyRoleId);
        }
    }
    
    /**
     * Appends and returns a new empty "partyRoleId" element
     */
    public org.apache.xmlbeans.XmlObject addNewPartyRoleId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(PARTYROLEID$0);
            return target;
        }
    }
    
    /**
     * Unsets the "partyRoleId" element
     */
    public void unsetPartyRoleId()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(PARTYROLEID$0, 0);
        }
    }
    
    /**
     * Gets the "status" element
     */
    public org.apache.xmlbeans.XmlObject getStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(STATUS$2, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "status" element
     */
    public boolean isSetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(STATUS$2) != 0;
        }
    }
    
    /**
     * Sets the "status" element
     */
    public void setStatus(org.apache.xmlbeans.XmlObject status)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().find_element_user(STATUS$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(STATUS$2);
            }
            target.set(status);
        }
    }
    
    /**
     * Appends and returns a new empty "status" element
     */
    public org.apache.xmlbeans.XmlObject addNewStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.XmlObject target = null;
            target = (org.apache.xmlbeans.XmlObject)get_store().add_element_user(STATUS$2);
            return target;
        }
    }
    
    /**
     * Unsets the "status" element
     */
    public void unsetStatus()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(STATUS$2, 0);
        }
    }
    
    /**
     * Gets the "validFor" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType getValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(VALIDFOR$4, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "validFor" element
     */
    public boolean isSetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VALIDFOR$4) != 0;
        }
    }
    
    /**
     * Sets the "validFor" element
     */
    public void setValidFor(org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType validFor)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().find_element_user(VALIDFOR$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(VALIDFOR$4);
            }
            target.set(validFor);
        }
    }
    
    /**
     * Appends and returns a new empty "validFor" element
     */
    public org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType addNewValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType target = null;
            target = (org.tmforum.mtop.sb.xsd.csi.v1.TimePeriodType)get_store().add_element_user(VALIDFOR$4);
            return target;
        }
    }
    
    /**
     * Unsets the "validFor" element
     */
    public void unsetValidFor()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VALIDFOR$4, 0);
        }
    }
}
