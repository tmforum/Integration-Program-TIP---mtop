/*
 * XML Type:  RootRequestType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/sai/v1
 * Java type: org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.sai.v1.impl;
/**
 * An XML RootRequestType(@http://www.tmforum.org/mtop/sa/xsd/sai/v1).
 *
 * This is a complex type.
 */
public class RootRequestTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.sa.xsd.sai.v1.RootRequestType
{
    
    public RootRequestTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName VENDOREXTENSIONS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sa/xsd/sai/v1", "vendorExtensions");
    
    
    /**
     * Gets the "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType getVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Tests for nil "vendorExtensions" element
     */
    public boolean isNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
            if (target == null) return false;
            return target.isNil();
        }
    }
    
    /**
     * True if has "vendorExtensions" element
     */
    public boolean isSetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(VENDOREXTENSIONS$0) != 0;
        }
    }
    
    /**
     * Sets the "vendorExtensions" element
     */
    public void setVendorExtensions(org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType vendorExtensions)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
            }
            target.set(vendorExtensions);
        }
    }
    
    /**
     * Appends and returns a new empty "vendorExtensions" element
     */
    public org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType addNewVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
            return target;
        }
    }
    
    /**
     * Nils the "vendorExtensions" element
     */
    public void setNilVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType target = null;
            target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().find_element_user(VENDOREXTENSIONS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.AnyListType)get_store().add_element_user(VENDOREXTENSIONS$0);
            }
            target.setNil();
        }
    }
    
    /**
     * Unsets the "vendorExtensions" element
     */
    public void unsetVendorExtensions()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(VENDOREXTENSIONS$0, 0);
        }
    }
}
