/*
 * XML Type:  BasicFailureEventType
 * Namespace: http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1
 * Java type: org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sa.xsd.saiexcpt.v1.impl;
/**
 * An XML BasicFailureEventType(@http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1).
 *
 * This is a complex type.
 */
public class BasicFailureEventTypeImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.sa.xsd.saiexcpt.v1.BasicFailureEventType
{
    
    public BasicFailureEventTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
