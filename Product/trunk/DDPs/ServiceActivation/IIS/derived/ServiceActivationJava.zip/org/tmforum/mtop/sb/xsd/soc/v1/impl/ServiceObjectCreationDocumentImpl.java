/*
 * An XML document type.
 * Localname: serviceObjectCreation
 * Namespace: http://www.tmforum.org/mtop/sb/xsd/soc/v1
 * Java type: org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.sb.xsd.soc.v1.impl;
/**
 * A document containing one serviceObjectCreation(@http://www.tmforum.org/mtop/sb/xsd/soc/v1) element.
 *
 * This is a complex type.
 */
public class ServiceObjectCreationDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInformationDocumentImpl implements org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationDocument
{
    
    public ServiceObjectCreationDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SERVICEOBJECTCREATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/sb/xsd/soc/v1", "serviceObjectCreation");
    
    
    /**
     * Gets the "serviceObjectCreation" element
     */
    public org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType getServiceObjectCreation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType target = null;
            target = (org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType)get_store().find_element_user(SERVICEOBJECTCREATION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "serviceObjectCreation" element
     */
    public void setServiceObjectCreation(org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType serviceObjectCreation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType target = null;
            target = (org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType)get_store().find_element_user(SERVICEOBJECTCREATION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType)get_store().add_element_user(SERVICEOBJECTCREATION$0);
            }
            target.set(serviceObjectCreation);
        }
    }
    
    /**
     * Appends and returns a new empty "serviceObjectCreation" element
     */
    public org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType addNewServiceObjectCreation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType target = null;
            target = (org.tmforum.mtop.sb.xsd.soc.v1.ServiceObjectCreationType)get_store().add_element_user(SERVICEOBJECTCREATION$0);
            return target;
        }
    }
}
