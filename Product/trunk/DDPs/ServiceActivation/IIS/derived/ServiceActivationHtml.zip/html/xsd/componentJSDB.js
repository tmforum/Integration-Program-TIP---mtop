﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_ciFileName = "componentIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function CN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function C (attributeList, attributeGroupList,
						simpleTypeList, complexTypeList,
						modelGroupList, elementList, 
						notationList) 
{
	this.attributes = attributeList;
	this.attributegroups = attributeGroupList;
	this.simpletypes = simpleTypeList;
	this.complextypes = complexTypeList;
	this.modelgroups = modelGroupList;
	this.elements = elementList;
	this.notations = notationList;
}

function component_showAllComponents() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_ciFileName;
}

function component_filterComponents () {
	parent._href = "xsd/" + xsd_ciFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function component_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href=xsd_ciFileName;	
}

function component_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in componentDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}

	parent._xsdNsFilter = nsList;
}

function component_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	component_outputList (null, components);	
}


function component_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		component_outputList (namespace, list);	
	}
}


function component_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		component_showComponentsNS (nsList, componentList)
	} else {
		component_showComponentsNoNS (nsList, componentList)
	}
}

function component_showAttributes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		attributes [i] = componentDB [nsList[i]].attributes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributes);
}

function component_showAttributeGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributegroups = new Array();
	var nss = new Array();		

	for (var i=0; i<nsList.length; i++) {
		attributegroups [i] = componentDB [nsList[i]].attributegroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributegroups);
}

function component_showSimpleTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var simpletypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		simpletypes [i] = componentDB [nsList[i]].simpletypes;	
		nss [i] = nsList[i];
	}		

	component_showComponents (nss, simpletypes);
}

function component_showComplexTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var complextypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		complextypes [i] = componentDB [nsList[i]].complextypes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, complextypes);
}

function component_showElements() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var elements = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		elements [i] = componentDB [nsList[i]].elements;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, elements);
}

function component_showModelGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var modelgroups = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		modelgroups [i] = componentDB [nsList[i]].modelgroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, modelgroups);
}

function component_showNotations() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var notations = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		notations [i] = componentDB [nsList[i]].notations;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, notations);

}


function component_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function component_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+component_getNodeText(node)+
			  '" target="'+target+'">'+component_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function component_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+component_getNodeText(node)+
			'" target="'+target+'">'+component_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		component_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function component_outputTree (node) {
	if (node.hasChild == false) {
		component_outputLeaf (node);
	} else {
		component_outputNonLeaf (node);
	}
}

function component_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = componentNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+target+'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		component_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}


var componentDB = new Array();
var componentNSMap = new Array();

componentDB ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("11/complextype/AttributeValueChangeType.html","AttributeValueChangeType",false,new Array(new CN("11/element/259.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] = "11/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("9/complextype/CommonEventInformationType.html","CommonEventInformationType",false,new Array(new CN("9/element/33.html","notificationId",false,null),new CN("9/element/34.html","sourceTime",false,null),new CN("9/element/35.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("9/element/commonEventInformation.html","commonEventInformation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "9/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("4/complextype/CommonObjectInfoType.html","CommonObjectInfoType",false,new Array(new CN("4/element/10.html","name",false,null),new CN("4/element/45.html","userLabel",false,null),new CN("4/element/46.html","discoveredName",false,null),new CN("4/element/47.html","namingOs",false,null),new CN("4/element/48.html","owner",false,null),new CN("4/element/49.html","aliasNameList",false,null),new CN("4/element/50.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("4/element/commonObjectInfo.html","commonObjectInfo",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "4/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("5/complextype/EventInformationType.html","EventInformationType",false,new Array(new CN("5/element/36.html","objectType",false,null),new CN("5/element/12.html","objectName",false,null),new CN("5/element/37.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "5/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("2/simpletype/DiscoveredNameType.html","DiscoveredNameType",false,null),new CN("2/simpletype/LocationType.html","LocationType",false,null),new CN("2/simpletype/ManufactureDateType.html","ManufactureDateType",false,null),new CN("2/simpletype/ManufacturerType.html","ManufacturerType",false,null),new CN("2/simpletype/NamingOperationsSystemType.html","NamingOperationsSystemType",false,null),new CN("2/simpletype/NetworkAccessDomainType.html","NetworkAccessDomainType",false,null),new CN("2/simpletype/NotificationIdentifierType.html","NotificationIdentifierType",false,null),new CN("2/simpletype/ObjectEnumType.html","ObjectEnumType",false,null),new CN("2/simpletype/ObjectTypeType.html","ObjectTypeType",false,null),new CN("2/simpletype/OwnerType.html","OwnerType",false,null),new CN("2/simpletype/ProductNameType.html","ProductNameType",false,null),new CN("2/simpletype/UserLabelType.html","UserLabelType",false,null)),
					new Array(new CN("2/complextype/AliasNameListType.html","AliasNameListType",false,new Array(new CN("2/element/113.html","alias",false,null),new CN("2/element/114.html","alias/aliasName",false,null),new CN("2/element/115.html","alias/aliasValue",false,null))),new CN("2/complextype/AnyListType.html","AnyListType",false,null),new CN("2/complextype/MultiEventInventoryAttributesType.html","MultiEventInventoryAttributesType",false,new Array(new CN("2/element/118.html","neTime",false,null),new CN("2/element/119.html","eventIndication",false,null))),new CN("2/complextype/NotificationIdentifierListType.html","NotificationIdentifierListType",false,new Array(new CN("2/element/112.html","notificationId",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "2/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("17/simpletype/ActivityStatusEnumType.html","ActivityStatusEnumType",false,null),new CN("17/simpletype/CommunicationPatternType.html","CommunicationPatternType",false,null),new CN("17/simpletype/CommunicationStyleType.html","CommunicationStyleType",false,null),new CN("17/simpletype/CompressionEnumType.html","CompressionEnumType",false,null),new CN("17/simpletype/MessageTypeType.html","MessageTypeType",false,null),new CN("17/simpletype/PackingEnumType.html","PackingEnumType",false,null)),
					new Array(new CN("17/complextype/ActivityStatusType.html","ActivityStatusType",false,null),new CN("17/complextype/CompressionTypeType.html","CompressionTypeType",false,null),new CN("17/complextype/PackingTypeType.html","PackingTypeType",false,null)),
					new Array(),
					new Array(new CN("17/element/header.html","header",false,new Array(new CN("17/element/88.html","activityName",false,null),new CN("17/element/89.html","msgName",false,null),new CN("17/element/84.html","msgType",false,null),new CN("17/element/90.html","senderURI",false,null),new CN("17/element/91.html","destinationURI",false,null),new CN("17/element/92.html","replyToURI",false,null),new CN("17/element/93.html","originatorURI",false,null),new CN("17/element/94.html","failureReplytoURI",false,null),new CN("17/element/85.html","activityStatus",false,null),new CN("17/element/95.html","correlationId",false,null),new CN("17/element/96.html","security",false,null),new CN("17/element/97.html","securityType",false,null),new CN("17/element/98.html","priority",false,null),new CN("17/element/99.html","msgSpecificProperties",false,null),new CN("17/element/100.html","msgSpecificProperties/property",false,null),new CN("17/element/101.html","msgSpecificProperties/property/propName",false,null),new CN("17/element/102.html","msgSpecificProperties/property/propValue",false,null),new CN("17/element/82.html","communicationPattern",false,null),new CN("17/element/83.html","communicationStyle",false,null),new CN("17/element/103.html","requestedBatchSize",false,null),new CN("17/element/104.html","batchSequenceNumber",false,null),new CN("17/element/105.html","batchSequenceEndOfReply",false,null),new CN("17/element/106.html","iteratorReferenceURI",false,null),new CN("17/element/107.html","fileLocationURI",false,null),new CN("17/element/86.html","compressionType",false,null),new CN("17/element/87.html","packingType",false,null),new CN("17/element/108.html","timestamp",false,null),new CN("17/element/109.html","vendorExtensions",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] = "17/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("18/complextype/AllExceptionsType.html","AllExceptionsType",false,null),new CN("18/complextype/BaseExceptionMessageType.html","BaseExceptionMessageType",false,new Array(new CN("18/element/110.html","reason",false,null),new CN("18/element/111.html","vendorExtensions",false,null))),new CN("18/complextype/GetAllDataIteratorExceptionType.html","GetAllDataIteratorExceptionType",false,null),new CN("18/complextype/GetAllDataIteratorRequestType.html","GetAllDataIteratorRequestType",false,null)),
					new Array(),
					new Array(new CN("18/element/accessDenied.html","accessDenied",false,null),new CN("18/element/capacityExceeded.html","capacityExceeded",false,null),new CN("18/element/communicationFailure.html","communicationFailure",false,null),new CN("18/element/entityNotFound.html","entityNotFound",false,null),new CN("18/element/internalError.html","internalError",false,null),new CN("18/element/invalidFilterDefinition.html","invalidFilterDefinition",false,null),new CN("18/element/invalidInput.html","invalidInput",false,null),new CN("18/element/invalidTopic.html","invalidTopic",false,null),new CN("18/element/notificationServiceProblem.html","notificationServiceProblem",false,null),new CN("18/element/notImplemented.html","notImplemented",false,null),new CN("18/element/notInValidState.html","notInValidState",false,null),new CN("18/element/objectInUse.html","objectInUse",false,null),new CN("18/element/protectionEffortNotMet.html","protectionEffortNotMet",false,null),new CN("18/element/timeslotInUse.html","timeslotInUse",false,null),new CN("18/element/tooManyOpenIterators.html","tooManyOpenIterators",false,null),new CN("18/element/tpInvalidEndPoint.html","tpInvalidEndPoint",false,null),new CN("18/element/unableToComply.html","unableToComply",false,null),new CN("18/element/unsupportedCompressionFormat.html","unsupportedCompressionFormat",false,null),new CN("18/element/unsupportedPackingFormat.html","unsupportedPackingFormat",false,null),new CN("18/element/unsupportedRoutingConstraints.html","unsupportedRoutingConstraints",false,null),new CN("18/element/userlabelInUse.html","userlabelInUse",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] = "18/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("1/complextype/NameAndAnyValueListType.html","NameAndAnyValueListType",false,new Array(new CN("1/element/0.html","nv",false,null))),new CN("1/complextype/NameAndAnyValueType.html","NameAndAnyValueType",false,new Array(new CN("1/element/1.html","name",false,null))),new CN("1/complextype/NameAndStringValueType.html","NameAndStringValueType",false,new Array(new CN("1/element/2.html","name",false,null),new CN("1/element/3.html","value",false,null))),new CN("1/complextype/NameAndValueStringListType.html","NameAndValueStringListType",false,new Array(new CN("1/element/4.html","nvs",false,null))),new CN("1/complextype/NamingAttributeListType.html","NamingAttributeListType",false,new Array(new CN("1/element/5.html","name",false,null))),new CN("1/complextype/NamingAttributeType.html","NamingAttributeType",false,new Array(new CN("1/element/6.html","object",false,null),new CN("1/element/7.html","object/type",false,null),new CN("1/element/8.html","object/name",false,null)))),
					new Array(),
					new Array(new CN("1/element/nvList.html","nvList",false,null),new CN("1/element/nvsList.html","nvsList",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "1/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("10/complextype/ObjectCreationType.html","ObjectCreationType",false,new Array(new CN("10/element/38.html","object",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] = "10/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("12/complextype/ObjectDeletionType.html","ObjectDeletionType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] = "12/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("13/complextype/StateChangeType.html","StateChangeType",false,new Array(new CN("13/element/39.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] = "13/index.html";
componentDB ["http://www.tmforum.org/mtop/sa/xsd/sai/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("3/complextype/AvailabilityScheduleType.html","AvailabilityScheduleType",false,new Array(new CN("3/element/121.html","periodicSchedule",false,null),new CN("3/element/122.html","randomSchedule",false,null))),new CN("3/complextype/PeriodicScheduleType.html","PeriodicScheduleType",false,new Array(new CN("3/element/124.html","start",false,null),new CN("3/element/125.html","availabilityDuration",false,null),new CN("3/element/126.html","recurrenceInterval",false,null),new CN("3/element/127.html","end",false,null),new CN("3/element/128.html","extensionTime",false,null))),new CN("3/complextype/ProductInfoType.html","ProductInfoType",false,new Array(new CN("3/element/15.html","productName",false,null),new CN("3/element/17.html","productSpecificationName",false,null),new CN("3/element/13.html","productBundleName",false,null),new CN("3/element/16.html","productSpecCharacteristicID",false,null),new CN("3/element/14.html","productCharacteristicValue",false,null))),new CN("3/complextype/RandomScheduleType.html","RandomScheduleType",false,new Array(new CN("3/element/129.html","start",false,null),new CN("3/element/130.html","availabilityDuration",false,null),new CN("3/element/131.html","extensionTime",false,null))),new CN("3/complextype/RequestInfoBasicType.html","RequestInfoBasicType",false,new Array(new CN("3/element/132.html","productInfo",false,null),new CN("3/element/19.html","subscriberList",false,null),new CN("3/element/20.html","userList",false,null),new CN("3/element/18.html","sapList",false,null))),new CN("3/complextype/RequestInfoSOAwareType.html","RequestInfoSOAwareType",false,new Array(new CN("3/element/139.html","requestedCompletionDate",false,null),new CN("3/element/140.html","priority",false,null),new CN("3/element/141.html","purchaseOrder",false,null),new CN("3/element/142.html","validFor",false,null))),new CN("3/complextype/RootRequestType.html","RootRequestType",false,new Array(new CN("3/element/116.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("3/element/activateException.html","activateException",false,new Array(new CN("3/element/158.html","basicFailureEvent",false,null),new CN("3/element/159.html","serviceCreationFailureEvent",false,null),new CN("3/element/160.html","serviceStateTransitionFailureEvent",false,null))),new CN("3/element/activateRequest.html","activateRequest",false,new Array(new CN("3/element/133.html","basicInput",false,null),new CN("3/element/143.html","soaInput",false,null),new CN("3/element/167.html","cfsCurrentState",false,null))),new CN("3/element/activateResponse.html","activateResponse",false,new Array(new CN("3/element/168.html","initialResponse",false,null),new CN("3/element/169.html","beginProcessingEvent",false,null),new CN("3/element/170.html","cfsCreation",false,null),new CN("3/element/171.html","cfsStateChange",false,null))),new CN("3/element/amend.html","amend",false,new Array(new CN("3/element/180.html","serviceRequestID",false,null))),new CN("3/element/amendException.html","amendException",false,new Array(new CN("3/element/181.html","basicFailureEvent",false,null))),new CN("3/element/amendResponse.html","amendResponse",false,new Array(new CN("3/element/182.html","ack",false,null),new CN("3/element/183.html","nackReason",false,null))),new CN("3/element/cancelException.html","cancelException",false,new Array(new CN("3/element/184.html","basicFailureEvent",false,null),new CN("3/element/185.html","serviceDeletionFailureEvent",false,null))),new CN("3/element/cancelRequest.html","cancelRequest",false,new Array(new CN("3/element/152.html","rootRequest",false,null),new CN("3/element/9.html","productName",false,null),new CN("3/element/144.html","soaInput",false,null))),new CN("3/element/cancelResponse.html","cancelResponse",false,new Array(new CN("3/element/189.html","initialResponse",false,null),new CN("3/element/190.html","beginProcessingEvent",false,null),new CN("3/element/191.html","cfsDeleteEvent",false,null))),new CN("3/element/deactivateException.html","deactivateException",false,new Array(new CN("3/element/193.html","basicFailureEvent",false,null),new CN("3/element/194.html","serviceStateTransitionFailureEvent",false,null))),new CN("3/element/deactivateRequest.html","deactivateRequest",false,new Array(new CN("3/element/153.html","rootRequest",false,null),new CN("3/element/11.html","productName",false,null),new CN("3/element/145.html","soaInput",false,null))),new CN("3/element/deactivateResponse.html","deactivateResponse",false,new Array(new CN("3/element/195.html","initialResponse",false,null),new CN("3/element/196.html","beginProcessingEvent",false,null),new CN("3/element/197.html","cfsStateChange",false,null))),new CN("3/element/designException.html","designException",false,new Array(new CN("3/element/198.html","basicFailureEvent",false,null),new CN("3/element/199.html","serviceCreationFailureEvent",false,null),new CN("3/element/200.html","serviceStateTransitionFailureEvent",false,null))),new CN("3/element/designRequest.html","designRequest",false,new Array(new CN("3/element/134.html","basicInput",false,null),new CN("3/element/146.html","soaInput",false,null))),new CN("3/element/designResponse.html","designResponse",false,new Array(new CN("3/element/201.html","initialResponse",false,null),new CN("3/element/202.html","beginProcessingEvent",false,null),new CN("3/element/203.html","cfsCreation",false,null),new CN("3/element/204.html","cfsStateChange",false,null))),new CN("3/element/feasibilityCheckException.html","feasibilityCheckException",false,new Array(new CN("3/element/205.html","basicFailureEvent",false,null),new CN("3/element/206.html","serviceCreationFailureEvent",false,null))),new CN("3/element/feasibilityCheckRequest.html","feasibilityCheckRequest",false,new Array(new CN("3/element/135.html","feasibilityCheckRequestInput",false,null))),new CN("3/element/feasibilityCheckResponse.html","feasibilityCheckResponse",false,new Array(new CN("3/element/207.html","initialResponse",false,null),new CN("3/element/208.html","beginProcessingEvent",false,null),new CN("3/element/209.html","cfsCreation",false,null))),new CN("3/element/modifyException.html","modifyException",false,new Array(new CN("3/element/210.html","basicFailureEvent",false,null),new CN("3/element/211.html","serviceCreationFailureEvent",false,null),new CN("3/element/212.html","serviceDeletionFailureEvent",false,null),new CN("3/element/213.html","serviceStateTransitionFailureEvent",false,null),new CN("3/element/214.html","serviceAvcFailureEvent",false,null))),new CN("3/element/modifyRequest.html","modifyRequest",false,new Array(new CN("3/element/136.html","basicInput",false,null),new CN("3/element/147.html","soaInput",false,null),new CN("3/element/217.html","targetState",false,null))),new CN("3/element/modifyResponse.html","modifyResponse",false,new Array(new CN("3/element/218.html","initialResponse",false,null),new CN("3/element/219.html","beginProcessingEvent",false,null),new CN("3/element/220.html","cfsCreation",false,null),new CN("3/element/221.html","cfsDeletion",false,null),new CN("3/element/222.html","cfsStateChange",false,null),new CN("3/element/223.html","cfsAvcChange",false,null))),new CN("3/element/provisionException.html","provisionException",false,new Array(new CN("3/element/226.html","basicFailureEvent",false,null),new CN("3/element/227.html","serviceCreationFailureEvent",false,null),new CN("3/element/228.html","serviceStateTransitionFailureEvent",false,null))),new CN("3/element/provisionRequest.html","provisionRequest",false,new Array(new CN("3/element/137.html","basicInput",false,null),new CN("3/element/148.html","soaInput",false,null))),new CN("3/element/provisionResponse.html","provisionResponse",false,new Array(new CN("3/element/229.html","initialResponse",false,null),new CN("3/element/230.html","beginProcessingEvent",false,null),new CN("3/element/231.html","cfsCreation",false,null),new CN("3/element/232.html","cfsStateChange",false,null))),new CN("3/element/reserveException.html","reserveException",false,new Array(new CN("3/element/233.html","basicFailureEvent",false,null),new CN("3/element/234.html","serviceCreationFailureEvent",false,null),new CN("3/element/235.html","serviceStateTransitionFailureEvent",false,null))),new CN("3/element/reserveRequest.html","reserveRequest",false,new Array(new CN("3/element/138.html","basicInput",false,null),new CN("3/element/149.html","soaInput",false,null),new CN("3/element/236.html","expiringTime",false,null),new CN("3/element/123.html","productAvailabilitySchedule",false,null),new CN("3/element/237.html","commit",false,null),new CN("3/element/238.html","desiredState",false,null))),new CN("3/element/reserveResponse.html","reserveResponse",false,new Array(new CN("3/element/239.html","initialResponse",false,null),new CN("3/element/240.html","beginProcessingEvent",false,null),new CN("3/element/241.html","cfsCreation",false,null),new CN("3/element/242.html","cfsStateChange",false,null))),new CN("3/element/retireException.html","retireException",false,new Array(new CN("3/element/243.html","basicFailureEvent",false,null),new CN("3/element/244.html","serviceDeletionFailureEvent",false,null))),new CN("3/element/retireRequest.html","retireRequest",false,new Array(new CN("3/element/154.html","rootRequest",false,null),new CN("3/element/21.html","productName",false,null),new CN("3/element/150.html","soaInput",false,null))),new CN("3/element/retireResponse.html","retireResponse",false,new Array(new CN("3/element/245.html","initialResponse",false,null),new CN("3/element/246.html","beginProcessingEvent",false,null),new CN("3/element/247.html","cfsDeleteEvent",false,null))),new CN("3/element/retrieveServiceStatesException.html","retrieveServiceStatesException",false,new Array(new CN("3/element/248.html","basicFailureEvent",false,null))),new CN("3/element/retrieveServiceStatesRequest.html","retrieveServiceStatesRequest",false,new Array(new CN("3/element/155.html","rootRequest",false,null),new CN("3/element/22.html","productName",false,null))),new CN("3/element/retrieveServiceStatesResponse.html","retrieveServiceStatesResponse",false,new Array(new CN("3/element/23.html","cfsName",false,null),new CN("3/element/249.html","cfsState",false,null))),new CN("3/element/terminateException.html","terminateException",false,new Array(new CN("3/element/250.html","basicFailureEvent",false,null),new CN("3/element/251.html","serviceStateTransitionFailureEvent",false,null))),new CN("3/element/terminateRequest.html","terminateRequest",false,new Array(new CN("3/element/156.html","rootRequest",false,null),new CN("3/element/31.html","productName",false,null),new CN("3/element/151.html","soaInput",false,null))),new CN("3/element/terminateResponse.html","terminateResponse",false,new Array(new CN("3/element/252.html","initialResponse",false,null),new CN("3/element/253.html","beginProcessingEvent",false,null),new CN("3/element/254.html","cfsStateChange",false,null))),new CN("3/element/testException.html","testException",false,new Array(new CN("3/element/255.html","basicFailureEvent",false,null))),new CN("3/element/testRequest.html","testRequest",false,new Array(new CN("3/element/157.html","rootRequest",false,null),new CN("3/element/32.html","productName",false,null))),new CN("3/element/testResponse.html","testResponse",false,new Array(new CN("3/element/256.html","initialResponse",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sa/xsd/sai/v1"] = "3/index.html";
componentDB ["http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("7/complextype/BasicFailureEventType.html","BasicFailureEventType",false,null),new CN("7/complextype/ServiceAvcFailureEventType.html","ServiceAvcFailureEventType",false,new Array(new CN("7/element/215.html","serviceRequestID",false,null),new CN("7/element/216.html","productName",false,null),new CN("7/element/25.html","cfsName",false,null),new CN("7/element/26.html","productSpecCharacteristicID",false,null),new CN("7/element/27.html","serviceSpecCharacteristicID",false,null))),new CN("7/complextype/ServiceCreationFailureEventType.html","ServiceCreationFailureEventType",false,new Array(new CN("7/element/28.html","cfsName",false,null),new CN("7/element/161.html","currentState",false,null),new CN("7/element/162.html","failedState",false,null))),new CN("7/complextype/ServiceDeletionFailureEventType.html","ServiceDeletionFailureEventType",false,new Array(new CN("7/element/186.html","serviceRequestID",false,null),new CN("7/element/187.html","productName",false,null),new CN("7/element/29.html","cfsName",false,null),new CN("7/element/188.html","currentState",false,null))),new CN("7/complextype/ServiceStateTransitionFailureEventType.html","ServiceStateTransitionFailureEventType",false,new Array(new CN("7/element/163.html","serviceRequestID",false,null),new CN("7/element/164.html","productName",false,null),new CN("7/element/30.html","cfsName",false,null),new CN("7/element/165.html","currentState",false,null),new CN("7/element/166.html","failedState",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sa/xsd/saiexcpt/v1"] = "7/index.html";
componentDB ["http://www.tmforum.org/mtop/sa/xsd/sairsp/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("6/complextype/BeginProcessingEventType.html","BeginProcessingEventType",false,new Array(new CN("6/element/174.html","soAwareParamsRes",false,null))),new CN("6/complextype/CfsAvcEventType.html","CfsAvcEventType",false,new Array(new CN("6/element/224.html","serviceAttributeValueChangeList",false,null),new CN("6/element/225.html","last",false,null))),new CN("6/complextype/CfsCreationEventType.html","CfsCreationEventType",false,new Array(new CN("6/element/175.html","cfsCreationEvent",false,null),new CN("6/element/176.html","feasibilityFlag",false,null),new CN("6/element/177.html","offeredActivationTime",false,null),new CN("6/element/178.html","last",false,null))),new CN("6/complextype/CfsDeletionEventType.html","CfsDeletionEventType",false,new Array(new CN("6/element/120.html","cfsDeletionEvents",false,null),new CN("6/element/192.html","last",false,null))),new CN("6/complextype/CfsStateChangeEventType.html","CfsStateChangeEventType",false,new Array(new CN("6/element/40.html","serviceStateChangeList",false,null),new CN("6/element/179.html","last",false,null))),new CN("6/complextype/InitialResponseType.html","InitialResponseType",false,new Array(new CN("6/element/173.html","accept",false,null))),new CN("6/complextype/RootResponseType.html","RootResponseType",false,new Array(new CN("6/element/172.html","serviceRequestID",false,null),new CN("6/element/24.html","productName",false,null),new CN("6/element/117.html","vendorExtensions",false,null))),new CN("6/complextype/SOAwareParamsResType.html","SOAwareParamsResType",false,new Array(new CN("6/element/257.html","serviceOrderID",false,null),new CN("6/element/258.html","expectedCompletionDate",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sa/xsd/sairsp/v1"] = "6/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("15/simpletype/OperStateType.html","OperStateType",false,null),new CN("15/simpletype/ServiceStateType.html","ServiceStateType",false,null)),
					new Array(new CN("15/complextype/CommonServiceInfoType.html","CommonServiceInfoType",false,new Array(new CN("15/element/43.html","id",false,null),new CN("15/element/44.html","description",false,null))),new CN("15/complextype/PartyRoleType.html","PartyRoleType",false,new Array(new CN("15/element/51.html","partyRoleId",false,null),new CN("15/element/52.html","status",false,null),new CN("15/element/53.html","validFor",false,null))),new CN("15/complextype/ServiceAccessPointType.html","ServiceAccessPointType",false,new Array(new CN("15/element/56.html","type",false,null),new CN("15/element/57.html","name",false,null),new CN("15/element/58.html","description",false,null),new CN("15/element/42.html","serviceState",false,null),new CN("15/element/41.html","operationalState",false,null))),new CN("15/complextype/ServiceCharValueType.html","ServiceCharValueType",false,new Array(new CN("15/element/59.html","value",false,null),new CN("15/element/60.html","validFor",false,null),new CN("15/element/61.html","serviceSpecCharacteristic",false,null))),new CN("15/complextype/ServiceSpecCharType.html","ServiceSpecCharType",false,new Array(new CN("15/element/62.html","valueType",false,null),new CN("15/element/63.html","minCardinality",false,null),new CN("15/element/64.html","maxCardinality",false,null),new CN("15/element/65.html","derivationFormula",false,null),new CN("15/element/66.html","validFor",false,null),new CN("15/element/67.html","serviceSpecCharacteristicValue",false,null))),new CN("15/complextype/ServiceSpecCharValueType.html","ServiceSpecCharValueType",false,new Array(new CN("15/element/68.html","valueType",false,null),new CN("15/element/69.html","default",false,null),new CN("15/element/70.html","value",false,null),new CN("15/element/71.html","unitOfMeasure",false,null),new CN("15/element/72.html","valueFrom",false,null),new CN("15/element/73.html","valueTo",false,null),new CN("15/element/74.html","validFor",false,null))),new CN("15/complextype/ServiceSpecVersionType.html","ServiceSpecVersionType",false,new Array(new CN("15/element/75.html","svcSpecRevisionName",false,null),new CN("15/element/76.html","svcSpecRevisionFormat",false,null),new CN("15/element/77.html","svcSpecRevisionNumber",false,null),new CN("15/element/78.html","svcSpecRevisionReason",false,null),new CN("15/element/79.html","svcSpecRevisionSemantics",false,null),new CN("15/element/80.html","svcSpecRevisionTimestamp",false,null),new CN("15/element/81.html","svcSpecRevisionValidityPeriod",false,null))),new CN("15/complextype/SubscriberType.html","SubscriberType",false,null),new CN("15/complextype/TimePeriodType.html","TimePeriodType",false,new Array(new CN("15/element/54.html","startDateTime",false,null),new CN("15/element/55.html","endDateTime",false,null))),new CN("15/complextype/UserType.html","UserType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] = "15/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/savc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("19/complextype/ServiceAttributeValueChangeType.html","ServiceAttributeValueChangeType",false,null)),
					new Array(),
					new Array(new CN("19/element/serviceAttributeValueChange.html","serviceAttributeValueChange",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/savc/v1"] = "19/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/soc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("8/complextype/ServiceObjectCreationType.html","ServiceObjectCreationType",false,null)),
					new Array(),
					new Array(new CN("8/element/serviceObjectCreation.html","serviceObjectCreation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/soc/v1"] = "8/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/sodel/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("16/complextype/ServiceObjectDeletionType.html","ServiceObjectDeletionType",false,null)),
					new Array(),
					new Array(new CN("16/element/serviceObjectDeletion.html","serviceObjectDeletion",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/sodel/v1"] = "16/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/ssc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("14/complextype/ServiceStateChangeType.html","ServiceStateChangeType",false,null)),
					new Array(),
					new Array(new CN("14/element/ServiceStateChange.html","ServiceStateChange",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/ssc/v1"] = "14/index.html";
								   


