﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_ciFileName = "componentIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function CN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function C (attributeList, attributeGroupList,
						simpleTypeList, complexTypeList,
						modelGroupList, elementList, 
						notationList) 
{
	this.attributes = attributeList;
	this.attributegroups = attributeGroupList;
	this.simpletypes = simpleTypeList;
	this.complextypes = complexTypeList;
	this.modelgroups = modelGroupList;
	this.elements = elementList;
	this.notations = notationList;
}

function component_showAllComponents() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_ciFileName;
}

function component_filterComponents () {
	parent._href = "xsd/" + xsd_ciFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function component_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href=xsd_ciFileName;	
}

function component_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in componentDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}

	parent._xsdNsFilter = nsList;
}

function component_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	component_outputList (null, components);	
}


function component_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		component_outputList (namespace, list);	
	}
}


function component_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		component_showComponentsNS (nsList, componentList)
	} else {
		component_showComponentsNoNS (nsList, componentList)
	}
}

function component_showAttributes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		attributes [i] = componentDB [nsList[i]].attributes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributes);
}

function component_showAttributeGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributegroups = new Array();
	var nss = new Array();		

	for (var i=0; i<nsList.length; i++) {
		attributegroups [i] = componentDB [nsList[i]].attributegroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributegroups);
}

function component_showSimpleTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var simpletypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		simpletypes [i] = componentDB [nsList[i]].simpletypes;	
		nss [i] = nsList[i];
	}		

	component_showComponents (nss, simpletypes);
}

function component_showComplexTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var complextypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		complextypes [i] = componentDB [nsList[i]].complextypes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, complextypes);
}

function component_showElements() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var elements = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		elements [i] = componentDB [nsList[i]].elements;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, elements);
}

function component_showModelGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var modelgroups = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		modelgroups [i] = componentDB [nsList[i]].modelgroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, modelgroups);
}

function component_showNotations() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var notations = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		notations [i] = componentDB [nsList[i]].notations;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, notations);

}


function component_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function component_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+component_getNodeText(node)+
			  '" target="'+target+'">'+component_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function component_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+component_getNodeText(node)+
			'" target="'+target+'">'+component_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		component_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function component_outputTree (node) {
	if (node.hasChild == false) {
		component_outputLeaf (node);
	} else {
		component_outputNonLeaf (node);
	}
}

function component_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = componentNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+target+'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		component_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}


var componentDB = new Array();
var componentNSMap = new Array();

componentDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("3/complextype/CommonObjectInfoType.html","CommonObjectInfoType",false,new Array(new CN("3/element/20.html","name",false,null),new CN("3/element/57.html","userLabel",false,null),new CN("3/element/58.html","discoveredName",false,null),new CN("3/element/59.html","namingOs",false,null),new CN("3/element/60.html","owner",false,null),new CN("3/element/61.html","aliasNameList",false,null),new CN("3/element/62.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("3/element/commonObjectInfo.html","commonObjectInfo",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "3/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("5/simpletype/DiscoveredNameType.html","DiscoveredNameType",false,null),new CN("5/simpletype/ManufactureDateType.html","ManufactureDateType",false,null),new CN("5/simpletype/NetworkAccessDomainType.html","NetworkAccessDomainType",false,null),new CN("5/simpletype/NotificationIdentifierType.html","NotificationIdentifierType",false,null),new CN("5/simpletype/ObjectEnumType.html","ObjectEnumType",false,null),new CN("5/simpletype/ObjectTypeType.html","ObjectTypeType",false,null),new CN("5/simpletype/OwnerType.html","OwnerType",false,null),new CN("5/simpletype/QueryDialectEnumType.html","QueryDialectEnumType",false,null),new CN("5/simpletype/QueryDialectTypeType.html","QueryDialectTypeType",false,null)),
					new Array(new CN("5/complextype/AliasNameListType.html","AliasNameListType",false,new Array(new CN("5/element/151.html","alias",false,null),new CN("5/element/152.html","alias/aliasName",false,null),new CN("5/element/153.html","alias/aliasValue",false,null))),new CN("5/complextype/AnyListType.html","AnyListType",false,null),new CN("5/complextype/MultiEventInventoryAttributesType.html","MultiEventInventoryAttributesType",false,new Array(new CN("5/element/155.html","neTime",false,null),new CN("5/element/156.html","eventIndication",false,null))),new CN("5/complextype/NameAndAnyValueListType.html","NameAndAnyValueListType",false,new Array(new CN("5/element/157.html","nv",false,null))),new CN("5/complextype/NameAndAnyValueType.html","NameAndAnyValueType",false,new Array(new CN("5/element/158.html","name",false,null))),new CN("5/complextype/NameAndStringValueType.html","NameAndStringValueType",false,new Array(new CN("5/element/159.html","name",false,null),new CN("5/element/160.html","value",false,null))),new CN("5/complextype/NameAndValueStringListType.html","NameAndValueStringListType",false,new Array(new CN("5/element/161.html","nvs",false,null))),new CN("5/complextype/NotificationIdentifierListType.html","NotificationIdentifierListType",false,new Array(new CN("5/element/150.html","notificationId",false,null))),new CN("5/complextype/QueryExpressionType.html","QueryExpressionType",false,null)),
					new Array(),
					new Array(new CN("5/element/nvList.html","nvList",false,null),new CN("5/element/nvsList.html","nvsList",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "5/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("8/simpletype/ActivityStatusEnumType.html","ActivityStatusEnumType",false,null),new CN("8/simpletype/CommunicationPatternType.html","CommunicationPatternType",false,null),new CN("8/simpletype/CommunicationStyleType.html","CommunicationStyleType",false,null),new CN("8/simpletype/CompressionEnumType.html","CompressionEnumType",false,null),new CN("8/simpletype/MessageTypeType.html","MessageTypeType",false,null),new CN("8/simpletype/PackingEnumType.html","PackingEnumType",false,null)),
					new Array(new CN("8/complextype/ActivityStatusType.html","ActivityStatusType",false,null),new CN("8/complextype/CompressionTypeType.html","CompressionTypeType",false,null),new CN("8/complextype/PackingTypeType.html","PackingTypeType",false,null)),
					new Array(),
					new Array(new CN("8/element/header.html","header",false,new Array(new CN("8/element/128.html","activityName",false,null),new CN("8/element/129.html","msgName",false,null),new CN("8/element/124.html","msgType",false,null),new CN("8/element/130.html","senderURI",false,null),new CN("8/element/131.html","destinationURI",false,null),new CN("8/element/132.html","replyToURI",false,null),new CN("8/element/133.html","originatorURI",false,null),new CN("8/element/134.html","failureReplytoURI",false,null),new CN("8/element/125.html","activityStatus",false,null),new CN("8/element/135.html","correlationId",false,null),new CN("8/element/136.html","security",false,null),new CN("8/element/137.html","securityType",false,null),new CN("8/element/138.html","priority",false,null),new CN("8/element/139.html","msgSpecificProperties",false,null),new CN("8/element/140.html","msgSpecificProperties/property",false,null),new CN("8/element/141.html","msgSpecificProperties/property/propName",false,null),new CN("8/element/142.html","msgSpecificProperties/property/propValue",false,null),new CN("8/element/122.html","communicationPattern",false,null),new CN("8/element/123.html","communicationStyle",false,null),new CN("8/element/143.html","requestedBatchSize",false,null),new CN("8/element/144.html","batchSequenceNumber",false,null),new CN("8/element/145.html","batchSequenceEndOfReply",false,null),new CN("8/element/146.html","iteratorReferenceURI",false,null),new CN("8/element/147.html","fileLocationURI",false,null),new CN("8/element/126.html","compressionType",false,null),new CN("8/element/127.html","packingType",false,null),new CN("8/element/148.html","timestamp",false,null),new CN("8/element/149.html","vendorExtensions",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/hdr/v1"] = "8/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("7/complextype/AllExceptionsType.html","AllExceptionsType",false,null),new CN("7/complextype/BaseExceptionMessageType.html","BaseExceptionMessageType",false,new Array(new CN("7/element/162.html","reason",false,null),new CN("7/element/154.html","vendorExtensions",false,null))),new CN("7/complextype/GetAllDataIteratorExceptionType.html","GetAllDataIteratorExceptionType",false,null),new CN("7/complextype/GetAllDataIteratorRequestType.html","GetAllDataIteratorRequestType",false,null)),
					new Array(),
					new Array(new CN("7/element/accessDenied.html","accessDenied",false,null),new CN("7/element/capacityExceeded.html","capacityExceeded",false,null),new CN("7/element/commLoss.html","commLoss",false,null),new CN("7/element/entityNotFound.html","entityNotFound",false,null),new CN("7/element/internalError.html","internalError",false,null),new CN("7/element/invalidFilterDefinition.html","invalidFilterDefinition",false,null),new CN("7/element/invalidInput.html","invalidInput",false,null),new CN("7/element/invalidTopic.html","invalidTopic",false,null),new CN("7/element/notificationServiceProblem.html","notificationServiceProblem",false,null),new CN("7/element/notImplemented.html","notImplemented",false,null),new CN("7/element/notInValidState.html","notInValidState",false,null),new CN("7/element/objectInUse.html","objectInUse",false,null),new CN("7/element/protectionEffortNotMet.html","protectionEffortNotMet",false,null),new CN("7/element/timeslotInUse.html","timeslotInUse",false,null),new CN("7/element/tooManyOpenIterators.html","tooManyOpenIterators",false,null),new CN("7/element/tpInvalidEndPoint.html","tpInvalidEndPoint",false,null),new CN("7/element/unableToComply.html","unableToComply",false,null),new CN("7/element/unsupportedCompressionFormat.html","unsupportedCompressionFormat",false,null),new CN("7/element/unsupportedPackingFormat.html","unsupportedPackingFormat",false,null),new CN("7/element/unsupportedRoutingConstraints.html","unsupportedRoutingConstraints",false,null),new CN("7/element/userlabelInUse.html","userlabelInUse",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/msg/v1"] = "7/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("1/complextype/NamingAttributeListType.html","NamingAttributeListType",false,new Array(new CN("1/element/0.html","name",false,null))),new CN("1/complextype/NamingAttributeType.html","NamingAttributeType",false,new Array(new CN("1/element/19.html","rdn",false,null))),new CN("1/complextype/RelativeDistinguishNameType.html","RelativeDistinguishNameType",false,new Array(new CN("1/element/35.html","type",false,null),new CN("1/element/36.html","value",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "1/index.html";
componentDB ["http://www.tmforum.org/mtop/msi/xsd/sir/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("4/simpletype/GranularityType.html","GranularityType",false,null),new CN("4/simpletype/ServiceObjectEnumType.html","ServiceObjectEnumType",false,null),new CN("4/simpletype/ServiceObjectTypeType.html","ServiceObjectTypeType",false,null)),
					new Array(new CN("4/complextype/ServiceInventoryDataType.html","ServiceInventoryDataType",false,new Array(new CN("4/element/39.html","serviceDefinitionList",false,null),new CN("4/element/40.html","serviceDefinitionList/sd",false,null),new CN("4/element/41.html","serviceTemplateList",false,null),new CN("4/element/42.html","serviceTemplateList/st",false,null),new CN("4/element/43.html","serviceCatalogList",false,null),new CN("4/element/44.html","serviceCatalogList/sc",false,null),new CN("4/element/45.html","cfsList",false,null),new CN("4/element/46.html","cfsList/cfs",false,null),new CN("4/element/47.html","rfsList",false,null),new CN("4/element/48.html","rfsList/rfs",false,null),new CN("4/element/49.html","sscList",false,null),new CN("4/element/50.html","sscList/ssc",false,null),new CN("4/element/51.html","sapSpecList",false,null),new CN("4/element/52.html","sapSpecList/sapSpec",false,null),new CN("4/element/53.html","sapList",false,null),new CN("4/element/54.html","sapList/sap",false,null))),new CN("4/complextype/SimpleServiceFilterType.html","SimpleServiceFilterType",false,new Array(new CN("4/element/92.html","scope",false,null),new CN("4/element/34.html","scope/baseInstance",false,null),new CN("4/element/38.html","scope/serviceObjectType",false,null),new CN("4/element/93.html","scope/queryExpression",false,null),new CN("4/element/37.html","selection",false,null)))),
					new Array(),
					new Array(new CN("4/element/getServiceInventoryException.html","getServiceInventoryException",false,null),new CN("4/element/getServiceInventoryIteratorException.html","getServiceInventoryIteratorException",false,null),new CN("4/element/getServiceInventoryIteratorRequest.html","getServiceInventoryIteratorRequest",false,null),new CN("4/element/getServiceInventoryIteratorResponse.html","getServiceInventoryIteratorResponse",false,new Array(new CN("4/element/55.html","inventoryData",false,null))),new CN("4/element/getServiceInventoryRequest.html","getServiceInventoryRequest",false,new Array(new CN("4/element/94.html","filter",false,null),new CN("4/element/95.html","diffDateAndTime",false,null))),new CN("4/element/getServiceInventoryResponse.html","getServiceInventoryResponse",false,new Array(new CN("4/element/56.html","inventoryData",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/msi/xsd/sir/v1"] = "4/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("6/complextype/CommonServiceInfoType.html","CommonServiceInfoType",false,new Array(new CN("6/element/63.html","description",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/csi/v1"] = "6/index.html";
componentDB ["http://www.tmforum.org/mtop/sb/xsd/svc/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("2/simpletype/AdminStateType.html","AdminStateType",false,null),new CN("2/simpletype/OperationalStateType.html","OperationalStateType",false,null),new CN("2/simpletype/ServiceDefinitionStatusType.html","ServiceDefinitionStatusType",false,null),new CN("2/simpletype/ServiceStateType.html","ServiceStateType",false,null),new CN("2/simpletype/ServiceTemplateStatusType.html","ServiceTemplateStatusType",false,null),new CN("2/simpletype/StartModeType.html","StartModeType",false,null)),
					new Array(new CN("2/complextype/CustomerFacingServiceType.html","CustomerFacingServiceType",false,new Array(new CN("2/element/21.html","containedByCfsRef",false,null),new CN("2/element/1.html","containsCfsRefList",false,null),new CN("2/element/2.html","rfsRefList",false,null),new CN("2/element/22.html","productRef",false,null))),new CN("2/complextype/PartyRoleType.html","PartyRoleType",false,new Array(new CN("2/element/96.html","partyRoleId",false,null),new CN("2/element/97.html","status",false,null),new CN("2/element/98.html","validFor",false,null))),new CN("2/complextype/ResourceFacingServiceType.html","ResourceFacingServiceType",false,new Array(new CN("2/element/24.html","containedByRfsRef",false,null),new CN("2/element/3.html","containsRfsRefList",false,null),new CN("2/element/23.html","cfsRef",false,null))),new CN("2/complextype/SapSpecificationType.html","SapSpecificationType",false,new Array(new CN("2/element/86.html","type",false,null),new CN("2/element/87.html","applicableServiceList",false,null),new CN("2/element/88.html","applicableStateValueList",false,null),new CN("2/element/4.html","supportedSdRefList",false,null))),new CN("2/complextype/ServiceAccessPointType.html","ServiceAccessPointType",false,new Array(new CN("2/element/89.html","adminState",false,null),new CN("2/element/90.html","serviceState",false,null),new CN("2/element/91.html","operationalState",false,null),new CN("2/element/27.html","subscriberRef",false,null),new CN("2/element/5.html","userRefList",false,null),new CN("2/element/25.html","resourceRef",false,null),new CN("2/element/26.html","sapSpecRef",false,null))),new CN("2/complextype/ServiceCatalogType.html","ServiceCatalogType",false,new Array(new CN("2/element/6.html","sscRefList",false,null),new CN("2/element/7.html","ssDefinitionRefList",false,null),new CN("2/element/8.html","ssTemplateRefList",false,null))),new CN("2/complextype/ServiceCharacteristicValueType.html","ServiceCharacteristicValueType",false,new Array(new CN("2/element/104.html","value",false,null),new CN("2/element/105.html","validFor",false,null),new CN("2/element/28.html","sscRef",false,null))),new CN("2/complextype/ServiceDefinitionType.html","ServiceDefinitionType",false,new Array(new CN("2/element/67.html","activationMode",false,null),new CN("2/element/68.html","sdStatus",false,null),new CN("2/element/10.html","sapSpecificationRefList",false,null),new CN("2/element/9.html","dependencyRefList",false,null),new CN("2/element/11.html","validatesRefList",false,null))),new CN("2/complextype/ServiceSpecCharacteristicType.html","ServiceSpecCharacteristicType",false,new Array(new CN("2/element/80.html","valueType",false,null),new CN("2/element/81.html","minCardinality",false,null),new CN("2/element/82.html","maxCardinality",false,null),new CN("2/element/83.html","derivationFormula",false,null),new CN("2/element/84.html","validFor",false,null),new CN("2/element/12.html","containedBySscRefList",false,null),new CN("2/element/13.html","containsSscRefList",false,null),new CN("2/element/29.html","productScRef",false,null),new CN("2/element/14.html","serviceCatalogRefList",false,null),new CN("2/element/85.html","valueList",false,null))),new CN("2/complextype/ServiceSpecCharacteristicUseType.html","ServiceSpecCharacteristicUseType",false,new Array(new CN("2/element/114.html","globallySet",false,null),new CN("2/element/115.html","canBeOveridden",false,null),new CN("2/element/116.html","minCardinality",false,null),new CN("2/element/117.html","maxCardinality",false,null),new CN("2/element/118.html","extensible",false,null),new CN("2/element/119.html","validFor",false,null))),new CN("2/complextype/ServiceSpecCharacteristicValueType.html","ServiceSpecCharacteristicValueType",false,new Array(new CN("2/element/106.html","valueType",false,null),new CN("2/element/107.html","default",false,null),new CN("2/element/108.html","value",false,null),new CN("2/element/109.html","unitOfMeasure",false,null),new CN("2/element/110.html","valueFrom",false,null),new CN("2/element/111.html","valueTo",false,null),new CN("2/element/112.html","rangeInterval",false,null),new CN("2/element/113.html","validFor",false,null))),new CN("2/complextype/ServiceSpecCharInUseType.html","ServiceSpecCharInUseType",false,new Array(new CN("2/element/30.html","sscRef",false,null),new CN("2/element/120.html","sscUse",false,null),new CN("2/element/121.html","valueList",false,null))),new CN("2/complextype/ServiceSpecificationType.html","ServiceSpecificationType",false,new Array(new CN("2/element/64.html","serviceSpecType",false,null),new CN("2/element/65.html","version",false,null),new CN("2/element/15.html","productSpecRefList",false,null),new CN("2/element/16.html","serviceCatalogRefList",false,null),new CN("2/element/66.html","describedByList",false,null))),new CN("2/complextype/ServiceSpecificationTypeType.html","ServiceSpecificationTypeType",false,new Array(new CN("2/element/101.html","name",false,null),new CN("2/element/102.html","description",false,null),new CN("2/element/103.html","version",false,null))),new CN("2/complextype/ServiceTemplateType.html","ServiceTemplateType",false,new Array(new CN("2/element/69.html","source",false,null),new CN("2/element/70.html","serviceLocation",false,null),new CN("2/element/71.html","stStatus",false,null),new CN("2/element/31.html","validatedByRef",false,null))),new CN("2/complextype/ServiceType.html","ServiceType",false,new Array(new CN("2/element/72.html","hasStarted",false,null),new CN("2/element/73.html","isMandatory",false,null),new CN("2/element/74.html","startMode",false,null),new CN("2/element/75.html","isStateful",false,null),new CN("2/element/76.html","adminState",false,null),new CN("2/element/77.html","serviceState",false,null),new CN("2/element/78.html","operationalState",false,null),new CN("2/element/32.html","serviceTemplateRef",false,null),new CN("2/element/33.html","subscriberRef",false,null),new CN("2/element/18.html","userRefList",false,null),new CN("2/element/17.html","sapRefList",false,null),new CN("2/element/79.html","describedByList",false,null))),new CN("2/complextype/SubscriberType.html","SubscriberType",false,null),new CN("2/complextype/TimePeriodType.html","TimePeriodType",false,new Array(new CN("2/element/99.html","startDateTime",false,null),new CN("2/element/100.html","endDateTime",false,null))),new CN("2/complextype/UserType.html","UserType",false,null)),
					new Array(),
					new Array(new CN("2/element/serviceCatalog.html","serviceCatalog",false,null),new CN("2/element/serviceDefinition.html","serviceDefinition",false,null),new CN("2/element/serviceSpecCharacteristicUseType.html","serviceSpecCharacteristicUseType",false,null),new CN("2/element/serviceSpecCharInUseType.html","serviceSpecCharInUseType",false,null),new CN("2/element/serviceSpecification.html","serviceSpecification",false,null),new CN("2/element/serviceTemplate.html","serviceTemplate",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/sb/xsd/svc/v1"] = "2/index.html";
								   


