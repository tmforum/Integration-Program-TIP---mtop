﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var target = "content";
var xsd_ciFileName = "componentIndex.html";
var xsd_nsFilterFileName = "nsFilter.html";

function CN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function C (attributeList, attributeGroupList,
						simpleTypeList, complexTypeList,
						modelGroupList, elementList, 
						notationList) 
{
	this.attributes = attributeList;
	this.attributegroups = attributeGroupList;
	this.simpletypes = simpleTypeList;
	this.complextypes = complexTypeList;
	this.modelgroups = modelGroupList;
	this.elements = elementList;
	this.notations = notationList;
}

function component_showAllComponents() {
	parent._xsdNsFilter = null;
	parent.index.location.href= "xsd/" + xsd_ciFileName;
}

function component_filterComponents () {
	parent._href = "xsd/" + xsd_ciFileName;
	window.open(xsd_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function component_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href=xsd_ciFileName;	
}

function component_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in componentDB) {
		if (parent._xsdNsFilter == null) {
			if (ns == "http://schemas.xmlsoap.org/soap/encoding/") {
				//NOOP
			} else {
				nsList[i] = ns;
				i++;
			}
		} else {
			nsList[i] = ns; 
			i++;		
		}
	}

	parent._xsdNsFilter = nsList;
}

function component_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	component_outputList (null, components);	
}


function component_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		component_outputList (namespace, list);	
	}
}


function component_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		component_showComponentsNS (nsList, componentList)
	} else {
		component_showComponentsNoNS (nsList, componentList)
	}
}

function component_showAttributes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		attributes [i] = componentDB [nsList[i]].attributes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributes);
}

function component_showAttributeGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var attributegroups = new Array();
	var nss = new Array();		

	for (var i=0; i<nsList.length; i++) {
		attributegroups [i] = componentDB [nsList[i]].attributegroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, attributegroups);
}

function component_showSimpleTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var simpletypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		simpletypes [i] = componentDB [nsList[i]].simpletypes;	
		nss [i] = nsList[i];
	}		

	component_showComponents (nss, simpletypes);
}

function component_showComplexTypes() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var complextypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		complextypes [i] = componentDB [nsList[i]].complextypes;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, complextypes);
}

function component_showElements() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var elements = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		elements [i] = componentDB [nsList[i]].elements;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, elements);
}

function component_showModelGroups() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var modelgroups = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		modelgroups [i] = componentDB [nsList[i]].modelgroups;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, modelgroups);
}

function component_showNotations() {
	if (parent._xsdNsFilter == null) {
		component_setFilterToAll();		
	}
	
	var nsList = parent._xsdNsFilter;
	var notations = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		notations [i] = componentDB [nsList[i]].notations;	
		nss[i] = nsList[i];
	}		

	component_showComponents (nss, notations);

}


function component_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function component_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+component_getNodeText(node)+
			  '" target="'+target+'">'+component_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function component_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+component_getNodeText(node)+
			'" target="'+target+'">'+component_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		component_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function component_outputTree (node) {
	if (node.hasChild == false) {
		component_outputLeaf (node);
	} else {
		component_outputNonLeaf (node);
	}
}

function component_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = componentNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+target+'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		component_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}


var componentDB = new Array();
var componentNSMap = new Array();

componentDB ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("10/complextype/AttributeValueChangeType.html","AttributeValueChangeType",false,new Array(new CN("10/element/13.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/avc/v1"] = "10/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("5/complextype/CommonEventInformationType.html","CommonEventInformationType",false,new Array(new CN("5/element/7.html","notificationId",false,null),new CN("5/element/8.html","sourceTime",false,null),new CN("5/element/9.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("5/element/commonEventInformation.html","commonEventInformation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cei/v1"] = "5/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cocd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("20/complextype/CommonObjectCreateDataType.html","CommonObjectCreateDataType",false,new Array(new CN("20/element/54.html","name",false,null)))),
					new Array(),
					new Array(new CN("20/element/commonObjectCreateData.html","commonObjectCreateData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cocd/v1"] = "20/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("23/complextype/CommonObjectInfoType.html","CommonObjectInfoType",false,new Array(new CN("23/element/55.html","name",false,null),new CN("23/element/64.html","userLabel",false,null),new CN("23/element/65.html","discoveredName",false,null),new CN("23/element/66.html","namingOs",false,null),new CN("23/element/67.html","owner",false,null),new CN("23/element/68.html","aliasNameList",false,null),new CN("23/element/69.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("23/element/commonObjectInfo.html","commonObjectInfo",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/coi/v1"] = "23/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/comd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("16/complextype/CommonObjectModifyDataType.html","CommonObjectModifyDataType",false,null)),
					new Array(),
					new Array(new CN("16/element/commonObjectModifyData.html","commonObjectModifyData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/comd/v1"] = "16/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/cosd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("15/complextype/CommonObjectSetDataType.html","CommonObjectSetDataType",false,new Array(new CN("15/element/15.html","userLabel",false,null),new CN("15/element/16.html","isForceUniqueness",false,null),new CN("15/element/17.html","owner",false,null),new CN("15/element/18.html","aliasNameList",false,null),new CN("15/element/19.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("15/element/commonObjectSetData.html","commonObjectSetData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/cosd/v1"] = "15/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("9/complextype/EventInformationType.html","EventInformationType",false,new Array(new CN("9/element/10.html","objectType",false,null),new CN("9/element/11.html","objectName",false,null),new CN("9/element/12.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/ei/v1"] = "9/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("3/simpletype/DiscoveredNameType.html","DiscoveredNameType",false,null),new CN("3/simpletype/ManufactureDateType.html","ManufactureDateType",false,null),new CN("3/simpletype/NetworkAccessDomainType.html","NetworkAccessDomainType",false,null),new CN("3/simpletype/NotificationIdentifierType.html","NotificationIdentifierType",false,null),new CN("3/simpletype/ObjectEnumType.html","ObjectEnumType",false,null),new CN("3/simpletype/ObjectTypeType.html","ObjectTypeType",false,null),new CN("3/simpletype/OwnerType.html","OwnerType",false,null),new CN("3/simpletype/QueryDialectEnumType.html","QueryDialectEnumType",false,null),new CN("3/simpletype/QueryDialectTypeType.html","QueryDialectTypeType",false,null)),
					new Array(new CN("3/complextype/AliasNameListType.html","AliasNameListType",false,new Array(new CN("3/element/46.html","alias",false,null),new CN("3/element/47.html","alias/aliasName",false,null),new CN("3/element/48.html","alias/aliasValue",false,null))),new CN("3/complextype/AnyListType.html","AnyListType",false,null),new CN("3/complextype/MultiEventInventoryAttributesType.html","MultiEventInventoryAttributesType",false,new Array(new CN("3/element/62.html","neTime",false,null),new CN("3/element/63.html","eventIndication",false,null))),new CN("3/complextype/NameAndAnyValueListType.html","NameAndAnyValueListType",false,new Array(new CN("3/element/73.html","nv",false,null))),new CN("3/complextype/NameAndAnyValueType.html","NameAndAnyValueType",false,new Array(new CN("3/element/74.html","name",false,null))),new CN("3/complextype/NameAndStringValueType.html","NameAndStringValueType",false,new Array(new CN("3/element/75.html","name",false,null),new CN("3/element/76.html","value",false,null))),new CN("3/complextype/NameAndValueStringListType.html","NameAndValueStringListType",false,new Array(new CN("3/element/3.html","nvs",false,null))),new CN("3/complextype/NotificationIdentifierListType.html","NotificationIdentifierListType",false,new Array(new CN("3/element/72.html","notificationId",false,null))),new CN("3/complextype/QueryExpressionType.html","QueryExpressionType",false,null)),
					new Array(),
					new Array(new CN("3/element/nvList.html","nvList",false,null),new CN("3/element/nvsList.html","nvsList",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/gen/v1"] = "3/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("11/complextype/NamingAttributeListType.html","NamingAttributeListType",false,new Array(new CN("11/element/52.html","name",false,null))),new CN("11/complextype/NamingAttributeType.html","NamingAttributeType",false,new Array(new CN("11/element/53.html","rdn",false,null))),new CN("11/complextype/RelativeDistinguishNameType.html","RelativeDistinguishNameType",false,new Array(new CN("11/element/56.html","type",false,null),new CN("11/element/57.html","value",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/nam/v1"] = "11/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("22/complextype/ObjectCreationType.html","ObjectCreationType",false,new Array(new CN("22/element/50.html","object",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/oc/v1"] = "22/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("12/complextype/ObjectDeletionType.html","ObjectDeletionType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odel/v1"] = "12/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("4/complextype/ObjectDiscoveryType.html","ObjectDiscoveryType",false,new Array(new CN("4/element/4.html","discoveredName",false,null),new CN("4/element/5.html","osTime",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/odis/v1"] = "4/index.html";
componentDB ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("17/complextype/StateChangeType.html","StateChangeType",false,new Array(new CN("17/element/20.html","attributeList",false,null)))),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/fmw/xsd/sc/v1"] = "17/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/com/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("7/simpletype/ProtectionSchemeStateEnumType.html","ProtectionSchemeStateEnumType",false,null)),
					new Array(new CN("7/complextype/ProtectionSchemeStateType.html","ProtectionSchemeStateType",false,null)),
					new Array(),
					new Array(),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/com/v1"] = "7/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/crcd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("25/complextype/CommonResourceCreateDataType.html","CommonResourceCreateDataType",false,new Array(new CN("25/element/71.html","networkAccessDomain",false,null)))),
					new Array(),
					new Array(new CN("25/element/commonResourceCreateData.html","commonResourceCreateData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/crcd/v1"] = "25/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/cri/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("24/simpletype/ResourceStateEnumType.html","ResourceStateEnumType",false,null),new CN("24/simpletype/SourceEnumType.html","SourceEnumType",false,null)),
					new Array(new CN("24/complextype/CommonResourceInfoType.html","CommonResourceInfoType",false,new Array(new CN("24/element/58.html","source",false,null),new CN("24/element/59.html","networkAccessDomain",false,null),new CN("24/element/60.html","meiAttributes",false,null),new CN("24/element/61.html","resourceState",false,null))),new CN("24/complextype/ResourceStateType.html","ResourceStateType",false,null),new CN("24/complextype/SourceType.html","SourceType",false,null)),
					new Array(),
					new Array(new CN("24/element/commonResourceInfo.html","commonResourceInfo",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/cri/v1"] = "24/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/crmd/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("14/complextype/CommonResourceModifyDataType.html","CommonResourceModifyDataType",false,new Array(new CN("14/element/14.html","networkAccessDomain",false,null)))),
					new Array(),
					new Array(new CN("14/element/commonResourceModifyData.html","commonResourceModifyData",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/crmd/v1"] = "14/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/itu/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("19/simpletype/M3100.AlarmStatusType.html","M3100.AlarmStatusType",false,null),new CN("19/simpletype/M3100.ArcQIStatusType.html","M3100.ArcQIStatusType",false,null),new CN("19/simpletype/M3100.ArcStateType.html","M3100.ArcStateType",false,null),new CN("19/simpletype/M3100.CircuitPackTypeType.html","M3100.CircuitPackTypeType",false,null),new CN("19/simpletype/M3100.HolderStatusType.html","M3100.HolderStatusType",false,null),new CN("19/simpletype/M3100.NALMQIIntervalType.html","M3100.NALMQIIntervalType",false,null),new CN("19/simpletype/M3100.NALMTIIntervalType.html","M3100.NALMTIIntervalType",false,null),new CN("19/simpletype/X721.AdministrativeStateType.html","X721.AdministrativeStateType",false,null),new CN("19/simpletype/X721.AvailabilityStatusType.html","X721.AvailabilityStatusType",false,null),new CN("19/simpletype/X721.ControlStatusType.html","X721.ControlStatusType",false,null),new CN("19/simpletype/X721.OperationalStateType.html","X721.OperationalStateType",false,null),new CN("19/simpletype/X721.UnkownstatusType.html","X721.UnkownstatusType",false,null),new CN("19/simpletype/X721.UsageStateType.html","X721.UsageStateType",false,null)),
					new Array(new CN("19/complextype/X721.StateType.html","X721.StateType",false,new Array(new CN("19/element/40.html","X721.OperationalState",false,null),new CN("19/element/34.html","X721.AdministrativeState",false,null),new CN("19/element/44.html","X721.UsageState",false,null),new CN("19/element/36.html","X721.AvailabilityStatus",false,null),new CN("19/element/38.html","X721.ControlStatus",false,null),new CN("19/element/30.html","M3100.HolderStatus",false,null),new CN("19/element/23.html","M3100.AlarmStatus",false,null),new CN("19/element/27.html","M3100.ArcState",false,null),new CN("19/element/25.html","M3100.ArcQIStatus",false,null),new CN("19/element/42.html","X721.Unkownstatus",false,null)))),
					new Array(),
					new Array(new CN("19/element/ituParameters.html","ituParameters",false,new Array(new CN("19/element/39.html","x721.OperationalState",false,null),new CN("19/element/33.html","x721.AdministrativeState",false,null),new CN("19/element/43.html","x721.UsageState",false,null),new CN("19/element/35.html","x721.AvailabilityStatus",false,null),new CN("19/element/37.html","x721.ControlStatus",false,null),new CN("19/element/29.html","m3100.HolderStatus",false,null),new CN("19/element/28.html","m3100.CircuitPackType",false,null),new CN("19/element/22.html","m3100.AlarmStatus",false,null),new CN("19/element/26.html","m3100.ArcState",false,null),new CN("19/element/32.html","m3100.NALMTIInterval",false,null),new CN("19/element/31.html","m3100.NALMQIInterval",false,null),new CN("19/element/24.html","m3100.ArcQIStatus",false,null),new CN("19/element/41.html","x721.Unkownstatus",false,null),new CN("19/element/45.html","x721.State",false,null)))),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/itu/v1"] = "19/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/lay/v1"] =  new C (new Array(),
					new Array(),
					new Array(new CN("2/simpletype/LayerRateEnumType.html","LayerRateEnumType",false,null)),
					new Array(new CN("2/complextype/LayerRateListType.html","LayerRateListType",false,new Array(new CN("2/element/77.html","layerRate",false,null))),new CN("2/complextype/LayerRateType.html","LayerRateType",false,null)),
					new Array(),
					new Array(new CN("2/element/layerRateListType.html","layerRateListType",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/lay/v1"] = "2/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/lp/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("1/complextype/LayeredParametersListType.html","LayeredParametersListType",false,null),new CN("1/complextype/LayeredParametersType.html","LayeredParametersType",false,new Array(new CN("1/element/0.html","layerRate",false,null),new CN("1/element/1.html","parameterList",false,null),new CN("1/element/2.html","vendorExtensions",false,null)))),
					new Array(),
					new Array(new CN("1/element/transmissionParameters.html","transmissionParameters",false,null),new CN("1/element/transmissionParametersList.html","transmissionParametersList",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/lp/v1"] = "1/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("8/complextype/ResourceAttributeValueChangeType.html","ResourceAttributeValueChangeType",false,new Array(new CN("8/element/6.html","isEdgePointRelated",false,null)))),
					new Array(),
					new Array(new CN("8/element/resourceAttributeValueChange.html","resourceAttributeValueChange",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscavc/v1"] = "8/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/rscoc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("21/complextype/ResourceObjectCreationType.html","ResourceObjectCreationType",false,new Array(new CN("21/element/49.html","isEdgePointRelated",false,null)))),
					new Array(),
					new Array(new CN("21/element/resourceObjectCreation.html","resourceObjectCreation",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscoc/v1"] = "21/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("13/complextype/ResourceObjectDeletionType.html","ResourceObjectDeletionType",false,new Array(new CN("13/element/70.html","isEdgePointRelated",false,null)))),
					new Array(),
					new Array(new CN("13/element/resourceObjectDeletion.html","resourceObjectDeletion",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscodel/v1"] = "13/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("6/complextype/ResourceObjectDiscoveryType.html","ResourceObjectDiscoveryType",false,new Array(new CN("6/element/51.html","isEdgePointRelated",false,null)))),
					new Array(),
					new Array(new CN("6/element/resourceObjectDiscovery.html","resourceObjectDiscovery",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscodis/v1"] = "6/index.html";
componentDB ["http://www.tmforum.org/mtop/nrb/xsd/rscsc/v1"] =  new C (new Array(),
					new Array(),
					new Array(),
					new Array(new CN("18/complextype/ResourceStateChangeType.html","ResourceStateChangeType",false,new Array(new CN("18/element/21.html","isEdgePointRelated",false,null)))),
					new Array(),
					new Array(new CN("18/element/resourceStateChange.html","resourceStateChange",false,null)),
					new Array());

componentNSMap ["http://www.tmforum.org/mtop/nrb/xsd/rscsc/v1"] = "18/index.html";
								   


