﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/rpm/wsdl/pmc/v1-0"] =  new WC (
					new Array(new WCN("26/service/PerformanceManagementControlHttp.html","PerformanceManagementControlHttp",false,null),new WCN("26/service/PerformanceManagementControlJms.html","PerformanceManagementControlJms",false,null)),
					new Array(new WCN("26/message/clearPerformanceMonitoringDataException.html","clearPerformanceMonitoringDataException",false,null),new WCN("26/message/clearPerformanceMonitoringDataRequest.html","clearPerformanceMonitoringDataRequest",false,null),new WCN("26/message/clearPerformanceMonitoringDataResponse.html","clearPerformanceMonitoringDataResponse",false,null),new WCN("26/message/disablePerformanceMonitoringDataException.html","disablePerformanceMonitoringDataException",false,null),new WCN("26/message/disablePerformanceMonitoringDataRequest.html","disablePerformanceMonitoringDataRequest",false,null),new WCN("26/message/disablePerformanceMonitoringDataResponse.html","disablePerformanceMonitoringDataResponse",false,null),new WCN("26/message/enablePerformanceMonitoringDataException.html","enablePerformanceMonitoringDataException",false,null),new WCN("26/message/enablePerformanceMonitoringDataRequest.html","enablePerformanceMonitoringDataRequest",false,null),new WCN("26/message/enablePerformanceMonitoringDataResponse.html","enablePerformanceMonitoringDataResponse",false,null)),
					new Array(new WCN("26/porttype/PerformanceManagementControl.html","PerformanceManagementControl",false,new Array(new WCN("26/operation/clearPerformanceMonitoringData_0.html","clearPerformanceMonitoringData",false,null),new WCN("26/operation/disablePerformanceMonitoringData_1.html","disablePerformanceMonitoringData",false,null),new WCN("26/operation/enablePerformanceMonitoringData_2.html","enablePerformanceMonitoringData",false,null)))),
					new Array(new WCN("26/binding/PerformanceManagementControlSoapHttpBinding.html","PerformanceManagementControlSoapHttpBinding",false,new Array(new WCN("26/operation/clearPerformanceMonitoringData_0.html","clearPerformanceMonitoringData",false,null),new WCN("26/operation/disablePerformanceMonitoringData_1.html","disablePerformanceMonitoringData",false,null),new WCN("26/operation/enablePerformanceMonitoringData_2.html","enablePerformanceMonitoringData",false,null))),new WCN("26/binding/PerformanceManagementControlSoapJmsBinding.html","PerformanceManagementControlSoapJmsBinding",false,new Array(new WCN("26/operation/clearPerformanceMonitoringData_0.html","clearPerformanceMonitoringData",false,null),new WCN("26/operation/disablePerformanceMonitoringData_1.html","disablePerformanceMonitoringData",false,null),new WCN("26/operation/enablePerformanceMonitoringData_2.html","enablePerformanceMonitoringData",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rpm/wsdl/pmc/v1-0"] = "26/index.html";
wcDB ["http://www.tmforum.org/mtop/rpm/wsdl/pmr/v1-0"] =  new WC (
					new Array(new WCN("28/service/PerformanceManagementRetrievalHttp.html","PerformanceManagementRetrievalHttp",false,null),new WCN("28/service/PerformanceManagementRetrievalJms.html","PerformanceManagementRetrievalJms",false,null)),
					new Array(new WCN("28/message/getAllCurrentPerformanceMonitoringDataException.html","getAllCurrentPerformanceMonitoringDataException",false,null),new WCN("28/message/getAllCurrentPerformanceMonitoringDataRequest.html","getAllCurrentPerformanceMonitoringDataRequest",false,null),new WCN("28/message/getAllCurrentPerformanceMonitoringDataResponse.html","getAllCurrentPerformanceMonitoringDataResponse",false,null),new WCN("28/message/getAllPerformanceMonitoringPointNamesException.html","getAllPerformanceMonitoringPointNamesException",false,null),new WCN("28/message/getAllPerformanceMonitoringPointNamesRequest.html","getAllPerformanceMonitoringPointNamesRequest",false,null),new WCN("28/message/getAllPerformanceMonitoringPointNamesResponse.html","getAllPerformanceMonitoringPointNamesResponse",false,null),new WCN("28/message/getAllPerformanceMonitoringPointsException.html","getAllPerformanceMonitoringPointsException",false,null),new WCN("28/message/getAllPerformanceMonitoringPointsRequest.html","getAllPerformanceMonitoringPointsRequest",false,null),new WCN("28/message/getAllPerformanceMonitoringPointsResponse.html","getAllPerformanceMonitoringPointsResponse",false,null),new WCN("28/message/getHistoryPerformanceMonitoringDataException.html","getHistoryPerformanceMonitoringDataException",false,null),new WCN("28/message/getHistoryPerformanceMonitoringDataRequest.html","getHistoryPerformanceMonitoringDataRequest",false,null),new WCN("28/message/getHistoryPerformanceMonitoringDataResponse.html","getHistoryPerformanceMonitoringDataResponse",false,null),new WCN("28/message/getHoldingTimeException.html","getHoldingTimeException",false,null),new WCN("28/message/getHoldingTimeRequest.html","getHoldingTimeRequest",false,null),new WCN("28/message/getHoldingTimeResponse.html","getHoldingTimeResponse",false,null),new WCN("28/message/getMePerformanceMonitoringCapabilitiesException.html","getMePerformanceMonitoringCapabilitiesException",false,null),new WCN("28/message/getMePerformanceMonitoringCapabilitiesRequest.html","getMePerformanceMonitoringCapabilitiesRequest",false,null),new WCN("28/message/getMePerformanceMonitoringCapabilitiesResponse.html","getMePerformanceMonitoringCapabilitiesResponse",false,null),new WCN("28/message/getPerformanceMonitoringDataIteratorException.html","getPerformanceMonitoringDataIteratorException",false,null),new WCN("28/message/getPerformanceMonitoringDataIteratorRequest.html","getPerformanceMonitoringDataIteratorRequest",false,null),new WCN("28/message/getPerformanceMonitoringDataIteratorResponse.html","getPerformanceMonitoringDataIteratorResponse",false,null),new WCN("28/message/getPerformanceMonitoringPointNamesIteratorException.html","getPerformanceMonitoringPointNamesIteratorException",false,null),new WCN("28/message/getPerformanceMonitoringPointNamesIteratorRequest.html","getPerformanceMonitoringPointNamesIteratorRequest",false,null),new WCN("28/message/getPerformanceMonitoringPointNamesIteratorResponse.html","getPerformanceMonitoringPointNamesIteratorResponse",false,null),new WCN("28/message/getPerformanceMonitoringPointsIteratorException.html","getPerformanceMonitoringPointsIteratorException",false,null),new WCN("28/message/getPerformanceMonitoringPointsIteratorRequest.html","getPerformanceMonitoringPointsIteratorRequest",false,null),new WCN("28/message/getPerformanceMonitoringPointsIteratorResponse.html","getPerformanceMonitoringPointsIteratorResponse",false,null),new WCN("28/message/getProfileAssociatedTerminationPointsException.html","getProfileAssociatedTerminationPointsException",false,null),new WCN("28/message/getProfileAssociatedTerminationPointsRequest.html","getProfileAssociatedTerminationPointsRequest",false,null),new WCN("28/message/getProfileAssociatedTerminationPointsResponse.html","getProfileAssociatedTerminationPointsResponse",false,null)),
					new Array(new WCN("28/porttype/PerformanceManagementRetrieval.html","PerformanceManagementRetrieval",false,new Array(new WCN("28/operation/getAllCurrentPerformanceMonitoringData_16.html","getAllCurrentPerformanceMonitoringData",false,null),new WCN("28/operation/getAllPerformanceMonitoringPointNames_17.html","getAllPerformanceMonitoringPointNames",false,null),new WCN("28/operation/getAllPerformanceMonitoringPoints_18.html","getAllPerformanceMonitoringPoints",false,null),new WCN("28/operation/getHistoryPerformanceMonitoringData_19.html","getHistoryPerformanceMonitoringData",false,null),new WCN("28/operation/getHoldingTime_20.html","getHoldingTime",false,null),new WCN("28/operation/getMePerformanceMonitoringCapabilities_21.html","getMePerformanceMonitoringCapabilities",false,null),new WCN("28/operation/getPerformanceMonitoringDataIterator_23.html","getPerformanceMonitoringDataIterator",false,null),new WCN("28/operation/getPerformanceMonitoringPointNamesIterator_24.html","getPerformanceMonitoringPointNamesIterator",false,null),new WCN("28/operation/getPerformanceMonitoringPointsIterator_25.html","getPerformanceMonitoringPointsIterator",false,null),new WCN("28/operation/getProfileAssociatedTerminationPoints_22.html","getProfileAssociatedTerminationPoints",false,null)))),
					new Array(new WCN("28/binding/PerformanceManagementRetrievalSoapHttpBinding.html","PerformanceManagementRetrievalSoapHttpBinding",false,new Array(new WCN("28/operation/getAllCurrentPerformanceMonitoringData_16.html","getAllCurrentPerformanceMonitoringData",false,null),new WCN("28/operation/getAllPerformanceMonitoringPointNames_17.html","getAllPerformanceMonitoringPointNames",false,null),new WCN("28/operation/getAllPerformanceMonitoringPoints_18.html","getAllPerformanceMonitoringPoints",false,null),new WCN("28/operation/getHistoryPerformanceMonitoringData_19.html","getHistoryPerformanceMonitoringData",false,null),new WCN("28/operation/getHoldingTime_20.html","getHoldingTime",false,null),new WCN("28/operation/getMePerformanceMonitoringCapabilities_21.html","getMePerformanceMonitoringCapabilities",false,null),new WCN("28/operation/getPerformanceMonitoringDataIterator_23.html","getPerformanceMonitoringDataIterator",false,null),new WCN("28/operation/getPerformanceMonitoringPointNamesIterator_24.html","getPerformanceMonitoringPointNamesIterator",false,null),new WCN("28/operation/getPerformanceMonitoringPointsIterator_25.html","getPerformanceMonitoringPointsIterator",false,null),new WCN("28/operation/getProfileAssociatedTerminationPoints_22.html","getProfileAssociatedTerminationPoints",false,null))),new WCN("28/binding/PerformanceManagementRetrievalSoapJmsBinding.html","PerformanceManagementRetrievalSoapJmsBinding",false,new Array(new WCN("28/operation/getAllCurrentPerformanceMonitoringData_16.html","getAllCurrentPerformanceMonitoringData",false,null),new WCN("28/operation/getAllPerformanceMonitoringPointNames_17.html","getAllPerformanceMonitoringPointNames",false,null),new WCN("28/operation/getAllPerformanceMonitoringPoints_18.html","getAllPerformanceMonitoringPoints",false,null),new WCN("28/operation/getHistoryPerformanceMonitoringData_19.html","getHistoryPerformanceMonitoringData",false,null),new WCN("28/operation/getHoldingTime_20.html","getHoldingTime",false,null),new WCN("28/operation/getMePerformanceMonitoringCapabilities_21.html","getMePerformanceMonitoringCapabilities",false,null),new WCN("28/operation/getPerformanceMonitoringDataIterator_23.html","getPerformanceMonitoringDataIterator",false,null),new WCN("28/operation/getPerformanceMonitoringPointNamesIterator_24.html","getPerformanceMonitoringPointNamesIterator",false,null),new WCN("28/operation/getPerformanceMonitoringPointsIterator_25.html","getPerformanceMonitoringPointsIterator",false,null),new WCN("28/operation/getProfileAssociatedTerminationPoints_22.html","getProfileAssociatedTerminationPoints",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rpm/wsdl/pmr/v1-0"] = "28/index.html";
wcDB ["http://www.tmforum.org/mtop/rpm/wsdl/tcac/v1-0"] =  new WC (
					new Array(new WCN("27/service/ThresholdCrossingAlertControlHttp.html","ThresholdCrossingAlertControlHttp",false,null),new WCN("27/service/ThresholdCrossingAlertControlJms.html","ThresholdCrossingAlertControlJms",false,null)),
					new Array(new WCN("27/message/createTcaParameterProfileException.html","createTcaParameterProfileException",false,null),new WCN("27/message/createTcaParameterProfileRequest.html","createTcaParameterProfileRequest",false,null),new WCN("27/message/createTcaParameterProfileResponse.html","createTcaParameterProfileResponse",false,null),new WCN("27/message/deleteTcaParameterProfileException.html","deleteTcaParameterProfileException",false,null),new WCN("27/message/deleteTcaParameterProfileRequest.html","deleteTcaParameterProfileRequest",false,null),new WCN("27/message/deleteTcaParameterProfileResponse.html","deleteTcaParameterProfileResponse",false,null),new WCN("27/message/disableThresholdCrossingAlertException.html","disableThresholdCrossingAlertException",false,null),new WCN("27/message/disableThresholdCrossingAlertRequest.html","disableThresholdCrossingAlertRequest",false,null),new WCN("27/message/disableThresholdCrossingAlertResponse.html","disableThresholdCrossingAlertResponse",false,null),new WCN("27/message/enableThresholdCrossingAlertException.html","enableThresholdCrossingAlertException",false,null),new WCN("27/message/enableThresholdCrossingAlertRequest.html","enableThresholdCrossingAlertRequest",false,null),new WCN("27/message/enableThresholdCrossingAlertResponse.html","enableThresholdCrossingAlertResponse",false,null),new WCN("27/message/getAllTcaParameterProfileNamesException.html","getAllTcaParameterProfileNamesException",false,null),new WCN("27/message/getAllTcaParameterProfileNamesRequest.html","getAllTcaParameterProfileNamesRequest",false,null),new WCN("27/message/getAllTcaParameterProfileNamesResponse.html","getAllTcaParameterProfileNamesResponse",false,null),new WCN("27/message/getAllTcaParameterProfilesException.html","getAllTcaParameterProfilesException",false,null),new WCN("27/message/getAllTcaParameterProfilesRequest.html","getAllTcaParameterProfilesRequest",false,null),new WCN("27/message/getAllTcaParameterProfilesResponse.html","getAllTcaParameterProfilesResponse",false,null),new WCN("27/message/getTcaParameterProfileException.html","getTcaParameterProfileException",false,null),new WCN("27/message/getTcaParameterProfileNamesIteratorException.html","getTcaParameterProfileNamesIteratorException",false,null),new WCN("27/message/getTcaParameterProfileNamesIteratorRequest.html","getTcaParameterProfileNamesIteratorRequest",false,null),new WCN("27/message/getTcaParameterProfileNamesIteratorResponse.html","getTcaParameterProfileNamesIteratorResponse",false,null),new WCN("27/message/getTcaParameterProfileRequest.html","getTcaParameterProfileRequest",false,null),new WCN("27/message/getTcaParameterProfileResponse.html","getTcaParameterProfileResponse",false,null),new WCN("27/message/getTcaParameterProfilesIteratorException.html","getTcaParameterProfilesIteratorException",false,null),new WCN("27/message/getTcaParameterProfilesIteratorRequest.html","getTcaParameterProfilesIteratorRequest",false,null),new WCN("27/message/getTcaParameterProfilesIteratorResponse.html","getTcaParameterProfilesIteratorResponse",false,null),new WCN("27/message/getTcaTpParameterException.html","getTcaTpParameterException",false,null),new WCN("27/message/getTcaTpParameterRequest.html","getTcaTpParameterRequest",false,null),new WCN("27/message/getTcaTpParameterResponse.html","getTcaTpParameterResponse",false,null),new WCN("27/message/setTcaParameterProfileException.html","setTcaParameterProfileException",false,null),new WCN("27/message/setTcaParameterProfilePointerException.html","setTcaParameterProfilePointerException",false,null),new WCN("27/message/setTcaParameterProfilePointerRequest.html","setTcaParameterProfilePointerRequest",false,null),new WCN("27/message/setTcaParameterProfilePointerResponse.html","setTcaParameterProfilePointerResponse",false,null),new WCN("27/message/setTcaParameterProfileRequest.html","setTcaParameterProfileRequest",false,null),new WCN("27/message/setTcaParameterProfileResponse.html","setTcaParameterProfileResponse",false,null),new WCN("27/message/setTcaTpParameterException.html","setTcaTpParameterException",false,null),new WCN("27/message/setTcaTpParameterRequest.html","setTcaTpParameterRequest",false,null),new WCN("27/message/setTcaTpParameterResponse.html","setTcaTpParameterResponse",false,null)),
					new Array(new WCN("27/porttype/ThresholdCrossingAlertControl.html","ThresholdCrossingAlertControl",false,new Array(new WCN("27/operation/createTcaParameterProfile_3.html","createTcaParameterProfile",false,null),new WCN("27/operation/deleteTcaParameterProfile_4.html","deleteTcaParameterProfile",false,null),new WCN("27/operation/disableThresholdCrossingAlert_5.html","disableThresholdCrossingAlert",false,null),new WCN("27/operation/enableThresholdCrossingAlert_6.html","enableThresholdCrossingAlert",false,null),new WCN("27/operation/getAllTcaParameterProfileNames_7.html","getAllTcaParameterProfileNames",false,null),new WCN("27/operation/getAllTcaParameterProfiles_8.html","getAllTcaParameterProfiles",false,null),new WCN("27/operation/getTcaParameterProfile_9.html","getTcaParameterProfile",false,null),new WCN("27/operation/getTcaParameterProfileNamesIterator_14.html","getTcaParameterProfileNamesIterator",false,null),new WCN("27/operation/getTcaParameterProfilesIterator_15.html","getTcaParameterProfilesIterator",false,null),new WCN("27/operation/getTcaTpParameter_10.html","getTcaTpParameter",false,null),new WCN("27/operation/setTcaParameterProfile_11.html","setTcaParameterProfile",false,null),new WCN("27/operation/setTcaParameterProfilePointer_12.html","setTcaParameterProfilePointer",false,null),new WCN("27/operation/setTcaTpParameter_13.html","setTcaTpParameter",false,null)))),
					new Array(new WCN("27/binding/ThresholdCrossingAlertControlSoapHttpBinding.html","ThresholdCrossingAlertControlSoapHttpBinding",false,new Array(new WCN("27/operation/createTcaParameterProfile_3.html","createTcaParameterProfile",false,null),new WCN("27/operation/deleteTcaParameterProfile_4.html","deleteTcaParameterProfile",false,null),new WCN("27/operation/disableThresholdCrossingAlert_5.html","disableThresholdCrossingAlert",false,null),new WCN("27/operation/enableThresholdCrossingAlert_6.html","enableThresholdCrossingAlert",false,null),new WCN("27/operation/getAllTcaParameterProfileNames_7.html","getAllTcaParameterProfileNames",false,null),new WCN("27/operation/getAllTcaParameterProfiles_8.html","getAllTcaParameterProfiles",false,null),new WCN("27/operation/getTcaParameterProfile_9.html","getTcaParameterProfile",false,null),new WCN("27/operation/getTcaParameterProfileNamesIterator_14.html","getTcaParameterProfileNamesIterator",false,null),new WCN("27/operation/getTcaParameterProfilesIterator_15.html","getTcaParameterProfilesIterator",false,null),new WCN("27/operation/getTcaTpParameter_10.html","getTcaTpParameter",false,null),new WCN("27/operation/setTcaParameterProfile_11.html","setTcaParameterProfile",false,null),new WCN("27/operation/setTcaParameterProfilePointer_12.html","setTcaParameterProfilePointer",false,null),new WCN("27/operation/setTcaTpParameter_13.html","setTcaTpParameter",false,null))),new WCN("27/binding/ThresholdCrossingAlertControlSoapJmsBinding.html","ThresholdCrossingAlertControlSoapJmsBinding",false,new Array(new WCN("27/operation/createTcaParameterProfile_3.html","createTcaParameterProfile",false,null),new WCN("27/operation/deleteTcaParameterProfile_4.html","deleteTcaParameterProfile",false,null),new WCN("27/operation/disableThresholdCrossingAlert_5.html","disableThresholdCrossingAlert",false,null),new WCN("27/operation/enableThresholdCrossingAlert_6.html","enableThresholdCrossingAlert",false,null),new WCN("27/operation/getAllTcaParameterProfileNames_7.html","getAllTcaParameterProfileNames",false,null),new WCN("27/operation/getAllTcaParameterProfiles_8.html","getAllTcaParameterProfiles",false,null),new WCN("27/operation/getTcaParameterProfile_9.html","getTcaParameterProfile",false,null),new WCN("27/operation/getTcaParameterProfileNamesIterator_14.html","getTcaParameterProfileNamesIterator",false,null),new WCN("27/operation/getTcaParameterProfilesIterator_15.html","getTcaParameterProfilesIterator",false,null),new WCN("27/operation/getTcaTpParameter_10.html","getTcaTpParameter",false,null),new WCN("27/operation/setTcaParameterProfile_11.html","setTcaParameterProfile",false,null),new WCN("27/operation/setTcaParameterProfilePointer_12.html","setTcaParameterProfilePointer",false,null),new WCN("27/operation/setTcaTpParameter_13.html","setTcaTpParameter",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/rpm/wsdl/tcac/v1-0"] = "27/index.html";
