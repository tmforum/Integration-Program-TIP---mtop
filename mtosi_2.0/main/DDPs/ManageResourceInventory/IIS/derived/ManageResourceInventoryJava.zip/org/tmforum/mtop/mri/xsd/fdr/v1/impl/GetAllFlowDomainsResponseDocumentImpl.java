/*
 * An XML document type.
 * Localname: getAllFlowDomainsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllFlowDomainsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFlowDomainsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument
{
    
    public GetAllFlowDomainsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFLOWDOMAINSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllFlowDomainsResponse");
    
    
    /**
     * Gets the "getAllFlowDomainsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse getGetAllFlowDomainsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse)get_store().find_element_user(GETALLFLOWDOMAINSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFlowDomainsResponse" element
     */
    public void setGetAllFlowDomainsResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse getAllFlowDomainsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse)get_store().find_element_user(GETALLFLOWDOMAINSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse)get_store().add_element_user(GETALLFLOWDOMAINSRESPONSE$0);
            }
            target.set(getAllFlowDomainsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFlowDomainsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse addNewGetAllFlowDomainsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse)get_store().add_element_user(GETALLFLOWDOMAINSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAllFlowDomainsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFlowDomainsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFlowDomainsResponseDocument.GetAllFlowDomainsResponse
    {
        
        public GetAllFlowDomainsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FLOWDOMAINS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "flowDomains");
        
        
        /**
         * Gets the "flowDomains" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FdListType getFlowDomains()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().find_element_user(FLOWDOMAINS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "flowDomains" element
         */
        public boolean isSetFlowDomains()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FLOWDOMAINS$0) != 0;
            }
        }
        
        /**
         * Sets the "flowDomains" element
         */
        public void setFlowDomains(org.tmforum.mtop.nrf.xsd.fd.v1.FdListType flowDomains)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().find_element_user(FLOWDOMAINS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().add_element_user(FLOWDOMAINS$0);
                }
                target.set(flowDomains);
            }
        }
        
        /**
         * Appends and returns a new empty "flowDomains" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FdListType addNewFlowDomains()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().add_element_user(FLOWDOMAINS$0);
                return target;
            }
        }
        
        /**
         * Unsets the "flowDomains" element
         */
        public void unsetFlowDomains()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FLOWDOMAINS$0, 0);
            }
        }
    }
}
