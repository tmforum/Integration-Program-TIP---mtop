/*
 * An XML document type.
 * Localname: getFlowDomainResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument
{
    
    public GetFlowDomainResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainResponse");
    
    
    /**
     * Gets the "getFlowDomainResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse getGetFlowDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse)get_store().find_element_user(GETFLOWDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainResponse" element
     */
    public void setGetFlowDomainResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse getFlowDomainResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse)get_store().find_element_user(GETFLOWDOMAINRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse)get_store().add_element_user(GETFLOWDOMAINRESPONSE$0);
            }
            target.set(getFlowDomainResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse addNewGetFlowDomainResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse)get_store().add_element_user(GETFLOWDOMAINRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainResponseDocument.GetFlowDomainResponse
    {
        
        public GetFlowDomainResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FLOWDOMAIN$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "flowDomain");
        
        
        /**
         * Gets the "flowDomain" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType getFlowDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FLOWDOMAIN$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "flowDomain" element
         */
        public boolean isSetFlowDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FLOWDOMAIN$0) != 0;
            }
        }
        
        /**
         * Sets the "flowDomain" element
         */
        public void setFlowDomain(org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType flowDomain)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FLOWDOMAIN$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FLOWDOMAIN$0);
                }
                target.set(flowDomain);
            }
        }
        
        /**
         * Appends and returns a new empty "flowDomain" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType addNewFlowDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FLOWDOMAIN$0);
                return target;
            }
        }
        
        /**
         * Unsets the "flowDomain" element
         */
        public void unsetFlowDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FLOWDOMAIN$0, 0);
            }
        }
    }
}
