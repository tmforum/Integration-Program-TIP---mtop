/*
 * An XML document type.
 * Localname: getSubnetworkConnectionsIteratorException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsIteratorExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSubnetworkConnectionsIteratorException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSubnetworkConnectionsIteratorExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSubnetworkConnectionsIteratorExceptionDocument
{
    
    public GetSubnetworkConnectionsIteratorExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUBNETWORKCONNECTIONSITERATOREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSubnetworkConnectionsIteratorException");
    
    
    /**
     * Gets the "getSubnetworkConnectionsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getGetSubnetworkConnectionsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETSUBNETWORKCONNECTIONSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSubnetworkConnectionsIteratorException" element
     */
    public void setGetSubnetworkConnectionsIteratorException(org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType getSubnetworkConnectionsIteratorException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().find_element_user(GETSUBNETWORKCONNECTIONSITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETSUBNETWORKCONNECTIONSITERATOREXCEPTION$0);
            }
            target.set(getSubnetworkConnectionsIteratorException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSubnetworkConnectionsIteratorException" element
     */
    public org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType addNewGetSubnetworkConnectionsIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.msg.v1.GetAllDataIteratorExceptionType)get_store().add_element_user(GETSUBNETWORKCONNECTIONSITERATOREXCEPTION$0);
            return target;
        }
    }
}
