/*
 * XML Type:  updateInventoryRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/invu/v1
 * Java type: org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.invu.v1.impl;
/**
 * An XML updateInventoryRequest(@http://www.tmforum.org/mtop/mri/xsd/invu/v1).
 *
 * This is a complex type.
 */
public class UpdateInventoryRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest
{
    
    public UpdateInventoryRequestImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName INVENTORYUPDATE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "inventoryUpdate");
    private static final javax.xml.namespace.QName EFFORTMODE$2 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "effortMode");
    private static final javax.xml.namespace.QName INTEGRATIONMODE$4 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "integrationMode");
    
    
    /**
     * Gets the "inventoryUpdate" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType getInventoryUpdate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType)get_store().find_element_user(INVENTORYUPDATE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "inventoryUpdate" element
     */
    public boolean isSetInventoryUpdate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INVENTORYUPDATE$0) != 0;
        }
    }
    
    /**
     * Sets the "inventoryUpdate" element
     */
    public void setInventoryUpdate(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType inventoryUpdate)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType)get_store().find_element_user(INVENTORYUPDATE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType)get_store().add_element_user(INVENTORYUPDATE$0);
            }
            target.set(inventoryUpdate);
        }
    }
    
    /**
     * Appends and returns a new empty "inventoryUpdate" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType addNewInventoryUpdate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType)get_store().add_element_user(INVENTORYUPDATE$0);
            return target;
        }
    }
    
    /**
     * Unsets the "inventoryUpdate" element
     */
    public void unsetInventoryUpdate()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INVENTORYUPDATE$0, 0);
        }
    }
    
    /**
     * Gets the "effortMode" element
     */
    public org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType.Enum getEffortMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EFFORTMODE$2, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "effortMode" element
     */
    public org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType xgetEffortMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType target = null;
            target = (org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType)get_store().find_element_user(EFFORTMODE$2, 0);
            return target;
        }
    }
    
    /**
     * True if has "effortMode" element
     */
    public boolean isSetEffortMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(EFFORTMODE$2) != 0;
        }
    }
    
    /**
     * Sets the "effortMode" element
     */
    public void setEffortMode(org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType.Enum effortMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(EFFORTMODE$2, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(EFFORTMODE$2);
            }
            target.setEnumValue(effortMode);
        }
    }
    
    /**
     * Sets (as xml) the "effortMode" element
     */
    public void xsetEffortMode(org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType effortMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType target = null;
            target = (org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType)get_store().find_element_user(EFFORTMODE$2, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType)get_store().add_element_user(EFFORTMODE$2);
            }
            target.set(effortMode);
        }
    }
    
    /**
     * Unsets the "effortMode" element
     */
    public void unsetEffortMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(EFFORTMODE$2, 0);
        }
    }
    
    /**
     * Gets the "integrationMode" element
     */
    public org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType.Enum getIntegrationMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTEGRATIONMODE$4, 0);
            if (target == null)
            {
                return null;
            }
            return (org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType.Enum)target.getEnumValue();
        }
    }
    
    /**
     * Gets (as xml) the "integrationMode" element
     */
    public org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType xgetIntegrationMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType target = null;
            target = (org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType)get_store().find_element_user(INTEGRATIONMODE$4, 0);
            return target;
        }
    }
    
    /**
     * True if has "integrationMode" element
     */
    public boolean isSetIntegrationMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(INTEGRATIONMODE$4) != 0;
        }
    }
    
    /**
     * Sets the "integrationMode" element
     */
    public void setIntegrationMode(org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType.Enum integrationMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.apache.xmlbeans.SimpleValue target = null;
            target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(INTEGRATIONMODE$4, 0);
            if (target == null)
            {
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(INTEGRATIONMODE$4);
            }
            target.setEnumValue(integrationMode);
        }
    }
    
    /**
     * Sets (as xml) the "integrationMode" element
     */
    public void xsetIntegrationMode(org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType integrationMode)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType target = null;
            target = (org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType)get_store().find_element_user(INTEGRATIONMODE$4, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType)get_store().add_element_user(INTEGRATIONMODE$4);
            }
            target.set(integrationMode);
        }
    }
    
    /**
     * Unsets the "integrationMode" element
     */
    public void unsetIntegrationMode()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(INTEGRATIONMODE$4, 0);
        }
    }
}
