/*
 * An XML document type.
 * Localname: getSncResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSncResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSncResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument
{
    
    public GetSncResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSNCRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSncResponse");
    
    
    /**
     * Gets the "getSncResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse getGetSncResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse)get_store().find_element_user(GETSNCRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSncResponse" element
     */
    public void setGetSncResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse getSncResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse)get_store().find_element_user(GETSNCRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse)get_store().add_element_user(GETSNCRESPONSE$0);
            }
            target.set(getSncResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getSncResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse addNewGetSncResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse)get_store().add_element_user(GETSNCRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getSncResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetSncResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncResponseDocument.GetSncResponse
    {
        
        public GetSncResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName SNC$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "snc");
        
        
        /**
         * Gets the "snc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType getSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNC$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "snc" element
         */
        public boolean isSetSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(SNC$0) != 0;
            }
        }
        
        /**
         * Sets the "snc" element
         */
        public void setSnc(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType snc)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().find_element_user(SNC$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNC$0);
                }
                target.set(snc);
            }
        }
        
        /**
         * Appends and returns a new empty "snc" element
         */
        public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType addNewSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType target = null;
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionType)get_store().add_element_user(SNC$0);
                return target;
            }
        }
        
        /**
         * Unsets the "snc" element
         */
        public void unsetSnc()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(SNC$0, 0);
            }
        }
    }
}
