/*
 * XML Type:  MultiEventInventoryType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mei/v1
 * Java type: org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mei.v1.impl;
/**
 * An XML MultiEventInventoryType(@http://www.tmforum.org/mtop/mri/xsd/mei/v1).
 *
 * This is a complex type.
 */
public class MultiEventInventoryTypeImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoTypeImpl implements org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType
{
    
    public MultiEventInventoryTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName EVENTS$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mei/v1", "events");
    
    
    /**
     * Gets the "events" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType getEvents()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType)get_store().find_element_user(EVENTS$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "events" element
     */
    public void setEvents(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType events)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType)get_store().find_element_user(EVENTS$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType)get_store().add_element_user(EVENTS$0);
            }
            target.set(events);
        }
    }
    
    /**
     * Appends and returns a new empty "events" element
     */
    public org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType addNewEvents()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType target = null;
            target = (org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType)get_store().add_element_user(EVENTS$0);
            return target;
        }
    }
}
