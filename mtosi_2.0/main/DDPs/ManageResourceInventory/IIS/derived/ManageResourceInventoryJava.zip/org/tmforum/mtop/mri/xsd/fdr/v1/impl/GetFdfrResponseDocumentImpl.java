/*
 * An XML document type.
 * Localname: getFdfrResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument
{
    
    public GetFdfrResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrResponse");
    
    
    /**
     * Gets the "getFdfrResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse getGetFdfrResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse)get_store().find_element_user(GETFDFRRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrResponse" element
     */
    public void setGetFdfrResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse getFdfrResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse)get_store().find_element_user(GETFDFRRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse)get_store().add_element_user(GETFDFRRESPONSE$0);
            }
            target.set(getFdfrResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse addNewGetFdfrResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse)get_store().add_element_user(GETFDFRRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFdfrResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrResponseDocument.GetFdfrResponse
    {
        
        public GetFdfrResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFR$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfr");
        
        
        /**
         * Gets the "fdfr" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType getFdfr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().find_element_user(FDFR$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fdfr" element
         */
        public boolean isSetFdfr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDFR$0) != 0;
            }
        }
        
        /**
         * Sets the "fdfr" element
         */
        public void setFdfr(org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType fdfr)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().find_element_user(FDFR$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().add_element_user(FDFR$0);
                }
                target.set(fdfr);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfr" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType addNewFdfr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FlowDomainFragmentType)get_store().add_element_user(FDFR$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fdfr" element
         */
        public void unsetFdfr()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDFR$0, 0);
            }
        }
    }
}
