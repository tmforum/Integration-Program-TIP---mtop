/*
 * An XML document type.
 * Localname: getAssociatingFdRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssociatingFdRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssociatingFdRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument
{
    
    public GetAssociatingFdRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSOCIATINGFDREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssociatingFdRequest");
    
    
    /**
     * Gets the "getAssociatingFdRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest getGetAssociatingFdRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest)get_store().find_element_user(GETASSOCIATINGFDREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssociatingFdRequest" element
     */
    public void setGetAssociatingFdRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest getAssociatingFdRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest)get_store().find_element_user(GETASSOCIATINGFDREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest)get_store().add_element_user(GETASSOCIATINGFDREQUEST$0);
            }
            target.set(getAssociatingFdRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssociatingFdRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest addNewGetAssociatingFdRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest)get_store().add_element_user(GETASSOCIATINGFDREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAssociatingFdRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssociatingFdRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdRequestDocument.GetAssociatingFdRequest
    {
        
        public GetAssociatingFdRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfdName");
        
        
        /**
         * Gets the "mfdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMfdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MFDNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "mfdName" element
         */
        public void setMfdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType mfdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MFDNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MFDNAME$0);
                }
                target.set(mfdName);
            }
        }
        
        /**
         * Appends and returns a new empty "mfdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMfdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MFDNAME$0);
                return target;
            }
        }
    }
}
