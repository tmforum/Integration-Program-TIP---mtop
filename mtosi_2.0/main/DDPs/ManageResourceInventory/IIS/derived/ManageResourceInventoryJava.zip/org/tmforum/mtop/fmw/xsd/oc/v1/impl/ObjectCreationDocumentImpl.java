/*
 * An XML document type.
 * Localname: objectCreation
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/oc/v1
 * Java type: org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.oc.v1.impl;
/**
 * A document containing one objectCreation(@http://www.tmforum.org/mtop/fmw/xsd/oc/v1) element.
 *
 * This is a complex type.
 */
public class ObjectCreationDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoDocumentImpl implements org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationDocument
{
    
    public ObjectCreationDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTCREATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/oc/v1", "objectCreation");
    private static final org.apache.xmlbeans.QNameSet OBJECTCREATION$1 = org.apache.xmlbeans.QNameSet.forArray( new javax.xml.namespace.QName[] { 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/rscoc/v1", "resourceObjectCreation"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/oc/v1", "objectCreation"),
    });
    
    
    /**
     * Gets the "objectCreation" element
     */
    public org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType getObjectCreation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType)get_store().find_element_user(OBJECTCREATION$1, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "objectCreation" element
     */
    public void setObjectCreation(org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType objectCreation)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType)get_store().find_element_user(OBJECTCREATION$1, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType)get_store().add_element_user(OBJECTCREATION$0);
            }
            target.set(objectCreation);
        }
    }
    
    /**
     * Appends and returns a new empty "objectCreation" element
     */
    public org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType addNewObjectCreation()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType target = null;
            target = (org.tmforum.mtop.fmw.xsd.oc.v1.ObjectCreationType)get_store().add_element_user(OBJECTCREATION$0);
            return target;
        }
    }
}
