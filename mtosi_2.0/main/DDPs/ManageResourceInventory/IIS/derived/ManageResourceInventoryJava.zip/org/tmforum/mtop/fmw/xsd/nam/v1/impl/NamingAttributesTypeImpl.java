/*
 * XML Type:  NamingAttributesType
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/nam/v1
 * Java type: org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.nam.v1.impl;
/**
 * An XML NamingAttributesType(@http://www.tmforum.org/mtop/fmw/xsd/nam/v1).
 *
 * This is a complex type.
 */
public class NamingAttributesTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType
{
    
    public NamingAttributesTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECT$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "object");
    
    
    /**
     * Gets a List of "object" elements
     */
    public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object> getObjectList()
    {
        final class ObjectList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object>
        {
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object get(int i)
                { return NamingAttributesTypeImpl.this.getObjectArray(i); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object o)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object old = NamingAttributesTypeImpl.this.getObjectArray(i);
                NamingAttributesTypeImpl.this.setObjectArray(i, o);
                return old;
            }
            
            public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object o)
                { NamingAttributesTypeImpl.this.insertNewObject(i).set(o); }
            
            public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object remove(int i)
            {
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object old = NamingAttributesTypeImpl.this.getObjectArray(i);
                NamingAttributesTypeImpl.this.removeObject(i);
                return old;
            }
            
            public int size()
                { return NamingAttributesTypeImpl.this.sizeOfObjectArray(); }
            
        }
        
        synchronized (monitor())
        {
            check_orphaned();
            return new ObjectList();
        }
    }
    
    /**
     * Gets array of all "object" elements
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object[] getObjectArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            java.util.List targetList = new java.util.ArrayList();
            get_store().find_all_element_users(OBJECT$0, targetList);
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object[targetList.size()];
            targetList.toArray(result);
            return result;
        }
    }
    
    /**
     * Gets ith "object" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object getObjectArray(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object)get_store().find_element_user(OBJECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            return target;
        }
    }
    
    /**
     * Returns number of "object" element
     */
    public int sizeOfObjectArray()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(OBJECT$0);
        }
    }
    
    /**
     * Sets array of all "object" element
     */
    public void setObjectArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object[] objectArray)
    {
        synchronized (monitor())
        {
            check_orphaned();
            arraySetterHelper(objectArray, OBJECT$0);
        }
    }
    
    /**
     * Sets ith "object" element
     */
    public void setObjectArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object object)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object)get_store().find_element_user(OBJECT$0, i);
            if (target == null)
            {
                throw new IndexOutOfBoundsException();
            }
            target.set(object);
        }
    }
    
    /**
     * Inserts and returns a new empty value (as xml) as the ith "object" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object insertNewObject(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object)get_store().insert_element_user(OBJECT$0, i);
            return target;
        }
    }
    
    /**
     * Appends and returns a new empty value (as xml) as the last "object" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object addNewObject()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object)get_store().add_element_user(OBJECT$0);
            return target;
        }
    }
    
    /**
     * Removes the ith "object" element
     */
    public void removeObject(int i)
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(OBJECT$0, i);
        }
    }
    /**
     * An XML object(@http://www.tmforum.org/mtop/fmw/xsd/nam/v1).
     *
     * This is a complex type.
     */
    public static class ObjectImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType.Object
    {
        
        public ObjectImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName TYPE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "type");
        private static final javax.xml.namespace.QName NAME$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/nam/v1", "name");
        
        
        /**
         * Gets the "type" element
         */
        public java.lang.String getType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "type" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetType()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(TYPE$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "type" element
         */
        public void setType(java.lang.String type)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(TYPE$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(TYPE$0);
                }
                target.setStringValue(type);
            }
        }
        
        /**
         * Sets (as xml) the "type" element
         */
        public void xsetType(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType type)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(TYPE$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().add_element_user(TYPE$0);
                }
                target.set(type);
            }
        }
        
        /**
         * Gets the "name" element
         */
        public java.lang.String getName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NAME$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "name" element
         */
        public org.apache.xmlbeans.XmlString xgetName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NAME$2, 0);
                return target;
            }
        }
        
        /**
         * Sets the "name" element
         */
        public void setName(java.lang.String name)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(NAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(NAME$2);
                }
                target.setStringValue(name);
            }
        }
        
        /**
         * Sets (as xml) the "name" element
         */
        public void xsetName(org.apache.xmlbeans.XmlString name)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.XmlString target = null;
                target = (org.apache.xmlbeans.XmlString)get_store().find_element_user(NAME$2, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.XmlString)get_store().add_element_user(NAME$2);
                }
                target.set(name);
            }
        }
    }
}
