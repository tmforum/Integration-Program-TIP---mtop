/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionNamesWithTpException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionNamesWithTpException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionNamesWithTpExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument
{
    
    public GetAllSubnetworkConnectionNamesWithTpExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONNAMESWITHTPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionNamesWithTpException");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionNamesWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException getGetAllSubnetworkConnectionNamesWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionNamesWithTpException" element
     */
    public void setGetAllSubnetworkConnectionNamesWithTpException(org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException getAllSubnetworkConnectionNamesWithTpException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESWITHTPEXCEPTION$0);
            }
            target.set(getAllSubnetworkConnectionNamesWithTpException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionNamesWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException addNewGetAllSubnetworkConnectionNamesWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESWITHTPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllSubnetworkConnectionNamesWithTpException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSubnetworkConnectionNamesWithTpExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesWithTpExceptionDocument.GetAllSubnetworkConnectionNamesWithTpException
    {
        
        public GetAllSubnetworkConnectionNamesWithTpExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
