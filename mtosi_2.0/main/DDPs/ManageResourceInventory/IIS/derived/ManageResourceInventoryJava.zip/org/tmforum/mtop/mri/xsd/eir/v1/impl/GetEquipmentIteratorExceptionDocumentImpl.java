/*
 * An XML document type.
 * Localname: getEquipmentIteratorException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getEquipmentIteratorException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetEquipmentIteratorExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument
{
    
    public GetEquipmentIteratorExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETEQUIPMENTITERATOREXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getEquipmentIteratorException");
    
    
    /**
     * Gets the "getEquipmentIteratorException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException getGetEquipmentIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException)get_store().find_element_user(GETEQUIPMENTITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getEquipmentIteratorException" element
     */
    public void setGetEquipmentIteratorException(org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException getEquipmentIteratorException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException)get_store().find_element_user(GETEQUIPMENTITERATOREXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException)get_store().add_element_user(GETEQUIPMENTITERATOREXCEPTION$0);
            }
            target.set(getEquipmentIteratorException);
        }
    }
    
    /**
     * Appends and returns a new empty "getEquipmentIteratorException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException addNewGetEquipmentIteratorException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException)get_store().add_element_user(GETEQUIPMENTITERATOREXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getEquipmentIteratorException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetEquipmentIteratorExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetEquipmentIteratorExceptionDocument.GetEquipmentIteratorException
    {
        
        public GetEquipmentIteratorExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
