/*
 * An XML document type.
 * Localname: getBackupRoutesException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getBackupRoutesException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetBackupRoutesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument
{
    
    public GetBackupRoutesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETBACKUPROUTESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getBackupRoutesException");
    
    
    /**
     * Gets the "getBackupRoutesException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException getGetBackupRoutesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException)get_store().find_element_user(GETBACKUPROUTESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getBackupRoutesException" element
     */
    public void setGetBackupRoutesException(org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException getBackupRoutesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException)get_store().find_element_user(GETBACKUPROUTESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException)get_store().add_element_user(GETBACKUPROUTESEXCEPTION$0);
            }
            target.set(getBackupRoutesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getBackupRoutesException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException addNewGetBackupRoutesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException)get_store().add_element_user(GETBACKUPROUTESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getBackupRoutesException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetBackupRoutesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesExceptionDocument.GetBackupRoutesException
    {
        
        public GetBackupRoutesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
