/*
 * An XML document type.
 * Localname: getFdfrRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument
{
    
    public GetFdfrRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrRequest");
    
    
    /**
     * Gets the "getFdfrRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest getGetFdfrRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest)get_store().find_element_user(GETFDFRREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrRequest" element
     */
    public void setGetFdfrRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest getFdfrRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest)get_store().find_element_user(GETFDFRREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest)get_store().add_element_user(GETFDFRREQUEST$0);
            }
            target.set(getFdfrRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest addNewGetFdfrRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest)get_store().add_element_user(GETFDFRREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFdfrRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRequestDocument.GetFdfrRequest
    {
        
        public GetFdfrRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrName");
        
        
        /**
         * Gets the "fdfrName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getFdfrName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FDFRNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "fdfrName" element
         */
        public void setFdfrName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType fdfrName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FDFRNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FDFRNAME$0);
                }
                target.set(fdfrName);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewFdfrName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FDFRNAME$0);
                return target;
            }
        }
    }
}
