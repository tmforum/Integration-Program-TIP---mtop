/*
 * An XML document type.
 * Localname: getFdfrRouteResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrRouteResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument
{
    
    public GetFdfrRouteResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRROUTERESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrRouteResponse");
    
    
    /**
     * Gets the "getFdfrRouteResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse getGetFdfrRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse)get_store().find_element_user(GETFDFRROUTERESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrRouteResponse" element
     */
    public void setGetFdfrRouteResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse getFdfrRouteResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse)get_store().find_element_user(GETFDFRROUTERESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse)get_store().add_element_user(GETFDFRROUTERESPONSE$0);
            }
            target.set(getFdfrRouteResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrRouteResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse addNewGetFdfrRouteResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse)get_store().add_element_user(GETFDFRROUTERESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFdfrRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrRouteResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrRouteResponseDocument.GetFdfrRouteResponse
    {
        
        public GetFdfrRouteResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ROUTE$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "route");
        
        
        /**
         * Gets the "route" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType getRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType)get_store().find_element_user(ROUTE$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "route" element
         */
        public void setRoute(org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType route)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType)get_store().find_element_user(ROUTE$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType)get_store().add_element_user(ROUTE$0);
                }
                target.set(route);
            }
        }
        
        /**
         * Appends and returns a new empty "route" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType addNewRoute()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfrroute.v1.FdfrRouteType)get_store().add_element_user(ROUTE$0);
                return target;
            }
        }
    }
}
