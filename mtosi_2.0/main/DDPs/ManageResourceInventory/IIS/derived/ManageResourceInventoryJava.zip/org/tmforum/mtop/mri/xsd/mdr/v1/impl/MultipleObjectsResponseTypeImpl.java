/*
 * XML Type:  MultipleObjectsResponseType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mdr.v1.impl;
/**
 * An XML MultipleObjectsResponseType(@http://www.tmforum.org/mtop/mri/xsd/mdr/v1).
 *
 * This is a complex type.
 */
public class MultipleObjectsResponseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.mdr.v1.MultipleObjectsResponseType
{
    
    public MultipleObjectsResponseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MDLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mdr/v1", "mdList");
    
    
    /**
     * Gets the "mdList" element
     */
    public org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType getMdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType)get_store().find_element_user(MDLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "mdList" element
     */
    public boolean isSetMdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(MDLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "mdList" element
     */
    public void setMdList(org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType mdList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType)get_store().find_element_user(MDLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType)get_store().add_element_user(MDLIST$0);
            }
            target.set(mdList);
        }
    }
    
    /**
     * Appends and returns a new empty "mdList" element
     */
    public org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType addNewMdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.md.v1.ManagementDomainListType)get_store().add_element_user(MDLIST$0);
            return target;
        }
    }
    
    /**
     * Unsets the "mdList" element
     */
    public void unsetMdList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(MDLIST$0, 0);
        }
    }
}
