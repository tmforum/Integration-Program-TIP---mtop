/*
 * An XML document type.
 * Localname: getFlowDomainRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument
{
    
    public GetFlowDomainRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainRequest");
    
    
    /**
     * Gets the "getFlowDomainRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest getGetFlowDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest)get_store().find_element_user(GETFLOWDOMAINREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainRequest" element
     */
    public void setGetFlowDomainRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest getFlowDomainRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest)get_store().find_element_user(GETFLOWDOMAINREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest)get_store().add_element_user(GETFLOWDOMAINREQUEST$0);
            }
            target.set(getFlowDomainRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest addNewGetFlowDomainRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest)get_store().add_element_user(GETFLOWDOMAINREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainRequestDocument.GetFlowDomainRequest
    {
        
        public GetFlowDomainRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdName");
        
        
        /**
         * Gets the "fdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getFdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FDNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "fdName" element
         */
        public void setFdName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType fdName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(FDNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FDNAME$0);
                }
                target.set(fdName);
            }
        }
        
        /**
         * Appends and returns a new empty "fdName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewFdName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(FDNAME$0);
                return target;
            }
        }
    }
}
