/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionNamesException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionNamesException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument
{
    
    public GetAllSubnetworkConnectionNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionNamesException");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException getGetAllSubnetworkConnectionNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionNamesException" element
     */
    public void setGetAllSubnetworkConnectionNamesException(org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException getAllSubnetworkConnectionNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESEXCEPTION$0);
            }
            target.set(getAllSubnetworkConnectionNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException addNewGetAllSubnetworkConnectionNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllSubnetworkConnectionNamesException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSubnetworkConnectionNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionNamesExceptionDocument.GetAllSubnetworkConnectionNamesException
    {
        
        public GetAllSubnetworkConnectionNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
