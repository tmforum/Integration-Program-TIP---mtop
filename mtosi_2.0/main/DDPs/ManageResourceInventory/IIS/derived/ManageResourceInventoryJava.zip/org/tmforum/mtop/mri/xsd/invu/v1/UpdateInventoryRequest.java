/*
 * XML Type:  updateInventoryRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/invu/v1
 * Java type: org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.invu.v1;


/**
 * An XML updateInventoryRequest(@http://www.tmforum.org/mtop/mri/xsd/invu/v1).
 *
 * This is a complex type.
 */
public interface UpdateInventoryRequest extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(UpdateInventoryRequest.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sCF63B8FC4B8F28B258F2EB26485C9EFE").resolveHandle("updateinventoryrequestfa2dtype");
    
    /**
     * Gets the "inventoryUpdate" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType getInventoryUpdate();
    
    /**
     * True if has "inventoryUpdate" element
     */
    boolean isSetInventoryUpdate();
    
    /**
     * Sets the "inventoryUpdate" element
     */
    void setInventoryUpdate(org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType inventoryUpdate);
    
    /**
     * Appends and returns a new empty "inventoryUpdate" element
     */
    org.tmforum.mtop.nrf.xsd.invdata.v1.InventoryDataType addNewInventoryUpdate();
    
    /**
     * Unsets the "inventoryUpdate" element
     */
    void unsetInventoryUpdate();
    
    /**
     * Gets the "effortMode" element
     */
    org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType.Enum getEffortMode();
    
    /**
     * Gets (as xml) the "effortMode" element
     */
    org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType xgetEffortMode();
    
    /**
     * True if has "effortMode" element
     */
    boolean isSetEffortMode();
    
    /**
     * Sets the "effortMode" element
     */
    void setEffortMode(org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType.Enum effortMode);
    
    /**
     * Sets (as xml) the "effortMode" element
     */
    void xsetEffortMode(org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType effortMode);
    
    /**
     * Unsets the "effortMode" element
     */
    void unsetEffortMode();
    
    /**
     * Gets the "integrationMode" element
     */
    org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType.Enum getIntegrationMode();
    
    /**
     * Gets (as xml) the "integrationMode" element
     */
    org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType xgetIntegrationMode();
    
    /**
     * True if has "integrationMode" element
     */
    boolean isSetIntegrationMode();
    
    /**
     * Sets the "integrationMode" element
     */
    void setIntegrationMode(org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType.Enum integrationMode);
    
    /**
     * Sets (as xml) the "integrationMode" element
     */
    void xsetIntegrationMode(org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType integrationMode);
    
    /**
     * Unsets the "integrationMode" element
     */
    void unsetIntegrationMode();
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest newInstance() {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryRequest) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
