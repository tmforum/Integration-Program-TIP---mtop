/*
 * An XML document type.
 * Localname: getAllFixedCrossConnectionsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedCrossConnectionsResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedCrossConnectionsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedCrossConnectionsResponseDocument
{
    
    public GetAllFixedCrossConnectionsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDCROSSCONNECTIONSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedCrossConnectionsResponse");
    
    
    /**
     * Gets the "getAllFixedCrossConnectionsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType getGetAllFixedCrossConnectionsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType)get_store().find_element_user(GETALLFIXEDCROSSCONNECTIONSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedCrossConnectionsResponse" element
     */
    public void setGetAllFixedCrossConnectionsResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType getAllFixedCrossConnectionsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType)get_store().find_element_user(GETALLFIXEDCROSSCONNECTIONSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType)get_store().add_element_user(GETALLFIXEDCROSSCONNECTIONSRESPONSE$0);
            }
            target.set(getAllFixedCrossConnectionsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedCrossConnectionsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType addNewGetAllFixedCrossConnectionsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleCcObjectsResponseType)get_store().add_element_user(GETALLFIXEDCROSSCONNECTIONSRESPONSE$0);
            return target;
        }
    }
}
