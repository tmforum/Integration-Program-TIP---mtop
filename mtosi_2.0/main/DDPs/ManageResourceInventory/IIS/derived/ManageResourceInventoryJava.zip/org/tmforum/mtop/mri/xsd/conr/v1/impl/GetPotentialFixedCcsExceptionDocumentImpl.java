/*
 * An XML document type.
 * Localname: getPotentialFixedCcsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getPotentialFixedCcsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetPotentialFixedCcsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument
{
    
    public GetPotentialFixedCcsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETPOTENTIALFIXEDCCSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getPotentialFixedCcsException");
    
    
    /**
     * Gets the "getPotentialFixedCcsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException getGetPotentialFixedCcsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException)get_store().find_element_user(GETPOTENTIALFIXEDCCSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getPotentialFixedCcsException" element
     */
    public void setGetPotentialFixedCcsException(org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException getPotentialFixedCcsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException)get_store().find_element_user(GETPOTENTIALFIXEDCCSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException)get_store().add_element_user(GETPOTENTIALFIXEDCCSEXCEPTION$0);
            }
            target.set(getPotentialFixedCcsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getPotentialFixedCcsException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException addNewGetPotentialFixedCcsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException)get_store().add_element_user(GETPOTENTIALFIXEDCCSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getPotentialFixedCcsException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetPotentialFixedCcsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetPotentialFixedCcsExceptionDocument.GetPotentialFixedCcsException
    {
        
        public GetPotentialFixedCcsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
