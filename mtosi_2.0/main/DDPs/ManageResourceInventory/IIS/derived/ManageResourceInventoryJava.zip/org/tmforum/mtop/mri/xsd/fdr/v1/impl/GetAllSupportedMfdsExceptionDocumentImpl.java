/*
 * An XML document type.
 * Localname: getAllSupportedMfdsException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllSupportedMfdsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportedMfdsExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument
{
    
    public GetAllSupportedMfdsExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTEDMFDSEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllSupportedMfdsException");
    
    
    /**
     * Gets the "getAllSupportedMfdsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException getGetAllSupportedMfdsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException)get_store().find_element_user(GETALLSUPPORTEDMFDSEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportedMfdsException" element
     */
    public void setGetAllSupportedMfdsException(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException getAllSupportedMfdsException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException)get_store().find_element_user(GETALLSUPPORTEDMFDSEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException)get_store().add_element_user(GETALLSUPPORTEDMFDSEXCEPTION$0);
            }
            target.set(getAllSupportedMfdsException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportedMfdsException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException addNewGetAllSupportedMfdsException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException)get_store().add_element_user(GETALLSUPPORTEDMFDSEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllSupportedMfdsException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSupportedMfdsExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsExceptionDocument.GetAllSupportedMfdsException
    {
        
        public GetAllSupportedMfdsExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
