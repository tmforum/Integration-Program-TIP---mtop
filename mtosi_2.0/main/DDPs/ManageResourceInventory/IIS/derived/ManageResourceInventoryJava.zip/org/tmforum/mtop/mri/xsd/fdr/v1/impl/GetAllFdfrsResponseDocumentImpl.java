/*
 * An XML document type.
 * Localname: getAllFdfrsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllFdfrsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFdfrsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument
{
    
    public GetAllFdfrsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFDFRSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllFdfrsResponse");
    
    
    /**
     * Gets the "getAllFdfrsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse getGetAllFdfrsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse)get_store().find_element_user(GETALLFDFRSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFdfrsResponse" element
     */
    public void setGetAllFdfrsResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse getAllFdfrsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse)get_store().find_element_user(GETALLFDFRSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse)get_store().add_element_user(GETALLFDFRSRESPONSE$0);
            }
            target.set(getAllFdfrsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFdfrsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse addNewGetAllFdfrsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse)get_store().add_element_user(GETALLFDFRSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAllFdfrsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFdfrsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllFdfrsResponseDocument.GetAllFdfrsResponse
    {
        
        public GetAllFdfrsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FDFRLIST$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "fdfrList");
        
        
        /**
         * Gets the "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType getFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "fdfrList" element
         */
        public boolean isSetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FDFRLIST$0) != 0;
            }
        }
        
        /**
         * Sets the "fdfrList" element
         */
        public void setFdfrList(org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType fdfrList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType)get_store().find_element_user(FDFRLIST$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType)get_store().add_element_user(FDFRLIST$0);
                }
                target.set(fdfrList);
            }
        }
        
        /**
         * Appends and returns a new empty "fdfrList" element
         */
        public org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType addNewFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fdfr.v1.FdfrListType)get_store().add_element_user(FDFRLIST$0);
                return target;
            }
        }
        
        /**
         * Unsets the "fdfrList" element
         */
        public void unsetFdfrList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FDFRLIST$0, 0);
            }
        }
    }
}
