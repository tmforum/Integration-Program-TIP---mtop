/*
 * XML Type:  updateInventoryResponseType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/invu/v1
 * Java type: org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryResponseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.invu.v1.impl;
/**
 * An XML updateInventoryResponseType(@http://www.tmforum.org/mtop/mri/xsd/invu/v1).
 *
 * This is a complex type.
 */
public class UpdateInventoryResponseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryResponseType
{
    
    public UpdateInventoryResponseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    
}
