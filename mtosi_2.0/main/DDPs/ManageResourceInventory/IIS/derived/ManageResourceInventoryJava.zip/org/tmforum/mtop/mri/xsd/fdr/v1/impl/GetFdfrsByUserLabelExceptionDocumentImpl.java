/*
 * An XML document type.
 * Localname: getFdfrsByUserLabelException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrsByUserLabelExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument
{
    
    public GetFdfrsByUserLabelExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRSBYUSERLABELEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrsByUserLabelException");
    
    
    /**
     * Gets the "getFdfrsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException getGetFdfrsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException)get_store().find_element_user(GETFDFRSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrsByUserLabelException" element
     */
    public void setGetFdfrsByUserLabelException(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException getFdfrsByUserLabelException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException)get_store().find_element_user(GETFDFRSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException)get_store().add_element_user(GETFDFRSBYUSERLABELEXCEPTION$0);
            }
            target.set(getFdfrsByUserLabelException);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException addNewGetFdfrsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException)get_store().add_element_user(GETFDFRSBYUSERLABELEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getFdfrsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrsByUserLabelExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelExceptionDocument.GetFdfrsByUserLabelException
    {
        
        public GetFdfrsByUserLabelExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
