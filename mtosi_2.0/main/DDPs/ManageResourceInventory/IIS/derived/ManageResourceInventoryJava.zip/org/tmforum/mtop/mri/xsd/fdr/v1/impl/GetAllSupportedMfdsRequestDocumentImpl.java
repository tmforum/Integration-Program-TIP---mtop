/*
 * An XML document type.
 * Localname: getAllSupportedMfdsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllSupportedMfdsRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSupportedMfdsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument
{
    
    public GetAllSupportedMfdsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUPPORTEDMFDSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllSupportedMfdsRequest");
    
    
    /**
     * Gets the "getAllSupportedMfdsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest getGetAllSupportedMfdsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest)get_store().find_element_user(GETALLSUPPORTEDMFDSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSupportedMfdsRequest" element
     */
    public void setGetAllSupportedMfdsRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest getAllSupportedMfdsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest)get_store().find_element_user(GETALLSUPPORTEDMFDSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest)get_store().add_element_user(GETALLSUPPORTEDMFDSREQUEST$0);
            }
            target.set(getAllSupportedMfdsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSupportedMfdsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest addNewGetAllSupportedMfdsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest)get_store().add_element_user(GETALLSUPPORTEDMFDSREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAllSupportedMfdsRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllSupportedMfdsRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllSupportedMfdsRequestDocument.GetAllSupportedMfdsRequest
    {
        
        public GetAllSupportedMfdsRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName HOLDERNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "holderName");
        
        
        /**
         * Gets the "holderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(HOLDERNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "holderName" element
         */
        public void setHolderName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType holderName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(HOLDERNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(HOLDERNAME$0);
                }
                target.set(holderName);
            }
        }
        
        /**
         * Appends and returns a new empty "holderName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewHolderName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(HOLDERNAME$0);
                return target;
            }
        }
    }
}
