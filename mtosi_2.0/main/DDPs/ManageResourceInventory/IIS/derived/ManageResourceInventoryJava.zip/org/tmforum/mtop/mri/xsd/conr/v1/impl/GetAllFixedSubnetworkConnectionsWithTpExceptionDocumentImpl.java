/*
 * An XML document type.
 * Localname: getAllFixedSubnetworkConnectionsWithTpException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedSubnetworkConnectionsWithTpException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedSubnetworkConnectionsWithTpExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument
{
    
    public GetAllFixedSubnetworkConnectionsWithTpExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedSubnetworkConnectionsWithTpException");
    
    
    /**
     * Gets the "getAllFixedSubnetworkConnectionsWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException getGetAllFixedSubnetworkConnectionsWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedSubnetworkConnectionsWithTpException" element
     */
    public void setGetAllFixedSubnetworkConnectionsWithTpException(org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException getAllFixedSubnetworkConnectionsWithTpException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0);
            }
            target.set(getAllFixedSubnetworkConnectionsWithTpException);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedSubnetworkConnectionsWithTpException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException addNewGetAllFixedSubnetworkConnectionsWithTpException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONSWITHTPEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getAllFixedSubnetworkConnectionsWithTpException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllFixedSubnetworkConnectionsWithTpExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionsWithTpExceptionDocument.GetAllFixedSubnetworkConnectionsWithTpException
    {
        
        public GetAllFixedSubnetworkConnectionsWithTpExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
