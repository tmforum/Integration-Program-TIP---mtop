/*
 * An XML document type.
 * Localname: getFlowDomainsByUserLabelResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFlowDomainsByUserLabelResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFlowDomainsByUserLabelResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument
{
    
    public GetFlowDomainsByUserLabelResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFLOWDOMAINSBYUSERLABELRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFlowDomainsByUserLabelResponse");
    
    
    /**
     * Gets the "getFlowDomainsByUserLabelResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse getGetFlowDomainsByUserLabelResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse)get_store().find_element_user(GETFLOWDOMAINSBYUSERLABELRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFlowDomainsByUserLabelResponse" element
     */
    public void setGetFlowDomainsByUserLabelResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse getFlowDomainsByUserLabelResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse)get_store().find_element_user(GETFLOWDOMAINSBYUSERLABELRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse)get_store().add_element_user(GETFLOWDOMAINSBYUSERLABELRESPONSE$0);
            }
            target.set(getFlowDomainsByUserLabelResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getFlowDomainsByUserLabelResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse addNewGetFlowDomainsByUserLabelResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse)get_store().add_element_user(GETFLOWDOMAINSBYUSERLABELRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getFlowDomainsByUserLabelResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFlowDomainsByUserLabelResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFlowDomainsByUserLabelResponseDocument.GetFlowDomainsByUserLabelResponse
    {
        
        public GetFlowDomainsByUserLabelResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FLOWDOMAINS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "flowDomains");
        
        
        /**
         * Gets the "flowDomains" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FdListType getFlowDomains()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().find_element_user(FLOWDOMAINS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "flowDomains" element
         */
        public boolean isSetFlowDomains()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FLOWDOMAINS$0) != 0;
            }
        }
        
        /**
         * Sets the "flowDomains" element
         */
        public void setFlowDomains(org.tmforum.mtop.nrf.xsd.fd.v1.FdListType flowDomains)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().find_element_user(FLOWDOMAINS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().add_element_user(FLOWDOMAINS$0);
                }
                target.set(flowDomains);
            }
        }
        
        /**
         * Appends and returns a new empty "flowDomains" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FdListType addNewFlowDomains()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FdListType)get_store().add_element_user(FLOWDOMAINS$0);
                return target;
            }
        }
        
        /**
         * Unsets the "flowDomains" element
         */
        public void unsetFlowDomains()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FLOWDOMAINS$0, 0);
            }
        }
    }
}
