/*
 * An XML document type.
 * Localname: getAllFixedSubnetworkConnectionNamesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionNamesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedSubnetworkConnectionNamesResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedSubnetworkConnectionNamesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionNamesResponseDocument
{
    
    public GetAllFixedSubnetworkConnectionNamesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDSUBNETWORKCONNECTIONNAMESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedSubnetworkConnectionNamesResponse");
    
    
    /**
     * Gets the "getAllFixedSubnetworkConnectionNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType getGetAllFixedSubnetworkConnectionNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedSubnetworkConnectionNamesResponse" element
     */
    public void setGetAllFixedSubnetworkConnectionNamesResponse(org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType getAllFixedSubnetworkConnectionNamesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESRESPONSE$0);
            }
            target.set(getAllFixedSubnetworkConnectionNamesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedSubnetworkConnectionNamesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType addNewGetAllFixedSubnetworkConnectionNamesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectNamesResponseType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESRESPONSE$0);
            return target;
        }
    }
}
