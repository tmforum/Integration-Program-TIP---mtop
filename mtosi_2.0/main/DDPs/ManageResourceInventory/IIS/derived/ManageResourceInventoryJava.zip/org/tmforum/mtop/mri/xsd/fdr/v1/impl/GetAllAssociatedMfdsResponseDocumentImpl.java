/*
 * An XML document type.
 * Localname: getAllAssociatedMfdsResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAllAssociatedMfdsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllAssociatedMfdsResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument
{
    
    public GetAllAssociatedMfdsResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLASSOCIATEDMFDSRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAllAssociatedMfdsResponse");
    
    
    /**
     * Gets the "getAllAssociatedMfdsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse getGetAllAssociatedMfdsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse)get_store().find_element_user(GETALLASSOCIATEDMFDSRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllAssociatedMfdsResponse" element
     */
    public void setGetAllAssociatedMfdsResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse getAllAssociatedMfdsResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse)get_store().find_element_user(GETALLASSOCIATEDMFDSRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse)get_store().add_element_user(GETALLASSOCIATEDMFDSRESPONSE$0);
            }
            target.set(getAllAssociatedMfdsResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllAssociatedMfdsResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse addNewGetAllAssociatedMfdsResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse)get_store().add_element_user(GETALLASSOCIATEDMFDSRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAllAssociatedMfdsResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAllAssociatedMfdsResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAllAssociatedMfdsResponseDocument.GetAllAssociatedMfdsResponse
    {
        
        public GetAllAssociatedMfdsResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName MFDS$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "mfds");
        
        
        /**
         * Gets the "mfds" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType getMfds()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType)get_store().find_element_user(MFDS$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "mfds" element
         */
        public boolean isSetMfds()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(MFDS$0) != 0;
            }
        }
        
        /**
         * Sets the "mfds" element
         */
        public void setMfds(org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType mfds)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType)get_store().find_element_user(MFDS$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType)get_store().add_element_user(MFDS$0);
                }
                target.set(mfds);
            }
        }
        
        /**
         * Appends and returns a new empty "mfds" element
         */
        public org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType addNewMfds()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.mfd.v1.MfdListType)get_store().add_element_user(MFDS$0);
                return target;
            }
        }
        
        /**
         * Unsets the "mfds" element
         */
        public void unsetMfds()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(MFDS$0, 0);
            }
        }
    }
}
