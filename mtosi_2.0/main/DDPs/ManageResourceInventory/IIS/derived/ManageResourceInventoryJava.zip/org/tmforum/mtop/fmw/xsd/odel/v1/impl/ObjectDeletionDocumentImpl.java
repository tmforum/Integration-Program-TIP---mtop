/*
 * An XML document type.
 * Localname: objectDeletion
 * Namespace: http://www.tmforum.org/mtop/fmw/xsd/odel/v1
 * Java type: org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.fmw.xsd.odel.v1.impl;
/**
 * A document containing one objectDeletion(@http://www.tmforum.org/mtop/fmw/xsd/odel/v1) element.
 *
 * This is a complex type.
 */
public class ObjectDeletionDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoDocumentImpl implements org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionDocument
{
    
    public ObjectDeletionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName OBJECTDELETION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odel/v1", "objectDeletion");
    private static final org.apache.xmlbeans.QNameSet OBJECTDELETION$1 = org.apache.xmlbeans.QNameSet.forArray( new javax.xml.namespace.QName[] { 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/rscodel/v1", "resourceObjectDeletion"),
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/fmw/xsd/odel/v1", "objectDeletion"),
    });
    
    
    /**
     * Gets the "objectDeletion" element
     */
    public org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType getObjectDeletion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType)get_store().find_element_user(OBJECTDELETION$1, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "objectDeletion" element
     */
    public void setObjectDeletion(org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType objectDeletion)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType)get_store().find_element_user(OBJECTDELETION$1, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType)get_store().add_element_user(OBJECTDELETION$0);
            }
            target.set(objectDeletion);
        }
    }
    
    /**
     * Appends and returns a new empty "objectDeletion" element
     */
    public org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType addNewObjectDeletion()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType target = null;
            target = (org.tmforum.mtop.fmw.xsd.odel.v1.ObjectDeletionType)get_store().add_element_user(OBJECTDELETION$0);
            return target;
        }
    }
}
