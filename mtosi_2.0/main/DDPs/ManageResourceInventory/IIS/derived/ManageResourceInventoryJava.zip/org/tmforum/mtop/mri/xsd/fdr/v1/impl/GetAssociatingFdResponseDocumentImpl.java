/*
 * An XML document type.
 * Localname: getAssociatingFdResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssociatingFdResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssociatingFdResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument
{
    
    public GetAssociatingFdResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSOCIATINGFDRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssociatingFdResponse");
    
    
    /**
     * Gets the "getAssociatingFdResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse getGetAssociatingFdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse)get_store().find_element_user(GETASSOCIATINGFDRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssociatingFdResponse" element
     */
    public void setGetAssociatingFdResponse(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse getAssociatingFdResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse)get_store().find_element_user(GETASSOCIATINGFDRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse)get_store().add_element_user(GETASSOCIATINGFDRESPONSE$0);
            }
            target.set(getAssociatingFdResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssociatingFdResponse" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse addNewGetAssociatingFdResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse)get_store().add_element_user(GETASSOCIATINGFDRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getAssociatingFdResponse(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssociatingFdResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssociatingFdResponseDocument.GetAssociatingFdResponse
    {
        
        public GetAssociatingFdResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName FLOWDOMAIN$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "flowDomain");
        
        
        /**
         * Gets the "flowDomain" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType getFlowDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FLOWDOMAIN$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "flowDomain" element
         */
        public boolean isSetFlowDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(FLOWDOMAIN$0) != 0;
            }
        }
        
        /**
         * Sets the "flowDomain" element
         */
        public void setFlowDomain(org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType flowDomain)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().find_element_user(FLOWDOMAIN$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FLOWDOMAIN$0);
                }
                target.set(flowDomain);
            }
        }
        
        /**
         * Appends and returns a new empty "flowDomain" element
         */
        public org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType addNewFlowDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType target = null;
                target = (org.tmforum.mtop.nrf.xsd.fd.v1.FlowDomainType)get_store().add_element_user(FLOWDOMAIN$0);
                return target;
            }
        }
        
        /**
         * Unsets the "flowDomain" element
         */
        public void unsetFlowDomain()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(FLOWDOMAIN$0, 0);
            }
        }
    }
}
