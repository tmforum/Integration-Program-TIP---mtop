/*
 * An XML document type.
 * Localname: getFdfrsByUserLabelRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getFdfrsByUserLabelRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetFdfrsByUserLabelRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument
{
    
    public GetFdfrsByUserLabelRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETFDFRSBYUSERLABELREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getFdfrsByUserLabelRequest");
    
    
    /**
     * Gets the "getFdfrsByUserLabelRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest getGetFdfrsByUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest)get_store().find_element_user(GETFDFRSBYUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getFdfrsByUserLabelRequest" element
     */
    public void setGetFdfrsByUserLabelRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest getFdfrsByUserLabelRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest)get_store().find_element_user(GETFDFRSBYUSERLABELREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest)get_store().add_element_user(GETFDFRSBYUSERLABELREQUEST$0);
            }
            target.set(getFdfrsByUserLabelRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getFdfrsByUserLabelRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest addNewGetFdfrsByUserLabelRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest)get_store().add_element_user(GETFDFRSBYUSERLABELREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getFdfrsByUserLabelRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetFdfrsByUserLabelRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetFdfrsByUserLabelRequestDocument.GetFdfrsByUserLabelRequest
    {
        
        public GetFdfrsByUserLabelRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName USERLABEL$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "userLabel");
        
        
        /**
         * Gets the "userLabel" element
         */
        public java.lang.String getUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) the "userLabel" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType xgetUserLabel()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$0, 0);
                return target;
            }
        }
        
        /**
         * Sets the "userLabel" element
         */
        public void setUserLabel(java.lang.String userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(USERLABEL$0);
                }
                target.setStringValue(userLabel);
            }
        }
        
        /**
         * Sets (as xml) the "userLabel" element
         */
        public void xsetUserLabel(org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType userLabel)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().find_element_user(USERLABEL$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.gen.v1.UserLabelType)get_store().add_element_user(USERLABEL$0);
                }
                target.set(userLabel);
            }
        }
    }
}
