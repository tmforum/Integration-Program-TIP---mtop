/*
 * XML Type:  GetAllEquipmentRequestType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * An XML GetAllEquipmentRequestType(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
 *
 * This is a complex type.
 */
public class GetAllEquipmentRequestTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetAllEquipmentRequestType
{
    
    public GetAllEquipmentRequestTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MEORHOLDERNAME$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "meOrHolderName");
    
    
    /**
     * Gets the "meOrHolderName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getMeOrHolderName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MEORHOLDERNAME$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "meOrHolderName" element
     */
    public void setMeOrHolderName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType meOrHolderName)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(MEORHOLDERNAME$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MEORHOLDERNAME$0);
            }
            target.set(meOrHolderName);
        }
    }
    
    /**
     * Appends and returns a new empty "meOrHolderName" element
     */
    public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewMeOrHolderName()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
            target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(MEORHOLDERNAME$0);
            return target;
        }
    }
}
