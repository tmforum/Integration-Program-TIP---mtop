/*
 * An XML document type.
 * Localname: getSupportingEquipmentNamesException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/eir/v1
 * Java type: org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.eir.v1.impl;
/**
 * A document containing one getSupportingEquipmentNamesException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1) element.
 *
 * This is a complex type.
 */
public class GetSupportingEquipmentNamesExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument
{
    
    public GetSupportingEquipmentNamesExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSUPPORTINGEQUIPMENTNAMESEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/eir/v1", "getSupportingEquipmentNamesException");
    
    
    /**
     * Gets the "getSupportingEquipmentNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException getGetSupportingEquipmentNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException)get_store().find_element_user(GETSUPPORTINGEQUIPMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSupportingEquipmentNamesException" element
     */
    public void setGetSupportingEquipmentNamesException(org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException getSupportingEquipmentNamesException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException)get_store().find_element_user(GETSUPPORTINGEQUIPMENTNAMESEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException)get_store().add_element_user(GETSUPPORTINGEQUIPMENTNAMESEXCEPTION$0);
            }
            target.set(getSupportingEquipmentNamesException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSupportingEquipmentNamesException" element
     */
    public org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException addNewGetSupportingEquipmentNamesException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException target = null;
            target = (org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException)get_store().add_element_user(GETSUPPORTINGEQUIPMENTNAMESEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getSupportingEquipmentNamesException(@http://www.tmforum.org/mtop/mri/xsd/eir/v1).
     *
     * This is a complex type.
     */
    public static class GetSupportingEquipmentNamesExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.eir.v1.GetSupportingEquipmentNamesExceptionDocument.GetSupportingEquipmentNamesException
    {
        
        public GetSupportingEquipmentNamesExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
