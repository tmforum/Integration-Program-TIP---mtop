/*
 * An XML document type.
 * Localname: getAllSubnetworkConnectionsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllSubnetworkConnectionsRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllSubnetworkConnectionsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllSubnetworkConnectionsRequestDocument
{
    
    public GetAllSubnetworkConnectionsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLSUBNETWORKCONNECTIONSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllSubnetworkConnectionsRequest");
    
    
    /**
     * Gets the "getAllSubnetworkConnectionsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType getGetAllSubnetworkConnectionsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllSubnetworkConnectionsRequest" element
     */
    public void setGetAllSubnetworkConnectionsRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType getAllSubnetworkConnectionsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType)get_store().find_element_user(GETALLSUBNETWORKCONNECTIONSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSREQUEST$0);
            }
            target.set(getAllSubnetworkConnectionsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllSubnetworkConnectionsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType addNewGetAllSubnetworkConnectionsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsRequestType)get_store().add_element_user(GETALLSUBNETWORKCONNECTIONSREQUEST$0);
            return target;
        }
    }
}
