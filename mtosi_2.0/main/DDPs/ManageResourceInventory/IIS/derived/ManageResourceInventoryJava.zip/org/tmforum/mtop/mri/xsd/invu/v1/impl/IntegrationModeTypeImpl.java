/*
 * XML Type:  IntegrationModeType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/invu/v1
 * Java type: org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.invu.v1.impl;
/**
 * An XML IntegrationModeType(@http://www.tmforum.org/mtop/mri/xsd/invu/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType.
 */
public class IntegrationModeTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.mri.xsd.invu.v1.IntegrationModeType
{
    
    public IntegrationModeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected IntegrationModeTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
