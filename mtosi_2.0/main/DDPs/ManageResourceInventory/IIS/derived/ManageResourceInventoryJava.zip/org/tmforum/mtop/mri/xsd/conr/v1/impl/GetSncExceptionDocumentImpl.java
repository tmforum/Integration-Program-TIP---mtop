/*
 * An XML document type.
 * Localname: getSncException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSncException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSncExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument
{
    
    public GetSncExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSNCEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSncException");
    
    
    /**
     * Gets the "getSncException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException getGetSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException)get_store().find_element_user(GETSNCEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSncException" element
     */
    public void setGetSncException(org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException getSncException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException)get_store().find_element_user(GETSNCEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException)get_store().add_element_user(GETSNCEXCEPTION$0);
            }
            target.set(getSncException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSncException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException addNewGetSncException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException)get_store().add_element_user(GETSNCEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getSncException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetSncExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncExceptionDocument.GetSncException
    {
        
        public GetSncExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
