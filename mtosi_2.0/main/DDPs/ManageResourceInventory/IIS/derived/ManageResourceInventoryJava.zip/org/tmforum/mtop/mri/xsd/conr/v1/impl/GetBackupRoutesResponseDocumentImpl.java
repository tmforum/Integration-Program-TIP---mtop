/*
 * An XML document type.
 * Localname: getBackupRoutesResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getBackupRoutesResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetBackupRoutesResponseDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument
{
    
    public GetBackupRoutesResponseDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETBACKUPROUTESRESPONSE$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getBackupRoutesResponse");
    
    
    /**
     * Gets the "getBackupRoutesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse getGetBackupRoutesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse)get_store().find_element_user(GETBACKUPROUTESRESPONSE$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getBackupRoutesResponse" element
     */
    public void setGetBackupRoutesResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse getBackupRoutesResponse)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse)get_store().find_element_user(GETBACKUPROUTESRESPONSE$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse)get_store().add_element_user(GETBACKUPROUTESRESPONSE$0);
            }
            target.set(getBackupRoutesResponse);
        }
    }
    
    /**
     * Appends and returns a new empty "getBackupRoutesResponse" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse addNewGetBackupRoutesResponse()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse)get_store().add_element_user(GETBACKUPROUTESRESPONSE$0);
            return target;
        }
    }
    /**
     * An XML getBackupRoutesResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetBackupRoutesResponseImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetBackupRoutesResponseDocument.GetBackupRoutesResponse
    {
        
        public GetBackupRoutesResponseImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName ADDITIONALINFO$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "additionalInfo");
        private static final javax.xml.namespace.QName ROUTELIST$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "routeList");
        
        
        /**
         * Gets the "additionalInfo" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType getAdditionalInfo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(ADDITIONALINFO$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "additionalInfo" element
         */
        public void setAdditionalInfo(org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType additionalInfo)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().find_element_user(ADDITIONALINFO$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(ADDITIONALINFO$0);
                }
                target.set(additionalInfo);
            }
        }
        
        /**
         * Appends and returns a new empty "additionalInfo" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType addNewAdditionalInfo()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType)get_store().add_element_user(ADDITIONALINFO$0);
                return target;
            }
        }
        
        /**
         * Gets the "routeList" element
         */
        public org.tmforum.mtop.nrf.xsd.route.v1.RouteListType getRouteList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().find_element_user(ROUTELIST$2, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * True if has "routeList" element
         */
        public boolean isSetRouteList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(ROUTELIST$2) != 0;
            }
        }
        
        /**
         * Sets the "routeList" element
         */
        public void setRouteList(org.tmforum.mtop.nrf.xsd.route.v1.RouteListType routeList)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().find_element_user(ROUTELIST$2, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().add_element_user(ROUTELIST$2);
                }
                target.set(routeList);
            }
        }
        
        /**
         * Appends and returns a new empty "routeList" element
         */
        public org.tmforum.mtop.nrf.xsd.route.v1.RouteListType addNewRouteList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.nrf.xsd.route.v1.RouteListType target = null;
                target = (org.tmforum.mtop.nrf.xsd.route.v1.RouteListType)get_store().add_element_user(ROUTELIST$2);
                return target;
            }
        }
        
        /**
         * Unsets the "routeList" element
         */
        public void unsetRouteList()
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(ROUTELIST$2, 0);
            }
        }
    }
}
