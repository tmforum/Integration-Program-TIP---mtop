/*
 * An XML document type.
 * Localname: updateInventoryException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/invu/v1
 * Java type: org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.invu.v1.impl;
/**
 * A document containing one updateInventoryException(@http://www.tmforum.org/mtop/mri/xsd/invu/v1) element.
 *
 * This is a complex type.
 */
public class UpdateInventoryExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument
{
    
    public UpdateInventoryExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName UPDATEINVENTORYEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "updateInventoryException");
    
    
    /**
     * Gets the "updateInventoryException" element
     */
    public org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException getUpdateInventoryException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException target = null;
            target = (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException)get_store().find_element_user(UPDATEINVENTORYEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "updateInventoryException" element
     */
    public void setUpdateInventoryException(org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException updateInventoryException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException target = null;
            target = (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException)get_store().find_element_user(UPDATEINVENTORYEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException)get_store().add_element_user(UPDATEINVENTORYEXCEPTION$0);
            }
            target.set(updateInventoryException);
        }
    }
    
    /**
     * Appends and returns a new empty "updateInventoryException" element
     */
    public org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException addNewUpdateInventoryException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException target = null;
            target = (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException)get_store().add_element_user(UPDATEINVENTORYEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML updateInventoryException(@http://www.tmforum.org/mtop/mri/xsd/invu/v1).
     *
     * This is a complex type.
     */
    public static class UpdateInventoryExceptionImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException
    {
        
        public UpdateInventoryExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName EXCEPTIONNOTIMPLEMENTED$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "exceptionNotImplemented");
        private static final javax.xml.namespace.QName EXCEPTIONINTERNALERROR$2 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "exceptionInternalError");
        private static final javax.xml.namespace.QName EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "exceptionInvalidInput_ObjectDoesNotExist");
        private static final javax.xml.namespace.QName NONEXISTENTCONTAININGOBJECT$6 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "nonexistentContainingObject");
        private static final javax.xml.namespace.QName EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "exceptionInvalidInput_UnsupportedObjectTypes");
        private static final javax.xml.namespace.QName UNSUPPORTEDOBJECTTYPES$10 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "unsupportedObjectTypes");
        private static final javax.xml.namespace.QName EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "exceptionInvalidInput_UnsupportAttributesOrValues");
        private static final javax.xml.namespace.QName EXCEPTIONOBJECTINUSE$14 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "exceptionObjectInUse");
        private static final javax.xml.namespace.QName OBJECTINUSE$16 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "objectInUse");
        private static final javax.xml.namespace.QName EXCEPTIONPOLICYVIOLATION$18 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "exceptionPolicyViolation");
        private static final javax.xml.namespace.QName BASEINSTANCE$20 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/invu/v1", "baseInstance");
        
        
        /**
         * Gets a List of "exceptionNotImplemented" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionNotImplementedList()
        {
            final class ExceptionNotImplementedList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType>
            {
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getExceptionNotImplementedArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType set(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionNotImplementedArray(i);
                    UpdateInventoryExceptionImpl.this.setExceptionNotImplementedArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                    { UpdateInventoryExceptionImpl.this.insertNewExceptionNotImplemented(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionNotImplementedArray(i);
                    UpdateInventoryExceptionImpl.this.removeExceptionNotImplemented(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfExceptionNotImplementedArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ExceptionNotImplementedList();
            }
        }
        
        /**
         * Gets array of all "exceptionNotImplemented" elements
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionNotImplementedArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EXCEPTIONNOTIMPLEMENTED$0, targetList);
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] result = new org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "exceptionNotImplemented" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionNotImplementedArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONNOTIMPLEMENTED$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "exceptionNotImplemented" element
         */
        public int sizeOfExceptionNotImplementedArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCEPTIONNOTIMPLEMENTED$0);
            }
        }
        
        /**
         * Sets array of all "exceptionNotImplemented" element
         */
        public void setExceptionNotImplementedArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionNotImplementedArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(exceptionNotImplementedArray, EXCEPTIONNOTIMPLEMENTED$0);
            }
        }
        
        /**
         * Sets ith "exceptionNotImplemented" element
         */
        public void setExceptionNotImplementedArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionNotImplemented)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONNOTIMPLEMENTED$0, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(exceptionNotImplemented);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionNotImplemented" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionNotImplemented(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().insert_element_user(EXCEPTIONNOTIMPLEMENTED$0, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionNotImplemented" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionNotImplemented()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(EXCEPTIONNOTIMPLEMENTED$0);
                return target;
            }
        }
        
        /**
         * Removes the ith "exceptionNotImplemented" element
         */
        public void removeExceptionNotImplemented(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCEPTIONNOTIMPLEMENTED$0, i);
            }
        }
        
        /**
         * Gets a List of "exceptionInternalError" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionInternalErrorList()
        {
            final class ExceptionInternalErrorList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType>
            {
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getExceptionInternalErrorArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType set(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionInternalErrorArray(i);
                    UpdateInventoryExceptionImpl.this.setExceptionInternalErrorArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                    { UpdateInventoryExceptionImpl.this.insertNewExceptionInternalError(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionInternalErrorArray(i);
                    UpdateInventoryExceptionImpl.this.removeExceptionInternalError(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfExceptionInternalErrorArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ExceptionInternalErrorList();
            }
        }
        
        /**
         * Gets array of all "exceptionInternalError" elements
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionInternalErrorArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EXCEPTIONINTERNALERROR$2, targetList);
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] result = new org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "exceptionInternalError" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionInternalErrorArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONINTERNALERROR$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "exceptionInternalError" element
         */
        public int sizeOfExceptionInternalErrorArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCEPTIONINTERNALERROR$2);
            }
        }
        
        /**
         * Sets array of all "exceptionInternalError" element
         */
        public void setExceptionInternalErrorArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionInternalErrorArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(exceptionInternalErrorArray, EXCEPTIONINTERNALERROR$2);
            }
        }
        
        /**
         * Sets ith "exceptionInternalError" element
         */
        public void setExceptionInternalErrorArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionInternalError)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONINTERNALERROR$2, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(exceptionInternalError);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionInternalError" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionInternalError(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().insert_element_user(EXCEPTIONINTERNALERROR$2, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionInternalError" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionInternalError()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(EXCEPTIONINTERNALERROR$2);
                return target;
            }
        }
        
        /**
         * Removes the ith "exceptionInternalError" element
         */
        public void removeExceptionInternalError(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCEPTIONINTERNALERROR$2, i);
            }
        }
        
        /**
         * Gets a List of "exceptionInvalidInput_ObjectDoesNotExist" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionInvalidInputObjectDoesNotExistList()
        {
            final class ExceptionInvalidInputObjectDoesNotExistList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType>
            {
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getExceptionInvalidInputObjectDoesNotExistArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType set(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionInvalidInputObjectDoesNotExistArray(i);
                    UpdateInventoryExceptionImpl.this.setExceptionInvalidInputObjectDoesNotExistArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                    { UpdateInventoryExceptionImpl.this.insertNewExceptionInvalidInputObjectDoesNotExist(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionInvalidInputObjectDoesNotExistArray(i);
                    UpdateInventoryExceptionImpl.this.removeExceptionInvalidInputObjectDoesNotExist(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfExceptionInvalidInputObjectDoesNotExistArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ExceptionInvalidInputObjectDoesNotExistList();
            }
        }
        
        /**
         * Gets array of all "exceptionInvalidInput_ObjectDoesNotExist" elements
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionInvalidInputObjectDoesNotExistArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4, targetList);
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] result = new org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionInvalidInputObjectDoesNotExistArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        public int sizeOfExceptionInvalidInputObjectDoesNotExistArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4);
            }
        }
        
        /**
         * Sets array of all "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        public void setExceptionInvalidInputObjectDoesNotExistArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionInvalidInputObjectDoesNotExistArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(exceptionInvalidInputObjectDoesNotExistArray, EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4);
            }
        }
        
        /**
         * Sets ith "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        public void setExceptionInvalidInputObjectDoesNotExistArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionInvalidInputObjectDoesNotExist)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(exceptionInvalidInputObjectDoesNotExist);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionInvalidInputObjectDoesNotExist(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().insert_element_user(EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionInvalidInputObjectDoesNotExist()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4);
                return target;
            }
        }
        
        /**
         * Removes the ith "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        public void removeExceptionInvalidInputObjectDoesNotExist(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCEPTIONINVALIDINPUTOBJECTDOESNOTEXIST$4, i);
            }
        }
        
        /**
         * Gets a List of "nonexistentContainingObject" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getNonexistentContainingObjectList()
        {
            final class NonexistentContainingObjectList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType>
            {
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getNonexistentContainingObjectArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = UpdateInventoryExceptionImpl.this.getNonexistentContainingObjectArray(i);
                    UpdateInventoryExceptionImpl.this.setNonexistentContainingObjectArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                    { UpdateInventoryExceptionImpl.this.insertNewNonexistentContainingObject(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = UpdateInventoryExceptionImpl.this.getNonexistentContainingObjectArray(i);
                    UpdateInventoryExceptionImpl.this.removeNonexistentContainingObject(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfNonexistentContainingObjectArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new NonexistentContainingObjectList();
            }
        }
        
        /**
         * Gets array of all "nonexistentContainingObject" elements
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getNonexistentContainingObjectArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(NONEXISTENTCONTAININGOBJECT$6, targetList);
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "nonexistentContainingObject" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getNonexistentContainingObjectArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(NONEXISTENTCONTAININGOBJECT$6, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "nonexistentContainingObject" element
         */
        public int sizeOfNonexistentContainingObjectArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(NONEXISTENTCONTAININGOBJECT$6);
            }
        }
        
        /**
         * Sets array of all "nonexistentContainingObject" element
         */
        public void setNonexistentContainingObjectArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] nonexistentContainingObjectArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(nonexistentContainingObjectArray, NONEXISTENTCONTAININGOBJECT$6);
            }
        }
        
        /**
         * Sets ith "nonexistentContainingObject" element
         */
        public void setNonexistentContainingObjectArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType nonexistentContainingObject)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(NONEXISTENTCONTAININGOBJECT$6, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(nonexistentContainingObject);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "nonexistentContainingObject" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewNonexistentContainingObject(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().insert_element_user(NONEXISTENTCONTAININGOBJECT$6, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "nonexistentContainingObject" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewNonexistentContainingObject()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(NONEXISTENTCONTAININGOBJECT$6);
                return target;
            }
        }
        
        /**
         * Removes the ith "nonexistentContainingObject" element
         */
        public void removeNonexistentContainingObject(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(NONEXISTENTCONTAININGOBJECT$6, i);
            }
        }
        
        /**
         * Gets a List of "exceptionInvalidInput_UnsupportedObjectTypes" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionInvalidInputUnsupportedObjectTypesList()
        {
            final class ExceptionInvalidInputUnsupportedObjectTypesList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType>
            {
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getExceptionInvalidInputUnsupportedObjectTypesArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType set(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionInvalidInputUnsupportedObjectTypesArray(i);
                    UpdateInventoryExceptionImpl.this.setExceptionInvalidInputUnsupportedObjectTypesArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                    { UpdateInventoryExceptionImpl.this.insertNewExceptionInvalidInputUnsupportedObjectTypes(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionInvalidInputUnsupportedObjectTypesArray(i);
                    UpdateInventoryExceptionImpl.this.removeExceptionInvalidInputUnsupportedObjectTypes(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfExceptionInvalidInputUnsupportedObjectTypesArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ExceptionInvalidInputUnsupportedObjectTypesList();
            }
        }
        
        /**
         * Gets array of all "exceptionInvalidInput_UnsupportedObjectTypes" elements
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionInvalidInputUnsupportedObjectTypesArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8, targetList);
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] result = new org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionInvalidInputUnsupportedObjectTypesArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        public int sizeOfExceptionInvalidInputUnsupportedObjectTypesArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8);
            }
        }
        
        /**
         * Sets array of all "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        public void setExceptionInvalidInputUnsupportedObjectTypesArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionInvalidInputUnsupportedObjectTypesArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(exceptionInvalidInputUnsupportedObjectTypesArray, EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8);
            }
        }
        
        /**
         * Sets ith "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        public void setExceptionInvalidInputUnsupportedObjectTypesArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionInvalidInputUnsupportedObjectTypes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(exceptionInvalidInputUnsupportedObjectTypes);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionInvalidInputUnsupportedObjectTypes(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().insert_element_user(EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionInvalidInputUnsupportedObjectTypes()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8);
                return target;
            }
        }
        
        /**
         * Removes the ith "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        public void removeExceptionInvalidInputUnsupportedObjectTypes(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCEPTIONINVALIDINPUTUNSUPPORTEDOBJECTTYPES$8, i);
            }
        }
        
        /**
         * Gets a List of "unsupportedObjectTypes" elements
         */
        public java.util.List<java.lang.String> getUnsupportedObjectTypesList()
        {
            final class UnsupportedObjectTypesList extends java.util.AbstractList<java.lang.String>
            {
                public java.lang.String get(int i)
                    { return UpdateInventoryExceptionImpl.this.getUnsupportedObjectTypesArray(i); }
                
                public java.lang.String set(int i, java.lang.String o)
                {
                    java.lang.String old = UpdateInventoryExceptionImpl.this.getUnsupportedObjectTypesArray(i);
                    UpdateInventoryExceptionImpl.this.setUnsupportedObjectTypesArray(i, o);
                    return old;
                }
                
                public void add(int i, java.lang.String o)
                    { UpdateInventoryExceptionImpl.this.insertUnsupportedObjectTypes(i, o); }
                
                public java.lang.String remove(int i)
                {
                    java.lang.String old = UpdateInventoryExceptionImpl.this.getUnsupportedObjectTypesArray(i);
                    UpdateInventoryExceptionImpl.this.removeUnsupportedObjectTypes(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfUnsupportedObjectTypesArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new UnsupportedObjectTypesList();
            }
        }
        
        /**
         * Gets array of all "unsupportedObjectTypes" elements
         */
        public java.lang.String[] getUnsupportedObjectTypesArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(UNSUPPORTEDOBJECTTYPES$10, targetList);
                java.lang.String[] result = new java.lang.String[targetList.size()];
                for (int i = 0, len = targetList.size() ; i < len ; i++)
                    result[i] = ((org.apache.xmlbeans.SimpleValue)targetList.get(i)).getStringValue();
                return result;
            }
        }
        
        /**
         * Gets ith "unsupportedObjectTypes" element
         */
        public java.lang.String getUnsupportedObjectTypesArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UNSUPPORTEDOBJECTTYPES$10, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target.getStringValue();
            }
        }
        
        /**
         * Gets (as xml) a List of "unsupportedObjectTypes" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType> xgetUnsupportedObjectTypesList()
        {
            final class UnsupportedObjectTypesList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType>
            {
                public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType get(int i)
                    { return UpdateInventoryExceptionImpl.this.xgetUnsupportedObjectTypesArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType set(int i, org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType o)
                {
                    org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType old = UpdateInventoryExceptionImpl.this.xgetUnsupportedObjectTypesArray(i);
                    UpdateInventoryExceptionImpl.this.xsetUnsupportedObjectTypesArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType o)
                    { UpdateInventoryExceptionImpl.this.insertNewUnsupportedObjectTypes(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType old = UpdateInventoryExceptionImpl.this.xgetUnsupportedObjectTypesArray(i);
                    UpdateInventoryExceptionImpl.this.removeUnsupportedObjectTypes(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfUnsupportedObjectTypesArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new UnsupportedObjectTypesList();
            }
        }
        
        /**
         * Gets (as xml) array of all "unsupportedObjectTypes" elements
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType[] xgetUnsupportedObjectTypesArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(UNSUPPORTEDOBJECTTYPES$10, targetList);
                org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType[] result = new org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets (as xml) ith "unsupportedObjectTypes" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetUnsupportedObjectTypesArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(UNSUPPORTEDOBJECTTYPES$10, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)target;
            }
        }
        
        /**
         * Returns number of "unsupportedObjectTypes" element
         */
        public int sizeOfUnsupportedObjectTypesArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(UNSUPPORTEDOBJECTTYPES$10);
            }
        }
        
        /**
         * Sets array of all "unsupportedObjectTypes" element
         */
        public void setUnsupportedObjectTypesArray(java.lang.String[] unsupportedObjectTypesArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(unsupportedObjectTypesArray, UNSUPPORTEDOBJECTTYPES$10);
            }
        }
        
        /**
         * Sets ith "unsupportedObjectTypes" element
         */
        public void setUnsupportedObjectTypesArray(int i, java.lang.String unsupportedObjectTypes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().find_element_user(UNSUPPORTEDOBJECTTYPES$10, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.setStringValue(unsupportedObjectTypes);
            }
        }
        
        /**
         * Sets (as xml) array of all "unsupportedObjectTypes" element
         */
        public void xsetUnsupportedObjectTypesArray(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType[]unsupportedObjectTypesArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(unsupportedObjectTypesArray, UNSUPPORTEDOBJECTTYPES$10);
            }
        }
        
        /**
         * Sets (as xml) ith "unsupportedObjectTypes" element
         */
        public void xsetUnsupportedObjectTypesArray(int i, org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType unsupportedObjectTypes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().find_element_user(UNSUPPORTEDOBJECTTYPES$10, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(unsupportedObjectTypes);
            }
        }
        
        /**
         * Inserts the value as the ith "unsupportedObjectTypes" element
         */
        public void insertUnsupportedObjectTypes(int i, java.lang.String unsupportedObjectTypes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = 
                    (org.apache.xmlbeans.SimpleValue)get_store().insert_element_user(UNSUPPORTEDOBJECTTYPES$10, i);
                target.setStringValue(unsupportedObjectTypes);
            }
        }
        
        /**
         * Appends the value as the last "unsupportedObjectTypes" element
         */
        public void addUnsupportedObjectTypes(java.lang.String unsupportedObjectTypes)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.apache.xmlbeans.SimpleValue target = null;
                target = (org.apache.xmlbeans.SimpleValue)get_store().add_element_user(UNSUPPORTEDOBJECTTYPES$10);
                target.setStringValue(unsupportedObjectTypes);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "unsupportedObjectTypes" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType insertNewUnsupportedObjectTypes(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().insert_element_user(UNSUPPORTEDOBJECTTYPES$10, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "unsupportedObjectTypes" element
         */
        public org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType addNewUnsupportedObjectTypes()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType target = null;
                target = (org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType)get_store().add_element_user(UNSUPPORTEDOBJECTTYPES$10);
                return target;
            }
        }
        
        /**
         * Removes the ith "unsupportedObjectTypes" element
         */
        public void removeUnsupportedObjectTypes(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(UNSUPPORTEDOBJECTTYPES$10, i);
            }
        }
        
        /**
         * Gets a List of "exceptionInvalidInput_UnsupportAttributesOrValues" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionInvalidInputUnsupportAttributesOrValuesList()
        {
            final class ExceptionInvalidInputUnsupportAttributesOrValuesList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType>
            {
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getExceptionInvalidInputUnsupportAttributesOrValuesArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType set(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionInvalidInputUnsupportAttributesOrValuesArray(i);
                    UpdateInventoryExceptionImpl.this.setExceptionInvalidInputUnsupportAttributesOrValuesArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                    { UpdateInventoryExceptionImpl.this.insertNewExceptionInvalidInputUnsupportAttributesOrValues(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionInvalidInputUnsupportAttributesOrValuesArray(i);
                    UpdateInventoryExceptionImpl.this.removeExceptionInvalidInputUnsupportAttributesOrValues(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfExceptionInvalidInputUnsupportAttributesOrValuesArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ExceptionInvalidInputUnsupportAttributesOrValuesList();
            }
        }
        
        /**
         * Gets array of all "exceptionInvalidInput_UnsupportAttributesOrValues" elements
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionInvalidInputUnsupportAttributesOrValuesArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12, targetList);
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] result = new org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionInvalidInputUnsupportAttributesOrValuesArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        public int sizeOfExceptionInvalidInputUnsupportAttributesOrValuesArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12);
            }
        }
        
        /**
         * Sets array of all "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        public void setExceptionInvalidInputUnsupportAttributesOrValuesArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionInvalidInputUnsupportAttributesOrValuesArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(exceptionInvalidInputUnsupportAttributesOrValuesArray, EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12);
            }
        }
        
        /**
         * Sets ith "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        public void setExceptionInvalidInputUnsupportAttributesOrValuesArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionInvalidInputUnsupportAttributesOrValues)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(exceptionInvalidInputUnsupportAttributesOrValues);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionInvalidInputUnsupportAttributesOrValues(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().insert_element_user(EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionInvalidInputUnsupportAttributesOrValues()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12);
                return target;
            }
        }
        
        /**
         * Removes the ith "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        public void removeExceptionInvalidInputUnsupportAttributesOrValues(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCEPTIONINVALIDINPUTUNSUPPORTATTRIBUTESORVALUES$12, i);
            }
        }
        
        /**
         * Gets a List of "exceptionObjectInUse" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionObjectInUseList()
        {
            final class ExceptionObjectInUseList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType>
            {
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getExceptionObjectInUseArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType set(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionObjectInUseArray(i);
                    UpdateInventoryExceptionImpl.this.setExceptionObjectInUseArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                    { UpdateInventoryExceptionImpl.this.insertNewExceptionObjectInUse(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionObjectInUseArray(i);
                    UpdateInventoryExceptionImpl.this.removeExceptionObjectInUse(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfExceptionObjectInUseArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ExceptionObjectInUseList();
            }
        }
        
        /**
         * Gets array of all "exceptionObjectInUse" elements
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionObjectInUseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EXCEPTIONOBJECTINUSE$14, targetList);
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] result = new org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "exceptionObjectInUse" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionObjectInUseArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONOBJECTINUSE$14, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "exceptionObjectInUse" element
         */
        public int sizeOfExceptionObjectInUseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCEPTIONOBJECTINUSE$14);
            }
        }
        
        /**
         * Sets array of all "exceptionObjectInUse" element
         */
        public void setExceptionObjectInUseArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionObjectInUseArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(exceptionObjectInUseArray, EXCEPTIONOBJECTINUSE$14);
            }
        }
        
        /**
         * Sets ith "exceptionObjectInUse" element
         */
        public void setExceptionObjectInUseArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionObjectInUse)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONOBJECTINUSE$14, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(exceptionObjectInUse);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionObjectInUse" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionObjectInUse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().insert_element_user(EXCEPTIONOBJECTINUSE$14, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionObjectInUse" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionObjectInUse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(EXCEPTIONOBJECTINUSE$14);
                return target;
            }
        }
        
        /**
         * Removes the ith "exceptionObjectInUse" element
         */
        public void removeExceptionObjectInUse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCEPTIONOBJECTINUSE$14, i);
            }
        }
        
        /**
         * Gets a List of "objectInUse" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getObjectInUseList()
        {
            final class ObjectInUseList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType>
            {
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getObjectInUseArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = UpdateInventoryExceptionImpl.this.getObjectInUseArray(i);
                    UpdateInventoryExceptionImpl.this.setObjectInUseArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                    { UpdateInventoryExceptionImpl.this.insertNewObjectInUse(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = UpdateInventoryExceptionImpl.this.getObjectInUseArray(i);
                    UpdateInventoryExceptionImpl.this.removeObjectInUse(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfObjectInUseArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ObjectInUseList();
            }
        }
        
        /**
         * Gets array of all "objectInUse" elements
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getObjectInUseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(OBJECTINUSE$16, targetList);
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "objectInUse" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectInUseArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTINUSE$16, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "objectInUse" element
         */
        public int sizeOfObjectInUseArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(OBJECTINUSE$16);
            }
        }
        
        /**
         * Sets array of all "objectInUse" element
         */
        public void setObjectInUseArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] objectInUseArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(objectInUseArray, OBJECTINUSE$16);
            }
        }
        
        /**
         * Sets ith "objectInUse" element
         */
        public void setObjectInUseArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectInUse)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(OBJECTINUSE$16, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(objectInUse);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "objectInUse" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewObjectInUse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().insert_element_user(OBJECTINUSE$16, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "objectInUse" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectInUse()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(OBJECTINUSE$16);
                return target;
            }
        }
        
        /**
         * Removes the ith "objectInUse" element
         */
        public void removeObjectInUse(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(OBJECTINUSE$16, i);
            }
        }
        
        /**
         * Gets a List of "exceptionPolicyViolation" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionPolicyViolationList()
        {
            final class ExceptionPolicyViolationList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType>
            {
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getExceptionPolicyViolationArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType set(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionPolicyViolationArray(i);
                    UpdateInventoryExceptionImpl.this.setExceptionPolicyViolationArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType o)
                    { UpdateInventoryExceptionImpl.this.insertNewExceptionPolicyViolation(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType old = UpdateInventoryExceptionImpl.this.getExceptionPolicyViolationArray(i);
                    UpdateInventoryExceptionImpl.this.removeExceptionPolicyViolation(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfExceptionPolicyViolationArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new ExceptionPolicyViolationList();
            }
        }
        
        /**
         * Gets array of all "exceptionPolicyViolation" elements
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionPolicyViolationArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(EXCEPTIONPOLICYVIOLATION$18, targetList);
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] result = new org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "exceptionPolicyViolation" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionPolicyViolationArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONPOLICYVIOLATION$18, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "exceptionPolicyViolation" element
         */
        public int sizeOfExceptionPolicyViolationArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(EXCEPTIONPOLICYVIOLATION$18);
            }
        }
        
        /**
         * Sets array of all "exceptionPolicyViolation" element
         */
        public void setExceptionPolicyViolationArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionPolicyViolationArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(exceptionPolicyViolationArray, EXCEPTIONPOLICYVIOLATION$18);
            }
        }
        
        /**
         * Sets ith "exceptionPolicyViolation" element
         */
        public void setExceptionPolicyViolationArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionPolicyViolation)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().find_element_user(EXCEPTIONPOLICYVIOLATION$18, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(exceptionPolicyViolation);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionPolicyViolation" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionPolicyViolation(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().insert_element_user(EXCEPTIONPOLICYVIOLATION$18, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionPolicyViolation" element
         */
        public org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionPolicyViolation()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType target = null;
                target = (org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType)get_store().add_element_user(EXCEPTIONPOLICYVIOLATION$18);
                return target;
            }
        }
        
        /**
         * Removes the ith "exceptionPolicyViolation" element
         */
        public void removeExceptionPolicyViolation(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(EXCEPTIONPOLICYVIOLATION$18, i);
            }
        }
        
        /**
         * Gets a List of "baseInstance" elements
         */
        public java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getBaseInstanceList()
        {
            final class BaseInstanceList extends java.util.AbstractList<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType>
            {
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType get(int i)
                    { return UpdateInventoryExceptionImpl.this.getBaseInstanceArray(i); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType set(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = UpdateInventoryExceptionImpl.this.getBaseInstanceArray(i);
                    UpdateInventoryExceptionImpl.this.setBaseInstanceArray(i, o);
                    return old;
                }
                
                public void add(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType o)
                    { UpdateInventoryExceptionImpl.this.insertNewBaseInstance(i).set(o); }
                
                public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType remove(int i)
                {
                    org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType old = UpdateInventoryExceptionImpl.this.getBaseInstanceArray(i);
                    UpdateInventoryExceptionImpl.this.removeBaseInstance(i);
                    return old;
                }
                
                public int size()
                    { return UpdateInventoryExceptionImpl.this.sizeOfBaseInstanceArray(); }
                
            }
            
            synchronized (monitor())
            {
                check_orphaned();
                return new BaseInstanceList();
            }
        }
        
        /**
         * Gets array of all "baseInstance" elements
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getBaseInstanceArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                java.util.List targetList = new java.util.ArrayList();
                get_store().find_all_element_users(BASEINSTANCE$20, targetList);
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] result = new org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[targetList.size()];
                targetList.toArray(result);
                return result;
            }
        }
        
        /**
         * Gets ith "baseInstance" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getBaseInstanceArray(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(BASEINSTANCE$20, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                return target;
            }
        }
        
        /**
         * Returns number of "baseInstance" element
         */
        public int sizeOfBaseInstanceArray()
        {
            synchronized (monitor())
            {
                check_orphaned();
                return get_store().count_elements(BASEINSTANCE$20);
            }
        }
        
        /**
         * Sets array of all "baseInstance" element
         */
        public void setBaseInstanceArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] baseInstanceArray)
        {
            synchronized (monitor())
            {
                check_orphaned();
                arraySetterHelper(baseInstanceArray, BASEINSTANCE$20);
            }
        }
        
        /**
         * Sets ith "baseInstance" element
         */
        public void setBaseInstanceArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType baseInstance)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(BASEINSTANCE$20, i);
                if (target == null)
                {
                    throw new IndexOutOfBoundsException();
                }
                target.set(baseInstance);
            }
        }
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "baseInstance" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewBaseInstance(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().insert_element_user(BASEINSTANCE$20, i);
                return target;
            }
        }
        
        /**
         * Appends and returns a new empty value (as xml) as the last "baseInstance" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewBaseInstance()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(BASEINSTANCE$20);
                return target;
            }
        }
        
        /**
         * Removes the ith "baseInstance" element
         */
        public void removeBaseInstance(int i)
        {
            synchronized (monitor())
            {
                check_orphaned();
                get_store().remove_element(BASEINSTANCE$20, i);
            }
        }
    }
}
