/*
 * XML Type:  EffortModeType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/invu/v1
 * Java type: org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.invu.v1.impl;
/**
 * An XML EffortModeType(@http://www.tmforum.org/mtop/mri/xsd/invu/v1).
 *
 * This is an atomic type that is a restriction of org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType.
 */
public class EffortModeTypeImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.tmforum.mtop.mri.xsd.invu.v1.EffortModeType
{
    
    public EffortModeTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected EffortModeTypeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
