/*
 * An XML document type.
 * Localname: meiNotification
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/mei/v1
 * Java type: org.tmforum.mtop.mri.xsd.mei.v1.MeiNotificationDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.mei.v1.impl;
/**
 * A document containing one meiNotification(@http://www.tmforum.org/mtop/mri/xsd/mei/v1) element.
 *
 * This is a complex type.
 */
public class MeiNotificationDocumentImpl extends org.tmforum.mtop.fmw.xsd.cei.v1.impl.CommonEventInfoDocumentImpl implements org.tmforum.mtop.mri.xsd.mei.v1.MeiNotificationDocument
{
    
    public MeiNotificationDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName MEINOTIFICATION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/mei/v1", "meiNotification");
    
    
    /**
     * Gets the "meiNotification" element
     */
    public org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType getMeiNotification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType target = null;
            target = (org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType)get_store().find_element_user(MEINOTIFICATION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "meiNotification" element
     */
    public void setMeiNotification(org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType meiNotification)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType target = null;
            target = (org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType)get_store().find_element_user(MEINOTIFICATION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType)get_store().add_element_user(MEINOTIFICATION$0);
            }
            target.set(meiNotification);
        }
    }
    
    /**
     * Appends and returns a new empty "meiNotification" element
     */
    public org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType addNewMeiNotification()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType target = null;
            target = (org.tmforum.mtop.mri.xsd.mei.v1.MultiEventInventoryType)get_store().add_element_user(MEINOTIFICATION$0);
            return target;
        }
    }
}
