/*
 * An XML document type.
 * Localname: getSncsByUserLabelException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getSncsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetSncsByUserLabelExceptionDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument
{
    
    public GetSncsByUserLabelExceptionDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETSNCSBYUSERLABELEXCEPTION$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getSncsByUserLabelException");
    
    
    /**
     * Gets the "getSncsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException getGetSncsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException)get_store().find_element_user(GETSNCSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getSncsByUserLabelException" element
     */
    public void setGetSncsByUserLabelException(org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException getSncsByUserLabelException)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException)get_store().find_element_user(GETSNCSBYUSERLABELEXCEPTION$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException)get_store().add_element_user(GETSNCSBYUSERLABELEXCEPTION$0);
            }
            target.set(getSncsByUserLabelException);
        }
    }
    
    /**
     * Appends and returns a new empty "getSncsByUserLabelException" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException addNewGetSncsByUserLabelException()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException)get_store().add_element_user(GETSNCSBYUSERLABELEXCEPTION$0);
            return target;
        }
    }
    /**
     * An XML getSncsByUserLabelException(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public static class GetSncsByUserLabelExceptionImpl extends org.tmforum.mtop.fmw.xsd.msg.v1.impl.AllExceptionsTypeImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetSncsByUserLabelExceptionDocument.GetSncsByUserLabelException
    {
        
        public GetSncsByUserLabelExceptionImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        
    }
}
