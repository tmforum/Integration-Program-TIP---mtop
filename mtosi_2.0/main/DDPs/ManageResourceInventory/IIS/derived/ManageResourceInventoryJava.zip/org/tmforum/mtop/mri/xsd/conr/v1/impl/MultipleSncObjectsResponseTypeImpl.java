/*
 * XML Type:  MultipleSncObjectsResponseType
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectsResponseType
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * An XML MultipleSncObjectsResponseType(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
 *
 * This is a complex type.
 */
public class MultipleSncObjectsResponseTypeImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.MultipleSncObjectsResponseType
{
    
    public MultipleSncObjectsResponseTypeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName SNCLIST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "sncList");
    
    
    /**
     * Gets the "sncList" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType getSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType)get_store().find_element_user(SNCLIST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * True if has "sncList" element
     */
    public boolean isSetSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            return get_store().count_elements(SNCLIST$0) != 0;
        }
    }
    
    /**
     * Sets the "sncList" element
     */
    public void setSncList(org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType sncList)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType)get_store().find_element_user(SNCLIST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType)get_store().add_element_user(SNCLIST$0);
            }
            target.set(sncList);
        }
    }
    
    /**
     * Appends and returns a new empty "sncList" element
     */
    public org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType addNewSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType target = null;
            target = (org.tmforum.mtop.nrf.xsd.snc.v1.SubnetworkConnectionListType)get_store().add_element_user(SNCLIST$0);
            return target;
        }
    }
    
    /**
     * Unsets the "sncList" element
     */
    public void unsetSncList()
    {
        synchronized (monitor())
        {
            check_orphaned();
            get_store().remove_element(SNCLIST$0, 0);
        }
    }
}
