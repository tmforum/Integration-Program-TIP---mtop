/*
 * An XML document type.
 * Localname: getIntendedRouteResponse
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1;


/**
 * A document containing one getIntendedRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public interface GetIntendedRouteResponseDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetIntendedRouteResponseDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sCF63B8FC4B8F28B258F2EB26485C9EFE").resolveHandle("getintendedrouteresponseeb7edoctype");
    
    /**
     * Gets the "getIntendedRouteResponse" element
     */
    org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse getGetIntendedRouteResponse();
    
    /**
     * Sets the "getIntendedRouteResponse" element
     */
    void setGetIntendedRouteResponse(org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse getIntendedRouteResponse);
    
    /**
     * Appends and returns a new empty "getIntendedRouteResponse" element
     */
    org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse addNewGetIntendedRouteResponse();
    
    /**
     * An XML getIntendedRouteResponse(@http://www.tmforum.org/mtop/mri/xsd/conr/v1).
     *
     * This is a complex type.
     */
    public interface GetIntendedRouteResponse extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(GetIntendedRouteResponse.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sCF63B8FC4B8F28B258F2EB26485C9EFE").resolveHandle("getintendedrouteresponse2db9elemtype");
        
        /**
         * Gets the "additionalInfo" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType getAdditionalInfo();
        
        /**
         * Sets the "additionalInfo" element
         */
        void setAdditionalInfo(org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType additionalInfo);
        
        /**
         * Appends and returns a new empty "additionalInfo" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NvsListType addNewAdditionalInfo();
        
        /**
         * Gets the "route" element
         */
        org.tmforum.mtop.nrf.xsd.route.v1.RouteType getRoute();
        
        /**
         * True if has "route" element
         */
        boolean isSetRoute();
        
        /**
         * Sets the "route" element
         */
        void setRoute(org.tmforum.mtop.nrf.xsd.route.v1.RouteType route);
        
        /**
         * Appends and returns a new empty "route" element
         */
        org.tmforum.mtop.nrf.xsd.route.v1.RouteType addNewRoute();
        
        /**
         * Unsets the "route" element
         */
        void unsetRoute();
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse newInstance() {
              return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument.GetIntendedRouteResponse) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument newInstance() {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.conr.v1.GetIntendedRouteResponseDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
