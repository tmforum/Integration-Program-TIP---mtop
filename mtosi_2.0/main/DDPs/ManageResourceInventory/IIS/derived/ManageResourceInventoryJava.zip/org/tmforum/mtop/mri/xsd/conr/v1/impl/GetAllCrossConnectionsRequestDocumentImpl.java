/*
 * An XML document type.
 * Localname: getAllCrossConnectionsRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllCrossConnectionsRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllCrossConnectionsRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllCrossConnectionsRequestDocument
{
    
    public GetAllCrossConnectionsRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLCROSSCONNECTIONSREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllCrossConnectionsRequest");
    
    
    /**
     * Gets the "getAllCrossConnectionsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType getGetAllCrossConnectionsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType)get_store().find_element_user(GETALLCROSSCONNECTIONSREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllCrossConnectionsRequest" element
     */
    public void setGetAllCrossConnectionsRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType getAllCrossConnectionsRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType)get_store().find_element_user(GETALLCROSSCONNECTIONSREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType)get_store().add_element_user(GETALLCROSSCONNECTIONSREQUEST$0);
            }
            target.set(getAllCrossConnectionsRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllCrossConnectionsRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType addNewGetAllCrossConnectionsRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetCcsRequestType)get_store().add_element_user(GETALLCROSSCONNECTIONSREQUEST$0);
            return target;
        }
    }
}
