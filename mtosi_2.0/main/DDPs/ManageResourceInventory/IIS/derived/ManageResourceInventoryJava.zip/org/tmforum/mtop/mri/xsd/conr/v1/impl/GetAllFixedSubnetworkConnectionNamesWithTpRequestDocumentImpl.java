/*
 * An XML document type.
 * Localname: getAllFixedSubnetworkConnectionNamesWithTpRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/conr/v1
 * Java type: org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionNamesWithTpRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.conr.v1.impl;
/**
 * A document containing one getAllFixedSubnetworkConnectionNamesWithTpRequest(@http://www.tmforum.org/mtop/mri/xsd/conr/v1) element.
 *
 * This is a complex type.
 */
public class GetAllFixedSubnetworkConnectionNamesWithTpRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.conr.v1.GetAllFixedSubnetworkConnectionNamesWithTpRequestDocument
{
    
    public GetAllFixedSubnetworkConnectionNamesWithTpRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/conr/v1", "getAllFixedSubnetworkConnectionNamesWithTpRequest");
    
    
    /**
     * Gets the "getAllFixedSubnetworkConnectionNamesWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType getGetAllFixedSubnetworkConnectionNamesWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAllFixedSubnetworkConnectionNamesWithTpRequest" element
     */
    public void setGetAllFixedSubnetworkConnectionNamesWithTpRequest(org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType getAllFixedSubnetworkConnectionNamesWithTpRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType)get_store().find_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0);
            }
            target.set(getAllFixedSubnetworkConnectionNamesWithTpRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAllFixedSubnetworkConnectionNamesWithTpRequest" element
     */
    public org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType addNewGetAllFixedSubnetworkConnectionNamesWithTpRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType target = null;
            target = (org.tmforum.mtop.mri.xsd.conr.v1.GetSncsWithTpRequestType)get_store().add_element_user(GETALLFIXEDSUBNETWORKCONNECTIONNAMESWITHTPREQUEST$0);
            return target;
        }
    }
}
