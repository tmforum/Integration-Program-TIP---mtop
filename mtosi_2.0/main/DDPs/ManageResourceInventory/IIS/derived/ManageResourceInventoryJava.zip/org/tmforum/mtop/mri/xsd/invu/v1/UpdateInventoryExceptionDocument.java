/*
 * An XML document type.
 * Localname: updateInventoryException
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/invu/v1
 * Java type: org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.invu.v1;


/**
 * A document containing one updateInventoryException(@http://www.tmforum.org/mtop/mri/xsd/invu/v1) element.
 *
 * This is a complex type.
 */
public interface UpdateInventoryExceptionDocument extends org.apache.xmlbeans.XmlObject
{
    public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
        org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(UpdateInventoryExceptionDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sCF63B8FC4B8F28B258F2EB26485C9EFE").resolveHandle("updateinventoryexceptione07ddoctype");
    
    /**
     * Gets the "updateInventoryException" element
     */
    org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException getUpdateInventoryException();
    
    /**
     * Sets the "updateInventoryException" element
     */
    void setUpdateInventoryException(org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException updateInventoryException);
    
    /**
     * Appends and returns a new empty "updateInventoryException" element
     */
    org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException addNewUpdateInventoryException();
    
    /**
     * An XML updateInventoryException(@http://www.tmforum.org/mtop/mri/xsd/invu/v1).
     *
     * This is a complex type.
     */
    public interface UpdateInventoryException extends org.apache.xmlbeans.XmlObject
    {
        public static final org.apache.xmlbeans.SchemaType type = (org.apache.xmlbeans.SchemaType)
            org.apache.xmlbeans.XmlBeans.typeSystemForClassLoader(UpdateInventoryException.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.sCF63B8FC4B8F28B258F2EB26485C9EFE").resolveHandle("updateinventoryexceptiond1e5elemtype");
        
        /**
         * Gets a List of "exceptionNotImplemented" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionNotImplementedList();
        
        /**
         * Gets array of all "exceptionNotImplemented" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionNotImplementedArray();
        
        /**
         * Gets ith "exceptionNotImplemented" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionNotImplementedArray(int i);
        
        /**
         * Returns number of "exceptionNotImplemented" element
         */
        int sizeOfExceptionNotImplementedArray();
        
        /**
         * Sets array of all "exceptionNotImplemented" element
         */
        void setExceptionNotImplementedArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionNotImplementedArray);
        
        /**
         * Sets ith "exceptionNotImplemented" element
         */
        void setExceptionNotImplementedArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionNotImplemented);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionNotImplemented" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionNotImplemented(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionNotImplemented" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionNotImplemented();
        
        /**
         * Removes the ith "exceptionNotImplemented" element
         */
        void removeExceptionNotImplemented(int i);
        
        /**
         * Gets a List of "exceptionInternalError" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionInternalErrorList();
        
        /**
         * Gets array of all "exceptionInternalError" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionInternalErrorArray();
        
        /**
         * Gets ith "exceptionInternalError" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionInternalErrorArray(int i);
        
        /**
         * Returns number of "exceptionInternalError" element
         */
        int sizeOfExceptionInternalErrorArray();
        
        /**
         * Sets array of all "exceptionInternalError" element
         */
        void setExceptionInternalErrorArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionInternalErrorArray);
        
        /**
         * Sets ith "exceptionInternalError" element
         */
        void setExceptionInternalErrorArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionInternalError);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionInternalError" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionInternalError(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionInternalError" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionInternalError();
        
        /**
         * Removes the ith "exceptionInternalError" element
         */
        void removeExceptionInternalError(int i);
        
        /**
         * Gets a List of "exceptionInvalidInput_ObjectDoesNotExist" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionInvalidInputObjectDoesNotExistList();
        
        /**
         * Gets array of all "exceptionInvalidInput_ObjectDoesNotExist" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionInvalidInputObjectDoesNotExistArray();
        
        /**
         * Gets ith "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionInvalidInputObjectDoesNotExistArray(int i);
        
        /**
         * Returns number of "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        int sizeOfExceptionInvalidInputObjectDoesNotExistArray();
        
        /**
         * Sets array of all "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        void setExceptionInvalidInputObjectDoesNotExistArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionInvalidInputObjectDoesNotExistArray);
        
        /**
         * Sets ith "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        void setExceptionInvalidInputObjectDoesNotExistArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionInvalidInputObjectDoesNotExist);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionInvalidInputObjectDoesNotExist(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionInvalidInputObjectDoesNotExist();
        
        /**
         * Removes the ith "exceptionInvalidInput_ObjectDoesNotExist" element
         */
        void removeExceptionInvalidInputObjectDoesNotExist(int i);
        
        /**
         * Gets a List of "nonexistentContainingObject" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getNonexistentContainingObjectList();
        
        /**
         * Gets array of all "nonexistentContainingObject" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getNonexistentContainingObjectArray();
        
        /**
         * Gets ith "nonexistentContainingObject" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getNonexistentContainingObjectArray(int i);
        
        /**
         * Returns number of "nonexistentContainingObject" element
         */
        int sizeOfNonexistentContainingObjectArray();
        
        /**
         * Sets array of all "nonexistentContainingObject" element
         */
        void setNonexistentContainingObjectArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] nonexistentContainingObjectArray);
        
        /**
         * Sets ith "nonexistentContainingObject" element
         */
        void setNonexistentContainingObjectArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType nonexistentContainingObject);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "nonexistentContainingObject" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewNonexistentContainingObject(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "nonexistentContainingObject" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewNonexistentContainingObject();
        
        /**
         * Removes the ith "nonexistentContainingObject" element
         */
        void removeNonexistentContainingObject(int i);
        
        /**
         * Gets a List of "exceptionInvalidInput_UnsupportedObjectTypes" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionInvalidInputUnsupportedObjectTypesList();
        
        /**
         * Gets array of all "exceptionInvalidInput_UnsupportedObjectTypes" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionInvalidInputUnsupportedObjectTypesArray();
        
        /**
         * Gets ith "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionInvalidInputUnsupportedObjectTypesArray(int i);
        
        /**
         * Returns number of "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        int sizeOfExceptionInvalidInputUnsupportedObjectTypesArray();
        
        /**
         * Sets array of all "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        void setExceptionInvalidInputUnsupportedObjectTypesArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionInvalidInputUnsupportedObjectTypesArray);
        
        /**
         * Sets ith "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        void setExceptionInvalidInputUnsupportedObjectTypesArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionInvalidInputUnsupportedObjectTypes);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionInvalidInputUnsupportedObjectTypes(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionInvalidInputUnsupportedObjectTypes();
        
        /**
         * Removes the ith "exceptionInvalidInput_UnsupportedObjectTypes" element
         */
        void removeExceptionInvalidInputUnsupportedObjectTypes(int i);
        
        /**
         * Gets a List of "unsupportedObjectTypes" elements
         */
        java.util.List<java.lang.String> getUnsupportedObjectTypesList();
        
        /**
         * Gets array of all "unsupportedObjectTypes" elements
         * @deprecated
         */
        java.lang.String[] getUnsupportedObjectTypesArray();
        
        /**
         * Gets ith "unsupportedObjectTypes" element
         */
        java.lang.String getUnsupportedObjectTypesArray(int i);
        
        /**
         * Gets (as xml) a List of "unsupportedObjectTypes" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType> xgetUnsupportedObjectTypesList();
        
        /**
         * Gets (as xml) array of all "unsupportedObjectTypes" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType[] xgetUnsupportedObjectTypesArray();
        
        /**
         * Gets (as xml) ith "unsupportedObjectTypes" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType xgetUnsupportedObjectTypesArray(int i);
        
        /**
         * Returns number of "unsupportedObjectTypes" element
         */
        int sizeOfUnsupportedObjectTypesArray();
        
        /**
         * Sets array of all "unsupportedObjectTypes" element
         */
        void setUnsupportedObjectTypesArray(java.lang.String[] unsupportedObjectTypesArray);
        
        /**
         * Sets ith "unsupportedObjectTypes" element
         */
        void setUnsupportedObjectTypesArray(int i, java.lang.String unsupportedObjectTypes);
        
        /**
         * Sets (as xml) array of all "unsupportedObjectTypes" element
         */
        void xsetUnsupportedObjectTypesArray(org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType[] unsupportedObjectTypesArray);
        
        /**
         * Sets (as xml) ith "unsupportedObjectTypes" element
         */
        void xsetUnsupportedObjectTypesArray(int i, org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType unsupportedObjectTypes);
        
        /**
         * Inserts the value as the ith "unsupportedObjectTypes" element
         */
        void insertUnsupportedObjectTypes(int i, java.lang.String unsupportedObjectTypes);
        
        /**
         * Appends the value as the last "unsupportedObjectTypes" element
         */
        void addUnsupportedObjectTypes(java.lang.String unsupportedObjectTypes);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "unsupportedObjectTypes" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType insertNewUnsupportedObjectTypes(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "unsupportedObjectTypes" element
         */
        org.tmforum.mtop.fmw.xsd.gen.v1.ObjectTypeType addNewUnsupportedObjectTypes();
        
        /**
         * Removes the ith "unsupportedObjectTypes" element
         */
        void removeUnsupportedObjectTypes(int i);
        
        /**
         * Gets a List of "exceptionInvalidInput_UnsupportAttributesOrValues" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionInvalidInputUnsupportAttributesOrValuesList();
        
        /**
         * Gets array of all "exceptionInvalidInput_UnsupportAttributesOrValues" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionInvalidInputUnsupportAttributesOrValuesArray();
        
        /**
         * Gets ith "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionInvalidInputUnsupportAttributesOrValuesArray(int i);
        
        /**
         * Returns number of "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        int sizeOfExceptionInvalidInputUnsupportAttributesOrValuesArray();
        
        /**
         * Sets array of all "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        void setExceptionInvalidInputUnsupportAttributesOrValuesArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionInvalidInputUnsupportAttributesOrValuesArray);
        
        /**
         * Sets ith "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        void setExceptionInvalidInputUnsupportAttributesOrValuesArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionInvalidInputUnsupportAttributesOrValues);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionInvalidInputUnsupportAttributesOrValues(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionInvalidInputUnsupportAttributesOrValues();
        
        /**
         * Removes the ith "exceptionInvalidInput_UnsupportAttributesOrValues" element
         */
        void removeExceptionInvalidInputUnsupportAttributesOrValues(int i);
        
        /**
         * Gets a List of "exceptionObjectInUse" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionObjectInUseList();
        
        /**
         * Gets array of all "exceptionObjectInUse" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionObjectInUseArray();
        
        /**
         * Gets ith "exceptionObjectInUse" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionObjectInUseArray(int i);
        
        /**
         * Returns number of "exceptionObjectInUse" element
         */
        int sizeOfExceptionObjectInUseArray();
        
        /**
         * Sets array of all "exceptionObjectInUse" element
         */
        void setExceptionObjectInUseArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionObjectInUseArray);
        
        /**
         * Sets ith "exceptionObjectInUse" element
         */
        void setExceptionObjectInUseArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionObjectInUse);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionObjectInUse" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionObjectInUse(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionObjectInUse" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionObjectInUse();
        
        /**
         * Removes the ith "exceptionObjectInUse" element
         */
        void removeExceptionObjectInUse(int i);
        
        /**
         * Gets a List of "objectInUse" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getObjectInUseList();
        
        /**
         * Gets array of all "objectInUse" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getObjectInUseArray();
        
        /**
         * Gets ith "objectInUse" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getObjectInUseArray(int i);
        
        /**
         * Returns number of "objectInUse" element
         */
        int sizeOfObjectInUseArray();
        
        /**
         * Sets array of all "objectInUse" element
         */
        void setObjectInUseArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] objectInUseArray);
        
        /**
         * Sets ith "objectInUse" element
         */
        void setObjectInUseArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType objectInUse);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "objectInUse" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewObjectInUse(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "objectInUse" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewObjectInUse();
        
        /**
         * Removes the ith "objectInUse" element
         */
        void removeObjectInUse(int i);
        
        /**
         * Gets a List of "exceptionPolicyViolation" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType> getExceptionPolicyViolationList();
        
        /**
         * Gets array of all "exceptionPolicyViolation" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] getExceptionPolicyViolationArray();
        
        /**
         * Gets ith "exceptionPolicyViolation" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType getExceptionPolicyViolationArray(int i);
        
        /**
         * Returns number of "exceptionPolicyViolation" element
         */
        int sizeOfExceptionPolicyViolationArray();
        
        /**
         * Sets array of all "exceptionPolicyViolation" element
         */
        void setExceptionPolicyViolationArray(org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType[] exceptionPolicyViolationArray);
        
        /**
         * Sets ith "exceptionPolicyViolation" element
         */
        void setExceptionPolicyViolationArray(int i, org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType exceptionPolicyViolation);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "exceptionPolicyViolation" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType insertNewExceptionPolicyViolation(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "exceptionPolicyViolation" element
         */
        org.tmforum.mtop.fmw.xsd.msg.v1.BaseExceptionMessageType addNewExceptionPolicyViolation();
        
        /**
         * Removes the ith "exceptionPolicyViolation" element
         */
        void removeExceptionPolicyViolation(int i);
        
        /**
         * Gets a List of "baseInstance" elements
         */
        java.util.List<org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType> getBaseInstanceList();
        
        /**
         * Gets array of all "baseInstance" elements
         * @deprecated
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] getBaseInstanceArray();
        
        /**
         * Gets ith "baseInstance" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getBaseInstanceArray(int i);
        
        /**
         * Returns number of "baseInstance" element
         */
        int sizeOfBaseInstanceArray();
        
        /**
         * Sets array of all "baseInstance" element
         */
        void setBaseInstanceArray(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType[] baseInstanceArray);
        
        /**
         * Sets ith "baseInstance" element
         */
        void setBaseInstanceArray(int i, org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType baseInstance);
        
        /**
         * Inserts and returns a new empty value (as xml) as the ith "baseInstance" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType insertNewBaseInstance(int i);
        
        /**
         * Appends and returns a new empty value (as xml) as the last "baseInstance" element
         */
        org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewBaseInstance();
        
        /**
         * Removes the ith "baseInstance" element
         */
        void removeBaseInstance(int i);
        
        /**
         * A factory class with static methods for creating instances
         * of this type.
         */
        
        public static final class Factory
        {
            public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException newInstance() {
              return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
            
            public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException newInstance(org.apache.xmlbeans.XmlOptions options) {
              return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument.UpdateInventoryException) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
            
            private Factory() { } // No instance of this class allowed
        }
    }
    
    /**
     * A factory class with static methods for creating instances
     * of this type.
     */
    
    public static final class Factory
    {
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument newInstance() {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument newInstance(org.apache.xmlbeans.XmlOptions options) {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newInstance( type, options ); }
        
        /** @param xmlAsString the string value to parse */
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.lang.String xmlAsString) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.lang.String xmlAsString, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xmlAsString, type, options ); }
        
        /** @param file the file from which to load an xml document */
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.io.File file) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.io.File file, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( file, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.net.URL u) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.net.URL u, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( u, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.io.InputStream is) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.io.InputStream is, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( is, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.io.Reader r) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(java.io.Reader r, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, java.io.IOException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( r, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(javax.xml.stream.XMLStreamReader sr) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(javax.xml.stream.XMLStreamReader sr, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( sr, type, options ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(org.w3c.dom.Node node) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, null ); }
        
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(org.w3c.dom.Node node, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( node, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument parse(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return (org.tmforum.mtop.mri.xsd.invu.v1.UpdateInventoryExceptionDocument) org.apache.xmlbeans.XmlBeans.getContextTypeLoader().parse( xis, type, options ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, null ); }
        
        /** @deprecated {@link org.apache.xmlbeans.xml.stream.XMLInputStream} */
        public static org.apache.xmlbeans.xml.stream.XMLInputStream newValidatingXMLInputStream(org.apache.xmlbeans.xml.stream.XMLInputStream xis, org.apache.xmlbeans.XmlOptions options) throws org.apache.xmlbeans.XmlException, org.apache.xmlbeans.xml.stream.XMLStreamException {
          return org.apache.xmlbeans.XmlBeans.getContextTypeLoader().newValidatingXMLInputStream( xis, type, options ); }
        
        private Factory() { } // No instance of this class allowed
    }
}
