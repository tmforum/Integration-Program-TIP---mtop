/*
 * An XML document type.
 * Localname: getAssigningMfdRequest
 * Namespace: http://www.tmforum.org/mtop/mri/xsd/fdr/v1
 * Java type: org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument
 *
 * Automatically generated - do not modify.
 */
package org.tmforum.mtop.mri.xsd.fdr.v1.impl;
/**
 * A document containing one getAssigningMfdRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1) element.
 *
 * This is a complex type.
 */
public class GetAssigningMfdRequestDocumentImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument
{
    
    public GetAssigningMfdRequestDocumentImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType);
    }
    
    private static final javax.xml.namespace.QName GETASSIGNINGMFDREQUEST$0 = 
        new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "getAssigningMfdRequest");
    
    
    /**
     * Gets the "getAssigningMfdRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest getGetAssigningMfdRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest)get_store().find_element_user(GETASSIGNINGMFDREQUEST$0, 0);
            if (target == null)
            {
                return null;
            }
            return target;
        }
    }
    
    /**
     * Sets the "getAssigningMfdRequest" element
     */
    public void setGetAssigningMfdRequest(org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest getAssigningMfdRequest)
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest)get_store().find_element_user(GETASSIGNINGMFDREQUEST$0, 0);
            if (target == null)
            {
                target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest)get_store().add_element_user(GETASSIGNINGMFDREQUEST$0);
            }
            target.set(getAssigningMfdRequest);
        }
    }
    
    /**
     * Appends and returns a new empty "getAssigningMfdRequest" element
     */
    public org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest addNewGetAssigningMfdRequest()
    {
        synchronized (monitor())
        {
            check_orphaned();
            org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest target = null;
            target = (org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest)get_store().add_element_user(GETASSIGNINGMFDREQUEST$0);
            return target;
        }
    }
    /**
     * An XML getAssigningMfdRequest(@http://www.tmforum.org/mtop/mri/xsd/fdr/v1).
     *
     * This is a complex type.
     */
    public static class GetAssigningMfdRequestImpl extends org.apache.xmlbeans.impl.values.XmlComplexContentImpl implements org.tmforum.mtop.mri.xsd.fdr.v1.GetAssigningMfdRequestDocument.GetAssigningMfdRequest
    {
        
        public GetAssigningMfdRequestImpl(org.apache.xmlbeans.SchemaType sType)
        {
            super(sType);
        }
        
        private static final javax.xml.namespace.QName CPTPNAME$0 = 
            new javax.xml.namespace.QName("http://www.tmforum.org/mtop/mri/xsd/fdr/v1", "cptpName");
        
        
        /**
         * Gets the "cptpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType getCptpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(CPTPNAME$0, 0);
                if (target == null)
                {
                    return null;
                }
                return target;
            }
        }
        
        /**
         * Sets the "cptpName" element
         */
        public void setCptpName(org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType cptpName)
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().find_element_user(CPTPNAME$0, 0);
                if (target == null)
                {
                    target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(CPTPNAME$0);
                }
                target.set(cptpName);
            }
        }
        
        /**
         * Appends and returns a new empty "cptpName" element
         */
        public org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType addNewCptpName()
        {
            synchronized (monitor())
            {
                check_orphaned();
                org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType target = null;
                target = (org.tmforum.mtop.fmw.xsd.nam.v1.NamingAttributesType)get_store().add_element_user(CPTPNAME$0);
                return target;
            }
        }
    }
}
