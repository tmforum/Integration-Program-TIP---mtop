﻿/**
 *
 * Copyright (c) 2002-2004 Bluetetra Software.  All rights reserved.
 *
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL BLUETETRA SOFTWARE BE LIABLE FOR 
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE 
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER 
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *  
 * http://www.bluetetra.com
 *
 */

var wc_target = "content";
var wc_fileName = "wsdlComponentIndex.html";
var wc_nsFilterFileName = "nsFilter.html";


function WCN (href, name, appendNSFlag, children) {
	this.href = href;
	this.name = name;
	this.appendNSFlag = appendNSFlag;

	this.children = children;
	this.hasChild = (children != null) && (children.length>0);	
	
	this.namespace = null;
}

function WC (serviceList, messageList, portTypeList, bindingList)
{
	this.services = serviceList;
	this.messages = messageList;
	this.portTypes = portTypeList;
	this.bindings = bindingList;
}

function wc_showAllComponents() {
	parent._wsdlNsFilter = null;
	parent.index.location.href= "wsdl/" + wc_fileName;
}

function wc_filterComponents () {
	parent._href = "wsdl/" + wc_fileName;
	window.open(wc_nsFilterFileName, "_blank", 
		"height=200,width=400,location=no,menubar=no,scrollbars=yes,status=yes,resizable=yes,toolbar=no");

}

function wc_groupByNS (flag) {
	parent._groupByNSFlag = flag;
	parent.index.location.href= wc_fileName;	
}

function wc_setFilterToAll() {
	var nsList = new Array();
	var i = 0;

	for (var ns in wcDB) {
		nsList[i] = ns; 		
		i++;
	}

	parent._wsdlNsFilter = nsList;
}


function wc_showComponentsNoNS (nsList, componentList) {

	var components = new Array ();
	var n = 0;

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			components[n] = list[j];
			components[n].namespace = namespace;
			n++;	
		}	
	}
	
	components = components.sort(function (n1,n2) {return n1.name.toLowerCase().localeCompare (n2.name.toLowerCase());});

	wc_outputList (null, components);	
}


function wc_showComponentsNS (nsList, componentList) {

	for (var i=0; i<componentList.length; i++) {
		var list = componentList [i];
		var namespace = nsList[i];

		if (list == null) {
			continue;
		}
	
		for (var j=0; j<list.length; j++) {
			list[j].namespace = namespace;
		}	

		wc_outputList (namespace, list);	
	}
}


function wc_showComponents (nsList, componentList) {
	if (parent._groupByNSFlag) {
		wc_showComponentsNS (nsList, componentList)
	} else {
		wc_showComponentsNoNS (nsList, componentList)
	}
}

function wc_showServices() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var services = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		services [i] = wcDB [nsList[i]].services;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, services);
}

function wc_showMessages() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var messages = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		messages [i] = wcDB [nsList[i]].messages;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, messages);
}

function wc_showPortTypes() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var portTypes = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		portTypes [i] = wcDB [nsList[i]].portTypes;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, portTypes);
}


function wc_showBindings() {
	if (parent._wsdlNsFilter == null) {
		wc_setFilterToAll();		
	}
	
	var nsList = parent._wsdlNsFilter;
	var bindings = new Array();
	var nss = new Array();

	for (var i=0; i<nsList.length; i++) {
		bindings [i] = wcDB [nsList[i]].bindings;	
		nss[i] = nsList[i];
	}		

	wc_showComponents (nss, bindings);
}

function wc_getNodeText(node) {
	if (node.appendNSFlag) {
		return node.name + "("+encodeURI(node.namespace)+")";
	} else {
		return node.name;
	} 
}

function wc_outputLeaf (node) {
	var str = '<span class="leaf">'+
			  '<nobr><img src="img/leaf.gif" hspace="2" align="middle">'+
			  '<a class="chref" href="'+node.href+
			  '" title="'+ wc_getNodeText(node)+
			  '" target="'+ wc_target+'">'+ wc_getNodeText(node)+'</a></nobr>'+
			  '</span><br />'
	
	document.write (str);
}

function wc_outputNonLeaf (node) {
	//initially, the childnodes are hidden

	var str = '<div><div class="nonleaf">'+
			'<nobr><img style="cursor: pointer" src="img/plus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
			'<a class="chref" href="'+node.href+
			'" title="'+ wc_getNodeText(node)+
			'" target="'+ wc_target +'">'+ wc_getNodeText(node)+'</a></nobr></div>'+
			'<div style="display:none;margin-left: 0.8em">';

	document.write (str);

	var childs = node.children;
	for (var i=0; i<childs.length; i++) {
		wc_outputTree (childs[i]);
	}					

	document.write ('</div></div>');
}

function wc_outputTree (node) {
	if (node.hasChild == false) {
		wc_outputLeaf (node);
	} else {
		wc_outputNonLeaf (node);
	}
}

function wc_outputList (ns, list) {	
	
	if (list == null || list.length<=0) {
		return;
	}

	if (parent._groupByNSFlag) {
		var fpath = wcNSMap[ns];

		var str = '<div class="nsBox"><div class="itemNS">'+
				'<nobr><img style="cursor: pointer" src="img/minus.gif" hspace="2" align="middle" onclick="IClick(this)">'+
				'<a class="chref" href="'+fpath+
				'" title="'+encodeURI(ns)+
				'" target="'+ wc_target +'">'+encodeURI(ns)+'</a></nobr></div>'+
				'<div style="margin-left: 0.5em">';

		document.write (str);
	}

	for (var i=0; i<list.length; i++) {
		wc_outputTree (list[i]);
	}
	
	if (parent._groupByNSFlag) {
		document.write ('</div></div>');
	}
}

var wcDB = new Array();
var wcNSMap = new Array();

wcDB ["http://www.tmforum.org/mtop/sa/wsdl/sai/v1-0"] =  new WC (
					new Array(new WCN("22/service/ServiceActivationInterfaceHttp.html","ServiceActivationInterfaceHttp",false,null),new WCN("22/service/ServiceActivationInterfaceJms.html","ServiceActivationInterfaceJms",false,null)),
					new Array(new WCN("22/message/activateException.html","activateException",true,null),new WCN("22/message/activateRequest.html","activateRequest",true,null),new WCN("22/message/activateResponse.html","activateResponse",true,null),new WCN("22/message/amendException.html","amendException",false,null),new WCN("22/message/amendRequest.html","amendRequest",false,null),new WCN("22/message/amendResponse.html","amendResponse",false,null),new WCN("22/message/cancelException.html","cancelException",false,null),new WCN("22/message/cancelRequest.html","cancelRequest",false,null),new WCN("22/message/cancelResponse.html","cancelResponse",false,null),new WCN("22/message/deactivateException.html","deactivateException",true,null),new WCN("22/message/deactivateRequest.html","deactivateRequest",true,null),new WCN("22/message/deactivateResponse.html","deactivateResponse",true,null),new WCN("22/message/designException.html","designException",false,null),new WCN("22/message/designRequest.html","designRequest",false,null),new WCN("22/message/designResponse.html","designResponse",false,null),new WCN("22/message/feasibilityCheckException.html","feasibilityCheckException",true,null),new WCN("22/message/feasibilityCheckRequest.html","feasibilityCheckRequest",true,null),new WCN("22/message/feasibilityCheckResponse.html","feasibilityCheckResponse",true,null),new WCN("22/message/modifyException.html","modifyException",true,null),new WCN("22/message/modifyRequest.html","modifyRequest",true,null),new WCN("22/message/modifyResponse.html","modifyResponse",true,null),new WCN("22/message/provisionException.html","provisionException",true,null),new WCN("22/message/provisionRequest.html","provisionRequest",true,null),new WCN("22/message/provisionResponse.html","provisionResponse",true,null),new WCN("22/message/reserveException.html","reserveException",true,null),new WCN("22/message/reserveRequest.html","reserveRequest",true,null),new WCN("22/message/reserveResponse.html","reserveResponse",true,null),new WCN("22/message/retireException.html","retireException",false,null),new WCN("22/message/retireRequest.html","retireRequest",false,null),new WCN("22/message/retireResponse.html","retireResponse",false,null),new WCN("22/message/retrieveServiceStatesException.html","retrieveServiceStatesException",false,null),new WCN("22/message/retrieveServiceStatesRequest.html","retrieveServiceStatesRequest",false,null),new WCN("22/message/retrieveServiceStatesResponse.html","retrieveServiceStatesResponse",false,null),new WCN("22/message/terminateException.html","terminateException",true,null),new WCN("22/message/terminateRequest.html","terminateRequest",true,null),new WCN("22/message/terminateResponse.html","terminateResponse",true,null),new WCN("22/message/testException.html","testException",false,null),new WCN("22/message/testRequest.html","testRequest",false,null),new WCN("22/message/testResponse.html","testResponse",false,null)),
					new Array(new WCN("22/porttype/ServiceActivationInterface.html","ServiceActivationInterface",false,new Array(new WCN("22/operation/activate_0.html","activate",false,null),new WCN("22/operation/amend_1.html","amend",false,null),new WCN("22/operation/cancel_2.html","cancel",false,null),new WCN("22/operation/deactivate_3.html","deactivate",false,null),new WCN("22/operation/design_4.html","design",false,null),new WCN("22/operation/feasibilityCheck_5.html","feasibilityCheck",false,null),new WCN("22/operation/modify_6.html","modify",false,null),new WCN("22/operation/provision_7.html","provision",false,null),new WCN("22/operation/reserve_8.html","reserve",false,null),new WCN("22/operation/retire_9.html","retire",false,null),new WCN("22/operation/retrieveServiceStates_10.html","retrieveServiceStates",false,null),new WCN("22/operation/terminate_11.html","terminate",false,null),new WCN("22/operation/test_12.html","test",false,null)))),
					new Array(new WCN("22/binding/ServiceActivationInterfaceSoapHttpBinding.html","ServiceActivationInterfaceSoapHttpBinding",false,new Array(new WCN("22/operation/activate_0.html","activate",false,null),new WCN("22/operation/amend_1.html","amend",false,null),new WCN("22/operation/cancel_2.html","cancel",false,null),new WCN("22/operation/deactivate_3.html","deactivate",false,null),new WCN("22/operation/design_4.html","design",false,null),new WCN("22/operation/feasibilityCheck_5.html","feasibilityCheck",false,null),new WCN("22/operation/modify_6.html","modify",false,null),new WCN("22/operation/provision_7.html","provision",false,null),new WCN("22/operation/reserve_8.html","reserve",false,null),new WCN("22/operation/retire_9.html","retire",false,null),new WCN("22/operation/retrieveServiceStates_10.html","retrieveServiceStates",false,null),new WCN("22/operation/terminate_11.html","terminate",false,null),new WCN("22/operation/test_12.html","test",false,null))),new WCN("22/binding/ServiceActivationInterfaceSoapJmsBinding.html","ServiceActivationInterfaceSoapJmsBinding",false,new Array(new WCN("22/operation/activate_0.html","activate",false,null),new WCN("22/operation/amend_1.html","amend",false,null),new WCN("22/operation/cancel_2.html","cancel",false,null),new WCN("22/operation/deactivate_3.html","deactivate",false,null),new WCN("22/operation/design_4.html","design",false,null),new WCN("22/operation/feasibilityCheck_5.html","feasibilityCheck",false,null),new WCN("22/operation/modify_6.html","modify",false,null),new WCN("22/operation/provision_7.html","provision",false,null),new WCN("22/operation/reserve_8.html","reserve",false,null),new WCN("22/operation/retire_9.html","retire",false,null),new WCN("22/operation/retrieveServiceStates_10.html","retrieveServiceStates",false,null),new WCN("22/operation/terminate_11.html","terminate",false,null),new WCN("22/operation/test_12.html","test",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/sa/wsdl/sai/v1-0"] = "22/index.html";
wcDB ["http://www.tmforum.org/mtop/sa/wsdl/scai/v1-0"] =  new WC (
					new Array(new WCN("23/service/ServiceComponentActivationInterfaceHttp.html","ServiceComponentActivationInterfaceHttp",false,null),new WCN("23/service/ServiceComponentActivationInterfaceJms.html","ServiceComponentActivationInterfaceJms",false,null)),
					new Array(new WCN("23/message/activateException.html","activateException",true,null),new WCN("23/message/activateRequest.html","activateRequest",true,null),new WCN("23/message/activateResponse.html","activateResponse",true,null),new WCN("23/message/deactivateException.html","deactivateException",true,null),new WCN("23/message/deactivateRequest.html","deactivateRequest",true,null),new WCN("23/message/deactivateResponse.html","deactivateResponse",true,null),new WCN("23/message/feasibilityCheckException.html","feasibilityCheckException",true,null),new WCN("23/message/feasibilityCheckRequest.html","feasibilityCheckRequest",true,null),new WCN("23/message/feasibilityCheckResponse.html","feasibilityCheckResponse",true,null),new WCN("23/message/modifyException.html","modifyException",true,null),new WCN("23/message/modifyRequest.html","modifyRequest",true,null),new WCN("23/message/modifyResponse.html","modifyResponse",true,null),new WCN("23/message/provisionException.html","provisionException",true,null),new WCN("23/message/provisionRequest.html","provisionRequest",true,null),new WCN("23/message/provisionResponse.html","provisionResponse",true,null),new WCN("23/message/reserveException.html","reserveException",true,null),new WCN("23/message/reserveRequest.html","reserveRequest",true,null),new WCN("23/message/reserveResponse.html","reserveResponse",true,null),new WCN("23/message/terminateException.html","terminateException",true,null),new WCN("23/message/terminateRequest.html","terminateRequest",true,null),new WCN("23/message/terminateResponse.html","terminateResponse",true,null)),
					new Array(new WCN("23/porttype/ServiceComponentActivationInterface.html","ServiceComponentActivationInterface",false,new Array(new WCN("23/operation/activate_16.html","activate",false,null),new WCN("23/operation/deactivate_17.html","deactivate",false,null),new WCN("23/operation/feasibilityCheck_13.html","feasibilityCheck",false,null),new WCN("23/operation/modify_19.html","modify",false,null),new WCN("23/operation/provision_15.html","provision",false,null),new WCN("23/operation/reserve_14.html","reserve",false,null),new WCN("23/operation/terminate_18.html","terminate",false,null)))),
					new Array(new WCN("23/binding/ServiceComponentActivationInterfaceSoapHttpBinding.html","ServiceComponentActivationInterfaceSoapHttpBinding",false,new Array(new WCN("23/operation/activate_16.html","activate",false,null),new WCN("23/operation/deactivate_17.html","deactivate",false,null),new WCN("23/operation/feasibilityCheck_13.html","feasibilityCheck",false,null),new WCN("23/operation/modify_19.html","modify",false,null),new WCN("23/operation/provision_15.html","provision",false,null),new WCN("23/operation/reserve_14.html","reserve",false,null),new WCN("23/operation/terminate_18.html","terminate",false,null))),new WCN("23/binding/ServiceComponentActivationInterfaceSoapJmsBinding.html","ServiceComponentActivationInterfaceSoapJmsBinding",false,new Array(new WCN("23/operation/activate_16.html","activate",false,null),new WCN("23/operation/deactivate_17.html","deactivate",false,null),new WCN("23/operation/feasibilityCheck_13.html","feasibilityCheck",false,null),new WCN("23/operation/modify_19.html","modify",false,null),new WCN("23/operation/provision_15.html","provision",false,null),new WCN("23/operation/reserve_14.html","reserve",false,null),new WCN("23/operation/terminate_18.html","terminate",false,null))))
					);

wcNSMap ["http://www.tmforum.org/mtop/sa/wsdl/scai/v1-0"] = "23/index.html";
