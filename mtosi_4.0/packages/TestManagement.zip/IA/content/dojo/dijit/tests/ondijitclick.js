if(!dojo._hasResource["dijit.tests.ondijitclick"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests.ondijitclick"] = true;
dojo.provide("dijit.tests.ondijitclick");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.ondijitclick", dojo.moduleUrl("dijit", "tests/ondijitclick.html"));
}

}
