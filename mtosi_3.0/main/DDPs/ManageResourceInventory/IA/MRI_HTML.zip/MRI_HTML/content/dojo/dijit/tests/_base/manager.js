if(!dojo._hasResource["dijit.tests._base.manager"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests._base.manager"] = true;
dojo.provide("dijit.tests._base.manager");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests._base.manager", dojo.moduleUrl("dijit", "tests/_base/manager.html"));
}

}
